<?php
require_once 'config.php';

// Display errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<html><body style='font-family: sans-serif; padding: 40px; background: #f8fafc; color: #1e293b;'>";
echo "<div style='max-width: 700px; margin: 0 auto; background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.05);'>";
echo "<h1 style='color: #ef4444; margin-top: 0;'>⚠️ Veritabanı Tablolarını Yeniden Oluşturma</h1>";
echo "<p style='color: #64748b;'>Bu işlem, mevcut hatalı veya eski sütun yapısına sahip tabloları silecek ve DramicBox JSON-veri yapısına uygun olarak yeniden oluşturacaktır. Verileriniz local JSON yedeklerinizden (public/Database/) tekrar aktarılacaktır.</p><hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;'>";

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT            => 5,
    ];
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    echo "<p style='color: green; font-weight: bold;'>✅ Veritabanı Bağlantısı Başarılı!</p>";

    // Unique tables list from mapping
    $tables = [
        'users',
        'series',
        'blog_posts',
        'tickets',
        'shorts',
        'actors',
        'events',
        'reports',
        'comments',
        'episode_comments',
        'polls',
        'announcements',
        'logs',
        'messages',
        'friend_requests',
        'admin_chat',
        'settings',
        'faqs',
        'notifications',
        'watch_parties',
        'requests',
        'dmca_reports',
        'social_posts',
        'webtoons',
        'hero_slides',
        'shop_items',
        'premium_packages',
        'activities',
        'live_streams',
        'live_chat'
    ];

    echo "<div style='max-height: 400px; overflow-y: auto; padding: 15px; background: #f1f5f9; border-radius: 10px; font-family: monospace; font-size: 0.85rem;'>";
    
    // Temporarily disable foreign key checks if any exist
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");

    foreach ($tables as $table) {
        echo "Tablo siliniyor: $table... ";
        $pdo->exec("DROP TABLE IF EXISTS `$table` CASCADE;");
        echo "<span style='color: blue;'>SİLİNDİ</span>. Oluşturuluyor... ";
        
        $sql = "CREATE TABLE `$table` (
            `id_val` VARCHAR(255) NOT NULL PRIMARY KEY,
            `data` LONGTEXT NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        
        $pdo->exec($sql);
        echo "<span style='color: green;'>BAŞARIYLA OLUŞTURULDU</span>.<br>";
    }
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
    echo "</div>";

    echo "<div style='margin-top: 30px; padding: 20px; background: #f0fdf4; border-radius: 12px; border: 1px solid #16a34a;'>";
    echo "<h3 style='color: #166534; margin-top: 0;'>🎉 Tablolar Başarıyla Temizlendi ve Hazırlandı!</h3>";
    echo "<p>Şimdi yapmanız gereken adımlar:</p>";
    echo "<ol>";
    echo "<li>Verilerinizi tekrar MySQL'e aktarmak için <b><a href='migrate_to_mysql.php' target='_blank'>migrate_to_mysql.php</a></b> sayfasını tarayıcıda çalıştırın.</li>";
    echo "<li>Giriş şifrenizi güncellemek veya admin hesabı oluşturmak için <b><a href='create_admin.php' target='_blank'>create_admin.php</a></b> sayfasını çalıştırın.</li>";
    echo "<li>Ardından sitenize gidip <b>admin</b> kullanıcısı ve <b>Zumran1514!</b> şifresiyle giriş yapın.</li>";
    echo "</ol>";
    echo "</div>";

} catch (PDOException $e) {
    echo "<div style='background: #fef2f2; padding: 20px; border: 1px solid #ef4444; border-radius: 12px; color: #b91c1c; margin-top: 20px;'>";
    echo "<h3>❌ Hata Oluştu!</h3>";
    echo "<b>Hata Mesajı:</b> " . htmlspecialchars($e->getMessage()) . "<br>";
    echo "<b>Hata Kodu:</b> " . $e->getCode() . "<br><br>";
    echo "Lütfen <b>config.php</b> dosyasındaki veritabanı şifresini ve cPanel veritabanı izinlerini kontrol edin.";
    echo "</div>";
}

echo "</div></body></html>";
?>
