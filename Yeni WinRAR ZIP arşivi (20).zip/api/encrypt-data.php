<?php
/**
 * Data Encryption Script for DramicBox
 * This script encrypts all JSON data files in the Database/ directory
 * Run this script once to encrypt existing data
 * 
 * Usage: php encrypt-data.php
 */

require_once __DIR__ . '/core/Cryptography.php';

class DataEncryptor {
    private $baseDir;
    private $encryptedCount = 0;
    private $skippedCount = 0;
    private $errorCount = 0;
    private $logFile;
    
    // Fields to encrypt (sensitive data)
    private $sensitiveFields = [
        'password', 'email', 'phone', 'ip_address', 'payment_info',
        'token', 'secret', 'apiKey', 'privateKey'
    ];
    
    public function __construct() {
        $this->baseDir = __DIR__ . '/../Database/';
        $this->logFile = __DIR__ . '/../Database/encryption_log.json';
    }
    
    public function run($silent = false) {
        if (!$silent) {
            echo "🔐 DramicBox Data Encryption Started\n";
            echo "====================================\n\n";
        }
        
        $startTime = microtime(true);
        
        // Process each subdirectory
        $dirs = glob($this->baseDir . '*', GLOB_ONLYDIR);
        
        foreach ($dirs as $dir) {
            $this->processDirectory($dir, true, $silent);
        }
        
        // Also process root-level JSON files
        $this->processDirectory($this->baseDir, false, $silent);
        
        $endTime = microtime(true);
        $duration = round($endTime - $startTime, 2);
        
        // Summary
        if (!$silent) {
            echo "\n====================================\n";
            echo "✅ Encryption Complete!\n";
            echo "📊 Summary:\n";
            echo "   - Encrypted: {$this->encryptedCount} files\n";
            echo "   - Skipped (already encrypted): {$this->skippedCount} files\n";
            echo "   - Errors: {$this->errorCount} files\n";
            echo "   - Duration: {$duration}s\n";
        }
        
        // Save log
        $this->saveLog($duration);
        
        return [
            'encrypted' => $this->encryptedCount,
            'skipped' => $this->skippedCount,
            'errors' => $this->errorCount,
            'duration' => $duration
        ];
    }
    
    private function processDirectory($dir, $recursive = true, $silent = false) {
        $dirName = basename($dir);
        if (!$silent) echo "📁 Processing: {$dirName}\n";
        
        // Get all JSON files
        $pattern = $recursive ? $dir . '/**/*.json' : $dir . '/*.json';
        $files = glob($pattern, GLOB_BRACE);
        
        // Also get direct children
        $directFiles = glob($dir . '/*.json');
        $files = array_unique(array_merge($files, $directFiles));
        
        foreach ($files as $file) {
            $this->processFile($file, $silent);
        }
    }
    
    private function processFile($filePath, $silent = false) {
        $fileName = basename($filePath);
        
        // Skip log file
        if ($fileName === 'encryption_log.json') return;
        
        try {
            $content = file_get_contents($filePath);
            if (!$content) return;
            
            $data = json_decode($content, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                if (!$silent) echo "   ⚠️  Invalid JSON: {$fileName}\n";
                $this->errorCount++;
                return;
            }
            
            // Check if already encrypted (has signature)
            $contentStr = json_encode($data);
            if (strpos($contentStr, 'DRMC') !== false) {
                echo "   ⏭️  Already encrypted: {$fileName}\n";
                $this->skippedCount++;
                return;
            }
            
            // Encrypt sensitive fields
            $encryptedData = $this->encryptSensitiveData($data);
            
            // If data was modified, save
            if ($encryptedData !== $data) {
                $jsonContent = json_encode($encryptedData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
                file_put_contents($filePath, $jsonContent);
                echo "   🔒 Encrypted: {$fileName}\n";
                $this->encryptedCount++;
            } else {
                echo "   ⏭️  No sensitive data: {$fileName}\n";
                $this->skippedCount++;
            }
            
        } catch (Exception $e) {
            echo "   ❌ Error: {$fileName} - {$e->getMessage()}\n";
            $this->errorCount++;
        }
    }
    
    private function encryptSensitiveData($data) {
        if (!is_array($data)) return $data;
        
        // Handle array of items (like users array)
        if (isset($data[0]) && is_array($data[0])) {
            foreach ($data as &$item) {
                $item = $this->encryptSensitiveData($item);
            }
            return $data;
        }
        
        // Handle single object
        foreach ($data as $key => &$value) {
            if (is_array($value)) {
                $value = $this->encryptSensitiveData($value);
            } elseif (is_string($value) && in_array($key, $this->sensitiveFields)) {
                // Don't encrypt if already encrypted
                if (substr($value, 0, 4) !== 'DRMC') {
                    $encrypted = Cryptography::encrypt($value);
                    if ($encrypted) {
                        $value = $encrypted;
                    }
                }
            }
        }
        
        return $data;
    }
    
    private function saveLog($duration) {
        $log = [
            'lastRun' => date('c'),
            'encrypted' => $this->encryptedCount,
            'skipped' => $this->skippedCount,
            'errors' => $this->errorCount,
            'duration' => $duration
        ];
        
        file_put_contents($this->logFile, json_encode($log, JSON_PRETTY_PRINT));
    }
}

// Run if called directly
if (php_sapi_name() === 'cli' || (isset($_GET['run']) && $_GET['run'] === 'encrypt')) {
    $encryptor = new DataEncryptor();
    $result = $encryptor->run();
    
    // If called via web, output JSON
    if (php_sapi_name() !== 'cli') {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'result' => $result]);
    }
}
