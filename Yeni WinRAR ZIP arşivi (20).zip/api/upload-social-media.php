<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/core/UploadHandler.php';

// Basic security check
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid method']);
    exit;
}

$handler = new UploadHandler('social');
$result = $handler->handle('media');

echo json_encode($result);
