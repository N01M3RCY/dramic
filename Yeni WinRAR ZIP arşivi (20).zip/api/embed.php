<?php
// Pseudo-Embed Service
// This script takes a video source URL and plays it using Plyr.
// It allows local videos to be loaded in an iframe, simulating an external embed.

$source = $_GET['source'] ?? '';
$poster = $_GET['poster'] ?? '';

if (empty($source)) {
    die("No source provided.");
}

// Security: Basic check to prevent playing unauthorized files (optional)
// For now, allow any so it's flexible
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Player</title>
    <link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css" />
    <style>
        body, html { margin: 0; padding: 0; width: 100%; height: 100%; background: #000; overflow: hidden; }
        .plyr { height: 100vh; width: 100vw; }
        :root { --plyr-color-main: #7c3aed; }
    </style>
</head>
<body>
    <video controls crossorigin playsinline <?php echo $poster ? 'poster="'.$poster.'"' : ''; ?>>
        <source src="<?php echo htmlspecialchars($source); ?>" type="video/mp4" />
    </video>

    <script src="https://cdn.plyr.io/3.7.8/plyr.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const player = new Plyr('video', {
                controls: [
                    'play-large', 'play', 'progress', 'current-time', 'duration', 'mute', 'volume', 'captions', 'settings', 'pip', 'airplay', 'fullscreen'
                ],
                settings: ['captions', 'quality', 'speed', 'loop']
            });
            window.player = player;
        });
    </script>
</body>
</html>
