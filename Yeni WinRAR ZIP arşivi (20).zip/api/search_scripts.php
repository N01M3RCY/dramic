<?php
// Temporary script cleaned up
http_response_code(404);
exit;
?>
