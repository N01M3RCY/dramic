<?php
require_once 'config.php';

// Display errors for this test file
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    echo "<h1>DramicBox Veritabanı Testi</h1>";
    echo "<p>Bağlanılıyor: " . DB_HOST . " ...</p>";
    
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_TIMEOUT            => 5, // 5 second timeout
    ];
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    
    echo "<h2 style='color: green;'>✅ BAĞLANTI BAŞARILI!</h2>";
    echo "<p>Şu an sunucu veritabanına sorunsuz bağlanabiliyor.</p>";
    
    // Check if tables exist
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "<h3>Mevcut Tablolar:</h3><ul>";
    if (empty($tables)) {
        echo "<li>⚠️ Henüz hiç tablo oluşturulmamış! (Otomatik oluşturma bekleniyor)</li>";
    } else {
        foreach ($tables as $table) {
            echo "<li>$table</li>";
        }
    }
    echo "</ul>";
    
    echo "<hr><p style='color: blue;'>NOT: Eğer bu sayfayı görüyorsan ama paylaşımların hala başkasına gitmiyorsa, sorun <b>InfinityFree Güvenlik Sistemi (AES Cookie)</b> kaynaklıdır. Bu durumda VPS'e geçmek tek kesin çözümdür.</p>";

} catch (PDOException $e) {
    echo "<h2 style='color: red;'>❌ BAĞLANTI HATASI!</h2>";
    echo "<div style='background: #fee; padding: 20px; border: 1px solid red; border-radius: 8px;'>";
    echo "<b>Hata Mesajı:</b> " . $e->getMessage() . "<br>";
    echo "<b>Hata Kodu:</b> " . $e->getCode();
    echo "</div>";
    
    echo "<h3>Olası Sebepler:</h3>";
    echo "<ul>
        <li>Şifre hatalı olabilir (Lütfen InfinityFree panelinden kontrol et).</li>
        <li>Veritabanı adı veya kullanıcı adı yanlış olabilir.</li>
        <li>MySQL sunucusu (sql113.infinityfree.com) şu an çevrimdışı olabilir.</li>
    </ul>";
}
?>
