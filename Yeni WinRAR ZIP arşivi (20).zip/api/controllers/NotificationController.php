<?php

require_once __DIR__ . '/../core/BaseController.php';
require_once __DIR__ . '/../core/Database.php';

class NotificationController extends BaseController {

    public function __construct() {
        parent::__construct();
        // $this->db is already initialized in BaseController
    }

    private function getNotifications() {
        return $this->db->getCollection('notifications');
    }

    private function saveNotifications($notifications) {
        return $this->db->saveCollection('notifications', $notifications);
    }

    // LIST: Get notifications for current user
    public function list() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $userId = $_SESSION['user_id'] ?? null;
        
        if (!$userId) {
            $this->success(['notifications' => [], 'unreadCount' => 0]);
            return;
        }

        $all = $this->getNotifications();
        $userNotes = [];
        $unreadCount = 0;

        foreach ($all as $n) {
            // Include private notes OR broadcast notes
            if ($n['userId'] === $userId || $n['userId'] === 'broadcast') {
                $userNotes[] = $n;
                if (!$n['read']) $unreadCount++;
            }
        }

        // Sort by time desc
        usort($userNotes, function($a, $b) {
            return ($b['time'] ?? 0) - ($a['time'] ?? 0);
        });

        $this->success(['notifications' => array_slice($userNotes, 0, 20), 'unreadCount' => $unreadCount]);
    }

    // MARK READ
    public function markRead() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) $this->error('Login required');

        $input = json_decode(file_get_contents('php://input'), true);
        $noteId = $input['id'] ?? null;

        $all = $this->getNotifications();
        
        foreach ($all as $n) {
            if ($n['userId'] === $userId || $n['userId'] === 'broadcast') {
                if ($noteId === 'all' || $n['id'] === $noteId) {
                    if (!$n['read']) {
                        $n['read'] = true;
                        $this->db->saveItem('notifications', $n);
                    }
                }
            }
        }
        $this->success(['status' => 'ok']);
    }

    // CREATE (Internal Helper or Admin Endpoint)
    public function create() {
        $input = json_decode(file_get_contents('php://input'), true);
        $targetUserId = $input['userId'] ?? null;
        $message = $input['message'] ?? '';
        $type = $input['type'] ?? 'info'; // info, success, warning
        $link = $input['link'] ?? null;

        if (!$targetUserId || !$message) $this->error('Invalid data');

        $note = [
            'id' => uniqid('not_'),
            'userId' => ($targetUserId === 'all') ? 'broadcast' : $targetUserId,
            'type' => $type,
            'message' => $message,
            'link' => $link,
            'read' => false,
            'time' => floor(microtime(true) * 1000)
        ];

        $this->db->addToCollection('notifications', $note);
        
        // Trigger Push if user has subscription (Logic placeholder)
        $this->triggerPush($targetUserId, $note);
        
        $this->success(['notification' => $note]);
    }

    // SAVE PUSH SUBSCRIPTION
    public function saveSubscription() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) $this->error('Login required');

        $input = json_decode(file_get_contents('php://input'), true);
        $subscription = $input['subscription'] ?? null;

        if (!$subscription) $this->error('Invalid subscription');

        // Store subscription in user stats or separate collection
        $users = $this->db->getCollection('users');
        foreach ($users as &$u) {
            if ($u['id'] === $userId) {
                if (!isset($u['stats'])) $u['stats'] = [];
                $u['stats']['pushSubscription'] = $subscription;
                break;
            }
        }
        $this->db->saveCollection('users', $users);
        $this->success(['status' => 'ok']);
    }

    private function triggerPush($userId, $note) {
        // In a real production environment, this would call FCM or a Web Push library (like minishlink/web-push)
        // For this architecture, we add it to a 'pending_pushes' collection that a worker could process
        // or just log it for now as a "simulated" real-time effect.
        $push = [
            'userId' => $userId,
            'title' => 'DramicBox',
            'body' => $note['message'],
            'url' => $note['link'] ?? '/',
            'time' => time()
        ];
        $this->db->addToCollection('pending_pushes', $push);
    }
}
