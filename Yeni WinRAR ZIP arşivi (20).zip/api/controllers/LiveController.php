<?php
require_once __DIR__ . '/../core/BaseController.php';

class LiveController extends BaseController {
    
    public function handle($action) {
        switch ($action) {
            case 'start-stream': $this->startStream(); break;
            case 'update-stream': $this->updateStream(); break;
            case 'stop-stream': $this->stopStream(); break;
            case 'get-active-streams': $this->getActiveStreams(); break;
            case 'chat-send': $this->sendChatMessage(); break;
            case 'chat-get': $this->getChatMessages(); break;
            case 'chat-delete': $this->deleteChatMessage(); break;
            case 'send-coin': $this->sendCoin(); break;
            case 'poll-create': $this->createPoll(); break;
            case 'poll-vote': $this->votePoll(); break;
            default: $this->json(['success' => false, 'message' => 'Invalid live action']);
        }
    }

    private function startStream() {
        $userId = $this->getUserId();
        if (!$userId) return $this->json(['success' => false, 'message' => 'Auth required']);
        
        $user = $this->db->getItemById('users', $userId);
        $badges = $user['badges'] ?? [];
        $canStream = !empty($user['can_stream'])
            || ($user['role'] ?? '') === 'admin'
            || ($user['role'] ?? '') === 'moderator'
            || ($user['role'] ?? '') === 'translator'
            || in_array('Çevirmen', $badges, true);
        if (!$user || !$canStream) {
            return $this->json(['success' => false, 'message' => 'Yayın açma yetkiniz bulunmuyor.']);
        }

        $input = $this->getInput();
        $streamId = 'live_' . $userId;
        
        $streamData = [
            'id' => $streamId,
            'broadcasterId' => $userId,
            'broadcasterName' => $user['username'],
            'title' => $input['title'] ?? 'Canlı Yayın',
            'tags' => $input['tags'] ?? [],
            'status' => 'live',
            'startedAt' => date('Y-m-d H:i:s'),
            'viewerCount' => 0,
            'moderators' => $input['moderators'] ?? [],
            'config' => $input['config'] ?? []
        ];

        $this->db->saveItem('liveStreams', $streamData);
        $this->json(['success' => true, 'stream' => $streamData]);
    }

    private function updateStream() {
        $input = $this->getInput();
        $streamId = $input['streamId'] ?? null;
        if (!$streamId) return $this->json(['success' => false]);

        $stream = $this->db->getItemById('liveStreams', $streamId);
        if ($stream) {
            if (isset($input['viewerCount'])) $stream['viewerCount'] = $input['viewerCount'];
            if (isset($input['status'])) $stream['status'] = $input['status'];
            if (isset($input['thumbnail'])) $stream['thumbnail'] = $input['thumbnail'];
            
            // Gain XP (10 XP per update/heartbeat)
            $broadcaster = $this->db->getItemById('users', $stream['broadcasterId']);
            if ($broadcaster) {
                if (!isset($broadcaster['stats'])) {
                    $broadcaster['stats'] = ['xp' => 0, 'level' => 1, 'coins' => 0];
                }
                if (!isset($broadcaster['stats']['xp'])) $broadcaster['stats']['xp'] = 0;
                
                $broadcaster['stats']['xp'] += 10;
                
                // Level Up check (very simple)
                $oldLevel = $broadcaster['stats']['level'] ?? 1;
                $newLevel = floor($broadcaster['stats']['xp'] / 1000) + 1;
                if ($newLevel > $oldLevel) {
                    $broadcaster['stats']['level'] = $newLevel;
                }
                $this->db->saveItem('users', $broadcaster);
            }

            $stream['updated_at'] = date('Y-m-d H:i:s');
            $this->db->saveItem('liveStreams', $stream);
        }
        $this->json(['success' => true]);
    }

    private function stopStream() {
        $userId = $this->getUserId();
        $input = $this->getInput();
        $streamId = $input['streamId'] ?? 'live_' . $userId;

        $stream = $this->db->getItemById('liveStreams', $streamId);
        if ($stream && $stream['broadcasterId'] == $userId) {
            $stream['status'] = 'ended';
            $stream['endedAt'] = date('Y-m-d H:i:s');
            $this->db->saveItem('liveStreams', $stream);
            $this->json(['success' => true]);
        } else {
            $this->json(['success' => false, 'message' => 'Unauthorized']);
        }
    }

    private function getActiveStreams() {
        $streams = $this->db->getCollection('liveStreams');
        $active = [];
        
        foreach ($streams as $s) {
            if ($s['status'] === 'live' && (strtotime($s['updated_at'] ?? $s['startedAt']) > time() - 60)) {
                $user = $this->db->getItemById('users', $s['broadcasterId']);
                $s['broadcasterLevel'] = $user['stats']['level'] ?? 1;
                $active[] = $s;
            }
        }
        
        $this->json(['success' => true, 'streams' => $active]);
    }

    private function sendChatMessage() {
        $userId = $this->getUserId();
        if (!$userId) return $this->json(['success' => false]);

        $input = $this->getInput();
        $streamId = $input['streamId'] ?? null;
        $messageText = $input['message'] ?? '';
        if (!$streamId || !$messageText) return $this->json(['success' => false]);

        $user = $this->db->getItemById('users', $userId);
        
        $chatMsg = [
            'id' => uniqid('msg_'),
            'streamId' => $streamId,
            'userId' => $userId,
            'username' => $user['username'],
            'role' => $user['role'],
            'message' => $messageText,
            'createdAt' => date('Y-m-d H:i:s'),
            'type' => 'text'
        ];

        $this->db->saveItem('liveChat', $chatMsg);
        $this->json(['success' => true, 'message' => $chatMsg]);
    }

    private function getChatMessages() {
        $streamId = $_GET['streamId'] ?? null;
        if (!$streamId) return $this->json(['success' => false]);

        $allMsgs = $this->db->getCollection('liveChat');
        $msgs = array_values(array_filter($allMsgs, function($m) use ($streamId) {
            return $m['streamId'] === $streamId;
        }));
        
        // Return last 50
        $msgs = array_slice($msgs, -50);
        $this->json(['success' => true, 'messages' => $msgs]);
    }

    private function deleteChatMessage() {
        $userId = $this->getUserId();
        $input = $this->getInput();
        $msgId = $input['msgId'] ?? null;
        if (!$userId || !$msgId) return $this->json(['success' => false]);

        $msg = $this->db->getItemById('liveChat', $msgId);
        if (!$msg) return $this->json(['success' => false]);

        $stream = $this->db->getItemById('liveStreams', $msg['streamId']);
        $isAdmin = in_array($userId, $stream['moderators'] ?? []) || $stream['broadcasterId'] == $userId;
        
        if ($isAdmin) {
            $this->db->deleteFromCollection('liveChat', $msgId);
            $this->json(['success' => true]);
        } else {
            $this->json(['success' => false, 'message' => 'No permission']);
        }
    }

    private function sendCoin() {
        $userId = $this->getUserId();
        $input = $this->getInput();
        $streamId = $input['streamId'] ?? null;
        $amount = intval($input['amount'] ?? 0);
        
        if (!$userId || !$streamId || $amount <= 0) return $this->json(['success' => false]);

        $sender = $this->db->getItemById('users', $userId);
        if (($sender['stats']['coins'] ?? 0) < $amount) {
            return $this->json(['success' => false, 'message' => 'Yetersiz bakiye']);
        }

        $stream = $this->db->getItemById('liveStreams', $streamId);
        $receiverId = $stream['broadcasterId'];
        $receiver = $this->db->getItemById('users', $receiverId);

        // Update sender
        $sender['stats']['coins'] -= $amount;
        $this->db->saveItem('users', $sender);

        // Update receiver
        if (!isset($receiver['stats']['coins'])) $receiver['stats']['coins'] = 0;
        $receiver['stats']['coins'] += $amount;
        $this->db->saveItem('users', $receiver);

        // Add special chat message for donation
        $donationMsg = [
            'id' => uniqid('msg_'),
            'streamId' => $streamId,
            'userId' => $userId,
            'username' => $sender['username'],
            'message' => "HEDİYE GÖNDERDİ! 🎉",
            'amount' => $amount,
            'createdAt' => date('Y-m-d H:i:s'),
            'type' => 'donation'
        ];
        $this->db->saveItem('liveChat', $donationMsg);

        $this->json(['success' => true, 'newBalance' => $sender['stats']['coins']]);
    }

    private function createPoll() {
        $userId = $this->getUserId();
        $input = $this->getInput();
        $streamId = $input['streamId'] ?? null;
        if (!$userId || !$streamId) return $this->json(['success' => false]);

        $poll = [
            'id' => uniqid('poll_'),
            'question' => $input['question'],
            'options' => array_map(function($opt) { return ['text' => $opt, 'votes' => 0]; }, $input['options']),
            'totalVotes' => 0,
            'expiresAt' => time() + (intval($input['duration'] ?? 300)),
            'voters' => []
        ];

        $stream = $this->db->getItemById('liveStreams', $streamId);
        if ($stream && $stream['broadcasterId'] == $userId) {
            $stream['activePoll'] = $poll;
            $this->db->saveItem('liveStreams', $stream);
            $this->json(['success' => true, 'poll' => $poll]);
        } else {
            $this->json(['success' => false, 'message' => 'Unauthorized']);
        }
    }

    private function votePoll() {
        $userId = $this->getUserId();
        $input = $this->getInput();
        $streamId = $input['streamId'] ?? null;
        $optionIdx = intval($input['optionIndex'] ?? -1);

        if (!$userId || !$streamId || $optionIdx < 0) return $this->json(['success' => false]);

        $stream = $this->db->getItemById('liveStreams', $streamId);
        if ($stream && isset($stream['activePoll'])) {
            $poll = &$stream['activePoll'];
            if (in_array($userId, $poll['voters'])) {
                return $this->json(['success' => false, 'message' => 'Already voted']);
            }
            if ($poll['expiresAt'] < time()) {
                return $this->json(['success' => false, 'message' => 'Poll expired']);
            }

            $poll['options'][$optionIdx]['votes']++;
            $poll['totalVotes']++;
            $poll['voters'][] = $userId;

            $this->db->saveItem('liveStreams', $stream);
            $this->json(['success' => true, 'poll' => $poll]);
        } else {
            $this->json(['success' => false, 'message' => 'No active poll']);
        }
    }
}
