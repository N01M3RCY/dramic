<?php
/**
 * DRAMICBOX - ADVANCED GAMIFICATION CONTROLLER
 * Handles chests opening, collectible cards, trading, level system, and calendar CRUD.
 */

require_once __DIR__ . '/../core/BaseController.php';

class GamificationController extends BaseController {

    /**
     * GET: api/gamification-config
     */
    public function getGamificationConfig() {
        $path = __DIR__ . '/../../Database/gamification_config.json';
        if (file_exists($path)) {
            header('Content-Type: application/json; charset=utf-8');
            echo file_get_contents($path);
            exit;
        }
        $this->error('Yapılandırma dosyası bulunamadı.');
    }

    /**
     * POST: api/claim-tier-reward
     */
    public function claimTierReward() {
        $userId = $this->getUserId();
        if (!$userId) $this->error('Giriş yapmalısınız.');

        $input = json_decode(file_get_contents('php://input'), true);
        $level = intval($input['level'] ?? 0);
        $track = $input['track'] ?? 'free'; // 'free' or 'vip'

        if ($level <= 0 || !in_array($track, ['free', 'vip'])) {
            $this->error('Geçersiz parametreler.');
        }

        $user = $this->db->getItemById('users', $userId);
        if (!$user) $this->error('Kullanıcı bulunamadı.');

        // Enforce gamification state initialization
        $user = $this->initializeUserGamification($user);

        // Check level eligibility
        $userLevel = intval($user['stats']['level'] ?? 1);
        if ($userLevel < $level) {
            $this->error("Bu seviye kilitli! Seviyeniz: $userLevel, Gerekli: $level");
        }

        // Check if already claimed
        if (!isset($user['gamification']['claimedTiers'][$track])) {
            $user['gamification']['claimedTiers'][$track] = [];
        }
        if (in_array($level, $user['gamification']['claimedTiers'][$track])) {
            $this->error('Bu ödülü zaten aldınız!');
        }

        // Check VIP track permissions
        if ($track === 'vip') {
            $hasVip = ($user['role'] ?? '') === 'admin' || 
                      ($user['role'] ?? '') === 'moderator' || 
                      ($user['role'] ?? '') === 'vip' || 
                      ($user['isVip'] ?? false) === true || 
                      in_array('VIP', $user['badges'] ?? []);
            if (!$hasVip) {
                $this->error('VIP ödüllerini almak için VIP üye olmalısınız!');
            }
        }

        // Load config
        $config = $this->loadConfig();
        if (!$config) $this->error('Gamification yapılandırması yüklenemedi.');

        $tierReward = $config['passTiers'][$level] ?? null;
        if (!$tierReward) $this->error('Bu seviye için ödül tanımı bulunamadı.');

        $reward = $track === 'free' ? ($tierReward['free'] ?? null) : ($tierReward['vip'] ?? null);
        if (!$reward) $this->error('Ödül tanımı boş.');

        // Apply reward
        $type = $reward['type'] ?? '';
        $value = $reward['value'] ?? '';

        if ($type === 'coins') {
            $user['stats']['coins'] = intval($user['stats']['coins'] ?? 0) + intval($value);
        } else if ($type === 'chest') {
            $user['gamification']['chests'][$value] = intval($user['gamification']['chests'][$value] ?? 0) + 1;
        } else if ($type === 'frame') {
            if (!isset($user['inventory'])) $user['inventory'] = [];
            if (!in_array($value, $user['inventory'])) {
                $user['inventory'][] = $value;
            }
        } else if ($type === 'vip_days') {
            if (!isset($user['badges'])) $user['badges'] = [];
            if (!in_array('VIP', $user['badges'])) {
                $user['badges'][] = 'VIP';
            }
            $user['isVip'] = true;
        }

        // Add to claimed list
        $user['gamification']['claimedTiers'][$track][] = $level;

        // Save
        if ($this->db->saveItem('users', $user)) {
            $this->success(['message' => 'Ödül başarıyla alındı!', 'user' => $this->sanitizeUser($user)]);
        } else {
            $this->error('Veritabanı kayıt hatası.');
        }
    }

    /**
     * POST: api/open-chest
     */
    public function openChest() {
        $userId = $this->getUserId();
        if (!$userId) $this->error('Giriş yapmalısınız.');

        $input = json_decode(file_get_contents('php://input'), true);
        $chestType = $input['chestType'] ?? ''; // bronz, gumus, altin, efsanevi
        $isFree = filter_var($input['isFree'] ?? false, FILTER_VALIDATE_BOOLEAN);

        if (!in_array($chestType, ['bronz', 'gumus', 'altin', 'efsanevi'])) {
            $this->error('Geçersiz sandık türü.');
        }

        $user = $this->db->getItemById('users', $userId);
        if (!$user) $this->error('Kullanıcı bulunamadı.');

        $user = $this->initializeUserGamification($user);
        $gamif = &$user['gamification'];

        $config = $this->loadConfig();
        if (!$config) $this->error('Yapılandırma yüklenemedi.');

        $isVip = ($user['role'] ?? '') === 'admin' || 
                 ($user['role'] ?? '') === 'moderator' || 
                 ($user['role'] ?? '') === 'vip' || 
                 ($user['isVip'] ?? false) === true || 
                 in_array('VIP', $user['badges'] ?? []);

        if ($isFree) {
            // Check 12-hour Cooldown
            $cooldown = 12 * 60 * 60; // 12 hours in seconds
            $lastTime = intval($gamif['lastFreeChestTime'] ?? 0) / 1000; // js timestamp fallback to seconds
            if (time() - $lastTime < $cooldown) {
                $rem = $cooldown - (time() - $lastTime);
                $this->error("Ücretsiz sandık bekleme süresinde! Kalan: " . ceil($rem / 60) . " dakika.");
            }

            // Enforce free chest types: Normal gets Bronze, VIP gets Silver
            $expectedChest = $isVip ? 'gumus' : 'bronz';
            if ($chestType !== $expectedChest) {
                $chestType = $expectedChest;
            }

            // Set new cooldown timestamp
            $gamif['lastFreeChestTime'] = time() * 1000;
        } else {
            // Use owned chest
            $ownedCount = intval($gamif['chests'][$chestType] ?? 0);
            if ($ownedCount <= 0) {
                $this->error('Kutunuz bulunmuyor, dükkandan satın alabilirsiniz.');
            }
            $gamif['chests'][$chestType] = $ownedCount - 1;
        }

        $chestDef = $config['chests'][$chestType] ?? null;
        if (!$chestDef) $this->error('Kutu tanımı bulunamadı.');

        // Roll XP & Coins
        $xpRoll = rand(intval($chestDef['xpMin']), intval($chestDef['xpMax']));
        $coinsRoll = rand(intval($chestDef['coinsMin']), intval($chestDef['coinsMax']));

        // Roll Card
        $cardDropped = null;
        $chance = floatval($chestDef['cardDropChance']);
        if ((rand(0, 100) / 100) <= $chance) {
            $cardDropped = $this->rollCardDrop($chestDef['rarityWeight'], $config['cards']);
            if ($cardDropped) {
                if (!isset($gamif['cards'])) $gamif['cards'] = [];
                $gamif['cards'][] = $cardDropped['id'];
            }
        }

        // Apply XP and Coins
        $oldXP = intval($user['stats']['xp'] ?? 0);
        $newXP = $oldXP + $xpRoll;
        $user['stats']['xp'] = $newXP;
        $user['stats']['coins'] = intval($user['stats']['coins'] ?? 0) + $coinsRoll;

        // Level Up Check
        $oldLvl = floor(sqrt($oldXP / 100)) + 1;
        $newLvl = floor(sqrt($newXP / 100)) + 1;
        $user['stats']['level'] = $newLvl;

        $leveledUp = false;
        $lvlReward = 0;
        if ($newLvl > $oldLvl) {
            $leveledUp = true;
            $lvlReward = 100 + ($newLvl * 20);
            $user['stats']['coins'] += $lvlReward;
        }

        // Save User
        if ($this->db->saveItem('users', $user)) {
            $this->success([
                'chestName' => $chestDef['name'],
                'xp' => $xpRoll,
                'coins' => $coinsRoll,
                'card' => $cardDropped,
                'leveledUp' => $leveledUp,
                'levelUpReward' => $lvlReward,
                'user' => $this->sanitizeUser($user)
            ]);
        } else {
            $this->error('Kutu ödülleri kaydedilemedi.');
        }
    }

    /**
     * POST: api/sell-item
     */
    public function sellItem() {
        $userId = $this->getUserId();
        if (!$userId) $this->error('Giriş yapmalısınız.');

        $input = json_decode(file_get_contents('php://input'), true);
        $type = $input['type'] ?? ''; // card or chest
        $itemId = $input['itemId'] ?? '';

        if (!in_array($type, ['card', 'chest']) || empty($itemId)) {
            $this->error('Geçersiz parametreler.');
        }

        $user = $this->db->getItemById('users', $userId);
        if (!$user) $this->error('Kullanıcı bulunamadı.');

        $user = $this->initializeUserGamification($user);
        $config = $this->loadConfig();
        if (!$config) $this->error('Yapılandırma yüklenemedi.');

        $value = 0;

        if ($type === 'chest') {
            $ownedCount = intval($user['gamification']['chests'][$itemId] ?? 0);
            if ($ownedCount <= 0) $this->error('Satacak sandığınız yok.');
            
            $chestDef = $config['chests'][$itemId] ?? null;
            if (!$chestDef) $this->error('Sandık tanımı bulunamadı.');

            $value = round(intval($chestDef['price']) * 0.5);
            $user['gamification']['chests'][$itemId] = $ownedCount - 1;

        } else if ($type === 'card') {
            $cards = $user['gamification']['cards'] ?? [];
            $idx = array_search($itemId, $cards);
            if ($idx === false) $this->error('Satacak oyuncu kartınız envanterinizde bulunamadı.');

            $cardDef = null;
            foreach ($config['cards'] as $c) {
                if ($c['id'] === $itemId) {
                    $cardDef = $c;
                    break;
                }
            }
            if (!$cardDef) $this->error('Oyuncu kartı tanımı bulunamadı.');

            $value = intval($cardDef['baseValue']);
            array_splice($user['gamification']['cards'], $idx, 1);
        }

        // Add coins
        $user['stats']['coins'] = intval($user['stats']['coins'] ?? 0) + $value;

        if ($this->db->saveItem('users', $user)) {
            $this->success([
                'earned' => $value,
                'user' => $this->sanitizeUser($user)
            ]);
        } else {
            $this->error('Satış işlemi kaydedilemedi.');
        }
    }

    /**
     * POST: api/execute-trade
     */
    public function executeTrade() {
        $userId = $this->getUserId();
        if (!$userId) $this->error('Giriş yapmalısınız.');

        $input = json_decode(file_get_contents('php://input'), true);
        $messageId = $input['messageId'] ?? '';

        if (empty($messageId)) $this->error('Mesaj kimliği gereklidir.');

        // Load messages
        $message = $this->db->getItemById('messages', $messageId);
        if (!$message) $this->error('Takas mesajı bulunamadı.');

        if (($message['type'] ?? '') !== 'trade') $this->error('Bu bir takas mesajı değildir.');
        if (($message['status'] ?? 'pending') !== 'pending') $this->error('Bu takas teklifi artık geçerli değil.');

        $senderId = $message['from'];
        $receiverId = $message['to'];

        // Enforce only the receiver can accept the trade
        if ($receiverId !== $userId) {
            $this->error('Bu takas teklifi size gönderilmemiş.');
        }

        // Lock & load users
        $sender = $this->db->getItemById('users', $senderId);
        $receiver = $this->db->getItemById('users', $receiverId);

        if (!$sender || !$receiver) $this->error('Takas taraflarından biri bulunamadı.');

        $sender = $this->initializeUserGamification($sender);
        $receiver = $this->initializeUserGamification($receiver);

        // Offer details
        $tradeDetails = $message['tradeDetails'] ?? [];
        $senderCards = $tradeDetails['senderCards'] ?? []; // Array of Card IDs
        $senderCoins = intval($tradeDetails['senderCoins'] ?? 0);
        $receiverCards = $tradeDetails['receiverCards'] ?? []; // Array of Card IDs

        // 1. Verify Sender Assets
        if (intval($sender['stats']['coins'] ?? 0) < $senderCoins) {
            $message['status'] = 'failed';
            $message['failReason'] = 'Yetersiz Coin bakiyesi (Gönderen)';
            $this->db->saveItem('messages', $message);
            $this->error('Gönderenin bakiyesi yetersiz, takas iptal edildi.');
        }

        $senderInventory = $sender['gamification']['cards'] ?? [];
        $tempSenderInv = $senderInventory;
        foreach ($senderCards as $cid) {
            $idx = array_search($cid, $tempSenderInv);
            if ($idx === false) {
                $message['status'] = 'failed';
                $message['failReason'] = 'Kartlar artık envanterde yok (Gönderen)';
                $this->db->saveItem('messages', $message);
                $this->error('Teklif edilen kartlar artık gönderenin envanterinde değil.');
            }
            array_splice($tempSenderInv, $idx, 1);
        }

        // 2. Verify Receiver Assets
        $receiverInventory = $receiver['gamification']['cards'] ?? [];
        $tempReceiverInv = $receiverInventory;
        foreach ($receiverCards as $cid) {
            $idx = array_search($cid, $tempReceiverInv);
            if ($idx === false) {
                $message['status'] = 'failed';
                $message['failReason'] = 'Kartlar artık envanterde yok (Alıcı)';
                $this->db->saveItem('messages', $message);
                $this->error('İstenen kartlar artık envanterinizde bulunmuyor.');
            }
            array_splice($tempReceiverInv, $idx, 1);
        }

        // 3. Perform SWAP
        // Sender: Deduct cards & coins
        $sender['gamification']['cards'] = $tempSenderInv;
        $sender['stats']['coins'] -= $senderCoins;

        // Receiver: Deduct cards, add coins
        $receiver['gamification']['cards'] = $tempReceiverInv;
        $receiver['stats']['coins'] += $senderCoins;

        // Swap cards
        foreach ($senderCards as $cid) {
            $receiver['gamification']['cards'][] = $cid;
        }
        foreach ($receiverCards as $cid) {
            $sender['gamification']['cards'][] = $cid;
        }

        // Update trade bubble message
        $message['status'] = 'accepted';
        $message['text'] = '🤝 Takas Başarıyla Tamamlandı!';

        // Save
        $this->db->saveItem('users', $sender);
        $this->db->saveItem('users', $receiver);
        $this->db->saveItem('messages', $message);

        // Add activity logs
        $this->logActivity('trade_complete', [
            'sender' => $sender['username'],
            'receiver' => $receiver['username'],
            'senderCoins' => $senderCoins,
            'senderCardsCount' => count($senderCards),
            'receiverCardsCount' => count($receiverCards)
        ]);

        $this->success([
            'message' => 'Takas başarıyla tamamlandı! Kartlar takas edildi. 🎉',
            'user' => $this->sanitizeUser($receiver)
        ]);
    }

    /**
     * POST: api/save-calendar-schedule
     */
    public function saveCalendarSchedule() {
        $this->checkAdmin(); // Enforce Admin/Moderator

        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? ('cal-' . time() . '-' . rand(10, 99));
        $seriesId = $input['seriesId'] ?? '';
        $day = $input['day'] ?? '';
        $time = $input['time'] ?? '20:00';
        $episodeNumber = isset($input['episodeNumber']) ? (empty($input['episodeNumber']) ? null : intval($input['episodeNumber'])) : null;

        if (empty($seriesId) || empty($day)) {
            $this->error('Dizi kimliği ve gün gereklidir.');
        }

        $entry = [
            'id' => $id,
            'seriesId' => $seriesId,
            'day' => $day,
            'time' => $time,
            'episodeNumber' => $episodeNumber
        ];

        if ($this->db->saveItem('calendar', $entry)) {
            $this->success(['message' => 'Yayın takvimi kaydedildi!', 'entry' => $entry]);
        } else {
            $this->error('Veritabanı kayıt hatası.');
        }
    }

    /**
     * POST: api/delete-calendar-schedule
     */
    public function deleteCalendarSchedule() {
        $this->checkAdmin();

        $id = $_GET['id'] ?? '';
        if (empty($id)) $this->error('Giriş kimliği gereklidir.');

        if ($this->db->deleteItem('calendar', $id)) {
            $this->success(['message' => 'Yayın takvimi girişi başarıyla silindi.']);
        } else {
            $this->error('Silme başarısız oldu.');
        }
    }


    // --- HELPERS ---

    private function loadConfig() {
        $path = __DIR__ . '/../../Database/gamification_config.json';
        if (file_exists($path)) {
            return json_decode(file_get_contents($path), true);
        }
        return null;
    }

    private function initializeUserGamification($user) {
        if (!isset($user['stats'])) {
            $user['stats'] = ['xp' => 0, 'level' => 1, 'coins' => 150];
        }
        if (!isset($user['gamification'])) {
            $user['gamification'] = [
                'cards' => [],
                'chests' => ['bronz' => 1, 'gumus' => 0, 'altin' => 0, 'efsanevi' => 0],
                'lastFreeChestTime' => 0,
                'claimedTiers' => ['free' => [], 'vip' => []]
            ];
        }
        if (!isset($user['gamification']['cards'])) $user['gamification']['cards'] = [];
        if (!isset($user['gamification']['chests'])) {
            $user['gamification']['chests'] = ['bronz' => 1, 'gumus' => 0, 'altin' => 0, 'efsanevi' => 0];
        }
        if (!isset($user['gamification']['claimedTiers'])) {
            $user['gamification']['claimedTiers'] = ['free' => [], 'vip' => []];
        }
        return $user;
    }

    private function rollCardDrop($weights, $cards) {
        $r = rand(0, 10000) / 10000;
        $rarity = 'common';

        $wCommon = floatval($weights['common']);
        $wRare = floatval($weights['rare']);
        $wEpic = floatval($weights['epic']);
        $wLegendary = floatval($weights['legendary']);

        if ($r < $wLegendary) {
            $rarity = 'legendary';
        } else if ($r < ($wLegendary + $wEpic)) {
            $rarity = 'epic';
        } else if ($r < ($wLegendary + $wEpic + $wRare)) {
            $rarity = 'rare';
        } else {
            $rarity = 'common';
        }

        $available = [];
        foreach ($cards as $c) {
            if ($c['rarity'] === $rarity) {
                $available[] = $c;
            }
        }

        if (empty($available)) {
            return $cards[array_rand($cards)];
        }
        return $available[array_rand($available)];
    }

    private function sanitizeUser($user) {
        unset($user['password']);
        unset($user['reset_code']);
        unset($user['reset_expiry']);
        return $user;
    }
}
