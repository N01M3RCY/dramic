<?php
// ============================================
// DRAMICBOX - SOCIAL STREAM CONTROLLER (SSE)
// Handles real-time updates for Social Hub
// ============================================

require_once __DIR__ . '/../core/BaseController.php';

class SocialStreamController extends BaseController {
    
    public function handle($action) {
        switch ($action) {
            case 'stream':
                $this->startStream();
                break;
            case 'heartbeat':
                $this->heartbeat();
                break;
            default:
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
    }

    private function startStream() {
        set_time_limit(0);
        ignore_user_abort(true);

        header('Content-Type: text/event-stream');
        header('Cache-Control: no-cache');
        header('Connection: keep-alive');
        header('X-Accel-Buffering: no'); // Disable buffering for Nginx

        $lastId = isset($_SERVER['HTTP_LAST_EVENT_ID']) ? intval($_SERVER['HTTP_LAST_EVENT_ID']) : 0;
        
        // Loop to keep connection open
        while (true) {
            if (connection_aborted()) break;

            // Check for new posts, comments, or notifications
            $updates = $this->checkForUpdates($lastId);
            
            if (!empty($updates)) {
                foreach ($updates as $update) {
                    echo "id: " . $update['id'] . "\n";
                    echo "data: " . json_encode($update['data']) . "\n\n";
                    $lastId = $update['id'];
                }
                ob_flush();
                flush();
            }

            // Send heartbeat every 30 seconds to keep connection alive
            echo "event: heartbeat\ndata: {\"time\": " . time() . "}\n\n";
            ob_flush();
            flush();

            sleep(5); // Poll every 5 seconds (simulated SSE for now)
        }
    }

    private function checkForUpdates($lastId) {
        // Reload activities to get fresh content from disk
        $activities = $this->db->loadCollections(['activities'])['activities'] ?? [];
        $updates = [];

        foreach ($activities as $activity) {
            $activityTs = intval($activity['createdAt'] ?? 0);
            
            if ($activityTs > $lastId) {
                $data = [
                    'type' => 'activity',
                    'activity' => $activity
                ];

                // Map specific activities to direct types for the frontend
                if ($activity['type'] === 'new_post') {
                    $db = new Database();
                    $post = $db->getItemById('socialPosts', $activity['data']['postId']);
                    if ($post) {
                        $data = [
                            'type' => 'new_post',
                            'post' => $post
                        ];
                    }
                }

                $updates[] = [
                    'id' => $activityTs,
                    'data' => $data
                ];
            }
        }

        // Sort updates by ID/Time
        usort($updates, function($a, $b) {
            return $a['id'] - $b['id'];
        });

        return $updates;
    }

    private function heartbeat() {
        $userId = $this->getUserId();
        if (!$userId) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Not logged in']);
            return;
        }

        // Update lastActive in DB
        $data = $this->db->getData();
        if (isset($data['users'])) {
            $found = false;
            foreach ($data['users'] as &$user) {
                if ($user['id'] == $userId) {
                    $user['lastActive'] = time() * 1000;
                    $found = true;
                    break;
                }
            }
            if ($found) {
                $this->db->saveData($data);
            }
        }

        header('Content-Type: application/json');
         echo json_encode(['success' => true]);
     }
 }
?>