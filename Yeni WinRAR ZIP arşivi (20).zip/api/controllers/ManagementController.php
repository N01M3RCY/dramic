<?php
/**
 * DRAMICBOX - ADVANCED MANAGEMENT CONTROLLER
 * Handles Tickets, Announcements, and Copyright Requests
 */

require_once __DIR__ . '/../core/BaseController.php';

class ManagementController extends BaseController {

    public function handle($action) {
        switch ($action) {
            // Ticket Systems
            case 'ticket-create': $this->createTicket(); break;
            case 'ticket-list': $this->listTickets(); break;
            case 'ticket-reply': $this->replyTicket(); break;
            case 'ticket-close': $this->closeTicket(); break;
            
            // Announcement Systems
            case 'announcement-save': $this->saveAnnouncement(); break;
            case 'announcement-delete': $this->deleteAnnouncement(); break;
            case 'list-announcements': $this->listAnnouncements(); break;
            
            // Copyright & Reports
            case 'report-copyright': $this->reportCopyright(); break;
            case 'report-list': $this->listReports(); break;
            case 'report-delete': $this->deleteReport(); break;

            // System Config
            case 'save-config': $this->saveConfig(); break;
            
            // Journal (E-Dergi)
            case 'journal-save': $this->saveJournal(); break;
            case 'journal-list': $this->listJournals(); break;
            case 'journal-delete': $this->deleteJournal(); break;
            
            default: $this->error('İşlem geçersiz.');
        }
    }

    private function saveConfig() {
        if (!$this->isAdmin()) $this->error('Yetkisiz erişim.');
        $data = json_decode(file_get_contents('php://input'), true);
        
        $host = $data['db_host'] ?? 'localhost';
        $name = $data['db_name'] ?? 'dramicbox';
        $user = $data['db_user'] ?? 'root';
        $pass = $data['db_pass'] ?? '';
        
        // Read current config to preserve other constants
        $currentConfig = file_get_contents(__DIR__ . '/../config.php');
        
        // Use regex to replace DB constants
        $patterns = [
            "/define\('DB_HOST', '.*?'\);/" => "define('DB_HOST', '$host');",
            "/define\('DB_NAME', '.*?'\);/" => "define('DB_NAME', '$name');",
            "/define\('DB_USER', '.*?'\);/" => "define('DB_USER', '$user');",
            "/define\('DB_PASS', '.*?'\);/" => "define('DB_PASS', '$pass');"
        ];
        
        $newConfig = preg_replace(array_keys($patterns), array_values($patterns), $currentConfig);
        
        if (file_put_contents(__DIR__ . '/../config.php', $newConfig)) {
            $this->success(['message' => 'Sistem konfigürasyonu güncellendi! Veritabanı bağlantısı kuruldu.']);
        } else {
            $this->error('config.php dosyasına yazılamadı. Dosya izinlerini (CHMOD) kontrol edin.');
        }
    }

    private function listAnnouncements() {
        $db = new Database();
        $anns = $db->getCollection('announcements');
        
        // Filter by active if requested
        if (isset($_GET['active'])) {
            $anns = array_filter($anns, function($a) {
                return isset($a['active']) && $a['active'] === true;
            });
        }
        
        $this->success(array_values($anns));
    }

    private function createTicket() {
        $userId = $this->getUserId();
        if (!$userId) $this->error('Giriş yapmalısınız.');

        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['subject']) || empty($data['message'])) $this->error('Konu ve mesaj boş olamaz.');

        $db = new Database();
        $ticketId = 'tkt-' . uniqid();
        $ticket = [
            'id' => $ticketId,
            'userId' => $userId,
            'username' => $_SESSION['user']['username'] ?? 'Anonim',
            'subject' => $data['subject'],
            'status' => 'open', // open, replied, closed
            'priority' => $data['priority'] ?? 'normal',
            'createdAt' => date('Y-m-d H:i:s'),
            'messages' => [
                [
                    'author' => 'user',
                    'username' => $_SESSION['user']['username'] ?? 'Anonim',
                    'text' => $data['message'],
                    'time' => date('Y-m-d H:i:s')
                ]
            ]
        ];

        $db->saveItem('tickets', $ticket);
        $this->success(['ticketId' => $ticketId, 'message' => 'Destek talebiniz başarıyla oluşturuldu.']);
    }

    private function listTickets() {
        $userId = $this->getUserId();
        if (!$userId) $this->error('Yetkisiz erişim.');

        $db = new Database();
        $tickets = $db->getCollection('tickets');

        // IF NOT ADMIN: Only show user's own tickets
        if (!$this->isAdmin()) {
            $tickets = array_filter($tickets, function($t) use ($userId) {
                return $t['userId'] === $userId;
            });
        }

        $this->success(array_values($tickets));
    }

    private function replyTicket() {
        $userId = $this->getUserId();
        $data = json_decode(file_get_contents('php://input'), true);
        $ticketId = $data['ticketId'] ?? null;

        if (!$ticketId) $this->error('Ticket ID eksik.');

        $db = new Database();
        $ticket = $db->getItem('tickets', $ticketId);
        if (!$ticket) $this->error('Ticket bulunamadı.');

        $isAdminReply = $this->isAdmin();
        
        $ticket['messages'][] = [
            'author' => $isAdminReply ? 'admin' : 'user',
            'username' => $_SESSION['user']['username'],
            'text' => $data['message'],
            'time' => date('Y-m-d H:i:s')
        ];
        
        $ticket['status'] = $isAdminReply ? 'replied' : 'open';
        $ticket['updatedAt'] = date('Y-m-d H:i:s');

        $db->saveItem('tickets', $ticket);
        $this->success(['message' => 'Cevabınız iletildi.']);
    }

    private function saveAnnouncement() {
        if (!$this->isAdmin()) $this->error('Sadece adminler duyuru yapabilir.');
        
        $data = json_decode(file_get_contents('php://input'), true);
        $db = new Database();
        
        $ann = [
            'id' => $data['id'] ?? 'ann-' . uniqid(),
            'title' => $data['title'],
            'content' => $data['content'],
            'type' => $data['type'] ?? 'info', // info, warning, success
            'active' => true,
            'createdAt' => date('Y-m-d H:i:s')
        ];

        $db->saveItem('announcements', $ann);
        $this->success(['message' => 'Duyuru kaydedildi.']);
    }

    private function deleteAnnouncement() {
        if (!$this->isAdmin()) $this->error('Yetkisiz erişim.');
        $id = $_GET['id'] ?? null;
        if (!$id) $this->error('ID eksik.');

        $db = new Database();
        $db->deleteItem('announcements', $id);
        $this->success(['message' => 'Duyuru silindi.']);
    }

    private function reportCopyright() {
        $data = json_decode(file_get_contents('php://input'), true);
        $db = new Database();
        
        $report = [
            'id' => 'cp-' . uniqid(),
            'url' => $data['url'],
            'owner' => $data['owner'],
            'email' => $data['email'],
            'reason' => $data['reason'],
            'status' => 'pending',
            'createdAt' => date('Y-m-d H:i:s')
        ];

        $db->saveItem('copyright_reports', $report);
        $this->success(['message' => 'Telif ihbarınız alındı, incelenecek.']);
    }

    private function listReports() {
        if (!$this->isAdmin()) $this->error('Yetkisiz erişim.');
        $db = new Database();
        $reports = $db->getCollection('copyright_reports');
        $this->success(array_values($reports));
    }

    private function deleteReport() {
        if (!$this->isAdmin()) $this->error('Yetkisiz erişim.');
        $id = $_GET['id'] ?? null;
        if (!$id) $this->error('ID eksik.');
        $db = new Database();
        $db->deleteItem('copyright_reports', $id);
        $this->success(['message' => 'Rapor silindi.']);
    }
    private function saveJournal() {
        if (!$this->isAdmin()) $this->error('Yetkisiz erişim.');
        $data = json_decode(file_get_contents('php://input'), true);
        $db = new Database();
        
        $journal = [
            'id' => $data['id'] ?? 'jnl-' . uniqid(),
            'title' => $data['title'],
            'coverImage' => $data['coverImage'],
            'month' => $data['month'],
            'year' => $data['year'],
            'description' => $data['description'] ?? '',
            'createdAt' => date('Y-m-d H:i:s')
        ];

        $db->saveItem('journals', $journal);
        $this->success(['message' => 'Dergi sayısı kaydedildi.']);
    }

    private function listJournals() {
        $db = new Database();
        $this->success($db->getCollection('journals'));
    }

    private function deleteJournal() {
        if (!$this->isAdmin()) $this->error('Yetkisiz erişim.');
        $id = $_GET['id'] ?? null;
        if (!$id) $this->error('ID eksik.');
        $db = new Database();
        $db->deleteItem('journals', $id);
        $this->success(['message' => 'Dergi silindi.']);
    }
}
