<?php

require_once __DIR__ . '/../core/BaseController.php';

class SearchController extends BaseController {
    
    public function search() {
        $query = $_GET['q'] ?? '';
        $query = mb_strtolower(trim($query), 'UTF-8');

        if (empty($query)) {
            $this->success([]);
            return;
        }

        $allSeries = $this->db->getCollection('series');
        $results = [];

        foreach ($allSeries as $series) {
            // Basic matching: Title, Original Title, Description
            // Can be expanded to Actors, Director, etc.
            
            $text = mb_strtolower(($series['title'] ?? '') . ' ' . ($series['originalTitle'] ?? '') . ' ' . ($series['description'] ?? ''), 'UTF-8');
            
            if (mb_strpos($text, $query, 0, 'UTF-8') !== false) {
                // Return lightweight object
                $results[] = [
                    'id' => $series['id'],
                    'title' => $series['title'],
                    'image' => $series['poster'] ?? $series['coverImage'] ?? null,
                    'year' => $series['year'] ?? '',
                    'type' => $series['type'] ?? 'drama',
                    'slug' => $series['slug'] ?? $series['id'] // Fallback
                ];
            }
        }

        // Limit results if needed (pagination could be added later)
        $this->success(['results' => array_slice($results, 0, 50)]);
    }
}
