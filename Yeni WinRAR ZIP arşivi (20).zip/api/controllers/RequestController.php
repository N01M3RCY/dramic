<?php

require_once __DIR__ . '/../core/BaseController.php';

class RequestController extends BaseController {
    public function __construct() {
        parent::__construct();
    }

    public function handle($action) {
        switch($action) {
            case 'req-list': $this->list(); break;
            case 'req-add': $this->add(); break;
            case 'req-vote': $this->vote(); break;
            case 'req-claim': $this->claim(); break;
            default: $this->error('Unknown request action');
        }
    }

    public function list() {
        $requests = $this->db->getCollection('requests');
        $this->success($requests);
    }

    public function add() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['username'])) $this->error('Giriş yapmalısınız.');

        $input = json_decode(file_get_contents('php://input'), true);
        $title = $input['title'] ?? '';
        $note = $input['note'] ?? '';

        if (empty($title)) $this->error('Dizi adı gereklidir.');

        $newRequest = [
            'id' => uniqid('req_'),
            'title' => $title,
            'note' => $note,
            'userId' => $_SESSION['username'],
            'votes' => 1,
            'voters' => [$_SESSION['username']],
            'status' => 'pending',
            'date' => date('c')
        ];

        $this->db->addToCollection('requests', $newRequest);
        $this->success($newRequest);
    }

    public function vote() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $username = $_SESSION['username'] ?? null;
        if (!$username) $this->error('Giriş yapmalısınız.');

        $id = $_GET['id'] ?? null;
        if (!$id) $this->error('Geçersiz istek.');

        $req = $this->db->getItemById('requests', $id);
        if ($req) {
            if (in_array($username, $req['voters'] ?? [])) $this->error('Zaten oy verdiniz.');
            $req['votes'] = ($req['votes'] ?? 0) + 1;
            $req['voters'][] = $username;
            $this->db->saveItem('requests', $req);
            $this->success(['votes' => $req['votes']]);
        } else {
            $this->error('İstek bulunamadı.');
        }
    }

    public function claim() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $username = $_SESSION['username'] ?? null;
        if (!$username) $this->error('Yetkisiz işlem.');

        $id = $_GET['id'] ?? null;
        if (!$id) $this->error('Geçersiz istek.');

        $req = $this->db->getItemById('requests', $id);
        if ($req) {
            $req['status'] = 'claimed';
            $req['claimedBy'] = $username;
            $this->db->saveItem('requests', $req);
            $this->success(['status' => 'claimed']);
        } else {
            $this->error('İstek bulunamadı.');
        }
    }
}
