<?php
// ============================================
// DRAMICBOX - VIDEO STUDIO CONTROLLER
// Handles video uploads to Vidmoly and project files
// ============================================

require_once __DIR__ . '/../core/BaseController.php';
require_once __DIR__ . '/../core/UploadHandler.php';

class VideoStudioController extends BaseController {

    public function handle($action) {
        $userId = $this->getUserId();
        if (!$userId) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Login required']);
            return;
        }

        switch ($action) {
            case 'vidmoly-upload':
                $this->uploadToVidmoly();
                break;
            case 'vidmoly-status':
                $this->checkVidmolyStatus();
                break;
            default:
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
    }

    private function uploadToVidmoly() {
        if (!defined('VIDMOLY_API_KEY') || VIDMOLY_API_KEY === 'YOUR_VIDMOLY_API_KEY_HERE' || empty(VIDMOLY_API_KEY)) {
            $this->error('Vidmoly API anahtarı yapılandırılmamış. Lütfen config.php dosyasını kontrol edin.');
            return;
        }

        if (!isset($_FILES['file'])) {
            $this->error('Yüklenecek dosya seçilmedi.');
        }

        // 1. Get Upload Server
        $serverUrl = "https://api.vidmoly.me/api/upload/server?key=" . VIDMOLY_API_KEY;
        $serverInfo = $this->curlGet($serverUrl);
        
        if (!$serverInfo || !isset($serverInfo['result'])) {
            $this->error('Vidmoly yükleme sunucusu alınamadı.');
        }

        $uploadUrl = $serverInfo['result'];
        $filePath = $_FILES['file']['tmp_name'];
        $fileName = $_FILES['file']['name'];

        // 2. Perform Upload via cURL (Server-side proxy)
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $uploadUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'key' => VIDMOLY_API_KEY,
            'file' => new CURLFile($filePath, $_FILES['file']['type'], $fileName)
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 3600); // 1 hour for large uploads
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            $this->error('Upload error: ' . $error);
        }

        $data = json_decode($response, true);
        
        if (isset($data[0]['file_code'])) {
            $this->success([
                'file_code' => $data[0]['file_code'],
                'url' => 'https://vidmoly.to/embed-' . $data[0]['file_code'] . '.html',
                'message' => 'Video Vidmoly\'e başarıyla yüklendi!'
            ]);
        } else {
            $this->error('Vidmoly yanıtı hatalı: ' . $response);
        }
    }

    private function checkVidmolyStatus() {
        $fileCode = $_GET['file_code'] ?? null;
        if (!$fileCode) return $this->error('Missing file code');

        $url = "https://api.vidmoly.me/api/file/info?key=" . VIDMOLY_API_KEY . "&file_code=" . $fileCode;
        $info = $this->curlGet($url);
        
        if ($info && isset($info['result'])) {
            $this->success($info['result']);
        } else {
            $this->error('Dosya bilgisi alınamadı.');
        }
    }

    private function curlGet($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }
}
