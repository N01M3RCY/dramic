<?php
/**
 * Cryptology Controller
 * Admin-only encryption/decryption interface
 */

require_once __DIR__ . '/../core/Cryptography.php';
require_once __DIR__ . '/../core/Database.php';

class CryptologyController {
    
    public function handle($action) {
        switch($action) {
            case 'crypto-token': $this->getAccessToken(); break;
            case 'crypto-verify': $this->verifyToken(); break;
            case 'crypto-decrypt': $this->decrypt(); break;
            case 'crypto-encrypt': $this->encrypt(); break;
            case 'crypto-analyze': $this->analyze(); break;
            case 'crypto-list': $this->listEncrypted(); break;
            default: header('Content-Type: application/json'); echo json_encode(['success' => false, 'error' => 'Unknown crypto action']);
        }
    }
    
    /**
     * Get access token for cryptology page
     */
    public function getAccessToken() {
        header('Content-Type: application/json');
        
        // Verify admin session
        session_start();
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
            echo json_encode(['success' => false, 'error' => 'Yetkisiz erişim']);
            return;
        }
        
        $token = Cryptography::generateAccessToken();
        echo json_encode(['success' => true, 'token' => $token]);
    }
    
    /**
     * Verify access token
     */
    public function verifyToken() {
        header('Content-Type: application/json');
        
        $token = $_GET['token'] ?? '';
        $valid = Cryptography::validateAccessToken($token);
        
        echo json_encode(['success' => $valid]);
    }
    
    /**
     * Decrypt submitted text
     */
    public function decrypt() {
        header('Content-Type: application/json');
        
        // Verify admin from session or token
        $input = json_decode(file_get_contents('php://input'), true);
        $token = $input['token'] ?? '';
        $encrypted = $input['encrypted'] ?? '';
        
        if (!Cryptography::validateAccessToken($token)) {
            echo json_encode(['success' => false, 'error' => 'Geçersiz veya süresi dolmuş token']);
            return;
        }
        
        if (empty($encrypted)) {
            echo json_encode(['success' => false, 'error' => 'Şifreli metin gerekli']);
            return;
        }
        
        $result = Cryptography::decrypt($encrypted, true);
        
        if ($result['success']) {
            // Try to parse as JSON
            $data = json_decode($result['data'], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                echo json_encode([
                    'success' => true, 
                    'type' => 'json',
                    'data' => $data,
                    'raw' => $result['data']
                ]);
            } else {
                echo json_encode([
                    'success' => true,
                    'type' => 'text',
                    'data' => $result['data']
                ]);
            }
        } else {
            echo json_encode($result);
        }
    }
    
    /**
     * Encrypt submitted text
     */
    public function encrypt() {
        header('Content-Type: application/json');
        
        $input = json_decode(file_get_contents('php://input'), true);
        $token = $input['token'] ?? '';
        $plaintext = $input['plaintext'] ?? '';
        
        if (!Cryptography::validateAccessToken($token)) {
            echo json_encode(['success' => false, 'error' => 'Geçersiz token']);
            return;
        }
        
        if (empty($plaintext)) {
            echo json_encode(['success' => false, 'error' => 'Metin gerekli']);
            return;
        }
        
        $encrypted = Cryptography::encrypt($plaintext);
        
        echo json_encode([
            'success' => true,
            'encrypted' => $encrypted,
            'analysis' => Cryptography::analyzeEncrypted($encrypted)
        ]);
    }
    
    /**
     * Analyze encrypted text without decrypting
     */
    public function analyze() {
        header('Content-Type: application/json');
        
        $input = json_decode(file_get_contents('php://input'), true);
        $encrypted = $input['encrypted'] ?? '';
        
        $analysis = Cryptography::analyzeEncrypted($encrypted);
        echo json_encode($analysis);
    }
    
    /**
     * Get all encrypted data in database for review
     */
    public function listEncrypted() {
        header('Content-Type: application/json');
        
        $input = json_decode(file_get_contents('php://input'), true);
        $token = $input['token'] ?? '';
        
        if (!Cryptography::validateAccessToken($token)) {
            echo json_encode(['success' => false, 'error' => 'Geçersiz token']);
            return;
        }
        
        $db = new Database();
        $users = $db->getCollection('users');
        
        $encryptedItems = [];
        
        // Scan users for encrypted fields
        foreach ($users as $user) {
            foreach (['password', 'email', 'phone'] as $field) {
                if (isset($user[$field]) && is_string($user[$field]) && substr($user[$field], 0, 4) === 'DRMC') {
                    $encryptedItems[] = [
                        'type' => 'user',
                        'id' => $user['id'] ?? ($user['username'] ?? 'unknown'),
                        'field' => $field,
                        'preview' => substr($user[$field], 0, 30) . '...'
                    ];
                }
            }
        }
        
        echo json_encode([
            'success' => true,
            'count' => count($encryptedItems),
            'items' => $encryptedItems
        ]);
    }
}
