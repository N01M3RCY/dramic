<?php

require_once __DIR__ . '/../core/BaseController.php';

class FAQController extends BaseController {
    
    public function handle($action) {
        switch($action) {
            case 'faq-list': $this->list(); break;
            case 'faq-add': $this->add(); break;
            case 'faq-update': $this->update(); break;
            case 'faq-delete': $this->delete(); break;
            default: $this->error('Unknown FAQ action');
        }
    }
    
    public function list() {
        $faqs = $this->db->getCollection('faqs');
        $this->success($faqs);
    }

    public function add() {
        $this->checkAdmin();
        $input = json_decode(file_get_contents('php://input'), true);
        if (!isset($input['question']) || !isset($input['answer'])) $this->error('Missing fields');

        $newFaq = [
            'id' => 'faq-' . uniqid(),
            'category' => $input['category'] ?? 'Genel',
            'question' => $input['question'],
            'answer' => $input['answer'],
            'createdAt' => time() * 1000
        ];

        $this->db->saveItem('faqs', $newFaq);
        $this->success($newFaq);
    }

    public function update() {
        $this->checkAdmin();
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        if (!$id) $this->error('ID required');

        $faq = $this->db->getItemById('faqs', $id);
        if ($faq) {
            $faq['question'] = $input['question'] ?? $faq['question'];
            $faq['answer'] = $input['answer'] ?? $faq['answer'];
            $faq['category'] = $input['category'] ?? $faq['category'];
            $this->db->saveItem('faqs', $faq);
            $this->success(['message' => 'SSS güncellendi']);
        } else {
            $this->error('SSS bulunamadı');
        }
    }

    public function delete() {
        $this->checkAdmin();
        $id = $_GET['id'] ?? null;
        if (!$id) $this->error('ID required');

        if ($this->db->deleteFromCollection('faqs', $id)) {
            $this->success(['message' => 'SSS silindi']);
        } else {
            $this->error('SSS bulunamadı');
        }
    }
}
