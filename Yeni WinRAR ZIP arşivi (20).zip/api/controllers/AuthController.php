<?php

require_once __DIR__ . '/../core/BaseController.php';

class AuthController extends BaseController {

    // Removed userDir as we use MySQL now

    public function login() {
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.gc_maxlifetime', 2592000);
            session_set_cookie_params([
                'lifetime' => 2592000,
                'path' => '/',
                'secure' => isset($_SERVER['HTTPS']),
                'httponly' => true,
                'samesite' => 'Lax'
            ]);
            session_start();
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $username = $input['username'] ?? '';
        $password = $input['password'] ?? '';

        if (!$username || !$password) {
            $this->error('Kullanıcı adı ve şifre gereklidir.');
            return;
        }

        $db = new Database();
        
        // Diagnostic: Check if PDO connection exists
        $users = $db->getCollection('users');
        if (empty($users)) {
            if (!$db->getPdo()) {
                $this->error('Veritabanı bağlantısı kurulamadı ve yerel yedek kullanıcı veritabanı boş. Hata: ' . ($db->getLastError() ?: 'Bilinmeyen hata.'));
            } else {
                $this->error('Veritabanında kayıtlı hiçbir kullanıcı bulunamadı (users tablosu boş). Lütfen migrate_to_mysql.php ve create_admin.php sayfasını çalıştırın.');
            }
            return;
        }

        $foundUser = null;
        foreach ($users as $u) {
            if (isset($u['username']) && strtolower($u['username']) === strtolower($username)) {
                $foundUser = $u;
                break;
            }
        }

        // Email ile de dene (kullanıcı e-posta adresiyle giriş yapıyor olabilir)
        if (!$foundUser) {
            foreach ($users as $u) {
                if (isset($u['email']) && strtolower($u['email']) === strtolower($username)) {
                    $foundUser = $u;
                    break;
                }
            }
        }

        if (!$foundUser) {
            $this->error('Kullanıcı adı veya e-posta bulunamadı. (Girilen: "' . htmlspecialchars($username) . '")');
            return;
        }

        if (isset($foundUser['password']) && $foundUser['password'] === $password) {
            if (isset($foundUser['isBanned']) && $foundUser['isBanned'] === true) {
                $this->error('Hesabınız askıya alınmıştır. Sebep: ' . ($foundUser['banReason'] ?? 'Belirtilmedi'), 403);
                return;
            }

            // Two-Factor Authentication Check
            if (isset($foundUser['twoFactorEnabled']) && $foundUser['twoFactorEnabled'] === true) {
                $otp = (string) rand(100000, 999999);
                $foundUser['loginOtp'] = $otp;
                $foundUser['loginOtpExpiry'] = time() + 600; // 10 minutes
                $db->saveItem('users', $foundUser);
                
                $email = $foundUser['email'] ?? '';
                if ($email) {
                    $subject = 'DramicBox İki Aşamalı Doğrulama Kodu';
                    $msg = "
                        <h2>Giriş Doğrulama</h2>
                        <p>DramicBox hesabınıza giriş yapmak için doğrulama kodunuz:</p>
                        <h1 style='color: #7c3aed; font-size: 32px; letter-spacing: 5px; text-align: center; background: #f4f4f5; padding: 15px; border-radius: 8px;'>{$otp}</h1>
                        <p>Bu kod 10 dakika geçerlidir.</p>
                    ";
                    $this->sendMail($email, $subject, $msg);
                }
                $this->success(['twoFactorRequired' => true, 'username' => $foundUser['username'], 'email' => $email]);
                return;
            }

            unset($foundUser['password']);
            
            $_SESSION['user_id'] = $foundUser['id'];
            $_SESSION['username'] = $foundUser['username']; 
            $_SESSION['user_role'] = $foundUser['role'] ?? 'user';
            $_SESSION['last_activity'] = time();

            $this->success(['user' => $foundUser, 'session_id' => session_id()]);
            return;
        }
        
        $this->error('Şifre hatalı. Lütfen şifrenizi kontrol edin.');
    }

    public function checkSession() {
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.gc_maxlifetime', 2592000);
            session_set_cookie_params([
                'lifetime' => 2592000,
                'path' => '/',
                'secure' => isset($_SERVER['HTTPS']),
                'httponly' => true,
                'samesite' => 'Lax'
            ]);
            session_start();
        }
        
        if (isset($_SESSION['user_id'])) {
            $db = new Database();
            $userData = $db->getItemById('users', $_SESSION['user_id']);
            
            if ($userData) {
                 if (isset($userData['isBanned']) && $userData['isBanned'] === true) {
                     session_destroy();
                     $this->success(['valid' => false, 'banned' => true, 'reason' => $userData['banReason'] ?? '']);
                     return;
                 }

                 unset($userData['password']);
                 $userData['lastSeen'] = date('c');
                 $db->saveItem('users', $userData);

                 $this->success(['user' => $userData, 'valid' => true]);
                 return;
            }
        }
        $this->success(['valid' => false]);
    }

    public function logout() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        session_unset();
        session_destroy();
        
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], "",
                $params["secure"], $params["httponly"]
            );
        }
        
        $this->success(['success' => true, 'message' => 'Çıkış yapıldı.']);
    }

    public function handleBanAppeal() {
        $input = json_decode(file_get_contents('php://input'), true);
        $username = $input['username'] ?? '';
        $message = $input['message'] ?? '';
        $contact = $input['contact'] ?? '';

        if (!$username || !$message) {
            $this->error('Eksik bilgi.');
        }

        // Send email to admin
        $to = 'halilcan1514@gmail.com'; // Admin email
        $subject = "[BAN APPEAL] $username - Ban Kaldırma Talebi";
        $body = "
            <h3>Ban Kaldırma Talebi</h3>
            <p><strong>Kullanıcı:</strong> $username</p>
            <p><strong>İletişim:</strong> $contact</p>
            <p><strong>Mesaj:</strong></p>
            <p>" . nl2br(htmlspecialchars($message)) . "</p>
        ";
        
        // Use global mail or require send-mail
        // Re-using simple mail() for now
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
        $headers .= "From: DramicBox System <noreplay@framcbox.com>" . "\r\n";
        
        @mail($to, $subject, $body, $headers);

        $this->success(['message' => 'Talebiniz iletildi.']);
    }
    
    public function sendVerification() {
        $input = json_decode(file_get_contents('php://input'), true);
        $email = $input['email'] ?? '';

        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->error('Geçersiz email adresi.');
        }

        // Generate Code on SERVER side
        $code = (string) rand(100000, 999999);
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION['admin_otp'] = $code;
        $_SESSION['admin_otp_expiry'] = time() + (10 * 60); // 10 mins

        // Also check if user wants Magic Link
        if (isset($input['type']) && $input['type'] === 'magic_link') {
            $this->handleMagicLinkSend($email);
            return;
        }

        $subject = 'DramicBox Admin Doğrulama Kodu';
        $message = "
            <div style='font-family: sans-serif; padding: 20px; border: 1px solid #eee; border-radius: 10px; max-width: 400px;'>
                <h2 style='color: #7c3aed;'>Admin Doğrulaması</h2>
                <p>Panele giriş yapmak için doğrulama kodunuz:</p>
                <div style='font-size: 32px; font-weight: 800; letter-spacing: 5px; color: #000; background: #f4f4f5; padding: 15px; text-align: center; border-radius: 8px;'>{$code}</div>
                <p style='color: #666; font-size: 12px; margin-top: 20px;'>Bu kod 10 dakika geçerlidir. Eğer bu işlemi siz yapmadıysanız lütfen şifrenizi değiştirin.</p>
            </div>
        ";

        $sent = $this->sendMail($email, $subject, $message);

        if ($sent) {
            $this->success(['message' => 'Doğrulama kodu gönderildi.']);
        } else {
            $this->success(['message' => 'Kod gönderildi (Dev: ' . $code . ')', 'dev_code' => $code]);
        }
    }

    public function verifyAdmin2FA() {
        $input = json_decode(file_get_contents('php://input'), true);
        $code = $input['code'] ?? '';
        $pin = $input['pin'] ?? '';

        if (session_status() === PHP_SESSION_NONE) session_start();

        // 1. Check OTP (Session based)
        $savedOtp = $_SESSION['admin_otp'] ?? null;
        $otpExpiry = $_SESSION['admin_otp_expiry'] ?? 0;

        if ($code && $savedOtp && $code === $savedOtp && time() < $otpExpiry) {
            unset($_SESSION['admin_otp']);
            $_SESSION['admin_verified'] = true;
            $this->success(['message' => 'Doğrulama başarılı.']);
            return;
        }

        // 2. Check Permanent PIN (Stored in DB)
        if ($pin && isset($_SESSION['user_id'])) {
            $userData = $this->db->getItemById('users', $_SESSION['user_id']);
            if ($userData) {
                $savedPin = $userData['admin_pin'] ?? null;
                if ($savedPin && $pin === $savedPin) {
                    $_SESSION['admin_verified'] = true;
                    $this->success(['message' => 'PIN doğrulaması başarılı.']);
                    return;
                }
            }
        }

        $this->error('Doğrulama kodu veya PIN hatalı.');
    }

    public function updateAdminPIN() {
        $input = json_decode(file_get_contents('php://input'), true);
        $pin = $input['pin'] ?? '';
        if (!$pin || strlen($pin) < 4) $this->error('PIN en az 4 haneli olmalıdır.');

        if (session_status() === PHP_SESSION_NONE) session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) $this->error('Oturum bulunamadı.');

        $userData = $this->db->getItemById('users', $userId);
        if ($userData) {
            $userData['admin_pin'] = $pin;
            $this->db->saveItem('users', $userData);
            $this->success(['message' => 'Güvenlik PIN kodu güncellendi.']);
        } else {
            $this->error('Kullanıcı bulunamadı.');
        }
    }

    private function handleMagicLinkSend($email) {
        $token = bin2hex(random_bytes(16)); // 32 chars
        $expiry = time() + (30 * 60); // 30 minutes

        $tokensFile = __DIR__ . '/../../data/admin_tokens.json';
        $tokens = [];
        if (file_exists($tokensFile)) {
            $tokens = json_decode(file_get_contents($tokensFile), true) ?: [];
        }

        // Clean expired tokens
        $tokens = array_filter($tokens, function($t) {
            return $t['expiry'] > time();
        });

        $tokens[$token] = [
            'email' => $email,
            'expiry' => $expiry
        ];

        if (!file_exists(dirname($tokensFile))) {
            mkdir(dirname($tokensFile), 0755, true);
        }
        file_put_contents($tokensFile, json_encode($tokens, JSON_PRETTY_PRINT));

        // Send Email
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
        $magicLink = $protocol . $_SERVER['HTTP_HOST'] . "/#/admin-panel/" . $token;
        $subject = 'DramicBox Admin Giriş Bağlantısı';
        $message = "
        <div style='font-family: Arial, sans-serif; padding: 20px; background: #f4f4f5; border: 1px solid #e4e4e7; max-width: 500px; margin: 0 auto; border-radius: 8px;'>
            <div style='text-align: center; margin-bottom: 20px;'>
                <h2 style='color: #7c3aed; margin: 0;'>DramicBox</h2>
                <p style='color: #71717a; font-size: 14px; margin-top: 5px;'>Admin Güvenli Giriş</p>
            </div>
            
            <div style='background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);'>
                <p style='color: #3f3f46; margin-bottom: 20px;'>Admin paneline erişmek için aşağıdaki butona tıklayın:</p>
                <a href='{$magicLink}' style='background: #7c3aed; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;'>
                    Admin Paneline Giriş Yap
                </a>
                <p style='color: #71717a; font-size: 11px; margin-top: 20px;'>Bu bağlantı 30 dakika geçerlidir ve tek kullanımlıktır. Giriş yaptıktan sonra oturumunuz 30 gün boyunca açık kalacaktır.</p>
                <p style='color: #94a3b8; font-size: 10px; margin-top: 10px;'>Link çalışmazsa buraya kopyalayın: <br> <span style='word-break: break-all;'>{$magicLink}</span></p>
            </div>
        </div>
        ";

        $sent = $this->sendMail($email, $subject, $message);

        if ($sent) {
            $this->success(['message' => 'Sihirli bağlantı e-posta adresinize gönderildi.']);
        } else {
            $this->error('Bağlantı gönderilemedi. (Dev Token: ' . $token . ')', 500);
        }
    }

    public function verifyMagicLink() {
        $input = json_decode(file_get_contents('php://input'), true);
        $token = $input['token'] ?? ($_GET['token'] ?? '');

        if (!$token) $this->error('Geçersiz istek.');

        $tokensFile = __DIR__ . '/../../data/admin_tokens.json';
        if (!file_exists($tokensFile)) $this->error('Bağlantı bulunamadı veya süresi dolmuş.');

        $tokens = json_decode(file_get_contents($tokensFile), true) ?: [];

        if (!isset($tokens[$token])) {
            $this->error('Geçersiz veya süresi dolmuş bağlantı.');
        }

        $tokenData = $tokens[$token];
        if ($tokenData['expiry'] < time()) {
            unset($tokens[$token]);
            file_put_contents($tokensFile, json_encode($tokens, JSON_PRETTY_PRINT));
            $this->error('Bağlantı süresi dolmuş.');
        }

        // Token matches! Find the user.
        $email = $tokenData['email'];
        require_once __DIR__ . '/../core/Database.php';
        $db = new Database();
        $allData = $db->loadCollections(['users']);
        $users = $allData['users'] ?? [];

        $foundUser = null;
        foreach ($users as $u) {
            if (isset($u['email']) && strtolower($u['email']) === strtolower($email)) {
                $foundUser = $u;
                break;
            }
        }

        if (!$foundUser) {
            $this->error('Kullanıcı bulunamadı.');
        }

        // Detect if this is an admin login or just a user verification
        $isAdminLogin = ($foundUser['role'] ?? '') === 'admin';
        
        // Login the user - Set long-lived session (30 days)
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.gc_maxlifetime', 2592000); // 30 days
            session_set_cookie_params([
                'lifetime' => 2592000,
                'path' => '/',
                'domain' => $_SERVER['HTTP_HOST'],
                'secure' => isset($_SERVER['HTTPS']),
                'httponly' => true,
                'samesite' => 'Lax'
            ]);
            session_start();
        }
        
        $_SESSION['user_id'] = $foundUser['id'];
        $_SESSION['username'] = $foundUser['username'];
        $_SESSION['user_role'] = $foundUser['role'] ?? 'user';
        $_SESSION['last_activity'] = time();

        // Log IP
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        $logFile = __DIR__ . '/../../data/admin_logins.json';
        $logData = [];
        if (file_exists($logFile)) {
            $logData = json_decode(file_get_contents($logFile), true) ?: [];
        }
        $logData[] = [
            'username' => $foundUser['username'],
            'email' => $email,
            'ip' => $ip,
            'time' => date('c'),
            'userAgent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
        ];
        if (!file_exists(dirname($logFile))) {
            mkdir(dirname($logFile), 0755, true);
        }
        file_put_contents($logFile, json_encode($logData, JSON_PRETTY_PRINT));

        // Consume token
        unset($tokens[$token]);
        file_put_contents($tokensFile, json_encode($tokens, JSON_PRETTY_PRINT));

        // Log the login
        $this->logAdminLogin($foundUser['username'], $email);

        $this->success(['user' => $this->sanitizeUser($foundUser)]);
    }

    private function logAdminLogin($username, $email) {
        $newEntry = [
            'id' => uniqid('adm_'),
            'username' => $username,
            'email' => $email,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'time' => date('c'),
            'ua' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ];
        $this->db->saveItem('admin_logins', $newEntry);
    }

    private function sanitizeUser($user) {
        unset($user['password']);
        unset($user['reset_code']);
        unset($user['reset_expiry']);
        return $user;
    }

    private function sendMail($to, $subject, $message) {
        $smtpHost = 'mail.dramicbox.com';
        $smtpPort = 465;
        $smtpUser = 'info@dramicbox.com';
        $smtpPass = 'Zumran1514';

        if (empty($smtpPass) || $smtpPass === 'BURAYA_MAIL_SIFRESINI_YAZIN') {
             $simpleHeaders = "MIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8\r\nFrom: DramicBox <info@dramicbox.com>\r\n";
             return @mail($to, $subject, $message, $simpleHeaders);
        } else {
             require_once __DIR__ . '/../core/SMTPMailer.php';
             $mailer = new SMTPMailer($smtpHost, $smtpPort, $smtpUser, $smtpPass);
             return $mailer->send($to, $subject, $message, 'DramicBox Security');
        }
    }
    

    public function register() {
        $input = json_decode(file_get_contents('php://input'), true);
        $username = $input['username'] ?? '';
        $password = $input['password'] ?? '';
        $email = $input['email'] ?? '';

        if (!$username || !$password) $this->error('Eksik bilgi.');

        $db = new Database();
        $users = $db->getCollection('users');
        
        foreach ($users as $u) {
            if (strtolower($u['username']) === strtolower($username)) {
                $this->error('Bu kullanıcı adı zaten alınmış.');
                return;
            }
        }

        $newUser = [
            'id' => uniqid('u_'),
            'username' => $username,
            'password' => $password, 
            'email' => $email,
            'role' => 'user',
            'badges' => [],
            'watchlist' => [],
            'createdAt' => date('c'),
            'stats' => ['xp' => 0, 'level' => 1, 'coins' => 0]
        ];

        if ($db->saveItem('users', $newUser)) {
            unset($newUser['password']);
            $this->success(['user' => $newUser]);
        } else {
            $this->error('Kayıt oluşturulamadı.');
        }
    }
    
    public function updateUser() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $currentUserId = $_SESSION['user_id'] ?? $_SESSION['user']['id'] ?? null;
        if (!$currentUserId) $this->error('Unauthorized');
        
        $input = json_decode(file_get_contents('php://input'), true);
        $targetUserId = $input['targetUserId'] ?? $currentUserId;

        // Security check: Only admins can update other users
        $userRole = $_SESSION['user_role'] ?? $_SESSION['user']['role'] ?? 'user';
        if ($targetUserId !== $currentUserId && $userRole !== 'admin') {
            $this->error('Permission denied. Only admins can update other users.');
        }

        $db = new Database();
        $userData = $db->getItemById('users', $targetUserId);
        
        if ($userData) {
            $updates = isset($input['updates']) ? $input['updates'] : $input;
            $allowedFields = [
                'status', 'mood', 'avatar', 'badges', 'stats', 'profile', 
                'privacy', 'watchlist', 'activeFrame', 'activeBadge', 
                'can_stream', 'achievements', 'lastLoginDate', 'following', 'showcase', 'fanLevels',
                'twoFactorEnabled', 'verificationRequested', 'ratings',
                'vipStatus', 'isVip', 'vipUntil', 'actorCards', 'gamification', 'inventory', 'activeItems', 'receivedCoffees'
            ];
            if ($userRole === 'admin') {
                $allowedFields[] = 'isVerified';
                $allowedFields[] = 'verificationStatus';
                $allowedFields[] = 'verificationToken';
                $allowedFields[] = 'role';
            }
            foreach ($updates as $key => $value) {
                if (in_array($key, $allowedFields)) {
                    $userData[$key] = $value;
                }
            }

            if ($db->saveItem('users', $userData)) {
                unset($userData['password']);
                $this->success(['user' => $userData]);
            } else {
                $this->error('Güncelleme başarısız');
            }
        } else {
            $this->error('Kullanıcı bulunamadı');
        }
    }

    public function handleDonation() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) $this->error('Unauthorized');

        $input = json_decode(file_get_contents('php://input'), true);
        $amount = intval($input['amount'] ?? 0);
        $receiverId = $input['creatorId'] ?? null;
        $note = $input['note'] ?? '';

        if ($amount <= 0 || !$receiverId) $this->error('Geçersiz bağış verisi.');

        $senderData = $this->db->getItemById('users', $userId);
        if (!$senderData) $this->error('Gönderici bulunamadı.');

        if (($senderData['stats']['coins'] ?? 0) < $amount) $this->error('Yetersiz bakiye.');

        // 2. Special Case: Translator Pool
        if ($receiverId === 'translator-pool' || $receiverId === 'translator') {
            $senderData['stats']['coins'] -= $amount;
            if (!isset($senderData['donationsGiven'])) $senderData['donationsGiven'] = [];
            $senderData['donationsGiven'][] = [
                'id' => uniqid('don_'), 'toName' => 'Çevirmen Havuzu', 'amount' => $amount, 'date' => date('c')
            ];
            $this->db->saveItem('users', $senderData);
            $this->success(['message' => 'Havuz bağışı başarılı!', 'newBalance' => $senderData['stats']['coins']]);
            return;
        }

        // 3. Find Receiver
        $receiverData = $this->db->getItemById('users', $receiverId);
        if (!$receiverData) {
            // Fallback: search by username
            $users = $this->db->getCollection('users');
            foreach ($users as $u) {
                if (strtolower($u['username'] ?? '') === strtolower($receiverId)) {
                    $receiverData = $u; break;
                }
            }
        }

        if (!$receiverData) $this->error('Alıcı bulunamadı.');
        if (($receiverData['id'] ?? '') === ($senderData['id'] ?? '')) $this->error('Kendinize bağış yapamazsınız.');

        // 4. Process Transaction
        $senderData['stats']['coins'] -= $amount;
        
        if (!isset($receiverData['stats']['earnings'])) $receiverData['stats']['earnings'] = 0;
        $receiverData['stats']['earnings'] += $amount;
        
        if (isset($receiverData['stats']['goal'])) {
            if (!isset($receiverData['stats']['goal']['current'])) $receiverData['stats']['goal']['current'] = 0;
            $receiverData['stats']['goal']['current'] += $amount;
        }

        if (!isset($receiverData['donationsReceived'])) $receiverData['donationsReceived'] = [];
        $receiverData['donationsReceived'][] = [
            'id' => uniqid('don_'), 'fromId' => $senderData['id'], 'fromName' => $senderData['username'],
            'amount' => $amount, 'note' => $note, 'date' => date('c')
        ];

        // 5. Save both
        $this->db->saveItem('users', $senderData);
        $this->db->saveItem('users', $receiverData);

        $this->success(['message' => 'Bağış başarıyla gönderildi!', 'newBalance' => $senderData['stats']['coins']]);
    }

    // ================= FORGOT PASSWORD =================

    public function handleForgotPassword() {
        $input = json_decode(file_get_contents('php://input'), true);
        $email = $input['email'] ?? '';

        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->error('Geçersiz email adresi.');
        }

        $db = new Database();
        $users = $db->getCollection('users');
        
        $foundUser = null;
        foreach ($users as $u) {
            if (isset($u['email']) && strtolower($u['email']) === strtolower($email)) {
                $foundUser = $u;
                break;
            }
        }

        if (!$foundUser) {
             $this->error('Bu email adresi ile kayıtlı kullanıcı bulunamadı.');
        }

        // Generate Code
        $code = (string) rand(100000, 999999);
        $foundUser['reset_code'] = $code;
        $foundUser['reset_expiry'] = time() + (15 * 60);

        $db->saveItem('users', $foundUser);

        $subject = 'DramicBox Şifre Sıfırlama Kodu';
        $message = "
            <h2>Şifre Sıfırlama</h2>
            <p>Merhaba {$foundUser['username']},</p>
            <p>Hesabınız için şifre sıfırlama talebi aldık. Kodunuz:</p>
            <h1 style='color: #7c3aed;'>{$code}</h1>
            <p>Bu kod 15 dakika geçerlidir.</p>
        ";
        
        $sent = $this->sendMail($email, $subject, $message);

        if ($sent) {
            $this->success(['message' => 'Doğrulama kodu email adresinize gönderildi.']);
        } else {
            $this->success(['message' => 'Kod gönderildi (Dev: ' . $code . ')', 'dev_code' => $code]); 
        }
    }

    public function handleResetPassword() {
        $input = json_decode(file_get_contents('php://input'), true);
        $email = $input['email'] ?? '';
        $code = $input['code'] ?? '';
        $newPassword = $input['newPassword'] ?? '';

        if (!$email || !$code || !$newPassword) {
            $this->error('Eksik bilgi.');
        }

        $db = new Database();
        $users = $db->getCollection('users');
        
        $foundUser = null;
        foreach ($users as $u) {
            if (isset($u['email']) && strtolower($u['email']) === strtolower($email)) {
                $foundUser = $u;
                break;
            }
        }

        if (!$foundUser) {
            $this->error('Kullanıcı bulunamadı.');
        }

        $savedCode = $foundUser['reset_code'] ?? null;
        $expiry = $foundUser['reset_expiry'] ?? 0;

        if (!$savedCode || $savedCode !== $code) {
            $this->error('Geçersiz doğrulama kodu.');
        }

        if (time() > $expiry) {
            $this->error('Doğrulama kodunun süresi dolmuş.');
        }

        $foundUser['password'] = $newPassword; 
        unset($foundUser['reset_code']);
        unset($foundUser['reset_expiry']);

        $db->saveItem('users', $foundUser);

        $this->success(['message' => 'Şifreniz başarıyla güncellendi. Giriş yapabilirsiniz.']);
    }

    public function verify2fa() {
        $input = json_decode(file_get_contents('php://input'), true);
        $username = $input['username'] ?? '';
        $code = $input['code'] ?? '';

        if (!$username || !$code) {
            $this->error('Kullanıcı adı ve doğrulama kodu gereklidir.');
            return;
        }

        $db = new Database();
        $users = $db->getCollection('users');
        $foundUser = null;
        foreach ($users as $u) {
            if (isset($u['username']) && strtolower($u['username']) === strtolower($username)) {
                $foundUser = $u;
                break;
            }
        }

        if (!$foundUser) {
            $this->error('Kullanıcı bulunamadı.');
            return;
        }

        $savedOtp = $foundUser['loginOtp'] ?? null;
        $otpExpiry = $foundUser['loginOtpExpiry'] ?? 0;

        if ($savedOtp && $code === $savedOtp && time() < $otpExpiry) {
            unset($foundUser['loginOtp']);
            unset($foundUser['loginOtpExpiry']);
            $db->saveItem('users', $foundUser);

            unset($foundUser['password']);
            
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION['user_id'] = $foundUser['id'];
            $_SESSION['username'] = $foundUser['username'];
            $_SESSION['user_role'] = $foundUser['role'] ?? 'user';
            $_SESSION['last_activity'] = time();

            $this->success(['user' => $foundUser, 'session_id' => session_id()]);
            return;
        }

        $this->error('Doğrulama kodu hatalı veya süresi dolmuş.');
    }

    public function sendLoginOtp() {
        $input = json_decode(file_get_contents('php://input'), true);
        $email = $input['email'] ?? '';

        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->error('Geçersiz email adresi.');
            return;
        }

        $db = new Database();
        $users = $db->getCollection('users');
        $foundUser = null;
        foreach ($users as $u) {
            if (isset($u['email']) && strtolower($u['email']) === strtolower($email)) {
                $foundUser = $u;
                break;
            }
        }

        if (!$foundUser) {
            $this->error('Bu e-posta adresiyle kayıtlı bir kullanıcı bulunamadı.');
            return;
        }

        $otp = (string) rand(100000, 999999);
        $foundUser['loginOtp'] = $otp;
        $foundUser['loginOtpExpiry'] = time() + 600; // 10 minutes
        $db->saveItem('users', $foundUser);

        $subject = 'DramicBox Şifresiz Giriş Kodu';
        $msg = "
            <h2>Şifresiz Giriş</h2>
            <p>DramicBox hesabınıza giriş yapmak için doğrulama kodunuz:</p>
            <h1 style='color: #7c3aed; font-size: 32px; letter-spacing: 5px; text-align: center; background: #f4f4f5; padding: 15px; border-radius: 8px;'>{$otp}</h1>
            <p>Bu kod 10 dakika geçerlidir.</p>
        ";
        $sent = $this->sendMail($email, $subject, $msg);

        if ($sent) {
            $this->success(['message' => 'Giriş kodu e-postanıza gönderildi.', 'email' => $email]);
        } else {
            // Mail gönderilemedi ama OTP kaydedildi — dev modda kodu göster
            $this->success(['message' => 'Kod gönderildi (Dev: ' . $otp . ')', 'dev_code' => $otp, 'email' => $email]);
        }
    }

    public function verifyLoginOtp() {
        $input = json_decode(file_get_contents('php://input'), true);
        $email = $input['email'] ?? '';
        $code = $input['code'] ?? '';

        if (!$email || !$code) {
            $this->error('E-posta ve doğrulama kodu gereklidir.');
            return;
        }

        $db = new Database();
        $users = $db->getCollection('users');
        $foundUser = null;
        foreach ($users as $u) {
            if (isset($u['email']) && strtolower($u['email']) === strtolower($email)) {
                $foundUser = $u;
                break;
            }
        }

        if (!$foundUser) {
            $this->error('Kullanıcı bulunamadı.');
            return;
        }

        $savedOtp = $foundUser['loginOtp'] ?? null;
        $otpExpiry = $foundUser['loginOtpExpiry'] ?? 0;

        if ($savedOtp && $code === $savedOtp && time() < $otpExpiry) {
            unset($foundUser['loginOtp']);
            unset($foundUser['loginOtpExpiry']);
            $db->saveItem('users', $foundUser);

            unset($foundUser['password']);

            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION['user_id'] = $foundUser['id'];
            $_SESSION['username'] = $foundUser['username'];
            $_SESSION['user_role'] = $foundUser['role'] ?? 'user';
            $_SESSION['last_activity'] = time();

            $this->success(['user' => $foundUser, 'session_id' => session_id()]);
            return;
        }

        $this->error('Doğrulama kodu hatalı veya süresi dolmuş.');
    }

    public function approveVerification() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $userRole = $_SESSION['user_role'] ?? $_SESSION['user']['role'] ?? 'guest';
        if ($userRole !== 'admin') {
            $this->error('Permission denied. Admin only.');
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $userId = $input['userId'] ?? '';

        if (!$userId) {
            $this->error('User ID is required.');
            return;
        }

        $db = new Database();
        $user = $db->getItemById('users', $userId);
        if (!$user) {
            $this->error('User not found.');
            return;
        }

        $token = bin2hex(random_bytes(16));
        $user['verificationStatus'] = 'approved';
        $user['verificationToken'] = $token;
        $user['verificationTokenExpiry'] = time() + (24 * 60 * 60); // 24 hours

        if ($db->saveItem('users', $user)) {
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
            $link = $protocol . $_SERVER['HTTP_HOST'] . "/#/verify-account/" . $token;
            
            $email = $user['email'] ?? '';
            if ($email) {
                $subject = 'DramicBox Hesap Doğrulama Bağlantısı';
                $msg = "
                    <h2>Hesap Doğrulama</h2>
                    <p>Merhaba {$user['username']},</p>
                    <p>Mavi tik başvurunuz onaylanmıştır! Hesabınızı doğrulamak ve rozetinizi almak için aşağıdaki bağlantıya tıklayın:</p>
                    <p><a href='{$link}' style='display:inline-block; padding:10px 20px; background:#7c3aed; color:#fff; text-decoration:none; border-radius:6px;'>Hesabımı Doğrula</a></p>
                    <p style='font-size:12px; color:#666;'>Bu bağlantı 24 saat geçerlidir.</p>
                ";
                $this->sendMail($email, $subject, $msg);
            }
            $this->success(['message' => 'Başvuru onaylandı, doğrulama linki gönderildi.']);
        } else {
            $this->error('Veritabanı kayıt hatası.');
        }
    }

    public function rejectVerification() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $userRole = $_SESSION['user_role'] ?? $_SESSION['user']['role'] ?? 'guest';
        if ($userRole !== 'admin') {
            $this->error('Permission denied. Admin only.');
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $userId = $input['userId'] ?? '';

        if (!$userId) {
            $this->error('User ID is required.');
            return;
        }

        $db = new Database();
        $user = $db->getItemById('users', $userId);
        if (!$user) {
            $this->error('User not found.');
            return;
        }

        $user['verificationStatus'] = 'rejected';
        $user['verificationRequested'] = false;
        unset($user['verificationToken']);

        if ($db->saveItem('users', $user)) {
            $this->success(['message' => 'Başvuru reddedildi.']);
        } else {
            $this->error('Veritabanı kayıt hatası.');
        }
    }

    public function verifyAccountMagicLink() {
        $input = json_decode(file_get_contents('php://input'), true);
        $token = $input['token'] ?? '';

        if (!$token) {
            $this->error('Geçersiz doğrulama bağlantısı.');
            return;
        }

        $db = new Database();
        $users = $db->getCollection('users');
        $foundUser = null;
        foreach ($users as $u) {
            if (isset($u['verificationToken']) && $u['verificationToken'] === $token) {
                $foundUser = $u;
                break;
            }
        }

        if (!$foundUser) {
            $this->error('Geçersiz veya süresi dolmuş doğrulama bağlantısı.');
            return;
        }

        $expiry = $foundUser['verificationTokenExpiry'] ?? 0;
        if (time() > $expiry) {
            $this->error('Doğrulama bağlantısının süresi dolmuş.');
            return;
        }

        $foundUser['isVerified'] = true;
        $foundUser['verificationStatus'] = 'verified';
        unset($foundUser['verificationToken']);
        unset($foundUser['verificationTokenExpiry']);

        if ($db->saveItem('users', $foundUser)) {
            $this->success(['message' => 'Tebrikler! Hesabınız başarıyla doğrulandı ve mavi tikiniz tanımlandı.', 'user' => $this->sanitizeUser($foundUser)]);
        } else {
            $this->error('Doğrulama kaydedilemedi.');
        }
    }

    public function sendAdminOtp() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        
        $userId = $_SESSION['user_id'] ?? $_SESSION['user']['id'] ?? null;
        if (!$userId) {
            $this->error('Önce giriş yapmalısınız.');
            return;
        }

        $db = new Database();
        $user = $db->getItemById('users', $userId);
        if (!$user) {
            $this->error('Kullanıcı bulunamadı.');
            return;
        }

        if (!isset($user['role']) || !in_array($user['role'], ['admin', 'moderator', 'editor', 'translation_leader', 'editor_leader'])) {
            $this->error('Yetkisiz erişim.');
            return;
        }

        $email = $user['email'] ?? '';
        if (!$email) {
            $this->error('Kullanıcının kayıtlı bir e-posta adresi bulunamadı.');
            return;
        }

        $otp = (string) rand(100000, 999999);
        $user['adminOtp'] = $otp;
        $user['adminOtpExpiry'] = time() + 600; // 10 minutes
        $db->saveItem('users', $user);

        $subject = 'DramicBox Yönetici Giriş Kodu';
        $msg = "
            <div style='font-family: sans-serif; padding: 20px; border: 1px solid #eee; border-radius: 10px; max-width: 450px; margin: 0 auto;'>
                <h2 style='color: #7c3aed; text-align: center;'>Yönetici Giriş Doğrulaması</h2>
                <p>Merhaba <strong>{$user['username']}</strong>,</p>
                <p>DramicBox Yönetim Paneline erişmek için tek kullanımlık güvenlik doğrulama kodunuz:</p>
                <div style='font-size: 32px; font-weight: 800; letter-spacing: 5px; color: #7c3aed; background: #f4f4f5; padding: 15px; text-align: center; border-radius: 8px; margin: 20px 0;'>{$otp}</div>
                <p style='color: #666; font-size: 12px;'>Bu kod 10 dakika geçerlidir. Eğer bu işlemi siz yapmadıysanız lütfen hemen hesabınızın şifresini değiştirin.</p>
            </div>
        ";
        $this->sendMail($email, $subject, $msg);

        $maskedEmail = substr($email, 0, 3) . '****' . strrchr($email, '@');
        $this->success(['message' => 'Yönetici giriş kodu e-posta adresinize gönderildi.', 'email' => $maskedEmail]);
    }

    public function verifyAdminOtp() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        $userId = $_SESSION['user_id'] ?? $_SESSION['user']['id'] ?? null;
        if (!$userId) {
            $this->error('Giriş yapmalısınız.');
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $code = $input['code'] ?? '';

        if (!$code) {
            $this->error('Güvenlik kodu gereklidir.');
            return;
        }

        $db = new Database();
        $user = $db->getItemById('users', $userId);
        if (!$user) {
            $this->error('Kullanıcı bulunamadı.');
            return;
        }

        $savedOtp = $user['adminOtp'] ?? null;
        $otpExpiry = $user['adminOtpExpiry'] ?? 0;

        if ($savedOtp && $code === $savedOtp && time() < $otpExpiry) {
            unset($user['adminOtp']);
            unset($user['adminOtpExpiry']);
            $db->saveItem('users', $user);

            $_SESSION['admin_verified'] = true;

            $this->success(['message' => 'Yönetici kimlik doğrulaması başarılı.']);
            return;
        }

        $this->error('Güvenlik kodu hatalı veya süresi dolmuş.');
    }

}
