<?php

require_once __DIR__ . '/../core/BaseController.php';
require_once __DIR__ . '/../core/Database.php';

class ReportController extends BaseController {
    private $userDir;

    public function __construct() {
        parent::__construct();
        $this->userDir = __DIR__ . '/../../Database/kullanicilar/';
    }

    public function handle($action) {
        switch($action) {
            case 'rep-submit':
            case 'report-submit': $this->submit(); break;
            case 'rep-list':
            case 'report-list': $this->list(); break;
            case 'rep-resolve':
            case 'report-resolve': $this->resolve(); break;
            default: $this->error('Unknown report action');
        }
    }

    public function submit() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['username'])) $this->error('Giriş yapmalısınız.');

        $input = json_decode(file_get_contents('php://input'), true);
        $seriesId = $input['seriesId'] ?? '';
        $episodeNum = intval($input['episodeNum'] ?? 0);
        $type = $input['type'] ?? 'other'; 
        $description = $input['description'] ?? '';

        if (empty($seriesId) || empty($episodeNum)) $this->error('Geçersiz veri.');

        $newReport = [
            'id' => uniqid('rep_'),
            'seriesId' => $seriesId,
            'episodeNum' => $episodeNum,
            'type' => $type,
            'description' => $description,
            'userId' => $_SESSION['username'],
            'status' => 'open', 
            'date' => date('c')
        ];

        $this->db->addToCollection('reports', $newReport);
        $this->success($newReport);
    }

    public function list() {
        $reports = $this->db->getCollection('reports');
        $this->success($reports);
    }

    public function resolve() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $id = $_GET['id'] ?? null;
        $status = $_GET['status'] ?? 'fixed';
        if (!$id) $this->error('Geçersiz rapor.');

        $rep = $this->db->getItemById('reports', $id);
        if ($rep) {
            $rep['status'] = $status;
            $this->db->saveItem('reports', $rep);
            
            $resolverXP = null;
            if ($status === 'fixed') {
                if (isset($rep['userId'])) $this->rewardUser($rep['userId']);
                if (isset($_SESSION['username'])) {
                    $resolverXP = $this->awardCreatorXP($_SESSION['username'], 30);
                }
            }
            $this->success(['status' => $status, 'resolverXP' => $resolverXP]);
        } else {
            $this->error('Rapor bulunamadı.');
        }
    }

    private function rewardUser($username) {
        $users = $this->db->getCollection('users');
        foreach ($users as $u) {
            if (strtolower($u['username']) === strtolower($username)) {
                if (!isset($u['stats'])) $u['stats'] = ['coins' => 0];
                if (!isset($u['stats']['coins'])) $u['stats']['coins'] = 0;
                $u['stats']['coins'] += 20;
                $this->db->saveItem('users', $u);
                break;
            }
        }
    }
}
