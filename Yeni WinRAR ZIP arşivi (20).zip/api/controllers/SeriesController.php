<?php

require_once __DIR__ . '/../core/BaseController.php';

class SeriesController extends BaseController {
    
    public function index() {
        // Return full DB or just series depending on need
        // Original db.php returned everything on 'read', let's support that or specific
        $this->success($this->db->getData());
    }

    public function getSeries() {
        $data = $this->db->getData();
        $this->success($data['series'] ?? []);
    }

    public function incrementView() {
        $input = json_decode(file_get_contents('php://input'), true);
        $seriesId = $input['seriesId'] ?? null;

        if (!$seriesId) {
            $this->error('Series ID required');
        }

        $series = $this->db->getItemById('series', $seriesId);
        if (!$series) {
            $series = $this->db->getItemById('webtoons', $seriesId);
            $type = 'webtoons';
        } else {
            $type = 'series';
        }

        if ($series) {
            if (!isset($series['views'])) $series['views'] = 0;
            $series['views']++;
            
            if ($this->db->saveItem($type, $series)) {
                $this->success(['views' => $series['views']]);
            } else {
                $this->error('Failed to save view count');
            }
        } else {
            $this->error('Series not found');
        }
    }

    public function updateEpisode() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) $this->error('No input data provided');

        $seriesId = $input['seriesId'] ?? null;
        $episodeData = $input['episode'] ?? ($input['episodeData'] ?? null);
        $maturity = $input['maturity'] ?? null;

        if (!$seriesId || !$episodeData) {
            $this->error('Missing required fields: seriesId or episode data');
        }

        $series = $this->db->getItemById('series', $seriesId);
        $type = 'series';
        if (!$series) {
            $series = $this->db->getItemById('webtoons', $seriesId);
            $type = 'webtoons';
        }

        if (!$series) {
            $this->error('Content not found: ' . $seriesId);
        }
        
        if ($maturity) $series['ageRating'] = $maturity;
        if (!isset($series['seasons'])) $series['seasons'] = [];
        
        $targetEpisodeNum = $episodeData['number'] ?? null;
        if ($targetEpisodeNum === null) $this->error('Episode number is required');

        $episodeUpdated = false;
        foreach ($series['seasons'] as &$season) {
            if (!isset($season['episodes'])) $season['episodes'] = [];
            foreach ($season['episodes'] as &$episode) {
                if (isset($episode['number']) && $episode['number'] == $targetEpisodeNum) {
                    $episode = array_merge($episode, $episodeData);
                    $episodeUpdated = true;
                    break 2;
                }
            }
        }

        if (!$episodeUpdated) {
            $season1Idx = -1;
            foreach ($series['seasons'] as $idx => $s) {
                if ($s['number'] == 1) { $season1Idx = $idx; break; }
            }
            if ($season1Idx === -1) {
                $series['seasons'][] = ['id' => 'season-1-' . uniqid(), 'number' => 1, 'episodes' => []];
                $season1Idx = count($series['seasons']) - 1;
            }
            if (!isset($episodeData['id'])) $episodeData['id'] = 'ep-' . uniqid();
            $series['seasons'][$season1Idx]['episodes'][] = $episodeData;
        }

        if ($this->db->saveItem($type, $series)) {
             if (session_status() === PHP_SESSION_NONE) session_start();
             $this->logActivity('update_episode', [
                 'seriesId' => $seriesId,
                 'seriesTitle' => $series['title'] ?? '',
                 'episode' => $episodeData['number']
             ]);

             $xpData = null;
             if (isset($_SESSION['username'])) {
                 $xpData = $this->awardCreatorXP($_SESSION['username'], 50);
             }
             $this->success(['message' => 'Episode updated successfully', 'xp' => $xpData]);
        } else {
             $this->error('Failed to save to database');
        }
    }
    public function addSeries() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            $this->error('No input data provided');
        }

        $id = $input['id'] ?? null;
        $title = $input['title'] ?? null;

        if (!$id && $title) {
            // Generate Slug if no ID provided
            $id = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $title), '-'));
        }

        if (!$id) {
            $this->error('Series ID or Title is required');
        }

        // Prepare Data
        $seriesData = $input;
        $seriesData['id'] = $id;

        // Save to MySQL using upsert logic in saveItem
        if ($this->db->saveItem('series', $seriesData)) {
             // Optional: Log activity for NEW series only
             $existing = $this->db->getItemById('series', $id);
             if (!$existing) {
                $this->logActivity('new_series', [
                    'seriesId' => $id,
                    'title' => $seriesData['title'] ?? '',
                    'poster' => $seriesData['poster'] ?? ''
                ]);
             }
            $this->success(['message' => 'Series saved successfully', 'series' => $seriesData]);
        } else {
            $this->error('Failed to save to database');
        }
    }

    public function getCreatorStats() {
        $creatorId = $_GET['creatorId'] ?? null;
        if (!$creatorId) {
            $this->error('Creator ID required');
        }

        $stats = [
            'totalViews' => 0,
            'totalLikes' => 0,
            'contentCount' => 0,
            'items' => []
        ];

        $data = $this->db->getData();

        // 1. Check Series & Webtoons
        foreach ($data['series'] as $item) {
            $isContributor = false;
            if (isset($item['seasons'])) {
                foreach ($item['seasons'] as $season) {
                    if (isset($season['episodes'])) {
                        foreach ($season['episodes'] as $ep) {
                            if (isset($ep['sources'])) {
                                foreach ($ep['sources'] as $src) {
                                    if (isset($src['addedBy']) && $src['addedBy'] === $creatorId) {
                                        $isContributor = true;
                                        break 3;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if ($isContributor) {
                $itemViews = $item['views'] ?? 0;
                $itemLikes = $item['likes'] ?? 0;
                $stats['totalViews'] += $itemViews;
                $stats['totalLikes'] += $itemLikes;
                $stats['contentCount']++;
                $stats['items'][] = [
                    'title' => $item['title'],
                    'type' => $item['type'] ?? 'drama',
                    'views' => $itemViews,
                    'likes' => $itemLikes
                ];
            }
        }

        // 2. Check Blog Posts
        $blogPosts = $data['blogPosts'] ?? [];
        foreach ($blogPosts as $post) {
            if (isset($post['authorId']) && $post['authorId'] === $creatorId) {
                $stats['totalViews'] += ($post['views'] ?? 0);
                $stats['totalLikes'] += ($post['likes'] ?? 0);
                $stats['contentCount']++;
                $stats['items'][] = [
                    'title' => $post['title'],
                    'type' => 'blog',
                    'views' => $post['views'] ?? 0,
                    'likes' => $post['likes'] ?? 0
                ];
            }
        }

        $this->success($stats);
    }

    public function deleteSeries() {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            $input = json_decode(file_get_contents('php://input'), true);
            $id = $input['id'] ?? null;
        }

        if (!$id) {
            $this->error('Series ID is required');
        }

        if ($this->db->deleteFromCollection('series', $id)) {
            $this->success(['message' => 'Series deleted successfully']);
        } else {
            $this->error('Failed to delete series');
        }
    }

    private function deleteDir($dirPath) {
        if (!is_dir($dirPath)) return;
        $files = array_diff(scandir($dirPath), array('.', '..'));
        foreach ($files as $file) {
            (is_dir("$dirPath/$file")) ? $this->deleteDir("$dirPath/$file") : unlink("$dirPath/$file");
        }
        return rmdir($dirPath);
    }

    public function uploadWebtoonEpisode() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->error('POST method required');
        }

        $webtoonId = $_POST['webtoonId'] ?? null;
        $episodeNumber = $_POST['episodeNumber'] ?? null;

        if (!$webtoonId || !$episodeNumber) {
            $this->error('webtoonId and episodeNumber are required');
        }

        // Validate files exist
        if (!isset($_FILES['pages']) || empty($_FILES['pages']['name'][0])) {
            $this->error('No page files uploaded');
        }

        // Create upload directory
        $uploadDir = __DIR__ . '/../../uploads/webtoons/' . $webtoonId . '/episode-' . $episodeNumber . '/';
        if (!file_exists($uploadDir)) {
            if (!mkdir($uploadDir, 0777, true)) {
                $this->error('Failed to create upload directory');
            }
        }

        $savedFiles = [];
        $allowedTypes = ['image/webp', 'image/png', 'image/jpeg', 'image/jpg'];
        $fileCount = count($_FILES['pages']['name']);

        for ($i = 0; $i < $fileCount; $i++) {
            $tmpName = $_FILES['pages']['tmp_name'][$i];
            $fileType = $_FILES['pages']['type'][$i];
            $originalName = $_FILES['pages']['name'][$i];
            $error = $_FILES['pages']['error'][$i];

            if ($error !== UPLOAD_ERR_OK) {
                continue; // Skip failed uploads
            }

            // Validate file type
            if (!in_array($fileType, $allowedTypes)) {
                continue; // Skip non-image files
            }

            // Generate sequential filename: page-001.webp, page-002.webp, etc.
            $ext = pathinfo($originalName, PATHINFO_EXTENSION);
            $newName = sprintf('page-%03d.%s', $i + 1, $ext);
            $destPath = $uploadDir . $newName;

            if (move_uploaded_file($tmpName, $destPath)) {
                $savedFiles[] = 'uploads/webtoons/' . $webtoonId . '/episode-' . $episodeNumber . '/' . $newName;
            }
        }

        if (empty($savedFiles)) {
            $this->error('No files were saved successfully');
        }

        $this->success([
            'message' => 'Webtoon episode uploaded successfully',
            'webtoonId' => $webtoonId,
            'episodeNumber' => (int)$episodeNumber,
            'pages' => $savedFiles,
            'pageCount' => count($savedFiles)
        ]);
    }

    public function listCalendar() {
        $data = $this->db->loadCollections(['calendar']);
        $this->success($data['calendar'] ?? []);
    }

    public function saveCalendar() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) $this->error('No data');
        
        // Save calendar as a single object in a 'meta' or 'calendar' collection
        // For simplicity, we'll store it as items in 'calendar' collection
        foreach ($input as $item) {
            $this->db->saveItem('calendar', $item);
        }
        $this->success();
    }

    public function fetchTMDB() {
        if (!defined('TMDB_API_KEY') || TMDB_API_KEY === 'YOUR_TMDB_API_KEY_HERE') {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Lütfen public/api/config.php dosyasına geçerli bir TMDB_API_KEY girin.']);
            return;
        }

        $query = $_GET['query'] ?? '';
        $type = $_GET['type'] ?? 'search'; // search or get
        $tmdbId = $_GET['id'] ?? '';
        $mediaType = $_GET['media_type'] ?? 'tv'; // tv or movie or person
        
        $url = "";
        if ($type === 'get') {
            $url = "https://api.themoviedb.org/3/{$mediaType}/{$tmdbId}?api_key=" . TMDB_API_KEY . "&language=tr-TR&append_to_response=credits,images,videos";
        } else {
            if (!$query) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'No query provided']);
                return;
            }
            $url = "https://api.themoviedb.org/3/search/multi?api_key=" . TMDB_API_KEY . "&language=tr-TR&query=" . urlencode($query);
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        header('Content-Type: application/json');
        
        if ($httpCode === 200 && $response) {
            echo $response;
        } else {
            echo json_encode(['success' => false, 'message' => 'TMDB API error: ' . $httpCode, 'raw' => $response]);
        }
    }
}
