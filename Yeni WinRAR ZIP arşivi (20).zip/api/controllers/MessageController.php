<?php

require_once __DIR__ . '/../core/BaseController.php';

class MessageController extends BaseController {
    private $messagesDir;

    public function __construct() {
        parent::__construct();
    }

    public function list() {
        $userId = $_GET['userId'] ?? null;
        if (!$userId) return $this->error('User ID required');

        $allMessages = $this->db->getCollection('messages');
        
        // Filter for user (sent or received)
        $userMessages = array_filter($allMessages, function($m) use ($userId) {
            return ($m['from'] ?? '') === $userId || ($m['to'] ?? '') === $userId;
        });

        // Sort by time desc
        usort($userMessages, function($a, $b) {
            return ($b['timestamp'] ?? 0) - ($a['timestamp'] ?? 0);
        });

        $this->success(['messages' => array_values($userMessages)]);
    }

    public function send() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!isset($input['from']) || !isset($input['to']) || !isset($input['text'])) {
            return $this->error('Missing fields');
        }

        $newMessage = [
            'id' => uniqid('msg_'),
            'from' => $input['from'],
            'to' => $input['to'],
            'text' => $input['text'],
            'timestamp' => time() * 1000,
            'read' => false
        ];

        if ($this->db->saveItem('messages', $newMessage)) {
            $this->success(['message' => $newMessage]);
        } else {
            $this->error('Failed to send message');
        }
    }

    public function markRead() {
        $input = json_decode(file_get_contents('php://input'), true);
        $msgId = $input['id'] ?? null;
        $userId = $input['userId'] ?? null;

        if (!$msgId || !$userId) return $this->error('Missing fields');

        $msg = $this->db->getItemById('messages', $msgId);
        if ($msg && ($msg['to'] ?? '') === $userId) {
            $msg['read'] = true;
            $this->db->saveItem('messages', $msg);
        }
        $this->success();
    }

    public function markConversationRead() {
        $input = json_decode(file_get_contents('php://input'), true);
        $fromId = $input['fromId'] ?? null;
        $toId = $input['toId'] ?? null;

        if (!$fromId || !$toId) return $this->error('Missing fields');

        $allMessages = $this->db->getCollection('messages');
        foreach ($allMessages as $msg) {
            if (($msg['from'] ?? '') === $fromId && ($msg['to'] ?? '') === $toId && !($msg['read'] ?? false)) {
                $msg['read'] = true;
                $this->db->saveItem('messages', $msg);
            }
        }
        $this->success();
    }
}
