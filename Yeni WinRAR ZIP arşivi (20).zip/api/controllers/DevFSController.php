<?php
/**
 * DRAMICBOX - DEVELOPMENT FILE SYSTEM CONTROLLER
 * High-risk administrative tool for code management.
 */

require_once __DIR__ . '/../core/BaseController.php';

class DevFSController extends BaseController {

    private $rootPath;

    public function __construct() {
        parent::__construct();
        // Root is the public folder
        $this->rootPath = realpath(__DIR__ . '/../../../');
    }

    public function handle($action) {
        if (!$this->isAdmin()) {
            $this->error('Sadece Admin veya Teknik ekip erişebilir.');
        }

        switch ($action) {
            case 'list': $this->listFiles(); break;
            case 'read': $this->readFile(); break;
            case 'write': $this->writeFile(); break;
            case 'create': $this->createFile(); break;
            case 'delete': $this->deleteFile(); break;
            default: $this->error('İşlem geçersiz.');
        }
    }

    private function listFiles() {
        $path = $_GET['path'] ?? '';
        $fullPath = realpath($this->rootPath . '/' . $path);

        if (!$fullPath || strpos($fullPath, $this->rootPath) !== 0) {
            $this->error('Geçersiz yol.');
        }

        $items = [];
        $files = scandir($fullPath);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            
            $itemPath = $fullPath . '/' . $file;
            $items[] = [
                'name' => $file,
                'type' => is_dir($itemPath) ? 'dir' : 'file',
                'size' => is_file($itemPath) ? filesize($itemPath) : 0,
                'modified' => date('Y-m-d H:i:s', filemtime($itemPath))
            ];
        }

        $this->success($items);
    }

    private function readFile() {
        $path = $_GET['path'] ?? '';
        $fullPath = realpath($this->rootPath . '/' . $path);

        if (!$fullPath || !is_file($fullPath) || strpos($fullPath, $this->rootPath) !== 0) {
            $this->error('Dosya bulunamadı.');
        }

        $content = file_get_contents($fullPath);
        $this->success(['content' => $content, 'path' => $path]);
    }

    private function writeFile() {
        $data = json_decode(file_get_contents('php://input'), true);
        $path = $data['path'] ?? '';
        $content = $data['content'] ?? '';
        
        $fullPath = realpath($this->rootPath . '/' . $path);

        if (!$fullPath || !is_file($fullPath) || strpos($fullPath, $this->rootPath) !== 0) {
            $this->error('Dosya yazılamaz.');
        }

        if (file_put_contents($fullPath, $content) !== false) {
            $this->success(['message' => 'Dosya başarıyla kaydedildi.']);
        } else {
            $this->error('Dosya kaydedilemedi.');
        }
    }

    private function createFile() {
        $data = json_decode(file_get_contents('php://input'), true);
        $path = $data['path'] ?? '';
        $name = $data['name'] ?? '';
        $isDir = $data['isDir'] ?? false;

        $targetPath = $this->rootPath . '/' . $path . '/' . $name;
        
        if (file_exists($targetPath)) $this->error('Zaten mevcut.');

        if ($isDir) {
            if (mkdir($targetPath, 0755, true)) $this->success(['message' => 'Klasör oluşturuldu.']);
            else $this->error('Klasör oluşturulamadı.');
        } else {
            if (file_put_contents($targetPath, '') !== false) $this->success(['message' => 'Dosya oluşturuldu.']);
            else $this->error('Dosya oluşturulamadı.');
        }
    }

    private function deleteFile() {
        $path = $_GET['path'] ?? '';
        $fullPath = realpath($this->rootPath . '/' . $path);

        if (!$fullPath || strpos($fullPath, $this->rootPath) !== 0) {
            $this->error('Geçersiz yol.');
        }

        if (is_dir($fullPath)) {
            // Be very careful with recursive deletes, maybe just allow empty dirs for now
            if (rmdir($fullPath)) $this->success(['message' => 'Klasör silindi.']);
            else $this->error('Klasör silinemedi (boş olmayabilir).');
        } else {
            if (unlink($fullPath)) $this->success(['message' => 'Dosya silindi.']);
            else $this->error('Dosya silinemedi.');
        }
    }
}
