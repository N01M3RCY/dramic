<?php

require_once __DIR__ . '/../core/BaseController.php';
require_once __DIR__ . '/../core/Database.php';

class BlogController extends BaseController {

    public function __construct() {
        parent::__construct();
    }

    public function handle($action) {
        switch($action) {
            case 'blog-list': $this->list(); break;
            case 'blog-get': $this->get(); break;
            case 'blog-save': $this->save(); break;
            case 'blog-delete': $this->delete(); break;
            case 'blog-update-status': $this->updateStatus(); break;
            case 'blog-list-all': $this->listAll(); break;
            case 'upload-video': $this->uploadVideo(); break;
            default: $this->error('Unknown blog action');
        }
    }

    public function list() {
        $posts = $this->db->getCollection('blogPosts');
        $this->success(['posts' => $posts]);
    }

    public function get() {
        $id = $_GET['id'] ?? null;
        if (!$id) return $this->error('ID eksik');

        $post = $this->db->getItemById('blogPosts', $id);
        if ($post) {
            $this->success(['post' => $post]);
        } else {
            $this->error('Yazı bulunamadı');
        }
    }

    public function save() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input || !isset($input['title'])) return $this->error('Geçersiz veri');

        $id = $input['id'] ?? 'blog-' . uniqid();
        $post = $this->db->getItemById('blogPosts', $id);
        $isNew = false;

        if (!$post) {
            $isNew = true;
            $post = [
                'id' => $id,
                'date' => date('Y-m-d H:i:s'),
                'createdAt' => date('Y-m-d H:i:s'),
                'views' => 0,
                'likes' => 0
            ];
        }

        $post = array_merge($post, $input);
        $post['updatedAt'] = date('Y-m-d H:i:s');

        if ($this->db->saveItem('blogPosts', $post)) {
            $this->success(['message' => 'Yazı kaydedildi', 'id' => $post['id']]);
        } else {
            $this->error('Kaydetme hatası');
        }
    }

    public function delete() {
        $id = $_GET['id'] ?? null;
        if (!$id) return $this->error('ID eksik');

        if ($this->db->deleteFromCollection('blogPosts', $id)) {
            $this->success(['message' => 'Yazı silindi']);
        } else {
            $this->error('Yazı bulunamadı veya silinemedi');
        }
    }

    public function listAll() {
        $this->list();
    }

    public function updateStatus() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!isset($input['postId']) || !isset($input['status'])) return $this->error('Eksik veri');

        $post = $this->db->getItemById('blogPosts', $input['postId']);
        if ($post) {
            $post['approvalStatus'] = $input['status'];
            $post['updatedAt'] = date('Y-m-d H:i:s');
            if ($this->db->saveItem('blogPosts', $post)) {
                $this->success(['message' => 'Durum güncellendi']);
            } else {
                $this->error('Veritabanı kayıt hatası');
            }
        } else {
            $this->error('Yazı bulunamadı');
        }
    }

    public function uploadVideo() {
        $this->error('Video yükleme henüz aktif değil');
    }
}
