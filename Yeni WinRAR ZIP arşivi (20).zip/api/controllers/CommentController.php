<?php

require_once __DIR__ . '/../core/BaseController.php';

class CommentController extends BaseController {
    
    // POST Comment (or Reply)
    public function submit() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $user = $_SESSION['user_id'] ?? null;
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        $seriesId = $input['seriesId'] ?? null;
        $episodeIdx = $input['episodeIndex'] ?? 0;
        $text = $input['text'] ?? '';
        $parentId = $input['parentId'] ?? null; // For threading
        $username = $input['username'] ?? 'Anonim'; // Fallback
        
        if (!$seriesId || !$text) $this->error('Missing data');

        require_once __DIR__ . '/../core/FilterService.php';

        $userObj = null;
        if ($user) {
            $userObj = $this->db->getItemById('users', $user);
            if ($userObj) {
                $banMessage = FilterService::checkBanStatus($userObj);
                if ($banMessage) {
                    return $this->error($banMessage, 403);
                }
            }
        }

        if (!FilterService::isClean($text)) {
            $msg = FilterService::handleViolation($user, $this->db);
            return $this->error($msg, 403);
        }

        $commentId = uniqid('cmt_');
        $newComment = [
            'id' => $commentId,
            'seriesId' => $seriesId,
            'userId' => $user,
            'username' => $username,
            'text' => htmlspecialchars($text),
            'timestamp' => floor(microtime(true) * 1000),
            'episodeIndex' => (int)$episodeIdx,
            'parentId' => $parentId,
            'likes' => 0,
            'replies' => []
        ];

        // Save as individual file
        $collection = ($episodeIdx > 0) ? 'episodeComments' : 'comments';
        $success = $this->db->saveItem($collection, $newComment);

        if ($success) {
            $this->success(['comment' => $newComment]);
        } else {
            $this->error('Failed to save comment');
        }
    }

    // LIST Comments (Nested)
    public function list() {
        $seriesId = $_GET['seriesId'] ?? null;
        $episodeIdx = $_GET['episodeIndex'] ?? null;

        if (!$seriesId) $this->error('Missing seriesId');
        
        // Load from individual files
        $collection = ($episodeIdx > 0) ? 'episodeComments' : 'comments';
        $allComments = $this->db->getCollection($collection);
        
        // Filter by Series and Episode
        $filtered = array_filter($allComments, function($c) use ($seriesId, $episodeIdx) {
            if ($c['seriesId'] != $seriesId) return false;
            if ($episodeIdx !== null && isset($c['episodeIndex']) && $c['episodeIndex'] != $episodeIdx) return false;
            return true;
        });

        // Build Tree
        $nested = [];
        $childrenMap = [];
        foreach ($filtered as $c) {
            $pid = $c['parentId'] ?? null;
            if ($pid) {
                $childrenMap[$pid][] = $c;
            }
        }
        
        foreach ($filtered as $c) {
            if (empty($c['parentId'])) {
                $c['replies'] = $this->getReplies($c['id'], $childrenMap);
                $nested[] = $c;
            }
        }

        // Sort by timestamp (newest first for root)
        usort($nested, function($a, $b) {
            return $b['timestamp'] - $a['timestamp'];
        });

        $this->success(['comments' => $nested]);
    }

    // VOTE on Comment
    public function vote() {
        $input = json_decode(file_get_contents('php://input'), true);
        $commentId = $input['commentId'] ?? null;
        $voteType = $input['type'] ?? 'like'; // like or dislike
        $episodeIdx = $input['episodeIndex'] ?? 0;

        if (!$commentId) $this->error('Missing data');

        $collection = ($episodeIdx > 0) ? 'episodeComments' : 'comments';
        $item = $this->db->getItemById($collection, $commentId);
        
        if (!$item) $this->error('Comment not found');

        if ($voteType === 'like') {
            $item['likes'] = ($item['likes'] ?? 0) + 1;
        } else {
            $item['likes'] = ($item['likes'] ?? 0) - 1;
        }

        $success = $this->db->saveItem($collection, $item);
        if ($success) {
            $this->success(['status' => 'ok', 'likes' => $item['likes']]);
        } else {
            $this->error('Failed to update vote');
        }
    }

    // DELETE Comment
    public function delete() {
        $this->checkAdmin(); 
        
        $input = json_decode(file_get_contents('php://input'), true);
        $commentId = $input['commentId'] ?? $_GET['commentId'] ?? null;
        $episodeIdx = $input['episodeIndex'] ?? $_GET['episodeIndex'] ?? 0;

        if (!$commentId) $this->error('Missing data');

        $collection = ($episodeIdx > 0) ? 'episodeComments' : 'comments';
        $success = $this->db->deleteFromCollection($collection, $commentId);

        if ($success) {
            $this->success(['message' => 'Comment deleted']);
        } else {
            $this->error('Failed to delete comment');
        }
    }

    private function getReplies($parentId, $childrenMap) {
        if (!isset($childrenMap[$parentId])) return [];
        $replies = $childrenMap[$parentId];
        
        foreach ($replies as &$r) {
            $r['replies'] = $this->getReplies($r['id'], $childrenMap);
        }
        
        // Sort replies (oldest first usually for threads)
        usort($replies, function($a, $b) {
            return $a['timestamp'] - $b['timestamp'];
        });
        
        return $replies;
    }
}

