<?php

require_once __DIR__ . '/../core/BaseController.php';
require_once __DIR__ . '/../core/Logger.php';

class LogController extends BaseController {
    
    public function handle($action) {
        switch($action) {
            case 'log-list': $this->list(); break;
            case 'log-user-detail': $this->userActivity(); break;
            case 'log-export': $this->export(); break;
            case 'log-create': $this->create(); break;
            default: $this->error('Unknown log action');
        }
    }
    
    public function list() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $this->verifyAdmin();

        $logger = new Logger();
        $logs = $logger->getLogs(null, 500); // Newest 500 logs
        
        $this->success(['logs' => $logs]);
    }

    public function export() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $this->verifyAdmin();

        $logger = new Logger();
        $logs = $logger->getLogs(null, 2000);

        // Convert to CSV
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=logs_' . date('Y-m-d') . '.csv');
        
        $output = fopen('php://output', 'w');
        
        // Add BOM for Excel UTF-8 compatibility
        fputs($output, "\xEF\xBB\xBF");

        // Headers
        fputcsv($output, ['ID', 'Tarih', 'Kullanıcı', 'Eylem', 'Detaylar', 'IP', 'User Agent']);

        foreach ($logs as $log) {
            fputcsv($output, [
                $log['id'],
                $log['date'],
                $log['username'] . ($log['userId'] ? " ({$log['userId']})" : ''),
                $log['action'],
                is_string($log['details']) ? $log['details'] : json_encode($log['details'], JSON_UNESCAPED_UNICODE),
                $log['ip'],
                $log['userAgent']
            ]);
        }
        
        fclose($output);
        exit;
    }

    public function create() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? 'Unknown';
        $details = $input['details'] ?? [];
        $userId = $_SESSION['user_id'] ?? ($input['userId'] ?? null);
        $username = $_SESSION['username'] ?? ($input['username'] ?? 'System');

        $logger = new Logger();
        $logger->log($action, $userId, $username, $details);

        $this->success(['message' => 'Logged']);
    }

    public function userActivity() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $this->verifyAdmin();

        $userId = $_GET['userId'] ?? null;
        if (!$userId) $this->error('User ID required');

        // Search in MySQL logs table using JSON logic or simple fetch all and filter
        // For performance in MySQL, we use the 'logs' table mapping
        $allLogs = $this->db->getCollection('logs', 2000);
        $userLogs = array_filter($allLogs, function($l) use ($userId) {
            return (string)($l['userId'] ?? '') === (string)$userId;
        });
        $userLogs = array_slice(array_values($userLogs), 0, 50);

        // 2. Messages
        $userMessages = $this->db->getCollection('messages');
        $userMessages = array_filter($userMessages, function($m) use ($userId) {
            return (string)$m['from'] === (string)$userId || (string)$m['to'] === (string)$userId;
        });

        // 3. Comments
        $userComments = $this->fetchUserComments($userId);

        // 4. Profile Activity
        $user = $this->db->getItemById('users', $userId);
        $profileActivities = !empty($user['activityLog']) ? $user['activityLog'] : [];
        $avatarHistory = !empty($user['avatarHistory']) ? $user['avatarHistory'] : [];

        $this->success([
            'logs' => $userLogs,
            'messages' => array_slice(array_values($userMessages), 0, 50),
            'comments' => $userComments,
            'profileActivities' => $profileActivities,
            'avatarHistory' => $avatarHistory,
            'lastSeen' => !empty($userLogs) ? $userLogs[0]['date'] : 'Unknown'
        ]);
    }


    private function fetchUserComments($userId) {
        $sql = "(SELECT * FROM comments WHERE userId = :u1) UNION (SELECT * FROM episodeComments WHERE userId = :u2) ORDER BY timestamp DESC LIMIT 50";
        return $this->db->fetchAll($sql, ['u1' => $userId, 'u2' => $userId]);
    }

    private function verifyAdmin() {
        if (!isset($_SESSION['user_role'])) {
            $this->error('Unauthorized', 401);
        }

        $role = $_SESSION['user_role'];
        $username = $_SESSION['username'] ?? '';
        
        // Allowed roles: admin, technical
        if ($role === 'admin' || $role === 'technical' || strtolower($username) === 'admin') {
            return;
        }

        // Also check badges if role isn't explicitly set
        // Usually role is synced from DB on login
        $this->error('Admin or Technical access required', 403);
    }
}
