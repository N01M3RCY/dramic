<?php
// ============================================
// DRAMICBOX - SOCIAL CONTROLLER
// Handles social posts, likes, comments
// ============================================

require_once __DIR__ . '/../core/BaseController.php';

class SocialController extends BaseController
{

    public function submitPost()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->error('Invalid method');
            return;
        }

        $userId = $this->getUserId();
        // Fallback for ID in request body if session is not active
        if (!$userId) {
            $postData = json_decode(file_get_contents('php://input'), true);
            $userId = $postData['userId'] ?? $postData['authorId'] ?? null;
            // Reparse the body if we read it
            $_POST_DATA = $postData;
        } else {
            $_POST_DATA = json_decode(file_get_contents('php://input'), true);
        }

        if (!$userId)
            return $this->error('Login required to post');
        $postData = $_POST_DATA;
        if (!$postData)
            return $this->error('No data');

        require_once __DIR__ . '/../core/FilterService.php';

        $userObj = $this->db->getItemById('users', $userId);
        if ($userObj) {
            $banMessage = FilterService::checkBanStatus($userObj);
            if ($banMessage) {
                return $this->error($banMessage, 403);
            }
        }

        $textToCheck = $postData['text'] ?? '';
        if (!FilterService::isClean($textToCheck)) {
            $msg = FilterService::handleViolation($userId, $this->db);
            return $this->error($msg, 403);
        }

        $isBlog = $postData['isBlog'] ?? false;
        $status = 'active'; // Everyone sees posts immediately
        $postData['userId'] = $userId;
        if (!isset($postData['createdAt']))
            $postData['createdAt'] = date('Y-m-d\TH:i:s.v\Z');
        if (!isset($postData['id']))
            $postData['id'] = 'post-' . time() . '-' . rand(100, 999);
        if (!isset($postData['likes']))
            $postData['likes'] = [];
        if (!isset($postData['reactions']))
            $postData['reactions'] = [];
        if (!isset($postData['comments']))
            $postData['comments'] = [];
        $postData['status'] = $status;

        $collection = $isBlog ? 'blogPosts' : 'socialPosts';

        if ($this->db->saveItem($collection, $postData)) {
            if ($status === 'active') {
                $this->logActivity('new_post', [
                    'postId' => $postData['id'],
                    'text' => $postData['text'] ?? ''
                ]);
            }
            $this->success(['post' => $postData, 'status' => $status]);
        } else {
            $this->error('Failed to save post');
        }
    }

    public function moderate()
    {
        $userId = $this->getUserId();
        // Permission check
        $user = $this->db->getItemById('users', $userId);
        if (!$user || !in_array($user['role'], ['admin', 'moderator'])) {
            return $this->error('Access denied');
        }

        $postId = $_GET['postId'] ?? null;
        $action = $_GET['modAction'] ?? null; // 'approve', 'reject'

        if (!$postId || !$action)
            return $this->error('Missing parameters');

        $post = $this->db->getItemById('socialPosts', $postId);
        if (!$post)
            return $this->error('Post not found');

        if ($action === 'approve') {
            $post['status'] = 'active';
            $this->db->saveItem('socialPosts', $post);
            $this->success(['message' => 'Post approved']);
        } else if ($action === 'reject') {
            // rejection is permanent deletion for now as in JS implementation
            $this->db->deleteFromCollection('socialPosts', $postId);
            $this->success(['message' => 'Post rejected']);
        } else {
            $this->error('Invalid action');
        }
    }

    public function deletePost()
    {
        $userId = $this->getUserId();
        $postId = $_GET['postId'] ?? null;

        if (!$postId)
            return $this->error('Missing postId');

        $post = $this->db->getItemById('socialPosts', $postId);
        if (!$post)
            return $this->error('Post not found');

        // Check if user is owner or admin/mod
        $user = $this->db->getItemById('users', $userId);
        $isAdminMod = $user && in_array($user['role'], ['admin', 'moderator']);
        $isOwner = $post['userId'] === $userId;

        if (!$isOwner && !$isAdminMod) {
            return $this->error('Permission denied');
        }

        $result = $this->db->deleteFromCollection('socialPosts', $postId);
        if ($result) {
            $this->success(['message' => 'Post deleted']);
        } else {
            $this->error('Deletion failed');
        }
    }

    public function toggleLike()
    {
        $userId = $this->getUserId();
        if (!$userId)
            return $this->error('Login required');

        $postId = $_GET['postId'] ?? null;
        if (!$postId)
            return $this->error('Missing postId');

        $post = $this->db->getItemById('socialPosts', $postId);
        if (!$post) {
            $post = $this->db->getItemById('blogPosts', $postId);
            $type = 'blogPosts';
        } else {
            $type = 'socialPosts';
        }

        if ($post) {
            if (!isset($post['likes']))
                $post['likes'] = [];
            $idx = array_search($userId, $post['likes']);
            if ($idx !== false) {
                array_splice($post['likes'], $idx, 1);
            } else {
                $post['likes'][] = $userId;
            }
            $this->db->saveItem($type, $post);
            $this->success();
        } else {
            $this->error('Post not found');
        }
    }

    public function toggleReaction()
    {
        $userId = $this->getUserId();
        if (!$userId)
            return $this->error('Login required');

        $postId = $_GET['postId'] ?? null;
        $emoji = $_GET['emoji'] ?? '';
        if (!$postId || !$emoji)
            return $this->error('Missing parameters');

        $post = $this->db->getItemById('socialPosts', $postId);
        $type = 'socialPosts';
        if (!$post) {
            $post = $this->db->getItemById('blogPosts', $postId);
            $type = 'blogPosts';
        }

        if ($post) {
            if (!isset($post['reactions']))
                $post['reactions'] = [];
            if (!isset($post['reactions'][$emoji]))
                $post['reactions'][$emoji] = [];

            $idx = array_search($userId, $post['reactions'][$emoji]);
            if ($idx !== false) {
                array_splice($post['reactions'][$emoji], $idx, 1);
            } else {
                foreach ($post['reactions'] as $e => &$voters) {
                    $oldIdx = array_search($userId, $voters);
                    if ($oldIdx !== false)
                        array_splice($voters, $oldIdx, 1);
                }
                $post['reactions'][$emoji][] = $userId;
            }
            $this->db->saveItem($type, $post);
            $this->success();
        } else {
            $this->error('Post not found');
        }
    }

    public function addComment()
    {
        $userId = $this->getUserId();
        if (!$userId)
            return $this->error('Login required');

        $postId = $_GET['postId'] ?? null;
        $body = json_decode(file_get_contents('php://input'), true);
        $text = $body['text'] ?? '';
        $parentId = $body['parentId'] ?? null;

        if (!$postId || !$text)
            return $this->error('Missing data');

        require_once __DIR__ . '/../core/FilterService.php';

        $userObj = $this->db->getItemById('users', $userId);
        if ($userObj) {
            $banMessage = FilterService::checkBanStatus($userObj);
            if ($banMessage) {
                return $this->error($banMessage, 403);
            }
        }

        if (!FilterService::isClean($text)) {
            $msg = FilterService::handleViolation($userId, $this->db);
            return $this->error($msg, 403);
        }

        $post = $this->db->getItemById('socialPosts', $postId);
        $type = 'socialPosts';
        if (!$post) {
            $post = $this->db->getItemById('blogPosts', $postId);
            $type = 'blogPosts';
        }

        if ($post) {
            if (!isset($post['comments']))
                $post['comments'] = [];
            $newComment = [
                'id' => 'cmt-' . time() . '-' . rand(100, 999),
                'userId' => $userId,
                'text' => $text,
                'parentId' => $parentId,
                'createdAt' => date('Y-m-d\TH:i:s.v\Z')
            ];
            $post['comments'][] = $newComment;

            if ($this->db->saveItem($type, $post)) {
                $this->logActivity('add_comment', [
                    'postId' => $postId,
                    'commentId' => $newComment['id']
                ]);
                $this->success(['comment' => $newComment]);
            } else {
                $this->error('Save failed');
            }
        } else {
            $this->error('Post not found');
        }
    }

    public function search()
    {
        $query = strtolower($_GET['q'] ?? '');
        $username = strtolower($_GET['user'] ?? '');
        $startDate = $_GET['start'] ?? null;
        $endDate = $_GET['end'] ?? null;
        $category = $_GET['category'] ?? null;

        // Use SQL for filtering social posts (much faster than PHP filtering)
        $table = 'social_posts';
        $sql = "SELECT data FROM $table WHERE 1=1";
        $params = [];

        if ($query) {
            $sql .= " AND LOWER(data) LIKE ?";
            $params[] = "%$query%";
        }

        if ($username) {
            $sql .= " AND LOWER(data) LIKE ?";
            $params[] = "%$username%";
        }

        if ($category) {
            $sql .= " AND data->'$.category' = ?";
            $params[] = $category;
        }

        $sql .= " ORDER BY created_at DESC LIMIT 100";

        $results = $this->db->fetchAll($sql, $params);
        $this->success(['posts' => $results]);
    }

    public function logActivityAction()
    {
        $body = json_decode(file_get_contents('php://input'), true);
        $type = $body['type'] ?? '';
        $data = $body['data'] ?? [];

        if (!$type)
            return $this->error('Type required');

        $activity = $this->logActivity($type, $data);
        $this->success(['activity' => $activity]);
    }

    public function uploadMedia()
    {
        require_once __DIR__ . '/../core/UploadHandler.php';
        $handler = new UploadHandler('social');
        $result = $handler->handle('media');
        echo json_encode($result);
    }
}
?>