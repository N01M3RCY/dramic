<?php

require_once __DIR__ . '/../core/BaseController.php';
require_once __DIR__ . '/../core/Database.php';

class ApprovalController extends BaseController {
    public function __construct() {
        parent::__construct();
    }

    public function handle($action) {
        switch($action) {
            case 'admin-approvals-list': $this->listPending(); break;
            case 'admin-approve-item': $this->approve(); break;
            case 'admin-reject-item': $this->reject(); break;
            case 'admin-submit-approval': $this->submit(); break;
            default: $this->error('Unknown approval action');
        }
    }

    public function submit() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) $this->error('No data');
        
        $item = [
            'id' => uniqid('app_'),
            'type' => $input['type'] ?? 'unknown',
            'data' => $input['data'] ?? [],
            'submittedBy' => $input['userId'] ?? 'anon',
            'submittedByUsername' => $input['username'] ?? 'Anonymous',
            'submittedAt' => date('c'),
            'status' => 'pending'
        ];

        if ($item['type'] === 'source') {
            $item['seriesId'] = $input['data']['seriesId'] ?? '';
            $item['seriesTitle'] = $input['data']['seriesTitle'] ?? '';
            $item['episodeNumber'] = $input['data']['episodeNumber'] ?? '';
            $item['sourceName'] = $input['data']['name'] ?? 'Source';
        }

        if ($this->db->saveItem('approvals', $item)) {
            $this->success(['message' => 'Submitted for approval']);
        } else {
            $this->error('Failed to submit');
        }
    }

    public function listPending() {
        $this->checkAdmin();
        $approvals = $this->db->getCollection('approvals');
        $this->success(['items' => $approvals]);
    }

    public function approve() {
        $this->checkAdmin();
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        
        if (!$id) $this->error('ID required');

        $approval = $this->db->getItemById('approvals', $id);
        if (!$approval) $this->error('Approval not found');

        switch ($approval['type']) {
            case 'source': $this->approveSource($approval['data']); break;
            case 'blog': $this->approveBlog($approval['data']); break;
            case 'short': $this->approveShort($approval['data']); break;
            case 'webtoon': $this->approveWebtoon($approval['data']); break;
        }

        $this->db->deleteFromCollection('approvals', $id);
        $this->success(['message' => 'Approved']);
    }

    public function reject() {
        $this->checkAdmin();
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        
        if (!$id) $this->error('ID required');
        $this->db->deleteFromCollection('approvals', $id);
        $this->success(['message' => 'Rejected']);
    }

    private function approveSource($data) {
        $seriesId = $data['seriesId'];
        $episodeNum = $data['episodeNumber'];
        
        $series = $this->db->getItemById('series', $seriesId);
        if (!$series) $this->error('Series not found');

        $found = false;
        if (isset($series['seasons'])) {
            foreach ($series['seasons'] as &$season) {
                if (isset($season['episodes'])) {
                    foreach ($season['episodes'] as &$ep) {
                        if ($ep['number'] == $episodeNum) {
                            if (!isset($ep['sources'])) $ep['sources'] = [];
                            $ep['sources'][] = $data['sourceObject'];
                            $found = true;
                            break 2;
                        }
                    }
                }
            }
        }
        
        if ($found) {
            $this->db->saveItem('series', $series);
        }
    }

    private function approveBlog($data) {
        $data['approvalStatus'] = 'published';
        $this->db->saveItem('blogPosts', $data);
    }

    private function approveShort($data) {
        $shortId = $data['shortId'];
        $episodeData = $data['episode'];
        
        $short = $this->db->getItemById('shorts', $shortId);
        if ($short) {
            if (!isset($short['episodes'])) $short['episodes'] = [];
            $exists = false;
            foreach ($short['episodes'] as &$ep) {
                if ($ep['number'] == $episodeData['number']) {
                    $ep = $episodeData; $exists = true; break;
                }
            }
            if (!$exists) $short['episodes'][] = $episodeData;
            $short['totalEpisodes'] = count($short['episodes']);
            $this->db->saveItem('shorts', $short);
        }
    }

    private function approveWebtoon($data) {
        $this->db->saveItem('webtoons', $data);
    }
}
