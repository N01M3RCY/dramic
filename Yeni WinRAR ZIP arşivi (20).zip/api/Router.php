<?php

// ============================================
// DRAMICBOX - CENTRAL ROUTER
// Maps all API actions to their respective controllers
// ============================================

// 1. CORE & CONFIG
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/core/Database.php';
require_once __DIR__ . '/core/BaseController.php';
require_once __DIR__ . '/core/RateLimiter.php';

// 2. ESSENTIAL CONTROLLERS
require_once __DIR__ . '/controllers/SeriesController.php';
require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/NotificationController.php';
require_once __DIR__ . '/controllers/SocialStreamController.php';
require_once __DIR__ . '/controllers/SocialController.php';

// 3. OPTIONAL CONTROLLERS
require_once __DIR__ . '/controllers/SearchController.php';
require_once __DIR__ . '/controllers/CommentController.php';
require_once __DIR__ . '/controllers/BlogController.php';
require_once __DIR__ . '/controllers/LogController.php';
require_once __DIR__ . '/controllers/RequestController.php';
require_once __DIR__ . '/controllers/ReportController.php';
require_once __DIR__ . '/controllers/FAQController.php';
require_once __DIR__ . '/controllers/CryptologyController.php';
require_once __DIR__ . '/controllers/ApprovalController.php';
require_once __DIR__ . '/controllers/MessageController.php';
require_once __DIR__ . '/controllers/VideoStudioController.php';
require_once __DIR__ . '/controllers/ManagementController.php';
require_once __DIR__ . '/controllers/DevFSController.php';
require_once __DIR__ . '/controllers/LiveController.php';
require_once __DIR__ . '/controllers/GamificationController.php';

// 4. UTILITIES
if (file_exists(__DIR__ . '/encrypt-data.php')) {
    require_once __DIR__ . '/encrypt-data.php';
}

class Router
{
    private $limiter;

    public function __construct()
    {
        $this->limiter = new RateLimiter();
    }

    private function getUserId()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        return $_SESSION['user_id'] ?? $_SESSION['user']['id'] ?? null;
    }

    private function error($message, $code = 400)
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
        exit;
    }

    private function success($data = [])
    {
        header('Content-Type: application/json; charset=utf-8');
        $response = array_merge(['success' => true], $data);
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }

    private function checkAdmin()
    {
        if (session_status() === PHP_SESSION_NONE)
            session_start();
        $userRole = $_SESSION['user_role'] ?? $_SESSION['user']['role'] ?? 'guest';
        if ($userRole !== 'admin') {
            $this->error('Bu işlem için admin yetkisi gereklidir.', 403);
        }
        if (!isset($_SESSION['admin_verified']) || $_SESSION['admin_verified'] !== true) {
            $this->error('Lütfen önce e-posta adresinize gönderilen güvenlik kodunu doğrulayın.', 401);
        }
    }

    private function checkAdminSession()
    {
        if (session_status() === PHP_SESSION_NONE)
            session_start();
        $userRole = $_SESSION['user_role'] ?? $_SESSION['user']['role'] ?? 'guest';
        if (!in_array($userRole, ['admin', 'moderator', 'editor', 'translation_leader', 'editor_leader'])) {
            $this->error('Bu alan için yetkiniz bulunmamaktadır.', 403);
        }
        if (!isset($_SESSION['admin_verified']) || $_SESSION['admin_verified'] !== true) {
            $this->error('Lütfen önce e-posta adresinize gönderilen güvenlik kodunu doğrulayın.', 401);
        }
    }

    public function handleRequest()
    {
        $action = $_GET['action'] ?? null;
        $this->limiter->check($action);

        // Handle CORS
        if (isset($_SERVER['HTTP_ORIGIN'])) {
            header("Access-Control-Allow-Origin: " . $_SERVER['HTTP_ORIGIN']);
            header("Access-Control-Allow-Credentials: true");
        } else {
            header("Access-Control-Allow-Origin: *");
        }
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

        // Modular Routing System
        if ($this->handleCore($action)) return;
        if ($this->handleAuth($action)) return;
        if ($this->handleContent($action)) return;
        if ($this->handleSocial($action)) return;
        if ($this->handleAdmin($action)) return;
        if ($this->handleMarket($action)) return;
        if ($this->handleGamification($action)) return;

        $this->error('Geçersiz işlem: ' . $action, 404);
    }

    private function handleCore($action)
    {
        switch ($action) {
            case 'database-export':
                $this->checkAdmin();
                $db = new Database();
                echo json_encode($db->exportAll(), JSON_UNESCAPED_UNICODE);
                return true;
            case 'get-data':
                $collections = $_GET['collections'] ?? '';
                $collectionsArray = array_filter(explode(',', $collections));
                $db = new Database();
                $data = empty($collectionsArray) ? $db->exportAll() : $db->loadCollections($collectionsArray);
                $this->success(['data' => $data]);
                return true;
            case 'check-sync':
                $id = $_GET['id'] ?? '';
                $type = $_GET['type'] ?? 'series';
                $db = new Database();
                $collection = ($type === 'series') ? 'series' : (($type === 'webtoon') ? 'webtoons' : (($type === 'actors') ? 'actors' : 'series'));
                $item = $db->getItemById($collection, $id);
                $this->success(['exists' => ($item !== null)]);
                return true;
            case 'write':
                $this->handleWrite();
                return true;
            case 'sync-action':
                $this->handleSyncAction();
                return true;
            case 'sync-item':
                $this->handleSyncItem();
                return true;
            case 'global-stats':
                $this->handleGlobalStats();
                return true;
            case 'system-health':
                $this->handleSystemHealth();
                return true;
            case 'delete-item':
                $this->checkAdmin();
                $id = $_GET['id'] ?? null;
                $collection = $_GET['collection'] ?? null;
                if ($id && $collection) {
                    $db = new Database();
                    $this->success(['success' => $db->deleteItem($collection, $id)]);
                }
                $this->error('Eksik parametre.');
                return true;
            case 'live-action':
                (new LiveController())->handle($_GET['live_action'] ?? 'list');
                return true;
            case 'dev-fs':
                (new DevFSController())->handle($_GET['fs_action'] ?? 'list');
                return true;
        }
        return false;
    }

    private function handleAuth($action)
    {
        $authController = new AuthController();
        switch ($action) {
            case 'login': $authController->login(); return true;
            case 'register': $authController->register(); return true;
            case 'logout': $authController->logout(); return true;
            case 'check-session': $authController->checkSession(); return true;
            case 'user-update': $authController->updateUser(); return true;
            case 'send-verification': $authController->sendVerification(); return true;
            case 'verify-admin-2fa': $authController->verifyAdmin2FA(); return true;
            case 'admin-update-pin': $authController->updateAdminPIN(); return true;
            case 'auth-forgot': $authController->handleForgotPassword(); return true;
            case 'auth-reset': $authController->handleResetPassword(); return true;
            case 'verify-2fa': $authController->verify2fa(); return true;
            case 'send-login-otp': $authController->sendLoginOtp(); return true;
            case 'verify-login-otp': $authController->verifyLoginOtp(); return true;
            case 'approve-verification': $authController->approveVerification(); return true;
            case 'reject-verification': $authController->rejectVerification(); return true;
            case 'verify-account-magic-link': $authController->verifyAccountMagicLink(); return true;
            case 'admin-magic-verify':
            case 'verify-magic-link': $authController->verifyMagicLink(); return true;
            case 'ban-appeal': $authController->handleBanAppeal(); return true;
            case 'donate': $authController->handleDonation(); return true;
            case 'send-admin-otp': $authController->sendAdminOtp(); return true;
            case 'verify-admin-otp': $authController->verifyAdminOtp(); return true;
            case 'sync-session':
                if (session_status() === PHP_SESSION_NONE) session_start();
                $input = json_decode(file_get_contents('php://input'), true);
                if ($input) {
                    $_SESSION['user_id'] = $input['id'] ?? null;
                    $_SESSION['user_role'] = $input['role'] ?? 'user';
                    $_SESSION['user'] = $input;
                    $this->success();
                }
                $this->error('No data');
                return true;
        }
        return false;
    }

    private function handleContent($action)
    {
        switch ($action) {
            case 'read': (new SeriesController())->index(); return true;
            case 'add-series': (new SeriesController())->addSeries(); return true;
            case 'delete-series': (new SeriesController())->deleteSeries(); return true;
            case 'update-episode': (new SeriesController())->updateEpisode(); return true;
            case 'increment-view': (new SeriesController())->incrementView(); return true;
            case 'search': (new SearchController())->search(); return true;
            case 'notif-save-subscription': (new NotificationController())->saveSubscription(); return true;
            
            // Comments
            case 'comment-list': (new CommentController())->list(); return true;
            case 'comment-submit': (new CommentController())->submit(); return true;
            case 'comment-vote': (new CommentController())->vote(); return true;
            case 'comment-delete': (new CommentController())->delete(); return true;

            // Blog
            case 'blog-list': 
            case 'blog-get': 
            case 'blog-save': 
            case 'blog-delete': 
            case 'blog-update-status': 
            case 'blog-list-all': 
            case 'upload-video': (new BlogController())->handle($action); return true;

            // Actors
            case 'actor-get': $this->handleActorGet(); return true;
            case 'list-actors': $this->handleListActors(); return true;
            case 'actor-save': $this->handleActorSave(); return true;
            case 'actor-fan-action': $this->handleActorFanAction(); return true;

            // Requests & FAQs
            case 'req-list': 
            case 'req-add': 
            case 'req-vote': 
            case 'req-claim': (new RequestController())->handle($action); return true;
            case 'faq-list': 
            case 'faq-add': 
            case 'faq-update': 
            case 'faq-delete': (new FAQController())->handle($action); return true;
        }
        return false;
    }

    private function handleSocial($action)
    {
        switch ($action) {
            case 'social-post-submit':
            case 'social-sync-post': (new SocialController())->submitPost(); return true;
            case 'social-post-delete': (new SocialController())->deletePost(); return true;
            case 'social-post-like':
            case 'social-toggle-like': (new SocialController())->toggleLike(); return true;
            case 'social-post-comment':
            case 'social-add-comment': (new SocialController())->addComment(); return true;
            case 'social-get-posts': $this->handleSocialGetPosts(); return true;
            case 'social-moderate': (new SocialController())->moderate(); return true;
            case 'social-toggle-reaction': (new SocialController())->toggleReaction(); return true;
            case 'social-search': (new SocialController())->search(); return true;
            case 'social-log-activity': (new SocialController())->logActivityAction(); return true;
            case 'social-upload': (new SocialController())->uploadMedia(); return true;
            case 'social-stream': (new SocialStreamController())->handle('stream'); return true;
            case 'heartbeat':
            case 'social-heartbeat': (new SocialStreamController())->handle('heartbeat'); return true;
            case 'message-list': (new MessageController())->list(); return true;
            case 'message-send': (new MessageController())->send(); return true;
            case 'message-read': (new MessageController())->markConversationRead(); return true;
            case 'list-hashtags':
                $db = new Database();
                $data = $db->loadCollections(['hashtags']);
                $this->success(['hashtags' => $data['hashtags'] ?? []]);
                return true;
        }
        return false;
    }

    private function handleAdmin($action)
    {
        $this->checkAdminSession();
        switch ($action) {
            case 'admin-dashboard-stats': $this->handleAdminStats(); return true;
            case 'admin-approvals-list': case 'admin-approve-item': case 'admin-reject-item': case 'admin-submit-approval': 
                (new ApprovalController())->handle($action); return true;
            case 'log-list': case 'log-user-detail': case 'log-export': case 'log-create': 
                (new LogController())->handle($action); return true;
            case 'crypto-token': case 'crypto-verify': case 'crypto-decrypt': case 'crypto-encrypt': case 'crypto-analyze': case 'crypto-list': 
                (new CryptologyController())->handle($action); return true;
            case 'admin-block-ip': case 'admin-unblock-ip': case 'admin-list-blocked-ips': 
                $this->handleIPManagement($action); return true;
            case 'ticket-create': case 'ticket-list': case 'ticket-reply': case 'ticket-close':
            case 'announcement-save': case 'announcement-delete': case 'list-announcements': case 'list-tickets':
            case 'report-copyright': case 'journal-save': case 'journal-list': case 'journal-delete':
            case 'save-config': 
                (new ManagementController())->handle($action); return true;
            case 'rep-submit': case 'rep-list': case 'rep-resolve': 
                (new ReportController())->handle($action); return true;
        }
        return false;
    }

    private function handleMarket($action)
    {
        switch ($action) {
            case 'buy-coffee': $this->handleBuyCoffee(); return true;
            case 'convert-coffee': $this->handleConvertCoffee(); return true;
        }
        return false;
    }

    private function handleGamification($action)
    {
        $gamifController = new GamificationController();
        switch ($action) {
            case 'gamification-config': $gamifController->getGamificationConfig(); return true;
            case 'claim-tier-reward': $gamifController->claimTierReward(); return true;
            case 'open-chest': $gamifController->openChest(); return true;
            case 'sell-item': $gamifController->sellItem(); return true;
            case 'execute-trade': $gamifController->executeTrade(); return true;
            case 'save-calendar-schedule': $gamifController->saveCalendarSchedule(); return true;
            case 'delete-calendar-schedule': $gamifController->deleteCalendarSchedule(); return true;
        }
        return false;
    }

    // --- Helper Methods to reduce complexity ---

    private function handleWrite()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $userRole = $_SESSION['user_role'] ?? $_SESSION['user']['role'] ?? 'guest';
        $postData = json_decode(file_get_contents('php://input'), true);

        $publicCollections = ['socialPosts', 'comments', 'activities', 'friendRequests', 'users', 'customLists', 'watchParties', 'partyRooms', 'tickets', 'episodeComments'];

        require_once __DIR__ . '/core/FilterService.php';
        $currentUserId = $this->getUserId();
        
        // Ban Check for social collections
        if ($currentUserId) {
            $dbTemp = new Database();
            $userObj = $dbTemp->getItemById('users', $currentUserId);
            if ($userObj) {
                $banMessage = FilterService::checkBanStatus($userObj);
                if ($banMessage) {
                    foreach (['socialPosts', 'comments', 'episodeComments', 'blogPosts'] as $checkCol) {
                        if (!empty($postData[$checkCol])) {
                            $this->error($banMessage, 403);
                        }
                    }
                }
            }
        }

        // Profanity Check
        foreach ($postData as $key => $items) {
            if (in_array($key, ['socialPosts', 'comments', 'episodeComments', 'blogPosts'])) {
                foreach ($items as $item) {
                    $textToCheck = $item['text'] ?? $item['content'] ?? '';
                    if (!empty($textToCheck) && !FilterService::isClean($textToCheck)) {
                        $msg = FilterService::handleViolation($currentUserId, new Database());
                        $this->error($msg, 403);
                    }
                }
            }
        }

        if ($userRole === 'guest') {
            if (!isset($postData['adminCode']) || $postData['adminCode'] !== '202400') {
                $this->error('Giriş yapmanız gereklidir.', 403);
            }
        } else if ($userRole !== 'admin') {
            $currentUserId = $this->getUserId();
            foreach ($postData as $key => $items) {
                if (!in_array($key, $publicCollections)) {
                    $this->error("Yetkisiz koleksiyon: $key", 403);
                }
                
                // Extra security for users collection
                if ($key === 'users') {
                    foreach ($items as $u) {
                        if (isset($u['id']) && $u['id'] !== $currentUserId) {
                            $this->error("Sadece kendi profilinizi güncelleyebilirsiniz.", 403);
                        }
                    }
                }
            }
        }

        $db = new Database();
        $res = $db->saveData($postData);
        $this->success(['result' => $res]);
    }

    private function handleSyncItem()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $userRole = $_SESSION['user_role'] ?? $_SESSION['user']['role'] ?? 'guest';
        $postData = json_decode(file_get_contents('php://input'), true);

        $collection = $postData['collection'] ?? null;
        $item = $postData['item'] ?? null;

        if (!$collection || !$item) {
            $this->error('Eksik veri', 400);
        }

        $publicCollections = ['socialPosts', 'comments', 'activities', 'friendRequests', 'users', 'customLists', 'watchParties', 'partyRooms', 'tickets', 'episodeComments'];

        require_once __DIR__ . '/core/FilterService.php';
        $currentUserId = $this->getUserId();
        
        // Ban and Profanity Check
        if (in_array($collection, ['socialPosts', 'comments', 'episodeComments', 'blogPosts'])) {
            if ($currentUserId) {
                $dbTemp = new Database();
                $userObj = $dbTemp->getItemById('users', $currentUserId);
                if ($userObj) {
                    $banMessage = FilterService::checkBanStatus($userObj);
                    if ($banMessage) {
                        $this->error($banMessage, 403);
                    }
                }
            }

            $textToCheck = $item['text'] ?? $item['content'] ?? '';
            if (!empty($textToCheck) && !FilterService::isClean($textToCheck)) {
                $msg = FilterService::handleViolation($currentUserId, new Database());
                $this->error($msg, 403);
            }
        }

        if ($userRole === 'guest') {
            $this->error('Giriş yapmanız gereklidir.', 403);
        } else if ($userRole !== 'admin') {
            if (!in_array($collection, $publicCollections)) {
                $this->error("Yetkisiz koleksiyon: $collection", 403);
            }
            if ($collection === 'users' && isset($item['id']) && $item['id'] !== $currentUserId) {
                $this->error("Sadece kendi profilinizi güncelleyebilirsiniz.", 403);
            }
        }

        $db = new Database();
        $res = $db->saveItem($collection, $item);
        $this->success(['result' => $res]);
    }

    private function handleSyncAction()
    {
        $actionType = $_GET['type'] ?? '';
        $data = json_decode(file_get_contents('php://input'), true);
        $db = new Database();

        // Delegate social actions to handleSocial
        if (strpos($actionType, 'social-') === 0) {
            // Put data into $_GET or $_POST for the controllers
            foreach ($data as $k => $v) {
                $_GET[$k] = $v;
                $_POST[$k] = $v;
            }
            $this->handleSocial($actionType);
            return;
        }

        if ($actionType === 'comment-submit') {
            require_once __DIR__ . '/core/FilterService.php';
            $userId = $_SESSION['user_id'] ?? $_SESSION['user']['id'] ?? null;
            $userObj = $userId ? $db->getItemById('users', $userId) : null;
            if ($userObj) {
                $banMessage = FilterService::checkBanStatus($userObj);
                if ($banMessage) {
                    return $this->error($banMessage, 403);
                }
            }
            if (isset($data['text']) && !FilterService::isClean($data['text'])) {
                $msg = FilterService::handleViolation($userId, $db);
                return $this->error($msg, 403);
            }

            $seriesId = $data['seriesId'] ?? $data['id'] ?? null;
            $collection = null;
            $item = null;
            
            foreach (['series', 'webtoons', 'blogPosts', 'socialPosts', 'actors'] as $col) {
                $item = $db->getItemById($col, $seriesId);
                if ($item) {
                    $collection = $col;
                    break;
                }
            }
            
            if ($item) {
                if (!isset($item['comments'])) $item['comments'] = [];
                $newComment = [
                    'id' => 'cmt-' . time() . '-' . rand(100, 999),
                    'userId' => $_SESSION['user_id'] ?? $_SESSION['user']['id'] ?? 'guest',
                    'text' => $data['text'],
                    'createdAt' => Date('c'),
                    'upvotes' => 0, 'downvotes' => 0, 'voters' => []
                ];
                if (isset($data['parentId'])) {
                    // It's a reply (frontend handles nesting but we'll save it to the parent)
                    // Currently, frontend handles the push, we're just accepting it if synced, wait, 
                    // Actually, if parentId is present, we shouldn't add to the top level comments array.
                    // But in social-feed.js and enhanced-comments.js, the frontend modifies State.data directly and calls db.save() too.
                    // Wait, frontend calls db.save(), but also calls db.syncAction('comment-submit').
                    // If frontend calls both, it might duplicate!
                    // Let's just do what was originally there to avoid breaking other things, but fix userId and collection.
                }
                
                // If it's not a reply, or we just push it anyway (as original code did)
                if (!isset($data['parentId'])) {
                    array_unshift($item['comments'], $newComment);
                    // Use collection variable instead of hardcoded ternary
                    if ($collection === 'actors') {
                        $db->saveItem($collection, $item, 'name');
                    } else {
                        $db->saveItem($collection, $item);
                    }
                    $this->success(['comment' => $newComment]);
                } else {
                    $this->success(['message' => 'Reply synced.']);
                }
            }
        } else if ($actionType === 'view-increment' || $actionType === 'increment-view') {
            $seriesId = $data['seriesId'] ?? $data['id'] ?? null;
            $series = $db->getItemById('series', $seriesId) ?? $db->getItemById('webtoons', $seriesId);
            if ($series) {
                $series['views'] = intval($series['views'] ?? 0) + 1;
                $db->saveItem(isset($series['type']) && $series['type'] === 'webtoon' ? 'webtoons' : 'series', $series);
                $this->success(['views' => $series['views']]);
            }
        }
        $this->error('Bilinmeyen işlem tipi: ' . $actionType);
    }

    private function handleGlobalStats()
    {
        $db = new Database();
        $stats = $db->getItemById('settings', 'site_stats') ?? ['id' => 'site_stats', 'totalVisitors' => 0, 'dailyVisitors' => 0, 'lastReset' => date('Y-m-d')];
        if (($_GET['inc'] ?? '') === '1') {
            $stats['totalVisitors']++;
            if ($stats['lastReset'] !== date('Y-m-d')) {
                $stats['dailyVisitors'] = 1;
                $stats['lastReset'] = date('Y-m-d');
            } else {
                $stats['dailyVisitors']++;
            }
            $db->saveItem('settings', $stats);
        }
        $this->success(['stats' => $stats]);
    }

    private function handleSocialGetPosts()
    {
        $db = new Database();
        $data = $db->loadCollections(['socialPosts']);
        $activePosts = array_filter($data['socialPosts'] ?? [], fn($p) => ($p['status'] ?? 'active') === 'active');
        usort($activePosts, fn($a, $b) => strtotime($b['createdAt'] ?? 0) - strtotime($a['createdAt'] ?? 0));
        $this->success(['posts' => array_values($activePosts), 'count' => count($activePosts)]);
    }

    private function handleBuyCoffee()
    {
        $userId = $this->getUserId();
        if (!$userId) $this->error('Giriş yapmalısınız.');
        $input = json_decode(file_get_contents('php://input'), true);
        $db = new Database();
        $buyer = $db->getItemById('users', $userId);
        $target = $db->getItemById('users', $input['targetId'] ?? '');

        if ($buyer && $target) {
            $price = intval($input['price'] ?? 50);
            if (($buyer['stats']['coins'] ?? 0) < $price) $this->error('Yetersiz coin.');
            $buyer['stats']['coins'] -= $price;
            $target['receivedCoffees'] = ($target['receivedCoffees'] ?? 0) + 1;
            $db->saveItem('users', $buyer);
            $db->saveItem('users', $target);
            $this->success(['message' => 'Kahve ısmarlandı!']);
        }
        $this->error('Kullanıcı bulunamadı.');
    }

    private function handleConvertCoffee()
    {
        $userId = $this->getUserId();
        if (!$userId) $this->error('Giriş yapmalısınız.');
        $db = new Database();
        $u = $db->getItemById('users', $userId);
        if ($u) {
            $count = intval($u['receivedCoffees'] ?? 0);
            if ($count <= 0) $this->error('Çevrilecek kahve yok.');
            $u['receivedCoffees'] = 0;
            $u['stats']['coins'] = ($u['stats']['coins'] ?? 0) + ($count * 40);
            $db->saveItem('users', $u);
            $this->success(['message' => 'DC Coin eklendi!']);
        }
    }

    private function handleAdminStats()
    {
        $this->checkAdmin();
        $db = new Database();
        $users = $db->getCollection('users');
        $series = $db->getCollection('series');
        $this->success([
            'counts' => ['users' => count($users), 'series' => count($series)],
            'activity' => array_slice($db->getCollection('logs'), 0, 10)
        ]);
    }

    private function handleIPManagement($action)
    {
        $this->checkAdmin();
        if ($action === 'admin-block-ip') {
            $input = json_decode(file_get_contents('php://input'), true);
            (new RateLimiter())->addBlockedIP($input['ip'], $input['reason'] ?? 'Admin');
            $this->success();
        } else if ($action === 'admin-list-blocked-ips') {
            $this->success(['ips' => (new RateLimiter())->getBlockedIPs()]);
        }
    }

    private function handleActorGet()
    {
        $db = new Database();
        $actor = $db->getItemById('actors', $_GET['name'] ?? '');
        $this->success(['actor' => $actor ?? ['name' => $_GET['name'] ?? '']]);
    }

    private function handleActorSave()
    {
        $this->checkAdmin();
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || !isset($data['name'])) $this->error('Eksik veri');
        $db = new Database();
        $db->saveItem('actors', $data, 'name');
        $this->success(['message' => 'Kaydedildi']);
    }

    private function handleActorFanAction()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $userId = $this->getUserId();
        if (!$userId) $this->error('Giriş yapmanız gereklidir.', 403);

        $input = json_decode(file_get_contents('php://input'), true);
        $actorId = $input['actorId'] ?? null;
        $actionType = $input['type'] ?? null; // 'join', 'vote', 'cheer', 'upload-photo'

        if (!$actorId || !$actionType) {
            $this->error('Eksik parametreler.');
        }

        $db = new Database();
        $actor = $db->getItemById('actors', $actorId);
        if (!$actor) {
            $this->error('Aktör bulunamadı.');
        }

        if (!isset($actor['fanCenter'])) {
            $actor['fanCenter'] = [
                'polls' => [],
                'members' => [],
                'gallery' => [],
                'weeklyCheers' => 0
            ];
        }
        if (!isset($actor['fanCenter']['polls'])) $actor['fanCenter']['polls'] = [];
        if (!isset($actor['fanCenter']['members'])) $actor['fanCenter']['members'] = [];
        if (!isset($actor['fanCenter']['gallery'])) $actor['fanCenter']['gallery'] = [];

        if (!isset($actor['fanCenter']['pendingMembers'])) $actor['fanCenter']['pendingMembers'] = [];
        
        $isPresident = $userId === ($actor['fanCenter']['presidentId'] ?? '');
        $isVicePresident = $userId === ($actor['fanCenter']['vicePresidentId'] ?? '');
        $isManager = $isPresident || $isVicePresident || ($_SESSION['user_role'] ?? ($_SESSION['user']['role'] ?? '')) === 'admin';
        
        $updated = false;
        $customMessage = null;

        if ($actionType === 'join') {
            if (!in_array($userId, $actor['fanCenter']['members']) && !in_array($userId, $actor['fanCenter']['pendingMembers'])) {
                $actor['fanCenter']['pendingMembers'][] = $userId;
                $updated = true;
                $customMessage = 'Başvurunuz alındı. Kulüp yönetiminin onayı bekleniyor.';
            } else if (in_array($userId, $actor['fanCenter']['pendingMembers'])) {
                $customMessage = 'Başvurunuz zaten değerlendirme aşamasında.';
            }
        } else if ($actionType === 'approve-join') {
            if (!$isManager) $this->error('Yetkiniz yok.');
            $targetUserId = $input['targetUserId'] ?? '';
            if (in_array($targetUserId, $actor['fanCenter']['pendingMembers'])) {
                $actor['fanCenter']['pendingMembers'] = array_values(array_filter($actor['fanCenter']['pendingMembers'], fn($id) => $id !== $targetUserId));
                if (!in_array($targetUserId, $actor['fanCenter']['members'])) {
                    $actor['fanCenter']['members'][] = $targetUserId;
                }
                $updated = true;
                $customMessage = 'Kullanıcı kulübe kabul edildi.';
            }
        } else if ($actionType === 'reject-join') {
            if (!$isManager) $this->error('Yetkiniz yok.');
            $targetUserId = $input['targetUserId'] ?? '';
            if (in_array($targetUserId, $actor['fanCenter']['pendingMembers'])) {
                $actor['fanCenter']['pendingMembers'] = array_values(array_filter($actor['fanCenter']['pendingMembers'], fn($id) => $id !== $targetUserId));
                $updated = true;
                $customMessage = 'Kullanıcı başvurusu reddedildi.';
            }
        } else if ($actionType === 'create-poll') {
            if (!$isManager) $this->error('Yetkiniz yok.');
            $pollOptions = array_map(function($opt) { return ['text' => $opt, 'votes' => 0]; }, $input['options'] ?? []);
            $actor['fanCenter']['polls'][] = [
                'id' => 'poll-' . time(),
                'question' => $input['question'] ?? 'Yeni Anket',
                'options' => $pollOptions,
                'type' => 'custom',
                'voters' => []
            ];
            $updated = true;
            $customMessage = 'Anket oluşturuldu.';
        } else if ($actionType === 'rating') {
            $score = intval($input['score'] ?? 0);
            if ($score < 1 || $score > 10) {
                $this->error('Geçersiz puan (1-10 arasında olmalıdır).');
            }
            if (!isset($actor['ratings'])) {
                $actor['ratings'] = [];
            }
            // Remove existing user rating
            $actor['ratings'] = array_values(array_filter($actor['ratings'], function($r) use ($userId) {
                return $r['userId'] !== $userId;
            }));
            $actor['ratings'][] = [
                'userId' => $userId,
                'score' => $score,
                'at' => time() * 1000
            ];
            $updated = true;
        } else if ($actionType === 'vote') {
            $pollIdx = intval($input['pollIdx'] ?? 0);
            $optIdx = intval($input['optIdx'] ?? 0);
            
            if (isset($actor['fanCenter']['polls'][$pollIdx])) {
                $poll = &$actor['fanCenter']['polls'][$pollIdx];
                if (!isset($poll['voters'])) $poll['voters'] = [];
                if (!in_array($userId, $poll['voters'])) {
                    if (!isset($poll['options'][$optIdx]['votes'])) {
                        $poll['options'][$optIdx]['votes'] = 0;
                    }
                    $poll['options'][$optIdx]['votes']++;
                    $poll['voters'][] = $userId;
                    $updated = true;
                } else {
                    $this->error('Bu oylamada zaten oy kullandınız.');
                }
            } else {
                $this->error('Oylama bulunamadı.');
            }
        } else if ($actionType === 'cheer') {
            if (!isset($actor['fanCenter']['weeklyCheers'])) {
                $actor['fanCenter']['weeklyCheers'] = 0;
            }
            $actor['fanCenter']['weeklyCheers']++;
            $updated = true;
        } else if ($actionType === 'upload-photo') {
            $photoUrl = $input['photoUrl'] ?? '';
            if (empty($photoUrl)) {
                $this->error('Resim URL boş olamaz.');
            }
            $photoItem = [
                'id' => 'photo_' . time() . '_' . rand(100, 999),
                'url' => $photoUrl,
                'userId' => $userId,
                'username' => $_SESSION['username'] ?? $_SESSION['user']['username'] ?? 'Anonim',
                'createdAt' => time() * 1000
            ];
            $actor['fanCenter']['gallery'][] = $photoItem;
            $updated = true;
        }

        if ($updated) {
            $db->saveItem('actors', $actor, 'name');
            $this->success(['actor' => $actor, 'message' => $customMessage ?? 'İşlem başarılı.']);
        } else {
            $this->success(['message' => $customMessage ?? 'Değişiklik yapılmadı.', 'actor' => $actor]);
        }
    }

    private function handleListActors()
    {
        $db = new Database();
        $actors = $db->getCollection('actors');
        $this->success(['actors' => $actors, 'count' => count($actors)]);
    }

    private function handleSystemHealth()
    {
        $this->checkAdmin();
        $db = new Database();
        $pdo = $db->getPdo();
        
        $mysqlStatus = 'Connected';
        $mysqlError = null;
        $tables = [];

        if (!$pdo) {
            $mysqlStatus = 'Failed';
            $mysqlError = 'Could not establish PDO connection.';
        } else {
            try {
                $stmt = $pdo->query("SHOW TABLES");
                if ($stmt) {
                    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }
            } catch (Exception $e) {
                $mysqlStatus = 'Error';
                $mysqlError = $e->getMessage();
            }
        }

        $this->success([
            'status' => 'healthy',
            'mysql' => [
                'status' => $mysqlStatus,
                'error' => $mysqlError,
                'table_count' => count($tables),
                'tables' => $tables,
                'host' => defined('DB_HOST') ? DB_HOST : 'Unknown',
                'database' => defined('DB_NAME') ? DB_NAME : 'Unknown'
            ],
            'server' => [
                'php_version' => PHP_VERSION,
                'os' => PHP_OS,
                'load' => function_exists('sys_getloadavg') ? sys_getloadavg() : 'N/A',
                'memory_usage' => round(memory_get_usage() / 1024 / 1024, 2) . ' MB'
            ],
            'timestamp' => date('c')
        ]);
    }
}
