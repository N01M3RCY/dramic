<?php
// DRAMICBOX API CONFIGURATION
define('TMDB_API_KEY', '9ae2ac70b11539e57dee6e9eff04b3f4'); // User replaced with active key
define('TMDB_LANG', 'tr-TR');
define('BASE_URL', 'https://api.themoviedb.org/3/');
define('TMDB_READ_TOKEN', 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5YWUyYWM3MGIxMTUzOWU1N2RlZTZlOWVmZjA0YjNmNCIsIm5iZiI6MTc3NDM1MDYyMS4wNjcwMDAyLCJzdWIiOiI2OWMyNzExZGUxMzA4NjA5MzlhZjAwMWUiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.fGIyaKtvjUpuCcBheFLjpOxuWzE3c3xrnHmZyXd4nM8');
define('VIDMOLY_API_KEY', 'YOUR_VIDMOLY_API_KEY_HERE'); // Central shared account

// DATABASE CONFIGURATION (Hosting Dünyam cPanel)
// Not: Hosting Dünyam sunucusunda MySQL bağlantısı için DB_HOST 'localhost' olmalıdır.
// cPanel'den veritabanını ve kullanıcıyı oluşturduktan sonra burayı güncelleyebilirsin.
define('DB_HOST', 'localhost');
define('DB_NAME', 'dramicb1_diziler');      // cPanel'de oluşturduğun veritabanı adı
define('DB_USER', 'dramicb1_admin');        // cPanel'de oluşturduğun veritabanı kullanıcısı
define('DB_PASS', 'Zumran1514!');     // cPanel'de veritabanı kullanıcısı için belirlediğin şifre
?>