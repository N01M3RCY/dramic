<?php
// ============================================
// DRAMICBOX - BLOG TO SOCIAL MIGRATION
// Run once to migrate blog posts to social feed
// ============================================

require_once __DIR__ . '/core/Database.php';

header('Content-Type: application/json');

$db = new Database();
$data = $db->load();

$blogPosts = $data['blogPosts'] ?? [];
$socialPosts = $data['socialPosts'] ?? [];

$migratedCount = 0;

foreach ($blogPosts as $blog) {
    // Check if already migrated (by checking for blog ID in social posts)
    $exists = false;
    foreach ($socialPosts as $sp) {
        if (isset($sp['legacyBlogId']) && $sp['legacyBlogId'] === $blog['id']) {
            $exists = true;
            break;
        }
    }

    if (!$exists) {
        $newPost = [
            'id' => 'post-' . time() . '-' . rand(1000, 9999),
            'legacyBlogId' => $blog['id'],
            'userId' => $blog['authorId'] ?? $blog['userId'] ?? 'admin',
            'username' => $blog['authorName'] ?? $blog['username'] ?? 'Blogger',
            'title' => $blog['title'] ?? 'Başlıksız Yazı',
            'text' => $blog['content'] ?? $blog['text'] ?? '',
            'mediaUrl' => $blog['coverImage'] ?? $blog['mediaUrl'] ?? null,
            'mediaType' => 'image',
            'isBlog' => true,
            'category' => $blog['category'] ?? 'Genel',
            'status' => 'approved',
            'createdAt' => $blog['createdAt'] ?? date('Y-m-d\TH:i:s.v\Z'),
            'likes' => $blog['likes'] ?? [],
            'comments' => [] // We could migrate comments too, but for now keeping it simple
        ];

        // Migrate comments if they exist
        if (isset($blog['comments']) && is_array($blog['comments'])) {
            foreach ($blog['comments'] as $c) {
                $newPost['comments'][] = [
                    'id' => 'cmt-' . time() . '-' . rand(100, 999),
                    'userId' => $c['userId'] ?? 'anonymous',
                    'text' => $c['text'] ?? '',
                    'createdAt' => $c['createdAt'] ?? date('Y-m-d\TH:i:s.v\Z')
                ];
            }
        }

        $socialPosts[] = $newPost;
        $migratedCount++;
    }
}

if ($migratedCount > 0) {
    $data['socialPosts'] = $socialPosts;
    $db->save($data);
    echo json_encode(['success' => true, 'message' => "Successfully migrated $migratedCount blog posts!"]);
} else {
    echo json_encode(['success' => true, 'message' => "No new blog posts to migrate."]);
}
?>