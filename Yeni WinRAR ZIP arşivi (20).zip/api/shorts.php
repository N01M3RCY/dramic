<?php
/**
 * Shorts API Endpoint - MySQL Integrated
 * Kısa drama videoları için CRUD ve coin işlemleri
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/core/Database.php';
$db = new Database();

/**
 * Get all shorts or single short by ID
 */
function getShorts($id = null) {
    global $db;
    
    if ($id) {
        return $db->getItemById('shorts', $id);
    }
    
    $allShorts = $db->getCollection('shorts');
    $shorts = [];
    
    foreach ($allShorts as $short) {
        if ($short && isset($short['status']) && $short['status'] === 'published') {
            $shorts[] = [
                'id' => $short['id'],
                'title' => $short['title'],
                'poster' => $short['poster'],
                'genres' => $short['genres'] ?? [],
                'translator' => $short['translator'] ?? '',
                'freeEpisodes' => $short['freeEpisodes'] ?? 0,
                'totalEpisodes' => $short['totalEpisodes'] ?? count($short['episodes'] ?? []),
                'vipOnly' => $short['vipOnly'] ?? false,
                'views' => $short['views'] ?? 0,
                'rating' => $short['rating'] ?? 0
            ];
        }
    }
    
    return $shorts;
}

/**
 * Save short to DB
 */
function saveShort($short) {
    global $db;
    $short['updatedAt'] = date('c');
    return $db->saveItem('shorts', $short);
}

/**
 * Get user data
 */
function getUser($userId) {
    global $db;
    return $db->getItemById('users', $userId);
}

/**
 * Save user data
 */
function saveUser($user) {
    global $db;
    return $db->saveItem('users', $user);
}

/**
 * Check if user can watch episode
 */
function canWatchEpisode($short, $episodeNum, $user) {
    $episode = null;
    foreach ($short['episodes'] as $ep) {
        if ($ep['number'] == $episodeNum) {
            $episode = $ep;
            break;
        }
    }
    
    if (!$episode) {
        return ['allowed' => false, 'reason' => 'episode_not_found'];
    }
    
    // VIP only check
    if ($short['vipOnly'] && !($user['isVip'] ?? false)) {
        return ['allowed' => false, 'reason' => 'vip_required'];
    }
    
    // Free episode
    if ($episode['isFree'] || $episodeNum <= ($short['freeEpisodes'] ?? 0)) {
        return ['allowed' => true, 'reason' => 'free'];
    }
    
    // Already unlocked
    $unlockKey = $short['id'] . '_ep_' . $episodeNum;
    if (in_array($unlockKey, $user['unlockedShortEpisodes'] ?? [])) {
        return ['allowed' => true, 'reason' => 'unlocked'];
    }
    
    // Check coins
    $userCoins = $user['stats']['coins'] ?? 0;
    $price = $episode['coinPrice'] ?? $short['defaultCoinPrice'] ?? 10;
    
    if ($userCoins >= $price) {
        return ['allowed' => true, 'reason' => 'can_unlock', 'price' => $price];
    }
    
    return ['allowed' => false, 'reason' => 'insufficient_coins', 'price' => $price, 'userCoins' => $userCoins];
}

/**
 * Unlock episode with coins
 */
function unlockEpisode($shortId, $episodeNum, $userId) {
    $short = getShorts($shortId);
    if (!$short) {
        return ['success' => false, 'error' => 'Short not found'];
    }
    
    $user = getUser($userId);
    if (!$user) {
        return ['success' => false, 'error' => 'User not found'];
    }
    
    $canWatch = canWatchEpisode($short, $episodeNum, $user);
    
    if ($canWatch['reason'] === 'free' || $canWatch['reason'] === 'unlocked') {
        return ['success' => true, 'message' => 'Already accessible'];
    }
    
    if ($canWatch['reason'] === 'insufficient_coins') {
        return ['success' => false, 'error' => 'Yetersiz coin', 'required' => $canWatch['price'], 'current' => $canWatch['userCoins']];
    }
    
    if ($canWatch['reason'] === 'vip_required') {
        return ['success' => false, 'error' => 'VIP üyelik gerekli'];
    }
    
    if ($canWatch['reason'] === 'can_unlock') {
        // Deduct coins
        $price = $canWatch['price'];
        $user['stats']['coins'] -= $price;
        
        // Add to unlocked list
        if (!isset($user['unlockedShortEpisodes'])) {
            $user['unlockedShortEpisodes'] = [];
        }
        $unlockKey = $shortId . '_ep_' . $episodeNum;
        $user['unlockedShortEpisodes'][] = $unlockKey;
        
        saveUser($user);
        
        // Increment views
        $short['views'] = ($short['views'] ?? 0) + 1;
        saveShort($short);
        
        return [
            'success' => true, 
            'message' => 'Bölüm açıldı!',
            'coinsSpent' => $price,
            'remainingCoins' => $user['stats']['coins']
        ];
    }
    
    return ['success' => false, 'error' => 'Unknown error'];
}

// Handle requests
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? $_POST['action'] ?? null;
$id = $_GET['id'] ?? $_POST['id'] ?? null;
$episodeNum = $_GET['ep'] ?? $_POST['ep'] ?? null;
$userId = $_GET['userId'] ?? $_POST['userId'] ?? null;

try {
    switch ($method) {
        case 'GET':
            if ($id && $episodeNum && $userId) {
                // Check episode access
                $short = getShorts($id);
                $user = getUser($userId);
                if (!$short || !$user) {
                    echo json_encode(['error' => 'Not found']);
                    break;
                }
                $access = canWatchEpisode($short, $episodeNum, $user);
                echo json_encode(['access' => $access, 'short' => $short]);
            } elseif ($id) {
                // Get single short with full details
                $short = getShorts($id);
                if ($short) {
                    echo json_encode(['success' => true, 'data' => $short]);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Not found']);
                }
            } else {
                // Get all shorts
                $shorts = getShorts();
                echo json_encode(['success' => true, 'data' => $shorts]);
            }
            break;
            
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
            $action = $input['action'] ?? $action;
            
            if ($action === 'unlock') {
                $result = unlockEpisode(
                    $input['shortId'] ?? $id,
                    $input['episodeNum'] ?? $episodeNum,
                    $input['userId'] ?? $userId
                );
                echo json_encode($result);
            } elseif ($action === 'create' || $action === 'update') {
                // Admin: Create/Update short
                $shortData = $input['data'] ?? $input;
                if (!isset($shortData['id'])) {
                    $shortData['id'] = strtolower(str_replace(' ', '-', $shortData['title'] ?? 'short-' . time()));
                }
                saveShort($shortData);
                echo json_encode(['success' => true, 'id' => $shortData['id']]);
            } elseif ($action === 'view') {
                // Increment view count
                $short = getShorts($id);
                if ($short) {
                    $short['views'] = ($short['views'] ?? 0) + 1;
                    saveShort($short);
                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['success' => false]);
                }
            } else {
                echo json_encode(['error' => 'Invalid action']);
            }
            break;
            
        case 'DELETE':
            if ($id && $db->deleteFromCollection('shorts', $id)) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Delete failed']);
            }
            break;
            
        default:
            echo json_encode(['error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
