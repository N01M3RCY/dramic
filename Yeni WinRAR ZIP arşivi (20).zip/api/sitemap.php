<?php
header('Content-Type: application/xml; charset=utf-8');

// Load database
$jsonFile = 'database.json';
if (!file_exists($jsonFile)) {
    http_response_code(404);
    exit();
}

$data = json_decode(file_get_contents($jsonFile), true);
$series = $data['series'] ?? [];

$baseUrl = 'https://dramicbox.com';

echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <!-- Static Pages -->
    <url>
        <loc><?php echo $baseUrl; ?>/</loc>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>
    <url>
        <loc><?php echo $baseUrl; ?>/diziler</loc>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?php echo $baseUrl; ?>/webtoon</loc>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>

    <!-- Dynamic Content (Series & Webtoons) -->
    <?php foreach ($series as $item): ?>
    <?php
        $type = ($item['type'] === 'webtoon') ? 'webtoon' : 'dizi';
        // Simple slug generation matching JS logic
        $slug = strtolower($item['title']);
        $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug); // Remove special chars
        $slug = preg_replace('/\s+/', '-', $slug); // Space to dash
        if (!empty($item['year'])) {
            $slug .= '-' . $item['year'];
        }
    ?>
    <url>
        <loc><?php echo $baseUrl; ?>/<?php echo $type; ?>/<?php echo $slug; ?></loc>
        <lastmod><?php echo date('Y-m-d', $item['updatedAt'] / 1000); ?></lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.9</priority>
    </url>
    <?php endforeach; ?>

</urlset>
