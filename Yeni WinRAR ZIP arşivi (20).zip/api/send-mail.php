<?php
/**
 * Email Sending API
 * Sends support tickets and DMCA reports to support@dramicbox.com
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Configuration
$SUPPORT_EMAIL = 'support@dramicbox.com';
$FROM_EMAIL = 'info@dramicbox.com';
$SITE_NAME = 'DramicBox';

require_once __DIR__ . '/core/SMTPMailer.php';

/**
 * Send email using socket-based SMTPMailer
 */
function sendEmail($to, $subject, $htmlBody, $replyTo = null) {
    global $FROM_EMAIL, $SITE_NAME;
    
    $smtpHost = 'mail.dramicbox.com';
    $smtpPort = 465;
    $smtpUser = 'info@dramicbox.com';
    $smtpPass = 'Zumran1514';
    
    $mailer = new SMTPMailer($smtpHost, $smtpPort, $smtpUser, $smtpPass);
    return $mailer->send($to, $subject, $htmlBody, $SITE_NAME);
}

/**
 * Build email HTML template
 */
function buildEmailTemplate($title, $content, $footer = '') {
    return "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #7c3aed, #a78bfa); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
            .header h1 { margin: 0; font-size: 24px; }
            .body { background: #f9fafb; padding: 20px; border: 1px solid #e5e7eb; }
            .footer { background: #1f2937; color: #9ca3af; padding: 15px; text-align: center; border-radius: 0 0 8px 8px; font-size: 12px; }
            .info-row { margin: 10px 0; padding: 10px; background: white; border-radius: 4px; border-left: 3px solid #7c3aed; }
            .label { font-weight: 600; color: #6b7280; font-size: 12px; text-transform: uppercase; }
            .value { margin-top: 4px; }
            .priority-high { border-left-color: #ef4444; }
            .priority-medium { border-left-color: #f59e0b; }
            .btn { display: inline-block; padding: 10px 20px; background: #7c3aed; color: white; text-decoration: none; border-radius: 4px; margin-top: 15px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>{$title}</h1>
            </div>
            <div class='body'>
                {$content}
            </div>
            <div class='footer'>
                &copy; " . date('Y') . " DramicBox - Tüm hakları saklıdır.
                {$footer}
            </div>
        </div>
    </body>
    </html>
    ";
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Only POST allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

$type = $input['type'] ?? '';

try {
    switch ($type) {
        case 'ticket':
            // Support Ticket
            $ticketId = $input['ticketId'] ?? 'TKT-' . time();
            $category = $input['category'] ?? 'Genel';
            $subject = $input['subject'] ?? 'Destek Talebi';
            $message = $input['message'] ?? '';
            $userName = $input['userName'] ?? 'Anonim';
            $userEmail = $input['userEmail'] ?? '';
            $userId = $input['userId'] ?? '';
            
            $content = "
                <p><strong>Yeni bir destek talebi alındı.</strong></p>
                
                <div class='info-row'>
                    <div class='label'>Ticket ID</div>
                    <div class='value'><strong>{$ticketId}</strong></div>
                </div>
                
                <div class='info-row'>
                    <div class='label'>Kategori</div>
                    <div class='value'>{$category}</div>
                </div>
                
                <div class='info-row'>
                    <div class='label'>Konu</div>
                    <div class='value'>{$subject}</div>
                </div>
                
                <div class='info-row'>
                    <div class='label'>Kullanıcı</div>
                    <div class='value'>{$userName}" . ($userId ? " (ID: {$userId})" : "") . "</div>
                </div>
                
                " . ($userEmail ? "
                <div class='info-row'>
                    <div class='label'>E-posta</div>
                    <div class='value'>{$userEmail}</div>
                </div>
                " : "") . "
                
                <div class='info-row'>
                    <div class='label'>Mesaj</div>
                    <div class='value'>" . nl2br(htmlspecialchars($message)) . "</div>
                </div>
                
                <p style='margin-top: 20px; color: #6b7280; font-size: 13px;'>
                    Bu ticket admin panelinden yönetilebilir.
                </p>
            ";
            
            $emailSubject = "[Destek #{$ticketId}] {$subject}";
            $html = buildEmailTemplate('Yeni Destek Talebi', $content);
            
            $sent = sendEmail($SUPPORT_EMAIL, $emailSubject, $html, $userEmail);
            
            echo json_encode([
                'success' => $sent,
                'ticketId' => $ticketId,
                'message' => $sent ? 'Email gönderildi' : 'Email gönderilemedi'
            ]);
            break;
            
        case 'dmca':
            // DMCA Report
            $reportId = $input['reportId'] ?? 'DMCA-' . time();
            $name = $input['name'] ?? '';
            $email = $input['email'] ?? '';
            $phone = $input['phone'] ?? '';
            $company = $input['company'] ?? '';
            $contentTitle = $input['contentTitle'] ?? '';
            $contentUrl = $input['contentUrl'] ?? '';
            $originalUrl = $input['originalUrl'] ?? '';
            $description = $input['description'] ?? '';
            $userName = $input['userName'] ?? 'Anonim';
            $userId = $input['userId'] ?? '';
            
            $content = "
                <p><strong>Yeni bir DMCA telif bildirimi alındı.</strong></p>
                
                <div class='info-row priority-high'>
                    <div class='label'>Bildirim ID</div>
                    <div class='value'><strong>{$reportId}</strong></div>
                </div>
                
                <h3 style='margin-top: 20px; color: #374151;'>Telif Sahibi Bilgileri</h3>
                
                <div class='info-row'>
                    <div class='label'>Ad Soyad</div>
                    <div class='value'>{$name}</div>
                </div>
                
                <div class='info-row'>
                    <div class='label'>E-posta</div>
                    <div class='value'>{$email}</div>
                </div>
                
                " . ($phone ? "
                <div class='info-row'>
                    <div class='label'>Telefon</div>
                    <div class='value'>{$phone}</div>
                </div>
                " : "") . "
                
                " . ($company ? "
                <div class='info-row'>
                    <div class='label'>Şirket/Organizasyon</div>
                    <div class='value'>{$company}</div>
                </div>
                " : "") . "
                
                <h3 style='margin-top: 20px; color: #374151;'>İhlal Edilen İçerik</h3>
                
                <div class='info-row'>
                    <div class='label'>İçerik Başlığı</div>
                    <div class='value'>{$contentTitle}</div>
                </div>
                
                " . ($contentUrl ? "
                <div class='info-row'>
                    <div class='label'>İhlal Edilen URL</div>
                    <div class='value'><a href='{$contentUrl}'>{$contentUrl}</a></div>
                </div>
                " : "") . "
                
                " . ($originalUrl ? "
                <div class='info-row'>
                    <div class='label'>Orijinal İçerik URL</div>
                    <div class='value'><a href='{$originalUrl}'>{$originalUrl}</a></div>
                </div>
                " : "") . "
                
                <div class='info-row'>
                    <div class='label'>Açıklama</div>
                    <div class='value'>" . nl2br(htmlspecialchars($description)) . "</div>
                </div>
                
                <h3 style='margin-top: 20px; color: #374151;'>Gönderen</h3>
                <div class='info-row'>
                    <div class='label'>Kullanıcı</div>
                    <div class='value'>{$userName}" . ($userId ? " (ID: {$userId})" : "") . "</div>
                </div>
                
                <p style='margin-top: 20px; color: #dc2626; font-size: 13px;'>
                    ⚠️ Bu bildirim DMCA yasalarına tabidir ve 24 saat içinde işleme alınmalıdır.
                </p>
            ";
            
            $emailSubject = "[DMCA #{$reportId}] Telif Bildirimi - {$contentTitle}";
            $html = buildEmailTemplate('DMCA Telif Bildirimi', $content);
            
            $sent = sendEmail($SUPPORT_EMAIL, $emailSubject, $html, $email);
            
            echo json_encode([
                'success' => $sent,
                'reportId' => $reportId,
                'message' => $sent ? 'DMCA bildirimi gönderildi' : 'Email gönderilemedi'
            ]);
            break;
            
        case 'notification':
            // General notification
            $to = $input['to'] ?? $SUPPORT_EMAIL;
            $subject = $input['subject'] ?? 'DramicBox Bildirimi';
            $message = $input['message'] ?? '';
            
            $content = "
                <div class='info-row'>
                    <div class='value'>" . nl2br(htmlspecialchars($message)) . "</div>
                </div>
            ";
            
            $html = buildEmailTemplate($subject, $content);
            $sent = sendEmail($to, $subject, $html);
            
            echo json_encode([
                'success' => $sent,
                'message' => $sent ? 'Bildirim gönderildi' : 'Gönderilemedi'
            ]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid type']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
