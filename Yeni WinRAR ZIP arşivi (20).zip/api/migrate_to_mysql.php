<?php
require_once __DIR__ . '/core/Database.php';

header('Content-Type: text/plain');
echo "Dramicbox MySQL Migration Started...\n";
echo "-----------------------------------\n";

$db = new Database();
$pdo = $db->getPdo();

if (!$pdo) {
    die("ERROR: Could not connect to MySQL. Please check your config.php settings.\n");
}

$baseDir = __DIR__ . '/../Database/';
$mapping = [
    'users' => 'kullanicilar',
    'series' => 'diziler',
    'blogPosts' => 'blog',
    'tickets' => 'tickets',
    'shorts' => 'shorts',
    'actors' => 'actors',
    'calendar' => 'etkinlikler',
    'reports' => 'raporlar',
    'comments' => 'yorumlar',
    'episodeComments' => 'bolum_yorumlari',
    'polls' => 'anketler',
    'announcements' => 'duyurular',
    'logs' => 'loglar',
    'messages' => 'messages',
    'friendRequests' => 'arkadaslik_istekleri',
    'adminChat' => 'admin_chat',
    'settings' => 'ayarlar',
    'faqs' => 'sss',
    'notifications' => 'bildirimler',
    'watchParties' => 'parti_odalari',
    'requests' => 'istekler',
    'dmcaReports' => 'dmca_reports',
    'webtoons' => 'webtoons',
    'heroSlides' => 'hero_slaytlar',
    'shopItems' => 'market_urunleri',
    'premiumPackages' => 'premium_paketler',
    'activities' => 'aktiviteler'
];

foreach ($mapping as $key => $folder) {
    $dir = $baseDir . $folder . '/';
    if (!file_exists($dir)) {
        echo "Skipping $key: Folder $folder not found.\n";
        continue;
    }

    echo "Migrating $key (from $folder)... ";
    
    $files = glob($dir . '*.json');
    $count = 0;
    $errors = [];

    foreach ($files as $file) {
        if (basename($file) === 'hub.json' || basename($file) === 'global.json') continue;
        
        $content = file_get_contents($file);
        $item = json_decode($content, true);
        
        if ($item) {
            $idField = ($key === 'actors') ? 'name' : 'id';
            if ($db->saveItem($key, $item, $idField)) {
                $count++;
            } else {
                $err = $db->getLastError();
                if ($err) {
                    $errors[] = basename($file) . ": " . $err;
                }
            }
        }
    }
    
    echo "Done! ($count items migrated)<br>\n";
    if (!empty($errors)) {
        echo "<span style='color:red;'>⚠️ Migration Errors in $key:</span><br><ul>";
        foreach ($errors as $e) {
            echo "<li>" . htmlspecialchars($e) . "</li>";
        }
        echo "</ul>";
    }
}

// Handle Social Hub specifically
echo "Migrating Social Hub (hub.json)... ";
$hubFile = $baseDir . 'socialhub/hub.json';
if (file_exists($hubFile)) {
    $hub = json_decode(file_get_contents($hubFile), true);
    if ($hub) {
        $socialCount = 0;
        $blogCount = 0;
        $socialErrors = [];
        $blogErrors = [];
        
        foreach ($hub['socialPosts'] ?? [] as $post) {
            if ($db->saveItem('socialPosts', $post)) {
                $socialCount++;
            } else {
                $err = $db->getLastError();
                if ($err) $socialErrors[] = $err;
            }
        }
        echo "Social Posts: $socialCount, ";
        
        foreach ($hub['blogPosts'] ?? [] as $post) {
            if ($db->saveItem('blogPosts', $post)) {
                $blogCount++;
            } else {
                $err = $db->getLastError();
                if ($err) $blogErrors[] = $err;
            }
        }
        echo "Blog Posts: $blogCount.<br>\n";
        
        if (!empty($socialErrors) || !empty($blogErrors)) {
            echo "<span style='color:red;'>⚠️ Social Hub Migration Errors:</span><br><ul>";
            foreach (array_unique(array_merge($socialErrors, $blogErrors)) as $e) {
                echo "<li>" . htmlspecialchars($e) . "</li>";
            }
            echo "</ul>";
        }
    }
} else {
    echo "Not found.<br>\n";
}

echo "-----------------------------------<br>\n";
echo "Migration finished successfully!<br>\n";
echo "You can now delete this script and use the MySQL system.<br>\n";
?>
