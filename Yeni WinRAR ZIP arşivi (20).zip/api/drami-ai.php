<?php
/**
 * DramicBox AI Proxy - MySQL Integrated
 * Handles internal logic and bridges to external LLMs
 */

header('Content-Type: application/json');
require_once __DIR__ . '/core/Database.php';
$db = new Database();

$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true);

switch ($action) {
    case 'ask':
        $userPrompt = $input['prompt'] ?? '';
        
        // Load Series Data from MySQL for "RAG-lite"
        $series = $db->getCollection('series');
        $response = handleLocalLogic($userPrompt, $series);
        
        echo json_encode([
            'success' => true,
            'response' => $response,
            'source' => 'drami_local_core'
        ]);
        break;

    case 'llm-proxy':
        // 🔑 Gemini API Key
        $apiKey = 'AIzaSyD6AXyCkNEJA68hOzt-J4cQhSuBHIcseG4'; 

        if ($apiKey === 'BURAYA_GOOGLE_API_ANAHTARINIZI_YAZIN') {
             echo json_encode(['success' => false, 'message' => 'Lütfen drami-ai.php dosyasını açıp API anahtarınızı yapıştırın.']);
             exit;
        }

        // --- QUOTA MANAGEMENT (MySQL Based) ---
        $settings = $db->getCollection('settings');
        if (!isset($settings['ai_usage'])) {
            $settings['ai_usage'] = ['date' => date('Y-m-d'), 'count' => 0];
        }
        
        $today = date('Y-m-d');
        if ($settings['ai_usage']['date'] !== $today) {
            $settings['ai_usage'] = ['date' => $today, 'count' => 0];
        }

        // Check Limit
        if ($settings['ai_usage']['count'] >= 1500) {
             echo json_encode([
                 'success' => false, 
                 'code' => 'quota_exceeded',
                 'message' => 'Günlük AI limitine ulaşıldı (1500/1500). Bakım moduna geçiliyor.'
             ]);
             exit;
        }

        // Increment & Save
        $settings['ai_usage']['count']++;
        $db->saveItem('settings', $settings);
        // -------------------------------------------


        $userPrompt = $input['prompt'] ?? '';
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' . $apiKey;

        // CONTEXT INJECTION
        $context = $input['context'] ?? null;
        $contextStr = "";
        if ($context) {
            $contextStr = "[CONTEXT: Kullanıcı şu an \"" . $context['title'] . "\" isimli içeriği " . ($context['episode'] ? $context['episode'] . ". bölümünü " : "") . "izliyor/inceliyor. Türler: " . (is_array($context['genres']) ? implode(', ', $context['genres']) : $context['genres']) . ".] ";
        }

        $data = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $contextStr . $userPrompt . " (Cevabı DramicBox asistanı Drami olarak, Türkçe ve samimi bir dille, kısa tutarak ver. Emoji kullanabilirsin.)"]
                    ]
                ]
            ]
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
             echo json_encode(['success' => false, 'message' => 'API Hatası: ' . curl_error($ch)]);
        } else {
             $decoded = json_decode($response, true);
             if (isset($decoded['candidates'][0]['content']['parts'][0]['text'])) {
                 $aiText = $decoded['candidates'][0]['content']['parts'][0]['text'];
                 echo json_encode(['success' => true, 'response' => $aiText, 'source' => 'gemini_flash']);
             } else {
                 $errorMessage = $decoded['error']['message'] ?? 'Bilinmeyen bir hata oluştu.';
                 echo json_encode(['success' => false, 'message' => 'AI Cevabı Alınamadı: ' . $errorMessage]);
             }
        }
        curl_close($ch);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

function handleLocalLogic($prompt, $seriesData) {
    $prompt = mb_strtolower($prompt, 'UTF-8');
    foreach ($seriesData as $series) {
        if (strpos($prompt, mb_strtolower($series['title'], 'UTF-8')) !== false) {
            return "Evet, " . $series['title'] . " harika bir seçim! İzlemek ister misin?";
        }
    }
    return "Şu an gelişmiş dil modelim uyku modunda. Ama sana diziler hakkında genel bilgi verebilirim!";
}
