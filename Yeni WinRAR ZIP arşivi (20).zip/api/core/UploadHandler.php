<?php
/**
 * DramicBox Professional Upload Handler
 */
class UploadHandler {
    private $allowedExtensions = [];
    private $maxSize;
    private $uploadDir;

    public function __construct($type = 'social') {
        $this->maxSize = 100 * 1024 * 1024; // 100MB default
        
        switch ($type) {
            case 'social':
                $this->allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'mp4', 'webm', 'mov'];
                $this->uploadDir = __DIR__ . '/../../uploads/social/';
                break;
            case 'avatar':
                $this->allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
                $this->uploadDir = __DIR__ . '/../../uploads/avatars/';
                $this->maxSize = 5 * 1024 * 1024; // 5MB
                break;
            case 'series':
                $this->allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
                $this->uploadDir = __DIR__ . '/../../uploads/series/';
                break;
            default:
                $this->allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
                $this->uploadDir = __DIR__ . '/../../uploads/misc/';
        }

        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0777, true);
        }
    }

    public function handle($fileKey = 'media') {
        if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) {
            $error = $_FILES[$fileKey]['error'] ?? 'No file';
            return ['success' => false, 'message' => 'Upload error: ' . $error];
        }

        $file = $_FILES[$fileKey];
        $size = $file['size'];
        $name = $file['name'];
        $tmp = $file['tmp_name'];

        if ($size > $this->maxSize) {
            return ['success' => false, 'message' => 'File too large'];
        }

        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!in_array($ext, $this->allowedExtensions)) {
            return ['success' => false, 'message' => 'Invalid file type: ' . $ext];
        }

        // Generate secure unique name
        $uniqueName = bin2hex(random_bytes(8)) . '_' . time() . '.' . $ext;
        $dest = $this->uploadDir . $uniqueName;

        if (move_uploaded_file($tmp, $dest)) {
            // Determine type
            $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
            
            // Return relative URL from public root
            $relativePath = str_replace(realpath(__DIR__ . '/../../'), '', realpath($dest));
            $relativePath = ltrim(str_replace('\\', '/', $relativePath), '/');

            return [
                'success' => true,
                'url' => $relativePath,
                'name' => $name,
                'size' => $size,
                'type' => $isImage ? 'image' : 'video'
            ];
        }

        return ['success' => false, 'message' => 'Failed to move file'];
    }
}
