<?php

require_once __DIR__ . '/Database.php';

/**
 * Base Controller for all API controllers
 * @property Database $db
 */
class BaseController {
    protected $db;
    protected $data;

    public function __construct() {
        if (!class_exists('Database')) {
            require_once __DIR__ . '/Database.php';
        }
        $this->db = new Database();
    }

    protected function jsonResponse($success, $data = [], $message = '') {
        header('Content-Type: application/json');
        echo json_encode(array_merge([
            'success' => $success,
            'message' => $message
        ], $data));
        exit;
    }

    protected function error($message, $code = 400) {
        http_response_code($code);
        $this->jsonResponse(false, [], $message);
    }

    protected function success($data = []) {
        $this->jsonResponse(true, $data);
    }

    protected function awardCreatorXP($username, $amount) {
        require_once __DIR__ . '/GamificationManager.php';
        
        // Find user by username in MySQL
        $users = $this->db->getCollection('users');
        $userData = null;
        foreach ($users as $u) {
            if (strtolower($u['username']) === strtolower($username)) {
                $userData = $u;
                break;
            }
        }
        
        if ($userData) {
            $res = GamificationManager::awardCreatorXP($userData, $amount);
            $this->db->saveItem('users', $userData);
            return $res;
        }
        return null;
    }

    public function getUserId() {
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.gc_maxlifetime', 2592000);
            session_set_cookie_params([
                'lifetime' => 2592000,
                'path' => '/',
                'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
                'httponly' => true,
                'samesite' => 'Lax'
            ]);
            session_start();
        }
        
        if (isset($_SESSION['user_id'])) return $_SESSION['user_id'];
        if (isset($_SESSION['user']['id'])) return $_SESSION['user']['id'];
        
        return null;
    }

    protected function checkAdmin() {
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.gc_maxlifetime', 2592000);
            session_set_cookie_params([
                'lifetime' => 2592000,
                'path' => '/',
                'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
                'httponly' => true,
                'samesite' => 'Lax'
            ]);
            session_start();
        }

        $role = $_SESSION['user_role'] ?? $_SESSION['user']['role'] ?? 'user';

        if ($role !== 'admin') {
            $this->error('Admin yetkisi gerekli', 403);
        }
    }

    protected function logActivity($type, $data) {
        $userId = $this->getUserId();
        $user = $userId ? $this->db->getItemById('users', $userId) : null;
        
        $activity = [
            'id' => 'act-' . time() . '-' . rand(100, 999),
            'type' => $type,
            'userId' => $userId,
            'username' => $user['username'] ?? 'Misafir',
            'avatar' => $user['avatar'] ?? 'assets/logo.png',
            'data' => $data,
            'timestamp' => date('c'),
            'createdAt' => time() // For SSE numeric ID
        ];

        $this->db->saveItem('activities', $activity);
        return $activity;
    }

    protected function isAdmin() {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $role = $_SESSION['user_role'] ?? $_SESSION['user']['role'] ?? 'user';
        return $role === 'admin' || $role === 'technical';
    }
}
