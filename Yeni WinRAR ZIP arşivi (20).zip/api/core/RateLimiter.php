<?php
/**
 * DramiBox Rate Limiter - DDoS & Abuse Protection
 * File-based IP rate limiting middleware
 */
class RateLimiter {
    private $storageDir;
    
    // Rate limit rules: [maxRequests, windowSeconds]
    private $rules = [
        'general'    => [120, 60],    // 120 req/min for general
        'auth'       => [10,  60],    // 10 req/min for login/register
        'write'      => [30,  60],    // 30 req/min for write operations
        'search'     => [20,  60],    // 20 req/min for search
        'upload'     => [5,   60],    // 5 req/min for uploads
        'heavy'      => [10,  60],    // 10 req/min for database-export etc.
    ];
    
    // Actions mapped to rule categories
    private $actionCategories = [
        'login'              => 'auth',
        'register'           => 'auth',
        'auth-forgot'        => 'auth',
        'auth-reset'         => 'auth',
        'send-verification'  => 'auth',
        'write'              => 'write',
        'blog-save'          => 'write',
        'comment-submit'     => 'write',
        'actor-save'         => 'write',
        'message-send'       => 'write',
        'message-read-conversation' => 'write',
        'user-update'        => 'write',
        'check-session'      => 'general',
        'notif-create'       => 'write',
        'not-create'         => 'write',
        'req-add'            => 'write',
        'rep-submit'         => 'write',
        'faq-add'            => 'write',
        'faq-update'         => 'write',
        'calendar-save'      => 'write',
        'upload-video'       => 'upload',
        'search'             => 'search',
        'database-export'    => 'heavy',
        'encrypt-all-data'   => 'heavy',
        'log-export'         => 'heavy',
    ];
    
    // Permanently blocked IPs (loaded from config)
    private $blockedIPs = [];
    
    // Whitelisted IPs (never rate limited)
    private $whitelistedIPs = ['127.0.0.1', '::1'];
    
    public function __construct() {
        $this->storageDir = __DIR__ . '/../../data/rate_limits';
        if (!file_exists($this->storageDir)) {
            mkdir($this->storageDir, 0755, true);
        }
        
        // Load blocked IPs
        $blockedFile = __DIR__ . '/../../data/blocked_ips.json';
        if (file_exists($blockedFile)) {
            $data = json_decode(file_get_contents($blockedFile), true);
            $this->blockedIPs = $data ?: [];
        }
    }
    
    /**
     * Check if the current request is allowed
     * Returns true if allowed, sends 429 and exits if blocked
     */
    public function check($action = null) {
        // DDoS Protection disabled as per user request
        return true;

        $ip = $this->getClientIP();
        
        // Whitelisted?
        if (in_array($ip, $this->whitelistedIPs)) {
            return true;
        }
        
        // Permanently blocked?
        if ($this->isIPBlocked($ip)) {
            $this->block('IP kalıcı olarak engellenmiştir.', 0);
        }
        
        // Determine category
        $category = $this->actionCategories[$action] ?? 'general';
        list($maxRequests, $windowSeconds) = $this->rules[$category];
        
        // Get request log for this IP
        $logFile = $this->getLogFile($ip);
        $log = $this->readLog($logFile);
        
        // Clean old entries
        $now = time();
        $cutoff = $now - $windowSeconds;
        
        // Filter entries for this category
        $categoryKey = $category;
        if (!isset($log[$categoryKey])) {
            $log[$categoryKey] = [];
        }
        
        // Remove expired timestamps
        $log[$categoryKey] = array_values(array_filter($log[$categoryKey], function($ts) use ($cutoff) {
            return $ts > $cutoff;
        }));
        
        // Check if over limit
        $requestCount = count($log[$categoryKey]);
        
        if ($requestCount >= $maxRequests) {
            // Over limit!
            $retryAfter = $windowSeconds - ($now - min($log[$categoryKey]));
            
            // Log the violation
            $this->logViolation($ip, $action, $category, $requestCount);
            
            // Auto-block if way over limit (3x the limit = likely attack)
            if ($requestCount > $maxRequests * 3) {
                $this->addBlockedIP($ip, 'Auto-blocked: excessive requests (' . $requestCount . ' in ' . $windowSeconds . 's for ' . $category . ')');
            }
            
            $this->block('Çok fazla istek. Lütfen ' . max(1, $retryAfter) . ' saniye bekleyin.', max(1, $retryAfter));
        }
        
        // Record this request
        $log[$categoryKey][] = $now;
        $this->writeLog($logFile, $log);
        
        // Set rate limit headers
        header('X-RateLimit-Limit: ' . $maxRequests);
        header('X-RateLimit-Remaining: ' . max(0, $maxRequests - $requestCount - 1));
        header('X-RateLimit-Reset: ' . ($now + $windowSeconds));
        
        return true;
    }
    
    /**
     * Block the request with 429 Too Many Requests
     */
    private function block($message, $retryAfter) {
        http_response_code(429);
        header('Content-Type: application/json');
        header('Retry-After: ' . $retryAfter);
        echo json_encode([
            'success' => false,
            'error' => 'rate_limited',
            'message' => $message,
            'retryAfter' => $retryAfter
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * Get real client IP (handles proxies)
     */
    private function getClientIP() {
        $headers = [
            'HTTP_CF_CONNECTING_IP',  // Cloudflare
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR'
        ];
        
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ips = explode(',', $_SERVER[$header]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Get log file path for an IP
     */
    private function getLogFile($ip) {
        $safeIP = preg_replace('/[^a-zA-Z0-9._:-]/', '_', $ip);
        return $this->storageDir . '/' . $safeIP . '.json';
    }
    
    /**
     * Read log file
     */
    private function readLog($file) {
        if (!file_exists($file)) return [];
        $data = json_decode(file_get_contents($file), true);
        return is_array($data) ? $data : [];
    }
    
    /**
     * Write log file
     */
    private function writeLog($file, $data) {
        file_put_contents($file, json_encode($data), LOCK_EX);
    }
    
    /**
     * Check if IP is permanently blocked
     */
    private function isIPBlocked($ip) {
        foreach ($this->blockedIPs as $entry) {
            if ($entry['ip'] === $ip) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Add IP to permanent block list
     */
    public function addBlockedIP($ip, $reason = '') {
        // Check if already blocked
        foreach ($this->blockedIPs as $entry) {
            if ($entry['ip'] === $ip) return;
        }
        
        $this->blockedIPs[] = [
            'ip' => $ip,
            'reason' => $reason,
            'blockedAt' => date('Y-m-d H:i:s'),
            'timestamp' => time()
        ];
        
        $blockedFile = __DIR__ . '/../../data/blocked_ips.json';
        file_put_contents($blockedFile, json_encode($this->blockedIPs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    }
    
    /**
     * Remove IP from block list
     */
    public function removeBlockedIP($ip) {
        $this->blockedIPs = array_values(array_filter($this->blockedIPs, function($entry) use ($ip) {
            return $entry['ip'] !== $ip;
        }));
        
        $blockedFile = __DIR__ . '/../../data/blocked_ips.json';
        file_put_contents($blockedFile, json_encode($this->blockedIPs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    }
    
    /**
     * Get all blocked IPs
     */
    public function getBlockedIPs() {
        return $this->blockedIPs;
    }
    
    /**
     * Log a rate limit violation
     */
    private function logViolation($ip, $action, $category, $count) {
        $logFile = $this->storageDir . '/_violations.log';
        $entry = date('Y-m-d H:i:s') . " | IP: $ip | Action: $action | Category: $category | Count: $count\n";
        file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Cleanup expired rate limit files (call periodically)
     */
    public function cleanup() {
        $files = glob($this->storageDir . '/*.json');
        $now = time();
        $maxAge = 300; // 5 minutes
        
        foreach ($files as $file) {
            if (basename($file) === '_violations.log') continue;
            if (basename($file) === '../blocked_ips.json') continue;
            
            if (filemtime($file) < ($now - $maxAge)) {
                unlink($file);
            }
        }
    }
}
