<?php

class FilterService {
    // Basic array of forbidden words (profanity)
    private static $badWords = [
        'amk', 'aq', 'oç', 'piç', 'sik', 'yarak', 'yarrak', 'orospu', 
        'kahpe', 'göt', 'ibne', 'amına', 'sikerim', 'sikeyim', 'yavşak',
        'pic', 'oc', 'yarram'
    ];

    /**
     * Checks if text contains any bad words
     * Returns true if clean, false if dirty
     */
    public static function isClean($text) {
        $lowerText = mb_strtolower($text, 'UTF-8');
        
        // Remove common evasions
        $normalized = str_replace(['1','0','3','@','$','*','-','_','.'], ['i','o','e','a','s','','','',''], $lowerText);
        
        foreach (self::$badWords as $word) {
            // Check for exact word matches or substrings if needed
            // Word boundary might not be sufficient for Turkish suffixes, so we use strpos
            if (strpos($normalized, $word) !== false) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks if the user is currently banned from social features
     * Throws an exception or returns an error string if banned.
     */
    public static function checkBanStatus($user) {
        if (!$user) return null; // Guests are handled by other layers
        
        if (!empty($user['socialBanUntil'])) {
            $banUntil = (int)$user['socialBanUntil'];
            $now = time() * 1000; // js timestamp in ms
            
            if ($now < $banUntil) {
                $remainingMs = $banUntil - $now;
                $remainingHours = ceil($remainingMs / (1000 * 60 * 60));
                return "Sosyal özelliklerden banlandınız! Kural ihlali nedeniyle paylaşımlarınız geçici olarak engellendi. Kalan süre: yaklaşık {$remainingHours} saat.";
            }
        }
        return null;
    }

    /**
     * Handles a violation, increments count, applies ban if needed.
     */
    public static function handleViolation($userId, $db) {
        if (!$userId) return;

        $user = $db->getItemById('users', $userId);
        if (!$user) return;

        // Initialize violation tracking if not exists
        if (!isset($user['violations'])) {
            $user['violations'] = 0;
        }

        $user['violations']++;
        
        // Calculate ban if violations >= 5
        if ($user['violations'] >= 5) {
            // Violations:
            // 5 -> 6 hours
            // 6 -> 12 hours
            // 7 -> 24 hours
            // 8 -> 48 hours
            // etc.
            $baseViolations = $user['violations'] - 5;
            $hours = 6 * pow(2, $baseViolations);
            
            // Limit max ban to 30 days
            if ($hours > 720) $hours = 720;

            $now = time() * 1000;
            $banDurationMs = $hours * 60 * 60 * 1000;
            
            $user['socialBanUntil'] = $now + $banDurationMs;
        }

        $db->saveItem('users', $user);
        
        // Return information about the action taken
        if ($user['violations'] >= 5) {
            return "Kural ihlali! Uygunsuz kelime kullanımı nedeniyle {$hours} saat banlandınız.";
        } else {
            $remainingWarnings = 5 - $user['violations'];
            return "Uyarı! Uygunsuz kelime kullanımı tespit edildi. ({$remainingWarnings} uyarınız kaldı, aksi takdirde banlanacaksınız!)";
        }
    }
}
