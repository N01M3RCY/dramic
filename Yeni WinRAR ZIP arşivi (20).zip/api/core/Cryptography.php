<?php
/**
 * DramicBox Custom Cryptography System
 * Uses AES-256-GCM with unique salt and IV for each encryption
 * Only admins can decrypt data
 */

class Cryptography {
    // Secret key - unique to your installation
    // This should be kept secret and never exposed
    private static $masterKey = 'DramicBox_X9k2$Lm!Qp#Vn@Rw8_SecretKey2026';
    
    // Algorithm
    private static $cipher = 'aes-256-gcm';
    
    /**
     * Encrypt data with custom format
     * Returns base64 encoded string with embedded IV, salt, and tag
     */
    public static function encrypt($plaintext) {
        if (empty($plaintext)) return '';
        
        // Generate unique salt (16 bytes)
        $salt = random_bytes(16);
        
        // Generate unique IV (12 bytes for GCM)
        $iv = random_bytes(12);
        
        // Derive key from master key + salt using PBKDF2
        $key = hash_pbkdf2('sha256', self::$masterKey, $salt, 100000, 32, true);
        
        // Encrypt
        $tag = '';
        $ciphertext = openssl_encrypt(
            $plaintext,
            self::$cipher,
            $key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag,
            '',
            16 // tag length
        );
        
        if ($ciphertext === false) {
            return false;
        }
        
        // Combine: salt (16) + iv (12) + tag (16) + ciphertext
        $combined = $salt . $iv . $tag . $ciphertext;
        
        // Add signature prefix for identification
        $signature = 'DRMC'; // DRaMiC signature
        
        // Return base64 encoded with signature
        return $signature . base64_encode($combined);
    }
    
    /**
     * Decrypt data
     * Requires admin access
     */
    public static function decrypt($encrypted, $isAdmin = false) {
        if (empty($encrypted)) return '';
        
        // Check signature
        if (substr($encrypted, 0, 4) !== 'DRMC') {
            return ['success' => false, 'error' => 'Geçersiz şifreleme formatı'];
        }
        
        // Remove signature and decode
        $combined = base64_decode(substr($encrypted, 4));
        
        if ($combined === false || strlen($combined) < 44) {
            return ['success' => false, 'error' => 'Bozuk şifreli veri'];
        }
        
        // Extract components
        $salt = substr($combined, 0, 16);
        $iv = substr($combined, 16, 12);
        $tag = substr($combined, 28, 16);
        $ciphertext = substr($combined, 44);
        
        // Derive key
        $key = hash_pbkdf2('sha256', self::$masterKey, $salt, 100000, 32, true);
        
        // Decrypt
        $plaintext = openssl_decrypt(
            $ciphertext,
            self::$cipher,
            $key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag
        );
        
        if ($plaintext === false) {
            return ['success' => false, 'error' => 'Şifre çözme başarısız'];
        }
        
        return ['success' => true, 'data' => $plaintext];
    }
    
    /**
     * Encrypt sensitive user data
     */
    public static function encryptUserData($userData) {
        if (!is_array($userData)) return $userData;
        
        // Fields to encrypt
        $sensitiveFields = ['password', 'email', 'phone', 'ip_address', 'payment_info'];
        
        foreach ($sensitiveFields as $field) {
            if (isset($userData[$field]) && !empty($userData[$field])) {
                // Don't re-encrypt already encrypted data
                if (substr($userData[$field], 0, 4) !== 'DRMC') {
                    $userData[$field] = self::encrypt($userData[$field]);
                }
            }
        }
        
        return $userData;
    }
    
    /**
     * Decrypt user data for admin viewing
     */
    public static function decryptUserData($userData) {
        if (!is_array($userData)) return $userData;
        
        $sensitiveFields = ['password', 'email', 'phone', 'ip_address', 'payment_info'];
        
        foreach ($sensitiveFields as $field) {
            if (isset($userData[$field]) && substr($userData[$field], 0, 4) === 'DRMC') {
                $result = self::decrypt($userData[$field], true);
                if ($result['success']) {
                    $userData[$field] = $result['data'];
                }
            }
        }
        
        return $userData;
    }
    
    /**
     * Generate a dynamic admin access token
     * Changes every request to prevent URL sharing
     */
    public static function generateAccessToken() {
        $timestamp = time();
        $random = bin2hex(random_bytes(8));
        $hash = hash_hmac('sha256', $timestamp . $random, self::$masterKey);
        return substr($hash, 0, 16) . '-' . $timestamp . '-' . $random;
    }
    
    /**
     * Validate access token (valid for 5 minutes)
     */
    public static function validateAccessToken($token) {
        $parts = explode('-', $token);
        if (count($parts) !== 3) return false;
        
        list($hash, $timestamp, $random) = $parts;
        
        // Check if token is expired (5 minutes)
        if (time() - intval($timestamp) > 300) {
            return false;
        }
        
        // Verify hash
        $expectedHash = substr(hash_hmac('sha256', $timestamp . $random, self::$masterKey), 0, 16);
        return hash_equals($expectedHash, $hash);
    }
    
    /**
     * Analyze encrypted text and return metadata
     */
    public static function analyzeEncrypted($encrypted) {
        if (empty($encrypted)) {
            return ['valid' => false, 'error' => 'Boş veri'];
        }
        
        if (substr($encrypted, 0, 4) !== 'DRMC') {
            return ['valid' => false, 'error' => 'DramicBox şifrelemesi değil'];
        }
        
        $combined = base64_decode(substr($encrypted, 4));
        $length = strlen($combined);
        
        return [
            'valid' => true,
            'signature' => 'DRMC',
            'algorithm' => 'AES-256-GCM',
            'totalLength' => strlen($encrypted),
            'dataLength' => $length,
            'encryptedAt' => 'Bilinmiyor (meta-data yok)'
        ];
    }
}
