<?php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Cache.php';

class Database {
    private $pdo;
    private $data = []; // Kept for legacy compatibility
    private $lastError = null;
    
    public function getLastError() {
        return $this->lastError;
    }
    
    private $mapping = [
        'users' => 'users',
        'series' => 'series',
        'blogPosts' => 'blog_posts',
        'tickets' => 'tickets',
        'shorts' => 'shorts',
        'actors' => 'actors',
        'calendar' => 'events',
        'reports' => 'reports',
        'comments' => 'comments',
        'episodeComments' => 'episode_comments',
        'polls' => 'polls',
        'announcements' => 'announcements',
        'logs' => 'logs',
        'messages' => 'messages',
        'friendRequests' => 'friend_requests',
        'adminChat' => 'admin_chat',
        'settings' => 'settings',
        'faqs' => 'faqs',
        'notifications' => 'notifications',
        'watchParties' => 'watch_parties',
        'partyRooms' => 'watch_parties',
        'requests' => 'requests',
        'dmcaReports' => 'dmca_reports',
        'socialPosts' => 'social_posts',
        'webtoons' => 'webtoons',
        'heroSlides' => 'hero_slides',
        'shopItems' => 'shop_items',
        'premiumPackages' => 'premium_packages',
        'activities' => 'activities',
        'liveStreams' => 'live_streams',
        'liveChat' => 'live_chat'
    ];

    private $folderMapping = [
        'users' => 'kullanicilar',
        'series' => 'diziler',
        'blogPosts' => 'blog',
        'tickets' => 'tickets',
        'shorts' => 'shorts',
        'actors' => 'actors',
        'calendar' => 'etkinlikler',
        'reports' => 'raporlar',
        'comments' => 'yorumlar',
        'episodeComments' => 'bolum_yorumlari',
        'polls' => 'anketler',
        'announcements' => 'duyurular',
        'logs' => 'loglar',
        'messages' => 'messages',
        'friendRequests' => 'arkadaslik_istekleri',
        'adminChat' => 'admin_chat',
        'settings' => 'ayarlar',
        'faqs' => 'sss',
        'notifications' => 'bildirimler',
        'watchParties' => 'parti_odalari',
        'partyRooms' => 'parti_odalari',
        'requests' => 'istekler',
        'dmcaReports' => 'dmca_reports',
        'webtoons' => 'webtoons',
        'heroSlides' => 'hero_slaytlar',
        'shopItems' => 'market_urunleri',
        'premiumPackages' => 'premium_paketler',
        'activities' => 'aktiviteler',
        'socialPosts' => 'socialhub'
    ];

    public function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (\Throwable $e) {
             // If DB connection fails, gracefully log and remain offline
             error_log("Database connection failed: " . $e->getMessage());
             $this->lastError = $e->getMessage();
             $this->pdo = null;
        }
    }

    public function getPdo() {
        return $this->pdo;
    }

    public function load() {
        return $this->exportAll();
    }

    public function getData($forceReload = false) {
        return $this->exportAll();
    }

    public function loadCollections($collections) {
        $data = [];
        foreach ($collections as $key) {
            $data[$key] = $this->getCollection($key);
        }
        return $data;
    }

    public function exportAll() {
        $allData = [];
        foreach ($this->mapping as $key => $table) {
            $allData[$key] = $this->getCollection($key);
        }
        return $allData;
    }

    public function getCollection($key, $limit = null) {
        if ($this->pdo) {
            $table = $this->mapping[$key] ?? $key;
            try {
                $sql = "SELECT data FROM $table";
                if ($limit) $sql .= " ORDER BY created_at DESC LIMIT " . intval($limit);
                
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute();
                
                $items = [];
                while ($row = $stmt->fetch()) {
                    $items[] = json_decode($row['data'], true);
                }
                if (!empty($items)) {
                    return $items;
                }
            } catch (\Throwable $e) {
                error_log("Database getCollection failed for table $table: " . $e->getMessage());
            }
        }
        // Fallback to JSON File database
        return $this->getFileCollection($key, $limit);
    }

    public function getItemById($collectionKey, $id) {
        if ($this->pdo) {
            $table = $this->mapping[$collectionKey] ?? $collectionKey;
            try {
                // Using id_val which is the PRIMARY KEY and much faster
                $stmt = $this->pdo->prepare("SELECT data FROM $table WHERE id_val = ?");
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                
                if ($row) {
                    return json_decode($row['data'], true);
                }
            } catch (\Throwable $e) {
                error_log("getItemById Error: " . $e->getMessage());
            }
        }
        // Fallback to JSON File database
        return $this->getFileItemById($collectionKey, $id);
    }
    public function saveItem($collectionKey, $item, $idField = 'id') {
        if ($collectionKey === 'actors' && $idField === 'id') $idField = 'name';
        
        $idValue = $item[$idField] ?? null;
        if (!$idValue) return false;

        if ($this->pdo) {
            $table = $this->mapping[$collectionKey] ?? $collectionKey;
            $jsonData = json_encode($item, JSON_UNESCAPED_UNICODE);
            try {
                // Upsert logic (Insert or Update)
                $sql = "INSERT INTO $table (id_val, data) VALUES (:id, :data) 
                        ON DUPLICATE KEY UPDATE data = :data_update";
                
                $stmt = $this->pdo->prepare($sql);
                return $stmt->execute([
                    'id' => $idValue,
                    'data' => $jsonData,
                    'data_update' => $jsonData
                ]);
            } catch (\Throwable $e) {
                $this->lastError = $e->getMessage();
                
                $isNotExist = (strpos($e->getMessage(), "doesn't exist") !== false);
                $isColumnMismatch = (strpos($e->getMessage(), "Unknown column") !== false || 
                                     strpos($e->getMessage(), "doesn't have a default value") !== false ||
                                     strpos($e->getMessage(), "Incorrect table definition") !== false);
                
                if ($isNotExist || $isColumnMismatch) {
                    try {
                        if ($isColumnMismatch) {
                            $this->dropTable($table);
                        }
                        $this->createTable($table);
                        $stmt = $this->pdo->prepare("INSERT INTO $table (id_val, data) VALUES (:id, :data) 
                                                     ON DUPLICATE KEY UPDATE data = :data_update");
                        return $stmt->execute([
                            'id' => $idValue,
                            'data' => $jsonData,
                            'data_update' => $jsonData
                        ]);
                    } catch (\Throwable $e2) {
                        $this->lastError = $e2->getMessage();
                        error_log("Save Item Table Creation/Insert failed: " . $e2->getMessage());
                    }
                } else {
                    error_log("Save Item Error: " . $e->getMessage());
                }
            }
        }
        // Fallback to JSON File database
        return $this->saveFileItem($collectionKey, $item, $idField);
    }

    public function deleteFromCollection($collectionKey, $id) {
        if ($this->pdo) {
            $table = $this->mapping[$collectionKey] ?? $collectionKey;
            try {
                $stmt = $this->pdo->prepare("DELETE FROM $table WHERE id_val = ?");
                return $stmt->execute([$id]);
            } catch (\Throwable $e) {
                error_log("deleteFromCollection Error: " . $e->getMessage());
            }
        }
        // Fallback to JSON File database
        return $this->deleteFileItem($collectionKey, $id);
    }

    private function dropTable($table) {
        if (!$this->pdo) return;
        try {
            $this->pdo->exec("DROP TABLE IF EXISTS `$table` CASCADE;");
        } catch (\Throwable $e) {
            error_log("dropTable Error: " . $e->getMessage());
        }
    }

    private function createTable($table) {
        if (!$this->pdo) return;
        // Safe creation with LONGTEXT fallback for older MySQL/MariaDB often found on InfinityFree
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id_val VARCHAR(255) PRIMARY KEY,
            data LONGTEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
        
        $this->pdo->exec($sql);
    }

    // Proxy for other methods to avoid breaking existing code
    public function saveCollection($key, $items) {
        foreach ($items as $item) {
            $this->saveItem($key, $item);
        }
        return true;
    }

    public function saveData($allData) {
        if (!is_array($allData)) return false;
        foreach ($allData as $key => $items) {
            if (is_array($items)) {
                $this->saveCollection($key, $items);
            }
        }
        return true;
    }

    public function addToCollection($key, $item) {
        return $this->saveItem($key, $item);
    }

    public function getItem($key, $id) {
        return $this->getItemById($key, $id);
    }

    public function deleteItem($key, $id) {
        return $this->deleteFromCollection($key, $id);
    }

    public function updateInCollection($key, $id, $updates) {
        $item = $this->getItemById($key, $id);
        if ($item) {
            $item = array_merge($item, $updates);
            return $this->saveItem($key, $item);
        }
        return false;
    }

    public function fetchAll($sql, $params = []) {
        if ($this->pdo) {
            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($params);
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $items = [];
                foreach ($results as $row) {
                    if (isset($row['data'])) {
                        $items[] = json_decode($row['data'], true);
                    } else {
                        $items[] = $row;
                    }
                }
                return $items;
            } catch (\Throwable $e) {
                error_log("DB FetchAll Error: " . $e->getMessage());
            }
        }

        // File-based fallback for fetchAll:
        // Try to parse the table name from SQL query
        $collectionKey = 'socialPosts'; // default fallback
        foreach ($this->mapping as $key => $table) {
            if (stripos($sql, $table) !== false) {
                $collectionKey = $key;
                break;
            }
        }
        
        return $this->getFileCollection($collectionKey);
    }

    public function fetchOne($sql, $params = []) {
        if ($this->pdo) {
            try {
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute($params);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row && isset($row['data'])) {
                    return json_decode($row['data'], true);
                }
                return $row;
            } catch (\Throwable $e) {
                error_log("DB FetchOne Error: " . $e->getMessage());
            }
        }

        // File-based fallback for fetchOne:
        $collectionKey = 'settings';
        foreach ($this->mapping as $key => $table) {
            if (stripos($sql, $table) !== false) {
                $collectionKey = $key;
                break;
            }
        }
        
        if (!empty($params)) {
            $id = reset($params);
            $item = $this->getFileItemById($collectionKey, $id);
            if ($item) return $item;
        }
        
        $items = $this->getFileCollection($collectionKey);
        return !empty($items) ? $items[0] : null;
    }

    // ==========================================
    // JSON FILE-BASED BACKEND IMPLEMENTATION
    // ==========================================

    private function getFileCollection($collectionKey, $limit = null) {
        $folder = $this->folderMapping[$collectionKey] ?? $collectionKey;
        $dir = __DIR__ . '/../../Database/' . $folder . '/';
        $items = [];
        
        if (file_exists($dir)) {
            $files = glob($dir . '*.json');
            foreach ($files as $file) {
                $filename = basename($file);
                if ($filename === 'hub.json') {
                    $content = json_decode(file_get_contents($file), true);
                    if ($content && isset($content[$collectionKey]) && is_array($content[$collectionKey])) {
                        $items = array_merge($items, $content[$collectionKey]);
                    }
                    continue;
                }
                if ($filename === 'global.json') continue;
                
                $content = json_decode(file_get_contents($file), true);
                if ($content) {
                    $items[] = $content;
                }
            }
        }
        
        // Custom sorting for specific collections
        if ($collectionKey === 'socialPosts' || $collectionKey === 'blogPosts') {
            usort($items, function($a, $b) {
                $ta = isset($a['createdAt']) ? strtotime($a['createdAt']) : 0;
                $tb = isset($b['createdAt']) ? strtotime($b['createdAt']) : 0;
                return $tb - $ta; // descending
            });
        }
        
        if ($limit) {
            $items = array_slice($items, 0, intval($limit));
        }
        return $items;
    }

    private function getFileItemById($collectionKey, $id) {
        $folder = $this->folderMapping[$collectionKey] ?? $collectionKey;
        $dir = __DIR__ . '/../../Database/' . $folder . '/';
        
        $safeId = preg_replace('/[^a-zA-Z0-9_\-]/', '', $id);
        
        // Standard naming conventions
        $paths = [
            $dir . $safeId . '.json',
            $dir . $collectionKey . '-' . $safeId . '.json',
            $dir . 'user-' . $safeId . '.json',
            $dir . 'room-' . $safeId . '.json'
        ];
        
        foreach ($paths as $path) {
            if (file_exists($path)) {
                return json_decode(file_get_contents($path), true);
            }
        }
        
        // Scan directory fallback
        if (file_exists($dir)) {
            $files = glob($dir . '*.json');
            foreach ($files as $file) {
                if (basename($file) === 'hub.json' || basename($file) === 'global.json') continue;
                $item = json_decode(file_get_contents($file), true);
                if ($item) {
                    $idField = ($collectionKey === 'actors') ? 'name' : 'id';
                    if (isset($item[$idField]) && (string)$item[$idField] === (string)$id) {
                        return $item;
                    }
                }
            }
        }
        return null;
    }

    private function saveFileItem($collectionKey, $item, $idField = 'id') {
        $folder = $this->folderMapping[$collectionKey] ?? $collectionKey;
        $dir = __DIR__ . '/../../Database/' . $folder . '/';
        
        if (!file_exists($dir)) {
            @mkdir($dir, 0755, true);
        }
        
        if ($collectionKey === 'actors' && $idField === 'id') $idField = 'name';
        $idValue = $item[$idField] ?? null;
        if (!$idValue) return false;
        
        $safeId = preg_replace('/[^a-zA-Z0-9_\-]/', '', $idValue);
        
        $filename = $safeId . '.json';
        if ($collectionKey === 'users') {
            $filename = 'user-' . $safeId . '.json';
        } else if ($collectionKey === 'watchParties' || $collectionKey === 'partyRooms') {
            $filename = 'room-' . $safeId . '.json';
        }
        
        $path = $dir . $filename;
        $jsonData = json_encode($item, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        return @file_put_contents($path, $jsonData) !== false;
    }

    private function deleteFileItem($collectionKey, $id) {
        $folder = $this->folderMapping[$collectionKey] ?? $collectionKey;
        $dir = __DIR__ . '/../../Database/' . $folder . '/';
        
        $safeId = preg_replace('/[^a-zA-Z0-9_\-]/', '', $id);
        
        $paths = [
            $dir . $safeId . '.json',
            $dir . $collectionKey . '-' . $safeId . '.json',
            $dir . 'user-' . $safeId . '.json',
            $dir . 'room-' . $safeId . '.json'
        ];
        
        $deleted = false;
        foreach ($paths as $path) {
            if (file_exists($path)) {
                if (@unlink($path)) $deleted = true;
            }
        }
        
        if (!$deleted && file_exists($dir)) {
            $files = glob($dir . '*.json');
            foreach ($files as $file) {
                if (basename($file) === 'hub.json' || basename($file) === 'global.json') continue;
                $item = json_decode(file_get_contents($file), true);
                if ($item) {
                    $idField = ($collectionKey === 'actors') ? 'name' : 'id';
                    if (isset($item[$idField]) && (string)$item[$idField] === (string)$id) {
                        if (@unlink($file)) $deleted = true;
                    }
                }
            }
        }
        return $deleted;
    }
}
