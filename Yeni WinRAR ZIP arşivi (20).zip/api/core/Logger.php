<?php
/**
 * DRAMICBOX - MODERN LOGGER (MySQL Version)
 * Version: 2.0
 */

require_once __DIR__ . '/Database.php';

class Logger {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    /**
     * Log a system activity to MySQL
     */
    public function log($action, $userId = null, $username = 'System', $details = []) {
        $entry = [
            'id' => uniqid('log_'),
            'timestamp' => time(),
            'date' => date('Y-m-d H:i:s'),
            'action' => $action,
            'userId' => $userId,
            'username' => $username,
            'details' => $details,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
            'userAgent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
        ];

        // Save to 'logs' collection in MySQL
        return $this->db->saveItem('logs', $entry);
    }

    /**
     * Get logs (filtered by month/date if needed, but MySQL handles large data better)
     */
    public function getLogs($month = null, $limit = 1000) {
        // In MySQL version, we just get the 'logs' collection
        // Optional: filter by month using SQL (but Base Database doesn't support complex filters yet)
        return $this->db->getCollection('logs', $limit);
    }
}
