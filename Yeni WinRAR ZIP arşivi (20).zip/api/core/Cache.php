<?php
/**
 * Simple File-Based Caching System for DramicBox
 */
class Cache {
    private static $cacheDir = __DIR__ . '/../../Database/cache/';
    private static $ttl = 300; // Default 5 minutes

    public static function init() {
        if (!is_dir(self::$cacheDir)) {
            mkdir(self::$cacheDir, 0755, true);
        }
    }

    public static function get($key) {
        $file = self::$cacheDir . md5($key) . '.cache';
        if (file_exists($file)) {
            $data = json_decode(file_get_contents($file), true);
            if ($data['expiry'] > time()) {
                return $data['content'];
            }
            unlink($file); // Expired
        }
        return null;
    }

    public static function set($key, $content, $customTtl = null) {
        self::init();
        $file = self::$cacheDir . md5($key) . '.cache';
        $data = [
            'expiry' => time() + ($customTtl ?? self::$ttl),
            'content' => $content
        ];
        return file_put_contents($file, json_encode($data)) !== false;
    }

    public static function delete($key) {
        $file = self::$cacheDir . md5($key) . '.cache';
        if (file_exists($file)) unlink($file);
    }

    public static function clear() {
        if (!is_dir(self::$cacheDir)) return;
        $files = glob(self::$cacheDir . '*.cache');
        foreach ($files as $file) unlink($file);
    }
}
