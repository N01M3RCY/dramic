<?php

class SMTPMailer {
    private $host;
    private $port;
    private $username;
    private $password;
    private $timeout = 15;
    private $debug = true; // Always log errors for diagnosis
    private $socket;
    private $lastError = '';

    public function __construct($host, $port, $username, $password) {
        $this->host = $host;
        $this->port = $port;
        $this->username = $username;
        $this->password = $password;
    }

    public function getLastError() {
        return $this->lastError;
    }

    public function send($to, $subject, $body, $fromName = 'DramicBox') {
        // Attempt 1: Direct SMTP
        $hosts = [$this->host];
        
        foreach ($hosts as $currentHost) {
            try {
                $result = $this->trySMTP($currentHost, $to, $subject, $body, $fromName);
                if ($result) return true;
            } catch (Exception $e) {
                $this->lastError = "SMTP ($currentHost): " . $e->getMessage();
                $this->log("Host {$currentHost} failed: " . $e->getMessage());
                if ($this->socket) {
                    @fclose($this->socket);
                    $this->socket = null;
                }
            }
        }
        
        // Attempt 2: PHP mail() fallback
        try {
            $headers  = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type: text/html; charset=UTF-8\r\n";
            $headers .= "From: $fromName <{$this->username}>\r\n";
            $headers .= "X-Mailer: DramicBox Fallback\r\n";
            
            $sent = @mail($to, $subject, $body, $headers);
            if ($sent) {
                $this->log("Fallback mail() succeeded for $to");
                return true;
            }
            $this->lastError .= " | Fallback mail() also failed.";
        } catch (Exception $e) {
            $this->lastError .= " | Fallback error: " . $e->getMessage();
        }
        
        error_log("DramicBox SMTP Error: All mail attempts failed for $to. Details: " . $this->lastError);
        return false;
    }

    private function trySMTP($currentHost, $to, $subject, $body, $fromName) {
        // 1. Connect
        $protocol = ($this->port == 465) ? 'ssl://' : 'tcp://';
        $server = $protocol . $currentHost;
        
        $this->log("Connecting to $server on port {$this->port}...");
        
        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true,
                'crypto_method' => STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_SSLv23_CLIENT
            ]
        ]);
        
        $this->socket = @stream_socket_client(
            $server . ':' . $this->port,
            $errno,
            $errstr,
            $this->timeout,
            STREAM_CLIENT_CONNECT,
            $context
        );
        
        if (!$this->socket) {
            throw new Exception("Connection failed: $errno - $errstr");
        }
        
        // Set socket timeout
        stream_set_timeout($this->socket, $this->timeout);
        
        $greeting = $this->read(); // Server greeting
        if (!$greeting) {
            throw new Exception("No server greeting received");
        }

        // 2. EHLO handshake
        $ehloResponse = $this->cmd('EHLO ' . ($_SERVER['SERVER_NAME'] ?? gethostname() ?? 'dramicbox.com'));
        
        // 3. STARTTLS if port 587
        if ($this->port == 587 && strpos($ehloResponse, 'STARTTLS') !== false) {
            $this->cmd('STARTTLS');
            $crypto = @stream_socket_enable_crypto($this->socket, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT);
            if (!$crypto) {
                throw new Exception("STARTTLS handshake failed");
            }
            $this->cmd('EHLO ' . ($_SERVER['SERVER_NAME'] ?? gethostname() ?? 'dramicbox.com'));
        }
        
        // 4. AUTH LOGIN
        $authResponse = $this->cmd('AUTH LOGIN');
        // Server should respond with 334 (continue)
        
        $userResponse = $this->cmd(base64_encode($this->username));
        $passResponse = $this->cmd(base64_encode($this->password));

        // 5. MAIL FROM / RCPT TO
        $this->cmd("MAIL FROM: <{$this->username}>");
        $this->cmd("RCPT TO: <$to>");

        // 6. DATA
        $this->cmd('DATA');
        
        // 7. Headers & Body — DATA content ends with \r\n.\r\n
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: $fromName <{$this->username}>\r\n";
        $headers .= "To: $to\r\n";
        $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
        $headers .= "X-Mailer: DramicBox SMTP v2\r\n";
        $headers .= "Date: " . date('r') . "\r\n";
        $headers .= "Message-ID: <" . uniqid('dbox_') . "@" . ($this->host) . ">\r\n";
        
        // Write headers + body + terminator
        $content = "$headers\r\n$body\r\n.";
        $this->cmd($content);

        // 8. QUIT
        $this->cmd('QUIT');
        @fclose($this->socket);
        $this->socket = null;
        
        return true;
    }

    private function cmd($command) {
        if (!$this->socket || feof($this->socket)) {
            throw new Exception("Socket connection lost");
        }
        
        $this->log("C > " . (strlen($command) > 100 ? substr($command, 0, 100) . '...' : $command));
        $written = @fputs($this->socket, $command . "\r\n");
        if ($written === false) {
            throw new Exception("Failed to write to socket");
        }
        return $this->read();
    }

    private function read() {
        if (!$this->socket || feof($this->socket)) {
            throw new Exception("Socket connection lost during read");
        }
        
        $response = '';
        $startTime = time();
        
        while ($str = @fgets($this->socket, 515)) {
            $response .= $str;
            // Multi-line response check: if 4th char is space, this is the last line
            if (strlen($str) >= 4 && substr($str, 3, 1) == ' ') break;
            // Timeout safety
            if ((time() - $startTime) > $this->timeout) {
                throw new Exception("Read timeout exceeded");
            }
        }
        
        if (empty($response)) {
            // Check for stream timeout
            $info = @stream_get_meta_data($this->socket);
            if ($info && $info['timed_out']) {
                throw new Exception("Socket read timed out");
            }
            return '';
        }
        
        $this->log("S < " . trim($response));
        
        // Check response code - codes >= 400 are errors, EXCEPT during DATA content
        $code = intval(substr($response, 0, 3));
        if ($code >= 400) {
            throw new Exception("Server error ($code): " . trim($response));
        }
        
        return $response;
    }

    private function log($msg) {
        if ($this->debug) {
            error_log("[DramicBox SMTP] " . $msg);
        }
    }
}
?>
