<?php

class GamificationManager {
    /**
     * Ranks based on level
     */
    private static $ranks = [
        1 => 'Stajyer Çevirmen',
        3 => 'Kadrolu Çevirmen',
        6 => 'Uzman Çevirmen',
        10 => 'Efsanevi Çevirmen'
    ];

    /**
     * Calculate Level from XP
     */
    public static function getLevel($xp) {
        return floor(sqrt($xp / 50)) + 1;
    }

    /**
     * Get Rank title from Level
     */
    public static function getRank($level) {
        $currentRank = 'Çevirmen';
        foreach (self::$ranks as $lvl => $title) {
            if ($level >= $lvl) {
                $currentRank = $title;
            }
        }
        return $currentRank;
    }

    /**
     * Update Creator Stats for a user
     */
    public static function awardCreatorXP(&$userData, $amount) {
        if (!isset($userData['creatorStats'])) {
            $userData['creatorStats'] = [
                'xp' => 0,
                'level' => 1,
                'rank' => 'Stajyer Çevirmen',
                'totalSources' => 0,
                'reportsFixed' => 0
            ];
        }

        $oldLevel = $userData['creatorStats']['level'] ?? 1;
        $userData['creatorStats']['xp'] += $amount;
        
        $newLevel = self::getLevel($userData['creatorStats']['xp']);
        $userData['creatorStats']['level'] = $newLevel;
        $userData['creatorStats']['rank'] = self::getRank($newLevel);

        return [
            'leveledUp' => ($newLevel > $oldLevel),
            'newLevel' => $newLevel,
            'newRank' => $userData['creatorStats']['rank'],
            'xpGained' => $amount
        ];
    }
}
