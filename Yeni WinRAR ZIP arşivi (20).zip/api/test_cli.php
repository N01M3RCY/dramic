<?php
// DRAMICBOX CLI DATABASE DIAGNOSTIC
require_once 'config.php';

echo "=== DramicBox CLI Database Connection Check ===\n";
echo "Host: " . DB_HOST . "\n";
echo "Database: " . DB_NAME . "\n";
echo "User: " . DB_USER . "\n";
echo "----------------------------------------------\n";

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT            => 5,
    ];
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    echo "✅ SUCCESS: Connected to MySQL database successfully!\n\n";
    
    // Check tables
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "Mevcut Tablolar (Tables):\n";
    if (empty($tables)) {
        echo "⚠️ WARNING: No tables found. You need to run migration!\n";
    } else {
        foreach ($tables as $table) {
            $countStmt = $pdo->query("SELECT COUNT(*) FROM $table");
            $count = $countStmt->fetchColumn();
            echo "  - $table ($count rows)\n";
        }
    }
} catch (PDOException $e) {
    echo "❌ ERROR: Database connection failed!\n";
    echo "Error Message: " . $e->getMessage() . "\n";
    echo "Error Code: " . $e->getCode() . "\n\n";
    echo "Suggested Actions:\n";
    echo "1. Verify DB_NAME, DB_USER, and DB_PASS in public/api/config.php\n";
    echo "2. Make sure you added DB_USER to DB_NAME with ALL PRIVILEGES in cPanel -> MySQL Databases.\n";
    echo "3. Ensure DB_HOST is set to 'localhost'.\n";
}
echo "==============================================\n";
?>
