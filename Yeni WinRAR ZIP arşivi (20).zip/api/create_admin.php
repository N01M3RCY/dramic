<?php
require_once 'config.php';
require_once 'core/Database.php';

// Display errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

$db = new Database();

// Define admin user data
$adminUser = [
    'id' => '10001',
    'username' => 'admin',
    'email' => 'admin@dramicbox.com',
    'password' => 'Zumran1514!', 
    'role' => 'admin',
    'badges' => ['Admin', 'Kurucu'],
    'stats' => ['xp' => 100, 'level' => 10, 'coins' => 9999],
    'createdAt' => date('c'),
    'joinedAt' => date('c')
];

try {
    // Check if users collection exists and if admin exists
    $users = $db->getCollection('users');
    $exists = false;
    
    if (is_array($users)) {
        foreach($users as $u) {
            if(isset($u['username']) && strtolower($u['username']) === 'admin') {
                $exists = true;
                break;
            }
        }
    }

    if(!$exists) {
        $db->saveItem('users', $adminUser);
        echo "<h1>✅ Admin Hesabı Oluşturuldu!</h1>";
        echo "<div style='background: #f0fdf4; padding: 20px; border: 1px solid #16a34a; border-radius: 12px; font-family: sans-serif;'>";
        echo "<p><b>Kullanıcı Adı:</b> admin</p>";
        echo "<p><b>Şifre:</b> Zumran1514!</p>";
        echo "<p>Artık bu bilgilerle siteye giriş yapabilirsin. Giriş yaptıktan sonra yaptığın tüm paylaşımlar veritabanına kaydedilecektir.</p>";
        echo "</div>";
    } else {
        // If the admin already exists, update the password to the requested one
        $adminToUpdate = null;
        foreach($users as $u) {
            if(isset($u['username']) && strtolower($u['username']) === 'admin') {
                $adminToUpdate = $u;
                break;
            }
        }
        if ($adminToUpdate) {
            $adminToUpdate['password'] = 'Zumran1514!';
            $db->saveItem('users', $adminToUpdate);
        }
        echo "<h1>ℹ️ Admin hesabı zaten mevcuttu, şifresi güncellendi.</h1>";
        echo "<div style='background: #f0fdf4; padding: 20px; border: 1px solid #16a34a; border-radius: 12px; font-family: sans-serif;'>";
        echo "<p><b>Kullanıcı Adı:</b> admin</p>";
        echo "<p><b>Güncellenen Şifre:</b> Zumran1514!</p>";
        echo "<p>Giriş bilgileriniz başarıyla güncellenmiştir.</p>";
        echo "</div>";
    }
    
    echo "<p><a href='../#/home' style='color: blue; text-decoration: none;'>← Siteye Dön</a></p>";

} catch (Exception $e) {
    echo "<h1>❌ Hata Oluştu!</h1>";
    echo "<p>" . $e->getMessage() . "</p>";
}
?>
