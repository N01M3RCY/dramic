<?php
require_once 'config.php';
require_once 'core/Database.php';

// Display errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

$db = new Database();
$userDir = __DIR__ . '/../Database/kullanicilar';

echo "<html><body style='font-family: sans-serif; padding: 40px; background: #f8fafc;'>";
echo "<div style='max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.05);'>";
echo "<h1 style='color: #1e293b; margin-top: 0;'>📁 Kullanıcı Taşıma Sistemi</h1>";

if (!is_dir($userDir)) {
    echo "<div style='padding: 20px; background: #fef2f2; border: 1px solid #ef4444; border-radius: 12px; color: #b91c1c;'>";
    echo "❌ Hata: <b>$userDir</b> klasörü sunucuda bulunamadı!<br>";
    echo "Lütfen klasörün var olduğundan ve içinde .json dosyaları olduğundan emin ol.";
    echo "</div>";
    die();
}

$files = glob($userDir . '/*.json');
echo "<p style='color: #64748b;'>Toplam <b>" . count($files) . "</b> dosya bulundu. MySQL veritabanına aktarılıyor...</p><hr style='border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;'>";

$successCount = 0;
$failCount = 0;

echo "<div style='max-height: 300px; overflow-y: auto; padding: 10px; background: #f1f5f9; border-radius: 10px; font-size: 0.9rem;'>";
foreach ($files as $file) {
    $content = file_get_contents($file);
    $userData = json_decode($content, true);

    if ($userData && (isset($userData['username']) || isset($userData['id']))) {
        // Ensure id exists
        if (!isset($userData['id'])) $userData['id'] = basename($file, '.json');
        
        // MySQL'e kaydet
        if ($db->saveItem('users', $userData)) {
            echo "<span style='color: #16a34a;'>✅ Taşındı:</span> " . ($userData['username'] ?? $userData['id']) . "<br>";
            $successCount++;
        } else {
            echo "<span style='color: #dc2626;'>❌ Hata:</span> " . ($userData['username'] ?? $userData['id']) . " kaydedilemedi!<br>";
            $failCount++;
        }
    }
}
echo "</div>";

echo "<div style='margin-top: 30px; padding: 20px; background: #f0fdf4; border-radius: 12px; border: 1px solid #16a34a;'>";
echo "<h3 style='color: #166534; margin-top: 0;'>🎉 İşlem Tamamlandı!</h3>";
echo "<p style='margin-bottom: 0;'><b>$successCount</b> kullanıcı başarıyla MySQL veritabanına aktarıldı.</p>";
if ($failCount > 0) echo "<p style='color: #dc2626;'><b>$failCount</b> kullanıcı aktarılamadı.</p>";
echo "</div>";

echo "<p style='text-align: center; margin-top: 30px;'><a href='../#/home' style='display: inline-block; padding: 12px 24px; background: #3b82f6; color: white; text-decoration: none; border-radius: 10px; font-weight: bold;'>Siteye Dön ve Giriş Yap</a></p>";
echo "</div></body></html>";
?>
