// ============================================
// WEBTOON UPLOAD MODAL
// Multi-image upload for webtoon episodes
// ============================================

const WebtoonUploadModal = {
    currentWebtoonId: null,
    currentWebtoon: null,
    uploadMode: null, // 'url' or 'upload'
    uploadedPages: [],
    coverImage: null,

    show(webtoonId) {
        this.currentWebtoonId = webtoonId;
        this.currentWebtoon = State.data.webtoons?.find(w => w.id === webtoonId);
        this.uploadMode = null;

        if (!this.currentWebtoon) {
            Toast.error('Webtoon bulunamadı');
            return;
        }

        this.uploadedPages = [];
        this.coverImage = null;
        this.renderModeSelection();
    },

    renderModeSelection() {
        const modal = document.createElement('div');
        modal.id = 'webtoon-upload-modal';
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="webtoon-upload-modal mode-selection">
                <div class="modal-header">
                    <h2>
                        <i class="fa-solid fa-book"></i>
                        Webtoon Bölüm Ekle - ${this.currentWebtoon.title}
                    </h2>
                    <button class="modal-close" onclick="WebtoonUploadModal.close()">
                        <i class="fa-solid fa-times"></i>
                    </button>
                </div>
                
                <div class="modal-body">
                    <h3 style="text-align: center; color: #e2e8f0; margin-bottom: 24px;">
                        Ekleme yöntemini seçin:
                    </h3>
                    
                    <div class="mode-selection-buttons">
                        <button class="mode-btn" onclick="WebtoonUploadModal.selectMode('url')">
                            <i class="fa-solid fa-link"></i>
                            <h4>URL ile Ekle</h4>
                            <p>Webtoon sayfalarını URL ile ekle</p>
                        </button>
                        
                        <button class="mode-btn" onclick="WebtoonUploadModal.selectMode('upload')">
                            <i class="fa-solid fa-upload"></i>
                            <h4>Resim Yükle</h4>
                            <p>Bilgisayarınızdan JPEG/PNG yükle</p>
                        </button>
                    </div>
                </div>
                
                <style>
                    .mode-selection-buttons {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        gap: 20px;
                        padding: 20px;
                    }
                    
                    .mode-btn {
                        background: linear-gradient(135deg, rgba(236, 72, 153, 0.1), rgba(139, 92, 246, 0.1));
                        border: 2px solid rgba(236, 72, 153, 0.3);
                        border-radius: 12px;
                        padding: 32px 24px;
                        cursor: pointer;
                        transition: all 0.3s;
                        text-align: center;
                    }
                    
                    .mode-btn:hover {
                        background: linear-gradient(135deg, rgba(236, 72, 153, 0.2), rgba(139, 92, 246, 0.2));
                        border-color: #ec4899;
                        transform: translateY(-4px);
                        box-shadow: 0 8px 24px rgba(236, 72, 153, 0.3);
                    }
                    
                    .mode-btn i {
                        font-size: 48px;
                        color: #ec4899;
                        margin-bottom: 16px;
                    }
                    
                    .mode-btn h4 {
                        color: #e2e8f0;
                        margin: 0 0 8px 0;
                        font-size: 18px;
                    }
                    
                    .mode-btn p {
                        color: #94a3b8;
                        margin: 0;
                        font-size: 13px;
                    }
                </style>
            </div>
        `;

        document.body.appendChild(modal);
    },

    selectMode(mode) {
        this.uploadMode = mode;

        // Remove mode selection modal
        const modal = document.getElementById('webtoon-upload-modal');
        if (modal) modal.remove();

        // Show appropriate form or redirect
        if (mode === 'url') {
            this.renderUrlForm();
        } else {
            this.renderUploadForm();
        }
    },

    renderUrlForm() {
        // TODO: URL form for webtoon pages
        Toast.info('URL ekleme yakında...');
    },

    renderUploadForm() {
        const modal = document.createElement('div');
        modal.id = 'webtoon-upload-modal';
        modal.className = 'modal-overlay';
        modal.innerHTML = `
    < div class="webtoon-upload-modal" >
                <div class="modal-header">
                    <h2>
                        <i class="fa-solid fa-book"></i>
                        Webtoon Bölüm Yükle - ${this.currentWebtoon.title}
                    </h2>
                    <button class="modal-close" onclick="WebtoonUploadModal.close()">
                        <i class="fa-solid fa-times"></i>
                    </button>
                </div>
                
                <div class="modal-body">
                    <!-- Episode Info -->
                    <div class="form-group">
                        <label>Bölüm Numarası</label>
                        <input type="number" id="wt-episode-number" class="form-input" 
                               placeholder="1" min="1">
                    </div>
                    
                    <div class="form-group">
                        <label>Bölüm Adı (Opsiyonel)</label>
                        <input type="text" id="wt-episode-title" class="form-input" 
                               placeholder="İlk Karşılaşma">
                    </div>
                    
                    <!-- Page Upload -->
                    <div class="form-group">
                        <label>Sayfalar (JPEG, PNG, WEBP)</label>
                        <div class="upload-zone" id="wt-upload-zone"
                             ondrop="WebtoonUploadModal.handleDrop(event)"
                             ondragover="event.preventDefault()"
                             ondragenter="event.target.classList.add('drag-over')"
                             ondragleave="event.target.classList.remove('drag-over')">
                            <i class="fa-solid fa-cloud-upload-alt"></i>
                            <p>Sayfaları sürükle-bırak veya tıkla</p>
                            <input type="file" id="wt-page-input" multiple 
                                   accept="image/jpeg,image/png,image/webp"
                                   onchange="WebtoonUploadModal.handleFileSelect(event)"
                                   style="display: none;">
                            <button class="btn btn-outline" onclick="document.getElementById('wt-page-input').click()">
                                Dosya Seç
                            </button>
                        </div>
                    </div>
                    
                    <!-- Uploaded Pages Grid -->
                    <div id="wt-pages-container" style="display: none;">
                        <h4>Yüklenen Sayfalar (<span id="wt-page-count">0</span>)</h4>
                        <div class="pages-grid" id="wt-pages-grid"></div>
                    </div>
                    
                    <!-- Cover Image -->
                    <div class="form-group">
                        <label>Kapak Resmi (Opsiyonel)</label>
                        <input type="file" id="wt-cover-input" accept="image/*"
                               onchange="WebtoonUploadModal.handleCoverSelect(event)">
                        <div id="wt-cover-preview" style="display: none;">
                            <img id="wt-cover-img" style="max-width: 200px; border-radius: 8px;">
                        </div>
                    </div>
                    
                    <!-- Age Rating -->
                    <div class="form-group">
                        <label>Yaş Sınırı</label>
                        <select id="wt-age-rating" class="form-input">
                            <option value="">Yok</option>
                            <option value="13+">13+</option>
                            <option value="18+">18+</option>
                            <option value="21+">21+</option>
                        </select>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button class="btn btn-outline" onclick="WebtoonUploadModal.close()">
                        İptal
                    </button>
                    <button class="btn btn-primary" onclick="WebtoonUploadModal.uploadEpisode()" 
                            id="wt-upload-btn" disabled>
                        <i class="fa-solid fa-upload"></i> Onaya Gönder
                    </button>
                </div>
            </div >

    <style>
        .webtoon-upload-modal {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border-radius: 16px;
        width: 90%;
        max-width: 800px;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        border: 1px solid rgba(139, 92, 246, 0.3);
                }

        .upload-zone {
            border: 2px dashed rgba(139, 92, 246, 0.3);
        border-radius: 12px;
        padding: 40px;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s;
                }

        .upload-zone:hover, .upload-zone.drag-over {
            border - color: #8b5cf6;
        background: rgba(139, 92, 246, 0.1);
                }

        .upload-zone i {
            font - size: 48px;
        color: #8b5cf6;
        margin-bottom: 16px;
                }

        .upload-zone p {
            color: #94a3b8;
        margin-bottom: 16px;
                }

        .pages-grid {
            display: grid;
        grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
        gap: 12px;
        margin-top: 12px;
                }

        .page-item {
            position: relative;
        aspect-ratio: 2/3;
        border-radius: 8px;
        overflow: hidden;
        border: 2px solid rgba(139, 92, 246, 0.2);
        cursor: move;
                }

        .page-item img {
            width: 100%;
        height: 100%;
        object-fit: cover;
                }

        .page-item .page-number {
            position: absolute;
        top: 4px;
        left: 4px;
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 700;
                }

        .page-item .page-delete {
            position: absolute;
        top: 4px;
        right: 4px;
        background: rgba(239, 68, 68, 0.9);
        color: white;
        border: none;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
                }

        .page-item .drag-handle {
            position: absolute;
        bottom: 4px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 10px;
        cursor: move;
                }
    </style>
`;

        document.body.appendChild(modal);
        this.setupDragAndDrop();
    },

    setupDragAndDrop() {
        const zone = document.getElementById('wt-upload-zone');
        zone.addEventListener('click', () => {
            document.getElementById('wt-page-input').click();
        });
    },

    handleDrop(event) {
        event.preventDefault();
        event.target.classList.remove('drag-over');

        const files = Array.from(event.dataTransfer.files);
        this.processFiles(files);
    },

    handleFileSelect(event) {
        const files = Array.from(event.target.files);
        this.processFiles(files);
    },

    processFiles(files) {
        const imageFiles = files.filter(f => f.type.startsWith('image/'));

        if (imageFiles.length === 0) {
            Toast.error('Lütfen sadece resim dosyaları seçin');
            return;
        }

        imageFiles.forEach(file => {
            const reader = new FileReader();
            reader.onload = (e) => {
                this.uploadedPages.push({
                    id: `page - ${Date.now()} -${Math.random()} `,
                    file: file,
                    dataUrl: e.target.result,
                    order: this.uploadedPages.length + 1
                });
                this.renderPages();
                this.validateForm();
            };
            reader.readAsDataURL(file);
        });
    },

    renderPages() {
        const container = document.getElementById('wt-pages-container');
        const grid = document.getElementById('wt-pages-grid');
        const count = document.getElementById('wt-page-count');

        if (this.uploadedPages.length === 0) {
            container.style.display = 'none';
            return;
        }

        container.style.display = 'block';
        count.textContent = this.uploadedPages.length;

        grid.innerHTML = this.uploadedPages
            .sort((a, b) => a.order - b.order)
            .map((page, index) => `
    < div class="page-item" draggable = "true"
data - page - id="${page.id}"
ondragstart = "WebtoonUploadModal.handleDragStart(event)"
ondragover = "WebtoonUploadModal.handleDragOver(event)"
ondrop = "WebtoonUploadModal.handlePageDrop(event)" >
    <img src="${page.dataUrl}" alt="Page ${index + 1}">
        <div class="page-number">${index + 1}</div>
        <button class="page-delete" onclick="WebtoonUploadModal.deletePage('${page.id}')">
            <i class="fa-solid fa-times"></i>
        </button>
        <div class="drag-handle">⋮⋮</div>
    </div>
`).join('');
    },

    handleDragStart(event) {
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('text/plain', event.target.dataset.pageId);
    },

    handleDragOver(event) {
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
    },

    handlePageDrop(event) {
        event.preventDefault();
        const draggedId = event.dataTransfer.getData('text/plain');
        const targetId = event.currentTarget.dataset.pageId;

        if (draggedId === targetId) return;

        const draggedIndex = this.uploadedPages.findIndex(p => p.id === draggedId);
        const targetIndex = this.uploadedPages.findIndex(p => p.id === targetId);

        // Swap
        const temp = this.uploadedPages[draggedIndex];
        this.uploadedPages[draggedIndex] = this.uploadedPages[targetIndex];
        this.uploadedPages[targetIndex] = temp;

        // Update orders
        this.uploadedPages.forEach((page, index) => {
            page.order = index + 1;
        });

        this.renderPages();
    },

    deletePage(pageId) {
        this.uploadedPages = this.uploadedPages.filter(p => p.id !== pageId);
        this.renderPages();
        this.validateForm();
    },

    handleCoverSelect(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            this.coverImage = {
                file: file,
                dataUrl: e.target.result
            };

            const preview = document.getElementById('wt-cover-preview');
            const img = document.getElementById('wt-cover-img');
            img.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    },

    validateForm() {
        const episodeNumber = document.getElementById('wt-episode-number').value;
        const hasPages = this.uploadedPages.length > 0;
        const uploadBtn = document.getElementById('wt-upload-btn');

        uploadBtn.disabled = !episodeNumber || !hasPages;
    },

    async uploadEpisode() {
        const episodeNumber = document.getElementById('wt-episode-number').value;
        const episodeTitle = document.getElementById('wt-episode-title').value;
        const ageRating = document.getElementById('wt-age-rating').value;

        if (!episodeNumber || this.uploadedPages.length === 0) {
            Toast.error('Bölüm numarası ve en az bir sayfa gerekli');
            return;
        }

        Toast.info('📤 Sayfalar yükleniyor...');

        // Create FormData
        const formData = new FormData();
        formData.append('webtoonId', this.currentWebtoonId);
        formData.append('episodeNumber', episodeNumber);
        formData.append('episodeTitle', episodeTitle);
        formData.append('ageRating', ageRating);
        formData.append('pageCount', this.uploadedPages.length);

        // Add pages in order
        this.uploadedPages
            .sort((a, b) => a.order - b.order)
            .forEach((page) => {
                formData.append('pages[]', page.file);
            });

        // Add cover if exists
        if (this.coverImage) {
            formData.append('cover', this.coverImage.file);
        }

        try {
            const response = await fetch('api/db.php?action=upload-webtoon-episode', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                // Submit for approval if translator
                if (State.currentUser.role === 'translator') {
                    await this.submitForApproval(result.episode);
                } else {
                    Toast.success('✅ Bölüm yüklendi ve yayınlandı');
                }
                this.close();
            } else {
                Toast.error('❌ Yükleme başarısız: ' + result.message);
            }
        } catch (error) {
            console.error('[WebtoonUpload] Upload failed:', error);
            Toast.error('❌ Yükleme hatası');
        }
    },

    async submitForApproval(episode) {
        // Submit to approval system
        const approval = {
            id: `approval - webtoon - ${Date.now()} `,
            type: 'webtoon-episode',
            webtoonId: this.currentWebtoonId,
            webtoonTitle: this.currentWebtoon.title,
            episode: episode,
            submittedBy: State.currentUser.id,
            submittedByName: State.currentUser.username,
            submittedAt: new Date().toISOString(),
            status: 'pending'
        };

        // Save to approvals
        try {
            const response = await fetch('api/db.php?action=submit-webtoon-approval', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    approval: JSON.stringify(approval)
                })
            });

            const result = await response.json();
            if (result.success) {
                Toast.info('✅ Bölüm admin onayına gönderildi');
            }
        } catch (error) {
            console.error('[WebtoonUpload] Approval submission failed:', error);
        }
    },

    close() {
        const modal = document.getElementById('webtoon-upload-modal');
        if (modal) modal.remove();

        this.uploadedPages = [];
        this.coverImage = null;
    }
};
