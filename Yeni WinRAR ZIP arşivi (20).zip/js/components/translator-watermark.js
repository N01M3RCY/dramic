// ============================================
// TRANSLATOR WATERMARK
// Shows translator info on video player
// ============================================

const TranslatorWatermark = {
    watermark: null,

    show(container, options = {}) {
        // Remove existing watermark
        this.hide();

        const user = State.currentUser;
        if (!user) return;

        const watermark = document.createElement('div');
        watermark.className = 'translator-watermark';
        watermark.innerHTML = `
            <div class="watermark-content">
                <div class="watermark-row">
                    <i class="fa-solid fa-user"></i>
                    <span>${user.username}</span>
                </div>
                <div class="watermark-row">
                    <i class="fa-solid fa-calendar"></i>
                    <span>${new Date().toLocaleString('tr-TR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        })}</span>
                </div>
                ${options.seriesTitle ? `
                    <div class="watermark-row">
                        <i class="fa-solid fa-film"></i>
                        <span>${options.seriesTitle}</span>
                    </div>
                ` : ''}
                ${options.episodeNumber ? `
                    <div class="watermark-row">
                        <i class="fa-solid fa-hashtag"></i>
                        <span>Bölüm ${options.episodeNumber}</span>
                    </div>
                ` : ''}
            </div>
            
            <style>
                .translator-watermark {
                    position: absolute;
                    top: 12px;
                    left: 12px;
                    background: rgba(0, 0, 0, 0.75);
                    backdrop-filter: blur(8px);
                    padding: 10px 14px;
                    border-radius: 8px;
                    font-size: 11px;
                    color: #e2e8f0;
                    z-index: 1000;
                    pointer-events: none;
                    border: 1px solid rgba(139, 92, 246, 0.3);
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
                }
                
                .watermark-content {
                    display: flex;
                    flex-direction: column;
                    gap: 4px;
                }
                
                .watermark-row {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    white-space: nowrap;
                }
                
                .watermark-row i {
                    color: #8b5cf6;
                    font-size: 10px;
                    width: 12px;
                }
                
                .watermark-row span {
                    font-weight: 500;
                }
            </style>
        `;

        container.appendChild(watermark);
        this.watermark = watermark;

        console.log('[Watermark] Shown for user:', user.username);
    },

    hide() {
        if (this.watermark) {
            this.watermark.remove();
            this.watermark = null;
        }
    },

    update(options) {
        if (this.watermark) {
            const container = this.watermark.parentElement;
            this.hide();
            this.show(container, options);
        }
    }
};
