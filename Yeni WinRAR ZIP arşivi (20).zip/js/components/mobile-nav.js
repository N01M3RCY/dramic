// Mobile Bottom Navigation Controller
const MobileNav = {
    setActive(el) {
        document.querySelectorAll('.mobile-nav-item').forEach(i => i.classList.remove('active'));
        if (el) el.classList.add('active');
    },

    // Update active state based on current route
    updateFromRoute(viewId) {
        const nav = document.getElementById('mobile-bottom-nav');
        if (!nav) return;

        const pageMap = {
            'home': 'home',
            'browse': 'browse',
            'movies': 'browse',
            'webtoons': 'browse',
            'anime': 'browse',
            'shorts': 'shorts',
            'social': 'social',
            'profile': 'profile',
            'admin': 'admin',
            'player': null,
            'detail': null,
            'calendar': null,
            'blog': null
        };

        const targetPage = pageMap[viewId];

        // Special case for movies vs browse
        let finalTarget = targetPage;
        if (viewId === 'browse') {
            const params = new URLSearchParams(window.location.hash.split('?')[1]);
            if (params.get('type') === 'movie') finalTarget = 'movies';
        }

        document.querySelectorAll('.mobile-nav-item').forEach(item => {
            item.classList.remove('active');
            if (finalTarget && item.dataset.page === finalTarget) {
                item.classList.add('active');
            }
        });

        // Always show bottom nav (persistent across all pages)
        nav.style.display = '';
    },

    init() {
        console.log('📱 MobileNav initialized');
    }
};

window.MobileNav = MobileNav;
