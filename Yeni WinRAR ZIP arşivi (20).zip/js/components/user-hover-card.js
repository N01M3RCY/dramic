// User Hover Card System
const UserHoverCard = {
    cardElement: null,
    timeout: null,
    currentTarget: null,

    init() {
        if (this.cardElement) return;

        // Create DOM Element
        this.createCard();

        // Global Event Delegation for dynamic content (like comments)
        document.body.addEventListener('mouseover', (e) => {
            // Find closest target with data-user-id
            const target = e.target.closest('.user-link, [data-user-id]');
            if (target && target.dataset.userId) {
                this.handleMouseEnter(e, target);
            }
        });

        document.body.addEventListener('mouseout', (e) => {
            const target = e.target.closest('.user-link, [data-user-id]');
            if (target) {
                this.handleMouseLeave();
            }
        });

        console.log('🆔 User Hover Cards Initialized');
    },

    createCard() {
        const div = document.createElement('div');
        div.className = 'user-hover-card';
        div.id = 'user-hover-card';
        div.innerHTML = `
            <div class="uhc-banner" id="uhc-banner"></div>
            <div class="uhc-avatar-container">
                <img src="" class="uhc-avatar" id="uhc-avatar">
            </div>
            <div class="uhc-content">
                <div class="uhc-header">
                    <h4 class="uhc-username" id="uhc-username"></h4>
                    <span class="uhc-role-badge" id="uhc-role">Member</span>
                </div>
                <div class="uhc-bio" id="uhc-bio"></div>
                <div class="uhc-badges" id="uhc-badges"></div>
                <div class="uhc-stats">
                    <div class="uhc-stat">
                        <span class="uhc-stat-val" id="uhc-stat-level">1</span>
                        <span class="uhc-stat-label">Level</span>
                    </div>
                    <div class="uhc-stat">
                        <span class="uhc-stat-val" id="uhc-stat-joined">2024</span>
                        <span class="uhc-stat-label">Katılım</span>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(div);
        this.cardElement = div;
    },

    handleMouseEnter(e, target) {
        if (this.timeout) clearTimeout(this.timeout);

        const userId = target.dataset.userId;
        if (!userId) return;

        // 500ms delay before showing
        this.timeout = setTimeout(() => {
            this.show(userId, target);
        }, 500);
    },

    handleMouseLeave() {
        if (this.timeout) clearTimeout(this.timeout);

        // Short delay to allow moving to the card itself if interactable (optional)
        // For now, hide immediately or short delay
        this.timeout = setTimeout(() => {
            this.hide();
        }, 300);
    },

    async show(userId, targetElement) {
        // Find user data
        let user = null;

        // 1. Try State.data.users
        if (State.data && State.data.users) {
            user = State.data.users.find(u => u.id === userId);
        }

        // 2. Fetch from API if not found (optional, if we have individual endpoint)
        if (!user && this.fetchUser) {
            // user = await this.fetchUser(userId); 
        }

        if (!user) return; // User not found

        // Populate Data
        const bannerEl = document.getElementById('uhc-banner');
        const avatarEl = document.getElementById('uhc-avatar');
        const usernameEl = document.getElementById('uhc-username');
        const roleEl = document.getElementById('uhc-role');
        const bioEl = document.getElementById('uhc-bio');
        const badgesEl = document.getElementById('uhc-badges');

        bannerEl.style.backgroundImage = `url('${user.coverPhoto || 'https://via.placeholder.com/320x80/333/666'}')`;
        avatarEl.src = user.avatar || 'assets/logo.png';
        usernameEl.textContent = user.username;
        usernameEl.style.color = this.getUserColor(user);

        roleEl.textContent = this.getMainRole(user);
        bioEl.textContent = user.bio || 'Henüz bir biyografi yok.';

        // Badges
        badgesEl.innerHTML = (user.badges || []).slice(0, 5).map(b => this.getBadgeIcon(b)).join('');

        // Stats
        document.getElementById('uhc-stat-level').textContent = user.level || 1;
        document.getElementById('uhc-stat-joined').textContent = user.createdAt ? new Date(user.createdAt).getFullYear() : '2024';

        // Position Card
        this.positionCard(targetElement);

        // Show
        this.cardElement.style.display = 'block';
        // Force reflow
        this.cardElement.offsetHeight;
        this.cardElement.classList.add('active');
    },

    hide() {
        if (!this.cardElement) return;
        this.cardElement.classList.remove('active');
        setTimeout(() => {
            if (!this.cardElement.classList.contains('active')) {
                this.cardElement.style.display = 'none';
            }
        }, 200);
    },

    positionCard(target) {
        const rect = target.getBoundingClientRect();
        const cardRect = this.cardElement.getBoundingClientRect();

        let top = rect.bottom + 10;
        let left = rect.left;

        // Boundary checks
        if (left + cardRect.width > window.innerWidth) {
            left = window.innerWidth - cardRect.width - 20;
        }
        if (top + cardRect.height > window.innerHeight) {
            top = rect.top - cardRect.height - 10; // Flip to top
        }

        this.cardElement.style.top = `${top}px`;
        this.cardElement.style.left = `${left}px`;
    },

    getMainRole(user) {
        if (user.role === 'admin') return 'Yönetici';
        if (user.role === 'translator') return 'Çevirmen';
        if (user.badges && user.badges.includes('VIP')) return 'VIP Üye';
        return 'Üye';
    },

    getUserColor(user) {
        // Check active item color or role
        if (user.activeItems && user.activeItems.color) {
            const item = window.ShopSystem?.items.find(i => i.id === user.activeItems.color);
            if (item) return item.value; // Hex code or gradient
        }
        return 'white';
    },

    getBadgeIcon(badge) {
        const icons = {
            'Yönetici': '<i class="fa-solid fa-crown"></i>',
            'Admin': '<i class="fa-solid fa-shield-halved"></i>',
            'Çevirmen': '<i class="fa-solid fa-language"></i>',
            'VIP': '<i class="fa-solid fa-gem"></i>',
            'Blogger': '<i class="fa-solid fa-pen-nib"></i>'
        };
        const icon = icons[badge] || '<i class="fa-solid fa-medal"></i>';
        return `<div class="uhc-badge-icon" title="${badge}">${icon}</div>`;
    }
};

window.UserHoverCard = UserHoverCard;
