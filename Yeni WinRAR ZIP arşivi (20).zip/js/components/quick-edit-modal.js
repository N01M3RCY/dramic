// ============================================
// QUICK EDIT MODAL
// Fast episode source editing for translators
// ============================================

const QuickEditModal = {
    currentSeriesId: null,
    currentSeries: null,
    uploadMode: null, // 'url' or 'upload'

    show(seriesId) {
        this.currentSeriesId = seriesId;
        this.currentSeries = State.data.series.find(s => s.id === seriesId);
        this.uploadMode = null;

        if (!this.currentSeries) {
            Toast.error('Dizi bulunamadı');
            return;
        }

        this.renderModeSelection();
    },

    renderModeSelection() {
        const modal = document.createElement('div');
        modal.id = 'quick-edit-modal';
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="quick-edit-modal mode-selection">
                <div class="modal-header">
                    <h2>
                        <i class="fa-solid fa-link"></i>
                        Kaynak Ekle - ${this.currentSeries.title}
                    </h2>
                    <button class="modal-close" onclick="QuickEditModal.close()">
                        <i class="fa-solid fa-times"></i>
                    </button>
                </div>

                <div class="modal-body">
                    <h3 style="text-align: center; color: #e2e8f0; margin-bottom: 24px;">
                        Kaynak ekleme yöntemini seçin:
                    </h3>

                    <div class="mode-selection-buttons">
                        <button class="mode-btn" onclick="QuickEditModal.selectMode('url')">
                            <i class="fa-solid fa-link"></i>
                            <h4>URL Kaynak Ekle</h4>
                            <p>Vidmoly, VK gibi platformlardan URL ile ekle</p>
                        </button>

                        <button class="mode-btn" onclick="QuickEditModal.selectMode('upload')">
                            <i class="fa-solid fa-upload"></i>
                            <h4>Video Yükle</h4>
                            <p>Bilgisayarınızdan video dosyası yükle</p>
                        </button>
                    </div>
                </div>

                <style>
                    .mode-selection-buttons {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        gap: 20px;
                        padding: 20px;
                    }

                    .mode-btn {
                        background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1));
                        border: 2px solid rgba(139, 92, 246, 0.3);
                        border-radius: 12px;
                        padding: 32px 24px;
                        cursor: pointer;
                        transition: all 0.3s;
                        text-align: center;
                    }

                    .mode-btn:hover {
                        background: linear-gradient(135deg, rgba(139, 92, 246, 0.2), rgba(59, 130, 246, 0.2));
                        border-color: #8b5cf6;
                        transform: translateY(-4px);
                        box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
                    }

                    .mode-btn i {
                        font-size: 48px;
                        color: #8b5cf6;
                        margin-bottom: 16px;
                    }

                    .mode-btn h4 {
                        color: #e2e8f0;
                        margin: 0 0 8px 0;
                        font-size: 18px;
                    }

                    .mode-btn p {
                        color: #94a3b8;
                        margin: 0;
                        font-size: 13px;
                    }
                </style>
            </div>
        `;

        document.body.appendChild(modal);
    },

    selectMode(mode) {
        this.uploadMode = mode;

        const modal = document.getElementById('quick-edit-modal');
        if (modal) modal.remove();

        if (mode === 'url') {
            this.renderUrlForm();
        } else {
            Toast.info('📹 Video Studio açılıyor...');
            const firstEpisode = this.getFirstEpisode();
            if (firstEpisode) {
                window.location.hash = `#/video-studio/${this.currentSeriesId}/${firstEpisode.number}`;
            } else {
                Toast.warning('Bu dizide henüz bölüm yok');
            }
        }
    },

    getFirstEpisode() {
        if (this.currentSeries.seasons && this.currentSeries.seasons[0] && this.currentSeries.seasons[0].episodes) {
            return this.currentSeries.seasons[0].episodes[0];
        }
        if (this.currentSeries.episodes && this.currentSeries.episodes[0]) {
            return this.currentSeries.episodes[0];
        }
        return null;
    },

    renderUrlForm() {
        const modal = document.createElement('div');
        modal.id = 'quick-edit-modal';
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="quick-edit-modal">
                <div class="modal-header">
                    <h2>
                        <i class="fa-solid fa-link"></i>
                        Kaynak Ekle - ${this.currentSeries.title}
                    </h2>
                    <button class="modal-close" onclick="QuickEditModal.close()">
                        <i class="fa-solid fa-times"></i>
                    </button>
                </div>
                
                <div class="modal-body">
                    <!-- Episode Selection -->
                    <div class="form-group">
                        <label>Bölüm Seç</label>
                        <select id="qe-episode" class="form-input" onchange="QuickEditModal.onEpisodeChange()">
                            <option value="">Bölüm seçin...</option>
                            ${this.renderEpisodeOptions()}
                        </select>
                    </div>
                    
                    <!-- Platform Selection -->
                    <div class="form-group">
                        <label>Platform</label>
                        <select id="qe-platform" class="form-input" onchange="QuickEditModal.onPlatformChange()">
                            <option value="vidmoly">Vidmoly</option>
                            ${State.currentUser?.role === 'admin' ? `
                                <option value="vk">VK</option>
                                <option value="dailymotion">Dailymotion</option>
                                <option value="custom">Özel URL</option>
                            ` : ''}
                        </select>
                        ${State.currentUser?.role !== 'admin' ? `
                            <small style="color: #64748b; font-size: 12px; margin-top: 4px; display: block;">
                                Sadece Vidmoly URL'leri yükleyebilirsiniz
                            </small>
                        ` : ''}
                    </div>
                    
                    <!-- URL Input -->
                    <div class="form-group">
                        <label>Video URL</label>
                        <input type="url" id="qe-url" class="form-input" 
                               placeholder="https://vidmoly.to/embed-xxxxx.html"
                               oninput="QuickEditModal.validateUrl()">
                        <div id="qe-url-error" class="error-message" style="display: none;"></div>
                    </div>
                    
                    <!-- Source Name -->
                    <div class="form-group">
                        <label>Kaynak Adı (Opsiyonel)</label>
                        <input type="text" id="qe-source-name" class="form-input" 
                               placeholder="Vidmoly HD">
                    </div>
                    
                    <!-- Quality -->
                    <div class="form-group">
                        <label>Kalite</label>
                        <select id="qe-quality" class="form-input">
                            <option value="1080p">1080p</option>
                            <option value="720p">720p</option>
                            <option value="480p">480p</option>
                            <option value="360p">360p</option>
                        </select>
                    </div>
                    
                    <!-- Preview -->
                    <div id="qe-preview" class="source-preview" style="display: none;">
                        <h4>Önizleme</h4>
                        <div class="preview-content">
                            <div class="preview-item">
                                <span class="label">Bölüm:</span>
                                <span id="preview-episode"></span>
                            </div>
                            <div class="preview-item">
                                <span class="label">Platform:</span>
                                <span id="preview-platform"></span>
                            </div>
                            <div class="preview-item">
                                <span class="label">Kaynak:</span>
                                <span id="preview-source"></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button class="btn btn-outline" onclick="QuickEditModal.close()">
                        İptal
                    </button>
                    <button class="btn btn-primary" onclick="QuickEditModal.addSource()" id="qe-add-btn" disabled>
                        <i class="fa-solid fa-plus"></i> Kaynak Ekle
                    </button>
                </div>
            </div>
            
            <style>
                .quick-edit-modal {
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    border-radius: 16px;
                    width: 90%;
                    max-width: 600px;
                    max-height: 90vh;
                    overflow-y: auto;
                    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
                    border: 1px solid rgba(139, 92, 246, 0.3);
                }
                
                .modal-header {
                    padding: 20px 24px;
                    border-bottom: 1px solid rgba(139, 92, 246, 0.2);
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .modal-header h2 {
                    margin: 0;
                    color: #e2e8f0;
                    font-size: 20px;
                    display: flex;
                    align-items: center;
                    gap: 12px;
                }
                
                .modal-header h2 i {
                    color: #8b5cf6;
                }
                
                .modal-close {
                    background: none;
                    border: none;
                    color: #94a3b8;
                    font-size: 24px;
                    cursor: pointer;
                    padding: 4px 8px;
                    transition: color 0.2s;
                }
                
                .modal-close:hover {
                    color: #8b5cf6;
                }
                
                .modal-body {
                    padding: 24px;
                }
                
                .form-group {
                    margin-bottom: 20px;
                }
                
                .form-group label {
                    display: block;
                    margin-bottom: 8px;
                    color: #e2e8f0;
                    font-size: 14px;
                    font-weight: 600;
                }
                
                .form-input {
                    width: 100%;
                    padding: 12px;
                    background: rgba(30, 41, 59, 0.5);
                    border: 1px solid rgba(139, 92, 246, 0.2);
                    border-radius: 8px;
                    color: #e2e8f0;
                    font-size: 14px;
                }
                
                .form-input:focus {
                    outline: none;
                    border-color: #8b5cf6;
                }
                
                .error-message {
                    color: #ef4444;
                    font-size: 12px;
                    margin-top: 4px;
                }
                
                .source-preview {
                    background: rgba(139, 92, 246, 0.1);
                    border: 1px solid rgba(139, 92, 246, 0.3);
                    border-radius: 8px;
                    padding: 16px;
                    margin-top: 20px;
                }
                
                .source-preview h4 {
                    margin: 0 0 12px 0;
                    color: #8b5cf6;
                    font-size: 14px;
                }
                
                .preview-content {
                    display: flex;
                    flex-direction: column;
                    gap: 8px;
                }
                
                .preview-item {
                    display: flex;
                    justify-content: space-between;
                    font-size: 13px;
                }
                
                .preview-item .label {
                    color: #94a3b8;
                }
                
                .preview-item span:last-child {
                    color: #e2e8f0;
                    font-weight: 600;
                }
                
                .modal-footer {
                    padding: 16px 24px;
                    border-top: 1px solid rgba(139, 92, 246, 0.2);
                    display: flex;
                    justify-content: flex-end;
                    gap: 12px;
                }
            </style>
        `;

        document.body.appendChild(modal);
    },

    renderEpisodeOptions() {
        const episodes = [];

        if (this.currentSeries.seasons && Array.isArray(this.currentSeries.seasons)) {
            this.currentSeries.seasons.forEach((season, sIdx) => {
                if (season.episodes) {
                    season.episodes.forEach(ep => {
                        episodes.push({
                            value: `season-${sIdx}-${ep.number}`,
                            label: `Sezon ${season.seasonNumber || sIdx + 1} - Bölüm ${ep.number}`,
                            episode: ep
                        });
                    });
                }
            });
        }

        if (this.currentSeries.episodes && Array.isArray(this.currentSeries.episodes)) {
            this.currentSeries.episodes.forEach(ep => {
                episodes.push({
                    value: `episode-${ep.number}`,
                    label: `Bölüm ${ep.number}`,
                    episode: ep
                });
            });
        }

        return episodes.map(e => `<option value="${e.value}">${e.label}</option>`).join('');
    },

    onEpisodeChange() {
        this.updatePreview();
        this.validateForm();
    },

    onPlatformChange() {
        const platform = document.getElementById('qe-platform').value;
        const urlInput = document.getElementById('qe-url');

        const placeholders = {
            vidmoly: 'https://vidmoly.to/embed-xxxxx.html',
            vk: 'https://vk.com/video_ext.php?oid=xxxxx',
            dailymotion: 'https://www.dailymotion.com/embed/video/xxxxx',
            custom: 'https://...'
        };

        urlInput.placeholder = placeholders[platform] || 'https://...';
        this.updatePreview();
    },

    validateUrl() {
        const url = document.getElementById('qe-url').value;
        const platform = document.getElementById('qe-platform').value;
        const errorEl = document.getElementById('qe-url-error');

        if (!url) {
            errorEl.style.display = 'none';
            this.validateForm();
            return;
        }

        const patterns = {
            vidmoly: /vidmoly\.to\/embed-/i,
            vk: /vk\.com\/video/i,
            dailymotion: /dailymotion\.com\/embed/i
        };

        if (patterns[platform] && !patterns[platform].test(url)) {
            errorEl.textContent = `Geçersiz ${platform} URL formatı`;
            errorEl.style.display = 'block';
            this.validateForm();
            return;
        }

        errorEl.style.display = 'none';
        this.updatePreview();
        this.validateForm();
    },

    updatePreview() {
        const episodeVal = document.getElementById('qe-episode').value;
        const platform = document.getElementById('qe-platform').value;
        const url = document.getElementById('qe-url').value;
        const sourceName = document.getElementById('qe-source-name').value;

        const preview = document.getElementById('qe-preview');

        if (episodeVal && url) {
            preview.style.display = 'block';
            document.getElementById('preview-episode').textContent =
                document.getElementById('qe-episode').selectedOptions[0].text;
            document.getElementById('preview-platform').textContent =
                platform.charAt(0).toUpperCase() + platform.slice(1);
            document.getElementById('preview-source').textContent =
                sourceName || `${platform.charAt(0).toUpperCase() + platform.slice(1)} HD`;
        } else {
            preview.style.display = 'none';
        }
    },

    validateForm() {
        const episode = document.getElementById('qe-episode').value;
        const url = document.getElementById('qe-url').value;
        const errorVisible = document.getElementById('qe-url-error').style.display !== 'none';
        const addBtn = document.getElementById('qe-add-btn');

        addBtn.disabled = !episode || !url || errorVisible;
    },

    async addSource() {
        const episodeVal = document.getElementById('qe-episode').value;
        const platform = document.getElementById('qe-platform').value;
        const url = document.getElementById('qe-url').value;
        const sourceName = document.getElementById('qe-source-name').value ||
            `${platform.charAt(0).toUpperCase() + platform.slice(1)} HD`;
        const quality = document.getElementById('qe-quality').value;

        // Find episode
        let episode = null;
        if (episodeVal.startsWith('season-')) {
            const parts = episodeVal.split('-');
            const sIdx = parseInt(parts[1]);
            const epNum = parts[2];
            episode = this.currentSeries.seasons[sIdx].episodes.find(e => e.number == epNum);
        } else {
            const epNum = episodeVal.split('-')[1];
            episode = this.currentSeries.episodes.find(e => e.number == epNum);
        }

        if (!episode) {
            Toast.error('Bölüm bulunamadı');
            return;
        }

        // Add source
        if (!episode.sources) episode.sources = [];

        // Check duplicate
        const isDuplicate = episode.sources.some(s => s.url === url || s.src === url);
        if (isDuplicate) {
            Toast.warning('Bu kaynak zaten ekli');
            return;
        }

        const sourceData = {
            name: sourceName,
            url: url,
            label: sourceName,
            src: url,
            type: 'video/mp4',
            quality: quality,
            platform: platform,
            addedBy: State.currentUser.id,
            addedAt: new Date().toISOString()
        };

        // Check if translator - submit for approval
        if (State.currentUser.role === 'translator' || State.currentUser.role === 'webtoon-translator') {
            if (typeof SourceApprovalSystem !== 'undefined') {
                const submitted = await SourceApprovalSystem.submitForApproval(
                    sourceData,
                    this.currentSeriesId,
                    episode.number,
                    this.currentSeries.title
                );

                if (submitted) {
                    this.close();
                }
            } else {
                Toast.error('Onay sistemi yüklenmedi');
            }
            return;
        }

        // Admin can add directly
        episode.sources.push(sourceData);

        try {
            if (window.db && window.db.updateSeries) {
                await db.updateSeries(this.currentSeriesId, this.currentSeries);
            }

            Toast.success(`✅ Kaynak eklendi: ${sourceName}`);
            this.close();
        } catch (error) {
            console.error('[QuickEdit] Failed to add source:', error);
            Toast.error('Kaynak eklenemedi');
        }
    },

    close() {
        const modal = document.getElementById('quick-edit-modal');
        if (modal) modal.remove();
    }
};

// Initialize
if (typeof window !== 'undefined') {
    window.QuickEditModal = QuickEditModal;
}
