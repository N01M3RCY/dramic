// ============================================
// APPROVAL MANAGER
// Admin interface for reviewing pending sources and webtoons
// ============================================

window.ApprovalManager = {
    pendingApprovals: [],
    currentFilter: 'all', // 'all', 'series', 'webtoons'

    async show() {
        await this.loadApprovals();
        this.render();
    },

    async loadApprovals() {
        try {
            // Load series source approvals
            const seriesResponse = await fetch('data/source-approvals.json');
            const seriesData = await seriesResponse.json();

            // Load webtoon approvals
            const webtoonResponse = await fetch('data/webtoon-approvals.json');
            const webtoonData = await webtoonResponse.json();

            // Combine all pending approvals
            this.pendingApprovals = [
                ...seriesData.pendingApprovals.map(a => ({ ...a, type: 'series-source' })),
                ...webtoonData.pendingApprovals.map(a => ({ ...a, type: 'webtoon-episode' }))
            ];

            // Sort by date (newest first)
            this.pendingApprovals.sort((a, b) =>
                new Date(b.submittedAt) - new Date(a.submittedAt)
            );

            console.log('[ApprovalManager] Loaded approvals:', this.pendingApprovals.length);
        } catch (error) {
            console.error('[ApprovalManager] Failed to load approvals:', error);
            this.pendingApprovals = [];
        }
    },

    render() {
        const modal = document.createElement('div');
        modal.id = 'approval-manager-modal';
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="approval-manager">
                <div class="modal-header">
                    <h2>
                        <i class="fa-solid fa-clock"></i>
                        Onay Bekleyenler
                        <span class="badge">${this.pendingApprovals.length}</span>
                    </h2>
                    <button class="modal-close" onclick="ApprovalManager.close()">
                        <i class="fa-solid fa-times"></i>
                    </button>
                </div>
                
                <!-- Filters -->
                <div class="approval-filters">
                    <button class="filter-btn ${this.currentFilter === 'all' ? 'active' : ''}" 
                            onclick="ApprovalManager.setFilter('all')">
                        Tümü (${this.pendingApprovals.length})
                    </button>
                    <button class="filter-btn ${this.currentFilter === 'series' ? 'active' : ''}" 
                            onclick="ApprovalManager.setFilter('series')">
                        Diziler (${this.getFilteredCount('series-source')})
                    </button>
                    <button class="filter-btn ${this.currentFilter === 'webtoons' ? 'active' : ''}" 
                            onclick="ApprovalManager.setFilter('webtoons')">
                        Webtoonlar (${this.getFilteredCount('webtoon-episode')})
                    </button>
                </div>
                
                <!-- Approvals List -->
                <div class="approvals-list" id="approvals-list">
                    ${this.renderApprovalsList()}
                </div>
                
                <style>
                    .approval-manager {
                        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                        border-radius: 16px;
                        width: 90%;
                        max-width: 900px;
                        max-height: 90vh;
                        overflow: hidden;
                        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
                        border: 1px solid rgba(139, 92, 246, 0.3);
                        display: flex;
                        flex-direction: column;
                    }
                    
                    .approval-filters {
                        display: flex;
                        gap: 8px;
                        padding: 16px 24px;
                        border-bottom: 1px solid rgba(139, 92, 246, 0.2);
                    }
                    
                    .filter-btn {
                        padding: 8px 16px;
                        background: rgba(30, 41, 59, 0.5);
                        border: 1px solid rgba(139, 92, 246, 0.2);
                        border-radius: 8px;
                        color: #94a3b8;
                        cursor: pointer;
                        transition: all 0.3s;
                        font-size: 14px;
                    }
                    
                    .filter-btn:hover {
                        background: rgba(139, 92, 246, 0.1);
                        border-color: #8b5cf6;
                        color: #e2e8f0;
                    }
                    
                    .filter-btn.active {
                        background: #8b5cf6;
                        border-color: #8b5cf6;
                        color: white;
                    }
                    
                    .approvals-list {
                        flex: 1;
                        overflow-y: auto;
                        padding: 24px;
                    }
                    
                    .approval-item {
                        background: rgba(30, 41, 59, 0.5);
                        border: 1px solid rgba(139, 92, 246, 0.2);
                        border-radius: 12px;
                        padding: 20px;
                        margin-bottom: 16px;
                        transition: all 0.3s;
                    }
                    
                    .approval-item:hover {
                        border-color: #8b5cf6;
                        background: rgba(30, 41, 59, 0.7);
                    }
                    
                    .approval-header {
                        display: flex;
                        justify-content: space-between;
                        align-items: start;
                        margin-bottom: 12px;
                    }
                    
                    .approval-title {
                        color: #e2e8f0;
                        font-size: 16px;
                        font-weight: 600;
                        margin: 0 0 4px 0;
                    }
                    
                    .approval-meta {
                        display: flex;
                        gap: 12px;
                        font-size: 13px;
                        color: #94a3b8;
                    }
                    
                    .approval-type {
                        display: inline-block;
                        padding: 4px 12px;
                        border-radius: 6px;
                        font-size: 11px;
                        font-weight: 700;
                        text-transform: uppercase;
                    }
                    
                    .type-series {
                        background: rgba(59, 130, 246, 0.2);
                        color: #3b82f6;
                    }
                    
                    .type-webtoon {
                        background: rgba(236, 72, 153, 0.2);
                        color: #ec4899;
                    }
                    
                    .approval-content {
                        margin: 12px 0;
                        padding: 12px;
                        background: rgba(0, 0, 0, 0.2);
                        border-radius: 8px;
                    }
                    
                    .approval-actions {
                        display: flex;
                        gap: 8px;
                        margin-top: 12px;
                    }
                    
                    .empty-state {
                        text-align: center;
                        padding: 60px 20px;
                        color: #64748b;
                    }
                    
                    .empty-state i {
                        font-size: 64px;
                        margin-bottom: 16px;
                        opacity: 0.5;
                    }
                </style>
            </div>
        `;

        document.body.appendChild(modal);
    },

    renderApprovalsList() {
        const filtered = this.getFilteredApprovals();

        if (filtered.length === 0) {
            return `
                <div class="empty-state">
                    <i class="fa-solid fa-check-circle"></i>
                    <h3>Onay Bekleyen İçerik Yok</h3>
                    <p>Tüm içerikler onaylandı!</p>
                </div>
            `;
        }

        return filtered.map(approval => {
            if (approval.type === 'series-source') {
                return this.renderSeriesApproval(approval);
            } else {
                return this.renderWebtoonApproval(approval);
            }
        }).join('');
    },

    renderSeriesApproval(approval) {
        return `
            <div class="approval-item">
                <div class="approval-header">
                    <div>
                        <h3 class="approval-title">${approval.seriesTitle} - Bölüm ${approval.episodeNumber}</h3>
                        <div class="approval-meta">
                            <span><i class="fa-solid fa-user"></i> ${approval.submittedByName}</span>
                            <span><i class="fa-solid fa-clock"></i> ${this.formatDate(approval.submittedAt)}</span>
                        </div>
                    </div>
                    <span class="approval-type type-series">Dizi Kaynağı</span>
                </div>
                
                <div class="approval-content">
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        <div><strong>Platform:</strong> ${approval.source.platform}</div>
                        <div><strong>Kaynak Adı:</strong> ${approval.source.name}</div>
                        <div><strong>Kalite:</strong> ${approval.source.quality}</div>
                        <div><strong>URL:</strong> <a href="${approval.source.url}" target="_blank" style="color: #8b5cf6;">${approval.source.url}</a></div>
                    </div>
                </div>
                
                <div class="approval-actions">
                    <button class="btn btn-success" onclick="ApprovalManager.approve('${approval.id}', 'series')">
                        <i class="fa-solid fa-check"></i> Onayla
                    </button>
                    <button class="btn btn-danger" onclick="ApprovalManager.reject('${approval.id}', 'series')">
                        <i class="fa-solid fa-times"></i> Reddet
                    </button>
                    <button class="btn btn-outline" onclick="ApprovalManager.preview('${approval.source.url}')">
                        <i class="fa-solid fa-eye"></i> Önizle
                    </button>
                </div>
            </div>
        `;
    },

    renderWebtoonApproval(approval) {
        const pageCount = approval.episode?.pages?.length || 0;
        return `
            <div class="approval-item">
                <div class="approval-header">
                    <div>
                        <h3 class="approval-title">${approval.webtoonTitle} - Bölüm ${approval.episode.number}</h3>
                        <div class="approval-meta">
                            <span><i class="fa-solid fa-user"></i> ${approval.submittedByName}</span>
                            <span><i class="fa-solid fa-clock"></i> ${this.formatDate(approval.submittedAt)}</span>
                        </div>
                    </div>
                    <span class="approval-type type-webtoon">Webtoon</span>
                </div>
                
                <div class="approval-content">
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        <div><strong>Bölüm Adı:</strong> ${approval.episode.title || 'Başlıksız'}</div>
                        <div><strong>Sayfa Sayısı:</strong> ${pageCount}</div>
                        ${approval.episode.ageRating ? `<div><strong>Yaş Sınırı:</strong> ${approval.episode.ageRating}</div>` : ''}
                    </div>
                </div>
                
                <div class="approval-actions">
                    <button class="btn btn-success" onclick="ApprovalManager.approve('${approval.id}', 'webtoon')">
                        <i class="fa-solid fa-check"></i> Onayla
                    </button>
                    <button class="btn btn-danger" onclick="ApprovalManager.reject('${approval.id}', 'webtoon')">
                        <i class="fa-solid fa-times"></i> Reddet
                    </button>
                    <button class="btn btn-outline" onclick="ApprovalManager.previewWebtoon('${approval.id}')">
                        <i class="fa-solid fa-eye"></i> Sayfaları Gör
                    </button>
                </div>
            </div>
        `;
    },

    getFilteredApprovals() {
        if (this.currentFilter === 'all') {
            return this.pendingApprovals;
        } else if (this.currentFilter === 'series') {
            return this.pendingApprovals.filter(a => a.type === 'series-source');
        } else {
            return this.pendingApprovals.filter(a => a.type === 'webtoon-episode');
        }
    },

    getFilteredCount(type) {
        return this.pendingApprovals.filter(a => a.type === type).length;
    },

    setFilter(filter) {
        this.currentFilter = filter;
        const list = document.getElementById('approvals-list');
        if (list) {
            list.innerHTML = this.renderApprovalsList();
        }

        // Update filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        event.target.classList.add('active');
    },

    async approve(approvalId, type) {
        if (!confirm('Bu içeriği onaylamak istediğinizden emin misiniz?')) {
            return;
        }

        try {
            if (type === 'series') {
                await SourceApprovalSystem.approve(approvalId);
            } else {
                await this.approveWebtoon(approvalId);
            }

            Toast.success('✅ İçerik onaylandı ve yayınlandı');
            await this.loadApprovals();

            // Re-render
            const list = document.getElementById('approvals-list');
            if (list) {
                list.innerHTML = this.renderApprovalsList();
            }

            // Update badge
            const badge = document.querySelector('.approval-manager .badge');
            if (badge) {
                badge.textContent = this.pendingApprovals.length;
            }
        } catch (error) {
            console.error('[ApprovalManager] Approval failed:', error);
            Toast.error('❌ Onaylama başarısız');
        }
    },

    async reject(approvalId, type) {
        const reason = prompt('Reddetme sebebi (opsiyonel):');

        try {
            if (type === 'series') {
                await SourceApprovalSystem.reject(approvalId, reason);
            } else {
                await this.rejectWebtoon(approvalId, reason);
            }

            Toast.info('İçerik reddedildi');
            await this.loadApprovals();

            // Re-render
            const list = document.getElementById('approvals-list');
            if (list) {
                list.innerHTML = this.renderApprovalsList();
            }

            // Update badge
            const badge = document.querySelector('.approval-manager .badge');
            if (badge) {
                badge.textContent = this.pendingApprovals.length;
            }
        } catch (error) {
            console.error('[ApprovalManager] Rejection failed:', error);
            Toast.error('❌ Reddetme başarısız');
        }
    },

    async approveWebtoon(approvalId) {
        const response = await fetch('api/db.php?action=approve-webtoon-episode', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ approvalId })
        });

        const result = await response.json();
        if (!result.success) {
            throw new Error(result.message || 'Approval failed');
        }
    },

    async rejectWebtoon(approvalId, reason) {
        const response = await fetch('api/db.php?action=reject-webtoon-episode', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ approvalId, reason: reason || '' })
        });

        const result = await response.json();
        if (!result.success) {
            throw new Error(result.message || 'Rejection failed');
        }
    },

    preview(url) {
        window.open(url, '_blank');
    },

    previewWebtoon(approvalId) {
        // TODO: Show webtoon pages preview modal
        Toast.info('Webtoon önizleme yakında...');
    },

    formatDate(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;

        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);

        if (minutes < 60) {
            return `${minutes} dakika önce`;
        } else if (hours < 24) {
            return `${hours} saat önce`;
        } else if (days < 7) {
            return `${days} gün önce`;
        } else {
            return date.toLocaleDateString('tr-TR');
        }
    },

    close() {
        const modal = document.getElementById('approval-manager-modal');
        if (modal) modal.remove();
    }
};
