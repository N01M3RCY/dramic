// ============================================
// UPLOAD BALLOON - Floating Upload Progress UI
// Similar to Admin Chat balloon
// ============================================

const UploadBalloon = {
    isMinimized: false,
    isDragging: false,

    init() {
        this.createBalloon();
        this.bindEvents();

        // Listen to UploadManager events
        UploadManager.on('started', () => this.show());
        UploadManager.on('progress', (upload) => this.updateUpload(upload));
        UploadManager.on('complete', (upload) => this.onComplete(upload));
        UploadManager.on('error', (upload) => this.onError(upload));

        console.log('🎈 UploadBalloon initialized');
    },

    createBalloon() {
        const balloon = document.createElement('div');
        balloon.id = 'upload-balloon';
        balloon.className = 'upload-balloon hidden';
        balloon.innerHTML = `
            <div class="upload-balloon-header">
                <div class="upload-balloon-title">
                    <i class="fa-solid fa-cloud-arrow-up"></i>
                    <span id="upload-count">0 Upload</span>
                </div>
                <div class="upload-balloon-actions">
                    <button class="minimize-btn" onclick="UploadBalloon.toggleMinimize()">
                        <i class="fa-solid fa-chevron-down"></i>
                    </button>
                    <button class="close-btn" onclick="UploadBalloon.hide()">
                        <i class="fa-solid fa-times"></i>
                    </button>
                </div>
            </div>
            <div class="upload-balloon-body">
                <div id="upload-list"></div>
            </div>
            
            <style>
                .upload-balloon {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    width: 380px;
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    border-radius: 16px;
                    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
                    z-index: 99999;
                    overflow: hidden;
                    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                    border: 1px solid rgba(139, 92, 246, 0.3);
                }
                
                .upload-balloon.hidden {
                    transform: translateY(120%) scale(0.8);
                    opacity: 0;
                    pointer-events: none;
                }
                
                .upload-balloon.minimized .upload-balloon-body {
                    max-height: 0;
                    opacity: 0;
                }
                
                .upload-balloon-header {
                    background: rgba(139, 92, 246, 0.1);
                    padding: 12px 16px;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    cursor: move;
                    border-bottom: 1px solid rgba(139, 92, 246, 0.2);
                }
                
                .upload-balloon-title {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    color: #e2e8f0;
                    font-weight: 600;
                    font-size: 14px;
                }
                
                .upload-balloon-title i {
                    color: #8b5cf6;
                    font-size: 18px;
                }
                
                .upload-balloon-actions {
                    display: flex;
                    gap: 8px;
                }
                
                .upload-balloon-actions button {
                    background: none;
                    border: none;
                    color: #94a3b8;
                    cursor: pointer;
                    padding: 4px 8px;
                    border-radius: 4px;
                    transition: all 0.2s;
                }
                
                .upload-balloon-actions button:hover {
                    background: rgba(139, 92, 246, 0.2);
                    color: #8b5cf6;
                }
                
                .upload-balloon-body {
                    max-height: 400px;
                    overflow-y: auto;
                    transition: all 0.3s;
                }
                
                .upload-item {
                    padding: 16px;
                    border-bottom: 1px solid rgba(139, 92, 246, 0.1);
                    cursor: pointer;
                    transition: background 0.2s;
                }
                
                .upload-item:hover {
                    background: rgba(139, 92, 246, 0.05);
                }
                
                .upload-item-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    margin-bottom: 8px;
                }
                
                .upload-item-name {
                    color: #e2e8f0;
                    font-size: 13px;
                    font-weight: 500;
                    flex: 1;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                
                .upload-item-status {
                    font-size: 11px;
                    padding: 2px 8px;
                    border-radius: 4px;
                    font-weight: 600;
                }
                
                .upload-item-status.uploading {
                    background: rgba(59, 130, 246, 0.2);
                    color: #3b82f6;
                }
                
                .upload-item-status.completed {
                    background: rgba(16, 185, 129, 0.2);
                    color: #10b981;
                }
                
                .upload-item-status.error {
                    background: rgba(239, 68, 68, 0.2);
                    color: #ef4444;
                }
                
                .upload-item-status.paused {
                    background: rgba(251, 191, 36, 0.2);
                    color: #fbbf24;
                }
                
                .upload-progress-bar {
                    height: 4px;
                    background: rgba(139, 92, 246, 0.2);
                    border-radius: 2px;
                    overflow: hidden;
                    margin-bottom: 8px;
                }
                
                .upload-progress-fill {
                    height: 100%;
                    background: linear-gradient(90deg, #8b5cf6, #a78bfa);
                    transition: width 0.3s;
                    border-radius: 2px;
                }
                
                .upload-item-stats {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    font-size: 11px;
                    color: #94a3b8;
                }
                
                .upload-item-speed {
                    display: flex;
                    align-items: center;
                    gap: 4px;
                }
                
                .upload-item-speed i {
                    color: #8b5cf6;
                }
                
                .upload-item-actions {
                    display: flex;
                    gap: 8px;
                    margin-top: 8px;
                }
                
                .upload-item-actions button {
                    flex: 1;
                    padding: 6px;
                    border: none;
                    border-radius: 6px;
                    font-size: 11px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                
                .upload-item-actions .pause-btn {
                    background: rgba(251, 191, 36, 0.2);
                    color: #fbbf24;
                }
                
                .upload-item-actions .resume-btn {
                    background: rgba(59, 130, 246, 0.2);
                    color: #3b82f6;
                }
                
                .upload-item-actions .cancel-btn {
                    background: rgba(239, 68, 68, 0.2);
                    color: #ef4444;
                }
                
                .upload-item-actions button:hover {
                    transform: translateY(-1px);
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
                }
            </style>
        `;

        document.body.appendChild(balloon);
        this.balloon = balloon;
    },

    bindEvents() {
        const header = this.balloon.querySelector('.upload-balloon-header');

        // Make draggable
        header.addEventListener('mousedown', (e) => {
            if (e.target.closest('button')) return;

            this.isDragging = true;
            const rect = this.balloon.getBoundingClientRect();
            this.dragOffset = {
                x: e.clientX - rect.left,
                y: e.clientY - rect.top
            };
        });

        document.addEventListener('mousemove', (e) => {
            if (!this.isDragging) return;

            const x = e.clientX - this.dragOffset.x;
            const y = e.clientY - this.dragOffset.y;

            this.balloon.style.left = x + 'px';
            this.balloon.style.top = y + 'px';
            this.balloon.style.right = 'auto';
            this.balloon.style.bottom = 'auto';
        });

        document.addEventListener('mouseup', () => {
            this.isDragging = false;
        });
    },

    show() {
        this.balloon.classList.remove('hidden');
        this.update();
    },

    hide() {
        const activeUploads = UploadManager.getActiveUploads();
        if (activeUploads.length > 0) {
            if (!confirm('Aktif yüklemeler var. Gizlemek istediğinize emin misiniz?')) {
                return;
            }
        }
        this.balloon.classList.add('hidden');
    },

    toggleMinimize() {
        this.isMinimized = !this.isMinimized;
        this.balloon.classList.toggle('minimized', this.isMinimized);

        const icon = this.balloon.querySelector('.minimize-btn i');
        icon.className = this.isMinimized ? 'fa-solid fa-chevron-up' : 'fa-solid fa-chevron-down';
    },

    update() {
        const uploads = UploadManager.getAllUploads();
        const activeCount = uploads.filter(u => u.status === 'uploading' || u.status === 'paused').length;

        // Update count
        const countEl = document.getElementById('upload-count');
        countEl.textContent = `${activeCount} Upload${activeCount !== 1 ? '' : ''}`;

        // Update list
        const listEl = document.getElementById('upload-list');
        listEl.innerHTML = uploads.map(upload => this.renderUploadItem(upload)).join('');

        // Auto-hide if no uploads
        if (uploads.length === 0) {
            this.hide();
        }
    },

    updateUpload(upload) {
        const item = document.getElementById(`upload-${upload.id}`);
        if (item) {
            item.outerHTML = this.renderUploadItem(upload);
        } else {
            this.update();
        }
    },

    renderUploadItem(upload) {
        const statusClass = upload.status;
        const statusText = {
            uploading: 'Yükleniyor',
            paused: 'Duraklatıldı',
            completed: 'Tamamlandı',
            error: 'Hata'
        }[upload.status];

        const showActions = upload.status === 'uploading' || upload.status === 'paused';

        return `
            <div class="upload-item" id="upload-${upload.id}" onclick="UploadBalloon.showDetails('${upload.id}')">
                <div class="upload-item-header">
                    <div class="upload-item-name" title="${upload.metadata.fileName}">
                        ${upload.metadata.seriesTitle} - Bölüm ${upload.metadata.episodeNumber}
                    </div>
                    <div class="upload-item-status ${statusClass}">${statusText}</div>
                </div>
                
                ${upload.status === 'uploading' || upload.status === 'paused' ? `
                    <div class="upload-progress-bar">
                        <div class="upload-progress-fill" style="width: ${upload.progress}%"></div>
                    </div>
                    
                    <div class="upload-item-stats">
                        <div class="upload-item-speed">
                            <i class="fa-solid fa-gauge-high"></i>
                            <span>${UploadManager.formatSpeed(upload.speed)}</span>
                        </div>
                        <div>${Number(upload.progress).toFixed(1)}%</div>
                        <div>
                            <i class="fa-solid fa-clock"></i>
                            ${UploadManager.formatTime(upload.eta)}
                        </div>
                    </div>
                ` : ''}
                
                ${upload.status === 'error' ? `
                    <div style="color: #ef4444; font-size: 11px; margin-top: 4px;">
                        ${upload.error}
                    </div>
                ` : ''}
                
                ${showActions ? `
                    <div class="upload-item-actions" onclick="event.stopPropagation()">
                        ${upload.status === 'uploading' ? `
                            <button class="pause-btn" onclick="UploadManager.pauseUpload('${upload.id}')">
                                <i class="fa-solid fa-pause"></i> Duraklat
                            </button>
                        ` : ''}
                        ${upload.status === 'paused' ? `
                            <button class="resume-btn" onclick="UploadManager.resumeUpload('${upload.id}')">
                                <i class="fa-solid fa-play"></i> Devam Et
                            </button>
                        ` : ''}
                        <button class="cancel-btn" onclick="UploadManager.cancelUpload('${upload.id}')">
                            <i class="fa-solid fa-times"></i> İptal
                        </button>
                    </div>
                ` : ''}
            </div>
        `;
    },

    showDetails(uploadId) {
        const upload = UploadManager.getUpload(uploadId);
        if (!upload) return;

        // Open detailed modal
        if (typeof UploadDetailsModal !== 'undefined') {
            UploadDetailsModal.show(uploadId);
        } else {
            console.log('Show details for:', upload);
            Toast.info('Detaylı görünüm yükleniyor...');
        }
    },

    onComplete(upload) {
        this.update();
        Toast.success(`✅ ${upload.metadata.fileName} yüklendi!`);

        // Auto-hide after 5 seconds if all completed
        setTimeout(() => {
            const activeUploads = UploadManager.getActiveUploads();
            if (activeUploads.length === 0) {
                this.hide();
            }
        }, 5000);
    },

    onError(upload) {
        this.update();
        Toast.error(`❌ ${upload.metadata.fileName} yüklenemedi: ${upload.error}`);
    }
};

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    UploadBalloon.init();
});
