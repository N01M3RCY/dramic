const SpotlightSearch = {
    isOpen: false,
    selectedIndex: -1,
    results: [],

    init() {
        if (document.getElementById('spotlight-overlay')) return; // Already inited

        this.injectHTML();
        this.bindEvents();
        console.log('🔍 Spotlight Search Initialized (Ctrl+K)');
    },

    injectHTML() {
        const html = `
        <div class="spotlight-modal" id="spotlight-overlay">
            <div class="spotlight-container">
                <div class="spotlight-header">
                    <div class="spotlight-input-wrapper">
                        <i class="fa-solid fa-magnifying-glass" style="font-size: 2rem; color: var(--ultra-accent);"></i>
                        <input type="text" class="spotlight-input" id="spotlight-input" placeholder="Neyi keşfetmek istersiniz?">
                        <button class="spotlight-close" onclick="SpotlightSearch.close()" style="background:none; border:none; color:var(--text-dim); font-weight:800; cursor:pointer;">ESC</button>
                    </div>
                </div>
                <div class="spotlight-results" id="spotlight-results">
                    <!-- Results or Initial State -->
                </div>
            </div>
        </div>
        `;
        document.body.insertAdjacentHTML('beforeend', html);
    },

    bindEvents() {
        // Keyboard Shortcut
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                this.open();
            }
            if (e.key === 'Escape' && this.isOpen) {
                this.close();
            }
        });

        const input = document.getElementById('spotlight-input');
        input.addEventListener('input', (e) => this.handleInput(e.target.value));
        input.addEventListener('keydown', (e) => this.handleKeydown(e));

        // Close on overlay click
        document.getElementById('spotlight-overlay').addEventListener('click', (e) => {
            if (e.target.id === 'spotlight-overlay') this.close();
        });
    },

    open() {
        this.isOpen = true;
        const overlay = document.getElementById('spotlight-overlay');
        overlay.style.display = 'flex';
        setTimeout(() => {
            overlay.classList.add('active');
        }, 10);
        const input = document.getElementById('spotlight-input');
        input.value = '';
        input.focus();
        this.renderInitial();
    },

    close() {
        this.isOpen = false;
        const overlay = document.getElementById('spotlight-overlay');
        overlay.classList.remove('active');
        setTimeout(() => {
            if (!this.isOpen) overlay.style.display = 'none';
        }, 300);
        this.selectedIndex = -1;
    },

    handleInput(query) {
        if (!query || query.length < 2) {
            this.renderInitial();
            return;
        }

        // Debounce could be added here, but client-side filtering is fast enough usually
        this.performSearch(query);
    },

    performSearch(query) {
        const q = query.toLowerCase();

        // 1. Content Scoring (Weighted Search)
        const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])];
        const mediaWithScores = allContent.map(s => {
            let score = 0;
            const title = (s.title || '').toLowerCase();
            const originalTitle = (s.originalTitle || '').toLowerCase();
            const description = (s.description || '').toLowerCase();
            const genres = Array.isArray(s.genres) ? s.genres.join(' ').toLowerCase() : (s.genre || '').toLowerCase();

            // Match Scenarios
            if (title === q) score += 100; // Exact match
            else if (title.startsWith(q)) score += 50;
            else if (title.includes(q)) score += 30;

            if (originalTitle.includes(q)) score += 20;
            if (genres.includes(q)) score += 10;
            if (description.includes(q)) score += 5;

            return { ...s, searchScore: score };
        }).filter(s => s.searchScore > 0);

        // Sort by score
        mediaWithScores.sort((a, b) => b.searchScore - a.searchScore);

        const series = mediaWithScores.filter(m => m.type !== 'movie' && m.type !== 'webtoon' && m.type !== 'short').slice(0, 5);
        const movies = mediaWithScores.filter(m => m.type === 'movie').slice(0, 5);
        const webtoons = mediaWithScores.filter(m => m.type === 'webtoon').slice(0, 5);
        const shorts = mediaWithScores.filter(m => m.type === 'short').slice(0, 5);

        // 2. Actors
        let actors = [];
        if (State.data.actors) {
            actors = State.data.actors.filter(a => a.name.toLowerCase().includes(q)).slice(0, 3);
        } else {
            const actorMap = new Map();
            (State.data.series || []).forEach(s => {
                (s.characters || []).forEach(c => {
                    if (c.actor && c.actor.toLowerCase().includes(q)) {
                        actorMap.set(c.actor, { name: c.actor, image: c.image });
                    }
                });
            });
            actors = Array.from(actorMap.values()).slice(0, 3);
        }

        // 3. Users
        const users = (State.data.users || []).filter(u =>
            u.username.toLowerCase().includes(q) && u.id !== State.currentUser?.id
        ).slice(0, 5);

        this.results = [
            ...series.map(i => ({ ...i, category: 'Dizi' })),
            ...movies.map(i => ({ ...i, category: 'Film' })),
            ...webtoons.map(i => ({ ...i, category: 'Webtoon' })),
            ...shorts.map(i => ({ ...i, category: 'Shorts' })),
            ...actors.map(i => ({ ...i, type: 'actor', category: 'Oyuncu' })),
            ...users.map(i => ({ ...i, type: 'user', category: 'Üye' }))
        ];

        this.selectedIndex = 0;
        this.renderResults();
    },

    renderInitial() {
        const container = document.getElementById('spotlight-results');
        
        // Pick some random trending series from State
        const trending = (State.data.series || []).slice(0, 3);
        
        container.innerHTML = `
            <div class="spotlight-initial">
                <i class="fa-solid fa-bolt"></i>
                <p>Neyi keşfetmek istersiniz?</p>
                
                <div style="margin-top: 30px; text-align: left; padding: 0 25px;">
                    <div style="font-size: 0.7rem; font-weight: 900; color: #7c3aed; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 15px; opacity: 0.6;">
                        HIZLI ÖNERİLER
                    </div>
                    ${trending.map(s => `
                        <div class="spotlight-item" onclick="SpotlightSearch.selectItemById('${s.id}', 'series')">
                            <img src="${s.poster}" class="spotlight-item-img" onerror="this.src='assets/logo.png'">
                            <div class="spotlight-item-info">
                                <div class="spotlight-item-title">${s.title}</div>
                                <div class="spotlight-item-subtitle">Trendlerde • ${s.year || ''}</div>
                            </div>
                            <i class="fa-solid fa-chevron-right" style="font-size: 0.7rem; opacity: 0.3;"></i>
                        </div>
                    `).join('')}
                    
                    <div style="margin-top: 20px; font-size: 0.8rem; color: #64748b; text-align: center;">
                        Örnek: <span style="color: #fff; cursor: pointer;" onclick="document.getElementById('spotlight-input').value='Squid Game'; SpotlightSearch.performSearch('Squid Game')">"Squid Game"</span>, 
                        <span style="color: #fff; cursor: pointer;" onclick="document.getElementById('spotlight-input').value='Lee Min-ho'; SpotlightSearch.performSearch('Lee Min-ho')">"Lee Min-ho"</span>
                    </div>
                </div>
            </div>
        `;
        this.results = [];
        this.selectedIndex = -1;
    },

    // Helper to select item by ID directly (used for trending)
    selectItemById(id, type) {
        const list = type === 'series' ? State.data.series : (type === 'actor' ? State.data.actors : State.data.users);
        const item = list.find(i => i.id == id);
        if (item) {
            this.close();
            if (type === 'series') App.router('detail', item.slug || item.id);
            else if (type === 'actor') App.router('actor-detail', encodeURIComponent(item.name));
            else if (type === 'user') App.router('profile', item.id);
        }
    },

    renderResults() {
        const container = document.getElementById('spotlight-results');
        if (this.results.length === 0) {
            container.innerHTML = `
                <div class="spotlight-empty">
                    <i class="fa-regular fa-face-frown-open"></i>
                    <p>Sonuç bulunamadı.</p>
                </div>
            `;
            return;
        }

        let html = '';

        // Group by type for display
        const groups = {
            series: this.results.filter(r => r.type === 'series' || r.type === 'movie' || r.type === 'webtoon' || r.type === 'short'),
            actor: this.results.filter(r => r.type === 'actor'),
            user: this.results.filter(r => r.type === 'user')
        };

        let globalIndex = 0;

        if (groups.series.length > 0) {
            html += `<div class="spotlight-section"><div class="spotlight-section-title">İÇERİKLER</div>`;
            groups.series.forEach(item => {
                html += this.createItemHTML(item, globalIndex++);
            });
            html += `</div>`;
        }

        if (groups.actor.length > 0) {
            html += `<div class="spotlight-section"><div class="spotlight-section-title">OYUNCULAR</div>`;
            groups.actor.forEach(item => {
                html += this.createItemHTML(item, globalIndex++);
            });
            html += `</div>`;
        }

        if (groups.user.length > 0) {
            html += `<div class="spotlight-section"><div class="spotlight-section-title">KULLANICILAR</div>`;
            groups.user.forEach(item => {
                html += this.createItemHTML(item, globalIndex++);
            });
            html += `</div>`;
        }

        container.innerHTML = html;
        this.updateSelection();
    },

    createItemHTML(item, index) {
        let title, subtitle, img, badge;
        const type = item.type;

        if (type === 'series' || type === 'movie' || type === 'webtoon' || type === 'short') {
            title = item.title;
            subtitle = item.category + (item.year ? ` • ${item.year}` : '');
            img = item.poster || item.coverImage;
            badge = item.rating;
        } else if (type === 'actor') {
            title = item.name;
            subtitle = 'Oyuncu';
            img = item.image;
        } else if (type === 'user') {
            title = item.username;
            subtitle = item.role === 'admin' ? 'Yönetici' : 'Üye';
            img = item.avatar || 'assets/logo.png';
        }

        const imgClass = (type === 'series' || type === 'movie' || type === 'webtoon' || type === 'short') ? 'spotlight-item-img' : 'spotlight-item-img circle';
        const isSelected = index === this.selectedIndex ? 'selected' : '';

        // Friend Request Logic
        let actionButton = '';
        if (type === 'user' && State.currentUser) {
            const isFriend = (State.currentUser.friends || []).includes(item.id);
            const isSent = (item.friendRequests || []).some(r => r.from === State.currentUser.id);
            
            if (isFriend) {
                actionButton = `<span class="spotlight-action-badge success"><i class="fa-solid fa-check"></i> Arkadaşsınız</span>`;
            } else if (isSent) {
                actionButton = `<span class="spotlight-action-badge pending"><i class="fa-solid fa-clock"></i> İstek Gönderildi</span>`;
            } else {
                actionButton = `<button class="spotlight-action-btn" onclick="event.stopPropagation(); SpotlightSearch.sendRequest('${item.id}')"><i class="fa-solid fa-user-plus"></i> Ekle</button>`;
            }
        }

        return `
        <div class="search-item-premium ${isSelected}" data-index="${index}" onclick="SpotlightSearch.selectItem(${index})">
            <img src="${img}" class="search-item-poster" onerror="this.src='assets/logo.png'">
            <div class="search-item-info">
                <div class="search-item-title">${title}</div>
                <div class="search-item-meta">
                    ${badge ? `<span style="color:#ffd700;"><i class="fa-solid fa-star"></i> ${badge}</span>` : ''}
                    <span>${subtitle}</span>
                </div>
            </div>
            <div class="search-item-actions">
                ${actionButton}
                <i class="fa-solid fa-chevron-right" style="opacity:0.3;"></i>
            </div>
        </div>
        `;
    },

    async sendRequest(userId) {
        if (window.Social && Social.sendFriendRequest) {
            await Social.sendFriendRequest(userId);
            this.performSearch(document.getElementById('spotlight-input').value); // Refresh results to show "Pending"
        } else if (window.FriendCenter && FriendCenter.sendRequest) {
            await FriendCenter.sendRequest(userId);
            this.performSearch(document.getElementById('spotlight-input').value);
        } else {
            Toast.error("Sosyal servis şu an ulaşılamaz durumda.");
        }
    },

    handleKeydown(e) {
        if (this.results.length === 0) return;

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.selectedIndex = (this.selectedIndex + 1) % this.results.length;
            this.updateSelection();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            this.selectedIndex = (this.selectedIndex - 1 + this.results.length) % this.results.length;
            this.updateSelection();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (this.selectedIndex >= 0) {
                this.selectItem(this.selectedIndex);
            }
        }
    },

    updateSelection() {
        const items = document.querySelectorAll('.search-item-premium');
        items.forEach(el => {
            const idx = parseInt(el.getAttribute('data-index'));
            if (idx === this.selectedIndex) {
                el.classList.add('selected');
                el.style.background = 'rgba(255,255,255,0.08)';
                el.scrollIntoView({ block: 'nearest' });
            } else {
                el.classList.remove('selected');
                el.style.background = '';
            }
        });
    },

    selectItem(index) {
        const item = this.results[index] || this.results.find(res => this.results.indexOf(res) === index); // Basic fallback
        // Since we flattened the list in renderResults logic:
        // Note: this.results is a flat array of objects with correct type

        if (!item) return;

        this.close();

        if (item.type === 'series' || item.type === 'movie' || item.type === 'webtoon' || item.type === 'short') {
            App.router('detail', item.slug || item.id);
        } else if (item.type === 'actor') {
            App.router('actor-detail', encodeURIComponent(item.name));
        } else if (item.type === 'user') {
            App.router('profile', item.id);
        }
    }
};

window.SpotlightSearch = SpotlightSearch;

// Auto Init
document.addEventListener('DOMContentLoaded', () => {
    SpotlightSearch.init();
});
