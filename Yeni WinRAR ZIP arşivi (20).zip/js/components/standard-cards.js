/**
 * DRAMICBOX - Standard Card Component (Premium Version)
 * Unified rendering for Series and Webtoons with high-end effects
 */

if (!window.StandardCard) {
    window.StandardCard = {
        /**
         * Renders a standardized premium card HTML
         * @param {Object} item - The series/webtoon object
         * @param {Object} options - Customization options
         * @returns {string} - HTML string
         */
        render(item, options = {}) {
            if (!item) return '';

            const poster = item.poster || item.coverImage || 'assets/poster-placeholder.jpg';
            const year = item.year || '2024';
            const genres = Array.isArray(item.genres) ? item.genres.slice(0, 2).join(', ') : (item.genres || item.genre || 'Dizi');
            
            // Type Label
            const typeLabel = item.type === 'webtoon' ? 'WEBTOON' : 'DİZİ';
            
            // Rating
            const rating = item.rating || (Math.random() * (9.5 - 7.0) + 7.0).toFixed(1);

            // Use the CSS classes for styling from ultra-premium.css
            return `
                <div class="premium-card" onclick="App.router('detail', '${item.id}')">
                    <img src="${poster}" alt="${item.title}" class="card-poster" loading="lazy">
                    
                    <div class="card-type-badge">${typeLabel}</div>
                    <div class="card-rating">
                        <i class="fa-solid fa-star"></i> ${rating}
                    </div>
                    
                    ${options.episode ? `<div class="card-type-badge" style="top:45px; background:var(--ultra-secondary);">${options.episode}. Bölüm</div>` : ''}

                    <div class="card-overlay">
                        <h3 class="card-title">${item.title}</h3>
                        <div class="card-meta">
                            <span><i class="fa-solid fa-calendar-day"></i> ${year}</span>
                            <span><i class="fa-solid fa-tags"></i> ${genres}</span>
                        </div>
                        <button class="card-btn">
                            <i class="fa-solid fa-play"></i> Hemen İzle
                        </button>
                    </div>

                    <div class="card-glow"></div>
                </div>
            `;
        }
    };
}
