// ============================================
// UPLOAD DETAILS MODAL
// Detailed statistics and controls for uploads
// ============================================

const UploadDetailsModal = {
    currentUploadId: null,
    updateInterval: null,

    show(uploadId) {
        this.currentUploadId = uploadId;
        const upload = UploadManager.getUpload(uploadId);

        if (!upload) {
            Toast.error('Upload bulunamadı');
            return;
        }

        this.createModal(upload);
        this.startUpdating();
    },

    createModal(upload) {
        // Remove existing modal if any
        const existing = document.getElementById('upload-details-modal');
        if (existing) existing.remove();

        const modal = document.createElement('div');
        modal.id = 'upload-details-modal';
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="upload-details-modal">
                <div class="modal-header">
                    <h2>📊 Upload Detayları</h2>
                    <button class="modal-close" onclick="UploadDetailsModal.close()">
                        <i class="fa-solid fa-times"></i>
                    </button>
                </div>
                
                <div class="modal-body">
                    <!-- File Info -->
                    <div class="detail-section">
                        <h3>📁 Dosya Bilgileri</h3>
                        <div class="detail-grid">
                            <div class="detail-item">
                                <span class="label">Dosya Adı:</span>
                                <span class="value">${upload.metadata.fileName}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Boyut:</span>
                                <span class="value">${UploadManager.formatBytes(upload.metadata.fileSize)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Dizi:</span>
                                <span class="value">${upload.metadata.seriesTitle}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Bölüm:</span>
                                <span class="value">${upload.metadata.episodeNumber}</span>
                            </div>
                        </div>
                    </div>

                    <!-- Progress -->
                    <div class="detail-section">
                        <h3>⏳ İlerleme</h3>
                        <div class="progress-container">
                            <div class="progress-bar">
                                <div class="progress-fill" id="detail-progress-fill" style="width: ${upload.progress}%"></div>
                            </div>
                            <div class="progress-text" id="detail-progress-text">${Math.round(upload.progress)}%</div>
                        </div>
                        <div class="progress-stats">
                            <span id="detail-loaded">${UploadManager.formatBytes(upload.loaded)}</span>
                            <span>/</span>
                            <span>${UploadManager.formatBytes(upload.total)}</span>
                        </div>
                    </div>

                    <!-- Speed Stats -->
                    <div class="detail-section">
                        <h3>🚀 Hız İstatistikleri</h3>
                        <div class="stats-grid">
                            <div class="stat-card">
                                <div class="stat-label">Anlık Hız</div>
                                <div class="stat-value" id="detail-current-speed">${UploadManager.formatSpeed(upload.speed)}</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-label">Ortalama Hız</div>
                                <div class="stat-value" id="detail-avg-speed">${UploadManager.formatSpeed(upload.avgSpeed)}</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-label">En Yüksek Hız</div>
                                <div class="stat-value" id="detail-peak-speed">${UploadManager.formatSpeed(upload.peakSpeed)}</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-label">Kalan Süre</div>
                                <div class="stat-value" id="detail-eta">${UploadManager.formatTime(upload.eta)}</div>
                            </div>
                        </div>
                    </div>

                    <!-- Speed Graph -->
                    <div class="detail-section">
                        <h3>📈 Hız Grafiği</h3>
                        <canvas id="speed-graph" width="600" height="200"></canvas>
                    </div>

                    <!-- Actions -->
                    <div class="detail-section">
                        <div class="action-buttons">
                            ${upload.status === 'uploading' ? `
                                <button class="btn btn-warning" onclick="UploadManager.pauseUpload('${upload.id}')">
                                    <i class="fa-solid fa-pause"></i> Duraklat
                                </button>
                            ` : ''}
                            ${upload.status === 'paused' ? `
                                <button class="btn btn-primary" onclick="UploadManager.resumeUpload('${upload.id}')">
                                    <i class="fa-solid fa-play"></i> Devam Et
                                </button>
                            ` : ''}
                            <button class="btn btn-danger" onclick="UploadManager.cancelUpload('${upload.id}'); UploadDetailsModal.close();">
                                <i class="fa-solid fa-times"></i> İptal Et
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                .modal-overlay {
                    position: fixed;
                    inset: 0;
                    background: rgba(0, 0, 0, 0.8);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 999999;
                    backdrop-filter: blur(4px);
                }

                .upload-details-modal {
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    border-radius: 16px;
                    width: 90%;
                    max-width: 700px;
                    max-height: 90vh;
                    overflow-y: auto;
                    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
                    border: 1px solid rgba(139, 92, 246, 0.3);
                }

                .modal-header {
                    padding: 20px 24px;
                    border-bottom: 1px solid rgba(139, 92, 246, 0.2);
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }

                .modal-header h2 {
                    margin: 0;
                    color: #e2e8f0;
                    font-size: 20px;
                }

                .modal-close {
                    background: none;
                    border: none;
                    color: #94a3b8;
                    font-size: 24px;
                    cursor: pointer;
                    padding: 4px 8px;
                    transition: color 0.2s;
                }

                .modal-close:hover {
                    color: #8b5cf6;
                }

                .modal-body {
                    padding: 24px;
                }

                .detail-section {
                    margin-bottom: 24px;
                }

                .detail-section h3 {
                    color: #8b5cf6;
                    font-size: 16px;
                    margin-bottom: 16px;
                }

                .detail-grid {
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 12px;
                }

                .detail-item {
                    display: flex;
                    justify-content: space-between;
                    padding: 12px;
                    background: rgba(139, 92, 246, 0.1);
                    border-radius: 8px;
                }

                .detail-item .label {
                    color: #94a3b8;
                    font-size: 13px;
                }

                .detail-item .value {
                    color: #e2e8f0;
                    font-weight: 600;
                    font-size: 13px;
                }

                .progress-container {
                    position: relative;
                }

                .progress-bar {
                    height: 24px;
                    background: rgba(139, 92, 246, 0.2);
                    border-radius: 12px;
                    overflow: hidden;
                }

                .progress-fill {
                    height: 100%;
                    background: linear-gradient(90deg, #8b5cf6, #a78bfa);
                    transition: width 0.3s;
                }

                .progress-text {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    color: white;
                    font-weight: 700;
                    font-size: 14px;
                }

                .progress-stats {
                    text-align: center;
                    margin-top: 8px;
                    color: #94a3b8;
                    font-size: 13px;
                }

                .stats-grid {
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 12px;
                }

                .stat-card {
                    background: rgba(139, 92, 246, 0.1);
                    padding: 16px;
                    border-radius: 12px;
                    text-align: center;
                }

                .stat-label {
                    color: #94a3b8;
                    font-size: 12px;
                    margin-bottom: 8px;
                }

                .stat-value {
                    color: #8b5cf6;
                    font-size: 20px;
                    font-weight: 700;
                }

                #speed-graph {
                    width: 100%;
                    height: 200px;
                    background: rgba(0, 0, 0, 0.3);
                    border-radius: 8px;
                }

                .action-buttons {
                    display: flex;
                    gap: 12px;
                    justify-content: center;
                }

                .btn {
                    padding: 10px 20px;
                    border: none;
                    border-radius: 8px;
                    font-weight: 600;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    transition: all 0.2s;
                }

                .btn-primary {
                    background: #3b82f6;
                    color: white;
                }

                .btn-warning {
                    background: #fbbf24;
                    color: #1a1a2e;
                }

                .btn-danger {
                    background: #ef4444;
                    color: white;
                }

                .btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                }
            </style>
        `;

        document.body.appendChild(modal);
        this.drawSpeedGraph(upload);
    },

    drawSpeedGraph(upload) {
        const canvas = document.getElementById('speed-graph');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;

        // Clear canvas
        ctx.clearRect(0, 0, width, height);

        if (!upload.speedHistory || upload.speedHistory.length === 0) {
            ctx.fillStyle = '#64748b';
            ctx.font = '14px Inter';
            ctx.textAlign = 'center';
            ctx.fillText('Veri bekleniyor...', width / 2, height / 2);
            return;
        }

        // Find max speed for scaling
        const maxSpeed = Math.max(...upload.speedHistory.map(h => h.speed), 1);

        // Draw grid
        ctx.strokeStyle = 'rgba(100, 116, 139, 0.2)';
        ctx.lineWidth = 1;
        for (let i = 0; i <= 4; i++) {
            const y = (height / 4) * i;
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(width, y);
            ctx.stroke();
        }

        // Draw speed line
        ctx.strokeStyle = '#8b5cf6';
        ctx.lineWidth = 2;
        ctx.beginPath();

        upload.speedHistory.forEach((point, index) => {
            const x = (index / (upload.speedHistory.length - 1)) * width;
            const y = height - (point.speed / maxSpeed) * height;

            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });

        ctx.stroke();

        // Draw labels
        ctx.fillStyle = '#94a3b8';
        ctx.font = '11px Inter';
        ctx.textAlign = 'right';
        ctx.fillText(UploadManager.formatSpeed(maxSpeed), width - 5, 15);
        ctx.fillText('0 B/s', width - 5, height - 5);
    },

    startUpdating() {
        this.updateInterval = setInterval(() => {
            const upload = UploadManager.getUpload(this.currentUploadId);
            if (!upload) {
                this.close();
                return;
            }

            this.updateStats(upload);
        }, 500);
    },

    updateStats(upload) {
        // Update progress
        const progressFill = document.getElementById('detail-progress-fill');
        const progressText = document.getElementById('detail-progress-text');
        const loaded = document.getElementById('detail-loaded');

        if (progressFill) progressFill.style.width = upload.progress + '%';
        if (progressText) progressText.textContent = Math.round(upload.progress) + '%';
        if (loaded) loaded.textContent = UploadManager.formatBytes(upload.loaded);

        // Update speeds
        const currentSpeed = document.getElementById('detail-current-speed');
        const avgSpeed = document.getElementById('detail-avg-speed');
        const peakSpeed = document.getElementById('detail-peak-speed');
        const eta = document.getElementById('detail-eta');

        if (currentSpeed) currentSpeed.textContent = UploadManager.formatSpeed(upload.speed);
        if (avgSpeed) avgSpeed.textContent = UploadManager.formatSpeed(upload.avgSpeed);
        if (peakSpeed) peakSpeed.textContent = UploadManager.formatSpeed(upload.peakSpeed);
        if (eta) eta.textContent = UploadManager.formatTime(upload.eta);

        // Redraw graph
        this.drawSpeedGraph(upload);
    },

    close() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
        }

        const modal = document.getElementById('upload-details-modal');
        if (modal) modal.remove();
    }
};
