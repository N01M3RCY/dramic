// Footer Utilities
const Footer = {
    showPrivacyPolicy() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 800px; max-height: 85vh; border-radius: 12px; background: #1a1a1a; color: #e0e0e0; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);">
                <div class="modal-header" style="border-bottom: 1px solid #333; padding: 20px 25px; background: linear-gradient(to right, #1a1a1a, #252525);">
                    <h2 style="margin: 0; font-size: 1.5rem; color: #fff; display: flex; align-items: center; gap: 10px;">
                        <i class="fa-solid fa-user-shield" style="color: #8b5cf6;"></i> Gizlilik Politikası
                    </h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()" style="background: none; border: none; font-size: 1.5rem; color: #888; cursor: pointer; padding: 5px;">×</button>
                </div>
                <div class="modal-body" style="padding: 25px; overflow-y: auto; max-height: calc(85vh - 80px); line-height: 1.7;">
                    <p style="color: #bbb; margin-bottom: 20px;"><strong>DramicBox</strong> ekibi olarak gizliliğinize ve verilerinizin güvenliğine büyük önem vermekteyiz.</p>

                    <div style="background: rgba(255,255,255,0.05); padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #8b5cf6;">
                        <h3 style="color: #fff; margin: 0 0 10px 0; font-size: 1.1rem;">Veri Toplama ve Kullanımı</h3>
                        <p style="margin: 0;">Kişisel verilerinizi yalnızca hizmetlerimizi sunmak ve iyileştirmek için ihtiyaç duyduğumuzda toplamaktayız.</p>
                    </div>

                    <h3 style="color: #fff; margin-top: 20px; font-size: 1.1rem;">Çerezler ve Takip</h3>
                    <p>Web sitemiz, kullanıcı deneyimini geliştirmek için çerezleri (cookies) kullanabilir.</p>

                    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #333; text-align: center;">
                        <p style="margin-bottom: 15px;">Sorularınız veya bildirimleriniz mi var?</p>
                        <button onclick="Footer.showReportModal()" class="btn btn-primary" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; border-radius: 8px; border: none; cursor: pointer; color: white;">
                             <i class="fa-solid fa-headset"></i> Destek & İletişim
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    showAbout() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px; padding: 0; border-radius: 16px; overflow: hidden;">
                <div class="modal-header" style="background: linear-gradient(135deg, #4f46e5, #7c3aed); padding: 30px 25px; color: white;">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <img src="assets/logo.png" style="width: 50px; height: 50px; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.3));">
                        <div>
                            <h2 style="margin: 0; font-size: 1.8rem; font-weight: 800;">DramicBox</h2>
                            <p style="margin: 5px 0 0 0; opacity: 0.9; font-size: 0.95rem;">Kore Dizileri & Webtoon Platformu</p>
                        </div>
                    </div>
                    <button class="modal-close" onclick="this.closest('.modal').remove()" style="color: white; opacity: 0.8;">×</button>
                </div>
                <div class="modal-body" style="padding: 30px; line-height: 1.7; color: #e2e8f0; background: #1e1e24;">
                    <p style="margin-bottom: 20px;">
                        <strong>DramicBox</strong>, Kore dizileri (KDrama) ve Webtoon severler için oluşturulmuş kapsamlı bir eğlence platformudur. 
                        Amacımız, en güncel ve kaliteli içerikleri Türkçe altyazı seçeneğiyle, kullanıcı dostu bir arayüzde sunmaktır.
                    </p>
                    <p style="margin-bottom: 20px;">
                        2024 yılında kurulan platformumuz, geniş arşivi, gelişmiş video oynatıcısı, kişiselleştirilmiş listeler ve sosyal özellikleriyle 
                        fark yaratmaktadır. Tutkulu ekibimizle her gün daha iyi bir deneyim sunmak için çalışıyoruz.
                    </p>
                    <div style="background: rgba(255,255,255,0.05); padding: 15px; border-radius: 10px; margin-top: 25px; display: flex; gap: 15px; align-items: center;">
                        <i class="fa-solid fa-heart" style="color: #ef4444; font-size: 1.5rem;"></i>
                        <div>
                            <h4 style="margin: 0 0 5px 0; color: white;">Bizi Destekleyin</h4>
                            <p style="margin: 0; font-size: 0.9rem; color: #94a3b8;">DramicBox tamamen ücretsizdir ve gönüllülük esasına dayanır.</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    showTerms() {
        // ... (Keep simpler implementation for terms if needed, or similar enhancement)
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 800px; max-height: 80vh;">
                <div class="modal-header">
                    <h2>Kullanım Şartları</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body" style="padding: 25px; overflow-y: auto;">
                    <h3>1. Genel Şartlar</h3>
                    <p>DramicBox'u kullanarak bu kullanım şartlarını kabul etmiş sayılırsınız.</p>
                    <!-- ... Details ... -->
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    showDMCAForm() {
        document.querySelectorAll('.modal').forEach(m => m.remove());

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'dmca-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 700px; width: 95%; max-height: 95vh; display: flex; flex-direction: column; border-radius: 16px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);">
                <div class="modal-header" style="background: linear-gradient(135deg, #1e3a8a, #4c1d95); padding: 20px 25px; flex-shrink: 0;">
                    <h2 style="color: white; margin: 0; display: flex; align-items: center; gap: 10px;">
                        <i class="fa-solid fa-gavel"></i> DMCA Telif Bildirimi
                    </h2>
                    <button class="modal-close" onclick="document.getElementById('dmca-modal').remove()" style="color: rgba(255,255,255,0.7);">×</button>
                </div>
                <div class="modal-body" style="background: #0f172a; padding: 0; overflow-y: auto; flex: 1;" class="custom-scrollbar">
                    <form onsubmit="Footer.submitDMCA(event)" style="padding: 25px;">
                        <div style="background: rgba(30, 41, 59, 0.5); padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.05);">
                            <p style="color: #94a3b8; font-size: 0.9rem; margin: 0;">
                                <i class="fa-solid fa-circle-info" style="color: #60a5fa; margin-right: 5px;"></i>
                                Telif hakkı ihlali bildirimlerinizi ciddiyetle ele alıyoruz. Lütfen aşağıdaki formu eksiksiz doldurunuz.
                            </p>
                        </div>

                        <h3 style="margin: 0 0 15px 0; color: #e2e8f0; font-size: 1rem; border-bottom: 1px solid #334155; padding-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;">
                            1. İletişim Bilgileri
                        </h3>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 5px; color: #cbd5e1; font-size: 0.9rem;">Ad Soyad *</label>
                                <input type="text" name="name" class="form-input" required placeholder="Tam adınız" style="width: 100%; background: #1e293b; border-color: #334155;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 5px; color: #cbd5e1; font-size: 0.9rem;">E-posta *</label>
                                <input type="email" name="email" class="form-input" required placeholder="ornek@email.com" style="width: 100%; background: #1e293b; border-color: #334155;">
                            </div>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 25px;">
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 5px; color: #cbd5e1; font-size: 0.9rem;">Telefon</label>
                                <input type="tel" name="phone" class="form-input" placeholder="+90..." style="width: 100%; background: #1e293b; border-color: #334155;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 5px; color: #cbd5e1; font-size: 0.9rem;">Şirket / Kurum</label>
                                <input type="text" name="company" class="form-input" placeholder="Varsa temsil edilen kurum" style="width: 100%; background: #1e293b; border-color: #334155;">
                            </div>
                        </div>

                        <div class="form-group" style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 5px; color: #cbd5e1; font-size: 0.9rem;">Açık Adres *</label>
                            <textarea name="address" class="form-input" rows="2" required placeholder="Tebligat adresi..." style="width: 100%; background: #1e293b; border-color: #334155;"></textarea>
                        </div>
                        
                        <h3 style="margin: 0 0 15px 0; color: #e2e8f0; font-size: 1rem; border-bottom: 1px solid #334155; padding-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;">
                            2. İhlal Detayları
                        </h3>
                        
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; color: #cbd5e1; font-size: 0.9rem;">İçerik Başlığı / URL *</label>
                            <input type="text" name="title" class="form-input" required placeholder="İhlal edilen içeriğin adı veya linki" style="width: 100%; background: #1e293b; border-color: #334155;">
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; color: #cbd5e1; font-size: 0.9rem;">Açıklama & Kanıt *</label>
                            <textarea name="description" class="form-input" rows="4" required placeholder="Telif hakkının size ait olduğunu gösteren detaylar..." style="width: 100%; background: #1e293b; border-color: #334155;"></textarea>
                        </div>

                        <div class="form-group" style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 5px; color: #cbd5e1; font-size: 0.9rem;">Dijital İmza (Ad Soyad) *</label>
                            <input type="text" name="signature" class="form-input" required placeholder="İmza niyetine tam adınızı yazın" style="width: 100%; background: #1e293b; border-color: #334155; font-family: monospace;">
                        </div>
                        
                        <div class="form-group" style="margin-bottom: 25px;">
                            <label style="display: flex; align-items: start; gap: 12px; cursor: pointer; background: rgba(76, 29, 149, 0.1); padding: 12px; border-radius: 8px; border: 1px solid rgba(76, 29, 149, 0.3);">
                                <input type="checkbox" required style="margin-top: 4px;">
                                <span style="font-size: 0.85em; color: #cbd5e1;">
                                    Yukarıdaki bilgilerin doğru olduğunu, telif hakkı sahibi olduğumu veya yetkili temsilci olarak hareket ettiğimi beyan ederim. Yalan beyanın yasal sorumluluklarını kabul ediyorum.
                                </span>
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" style="width: 100%; background: linear-gradient(135deg, #6366f1, #8b5cf6); border: none; padding: 14px; font-weight: bold; font-size: 1rem; border-radius: 10px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2);">
                            <i class="fa-solid fa-paper-plane"></i> Bildirimi Gönder
                        </button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async submitDMCA(event) {
        event.preventDefault();
        const form = event.target;

        const reportId = 'DMCA-' + Date.now();
        const data = {
            id: reportId,
            name: form.name.value,
            email: form.email.value,
            phone: form.phone.value,
            company: form.company.value,
            address: form.address.value,
            title: form.title.value,
            description: form.description.value,
            signature: form.signature.value,
            type: 'dmca',
            createdAt: new Date().toISOString(),
            status: 'open'
        };

        try {
            // 1. Add to AdminSupport System as a Ticket
            if (window.AdminSupport) {
                AdminSupport.createSystemTicket({
                    subject: 'DMCA Bildirimi: ' + data.title,
                    description: `Gönderen: ${data.name} (${data.email})\nKurum: ${data.company}\nTel: ${data.phone}\nAdres: ${data.address}\nİmza: ${data.signature}\n\nDetay:\n${data.description}`,
                    category: 'copyright',
                    priority: 'high',
                    metadata: data
                });
            }

            // 2. Also save to specific DMCA list if needed
            if (!State.data.dmcaReports) State.data.dmcaReports = [];
            State.data.dmcaReports.push(data);

            if (window.db && window.db.save) await window.db.save();

            Toast.success('DMCA bildiriminiz başarıyla alındı. Teşekkürler.');
            document.getElementById('dmca-modal').remove();

        } catch (error) {
            console.error('DMCA Submit Error:', error);
            Toast.error('Bildirim kaydedilirken hata oluştu.');
        }
    },

    showReportModal() {
        document.querySelectorAll('.modal').forEach(m => m.remove());

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 500px; border-radius: 16px;">
                <div class="modal-header" style="border-bottom: 1px solid rgba(255,255,255,0.1); padding: 20px;">
                    <h2 style="margin:0; font-size:1.3rem;"><i class="fa-solid fa-headset" style="color:#f59e0b;"></i> Destek & İletişim</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body" style="padding: 25px;">
                    <form onsubmit="Footer.submitReport(event)">
                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; font-weight:600;">Konu</label>
                            <select name="subject" class="form-input" style="width:100%;">
                                <option>Hata Bildirimi (Bug)</option>
                                <option>Öneri / İstek</option>
                                <option>İşbirliği</option>
                                <option>Diğer</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; font-weight:600;">Mesajınız</label>
                            <textarea name="message" class="form-input" rows="5" placeholder="Lütfen detaylı bilgi veriniz..." required style="width:100%;"></textarea>
                        </div>
                        ${!State.currentUser ? `
                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; font-weight:600;">E-posta Adresiniz</label>
                            <input type="email" name="email" class="form-input" placeholder="Size ulaşabilmemiz için..." required style="width:100%;">
                        </div>
                        ` : ''}
                        <button type="submit" class="btn btn-primary" style="width:100%; margin-top:10px; padding:12px;">
                            <i class="fa-solid fa-paper-plane"></i> Gönder
                        </button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async submitReport(event) {
        event.preventDefault();
        const form = event.target;

        try {
            const userEmail = form.email ? form.email.value : (State.currentUser ? 'usersystem@dramic.box' : 'anonymous');

            // Create a ticket via AdminSupport
            if (window.AdminSupport) {
                AdminSupport.createSystemTicket({
                    subject: form.subject.value,
                    description: form.message.value + (form.email ? `\n\nİletişim: ${form.email.value}` : ''),
                    category: 'other',
                    userId: State.currentUser ? State.currentUser.id : 'guest',
                    username: State.currentUser ? State.currentUser.username : (form.email ? form.email.value.split('@')[0] : 'Misafir')
                });
            } else {
                // Fallback direct save
                if (!State.data.tickets) State.data.tickets = [];
                State.data.tickets.push({
                    id: 'report-' + Date.now(),
                    subject: form.subject.value,
                    description: form.message.value,
                    status: 'open',
                    createdAt: Date.now()
                });
                if (window.db) window.db.save();
            }

            Toast.success('talebiniz alındı! En kısa sürede dönüş yapacağız.');
            document.querySelector('.modal').remove();
        } catch (error) {
            console.error('Report error:', error);
            Toast.error('Bir hata oluştu.');
        }
    }
};

console.log('✅ Footer Utilities Loaded!');
window.Footer = Footer;
