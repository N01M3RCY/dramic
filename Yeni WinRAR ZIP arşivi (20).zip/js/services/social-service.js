/**
 * Social Service
 * Handles Friends, Friend Requests, and Messaging
 */

const SocialService = {
    // --- FRIENDS ---

    async sendFriendRequest(targetUserId) {
        if (!State.currentUser) {
            Toast.error("Giriş yapmalısınız!");
            return;
        }

        if (State.currentUser.id === targetUserId) {
            Toast.error("Kendinize istek gönderemezsiniz.");
            return;
        }

        // Initialize user structures
        if (!State.currentUser.friendRequests) State.currentUser.friendRequests = [];
        if (!State.currentUser.friends) State.currentUser.friends = [];

        // Check availability
        const targetUser = State.data.users.find(u => u.id === targetUserId);
        if (!targetUser) {
            Toast.error("Kullanıcı bulunamadı.");
            return;
        }
        if (State.currentUser.friends.includes(targetUserId)) {
            Toast.info("Zaten arkadaşsınız.");
            return;
        }

        // Check outgoing
        const existingReq = (targetUser.friendRequests || []).find(r => r.from === State.currentUser.id);
        if (existingReq) {
            Toast.warning("Zaten bir istek gönderdiniz.");
            return;
        }

        // Send Request to Target
        if (!targetUser.friendRequests) targetUser.friendRequests = [];
        targetUser.friendRequests.push({
            id: 'req-' + Date.now(),
            from: State.currentUser.id,
            timestamp: Date.now(),
            status: 'pending'
        });

        // Save
        await db.syncItem('users', targetUser, false);
        await db.syncItem('users', State.currentUser, false);
        Toast.success("Arkadaşlık isteği gönderildi!");
    },

    async acceptFriendRequest(requestId, fromUserId) {
        // Find request
        const reqIndex = (State.currentUser.friendRequests || []).findIndex(r => r.id === requestId || r.from === fromUserId);
        if (reqIndex === -1) return;

        // Add to Friends (Mutual)
        if (!State.currentUser.friends) State.currentUser.friends = [];
        if (!State.currentUser.friends.includes(fromUserId)) {
            State.currentUser.friends.push(fromUserId);
        }

        const sender = State.data.users.find(u => u.id === fromUserId);
        if (sender) {
            if (!sender.friends) sender.friends = [];
            if (!sender.friends.includes(State.currentUser.id)) {
                sender.friends.push(State.currentUser.id);
            }
        }

        // Remove Request
        State.currentUser.friendRequests.splice(reqIndex, 1);

        // Save
        await db.syncItem('users', State.currentUser, false);
        if (sender) await db.syncItem('users', sender, false);
        Toast.success("Arkadaşlık isteği kabul edildi!");

        // Refresh UI if Profile is open
        if (typeof UserProfile !== 'undefined' && UserProfile.currentUserId === State.currentUser.id) {
            UserProfile.switchTab('friends'); // Or refresh
        }
    },

    async rejectFriendRequest(requestId) {
        const reqIndex = (State.currentUser.friendRequests || []).findIndex(r => r.id === requestId);
        if (reqIndex > -1) {
            State.currentUser.friendRequests.splice(reqIndex, 1);
            await db.syncItem('users', State.currentUser, false);
            Toast.info("İstek reddedildi.");
        }
    },

    // --- BIO & PROFILE EDIT ---
    async updateProfile(userId, newData) {
        const user = State.data.users.find(u => u.id === userId);
        if (!user) return false;

        Object.assign(user, newData);

        if (State.currentUser.id === userId) {
            State.currentUser = { ...State.currentUser, ...newData };
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        }

        await db.syncItem('users', user, false);
        Toast.success("Profil güncellendi!");
        return true;
    }
};

window.SocialService = SocialService;
// window.MessageService = SocialService; // REMOVED: Aliasing was causing conflicts with the real MessageService
