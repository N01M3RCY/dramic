// ============================================
// APPROVAL SERVICE
// Centralized system for managing content approvals
// ============================================

const ApprovalService = {
    pendingItems: [],

    // Initialize
    async init() {
        if (this.canModerate()) {
            await this.loadPendingItems();
        }
    },

    canModerate() {
        return State.currentUser && (
            State.currentUser.role === 'admin' ||
            (State.currentUser.badges && State.currentUser.badges.includes('Yönetici'))
        );
    },

    // Load all pending items (Local-First)
    async loadPendingItems() {
        if (!State.data) return;
        
        const pendingSeries = (State.data.series || []).filter(s => s.status === 'pending').map(s => ({ ...s, type: 'series' }));
        const pendingSocial = (State.data.socialPosts || []).filter(p => p.status === 'pending').map(p => ({ ...p, type: 'social' }));
        const pendingSource = (State.data.sourceApprovals || []).filter(a => a.status === 'pending').map(a => ({ ...a, type: 'source' }));
        const pendingTickets = (State.data.tickets || []).filter(t => t.status === 'open' || t.status === 'replied').map(t => ({ ...t, type: 'ticket' }));

        this.pendingItems = [...pendingSeries, ...pendingSocial, ...pendingSource, ...pendingTickets];
        this.updateBadge();
    },

    updateBadge() {
        const badge = document.getElementById('admin-approvals-badge');
        if (badge) {
            const count = this.pendingItems.length;
            if (count > 0) {
                badge.style.display = 'flex';
                badge.innerText = count;
            } else {
                badge.style.display = 'none';
            }
        }
    },

    // Approve an item (Local-First)
    async approveItem(type, id, data = {}) {
        if (!confirm('Bu içeriği onaylamak istediğinizden emin misiniz?')) return;

        let target = null;
        if (type === 'series') target = State.data.series.find(s => s.id === id);
        else if (type === 'social') target = State.data.socialPosts.find(p => p.id === id);
        else if (type === 'source') target = State.data.sourceApprovals.find(a => a.id === id);

        if (target) {
            target.status = 'approved';
            target.approvedAt = new Date().toISOString();
            target.approvedBy = State.currentUser.id;
            
            db.save();
            Toast.success('✅ İçerik onaylandı ve yayınlandı.');
            
            this.pendingItems = this.pendingItems.filter(item => item.id !== id);
            this.updateBadge();
            
            if (window.AdminApprovals && AdminApprovals.renderList) {
                AdminApprovals.renderList();
            }
        } else {
            Toast.error('İçerik bulunamadı.');
        }
    },

    // Reject an item (Local-First)
    async rejectItem(type, id) {
        const reason = prompt('Reddetme sebebi (kullanıcıya iletilecek):');
        if (reason === null) return;

        let target = null;
        if (type === 'series') target = State.data.series.find(s => s.id === id);
        else if (type === 'social') target = State.data.socialPosts.find(p => p.id === id);
        else if (type === 'source') target = State.data.sourceApprovals.find(a => a.id === id);

        if (target) {
            target.status = 'rejected';
            target.rejectionReason = reason;
            target.rejectedAt = new Date().toISOString();
            target.rejectedBy = State.currentUser.id;
            
            db.save();
            Toast.warning('❌ İçerik reddedildi.');
            
            this.pendingItems = this.pendingItems.filter(item => item.id !== id);
            this.updateBadge();
            
            if (window.AdminApprovals && AdminApprovals.renderList) {
                AdminApprovals.renderList();
            }
        } else {
            Toast.error('İçerik bulunamadı.');
        }
    },

    async submitReport(data) {
        const res = await fetch('api/db.php?action=ticket-create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return await res.json();
    }
};

window.ApprovalService = ApprovalService;
