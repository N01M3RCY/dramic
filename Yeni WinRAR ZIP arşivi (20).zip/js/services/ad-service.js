/**
 * AdService - Handles Pre-roll Ads, Social Ads, and Blog Ads
 */
const AdService = {
    config: {
        preRollDuration: 5,
        socialAdFrequency: 5,
        blogAdFrequency: 3,
        ads: [
            {
                id: 'ad-1',
                type: 'image',
                url: 'https://via.placeholder.com/800x450?text=Premium+Reklam+Alanı',
                link: '/vip-uyelik',
                title: 'DramicBox Premium'
            },
            {
                id: 'ad-2',
                type: 'video',
                url: 'https://www.w3schools.com/html/mov_bbb.mp4',
                link: '/ana-sayfa',
                title: 'Yeni Dizileri Kaçırma!'
            }
        ]
    },

    /**
     * Centralized check to determine if ads should be shown to the current user
     */
    shouldShowAds() {
        if (!typeof State !== 'undefined' || !State.currentUser) return true; // Show to guests

        const user = State.currentUser;
        const badges = user.badges || [];
        const role = user.role || 'guest';

        // Exemptions: Admins, Managers, Translators, VIPs, Premium members, No-Ads item holders
        const hasNoAdsItem = user.inventory?.includes('no_ads_week');

        const isExempt =
            role === 'admin' ||
            role === 'translator' ||
            badges.includes('Yönetici') ||
            badges.includes('Admin') ||
            badges.includes('Moderatör') ||
            badges.includes('VIP') ||
            badges.includes('Premium') ||
            badges.includes('Altın Üye') ||
            badges.includes('Elmas Üye') ||
            badges.includes('Çevirmen') ||
            hasNoAdsItem;

        return !isExempt;
    },

    /**
     * Updates service config from global settings
     */
    initSync() {
        if (typeof State !== 'undefined' && State.data?.settings) {
            let adsSetting = null;
            if (Array.isArray(State.data.settings)) {
                adsSetting = State.data.settings.find(s => s.id === 'ads');
            } else if (State.data.settings.ads) {
                adsSetting = State.data.settings.ads;
            }
            if (adsSetting) {
                this.config = { ...this.config, ...adsSetting };
                console.log('📢 AdService config synced with database', this.config);
            }
        }
    },

    getRandomAd() {
        return this.config.ads[Math.floor(Math.random() * this.config.ads.length)];
    },

    /**
     * Shows a 5s pre-roll ad before executing the callback
     */
    showPreRoll(callback) {
        const ad = this.getRandomAd();
        const overlay = document.createElement('div');
        overlay.id = 'ad-pre-roll-overlay';
        overlay.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: #000; z-index: 100000; display: flex; flex-direction: column;
            align-items: center; justify-content: center; font-family: 'Inter', sans-serif;
        `;

        let adContent = '';
        if (ad.type === 'video') {
            adContent = `<video src="${ad.url}" autoplay muted style="max-width: 90%; max-height: 70%; border-radius: 12px;"></video>`;
        } else {
            adContent = `<img src="${ad.url}" style="max-width: 90%; max-height: 70%; border-radius: 12px; cursor: pointer;" onclick="window.open('${ad.link}', '_blank')">`;
        }

        overlay.innerHTML = `
            <div style="position: absolute; top: 20px; right: 20px; color: #fff; background: rgba(0,0,0,0.5); padding: 8px 16px; border-radius: 20px; font-size: 14px; font-weight: 600;">
                Reklam bitiyor: <span id="ad-timer">${this.config.preRollDuration}</span>s
            </div>
            ${adContent}
            <div style="margin-top: 30px; text-align: center; color: rgba(255,255,255,0.6);">
                <h3 style="color: #fff; margin-bottom: 5px;">${ad.title}</h3>
                <p style="font-size: 14px;">Reklam bittikten sonra içerik yüklenecektir.</p>
            </div>
            <button id="skip-ad-btn" disabled style="margin-top: 20px; padding: 12px 24px; border-radius: 30px; border: 1px solid rgba(255,255,255,0.2); background: rgba(255,255,255,0.05); color: #fff; cursor: not-allowed; transition: all 0.3s;">
                Reklamı Geç
            </button>
        `;

        document.body.appendChild(overlay);

        let timeLeft = this.config.preRollDuration;
        const timerEl = document.getElementById('ad-timer');
        const skipBtn = document.getElementById('skip-ad-btn');

        const interval = setInterval(() => {
            timeLeft--;
            if (timerEl) timerEl.textContent = timeLeft;

            if (timeLeft <= 0) {
                clearInterval(interval);
                if (skipBtn) {
                    skipBtn.disabled = false;
                    skipBtn.style.background = 'var(--accent-color, #7c3aed)';
                    skipBtn.style.borderColor = 'var(--accent-color, #7c3aed)';
                    skipBtn.style.cursor = 'pointer';
                    skipBtn.textContent = 'İçeriğe Git';
                    skipBtn.onclick = () => {
                        overlay.remove();
                        if (callback) callback();
                    };
                }
            }
        }, 1000);
    },

    /**
     * Injects ads into an array of posts
     */
    injectSocialAds(posts) {
        if (!posts || !Array.isArray(posts)) return posts;
        const result = [];
        posts.forEach((post, index) => {
            result.push(post);
            if ((index + 1) % this.config.socialAdFrequency === 0) {
                const ad = this.getRandomAd();
                result.push({
                    id: `ad-post-${Date.now()}-${index}`,
                    isAd: true,
                    author: { username: 'Sponsorlu', avatar: 'assets/logo.png' },
                    content: ad.title,
                    image: ad.url,
                    link: ad.link,
                    timestamp: Date.now()
                });
            }
        });
        return result;
    },

    /**
     * Injects ads into blog content HTML
     */
    injectBlogAds(html) {
        if (!html) return html;
        const paragraphs = html.split('</p>');
        if (paragraphs.length <= this.config.blogAdFrequency) return html;

        const result = [];
        paragraphs.forEach((p, index) => {
            result.push(p + '</p>');
            if ((index + 1) % this.config.blogAdFrequency === 0 && index < paragraphs.length - 1) {
                const ad = this.getRandomAd();
                result.push(`
                    <div class="blog-ad-banner" style="margin: 30px 0; border-radius: 12px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05);">
                        <div style="font-size: 10px; color: #64748b; text-transform: uppercase; padding: 4px 10px; background: rgba(255,255,255,0.02);">Sponsorlu</div>
                        <a href="${ad.link}" target="_blank">
                            <img src="${ad.url}" style="width: 100%; display: block;">
                        </a>
                        <div style="padding: 10px; background: rgba(0,0,0,0.2); font-weight: 600; font-size: 14px;">${ad.title}</div>
                    </div>
                `);
            }
        });
        return result.join('');
    }
};

// Auto-sync after loading and periodically
setTimeout(() => {
    AdService.initSync();
    setInterval(() => AdService.initSync(), 5000);
}, 1000);

