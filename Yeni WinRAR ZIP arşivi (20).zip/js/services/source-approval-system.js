// ============================================
// SOURCE APPROVAL SYSTEM
// Admin approval workflow for translator-added sources
// ============================================

if (typeof SourceApprovalSystem === 'undefined') {
    window.SourceApprovalSystem = {
        pendingApprovals: [],

        async init() {
            await this.loadApprovals();
        },

        async loadApprovals() {
            try {
                // Local-first: use State.data
                if (!State.data.sourceApprovals) State.data.sourceApprovals = [];
                this.pendingApprovals = State.data.sourceApprovals;
                console.log('[Approvals] Loaded:', this.pendingApprovals.length);
            } catch (error) {
                console.error('[Approvals] Load failed:', error);
                this.pendingApprovals = [];
            }
        },

        // Submit source for approval (called by translators)
        async submitForApproval(sourceData, seriesId, episodeNumber, seriesTitle) {
            const approval = {
                id: `approval-${Date.now()}`,
                source: sourceData,
                seriesId: seriesId,
                seriesTitle: seriesTitle,
                episodeNumber: episodeNumber,
                submittedBy: State.currentUser.id,
                submittedByName: State.currentUser.username,
                submittedAt: new Date().toISOString(),
                status: 'pending',
                reviewedBy: null,
                reviewedAt: null,
                reviewNotes: null // No subtitle separate arg, it's inside sourceData
            };

            // Add to pending list
            this.pendingApprovals.push(approval);

            // Save locally
            try {
                if (!State.data.sourceApprovals) State.data.sourceApprovals = [];
                State.data.sourceApprovals.push(approval);
                await db.save();
                
                Toast.info('✅ Kaynak admin onayına gönderildi');
                return true;
            } catch (error) {
                console.error('[Approvals] Submit failed:', error);
                Toast.error('Kayıt hatası');
                return false;
            }
        },

        // Approve source (admin only)
        async approve(approvalId) {
            const approval = this.pendingApprovals.find(a => a.id === approvalId);
            if (!approval) {
                Toast.error('Onay bulunamadı');
                return false;
            }

            // Update status
            approval.status = 'approved';
            approval.reviewedBy = State.currentUser.id;
            approval.reviewedAt = new Date().toISOString();

            // Add source to episode
            try {
                const series = State.data.series.find(s => s.id === approval.seriesId);
                if (!series) throw new Error('Series not found');

                // Find episode
                let episode = null;
                if (series.seasons && Array.isArray(series.seasons)) {
                    for (let season of series.seasons) {
                        if (season.episodes) {
                            episode = season.episodes.find(e => e.number == approval.episodeNumber);
                            if (episode) break;
                        }
                    }
                }
                if (!episode && series.episodes) {
                    episode = series.episodes.find(e => e.number == approval.episodeNumber);
                }

                if (!episode) throw new Error('Episode not found');

                // Add source
                if (!episode.sources) episode.sources = [];

                // Subtitle Processing (Simulated Saving)
                const sourceToAdd = { ...approval.source };
                if (sourceToAdd.subtitle) {
                    // Here we would ideally upload sourceToAdd.subtitle.content to a file
                    // For now, we add it as a track with inline content (if supported) or simulated URL
                    if (!sourceToAdd.tracks) sourceToAdd.tracks = [];
                    sourceToAdd.tracks.push({
                        kind: 'captions',
                        label: 'Türkçe',
                        default: true,
                        // If player supports blob: use content. If not, this needs backend save.
                        // Assuming player handles object URLs or content:
                        content: sourceToAdd.subtitle.content
                    });
                    delete sourceToAdd.subtitle; // Clean up large content object if not needed there
                }

                episode.sources.push(sourceToAdd);

                // Save series
                await db.updateSeries(approval.seriesId, series);

                // Remove from pending
                this.pendingApprovals = this.pendingApprovals.filter(a => a.id !== approvalId);

                // Save approvals
                await this.saveApprovals();

                Toast.success('✅ Kaynak onaylandı ve yayınlandı');
                return true;
            } catch (error) {
                console.error('[Approvals] Approve failed:', error);
                Toast.error('Onaylama başarısız');
                return false;
            }
        },

        // Reject source (admin only)
        async reject(approvalId, reason = '') {
            const approval = this.pendingApprovals.find(a => a.id === approvalId);
            if (!approval) {
                Toast.error('Onay bulunamadı');
                return false;
            }

            approval.status = 'rejected';
            approval.reviewedBy = State.currentUser.id;
            approval.reviewedAt = new Date().toISOString();
            approval.reviewNotes = reason;

            // Remove from pending
            this.pendingApprovals = this.pendingApprovals.filter(a => a.id !== approvalId);

            await this.saveApprovals();

            Toast.warning('❌ Kaynak reddedildi');
            return true;
        },

        async saveApprovals() {
            try {
                State.data.sourceApprovals = this.pendingApprovals;
                await db.save();
                return { success: true };
            } catch (error) {
                console.error('[Approvals] Save failed:', error);
                return { success: false };
            }
        },

        // Get pending count
        getPendingCount() {
            return this.pendingApprovals.filter(a => a.status === 'pending').length;
        },

        // Render approval UI (for admin)
        renderApprovalList() {
            if (this.pendingApprovals.length === 0) {
                return `
                <div class="empty-state">
                    <i class="fa-solid fa-check-circle"></i>
                    <h3>Onay Bekleyen Kaynak Yok</h3>
                    <p>Tüm kaynaklar onaylandı!</p>
                </div>
            `;
            }

            return this.pendingApprovals.map(approval => `
            <div class="approval-card">
                <div class="approval-header">
                    <div class="approval-series">
                        <i class="fa-solid fa-film"></i>
                        ${approval.seriesTitle} - Bölüm ${approval.episodeNumber}
                    </div>
                    <div class="approval-status pending">Bekliyor</div>
                </div>
                <div class="approval-body">
                    <div class="approval-source">
                        <strong>${approval.source.name || approval.source.label}</strong>
                        <span class="source-platform">${approval.source.platform}</span>
                        <span class="source-quality">${approval.source.quality}</span>
                        ${approval.source.subtitle ? '<span class="badge" style="background: #8b5cf6; color:white; font-size:10px; margin-left:5px;">Alt Yazılı</span>' : ''}
                    </div>
                    <div class="approval-url">
                        <i class="fa-solid fa-link"></i>
                        <a href="${approval.source.url}" target="_blank" rel="noopener">
                            ${approval.source.url.substring(0, 50)}...
                        </a>
                    </div>
                    <div class="approval-meta">
                        <span>
                            <i class="fa-solid fa-user"></i>
                            ${approval.submittedByName}
                        </span>
                        <span>
                            <i class="fa-solid fa-calendar"></i>
                            ${new Date(approval.submittedAt).toLocaleString('tr-TR')}
                        </span>
                    </div>
                </div>
                <div class="approval-actions">
                    <button class="btn btn-success" onclick="SourceApprovalSystem.approve('${approval.id}')">
                        <i class="fa-solid fa-check"></i> Onayla
                    </button>
                    <button class="btn btn-danger" onclick="SourceApprovalSystem.rejectWithReason('${approval.id}')">
                        <i class="fa-solid fa-times"></i> Reddet
                    </button>
                    ${approval.source.subtitle ? `
                        <button class="btn btn-outline" onclick="/* Subtitle Preview Logic */ Toast.info('Alt yazı: ' + '${approval.source.subtitle.name}')">
                             <i class="fa-solid fa-closed-captioning"></i> ${approval.source.subtitle.name.substring(0, 10)}...
                        </button>
                    ` : ''}
                    <button class="btn btn-outline" onclick="window.open('${approval.source.url}', '_blank')">
                        <i class="fa-solid fa-eye"></i> Önizle
                    </button>
                </div>
            </div>
        `).join('');
        },

        rejectWithReason(approvalId) {
            const reason = prompt('Reddetme sebebi (opsiyonel):');
            this.reject(approvalId, reason || '');
        }
    };

    // Initialize on load
    document.addEventListener('DOMContentLoaded', () => {
        SourceApprovalSystem.init();
    });
}
