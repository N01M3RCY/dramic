const MessageService = {
    // Basic caching
    messages: [],

    async fetchMessages(userId) {
        try {
            const res = await fetch(`api/db.php?action=message-list&userId=${userId}`);
            const result = await res.json();
            if (result.success && result.messages) {
                this.messages = result.messages;
                State.data.messages = result.messages; // Update local cache
                return this.messages;
            }
        } catch (e) {
            console.warn("Msg fetch from API failed, falling back to local cache", e);
        }
        // LocalStorage fallback
        if (!State.data.messages) State.data.messages = [];
        this.messages = State.data.messages.filter(m => m.from === userId || m.to === userId);
        return this.messages;
    },

    async sendMessage(toUserId, text) {
        try {
            if (!State.data.messages) State.data.messages = [];
            
            const newMessage = {
                id: 'msg_' + Date.now(),
                from: State.currentUser.id,
                to: toUserId,
                text: text,
                timestamp: Date.now(),
                read: false
            };

            // Optimistic update
            State.data.messages.push(newMessage);
            this.messages.push(newMessage);
            db.saveDebounced();
            
            const res = await fetch(`api/db.php?action=message-send`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newMessage)
            });
            const result = await res.json();
            
            return { success: true, message: result.message || newMessage };
        } catch (e) {
            console.error("Msg send error", e);
            // It will at least be in localStorage
            return { success: true, localOnly: true };
        }
    },

    async sendTradeMessage(toUserId, tradeDetails) {
        try {
            if (!State.data.messages) State.data.messages = [];
            
            const newMessage = {
                id: 'msg_' + Date.now(),
                from: State.currentUser.id,
                to: toUserId,
                text: '🤝 Oyuncu Kartı Takas Teklifi Gönderildi!',
                type: 'trade',
                status: 'pending',
                tradeDetails: tradeDetails,
                timestamp: Date.now(),
                read: false
            };

            // Optimistic update
            State.data.messages.push(newMessage);
            this.messages.push(newMessage);
            db.saveDebounced();
            
            const res = await fetch(`api/db.php?action=message-send`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newMessage)
            });
            const result = await res.json();
            
            return { success: true, message: result.message || newMessage };
        } catch (e) {
            console.error("Trade Msg send error", e);
            return { success: true, localOnly: true };
        }
    },

    async markAsRead(msgId) {
        try {
            if (!State.data.messages) return false;
            
            const msg = State.data.messages.find(m => m.id === msgId);
            if (msg) {
                msg.read = true;
                db.saveDebounced();
            }

            // Update local cache
            const cacheMsg = this.messages.find(m => m.id === msgId);
            if (cacheMsg) cacheMsg.read = true;
            
            await fetch(`api/db.php?action=message-read`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: msgId, userId: State.currentUser.id })
            });
            
            return true;
        } catch (e) {
            return false;
        }
    },

    // Get conversations grouped by user
    getConversations(currentUserId) {
        const conversations = {};
        
        // Ensure we have current messages
        if (!State.data.messages) State.data.messages = [];
        this.messages = State.data.messages.filter(m => m.from === currentUserId || m.to === currentUserId);

        this.messages.forEach(msg => {
            const otherId = msg.from === currentUserId ? msg.to : msg.from;

            if (!conversations[otherId]) {
                // Find user info
                const otherUser = State.data.users?.find(u => u.id === otherId) || { username: 'Bilinmeyen Kullanıcı', avatar: 'assets/logo.png' };

                conversations[otherId] = {
                    userId: otherId,
                    username: otherUser.username,
                    avatar: otherUser.avatar || 'assets/logo.png',
                    messages: [],
                    unreadCount: 0,
                    lastMessage: null
                };
            }

            conversations[otherId].messages.push(msg);

            if (msg.to === currentUserId && !msg.read) {
                conversations[otherId].unreadCount++;
            }
        });

        // Sort messages within convos and set last message
        Object.values(conversations).forEach(convo => {
            if (convo.messages.length > 0) {
                convo.messages.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
                convo.lastMessage = convo.messages[convo.messages.length - 1];
            }
        });

        return Object.values(conversations)
            .filter(c => c.lastMessage) // Only show convos with at least one message
            .sort((a, b) => {
                return (b.lastMessage.timestamp || 0) - (a.lastMessage.timestamp || 0);
            });
    }
};

window.MessageService = MessageService;
