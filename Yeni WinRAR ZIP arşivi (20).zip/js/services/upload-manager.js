// ============================================
// UPLOAD MANAGER SERVICE
// Manages background uploads with progress tracking
// ============================================

if (typeof UploadManager === 'undefined') {
    window.UploadManager = {
    uploads: new Map(), // uploadId -> upload object
    listeners: {},
    nextId: 1,

    init() {
        console.log('📤 UploadManager initialized');
        this.loadFromStorage();

        // Cleanup completed uploads after 1 hour
        setInterval(() => this.cleanupOldUploads(), 3600000);
    },

    // Start a new upload
    startUpload(file, metadata = {}) {
        const uploadId = `upload-${Date.now()}-${this.nextId++}`;

        const upload = {
            id: uploadId,
            file: file,
            metadata: {
                seriesId: metadata.seriesId,
                seriesTitle: metadata.seriesTitle,
                episodeNumber: metadata.episodeNumber,
                fileName: file.name,
                fileSize: file.size,
                ...metadata
            },
            status: 'uploading', // uploading, paused, completed, error
            progress: 0,
            loaded: 0,
            total: file.size,
            speed: 0, // bytes per second
            avgSpeed: 0,
            peakSpeed: 0,
            startTime: Date.now(),
            lastUpdateTime: Date.now(),
            eta: null,
            error: null,
            xhr: null,
            speedHistory: [] // for graph
        };

        this.uploads.set(uploadId, upload);
        this.saveToStorage();

        console.log(`[UploadManager] Starting upload: ${uploadId}`, upload.metadata);

        // Start actual upload
        this._performUpload(upload);

        this.emit('started', upload);
        return uploadId;
    },

    async _performUpload(upload) {
        // 1. Get Server Limits
        let CHUNK_SIZE = 5 * 1024 * 1024; // Default 5MB
        try {
            const res = await fetch('api/db.php?action=get-server-limits');
            const data = await res.json();
            if (data.success && data.limit) {
                // Use 90% of server limit to be safe, max 100MB per chunk
                const safeLimit = Math.floor(data.limit * 0.9);
                CHUNK_SIZE = Math.min(safeLimit, 100 * 1024 * 1024);
                console.log(`[UploadManager] Dynamic Chunk Size: ${this.formatBytes(CHUNK_SIZE)} (Server Limit: ${this.formatBytes(data.limit)})`);
            }
        } catch (e) {
            console.warn('[UploadManager] Failed to get limits, using default 5MB', e);
        }

        const totalChunks = Math.ceil(upload.total / CHUNK_SIZE);

        upload.chunkIndex = 0;
        upload.totalChunks = totalChunks;

        // Start speed tracker
        this._startSpeedTracker(upload);

        const uploadChunk = async (index, retryCount = 0) => {
            if (upload.status !== 'uploading' && upload.status !== 'paused') return;
            if (upload.status === 'paused') return;

            const start = index * CHUNK_SIZE;
            const end = Math.min(start + CHUNK_SIZE, upload.total);
            const chunk = upload.file.slice(start, end);

            const formData = new FormData();
            formData.append('seriesId', upload.metadata.seriesId);
            formData.append('seriesTitle', upload.metadata.seriesTitle);
            formData.append('episodeNumber', upload.metadata.episodeNumber);
            formData.append('videoFile', chunk, upload.file.name);

            // Chunk Metadata
            formData.append('chunkIndex', index);
            formData.append('totalChunks', totalChunks);
            formData.append('chunkSize', CHUNK_SIZE);
            formData.append('totalSize', upload.total);

            try {
                return await new Promise((resolve, reject) => {
                    const xhr = new XMLHttpRequest();
                    upload.xhr = xhr;
                    xhr.timeout = 600000; // 10 mins per chunk

                    xhr.open('POST', 'api/db.php?action=upload-video-chunk', true);

                    xhr.upload.onprogress = (e) => {
                        if (e.lengthComputable) {
                            const currentLoaded = start + e.loaded;
                            upload.loaded = currentLoaded;
                            upload.progress = (currentLoaded / upload.total) * 100;
                            upload.lastUpdateTime = Date.now();
                        }
                    };

                    xhr.onload = () => {
                        if (xhr.status === 200) {
                            try {
                                const result = JSON.parse(xhr.responseText);
                                if (result.success) resolve(result);
                                else reject(new Error(result.message || 'Server error'));
                            } catch (e) {
                                reject(new Error('Invalid JSON response'));
                            }
                        } else {
                            reject(new Error(`HTTP ${xhr.status}`));
                        }
                    };

                    xhr.onerror = () => reject(new Error('Network error'));
                    xhr.ontimeout = () => reject(new Error('Timeout'));

                    xhr.send(formData);
                });
            } catch (err) {
                if (retryCount < 3) {
                    console.log(`[UploadManager] Chunk ${index} failed, retrying (${retryCount + 1}/3)...`);
                    await new Promise(r => setTimeout(r, 2000)); // Wait 2s
                    return uploadChunk(index, retryCount + 1);
                }
                throw err;
            }
        };

        try {
            for (let i = 0; i < totalChunks; i++) {
                if (upload.status !== 'uploading') break;

                upload.chunkIndex = i;
                const result = await uploadChunk(i);

                // If this was the last chunk and we got a URL
                if (i === totalChunks - 1 && result.url) {
                    this._finishUpload(upload, result);
                    return;
                }
            }
        } catch (err) {
            console.error('[UploadManager] Chunk error:', err);
            this._cleanup(upload);
            upload.status = 'error';
            upload.error = err.message || 'Upload failed';
            this.emit('error', upload);
            this.saveToStorage();
        }
    },

    _startSpeedTracker(upload) {
        let lastLoadedForSpeed = 0;
        upload.speedInterval = setInterval(() => {
            if (upload.status !== 'uploading') {
                clearInterval(upload.speedInterval);
                return;
            }

            const now = Date.now();
            const bytesDiff = upload.loaded - lastLoadedForSpeed;
            lastLoadedForSpeed = upload.loaded;

            upload.speed = bytesDiff; // Bytes/sec (since interval is 1s)
            if (upload.speed > upload.peakSpeed) upload.peakSpeed = upload.speed;

            const totalTime = (now - upload.startTime) / 1000;
            upload.avgSpeed = totalTime > 0 ? upload.loaded / totalTime : 0;

            const remaining = upload.total - upload.loaded;
            upload.eta = upload.avgSpeed > 0 ? remaining / upload.avgSpeed : null;

            upload.speedHistory.push({ time: now, speed: upload.speed });
            if (upload.speedHistory.length > 60) upload.speedHistory.shift();

            this.emit('progress', upload);
        }, 1000);
    },

    _cleanup(upload) {
        if (upload.speedInterval) clearInterval(upload.speedInterval);
    },

    _finishUpload(upload, result) {
        this._cleanup(upload);
        upload.status = 'completed';
        upload.progress = 100;
        upload.result = result;

        console.log(`[UploadManager] Upload completed: ${upload.id}`);
        this.emit('complete', upload);

        // Add to episode sources
        this._addToEpisodeSources(upload, result.url);
        this.saveToStorage();
    },

    async _addToEpisodeSources(upload, videoUrl) {
        try {
            const series = State.data.series.find(s => s.id == upload.metadata.seriesId);
            if (!series) return;

            let episode = null;

            // Check seasons
            if (series.seasons && Array.isArray(series.seasons)) {
                for (let season of series.seasons) {
                    if (season.episodes && Array.isArray(season.episodes)) {
                        episode = season.episodes.find(ep => ep.number == upload.metadata.episodeNumber);
                        if (episode) break;
                    }
                }
            }

            // Check flat episodes
            if (!episode && series.episodes && Array.isArray(series.episodes)) {
                episode = series.episodes.find(ep => ep.number == upload.metadata.episodeNumber);
            }

            if (!episode) return;

            if (!episode.sources) episode.sources = [];

            // Check for duplicates
            const isDuplicate = episode.sources.some(s =>
                (s.url === videoUrl) || (s.src === videoUrl)
            );

            if (!isDuplicate) {
                episode.sources.push({
                    name: 'DRB',
                    url: videoUrl,
                    label: 'DRB',
                    src: videoUrl,
                    type: 'video/mp4',
                    quality: '1080p'
                });

                await db.updateSeries(upload.metadata.seriesId, series);
                console.log('[UploadManager] Source added to episode');
            }
        } catch (error) {
            console.error('[UploadManager] Failed to add source:', error);
        }
    },

    pauseUpload(uploadId) {
        const upload = this.uploads.get(uploadId);
        if (upload && upload.xhr && upload.status === 'uploading') {
            upload.xhr.abort();
            upload.status = 'paused';
            this.emit('paused', upload);
            this.saveToStorage();
        }
    },

    resumeUpload(uploadId) {
        const upload = this.uploads.get(uploadId);
        if (upload && upload.status === 'paused') {
            // Note: Simple resume (restart upload)
            // For chunked resume, need backend support
            upload.status = 'uploading';
            upload.loaded = 0;
            upload.progress = 0;
            this._performUpload(upload);
            this.emit('resumed', upload);
        }
    },

    cancelUpload(uploadId) {
        const upload = this.uploads.get(uploadId);
        if (upload) {
            if (upload.xhr) {
                upload.xhr.abort();
            }
            this.uploads.delete(uploadId);
            this.emit('cancelled', upload);
            this.saveToStorage();
        }
    },

    getUpload(uploadId) {
        return this.uploads.get(uploadId);
    },

    getAllUploads() {
        return Array.from(this.uploads.values());
    },

    getActiveUploads() {
        return this.getAllUploads().filter(u =>
            u.status === 'uploading' || u.status === 'paused'
        );
    },

    // Event system
    on(event, callback) {
        if (!this.listeners[event]) {
            this.listeners[event] = [];
        }
        this.listeners[event].push(callback);
    },

    off(event, callback) {
        if (this.listeners[event]) {
            this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
        }
    },

    emit(event, data) {
        if (this.listeners[event]) {
            this.listeners[event].forEach(callback => callback(data));
        }
    },

    // Persistence
    saveToStorage() {
        try {
            const data = Array.from(this.uploads.values()).map(u => ({
                id: u.id,
                metadata: u.metadata,
                status: u.status,
                progress: u.progress,
                error: u.error,
                startTime: u.startTime
            }));
            localStorage.setItem('uploadManager_uploads', JSON.stringify(data));
        } catch (e) {
            console.error('[UploadManager] Failed to save to storage:', e);
        }
    },

    loadFromStorage() {
        try {
            const data = localStorage.getItem('uploadManager_uploads');
            if (data) {
                const uploads = JSON.parse(data);
                // Only load failed/paused uploads for manual retry
                uploads.forEach(u => {
                    if (u.status === 'error' || u.status === 'paused') {
                        // Don't auto-resume, just show in UI
                        console.log('[UploadManager] Found interrupted upload:', u.id);
                    }
                });
            }
        } catch (e) {
            console.error('[UploadManager] Failed to load from storage:', e);
        }
    },

    cleanupOldUploads() {
        const now = Date.now();
        const oneHour = 3600000;

        for (const [id, upload] of this.uploads.entries()) {
            if (upload.status === 'completed' && (now - upload.startTime) > oneHour) {
                this.uploads.delete(id);
            }
        }
        this.saveToStorage();
    },

    // Utility functions
    formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    },

    formatSpeed(bytesPerSecond) {
        return this.formatBytes(bytesPerSecond) + '/s';
    },

    formatTime(seconds) {
        if (!seconds || seconds === Infinity) return '--:--';
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = Math.floor(seconds % 60);

        if (h > 0) {
            return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
        }
        return `${m}:${s.toString().padStart(2, '0')}`;
    }
    };
}

// Initialize on load
if (typeof State !== 'undefined') {
    UploadManager.init();
}
