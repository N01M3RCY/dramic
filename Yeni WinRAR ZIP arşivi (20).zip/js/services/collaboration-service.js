// ============================================
// COLLABORATION SERVICE
// Real-time collaborative editing for Video Studio
// ============================================

if (typeof CollaborationService === 'undefined') {
    window.CollaborationService = {
    sessionId: null,
    userId: null,
    seriesId: null,
    episodeNumber: null,
    isActive: false,
    pollInterval: null,
    lastSync: Date.now(),
    localState: null,
    activeUsers: new Map(),
    listeners: {},

    init() {
        console.log('🤝 CollaborationService initialized');
    },

    // Join a collaborative session
    async joinSession(seriesId, episodeNumber) {
        this.seriesId = seriesId;
        this.episodeNumber = episodeNumber;
        this.userId = State.currentUser?.id || 'guest-' + Date.now();
        this.sessionId = `session-${seriesId}-${episodeNumber}`;

        console.log('[Collab] Joining session:', this.sessionId);

        try {
            // Register session on backend
            const response = await fetch('api/db.php?action=join-studio-session', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    sessionId: this.sessionId,
                    userId: this.userId,
                    username: State.currentUser?.username || 'Guest',
                    seriesId: seriesId,
                    episodeNumber: episodeNumber
                })
            });

            const result = await response.json();

            if (result.success) {
                this.isActive = true;
                this.startPolling();
                this.emit('joined', result.session);
                console.log('[Collab] Session joined successfully');
            } else {
                console.error('[Collab] Failed to join session:', result.message);
            }
        } catch (error) {
            console.error('[Collab] Join session error:', error);
        }
    },

    // Leave session
    async leaveSession() {
        if (!this.isActive) return;

        console.log('[Collab] Leaving session:', this.sessionId);

        this.stopPolling();
        this.isActive = false;

        try {
            await fetch('api/db.php?action=leave-studio-session', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    sessionId: this.sessionId,
                    userId: this.userId
                })
            });
        } catch (error) {
            console.error('[Collab] Leave session error:', error);
        }

        this.emit('left');
    },

    // Start polling for updates
    startPolling() {
        if (this.pollInterval) return;

        // Poll every 2 seconds
        this.pollInterval = setInterval(() => {
            this.syncSession();
        }, 2000);

        console.log('[Collab] Polling started (2s interval)');
    },

    stopPolling() {
        if (this.pollInterval) {
            clearInterval(this.pollInterval);
            this.pollInterval = null;
            console.log('[Collab] Polling stopped');
        }
    },

    // Sync session state
    async syncSession() {
        if (!this.isActive) return;

        try {
            const response = await fetch('api/db.php?action=sync-studio-session', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    sessionId: this.sessionId,
                    userId: this.userId,
                    state: JSON.stringify(this.localState || {})
                })
            });

            const result = await response.json();

            if (result.success) {
                // Update active users
                this.updateActiveUsers(result.users);

                // Merge remote changes
                if (result.states) {
                    this.mergeRemoteStates(result.states);
                }

                this.lastSync = Date.now();
            }
        } catch (error) {
            console.error('[Collab] Sync error:', error);
        }
    },

    // Update local state (called by Video Studio)
    updateState(state) {
        this.localState = {
            ...state,
            timestamp: Date.now(),
            userId: this.userId
        };
    },

    // Update active users list
    updateActiveUsers(users) {
        const previousUsers = new Map(this.activeUsers);
        this.activeUsers.clear();

        users.forEach(user => {
            this.activeUsers.set(user.userId, user);

            // Emit 'user-joined' if new user
            if (!previousUsers.has(user.userId) && user.userId !== this.userId) {
                this.emit('user-joined', user);
            }
        });

        // Check for users who left
        previousUsers.forEach((user, userId) => {
            if (!this.activeUsers.has(userId) && userId !== this.userId) {
                this.emit('user-left', user);
            }
        });

        this.emit('users-updated', Array.from(this.activeUsers.values()));
    },

    // Merge remote states with conflict resolution
    mergeRemoteStates(states) {
        states.forEach(remoteState => {
            if (remoteState.userId === this.userId) return; // Skip own state

            // Check for conflicts
            if (this.localState && this.hasConflict(remoteState)) {
                this.resolveConflict(remoteState);
            } else {
                // No conflict, apply remote changes
                this.emit('remote-state-change', remoteState);
            }
        });
    },

    // Conflict detection
    hasConflict(remoteState) {
        if (!this.localState) return false;

        // Check if both users modified the same timeline clip
        if (remoteState.selectedClipId && this.localState.selectedClipId) {
            return remoteState.selectedClipId === this.localState.selectedClipId;
        }

        // Check if timeline clips overlap
        if (remoteState.timelineClips && this.localState.timelineClips) {
            return this.checkTimelineOverlap(remoteState.timelineClips, this.localState.timelineClips);
        }

        return false;
    },

    // Check if timeline clips overlap
    checkTimelineOverlap(remoteClips, localClips) {
        for (const remoteClip of remoteClips) {
            for (const localClip of localClips) {
                if (remoteClip.id === localClip.id) {
                    // Same clip, check if positions differ
                    if (remoteClip.startTime !== localClip.startTime ||
                        remoteClip.endTime !== localClip.endTime) {
                        return true;
                    }
                }
            }
        }
        return false;
    },

    // Conflict resolution strategies
    resolveConflict(remoteState) {
        console.warn('[Collab] Conflict detected with user:', remoteState.userId);

        // Strategy 1: Last-write-wins (based on timestamp)
        if (remoteState.timestamp > this.localState.timestamp) {
            console.log('[Collab] Applying remote changes (newer)');
            this.emit('conflict-resolved', {
                strategy: 'last-write-wins',
                winner: 'remote',
                remoteState: remoteState
            });
            this.emit('remote-state-change', remoteState);
        } else {
            console.log('[Collab] Keeping local changes (newer)');
            this.emit('conflict-resolved', {
                strategy: 'last-write-wins',
                winner: 'local',
                localState: this.localState
            });
        }

        // Show notification to user
        Toast.warning(`⚠️ Değişiklik çakışması tespit edildi. ${remoteState.timestamp > this.localState.timestamp ? 'Uzak' : 'Yerel'} değişiklikler uygulandı.`);
    },

    // Lock mechanism for timeline clips
    requestLock(clipId) {
        return fetch('api/db.php?action=request-clip-lock', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                sessionId: this.sessionId,
                userId: this.userId,
                clipId: clipId
            })
        })
            .then(r => r.json())
            .then(result => {
                if (result.success) {
                    this.emit('lock-acquired', { clipId, userId: this.userId });
                    return true;
                } else {
                    this.emit('lock-denied', { clipId, lockedBy: result.lockedBy });
                    Toast.warning(`🔒 Bu klip ${result.lockedBy} tarafından düzenleniyor`);
                    return false;
                }
            });
    },

    releaseLock(clipId) {
        return fetch('api/db.php?action=release-clip-lock', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                sessionId: this.sessionId,
                userId: this.userId,
                clipId: clipId
            })
        })
            .then(r => r.json())
            .then(result => {
                if (result.success) {
                    this.emit('lock-released', { clipId });
                }
            });
    },

    // Get active users (excluding self)
    getOtherUsers() {
        return Array.from(this.activeUsers.values())
            .filter(user => user.userId !== this.userId);
    },

    // Event system
    on(event, callback) {
        if (!this.listeners[event]) {
            this.listeners[event] = [];
        }
        this.listeners[event].push(callback);
    },

    off(event, callback) {
        if (this.listeners[event]) {
            this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
        }
    },

    emit(event, data) {
        if (this.listeners[event]) {
            this.listeners[event].forEach(callback => callback(data));
        }
    },

    // Utility: Check if user has lock on item
    hasLock(itemId, userId) {
        // Simple lock mechanism: first to select gets lock
        // In real implementation, this would be managed by backend
        return true; // For now, allow all actions
    }
};
}

// Initialize on load
if (typeof State !== 'undefined') {
    CollaborationService.init();
}
