/**
 * Data Import Service
 * Import drama/actor data from external sources like MyDramaList and IMDB
 */
const DataImport = {

    /**
     * Import series/drama data from MyDramaList URL
     * @param {string} url - MyDramaList drama page URL
     * @returns {Object} - Parsed series data
     */
    async fromMDL(url) {
        if (!url || !url.includes('mydramalist.com')) {
            Toast.error('Geçerli bir MyDramaList URL\'si girin');
            return null;
        }

        Toast.info('MyDramaList\'den veri çekiliyor...');

        try {
            // Use CORS proxy for cross-origin requests
            const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
            const response = await fetch(proxyUrl);

            if (!response.ok) {
                throw new Error('Sayfa yüklenemedi');
            }

            const html = await response.text();
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');

            // Extract data from MDL page structure
            const data = {
                title: this.extractMDLText(doc, 'h1.film-title'),
                titleOriginal: this.extractMDLText(doc, '.film-title [lang]'),
                poster: this.extractMDLImage(doc, '.film-cover img'),
                description: this.extractMDLText(doc, '.show-synopsis'),
                rating: this.extractMDLText(doc, '.score'),
                year: this.extractMDLMeta(doc, 'Aired'),
                country: this.extractMDLMeta(doc, 'Country'),
                genres: this.extractMDLGenres(doc),
                cast: this.extractMDLCast(doc),
                episodes: this.extractMDLMeta(doc, 'Episodes'),
                network: this.extractMDLMeta(doc, 'Network'),
                status: null,
                source: 'mydramalist',
                sourceUrl: url
            };

            // Determine status
            const airedText = this.extractMDLMeta(doc, 'Aired');
            if (airedText && airedText.includes('-')) {
                data.status = 'completed';
            } else {
                data.status = 'ongoing';
            }

            console.log('📥 MDL Import Result:', data);
            Toast.success('Veri başarıyla çekildi!');
            return data;

        } catch (error) {
            console.error('MDL Import Error:', error);
            Toast.error('MyDramaList verisi çekilemedi: ' + error.message);
            return null;
        }
    },

    /**
     * Import actor data from IMDB URL
     * @param {string} url - IMDB person page URL
     * @returns {Object} - Parsed actor data
     */
    async fromIMDB(url) {
        if (!url || !url.includes('imdb.com')) {
            Toast.error('Geçerli bir IMDB URL\'si girin');
            return null;
        }

        Toast.info('IMDB\'den veri çekiliyor...');

        try {
            const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
            const response = await fetch(proxyUrl);

            if (!response.ok) {
                throw new Error('Sayfa yüklenemedi');
            }

            const html = await response.text();
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');

            // Extract actor data from IMDB
            const data = {
                name: this.extractIMDBText(doc, '[data-testid="hero__pageTitle"]') ||
                    this.extractIMDBText(doc, 'h1.header span'),
                image: this.extractIMDBImage(doc, '[data-testid="hero-image-container"] img') ||
                    this.extractIMDBImage(doc, '#name-poster'),
                bio: this.extractIMDBText(doc, '[data-testid="bio-content"]') ||
                    this.extractIMDBText(doc, '.inline'),
                birthDate: this.extractIMDBMeta(doc, 'Born'),
                birthPlace: this.extractIMDBMeta(doc, 'Born'),
                height: this.extractIMDBMeta(doc, 'Height'),
                knownFor: this.extractIMDBKnownFor(doc),
                source: 'imdb',
                sourceUrl: url
            };

            console.log('📥 IMDB Import Result:', data);
            Toast.success('Oyuncu verisi başarıyla çekildi!');
            return data;

        } catch (error) {
            console.error('IMDB Import Error:', error);
            Toast.error('IMDB verisi çekilemedi: ' + error.message);
            return null;
        }
    },

    // --- Helper Functions ---

    extractMDLText(doc, selector) {
        const el = doc.querySelector(selector);
        return el ? el.textContent.trim() : '';
    },

    extractMDLImage(doc, selector) {
        const el = doc.querySelector(selector);
        return el ? (el.src || el.getAttribute('data-src') || el.getAttribute('data-original')) : '';
    },

    extractMDLMeta(doc, label) {
        const items = doc.querySelectorAll('.show-detailsxss li, .list-item');
        for (const item of items) {
            if (item.textContent.includes(label)) {
                const value = item.querySelector('a, span:last-child');
                return value ? value.textContent.trim() : item.textContent.replace(label + ':', '').trim();
            }
        }
        return '';
    },

    extractMDLGenres(doc) {
        const genres = [];
        const genreLinks = doc.querySelectorAll('.show-genres a');
        genreLinks.forEach(link => genres.push(link.textContent.trim()));
        return genres;
    },

    extractMDLCast(doc) {
        const cast = [];
        const castItems = doc.querySelectorAll('.cast .box');
        castItems.forEach(item => {
            const actor = item.querySelector('.text-primary a');
            const role = item.querySelector('.text-muted');
            const image = item.querySelector('img');
            if (actor) {
                cast.push({
                    actor: actor.textContent.trim(),
                    role: role ? role.textContent.trim() : '',
                    image: image ? (image.src || image.getAttribute('data-src')) : ''
                });
            }
        });
        return cast;
    },

    extractIMDBText(doc, selector) {
        const el = doc.querySelector(selector);
        return el ? el.textContent.trim() : '';
    },

    extractIMDBImage(doc, selector) {
        const el = doc.querySelector(selector);
        return el ? el.src : '';
    },

    extractIMDBMeta(doc, label) {
        const items = doc.querySelectorAll('[data-testid="title-details-section"] li, .ipc-metadata-list__item');
        for (const item of items) {
            if (item.textContent.includes(label)) {
                const value = item.querySelector('a, span:last-of-type');
                return value ? value.textContent.trim() : '';
            }
        }
        return '';
    },

    extractIMDBKnownFor(doc) {
        const items = [];
        const knownFor = doc.querySelectorAll('[data-testid="known-for-widget"] a');
        knownFor.forEach(item => {
            const title = item.textContent.trim();
            if (title) items.push(title);
        });
        return items;
    },

    /**
     * Show import modal UI
     * @param {string} type - 'series' or 'actor'
     */
    showImportModal(type = 'series') {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'data-import-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 500px;">
                <div class="modal-header">
                    <h2><i class="fa-solid fa-cloud-arrow-down"></i> Veri İçe Aktar</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #e2e8f0;">
                            ${type === 'actor' ? 'IMDB Oyuncu URL' : 'MyDramaList URL'}
                        </label>
                        <input type="url" id="import-url-input" 
                               placeholder="${type === 'actor' ? 'https://www.imdb.com/name/nm...' : 'https://mydramalist.com/...'}"
                               style="width: 100%; padding: 12px; background: rgba(0,0,0,0.3); border: 1px solid #333; border-radius: 8px; color: white; font-size: 1rem;">
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <button onclick="DataImport.executeImport('${type}')" class="btn btn-primary" style="flex: 1;">
                            <i class="fa-solid fa-download"></i> Verileri Çek
                        </button>
                        ${type === 'series' ? `
                            <button onclick="DataImport.showTMDBSearch()" class="btn" style="background: #0d253f; color: #01b4e4; font-weight: 700;">
                                <i class="fa-solid fa-search"></i> TMDB Ara
                            </button>` : ''}
                    </div>
                    
                    <div id="import-result" style="margin-top: 20px; display: none; background: rgba(0,0,0,0.2); padding: 15px; border-radius: 8px; max-height: 300px; overflow-y: auto;">
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async executeImport(type) {
        const url = document.getElementById('import-url-input').value.trim();
        if (!url) {
            Toast.warning('Lütfen bir URL girin');
            return;
        }

        let result;
        if (type === 'actor') {
            result = await this.fromIMDB(url);
        } else {
            result = await this.fromMDL(url);
        }

        if (result) {
            const resultDiv = document.getElementById('import-result');
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = `
                <h4 style="margin: 0 0 15px 0; color: #10b981;">
                    <i class="fa-solid fa-check-circle"></i> Veri Alındı
                </h4>
                <pre style="font-size: 0.8rem; color: #94a3b8; white-space: pre-wrap; word-break: break-word;">${JSON.stringify(result, null, 2)}</pre>
                <button onclick="DataImport.applyImportedData('${type}')" class="btn btn-success" style="width: 100%; margin-top: 15px;">
                    <i class="fa-solid fa-plus"></i> Verileri Uygula
                </button>
            `;
            // Store for later use
            this.lastImportResult = result;
        }
    },

    applyImportedData(type) {
        if (!this.lastImportResult) {
            Toast.error('Önce veri çekmelisiniz');
            return;
        }

        document.getElementById('data-import-modal').remove();

        if (type === 'actor') {
            // Open actor add modal with pre-filled data
            if (typeof AdminActors !== 'undefined' && AdminActors.showAddModal) {
                AdminActors.showAddModal(this.lastImportResult.name);
                // Pre-fill fields after modal opens
                setTimeout(() => {
                    const bioInput = document.getElementById('actor-bio');
                    const imageInput = document.getElementById('actor-image');
                    if (bioInput && this.lastImportResult.bio) bioInput.value = this.lastImportResult.bio;
                    if (imageInput && this.lastImportResult.image) imageInput.value = this.lastImportResult.image;
                }, 200);
            }
        } else {
            Toast.success('Dizi verisi panoya kopyalandı. Yeni dizi formunda kullanabilirsiniz.');
            navigator.clipboard.writeText(JSON.stringify(this.lastImportResult, null, 2));
        }
    },

    /**
     * TMDB Integration
     */
    showTMDBSearch() {
        const body = document.querySelector('#data-import-modal .modal-body');
        if (!body) return;

        body.innerHTML = `
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #e2e8f0;">TMDB Film/Dizi Ara</label>
                <div style="display: flex; gap: 10px;">
                    <input type="text" id="tmdb-search-input" placeholder="Dizi/Film adı veya ID..." 
                           style="flex: 1; padding: 12px; background: rgba(0,0,0,0.3); border: 1px solid #333; border-radius: 8px; color: white; font-size: 1rem;">
                    <button onclick="DataImport.searchTMDB()" class="btn btn-primary"><i class="fa-solid fa-search"></i></button>
                </div>
            </div>
            <div id="tmdb-results" style="max-height: 400px; overflow-y: auto; display: grid; gap: 10px;"></div>
            <button onclick="DataImport.showImportModal('series')" class="btn btn-link" style="width: 100%; margin-top: 20px;">← MDL Import'a Dön</button>
        `;
    },

    async searchTMDB() {
        const query = document.getElementById('tmdb-search-input').value.trim();
        if (!query) return;

        const resultsDiv = document.getElementById('tmdb-results');
        resultsDiv.innerHTML = '<div style="text-align:center; padding:20px; color:#94a3b8;"><i class="fa-solid fa-spinner fa-spin"></i> TMDB taranıyor...</div>';

        try {
            const response = await fetch(`api/index.php?action=tmdb-search&query=${encodeURIComponent(query)}`);
            const data = await response.json();

            if (data.success && data.results && data.results.results) {
                const results = data.results.results.filter(r => r.media_type !== 'person');
                if (results.length === 0) {
                    resultsDiv.innerHTML = '<div style="text-align:center; padding:20px; color:#ef4444;">Sonuç bulunamadı.</div>';
                    return;
                }

                resultsDiv.innerHTML = results.map(r => `
                    <div style="display:flex; gap:12px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.05); padding:10px; border-radius:12px; cursor:pointer;" onclick="DataImport.getTMBDDetails('${r.id}', '${r.media_type}')">
                        <img src="https://image.tmdb.org/t/p/w92${r.poster_path}" style="width:50px; height:75px; object-fit:cover; border-radius:6px; background:#222;" onerror="this.src='assets/logo.png'">
                        <div style="flex:1;">
                            <div style="font-weight:700; color:#fff;">${r.name || r.title}</div>
                            <div style="font-size:0.8rem; color:#94a3b8;">${(r.first_air_date || r.release_date || '').split('-')[0]} · ${r.media_type === 'tv' ? 'Dizi' : 'Film'}</div>
                            <div style="font-size:0.75rem; color:#64748b; margin-top:4px; display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical; overflow:hidden;">${r.overview || ''}</div>
                        </div>
                    </div>
                `).join('');
            } else {
                resultsDiv.innerHTML = `<div style="text-align:center; padding:20px; color:#ef4444;">Hata: ${data.message || 'API Hatası'}</div>`;
            }
        } catch (e) {
            resultsDiv.innerHTML = '<div style="text-align:center; padding:20px; color:#ef4444;">Bağlantı hatası oluştu.</div>';
        }
    },

    async getTMBDDetails(id, mediaType) {
        Toast.info('Detaylı veriler TMDB\'den çekiliyor...');
        try {
            const response = await fetch(`api/index.php?action=tmdb-search&type=get&id=${id}&media_type=${mediaType}`);
            const data = await response.json();

            if (data && data.id) {
                // Convert TMDB format to Dramicbox format
                const drama = {
                    title: data.name || data.title,
                    titleOriginal: data.original_name || data.original_title,
                    poster: `https://image.tmdb.org/t/p/original${data.poster_path}`,
                    backdrop: `https://image.tmdb.org/t/p/original${data.backdrop_path}`,
                    description: data.overview,
                    rating: data.vote_average,
                    year: (data.first_air_date || data.release_date || '').split('-')[0],
                    genres: (data.genres || []).map(g => g.name),
                    cast: (data.credits?.cast || []).slice(0, 10).map(c => ({
                        actor: c.name,
                        role: c.character,
                        image: c.profile_path ? `https://image.tmdb.org/t/p/w185${c.profile_path}` : ''
                    })),
                    tmdbId: data.id,
                    mediaType: mediaType,
                    status: data.status === 'Ended' || data.status === 'Released' ? 'completed' : 'ongoing',
                    episodes: data.number_of_episodes || 1,
                    network: (data.networks || [])[0]?.name || ''
                };

                this.lastImportResult = drama;
                
                // Show final result
                this.showImportResult('series');
            }
        } catch (e) {
            Toast.error('Veri çekilemedi: ' + e.message);
        }
    },

    showImportResult(type) {
        const body = document.querySelector('#data-import-modal .modal-body');
        if (!body) return;

        body.innerHTML = `
            <div id="import-result" style="background: rgba(0,0,0,0.2); padding: 15px; border-radius: 8px; max-height: 400px; overflow-y: auto;">
                <h4 style="margin: 0 0 15px 0; color: #10b981;">
                    <i class="fa-solid fa-check-circle"></i> TMDB Verisi Alındı
                </h4>
                <div style="display:flex; gap:15px; margin-bottom:15px;">
                    <img src="${this.lastImportResult.poster}" style="width:80px; height:120px; border-radius:8px; object-fit:cover;">
                    <div>
                        <div style="font-weight:700; color:#fff; font-size:1.1rem;">${this.lastImportResult.title}</div>
                        <div style="color:#94a3b8; font-size:0.9rem;">${this.lastImportResult.year} · ${this.lastImportResult.genres.join(', ')}</div>
                    </div>
                </div>
                <pre style="font-size: 0.75rem; color: #64748b; white-space: pre-wrap; word-break: break-word; background:rgba(0,0,0,0.3); padding:10px; border-radius:8px;">${JSON.stringify(this.lastImportResult, null, 2)}</pre>
                <div style="display:flex; gap:10px; margin-top:20px;">
                    <button onclick="DataImport.applyImportedData('${type}')" class="btn btn-success" style="flex:1;">
                        <i class="fa-solid fa-plus"></i> Verileri Uygula
                    </button>
                    <button onclick="DataImport.showTMDBSearch()" class="btn btn-outline">← Geri</button>
                </div>
            </div>
        `;
    }
};

window.DataImport = DataImport;
console.log('✅ DataImport Service Loaded');
