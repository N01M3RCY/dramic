/**
 * Dramicbox Advanced Live Service
 * Handles WebRTC P2P Signaling, Chat, and Economy
 */
if (!window.LiveService) {
    window.LiveService = {
        peerConnection: null,
        localStream: null,
        currentStreamId: null,
        chatInterval: null,
        streamInterval: null,

        config: {
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:stun1.l.google.com:19302' }
            ]
        },

        /**
         * BROADCASTER: Start a live stream
         */
        async startBroadcast(options = {}) {
            try {
                const { title, mode, existingStream } = options; // mode: 'screen' | 'camera' | 'manual'

                // BroadcasterStudio önizlemede zaten kaynak seçtiyse tekrar izin isteme
                if (existingStream) {
                    this.localStream = existingStream;
                } else if (mode === 'camera') {
                    this.localStream = await navigator.mediaDevices.getUserMedia({
                        video: true,
                        audio: true
                    });
                } else if (mode === 'screen') {
                    this.localStream = await navigator.mediaDevices.getDisplayMedia({
                        video: { cursor: "always" },
                        audio: true
                    });
                } else if (!this.localStream) {
                    return null;
                }

                // 1. Call Backend to start stream
                const res = await fetch('api/db.php?action=live-action&live_action=start-stream', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ title: title, config: { mode } })
                });
                const data = await res.json();
                
                if (!data.success) throw new Error(data.message);

                this.currentStreamId = data.stream.id;
                
                // 2. Start signaling & heartbeat loop
                this.startBroadcasterLoops();
                
                Toast.success('Canlı yayın başlatıldı!');
                return this.localStream;
            } catch (err) {
                console.error('Broadcast error:', err);
                Toast.error('Yayın başlatılamadı: ' + err.message);
                return null;
            }
        },

        startBroadcasterLoops() {
            // Heartbeat & Sync viewer count
            this.streamInterval = setInterval(async () => {
                if (!this.currentStreamId) return;
                await fetch('api/db.php?action=live-action&live_action=update-stream', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ streamId: this.currentStreamId, viewerCount: this.getViewerCount() })
                });
            }, 30000);

            // Chat listener
            this.startChatListener();
        },

        getViewerCount() {
            // Simple mock or track active WebRTC connections
            return 0; // In a real system, we'd count peer connections
        },

        /**
         * CHAT: Send message
         */
        async sendChat(streamId, message) {
            const res = await fetch('api/db.php?action=live-action&live_action=chat-send', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ streamId, message })
            });
            return await res.json();
        },

        /**
         * CHAT: Get messages (poll)
         */
        async getChat(streamId) {
            const res = await fetch(`api/db.php?action=live-action&live_action=chat-get&streamId=${streamId}`);
            return await res.json();
        },

        /**
         * ECONOMY: Send coins
         */
        async sendCoins(streamId, amount) {
            const res = await fetch('api/db.php?action=live-action&live_action=send-coin', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ streamId, amount })
            });
            return await res.json();
        },

        /**
         * BROADCASTER: Stop stream
         */
        async stopBroadcast() {
            if (this.localStream) {
                this.localStream.getTracks().forEach(track => track.stop());
            }
            if (this.streamInterval) clearInterval(this.streamInterval);
            if (this.chatInterval) clearInterval(this.chatInterval);
            
            if (this.currentStreamId) {
                await fetch('api/db.php?action=live-action&live_action=stop-stream', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ streamId: this.currentStreamId })
                });
            }
            
            this.currentStreamId = null;
            Toast.info('Yayın sonlandırıldı.');
        },

        async heartbeat() {
            if (!this.currentStreamId) return;
            return fetch('api/db.php?action=live-action&live_action=update-stream', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ streamId: this.currentStreamId })
            });
        }
    }
};
