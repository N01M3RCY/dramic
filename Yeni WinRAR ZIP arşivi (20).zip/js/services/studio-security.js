// ============================================
// STUDIO SECURITY SERVICE
// URL encryption and access control
// ============================================

const StudioSecurity = {
    secretKey: 'dramicbox-studio-2024-secure',

    // Encrypt studio access data
    encrypt(data) {
        const payload = {
            ...data,
            exp: Date.now() + (24 * 60 * 60 * 1000), // 24 hours
            uid: State.currentUser?.id || 'guest',
            timestamp: Date.now()
        };

        // Simple Base64 encoding (for production, use proper encryption)
        return btoa(JSON.stringify(payload));
    },

    // Decrypt and validate studio access
    decrypt(token) {
        try {
            const payload = JSON.parse(atob(token));

            // Check expiry
            if (payload.exp < Date.now()) {
                console.error('[Security] Token expired');
                return null;
            }

            // Check user (if logged in)
            if (State.currentUser && payload.uid !== State.currentUser.id) {
                console.error('[Security] Invalid user');
                return null;
            }

            return payload;
        } catch (e) {
            console.error('[Security] Decryption failed:', e);
            return null;
        }
    },

    // Generate secure studio URL
    generateStudioUrl(seriesId, episodeNumber, seriesTitle) {
        const token = this.encrypt({
            seriesId,
            episodeNumber,
            seriesTitle
        });

        return `#/studio/${token}`;
    },

    // Check if user has access to series
    hasAccess(seriesId) {
        const user = State.currentUser;
        if (!user) return false;

        // Admin has access to everything
        if (user.role === 'admin') return true;

        // Check assignments for translators
        if (user.role === 'translator') {
            // TODO: Check assignments
            return user.assignedSeries?.includes(seriesId) || false;
        }

        return false;
    }
};
