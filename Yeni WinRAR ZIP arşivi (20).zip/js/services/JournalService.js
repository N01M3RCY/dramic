/**
 * DRAMICBOX - JOURNAL SERVICE (E-Dergi)
 * Handles magazine issues, drafts, and administrative curation
 */
const JournalService = {
    issues: [],

    init() {
        if (!State.data.journals) {
            State.data.journals = {
                activeIssue: null,
                allIssues: [],
                draft: this.getInitialDraft()
            };
        }
        this.issues = State.data.journals.allIssues || [];
    },

    getInitialDraft() {
        return {
            title: 'Yeni Sayı',
            coverImage: '',
            month: new Date().toLocaleString('tr-TR', { month: 'long' }),
            year: new Date().getFullYear(),
            sections: {
                editorNote: 'Bu ay neler oldu?',
                fanArts: [],       // Array of social post IDs
                topReviews: [],    // Array of social post IDs
                bestTranslators: [], // Array of user IDs
                featuredSeries: []  // Array of series IDs
            }
        };
    },

    // ==================== ADMIN ACTIONS ====================
    
    addToDraft(type, id) {
        if (!State.data.journals.draft) State.data.journals.draft = this.getInitialDraft();
        const draft = State.data.journals.draft;

        if (type === 'fanArt') {
            if (!draft.sections.fanArts.includes(id)) {
                draft.sections.fanArts.push(id);
                Toast.success('Dergide Fan-Art bölümüne eklendi! 🎨');
            }
        } else if (type === 'review') {
            if (!draft.sections.topReviews.includes(id)) {
                draft.sections.topReviews.push(id);
                Toast.success('Dergide İncelemeler bölümüne eklendi! ✍️');
            }
        }
        db.save();
    },

    updateDraft(data) {
        State.data.journals.draft = { ...State.data.journals.draft, ...data };
        db.save();
    },

    publishIssue() {
        const draft = State.data.journals.draft;
        if (!draft.coverImage) return Toast.error('Dergi kapak resmi olmadan yayınlanamaz!');

        const newIssue = {
            ...draft,
            id: 'journal_' + Date.now(),
            publishedAt: new Date().toISOString()
        };

        State.data.journals.allIssues.unshift(newIssue);
        State.data.journals.activeIssue = newIssue.id;
        
        // Reset Draft
        State.data.journals.draft = this.getInitialDraft();
        
        db.save();
        Toast.success('E-Dergi Yayında! Tüm kullanıcılara duyuruldu. 📖✨');
        
        // Send Notification to all
        State.data.users.forEach(u => {
            SocialFeed.sendSocialNotification(u.id, '📖 Yeni Dergi Yayında!', `${newIssue.month} ${newIssue.year} sayısı çıktı. Hemen oku!`, 'journal');
        });
    },

    // ==================== UI RENDERING ====================

    renderJournalPage() {
        const activeId = State.data.journals.activeIssue;
        const issue = State.data.journals.allIssues.find(i => i.id === activeId) || State.data.journals.allIssues[0];

        if (!issue) {
            return `
                <div style="height:80vh; display:flex; flex-direction:column; align-items:center; justify-content:center; color:#64748b;">
                    <i class="fa-solid fa-book-open" style="font-size:4rem; margin-bottom:20px; opacity:0.2;"></i>
                    <h2>Henüz bir sayı yayınlanmadı.</h2>
                    <p>Çok yakında ilk sayımızla buradayız!</p>
                </div>
            `;
        }

        return `
            <div class="journal-container" style="max-width:1200px; margin:0 auto; padding:40px 20px;">
                <!-- Header / Cover Section -->
                <div class="journal-header" style="position:relative; height:500px; border-radius:30px; overflow:hidden; margin-bottom:50px; box-shadow:0 20px 50px rgba(0,0,0,0.5);">
                    <img src="${issue.coverImage}" style="width:100%; height:100%; object-fit:cover;">
                    <div style="position:absolute; inset:0; background:linear-gradient(to top, rgba(15,15,19,0.95), transparent);"></div>
                    <div style="position:absolute; bottom:40px; left:40px;">
                        <span style="background:var(--premium-violet); color:white; padding:5px 15px; border-radius:20px; font-weight:800; font-size:0.8rem; text-transform:uppercase; letter-spacing:1px;">Dramicbox Journal</span>
                        <h1 style="font-size:4rem; color:white; font-weight:900; margin-top:10px;">${issue.title}</h1>
                        <p style="color:#94a3b8; font-size:1.2rem;">${issue.month} ${issue.year} Sayısı</p>
                    </div>
                </div>

                <!-- Content Grid -->
                <div style="display:grid; grid-template-columns: 2fr 1fr; gap:40px;">
                    
                    <!-- Main Content -->
                    <div>
                        <!-- Editor's Note -->
                        <div class="glass-card" style="padding:40px; border-radius:24px; margin-bottom:40px;">
                            <h2 style="color:gold; margin-bottom:20px; font-size:1.8rem; font-weight:900;">🖋️ Editörün Notu</h2>
                            <div style="color:#e2e8f0; line-height:1.8; font-size:1.1rem; font-style:italic;">
                                "${issue.sections.editorNote}"
                            </div>
                        </div>

                        <!-- Top Reviews -->
                        <h2 style="color:#fff; margin-bottom:30px; font-weight:900; display:flex; align-items:center; gap:15px;">
                            <i class="fa-solid fa-feather-pointed" style="color:var(--premium-violet);"></i> Ayın İncelemeleri
                        </h2>
                        <div style="display:grid; gap:20px; margin-bottom:50px;">
                            ${this.renderJournalReviews(issue.sections.topReviews)}
                        </div>

                        <!-- Fan Arts -->
                        <h2 style="color:#fff; margin-bottom:30px; font-weight:900; display:flex; align-items:center; gap:15px;">
                            <i class="fa-solid fa-palette" style="color:#10b981;"></i> Topluluk Sanatı (Fan-Art)
                        </h2>
                        <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:20px;">
                            ${this.renderJournalFanArts(issue.sections.fanArts)}
                        </div>
                    </div>

                    <!-- Sidebar -->
                    <div>
                        <div class="glass-card" style="padding:30px; border-radius:24px; position:sticky; top:100px;">
                            <h3 style="color:#fff; margin-bottom:20px; font-weight:800;">🏆 Ayın Çevirmenleri</h3>
                            <div style="display:grid; gap:15px;">
                                ${this.renderJournalTranslators(issue.sections.bestTranslators)}
                            </div>

                            <hr style="border:none; border-top:1px solid rgba(255,255,255,0.05); margin:30px 0;">
                            
                            <h3 style="color:#fff; margin-bottom:20px; font-weight:800;">🔍 Öne Çıkan Diziler</h3>
                            <div style="display:grid; gap:15px;">
                                ${this.renderJournalSeries(issue.sections.featuredSeries)}
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        `;
    },

    renderJournalReviews(ids) {
        return ids.map(id => {
            const post = State.data.socialPosts?.find(p => p.id === id);
            if (!post) return '';
            const user = State.data.users?.find(u => u.id === post.userId);
            return `
                <div class="glass-card" style="padding:25px; border-radius:18px; border-left:4px solid var(--premium-violet);">
                    <div style="display:flex; align-items:center; gap:12px; margin-bottom:15px;">
                        <img src="${user?.avatar || 'assets/logo.png'}" style="width:32px; height:32px; border-radius:50%;">
                        <span style="color:#fff; font-weight:700;">${user?.username}</span>
                    </div>
                    <div style="color:#94a3b8; font-size:0.95rem; display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden;">
                        ${post.text || post.content || ''}
                    </div>
                    <button onclick="App.navigate('social/post/${post.id}')" style="margin-top:15px; background:none; border:none; color:var(--premium-violet); cursor:pointer; font-weight:700; font-size:0.85rem;">Devamını Oku →</button>
                </div>
            `;
        }).join('') || '<p style="color:#64748b;">Bu ay inceleme seçilmedi.</p>';
    },

    renderJournalFanArts(ids) {
        return ids.map(id => {
            const post = State.data.socialPosts?.find(p => p.id === id);
            if (!post || (!post.mediaUrl && !post.media)) return '';
            return `
                <div class="journal-fanart-card" style="border-radius:15px; overflow:hidden; position:relative; aspect-ratio:1/1;">
                    <img src="${post.mediaUrl || post.media}" style="width:100%; height:100%; object-fit:cover;">
                    <div style="position:absolute; inset:0; background:rgba(0,0,0,0.4); opacity:0; transition:0.3s; display:flex; align-items:center; justify-content:center;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0">
                         <button onclick="App.navigate('social/post/${post.id}')" class="btn-sm btn-primary">Görüntüle</button>
                    </div>
                </div>
            `;
        }).join('') || '<p style="color:#64748b;">Henüz sanat eseri eklenmedi.</p>';
    },

    renderJournalTranslators(ids) {
        return ids.map(id => {
            const user = State.data.users?.find(u => u.id === id);
            if (!user) return '';
            return `
                <div style="display:flex; align-items:center; gap:12px; padding:10px; background:rgba(255,255,255,0.03); border-radius:12px;">
                    <img src="${user.avatar || 'assets/logo.png'}" style="width:36px; height:36px; border-radius:50%; border:2px solid gold;">
                    <div>
                        <div style="color:#fff; font-weight:700; font-size:0.9rem;">${user.username}</div>
                        <div style="color:gold; font-size:0.7rem; font-weight:800;">BÖLÜM CANAVARI ⚡</div>
                    </div>
                </div>
            `;
        }).join('') || '<p style="color:#64748b;">Seçim yapılmadı.</p>';
    },

    renderJournalSeries(ids) {
        return ids.map(id => {
            const series = State.data.series?.find(s => s.id === id);
            if (!series) return '';
            return `
                <div onclick="App.navigate('detail', '${series.id}')" style="cursor:pointer; display:flex; gap:10px; align-items:center;">
                    <img src="${series.poster}" style="width:50px; height:70px; border-radius:8px; object-fit:cover;">
                    <div>
                        <div style="color:#fff; font-weight:700; font-size:0.85rem;">${series.title}</div>
                        <div style="color:#64748b; font-size:0.7rem;">${series.genres?.join(', ')}</div>
                    </div>
                </div>
            `;
        }).join('') || '<p style="color:#64748b;">Öne çıkan dizi yok.</p>';
    }
};

window.JournalService = JournalService;
