/**
 * DRAMICBOX - LEADERBOARD PAGE (Popup Modal Version)
 * Modern leaderboard with close button, ESC support, and guide section.
 */
const LeaderboardPage = {
    activeFilter: 'all',

    init() {
        this.open();
    },

    open() {
        // Remove existing modal if any
        const existing = document.getElementById('leaderboard-page-modal');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.id = 'leaderboard-page-modal';
        overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:10000;background:rgba(0,0,0,0.85);backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:center;animation:lbFadeIn 0.3s ease;';

        overlay.innerHTML = `
            <style>
                @keyframes lbFadeIn { from { opacity: 0; } to { opacity: 1; } }
                @keyframes lbSlideUp { from { transform: translateY(40px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
                
                .lb-page-container { 
                    width: 95%; max-width: 900px; max-height: 90vh; overflow-y: auto; 
                    background: rgba(15, 16, 25, 0.7); 
                    backdrop-filter: blur(25px) saturate(180%);
                    -webkit-backdrop-filter: blur(25px) saturate(180%);
                    border-radius: 32px; border: 1px solid rgba(251,191,36,0.2); 
                    padding: 40px 30px; position: relative; animation: lbSlideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
                    box-shadow: 0 40px 100px rgba(0,0,0,0.8), 0 0 40px rgba(251,191,36,0.05);
                }
                .lb-page-container::-webkit-scrollbar { width: 6px; }
                .lb-page-container::-webkit-scrollbar-track { background: transparent; }
                .lb-page-container::-webkit-scrollbar-thumb { background: rgba(251,191,36,0.2); border-radius: 10px; }
                
                .lb-close-btn { 
                    position: absolute; top: 20px; right: 20px; width: 40px; height: 40px; 
                    border-radius: 50%; border: 1px solid rgba(255,255,255,0.1); 
                    background: rgba(255,255,255,0.05); color: #fff; font-size: 1.1rem; 
                    cursor: pointer; display: flex; align-items: center; justify-content: center; 
                    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); z-index: 100;
                }
                .lb-close-btn:hover { transform: rotate(90deg); background: #ef4444; border-color: #ef4444; color: #fff; }
                
                .lb-filter-pill { 
                    padding: 10px 24px; border-radius: 16px; cursor: pointer; 
                    border: 1px solid rgba(255,255,255,0.05); background: rgba(255,255,255,0.03); 
                    color: #94a3b8; font-weight: 700; font-size: 0.85rem; transition: all 0.3s; 
                }
                .lb-filter-pill.active { 
                    background: linear-gradient(135deg, #fbbf24, #d97706); color: #000; 
                    border-color: transparent; box-shadow: 0 8px 24px rgba(251,191,36,0.4); 
                }
                .lb-filter-pill:hover:not(.active) { background: rgba(255,255,255,0.1); color: #fff; }
                
                .lb-guide-card {
                    background: linear-gradient(135deg, rgba(251,191,36,0.08), rgba(217,119,6,0.15));
                    border: 1px solid rgba(251,191,36,0.2); border-radius: 24px; padding: 24px;
                    display: flex; gap: 20px; align-items: center; margin-bottom: 35px;
                    position: relative; overflow: hidden;
                }
                .lb-guide-card::before {
                    content: ''; position: absolute; top: -50%; left: -50%; width: 200%; height: 200%;
                    background: radial-gradient(circle, rgba(251,191,36,0.05) 0%, transparent 70%);
                    pointer-events: none;
                }
                .lb-guide-icon {
                    width: 54px; height: 54px; flex-shrink: 0; background: linear-gradient(135deg, #fbbf24, #d97706); 
                    border-radius: 14px; display: flex; align-items: center; justify-content: center; 
                    font-size: 1.4rem; color: #000; box-shadow: 0 10px 25px rgba(251,191,36,0.3);
                }
                .lb-podium-item { 
                    display: flex; flex-direction: column; align-items: center; cursor: pointer; 
                    transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1); 
                }
                .lb-podium-item:hover { transform: translateY(-12px); }
                .lb-list-row {
                    display: flex; align-items: center; padding: 16px 24px; 
                    border-bottom: 1px solid rgba(255,255,255,0.03); cursor: pointer; transition: all 0.2s;
                }
                .lb-list-row:hover { background: rgba(251,191,36,0.06); transform: scale(1.01); }
                .lb-list-row:last-child { border-bottom: none; }
                @media (max-width: 600px) {
                    .lb-page-container { padding: 30px 15px; border-radius: 24px; width: 98%; }
                    .lb-guide-card { flex-direction: column; text-align: center; gap: 12px; }
                    .lb-podium-container { gap: 10px !important; }
                }
            </style>
            <div class="lb-page-container">
                <button class="lb-close-btn" onclick="LeaderboardPage.close()" title="Kapat">
                    <i class="fa-solid fa-xmark"></i>
                </button>
                
                <!-- Title -->
                <div style="text-align: center; margin-bottom: 30px;">
                    <h1 style="font-size: 2.8rem; font-weight: 900; background: linear-gradient(to right, #fbbf24, #f59e0b, #d97706); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin: 0 0 8px 0; letter-spacing: -2px;">
                        <i class="fa-solid fa-trophy" style="color: #fbbf24; -webkit-text-fill-color: #fbbf24; margin-right: 10px;"></i>
                        Liderlik Tablosu
                    </h1>
                    <p style="color: #64748b; font-size: 0.9rem; margin: 0;">En yüksek XP'ye sahip kullanıcılar burada!</p>
                </div>

                <!-- Filters -->
                <div style="display: flex; justify-content: center; gap: 12px; margin-bottom: 30px;">
                    <div class="lb-filter-pill ${this.activeFilter === 'weekly' ? 'active' : ''}" onclick="LeaderboardPage.setFilter('weekly')">
                        <i class="fa-solid fa-calendar-week" style="margin-right: 6px;"></i> Haftalık
                    </div>
                    <div class="lb-filter-pill ${this.activeFilter === 'all' ? 'active' : ''}" onclick="LeaderboardPage.setFilter('all')">
                        <i class="fa-solid fa-infinity" style="margin-right: 6px;"></i> Tüm Zamanlar
                    </div>
                </div>

                <!-- Guide / Event Card -->
                <div class="lb-guide-card">
                    <div class="lb-guide-icon"><i class="fa-solid fa-bolt"></i></div>
                    <div style="flex: 1;">
                        <h3 style="color: #fff; font-size: 1.15rem; margin: 0 0 5px 0; font-weight: 800;">Kılavuz: XP Nasıl Kazanılır?</h3>
                        <p style="color: #94a3b8; font-size: 0.88rem; margin: 0; line-height: 1.5;">
                            Dizi izleyerek, yorum yaparak, arkadaş ekleyerek ve günlük görevleri tamamlayarak XP kazanabilirsiniz.
                            Haftalık sıralamada ilk 3'e girenlere <strong style="color: #fbbf24;">500 DramiCoin</strong> hediye!
                        </p>
                    </div>
                </div>

                <!-- Podium -->
                <div class="lb-podium-container" style="display: flex; justify-content: center; align-items: flex-end; gap: 40px; margin-bottom: 50px; padding-top: 20px;">
                    ${this.renderPodium()}
                </div>

                <!-- List -->
                <div style="background: rgba(15,15,20,0.6); border-radius: 24px; border: 1px solid rgba(255,255,255,0.05); overflow: hidden; backdrop-filter: blur(20px);">
                    ${this.renderList()}
                </div>

                <!-- Hall of Fame -->
                <div style="margin-top: 40px;">
                    <h2 style="font-size: 1.4rem; color: #fff; margin-bottom: 20px; display: flex; align-items: center; gap: 12px; font-weight: 800;">
                        <i class="fa-solid fa-medal" style="color: #fbbf24;"></i> Hall of Fame
                    </h2>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 15px;">
                        ${this.renderHallOfFame()}
                    </div>
                </div>
            </div>
        `;

        // Close on backdrop click
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) LeaderboardPage.close();
        });

        document.body.appendChild(overlay);

        // ESC key to close
        this._escHandler = (e) => { if (e.key === 'Escape') LeaderboardPage.close(); };
        document.addEventListener('keydown', this._escHandler);
    },

    close() {
        const modal = document.getElementById('leaderboard-page-modal');
        if (modal) {
            modal.style.animation = 'lbFadeIn 0.2s ease reverse';
            setTimeout(() => {
                modal.remove();
                // Navigate back to social hub when exiting leaderboard
                if (typeof App !== 'undefined') App.navigate('social');
            }, 200);
        }
        if (this._escHandler) {
            document.removeEventListener('keydown', this._escHandler);
            this._escHandler = null;
        }
    },

    render() {
        // Re-open with updated content
        this.close();
        setTimeout(() => this.open(), 50);
    },

    setFilter(filter) {
        this.activeFilter = filter;
        this.render();
    },

    getTopUsers() {
        if (!State.data.users) return [];
        let users = [...State.data.users];

        if (this.activeFilter === 'weekly') {
            users.forEach(u => u._tempWeeklyXp = u.stats?.xp ? Math.floor(u.stats.xp * 0.15 + (Math.random() * 50)) : 0);
            return users.sort((a, b) => b._tempWeeklyXp - a._tempWeeklyXp).slice(0, 50);
        }
        return users.sort((a, b) => (b.stats?.xp || 0) - (a.stats?.xp || 0)).slice(0, 50);
    },

    renderPodium() {
        const top3 = this.getTopUsers().slice(0, 3);
        if (top3.length < 3) return '<p style="color:#64748b; text-align: center;">Yeterli veri yok...</p>';

        const [first, second, third] = [top3[0], top3[1], top3[2]];
        return `
            ${this.renderPodiumItem(second, 2, '#94a3b8', '120px')}
            ${this.renderPodiumItem(first, 1, '#fbbf24', '160px')}
            ${this.renderPodiumItem(third, 3, '#cd7f32', '100px')}
        `;
    },

    renderPodiumItem(user, rank, color, height) {
        const xp = this.activeFilter === 'weekly' ? user._tempWeeklyXp : (user.stats?.xp || 0);
        const avatarSize = rank === 1 ? '90px' : '75px';
        return `
            <div class="lb-podium-item" onclick="LeaderboardPage.close(); App.router('profile', '${user.id}')">
                <div style="position: relative; margin-bottom: 15px;">
                    <div style="position: absolute; top: -14px; left: 50%; transform: translateX(-50%); font-size: ${rank === 1 ? '1.5rem' : '1.1rem'}; color: ${color}; filter: drop-shadow(0 0 5px ${color});">
                        <i class="fa-solid fa-crown"></i>
                    </div>
                    <img src="${user.avatar || 'assets/logo.png'}" style="width: ${avatarSize}; height: ${avatarSize}; border-radius: 50%; object-fit: cover; border: 3px solid ${color}; box-shadow: 0 8px 25px ${color}30;">
                    <div style="position: absolute; bottom: -8px; left: 50%; transform: translateX(-50%); background: ${color}; color: black; font-weight: 900; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid #0f1019; font-size: 0.85rem;">${rank}</div>
                </div>
                <div style="font-weight: 800; color: white; font-size: 1rem;">${user.username}</div>
                <div style="color: ${color}; font-size: 0.85rem; font-weight: 700;">${xp} XP</div>
                <div style="width: 80px; height: ${height}; background: linear-gradient(to top, ${color}20, transparent); margin-top: 12px; border-radius: 16px 16px 0 0; border: 1px solid ${color}30; border-bottom: none;"></div>
            </div>
        `;
    },

    renderList() {
        const others = this.getTopUsers().slice(3);
        if (others.length === 0) return '<div style="padding: 30px; text-align: center; color: #64748b;">Listelenecek kullanıcı yok.</div>';

        return others.map((user, index) => {
            const xp = this.activeFilter === 'weekly' ? user._tempWeeklyXp : (user.stats?.xp || 0);
            return `
                <div class="lb-list-row" onclick="LeaderboardPage.close(); App.router('profile', '${user.id}')">
                    <div style="width: 45px; font-weight: 900; color: #475569; font-size: 1.1rem;">#${index + 4}</div>
                    <img src="${user.avatar || 'assets/logo.png'}" style="width: 48px; height: 48px; border-radius: 50%; object-fit: cover; margin-right: 18px; border: 2px solid rgba(255,255,255,0.08);">
                    <div style="flex: 1;">
                        <div style="font-weight: 700; color: white; font-size: 1.05rem;">${user.username}</div>
                        <div style="font-size: 0.8rem; color: #64748b;">Seviye ${user.stats?.level || 1} • ${user.role === 'admin' ? 'Moderatör' : 'Üye'}</div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight: 800; color: #fbbf24; font-size: 1.1rem;">${xp}</div>
                        <div style="font-size: 0.65rem; color: #475569; text-transform: uppercase; font-weight: 800;">Toplam XP</div>
                    </div>
                </div>
            `;
        }).join('');
    },

    renderHallOfFame() {
        const pastWinners = [
            { name: 'KralVezir', date: 'Şubat 2026', badge: 'Haftanın Kralı' },
            { name: 'ShadowMan', date: 'Ocak 2026', badge: 'Efsane İzleyici' },
            { name: 'DramiLover', date: 'Aralık 2025', badge: 'Koleksiyoncu' }
        ];

        return pastWinners.map(winner => `
            <div style="background: rgba(251,191,36,0.05); border: 1px solid rgba(251,191,36,0.1); border-radius: 16px; padding: 16px; display: flex; align-items: center; gap: 14px;">
                <div style="width: 44px; height: 44px; flex-shrink: 0; background: rgba(251,191,36,0.1); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: #fbbf24; font-size: 1.3rem;">
                    <i class="fa-solid fa-trophy"></i>
                </div>
                <div>
                    <div style="font-weight: 800; color: #fff; font-size: 0.95rem;">${winner.name}</div>
                    <div style="font-size: 0.75rem; color: #94a3b8;">${winner.date} • ${winner.badge}</div>
                </div>
            </div>
        `).join('');
    }
};

window.LeaderboardPage = LeaderboardPage;
