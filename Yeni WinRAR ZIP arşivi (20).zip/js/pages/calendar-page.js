/**
 * DRAMICBOX - ADVANCED CALENDAR SYSTEM
 * Redesigned for Premium Experience
 */

const CalendarPage = {
    selectedDay: null,
    currentFilter: 'all',

    init(filter = 'all') {
        this.currentFilter = filter;
        const daysTR = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];
        const todayIdx = new Date().getDay();
        const todayTRIdx = todayIdx === 0 ? 6 : todayIdx - 1;
        
        if (!this.selectedDay) this.selectedDay = daysTR[todayTRIdx];

        this.render();
    },

    render() {
        const view = document.getElementById('calendar-view');
        if (!view) return;

        // Ensure proper section display
        document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
        view.style.display = 'block';

        const daysTR = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];
        const today = new Date();
        const todayIdx = today.getDay();
        const todayTRIdx = todayIdx === 0 ? 6 : todayIdx - 1;

        view.innerHTML = `
            <div class="calendar-premium-container">
                <header class="calendar-header-v2">
                    <div class="calendar-title-wrap">
                        <div class="calendar-icon-glow"><i class="fa-solid fa-calendar-days"></i></div>
                        <div>
                            <h1>Yayın Takvimi</h1>
                            <p>DramicBox'ın en güncel yayın akışını takip edin.</p>
                        </div>
                    </div>
                    
                    <div class="calendar-nav-v2">
                        <div class="nav-filters-v2">
                            <button class="nav-btn-v2 ${this.currentFilter === 'all' ? 'active' : ''}" onclick="CalendarPage.switchFilter('all')">Tümü</button>
                            <button class="nav-btn-v2 ${this.currentFilter === 'drama' ? 'active' : ''}" onclick="CalendarPage.switchFilter('drama')">Diziler</button>
                            <button class="nav-btn-v2 ${this.currentFilter === 'webtoon' ? 'active' : ''}" onclick="CalendarPage.switchFilter('webtoon')">Webtoonlar</button>
                        </div>
                    </div>
                </header>

                <div class="calendar-week-tabs">
                    ${daysTR.map((day, idx) => `
                        <div class="week-tab ${this.selectedDay === day ? 'active' : ''} ${idx === todayTRIdx ? 'is-today' : ''}" 
                             onclick="CalendarPage.switchDay('${day}')">
                            <span class="day-label">${day.substring(0, 3)}</span>
                            <span class="day-name">${day}</span>
                            ${idx === todayTRIdx ? '<span class="today-indicator">BUGÜN</span>' : ''}
                        </div>
                    `).join('')}
                </div>

                <div class="calendar-content-list" id="calendar-list-v2">
                    ${this.renderDayContent(this.selectedDay)}
                </div>
                
                ${this.renderUpcomingSection()}
            </div>
        `;

        this.injectCSS();
    },

    switchDay(day) {
        this.selectedDay = day;
        this.render();
    },

    switchFilter(filter) {
        this.currentFilter = filter;
        this.render();
    },

    renderDayContent(day) {
        let items = (State.data.calendar || []).filter(c => c.day === day);

        if (this.currentFilter !== 'all') {
            items = items.filter(i => {
                const s = (State.data.series || []).find(series => String(series.id) === String(i.seriesId)) ||
                          (State.data.webtoons || []).find(webtoon => String(webtoon.id) === String(i.seriesId));
                return s && (s.type === this.currentFilter || (this.currentFilter === 'drama' && s.type === 'dizi') || (this.currentFilter === 'webtoon' && s.type === 'webtoon'));
            });
        }

        items.sort((a, b) => (a.time || '').localeCompare(b.time || ''));

        if (items.length === 0) {
            return `
                <div class="calendar-empty-state">
                    <div class="empty-icon-pulse"><i class="fa-solid fa-mug-hot"></i></div>
                    <h3>Bu gün için planlanmış bir yayın bulunmuyor.</h3>
                    <p>Farklı bir güne göz atmaya ne dersiniz?</p>
                </div>
            `;
        }

        return `
            <div class="calendar-grid-v2">
                ${items.map(i => {
                    const s = (State.data.series || []).find(series => String(series.id) === String(i.seriesId)) ||
                              (State.data.webtoons || []).find(webtoon => String(webtoon.id) === String(i.seriesId));
                    if (!s) return '';
                    const isReminded = State.currentUser?.calendarReminders?.includes(s.id);
                    return `
                        <div class="cal-item-v2" onclick="App.router('detail', '${s.id}')">
                            <div class="cal-item-img-wrap">
                                <img src="${s.poster || s.coverImage || 'assets/logo.png'}" alt="${s.title}">
                                <div class="cal-item-time">${i.time || '20:00'}</div>
                            </div>
                            <div class="cal-item-body">
                                <div class="cal-item-meta">
                                    <span class="meta-tag type-${s.type || 'drama'}">${s.type === 'webtoon' ? 'Webtoon' : 'Dizi'}</span>
                                    ${s.isVip ? '<span class="meta-tag vip"><i class="fa-solid fa-crown"></i> VIP</span>' : ''}
                                </div>
                                <h3 class="cal-item-title">${s.title}</h3>
                                <p class="cal-item-ep">${i.episodeNumber ? i.episodeNumber + '. Bölüm' : 'Yeni Bölüm'}</p>
                                
                                <div class="cal-item-actions">
                                    <button class="reminder-btn-v2 ${isReminded ? 'active' : ''}" onclick="event.stopPropagation(); CalendarPage.toggleReminder('${s.id}')">
                                        <i class="fa-${isReminded ? 'solid' : 'regular'} fa-bell"></i>
                                        ${isReminded ? 'Hatırlatılıyor' : 'Hatırlatıcı Kur'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    },

    renderUpcomingSection() {
        const upcoming = [...(State.data.series || []), ...(State.data.webtoons || [])].filter(s => s.status === 'Yakında').slice(0, 6);
        if (upcoming.length === 0) return '';

        return `
            <div class="upcoming-section-v2">
                <div class="section-title-v2">
                    <i class="fa-solid fa-fire-flame-curved"></i>
                    <h2>Yakında Başlayacaklar</h2>
                </div>
                <div class="upcoming-grid-v2">
                    ${upcoming.map(s => `
                        <div class="upcoming-card-v2" onclick="App.router('detail', '${s.id}')">
                            <div class="upcoming-img-v2">
                                <img src="${s.poster || s.coverImage || 'assets/logo.png'}" alt="${s.title}">
                                <div class="upcoming-badge">BEKLENİYOR</div>
                            </div>
                            <div class="upcoming-info-v2">
                                <h4>${s.title}</h4>
                                <span>${s.releaseDate || 'Tarih Belirsiz'}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    },

    toggleReminder(seriesId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Hatırlatıcı eklemek için giriş yapmalısınız!');
            return;
        }

        if (!State.currentUser.calendarReminders) State.currentUser.calendarReminders = [];
        const reminders = State.currentUser.calendarReminders;
        const index = reminders.indexOf(seriesId);

        if (index === -1) {
            reminders.push(seriesId);
            Toast.success('Hatırlatıcı eklendi!');
        } else {
            reminders.splice(index, 1);
            Toast.info('Hatırlatıcı kaldırıldı.');
        }

        if (window.db && db.save) db.save();
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        this.render();
    },

    injectCSS() {
        if (document.getElementById('calendar-v2-styles')) return;
        const css = `
            .calendar-premium-container { max-width: 1400px; margin: 0 auto; padding: 40px 20px; animation: fadeIn 0.6s ease-out; }
            .calendar-header-v2 { display: flex; justify-content: space-between; align-items: center; margin-bottom: 50px; flex-wrap: wrap; gap: 30px; }
            .calendar-title-wrap { display: flex; align-items: center; gap: 20px; }
            .calendar-icon-glow { width: 60px; height: 60px; background: rgba(124, 58, 237, 0.1); border-radius: 18px; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; color: #7c3aed; box-shadow: 0 0 20px rgba(124,58,237,0.2); }
            .calendar-title-wrap h1 { font-size: 2.5rem; font-weight: 900; color: #fff; margin: 0; letter-spacing: -1px; }
            .calendar-title-wrap p { color: #94a3b8; margin: 5px 0 0; font-size: 1.1rem; }
            
            .nav-filters-v2 { display: flex; background: rgba(255,255,255,0.03); padding: 5px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05); }
            .nav-btn-v2 { padding: 10px 25px; border: none; background: transparent; color: #94a3b8; font-weight: 700; cursor: pointer; border-radius: 10px; transition: 0.3s; }
            .nav-btn-v2.active { background: #7c3aed; color: #fff; box-shadow: 0 5px 15px rgba(124,58,237,0.3); }

            .calendar-week-tabs { display: flex; gap: 12px; margin-bottom: 40px; }
            .week-tab { flex: 1; display: flex; flex-direction: column; align-items: center; padding: 20px 10px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius: 20px; cursor: pointer; transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); position: relative; }
            .week-tab:hover { background: rgba(255,255,255,0.05); transform: translateY(-5px); border-color: rgba(124,58,237,0.3); }
            .week-tab.active { background: linear-gradient(135deg, #7c3aed, #4c1d95); border-color: transparent; scale: 1.05; z-index: 2; box-shadow: 0 15px 30px rgba(0,0,0,0.4); }
            .day-label { font-size: 0.8rem; font-weight: 800; color: rgba(255,255,255,0.4); text-transform: uppercase; margin-bottom: 5px; }
            .week-tab.active .day-label { color: rgba(255,255,255,0.7); }
            .day-name { font-size: 1.1rem; font-weight: 900; color: #fff; }
            .today-indicator { position: absolute; bottom: -10px; background: #10b981; color: #000; font-size: 0.6rem; font-weight: 900; padding: 2px 8px; border-radius: 10px; }

            .calendar-grid-v2 { display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 25px; }
            .cal-item-v2 { background: rgba(255,255,255,0.025); border: 1px solid rgba(255,255,255,0.05); border-radius: 24px; display: flex; gap: 20px; padding: 15px; transition: all 0.4s; cursor: pointer; }
            .cal-item-v2:hover { background: rgba(255,255,255,0.05); border-color: #7c3aed; transform: translateY(-5px); }
            .cal-item-img-wrap { min-width: 120px; width: 120px; height: 170px; position: relative; border-radius: 18px; overflow: hidden; }
            .cal-item-img-wrap img { width: 100%; height: 100%; object-fit: cover; }
            .cal-item-time { position: absolute; top: 10px; left: 10px; background: rgba(0,0,0,0.6); backdrop-filter: blur(10px); color: #7c3aed; font-weight: 800; font-size: 0.75rem; padding: 4px 10px; border-radius: 10px; border: 1px solid rgba(124,58,237,0.3); }
            .cal-item-body { flex: 1; display: flex; flex-direction: column; justify-content: center; }
            .cal-item-meta { display: flex; gap: 8px; margin-bottom: 10px; }
            .meta-tag { font-size: 0.65rem; font-weight: 800; text-transform: uppercase; padding: 2px 8px; border-radius: 6px; }
            .meta-tag.type-drama { background: rgba(59, 130, 246, 0.1); color: #3b82f6; }
            .meta-tag.type-webtoon { background: rgba(16, 185, 129, 0.1); color: #10b981; }
            .meta-tag.vip { background: #f59e0b; color: #000; }
            .cal-item-title { font-size: 1.3rem; font-weight: 800; color: #fff; margin: 0 0 5px; line-height: 1.2; }
            .cal-item-ep { color: #94a3b8; font-size: 0.9rem; font-weight: 600; margin-bottom: 15px; }
            .reminder-btn-v2 { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 10px 15px; border-radius: 12px; font-weight: 700; font-size: 0.8rem; cursor: pointer; transition: 0.3s; display: flex; align-items: center; gap: 8px; }
            .reminder-btn-v2:hover { background: rgba(124, 58, 237, 0.1); border-color: #7c3aed; color: #7c3aed; }
            .reminder-btn-v2.active { background: #f59e0b; color: #000; border-color: transparent; }

            .upcoming-section-v2 { margin-top: 80px; padding-top: 50px; border-top: 1px solid rgba(255,255,255,0.05); }
            .section-title-v2 { display: flex; align-items: center; gap: 15px; margin-bottom: 30px; }
            .section-title-v2 i { color: #f59e0b; font-size: 1.5rem; }
            .section-title-v2 h2 { font-size: 1.8rem; font-weight: 800; color: #fff; margin: 0; }
            .upcoming-grid-v2 { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px; }
            .upcoming-card-v2 { background: rgba(255,255,255,0.02); border-radius: 20px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05); transition: 0.3s; cursor: pointer; }
            .upcoming-card-v2:hover { transform: translateY(-8px); border-color: #f59e0b; }
            .upcoming-img-v2 { height: 280px; position: relative; }
            .upcoming-img-v2 img { width: 100%; height: 100%; object-fit: cover; }
            .upcoming-badge { position: absolute; top: 12px; right: 12px; background: #f59e0b; color: #000; font-size: 0.6rem; font-weight: 900; padding: 3px 8px; border-radius: 6px; }
            .upcoming-info-v2 { padding: 15px; }
            .upcoming-info-v2 h4 { margin: 0 0 5px; color: #fff; font-weight: 700; }
            .upcoming-info-v2 span { color: #f59e0b; font-size: 0.75rem; font-weight: 700; }

            .calendar-empty-state { text-align: center; padding: 100px 20px; background: rgba(255,255,255,0.015); border-radius: 40px; border: 2px dashed rgba(255,255,255,0.05); }
            .empty-icon-pulse { font-size: 4rem; color: rgba(148, 163, 184, 0.3); margin-bottom: 25px; animation: pulse 2s infinite; }

            @media (max-width: 768px) {
                .calendar-week-tabs { overflow-x: auto; padding-bottom: 15px; scrollbar-width: none; }
                .week-tab { min-width: 100px; }
                .calendar-grid-v2 { grid-template-columns: 1fr; }
                .calendar-header-v2 { flex-direction: column; align-items: flex-start; }
            }
        `;
        const style = document.createElement('style');
        style.id = 'calendar-v2-styles';
        style.textContent = css;
        document.head.appendChild(style);
    }
};

window.CalendarPage = CalendarPage;
