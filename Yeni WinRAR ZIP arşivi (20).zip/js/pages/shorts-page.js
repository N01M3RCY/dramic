/**
 * Shorts Drama Page
 * Kısa drama videoları için sayfa yönetimi
 */

// Using window assignment to avoid duplicate declaration if script loaded twice
window.ShortsPage = window.ShortsPage || {
    shorts: [],
    currentShort: null,
    selectedRange: null,

    async init() {
        await this.loadShorts();
    },

    async loadShorts() {
        // Use local db if available (Unified Database System)
        if (typeof State !== 'undefined' && State.data && State.data.shorts) {
            this.shorts = State.data.shorts;
            return;
        }

        // Fallback or empty
        this.shorts = [];
    },

    render() {
        // Mobile Check - If on mobile, use the vertical TikTok-style feed
        if (window.innerWidth <= 768 && typeof DramaShorts !== 'undefined' && DramaShorts.isEnabled) {
            DramaShorts.load();
            return;
        }

        let container = document.getElementById('shorts-view');
        if (!container) {
            console.error('Shorts view container not found!');
            return;
        }

        container.innerHTML = `
            <div class="shorts-page">
                <!-- Hero Section -->
                <div class="shorts-hero">
                    <div class="shorts-hero-content">
                        <h1><i class="fa-solid fa-play-circle"></i> Kısa Dramalar</h1>
                        <p>Her bölümü birkaç dakika süren kısa drama serilerini keşfedin</p>
                    </div>
                </div>

                <!-- Shorts Grid -->
                <div class="shorts-container">
                    <div class="shorts-grid" id="shorts-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px; padding: 20px;">
                        ${this.shorts.length > 0 ?
                this.shorts.map(short => this.renderShortCard(short)).join('') :
                '<div class="empty-state"><i class="fa-solid fa-film"></i><p>Henüz kısa drama eklenmemiş</p></div>'
            }
                    </div>
                </div>
            </div>

            <!-- Short Detail Modal -->
            <div class="short-modal" id="short-modal" style="display: none;">
                <div class="short-modal-content" id="short-modal-content"></div>
            </div>

            <!-- Video Player Modal -->
            <div class="video-player-modal" id="video-player-modal" style="display: none;">
                <div class="video-player-container" id="video-player-container"></div>
            </div>

            <!-- Coin Unlock Modal -->
            <div class="coin-unlock-modal" id="coin-unlock-modal" style="display: none;">
                <div class="coin-unlock-content" id="coin-unlock-content"></div>
            </div>
        `;

        // Initial load
        if (this.shorts.length === 0) {
            this.loadShorts().then(() => {
                const grid = document.getElementById('shorts-grid');
                if (grid && this.shorts.length > 0) {
                    grid.innerHTML = this.shorts.map(short => this.renderShortCard(short)).join('');
                }
            });
        }
    },

    renderShortCard(short) {
        const poster = short.poster || 'assets/poster-placeholder.jpg';
        const rating = short.rating || '8.5';
        const logo = short.logo || 'assets/logo.png';

        return `
            <div class="standard-media-card" onclick="ShortsPage.openShortDetail('${short.id}')">
                <div class="std-card-poster-wrapper">
                    <div class="std-card-badge-top-left">
                         <span class="std-badge rating"><i class="fa-solid fa-star"></i> ${rating}</span>
                    </div>
                    <div class="std-card-badge-top-right">
                        <span class="std-badge hd">${short.totalEpisodes} Bölüm</span>
                    </div>
                    
                    <img src="${poster}" alt="${short.title}" class="std-card-poster" loading="lazy" onerror="this.src='assets/poster-placeholder.jpg'">
                    
                    <!-- Logo Overlay Effect -->
                    <img src="${logo}" class="std-card-logo-overlay" alt="Logo">
                </div>
                
                <div class="std-card-info">
                     <div class="std-card-meta">
                        <span class="std-card-type">Kısa Drama</span>
                    </div>
                    <h3 class="std-card-title">${short.title}</h3>
                </div>
            </div>
        `;
    },

    async openShortDetail(shortId) {
        try {
            const response = await fetch(`/api/shorts.php?id=${shortId}`);
            const result = await response.json();

            if (result.success) {
                this.currentShort = result.data;
                this.selectedRange = this.currentShort.episodeRanges?.[0] || null;
                this.showDetailModal();
            }
        } catch (error) {
            console.error('Short detayı yüklenemedi:', error);
            Toast?.error?.('Detay yüklenemedi');
        }
    },

    showDetailModal() {
        const short = this.currentShort;
        const modal = document.getElementById('short-modal');
        const content = document.getElementById('short-modal-content');

        // Get user's unlocked episodes
        const userUnlocked = State?.currentUser?.unlockedShortEpisodes || [];

        content.innerHTML = `
            <div class="short-detail-premium">
                <button class="close-modal-premium" onclick="ShortsPage.closeDetailModal()">
                    <i class="fa-solid fa-xmark"></i>
                </button>
                
                <div class="short-detail-container">
                    <!-- Left Section: Poster & Backdrop -->
                    <div class="short-detail-visual">
                        <img src="${short.poster || '/assets/placeholder.jpg'}" alt="${short.title}" class="detail-poster">
                        <div class="detail-backdrop" style="background-image: url('${short.poster || '/assets/placeholder.jpg'}')"></div>
                        <div class="visual-overlay"></div>
                    </div>

                    <!-- Right Section: Info & Episodes -->
                    <div class="short-detail-content">
                        <div class="short-breadcrumb-modern">
                            <span onclick="App.router('home'); ShortsPage.closeDetailModal();">Anasayfa</span>
                            <i class="fa-solid fa-chevron-right"></i>
                            <span onclick="App.router('shorts'); ShortsPage.closeDetailModal();">Diziler</span>
                            <i class="fa-solid fa-chevron-right"></i>
                            <span class="active">${short.title}</span>
                        </div>

                        <div class="info-header-premium">
                            <h1 class="short-title-alt">${short.title}</h1>
                            <div class="meta-row">
                                <span class="rating-badge"><i class="fa-solid fa-star"></i> ${short.rating || '8.5'}</span>
                                <span class="episode-total">${short.totalEpisodes} Bölüm</span>
                                <span class="translator-tag"><i class="fa-solid fa-user-pen"></i> ${short.translator || 'Bilinmiyor'}</span>
                                <button class="btn-coffee-shorts" onclick="DonationSystem.openModal('admin', '${short.translator || 'DramicBox'}')">
                                    <i class="fa-solid fa-mug-hot"></i> Kahve Ismarla
                                </button>
                            </div>
                            <style>
                                .btn-coffee-shorts {
                                    background: rgba(255, 215, 0, 0.1);
                                    border: 1px solid rgba(255, 215, 0, 0.3);
                                    color: #ffd700;
                                    padding: 4px 10px;
                                    border-radius: 6px;
                                    font-size: 12px;
                                    cursor: pointer;
                                    display: flex;
                                    align-items: center;
                                    gap: 5px;
                                    transition: 0.2s;
                                }
                                .btn-coffee-shorts:hover {
                                    background: rgba(255, 215, 0, 0.2);
                                    transform: translateY(-2px);
                                }
                            </style>
                            
                            <div class="genre-list">
                                ${(short.genres || []).map(g => `<span class="genre-pill">${g}</span>`).join('')}
                            </div>
                        </div>

                        <div class="description-box">
                            <p>${short.description || 'Bu kısa drama hakkında henüz açıklama eklenmemiş.'}</p>
                        </div>

                        ${State?.currentUser ? `
                            <div class="user-status-bar glass-panel">
                                <div class="user-info-brief">
                                    <img src="${State.currentUser.avatar || '/assets/default-avatar.png'}" class="user-avatar-small">
                                    <span>${State.currentUser.username}</span>
                                </div>
                                <div class="coin-balance-display">
                                    <i class="fa-solid fa-coins"></i> 
                                    <span>${State.currentUser.stats?.coins || 0}</span>
                                </div>
                            </div>
                        ` : `
                            <div class="login-prompt-bar glass-panel" onclick="App.router('login'); ShortsPage.closeDetailModal();">
                                <i class="fa-solid fa-lock"></i>
                                <span>Bölümleri açmak için giriş yapın</span>
                            </div>
                        `}

                        <div class="episode-section-modern">
                            <div class="section-header-compact">
                                <h3>Bölümler</h3>
                                <div class="range-tabs-modern">
                                    ${(short.episodeRanges || ['1-' + short.totalEpisodes]).map((range, i) => `
                                        <button class="range-pill ${i === 0 ? 'active' : ''}" 
                                                onclick="ShortsPage.selectRange('${range}', this)">
                                            ${range}
                                        </button>
                                    `).join('')}
                                </div>
                            </div>

                            <div class="episode-grid-premium" id="episode-grid">
                                ${this.renderEpisodeGrid(short, userUnlocked)}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    },

    renderEpisodeGrid(short, userUnlocked = []) {
        const freeCount = short.freeEpisodes || 0;
        const range = this.selectedRange;
        let episodes = short.episodes || [];

        // Filter by range if provided
        if (range) {
            const [start, end] = range.split('-').map(Number);
            episodes = episodes.filter(ep => ep.number >= start && ep.number <= end);
        }

        return episodes.map(ep => {
            const isFree = ep.isFree || ep.number <= freeCount;
            const unlockKey = `${short.id}_ep_${ep.number}`;
            const isUnlocked = userUnlocked.includes(unlockKey);
            const price = ep.coinPrice || short.defaultCoinPrice || 10;

            let badgeHtml = '';
            let cardClass = 'episode-card';

            if (isFree) {
                cardClass += ' free';
            } else if (isUnlocked) {
                cardClass += ' unlocked';
            } else {
                cardClass += ' locked';
                badgeHtml = `<span class="coin-badge"><i class="fa-solid fa-coins"></i> ${price}</span>`;
            }

            return `
                <div class="${cardClass}" onclick="ShortsPage.playEpisode(${ep.number})">
                    <span class="episode-number">${ep.number}</span>
                    ${badgeHtml}
                </div>
            `;
        }).join('');
    },

    selectRange(range, btn) {
        this.selectedRange = range;

        // Update active tab
        document.querySelectorAll('.range-tab').forEach(t => t.classList.remove('active'));
        btn.classList.add('active');

        // Re-render episode grid
        const grid = document.getElementById('episode-grid');
        const userUnlocked = State?.currentUser?.unlockedShortEpisodes || [];
        grid.innerHTML = this.renderEpisodeGrid(this.currentShort, userUnlocked);
    },

    async playEpisode(episodeNum) {
        const short = this.currentShort;
        const freeCount = short.freeEpisodes || 0;
        const episode = short.episodes.find(ep => ep.number === episodeNum);

        if (!episode) {
            Toast?.error?.('Bölüm bulunamadı');
            return;
        }

        const isFree = episode.isFree || episodeNum <= freeCount;

        // Check if user is logged in for paid content
        if (!isFree && !State?.currentUser) {
            Toast?.warning?.('Bu bölümü izlemek için giriş yapmalısınız');
            App?.router?.('login');
            return;
        }

        // Check access
        if (!isFree) {
            const unlockKey = `${short.id}_ep_${episodeNum}`;
            const isUnlocked = (State.currentUser.unlockedShortEpisodes || []).includes(unlockKey);

            if (!isUnlocked) {
                this.showUnlockModal(episode);
                return;
            }
        }

        // Play the video
        this.openVideoPlayer(episode);
    },

    showUnlockModal(episode) {
        const short = this.currentShort;
        const price = episode.coinPrice || short.defaultCoinPrice || 10;
        const userCoins = State?.currentUser?.stats?.coins || 0;
        const canUnlock = userCoins >= price;

        const modal = document.getElementById('coin-unlock-modal');
        const content = document.getElementById('coin-unlock-content');

        content.innerHTML = `
            <div class="unlock-dialog">
                <button class="close-unlock" onclick="ShortsPage.closeUnlockModal()">
                    <i class="fa-solid fa-xmark"></i>
                </button>
                
                <div class="unlock-icon">
                    <i class="fa-solid fa-lock"></i>
                </div>
                
                <h2>Bölümü Aç</h2>
                <p><strong>${short.title}</strong> - Bölüm ${episode.number}</p>
                
                <div class="unlock-price">
                    <i class="fa-solid fa-coins"></i>
                    <span>${price} Coin</span>
                </div>
                
                <div class="user-balance ${canUnlock ? 'sufficient' : 'insufficient'}">
                    <span>Bakiyeniz:</span>
                    <span><i class="fa-solid fa-coins"></i> ${userCoins}</span>
                </div>
                
                ${canUnlock ? `
                    <button class="btn-unlock" onclick="ShortsPage.confirmUnlock(${episode.number})">
                        <i class="fa-solid fa-unlock"></i> Bölümü Aç (${price} Coin)
                    </button>
                ` : `
                    <div class="insufficient-msg">
                        <p>Yeterli coininiz yok!</p>
                        <button class="btn-buy-coins" onclick="ShortsPage.closeUnlockModal(); ShopSystem?.show?.();">
                            <i class="fa-solid fa-cart-shopping"></i> Coin Satın Al
                        </button>
                    </div>
                `}
            </div>
        `;

        modal.style.display = 'flex';
    },

    async confirmUnlock(episodeNum) {
        const short = this.currentShort;

        try {
            const response = await fetch('/api/shorts.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'unlock',
                    shortId: short.id,
                    episodeNum: episodeNum,
                    userId: State.currentUser.id
                })
            });

            const result = await response.json();

            if (result.success) {
                // Update local state
                if (!State.currentUser.unlockedShortEpisodes) {
                    State.currentUser.unlockedShortEpisodes = [];
                }
                State.currentUser.unlockedShortEpisodes.push(`${short.id}_ep_${episodeNum}`);
                State.currentUser.stats.coins = result.remainingCoins;

                Toast?.success?.(`Bölüm açıldı! ${result.coinsSpent} coin harcandı`);

                this.closeUnlockModal();

                // Refresh episode grid
                const grid = document.getElementById('episode-grid');
                grid.innerHTML = this.renderEpisodeGrid(short, State.currentUser.unlockedShortEpisodes);

                // Update coin display
                const coinDisplay = document.querySelector('.coin-balance');
                if (coinDisplay) {
                    coinDisplay.innerHTML = `<i class="fa-solid fa-coins"></i> ${result.remainingCoins}`;
                }

                // Play the episode
                const episode = short.episodes.find(ep => ep.number === episodeNum);
                if (episode) {
                    this.openVideoPlayer(episode);
                }
            } else {
                Toast?.error?.(result.error || 'Bölüm açılamadı');
            }
        } catch (error) {
            console.error('Unlock error:', error);
            Toast?.error?.('Bir hata oluştu');
        }
    },

    openVideoPlayer(episode) {
        const short = this.currentShort;
        const modal = document.getElementById('video-player-modal');
        const container = document.getElementById('video-player-container');

        // Clean up previous instances
        container.innerHTML = '';

        // Get sources - logic to prioritize MP4/HLS
        let sources = episode.sources || [];
        if (sources.length === 0 && episode.videoUrl) {
            sources.push({ type: 'mp4', url: episode.videoUrl, quality: '720p', name: 'Standart' });
        }

        const currentSource = sources[0] || null;

        if (!currentSource) {
            Toast.error('Video kaynağı bulunamadı!');
            return;
        }

        container.innerHTML = `
            <div class="video-player full-screen-player">
                <style>
                    .full-screen-player {
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100vw;
                        height: 100vh;
                        background: black;
                        z-index: 3001; /* Above modal */
                        display: flex;
                        flex-direction: column;
                    }
                    .player-header {
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        background: linear-gradient(to bottom, rgba(0,0,0,0.8), transparent);
                        padding: 20px;
                        z-index: 10;
                        display: flex;
                        align-items: center;
                        gap: 20px;
                    }
                    .player-footer {
                        position: absolute;
                        bottom: 0;
                        left: 0;
                        width: 100%;
                        background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
                        padding: 20px;
                        z-index: 10;
                    }
                </style>
                
                <div class="player-header">
                    <button class="back-btn" onclick="ShortsPage.closeVideoPlayer()">
                        <i class="fa-solid fa-arrow-left"></i>
                    </button>
                    <div class="player-title">
                        <h3 style="font-size: 1.2rem; font-weight: bold;">${short.title}</h3>
                        <span style="font-size: 0.9rem; opacity: 0.8;">Bölüm ${episode.number}</span>
                    </div>
                </div>
                
                <div class="video-wrapper" id="short-video-wrapper" style="flex:1; display:flex; align-items:center; justify-content:center;">
                    ${this.renderVideoSource(currentSource)}
                </div>
                
                <div class="episode-nav" style="position: absolute; bottom: 30px; width: 100%; display: flex; justify-content: center; gap: 20px;">
                    ${episode.number > 1 ? `
                        <button class="nav-btn prev" onclick="ShortsPage.playEpisode(${episode.number - 1})" style="background: rgba(255,255,255,0.1); backdrop-filter: blur(10px);">
                            <i class="fa-solid fa-chevron-left"></i> Önceki
                        </button>
                    ` : ''}
                    
                    ${episode.number < short.totalEpisodes ? `
                        <button class="nav-btn next" onclick="ShortsPage.playEpisode(${episode.number + 1})" style="background: rgba(255,255,255,0.1); backdrop-filter: blur(10px);">
                            Sonraki <i class="fa-solid fa-chevron-right"></i>
                        </button>
                    ` : ''}
                </div>
            </div>
        `;

        modal.style.display = 'block';

        // Initialize HLS if needed
        if (currentSource?.type === 'hls') {
            setTimeout(() => this.initHLS(currentSource.url), 100);
        }

        // Increment view
        fetch('/api/shorts.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'view', id: short.id })
        }).catch(() => { });
    },

    renderVideoSource(source) {
        if (!source) {
            return `
                <div class="video-placeholder">
                    <i class="fa-solid fa-film"></i>
                    <p>Video henüz yüklenmemiş</p>
                </div>
            `;
        }

        switch (source.type) {
            case 'youtube':
                // Extract YouTube ID
                const ytMatch = source.url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&?]+)/);
                const ytId = ytMatch ? ytMatch[1] : source.url;
                return `
                    <iframe id="short-video" src="https://www.youtube.com/embed/${ytId}?autoplay=1" 
                            frameborder="0" allow="autoplay; fullscreen" allowfullscreen
                            style="width: 100%; height: 100%;"></iframe>
                `;

            case 'embed':
                return `
                    <iframe id="short-video" src="${source.url}" 
                            frameborder="0" allow="autoplay; fullscreen" allowfullscreen
                            style="width: 100%; height: 100%;"></iframe>
                `;

            case 'hls':
                return `
                    <video id="short-video" controls autoplay style="width: 100%; height: 100%;"></video>
                `;

            case 'mp4':
            default:
                return `
                    <video id="short-video" controls autoplay style="width: 100%; height: 100%;">
                        <source src="${source.url}" type="video/mp4">
                        Tarayıcınız video oynatmayı desteklemiyor.
                    </video>
                `;
        }
    },

    changeSource(episodeNum, sourceIndex) {
        const episode = this.currentShort.episodes.find(ep => ep.number === episodeNum);
        if (!episode || !episode.sources) return;

        const source = episode.sources[parseInt(sourceIndex)];
        if (!source) return;

        const wrapper = document.getElementById('short-video-wrapper');
        wrapper.innerHTML = this.renderVideoSource(source);

        if (source.type === 'hls') {
            this.initHLS(source.url);
        }
    },

    initHLS(url) {
        const video = document.getElementById('short-video');
        if (!video) return;

        // Check if HLS.js is available
        if (window.Hls && Hls.isSupported()) {
            const hls = new Hls();
            hls.loadSource(url);
            hls.attachMedia(video);
            hls.on(Hls.Events.MANIFEST_PARSED, () => {
                video.play().catch(e => console.log('Play blocked:', e));
            });
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
            // Native HLS support (Safari)
            video.src = url;
            video.addEventListener('loadedmetadata', () => {
                video.play().catch(e => console.log('Play blocked:', e));
            });
        } else {
            console.warn('HLS not supported');
        }
    },

    closeDetailModal() {
        const modal = document.getElementById('short-modal');
        modal.style.display = 'none';
        document.body.style.overflow = '';
        this.currentShort = null;
    },

    closeVideoPlayer() {
        const modal = document.getElementById('video-player-modal');
        const video = document.getElementById('short-video');
        if (video) video.pause();
        modal.style.display = 'none';
    },

    closeUnlockModal() {
        const modal = document.getElementById('coin-unlock-modal');
        modal.style.display = 'none';
    }
};

// Export
window.ShortsPage = ShortsPage;
