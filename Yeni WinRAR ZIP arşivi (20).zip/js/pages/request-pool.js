/**
 * Series Request Pool (Dizi İstek Havuzu)
 * Allows users to request new content and vote on them.
 */

window.RequestPool = {
    requests: [],

    async show() {
        // Toggle view
        ViewManager.show('request-pool');
        this.render();
        await this.load();
    },

    async load() {
        try {
            const response = await fetch('api/db.php?action=req-list');
            const result = await response.json();
            if (result.success) {
                this.requests = result.data.sort((a, b) => b.votes - a.votes);
                this.render();
            }
        } catch (e) {
            console.error('RequestPool load error:', e);
        }
    },

    render() {
        const container = document.getElementById('main-content');
        if (!container) return;

        const isCreator = State.currentUser?.role === 'admin' || State.currentUser?.badges?.includes('Çevirmen');

        container.innerHTML = `
            <div class="request-pool-page premium-page-styling" style="padding: 40px 10px; max-width: 1000px; margin: 0 auto;">
                <div class="pool-header" style="text-align: center; margin-bottom: 50px;">
                    <h1 style="font-size: 2.5rem; margin-bottom: 10px; background: linear-gradient(135deg, #fff, #8b5cf6); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Dizi İstek Havuzu</h1>
                    <p style="color: #94a3b8; font-size: 1.1rem;">Görmek istediğiniz yapımları oylayın veya yenisini ekleyin!</p>
                    <button class="btn btn-primary" onclick="RequestPool.showAddModal()" style="margin-top: 20px;">
                        <i class="fa-solid fa-plus-circle"></i> Yeni İstek Oluştur
                    </button>
                </div>

                <div class="requests-grid" style="display: grid; gap: 20px;">
                    ${this.requests.length > 0 ? this.requests.map(req => `
                        <div class="request-card glass-panel" style="display: flex; align-items: center; padding: 25px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); background: rgba(30, 41, 59, 0.4); backdrop-filter: blur(10px); transition: all 0.3s ease;">
                            <div class="vote-control" style="text-align: center; padding-right: 25px; border-right: 1px solid rgba(255,255,255,0.1); margin-right: 25px;">
                                <button onclick="RequestPool.vote('${req.id}')" style="background: none; border: none; color: ${req.voters.includes(State.currentUser?.username) ? '#8b5cf6' : '#fff'}; cursor: pointer; font-size: 1.5rem; display: block; width: 100%;">
                                    <i class="fa-solid fa-circle-chevron-up"></i>
                                </button>
                                <span style="font-size: 1.4rem; font-weight: 800; color: #fff;">${req.votes}</span>
                                <span style="display: block; font-size: 10px; color: #94a3b8; text-transform: uppercase;">OY</span>
                            </div>

                            <div class="request-info" style="flex: 1;">
                                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                                    <h3 style="margin: 0; color: #fff; font-size: 1.3rem;">${req.title}</h3>
                                    <span class="status-badge ${req.status}" style="font-size: 11px; padding: 3px 8px; border-radius: 10px; background: ${this.getStatusColor(req.status)}22; color: ${this.getStatusColor(req.status)}; border: 1px solid ${this.getStatusColor(req.status)}44;">
                                        ${this.getStatusText(req.status)}
                                    </span>
                                </div>
                                <p style="color: #94a3b8; font-size: 0.95rem; margin-bottom: 5px;">${req.note || 'Açıklama bırakılmadı.'}</p>
                                <div style="font-size: 11px; color: #64748b;">
                                    Öneren: <strong>${req.userId}</strong> • ${new Date(req.date).toLocaleDateString('tr-TR')}
                                </div>
                            </div>

                            <div class="request-actions">
                                ${isCreator && req.status === 'pending' ? `
                                    <button class="btn btn-sm btn-outline" onclick="RequestPool.claim('${req.id}')">
                                        <i class="fa-solid fa-hand-holding-hand"></i> Üstlen
                                    </button>
                                ` : ''}
                                ${req.status === 'claimed' ? `
                                    <div style="text-align: right; color: #10b981; font-size: 12px;">
                                        <i class="fa-solid fa-check-circle"></i> ${req.claimedBy} tarafından üstlenildi
                                    </div>
                                ` : ''}
                            </div>
                        </div>
                    `).join('') : `
                        <div style="text-align: center; padding: 50px; color: #64748b;">
                            <i class="fa-solid fa-face-smile-wd" style="font-size: 3rem; margin-bottom: 20px;"></i>
                            <p>Henüz istek yok. İlk isteği sen gönder!</p>
                        </div>
                    `}
                </div>
            </div>

            <style>
                .request-card:hover { transform: translateY(-5px); border-color: rgba(139, 92, 246, 0.4); box-shadow: 0 10px 30px rgba(0,0,0,0.3); }
                .pool-header h1 { letter-spacing: -1px; }
            </style>
        `;
    },

    getStatusColor(status) {
        switch (status) {
            case 'pending': return '#ffd700';
            case 'claimed': return '#10b981';
            case 'completed': return '#3b82f6';
            default: return '#94a3b8';
        }
    },

    getStatusText(status) {
        switch (status) {
            case 'pending': return 'Beklemede';
            case 'claimed': return 'Üstlenildi';
            case 'completed': return 'Tamamlandı';
            default: return 'Bilinmiyor';
        }
    },

    showAddModal() {
        if (!State.currentUser) {
            Toast.error('İstek oluşturmak için giriş yapmalısınız.');
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'add-request-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 500px; width: 90%;">
                <div class="modal-header">
                    <h2>Yeni Dizi İsteği</h2>
                    <button class="modal-close" onclick="document.getElementById('add-request-modal').remove()">×</button>
                </div>
                <div class="modal-body" style="padding: 20px;">
                    <form onsubmit="event.preventDefault(); RequestPool.submitRequest()">
                        <div class="form-group">
                            <label>Dizi / Film Adı</label>
                            <input type="text" id="req-title" class="form-input" placeholder="Örn: Squid Game" required>
                        </div>
                        <div class="form-group" style="margin-top: 15px;">
                            <label>Not / Açıklama (Opsiyonel)</label>
                            <textarea id="req-note" class="form-input" style="height: 100px;" placeholder="Dizi hakkında kısa bir bilgi veya neden istediğinizi yazabilirsiniz..."></textarea>
                        </div>
                        <div class="form-actions" style="margin-top: 25px; display: flex; justify-content: flex-end; gap: 10px;">
                            <button type="button" class="btn btn-outline" onclick="document.getElementById('add-request-modal').remove()">İptal</button>
                            <button type="submit" class="btn btn-primary">İsteği Gönder</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async submitRequest() {
        const title = document.getElementById('req-title').value;
        const note = document.getElementById('req-note').value;

        try {
            const response = await fetch('api/db.php?action=req-add', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, note })
            });

            const result = await response.json();
            if (result.success) {
                Toast.success('İsteğiniz başarıyla eklendi! Oyları topla!');
                document.getElementById('add-request-modal').remove();
                await this.load();
            } else {
                Toast.error(result.message);
            }
        } catch (e) {
            console.error('RequestPool submit error:', e);
            Toast.error('Sunucu hatası');
        }
    },

    async vote(id) {
        if (!State.currentUser) {
            Toast.error('Oy vermek için giriş yapmalısınız.');
            return;
        }

        try {
            const response = await fetch(`api/db.php?action=req-vote&id=${id}`);
            const result = await response.json();
            if (result.success) {
                Toast.success('Oyunuz kaydedildi!');
                await this.load();
            } else {
                Toast.error(result.message);
            }
        } catch (e) {
            console.error('RequestPool vote error:', e);
            Toast.error('Sunucu hatası');
        }
    },

    async claim(id) {
        try {
            const response = await fetch(`api/db.php?action=req-claim&id=${id}`);
            const result = await response.json();
            if (result.success) {
                Toast.success('İstek üstlenildi. Başarılar dileriz!');
                await this.load();
            } else {
                Toast.error(result.message);
            }
        } catch (e) {
            console.error('RequestPool claim error:', e);
            Toast.error('Sunucu hatası');
        }
    }
};
