/**
 * Series Edit — tabbed modal for admins / studio roles
 */
const SeriesEdit = {
    series: null,
    activeTab: 'general',
    GENRES: ['Dram', 'Romantik', 'Komedi', 'Aksiyon', 'Gerilim', 'Fantastik', 'Tarih', 'Bilim Kurgu', 'Korku', 'Gizem', 'Aile', 'Gençlik', 'Müzikal', 'Spor'],

    async open(seriesId) {
        await db.ensureCollection('series');
        await db.ensureCollection('actors');
        this.series = db.getSeries(seriesId);
        if (!this.series) {
            Toast.error('İçerik bulunamadı.');
            App.router('home');
            return;
        }
        if (!this.series.episodes) this.series.episodes = [];
        if (!this.series.cast) this.series.cast = [];
        if (!this.series.genres) {
            this.series.genres = Array.isArray(this.series.genre)
                ? [...this.series.genre]
                : (this.series.genre ? String(this.series.genre).split(',').map(g => g.trim()) : []);
        }
        this.activeTab = 'general';
        this.render();
    },

    close() {
        document.getElementById('series-edit-overlay')?.remove();
        if (window.location.hash.includes('edit-series')) {
            history.replaceState(null, '', '#/detail/' + encodeURIComponent(this.series?.id || ''));
        }
    },

    render() {
        document.getElementById('series-edit-overlay')?.remove();
        const s = this.series;
        const overlay = document.createElement('div');
        overlay.id = 'series-edit-overlay';
        overlay.className = 'series-edit-overlay glass-panel';
        overlay.innerHTML = `
            <div class="series-edit-modal glass-panel">
                <header class="series-edit-header">
                    <h2><i class="fa-solid fa-pen-to-square"></i> Dizi Düzenle: ${s.title}</h2>
                    <button type="button" class="btn-glass-icon" onclick="SeriesEdit.close()" aria-label="Kapat">&times;</button>
                </header>
                <nav class="series-edit-tabs">
                    <button type="button" class="${this.activeTab === 'general' ? 'active' : ''}" onclick="SeriesEdit.switchTab('general')">Genel</button>
                    <button type="button" class="${this.activeTab === 'episodes' ? 'active' : ''}" onclick="SeriesEdit.switchTab('episodes')">Bölümler</button>
                    <button type="button" class="${this.activeTab === 'cast' ? 'active' : ''}" onclick="SeriesEdit.switchTab('cast')">Oyuncular</button>
                    <button type="button" class="${this.activeTab === 'genres' ? 'active' : ''}" onclick="SeriesEdit.switchTab('genres')">Türler</button>
                </nav>
                <div class="series-edit-body" id="series-edit-body"></div>
                <footer class="series-edit-footer">
                    <button type="button" class="btn btn-outline" onclick="SeriesEdit.close()">İptal</button>
                    <button type="button" class="btn btn-primary btn-glass-glow" onclick="SeriesEdit.save()"><i class="fa-solid fa-floppy-disk"></i> Kaydet</button>
                </footer>
            </div>
        `;
        document.body.appendChild(overlay);
        this.renderTabBody();
    },

    switchTab(tab) {
        this.activeTab = tab;
        document.querySelectorAll('.series-edit-tabs button').forEach(btn => {
            btn.classList.toggle('active', btn.getAttribute('onclick')?.includes(`'${tab}'`));
        });
        this.renderTabBody();
    },

    renderTabBody() {
        const body = document.getElementById('series-edit-body');
        if (!body) return;
        const s = this.series;
        if (this.activeTab === 'general') {
            body.innerHTML = `
                <div class="form-grid-2">
                    <div class="form-group"><label>Başlık</label><input id="se-title" class="form-input" value="${this.esc(s.title)}"></div>
                    <div class="form-group"><label>Korece Başlık</label><input id="se-korean" class="form-input" value="${this.esc(s.koreanTitle || s.originalTitle || '')}" placeholder="예: 드라마 제목"></div>
                    <div class="form-group"><label>Yaş Sınırı</label>
                        <select id="se-age" class="form-input">
                            ${['Genel', '13+', '16+', '18+', '21+'].map(a => `<option value="${a}" ${(s.ageRating || 'Genel') === a ? 'selected' : ''}>${a}</option>`).join('')}
                        </select>
                    </div>
                    <div class="form-group"><label>Durum</label>
                        <select id="se-status" class="form-input">
                            <option value="Devam Ediyor" ${s.status === 'Devam Ediyor' ? 'selected' : ''}>Devam Ediyor</option>
                            <option value="Tamamlandı" ${s.status === 'Tamamlandı' ? 'selected' : ''}>Tamamlandı</option>
                        </select>
                    </div>
                </div>
                <div class="form-group"><label>Açıklama</label><textarea id="se-desc" class="form-input" rows="5">${this.esc(s.description || '')}</textarea></div>
            `;
        } else if (this.activeTab === 'episodes') {
            const eps = this.flattenEpisodes(s);
            body.innerHTML = `
                <div id="se-episodes-list">${eps.map((ep, i) => this.episodeRow(ep, i)).join('')}</div>
                <button type="button" class="btn btn-outline btn-sm" style="margin-top:12px;" onclick="SeriesEdit.addEpisode()"><i class="fa-solid fa-plus"></i> Bölüm Ekle</button>
            `;
        } else if (this.activeTab === 'cast') {
            const actors = State.data.actors || [];
            const castIds = (s.cast || []).map(c => typeof c === 'string' ? c : (c.id || c.name));
            body.innerHTML = `
                <div class="form-group">
                    <label>Oyuncu Ekle</label>
                    <select id="se-cast-select" class="form-input" onchange="SeriesEdit.addCastFromSelect(this.value)">
                        <option value="">— Oyuncu seç —</option>
                        ${actors.map(a => `<option value="${this.esc(a.id || a.name)}">${this.esc(a.name)}</option>`).join('')}
                    </select>
                </div>
                <div id="se-cast-chips">${(s.cast || []).map((c, i) => this.castChip(c, i)).join('')}</div>
                <button type="button" class="btn btn-outline btn-sm" style="margin-top:10px;" onclick="SeriesEdit.promptNewActor()"><i class="fa-solid fa-user-plus"></i> Yeni Oyuncu</button>
            `;
        } else if (this.activeTab === 'genres') {
            const selected = new Set((s.genres || []).map(g => g.trim()));
            body.innerHTML = `
                <div class="genre-checkbox-grid">
                    ${this.GENRES.map(g => `
                        <label class="genre-check glass-panel">
                            <input type="checkbox" value="${g}" ${selected.has(g) ? 'checked' : ''}>
                            <span>${g}</span>
                        </label>
                    `).join('')}
                </div>
            `;
        }
    },

    episodeRow(ep, index) {
        const sources = (ep.sources && ep.sources.length)
            ? ep.sources
            : ((ep.videoUrl || ep.url) ? [{ name: 'Varsayılan', url: ep.videoUrl || ep.url }] : [{ name: 'Kaynak 1', url: '' }]);
        const sourceFields = sources.map((s, si) => `
            <div class="se-source-row" style="display:grid; grid-template-columns:140px 1fr; gap:10px; margin-bottom:8px;">
                <input type="text" class="form-input se-ep-src-name" value="${this.esc(s.name || s.label || 'Kaynak ' + (si + 1))}" placeholder="Kaynak adı">
                <input type="url" class="form-input se-ep-src-url" value="${this.esc(s.url || '')}" placeholder="Video / embed URL">
            </div>
        `).join('');
        return `
            <div class="se-episode-row glass-panel" data-ep-index="${index}" style="margin-bottom:14px; padding:14px;">
                <div class="form-grid-3">
                    <div class="form-group"><label>Sezon</label><input type="number" class="form-input se-ep-season" value="${ep.seasonNum || 1}" min="1"></div>
                    <div class="form-group"><label>Bölüm #</label><input type="number" class="form-input se-ep-num" value="${ep.number || index + 1}" min="1"></div>
                    <div class="form-group"><label>Başlık</label><input type="text" class="form-input se-ep-title" value="${this.esc(ep.title || '')}"></div>
                </div>
                <div class="form-group" style="margin-top:10px;">
                    <label>Video Kaynakları</label>
                    <div class="se-sources-wrap">${sourceFields}</div>
                    <button type="button" class="btn btn-outline btn-sm" style="margin-top:6px;" onclick="SeriesEdit.addSourceRow(this)"><i class="fa-solid fa-plus"></i> Kaynak Ekle</button>
                </div>
                <button type="button" class="btn btn-sm btn-outline" style="color:#ef4444; margin-top:8px;" onclick="SeriesEdit.removeEpisode(${index})"><i class="fa-solid fa-trash"></i> Bölümü Sil</button>
            </div>
        `;
    },

    addSourceRow(btn) {
        const wrap = btn.previousElementSibling;
        if (!wrap) return;
        const row = document.createElement('div');
        row.className = 'se-source-row';
        row.style.cssText = 'display:grid; grid-template-columns:140px 1fr; gap:10px; margin-bottom:8px;';
        row.innerHTML = `
            <input type="text" class="form-input se-ep-src-name" value="Kaynak" placeholder="Kaynak adı">
            <input type="url" class="form-input se-ep-src-url" value="" placeholder="Video / embed URL">
        `;
        wrap.appendChild(row);
    },

    castChip(c, index) {
        const name = typeof c === 'string' ? c : (c.name || c.actor || 'Oyuncu');
        return `<span class="cast-chip">${this.esc(name)} <button type="button" onclick="SeriesEdit.removeCast(${index})">&times;</button></span>`;
    },

    flattenEpisodes(series) {
        const list = [];
        if (series.seasons?.length) {
            series.seasons.forEach(season => {
                (season.episodes || []).forEach(ep => {
                    list.push({ ...ep, seasonNum: season.number || 1 });
                });
            });
        } else {
            (series.episodes || []).forEach(ep => list.push({ ...ep, seasonNum: 1 }));
        }
        return list;
    },

    addEpisode() {
        if (!this.series.episodes) this.series.episodes = [];
        const n = this.series.episodes.length + 1;
        this.series.episodes.push({ number: n, title: `Bölüm ${n}`, sources: [], seasonNum: 1 });
        this.renderTabBody();
    },

    removeEpisode(index) {
        const flat = this.flattenEpisodes(this.series);
        flat.splice(index, 1);
        this.series.episodes = flat.map((ep, i) => ({
            number: ep.number || i + 1,
            title: ep.title || `Bölüm ${i + 1}`,
            sources: ep.sources?.length ? ep.sources : (ep.videoUrl || ep.url ? [{ name: 'Varsayılan', url: ep.videoUrl || ep.url }] : []),
            seasonNum: ep.seasonNum || 1
        }));
        this.series.seasons = null;
        this.renderTabBody();
    },

    addCastFromSelect(value) {
        if (!value) return;
        const actor = (State.data.actors || []).find(a => String(a.id) === value || a.name === value);
        if (!actor) return;
        if (!this.series.cast) this.series.cast = [];
        const exists = this.series.cast.some(c => {
            const id = typeof c === 'string' ? c : (c.id || c.name);
            return String(id) === String(actor.id) || id === actor.name;
        });
        if (exists) return Toast.info('Oyuncu zaten ekli.');
        this.series.cast.push({ id: actor.id, name: actor.name, image: actor.avatar, koreanName: actor.koreanName });
        document.getElementById('se-cast-select').value = '';
        this.renderTabBody();
    },

    removeCast(index) {
        this.series.cast.splice(index, 1);
        this.renderTabBody();
    },

    async promptNewActor() {
        const name = prompt('Yeni oyuncu adı:');
        if (!name?.trim()) return;
        const actor = { id: 'actor_' + Date.now(), name: name.trim(), avatar: 'assets/default-avatar.png', bio: '' };
        if (!State.data.actors) State.data.actors = [];
        State.data.actors.push(actor);
        await db.saveItem('actors', actor.id, actor);
        this.addCastFromSelect(actor.id);
        Toast.success('Oyuncu oluşturuldu ve kadroya eklendi.');
    },

    collectEpisodesFromForm() {
        const rows = document.querySelectorAll('.se-episode-row');
        const episodes = [];
        rows.forEach((row, i) => {
            const num = parseInt(row.querySelector('.se-ep-num')?.value, 10) || i + 1;
            const title = row.querySelector('.se-ep-title')?.value?.trim() || `Bölüm ${num}`;
            const ep = { number: num, title, sources: [] };
            row.querySelectorAll('.se-source-row').forEach((srcRow, si) => {
                const url = srcRow.querySelector('.se-ep-src-url')?.value?.trim() || '';
                const name = srcRow.querySelector('.se-ep-src-name')?.value?.trim() || `Kaynak ${si + 1}`;
                if (url) ep.sources.push({ id: 'src-' + Date.now() + '-' + i + '-' + si, name, url });
            });
            if (ep.sources[0]) ep.videoUrl = ep.sources[0].url;
            episodes.push(ep);
        });
        return episodes;
    },

    async save() {
        const s = this.series;
        if (this.activeTab === 'general' || document.getElementById('se-title')) {
            s.title = document.getElementById('se-title')?.value?.trim() || s.title;
            s.koreanTitle = document.getElementById('se-korean')?.value?.trim() || '';
            s.originalTitle = s.koreanTitle || s.originalTitle;
            s.ageRating = document.getElementById('se-age')?.value || s.ageRating;
            s.status = document.getElementById('se-status')?.value || s.status;
            s.description = document.getElementById('se-desc')?.value?.trim() || s.description;
        }
        if (document.querySelector('.se-episode-row')) {
            s.episodes = this.collectEpisodesFromForm();
            s.seasons = null;
        }
        if (document.querySelector('.genre-checkbox-grid')) {
            s.genres = Array.from(document.querySelectorAll('.genre-checkbox-grid input:checked')).map(i => i.value);
            s.genre = s.genres.join(', ');
        }

        Toast.info('Kaydediliyor...');
        const ok = await db.saveSeries(s);
        if (ok) {
            Toast.success('İçerik kaydedildi!');
            this.close();
            if (window.DetailedView?.render && State.currentSeries?.id === s.id) {
                DetailedView.render(s.id);
            }
        } else {
            Toast.warning('Yerel kayıt yapıldı; sunucu senkronu başarısız olabilir.');
            this.close();
        }
    },

    esc(str) {
        if (!str) return '';
        return String(str).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
};

window.SeriesEdit = SeriesEdit;
