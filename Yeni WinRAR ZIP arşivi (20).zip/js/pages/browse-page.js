var BrowsePage = {
    currentType: 'drama',

    init(type = 'drama') {
        this.currentType = type;
        this.render();
    },

    render() {
        const view = document.getElementById('browse-view');
        if (!view) return;

        // Update Title
        const title = document.getElementById('browse-page-title');
        if (title) {
            let label = 'Dizi Kütüphanesi';
            let icon = 'fa-solid fa-film';

            if (this.currentType === 'webtoon') { label = 'Webtoon Arşivi'; icon = 'fa-solid fa-book-open'; }
            else if (this.currentType === 'anime') { label = 'Anime Dünyası'; icon = 'fa-solid fa-ghost'; }
            else if (this.currentType === 'movie' || this.currentType === 'movies') { label = 'Film Koleksiyonu'; icon = 'fa-solid fa-clapperboard'; }

            title.innerHTML = `
                <i class="${icon}" style="color: #8b5cf6; margin-right: 10px;"></i>
                ${label}
            `;
        }

        // Setup Event Listeners for Filters if not already attached (or just re-attach)
        this.setupFilters();

        // Populate Filters
        this.populateFilters();

        // Initial Grid Render
        this.applyFilters();
    },

    filters: {
        genre: '',
        year: '',
        country: '',
        status: ''
    },

    setupFilters() {
        const searchInput = document.getElementById('browse-search-input');
        if (searchInput) {
            searchInput.oninput = () => this.applyFilters();
        }

        // Accordion logic: Close others when opening one
        window.toggleFilterDropdown = (key) => {
            const dropdown = document.getElementById(`dropdown-${key}`);
            const isActive = dropdown.classList.contains('active');
            
            // Close all
            document.querySelectorAll('.modern-filter-dropdown').forEach(d => d.classList.remove('active'));
            
            // Toggle current
            if (!isActive) dropdown.classList.add('active');
        };

        // Mobile toggle logic
        window.toggleMobileFilters = () => {
            const bar = document.querySelector('.modern-filter-bar');
            if (bar) bar.classList.toggle('active');
        };

        // Close dropdowns when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.modern-filter-dropdown')) {
                document.querySelectorAll('.modern-filter-dropdown.active').forEach(d => d.classList.remove('active'));
            }
        });
    },

    setFilter(key, value) {
        this.filters[key] = value;
        
        // Update UI Label
        const labelEl = document.getElementById(`selected-${key}`);
        if (labelEl) {
            labelEl.innerText = value || 'Tümü';
            labelEl.style.color = value ? 'var(--ultra-accent)' : 'rgba(255,255,255,0.6)';
        }

        // Close dropdown
        const dropdown = document.getElementById(`dropdown-${key}`);
        if (dropdown) dropdown.classList.remove('active');

        this.applyFilters();
    },

    clearFilters() {
        this.filters = { genre: '', year: '', country: '', status: '' };
        ['genre', 'year', 'country', 'status'].forEach(k => {
            const el = document.getElementById(`selected-${k}`);
            if (el) el.innerText = 'Tümü';
        });
        this.applyFilters();
    },

    populateFilters() {
        if (!State || !State.data || !State.data.series) return;

        const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])];
        const items = allContent.filter(s => {
            if (this.currentType === 'webtoon') return s.type === 'webtoon';
            if (this.currentType === 'anime') return s.type === 'anime';
            if (this.currentType === 'movie' || this.currentType === 'movies') return s.type === 'movie' || s.type === 'movies';
            return s.type !== 'webtoon' && s.type !== 'anime' && s.type !== 'movie' && s.type !== 'movies';
        });

        const years = new Set();
        const genres = new Set();
        const countries = new Set();

        items.forEach(s => {
            if (s.year) years.add(s.year);
            if (s.country) countries.add(s.country);

            const genreList = s.genres || s.genre;
            if (genreList) {
                if (Array.isArray(genreList)) {
                    genreList.forEach(g => genres.add(g.trim()));
                } else if (typeof genreList === 'string') {
                    genreList.split(',').forEach(g => genres.add(g.trim()));
                }
            }
        });

        this.renderOptions('genre', Array.from(genres).sort());
        this.renderOptions('year', Array.from(years).sort((a, b) => b - a));
        this.renderOptions('country', Array.from(countries).sort());
        // Status is static in HTML
    },

    renderOptions(key, values) {
        const el = document.getElementById(`options-${key}`);
        if (!el) return;

        let html = `<div class="option" onclick="BrowsePage.setFilter('${key}', '')">Tümü</div>`;
        values.forEach(v => {
            html += `<div class="option" onclick="BrowsePage.setFilter('${key}', '${v}')">${v}</div>`;
        });
        el.innerHTML = html;
    },

    applyFilters() {
        if (!State || !State.data || !State.data.series) return;

        const search = document.getElementById('browse-search-input')?.value.toLowerCase().trim();

        const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])];
        let items = allContent.filter(s => {
            if (this.currentType === 'webtoon') return s.type === 'webtoon';
            if (this.currentType === 'anime') return s.type === 'anime';
            if (this.currentType === 'movie' || this.currentType === 'movies') return s.type === 'movie' || s.type === 'movies';
            return s.type !== 'webtoon' && s.type !== 'anime' && s.type !== 'movie' && s.type !== 'movies';
        });

        // Apply Filters
        if (search) items = items.filter(s => s.title.toLowerCase().includes(search));
        if (this.filters.year) items = items.filter(s => s.year == this.filters.year);
        if (this.filters.status) items = items.filter(s => s.status === this.filters.status);
        if (this.filters.country) items = items.filter(s => s.country === this.filters.country);
        if (this.filters.genre) {
            items = items.filter(s => {
                const gList = s.genres || s.genre;
                if (Array.isArray(gList)) return gList.includes(this.filters.genre);
                if (typeof gList === 'string') return gList.includes(this.filters.genre);
                return false;
            });
        }

        this.renderGrid(items);
    },

    renderGrid(items) {
        const grid = document.getElementById('browse-grid');
        if (!grid) return;

        if (items.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 100px 20px; background: rgba(30, 41, 59, 0.3); border: 2px dashed rgba(139, 92, 246, 0.1); border-radius: 24px; margin-top: 20px;">
                    <i class="fa-solid fa-magnifying-glass" style="font-size: 4rem; color: #334155; margin-bottom: 20px; display: block;"></i>
                    <h3 style="color: #94a3b8;">Sonuç Bulunamadı</h3>
                    <p style="color: #64748b; margin-top: 10px;">Aradığınız kriterlere uygun herhangi bir ${this.currentType === 'anime' ? 'anime' : (this.currentType === 'webtoon' ? 'webtoon' : 'dizi')} bulunamadı.</p>
                </div>
            `;
            return;
        }

        // Use StandardCard for consistent premium look
        // Ensure StandardCard is available
        if (typeof StandardCard !== 'undefined') {
            grid.innerHTML = items.map(item => StandardCard.render(item)).join('');
        } else {
            // Fallback
            grid.innerHTML = items.map(item => `
                <div class="standard-media-card" onclick="App.router('detail', '${item.id}')">
                    <img src="${item.poster || item.coverImage}" class="std-card-poster">
                    <div class="std-card-info">
                        <h3>${item.title}</h3>
                    </div>
                </div>
            `).join('');
        }
    }
};

window.BrowsePage = BrowsePage;
