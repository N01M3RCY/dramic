const TranslationStudioPage = {
    seriesId: null,
    epNum: null,
    videoUrl: null,
    subtitles: [],
    meta: {},
    player: null,
    syncInterval: null,
    videoElement: null,
    lastLocalUpdate: 0,
    currentUser: null,
    subStyles: {
        fontSize: '24px',
        color: '#ffffff',
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        fontWeight: 'bold',
        textShadow: '0 2px 4px rgba(0,0,0,0.8)',
        borderRadius: '8px',
        padding: '10px 20px'
    },

    init(seriesId, epNum, videoUrl) {
        this.seriesId = seriesId;
        this.epNum = epNum;
        this.videoUrl = videoUrl;
        this.currentUser = State.currentUser ? State.currentUser.username : 'Guest_' + Math.floor(Math.random() * 1000);

        // Load CSS dynamically
        if (!document.getElementById('studio-css')) {
            const link = document.createElement('link');
            link.id = 'studio-css';
            link.rel = 'stylesheet';
            link.href = 'css/pages/translation-studio.css';
            document.head.appendChild(link);
        }

        this.renderUI();
        this.loadData();
        this.startSync();

        // Keyboard shortcuts
        document.addEventListener('keydown', this.handleKeydown.bind(this));
    },

    renderUI() {
        const view = document.createElement('div');
        view.id = 'translation-studio-view';
        view.className = 'studio-fullscreen-view';
        view.innerHTML = `
            <!-- Top Bar -->
            <div class="ts-topbar">
                <div class="ts-brand">
                    <button class="icon-btn-large" onclick="TranslationStudioPage.close()">
                        <i class="fa-solid fa-chevron-left"></i>
                    </button>
                    <div class="ts-title-group">
                        <span class="ts-app-name">DramicBox Studio</span>
                        <span class="ts-divider">/</span>
                        <span class="ts-project-name">${this.seriesId} - Bölüm ${this.epNum}</span>
                    </div>
                </div>

                <div class="ts-actions">
                    <div class="ts-collab-status" id="collab-status">
                        <div class="status-dot"></div> <span class="status-text">Çevrimdışı</span>
                    </div>
                    <div class="ts-action-divider"></div>
                    <button class="ts-btn ts-btn-icon" onclick="TranslationStudioPage.openStyleSettings()" title="Görünüm Ayarları">
                        <i class="fa-solid fa-swatchbook"></i>
                    </button>
                    <button class="ts-btn ts-btn-secondary" onclick="TranslationStudioPage.save()">
                        <i class="fa-solid fa-cloud"></i> Taslak
                    </button>
                    <button class="ts-btn ts-btn-primary" onclick="TranslationStudioPage.submit()">
                        <i class="fa-solid fa-paper-plane"></i> Gönder
                    </button>
                </div>
            </div>

            <div class="ts-workspace">
                <!-- Left: Video Preview -->
                <div class="ts-preview-panel">
                    <div class="ts-video-wrapper">
                         ${this.videoUrl ?
                `<video id="studio-video" class="ts-video" controls src="${this.videoUrl}"></video>` :
                `<div class="ts-no-video"><i class="fa-solid fa-film"></i><span>Video Kaynağı Yok</span></div>`
            }
                        <div id="video-overlay-subs" class="ts-video-overlay" style="display: none;"></div>
                    </div>
                    <div class="ts-controls-area">
                        <!-- Custom controls could go here -->
                        <div class="ts-shortcuts-hint">
                            <span><kbd>Space</kbd> Oynat/Durdur</span>
                            <span><kbd>Ctrl+S</kbd> Kaydet</span>
                            <span><kbd>Alt+N</kbd> Yeni Satır</span>
                        </div>
                    </div>
                </div>

                <!-- Right: Editor -->
                <div class="ts-editor-panel">
                    <div class="ts-editor-header">
                        <div class="ts-editor-title">Altyazı Editörü</div>
                        <div class="ts-editor-tools">
                             <button class="ts-tool-btn" onclick="TranslationStudioPage.aiTranslate()" title="AI Otomatik Çeviri">
                                <i class="fa-solid fa-wand-magic-sparkles"></i> AI
                            </button>
                            <button class="ts-tool-btn primary" onclick="TranslationStudioPage.addSubtitle()">
                                <i class="fa-solid fa-plus"></i> Ekle
                            </button>
                        </div>
                    </div>
                    <div class="ts-subtitle-list" id="subtitle-list">
                        <!-- Subtitles render here -->
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(view);

        if (this.videoUrl) {
            this.videoElement = document.getElementById('studio-video');
            this.videoElement.addEventListener('timeupdate', () => this.onVideoTimeUpdate());
        }
    },

    close() {
        if (confirm('Kaydedilmemiş değişiklikler olabilir. Çıkmak istiyor musunuz?')) {
            document.getElementById('translation-studio-view').remove();
            this.stopSync();
            document.removeEventListener('keydown', this.handleKeydown);
            // Navigate back?
            // window.history.back();
        }
    },

    async loadData() {
        try {
            const res = await fetch(`api/db.php?action=translation-get&seriesId=${this.seriesId}&epNum=${this.epNum}`);
            const data = await res.json();

            if (data.subtitles) {
                this.subtitles = data.subtitles;
                this.meta = data.meta;
                this.renderSubtitles();
            }
        } catch (e) {
            console.error('Load failed', e);
            Toast.error('Veri yüklenemedi');
        }
    },

    save() {
        this.performSave(true);
    },

    async performSave(showToast = false) {
        try {
            const payload = {
                seriesId: this.seriesId,
                epNum: this.epNum,
                subtitles: this.subtitles,
                userId: this.currentUser
            };

            const res = await fetch('api/db.php?action=translation-save', {
                method: 'POST',
                body: JSON.stringify(payload)
            });
            const result = await res.json();

            if (result.success) {
                this.lastLocalUpdate = Date.now();
                if (showToast) Toast.success('Kaydedildi');
            } else {
                if (showToast) Toast.error('Hata');
            }
        } catch (e) {
            console.error('Save failed', e);
        }
    },

    async submit() {
        if (!confirm('Çeviriyi onaya göndermek istediğinize emin misiniz?')) return;

        try {
            const res = await fetch('api/db.php?action=translation-submit', {
                method: 'POST',
                body: JSON.stringify({ seriesId: this.seriesId, epNum: this.epNum })
            });
            const result = await res.json();
            if (result.success) {
                Toast.success('Onaya gönderildi!');
                this.close();
            }
        } catch (e) {
            Toast.error('Gönderim hatası');
        }
    },

    startSync() {
        this.syncInterval = setInterval(async () => {
            // Poll for updates (simulate real-time)
            try {
                const res = await fetch(`api/db.php?action=translation-get&seriesId=${this.seriesId}&epNum=${this.epNum}`);
                const data = await res.json();

                // If remote has newer update than our last load/save
                // Simple logic: If data.subtitles differs and we haven't touched anything recently?
                // For simplicity in this non-socket env: Just check count or content hash?
                // Or simply: update Contributors list actively, but prompt for content update?

                // Let's just update the "meta" info (contributors) live
                if (data.meta && data.meta.contributors) {
                    const collabStatus = document.getElementById('collab-status');
                    if (collabStatus) collabStatus.innerHTML = `<div class="live-indicator"></div> ${data.meta.contributors.length} Aktif`;
                }

                // If massive difference (new lines added by others), we might want to merge.
                // Skipping complex merge for now to avoid overwriting user's active work.

            } catch (e) { /* silent fail */ }
        }, 5000);
    },

    stopSync() {
        if (this.syncInterval) clearInterval(this.syncInterval);
    },

    // --- Subtitle Logic ---

    renderSubtitles() {
        const container = document.getElementById('subtitle-list');
        container.innerHTML = this.subtitles.map((sub, index) => `
            <div class="ts-sub-item" id="sub-${sub.id}" onclick="TranslationStudioPage.jumpToSub('${sub.id}')">
                <div class="ts-sub-index">${index + 1}</div>
                <div class="ts-sub-content">
                     <div class="ts-time-controls">
                        <div class="ts-time-group">
                            <label>Başlangıç</label>
                            <input type="text" class="ts-time-input" value="${sub.start}" onchange="TranslationStudioPage.updateTime('${sub.id}', 'start', this.value)">
                        </div>
                        <div class="ts-time-connector"><i class="fa-solid fa-arrow-right"></i></div>
                        <div class="ts-time-group">
                            <label>Bitiş</label>
                            <input type="text" class="ts-time-input" value="${sub.end}" onchange="TranslationStudioPage.updateTime('${sub.id}', 'end', this.value)">
                        </div>
                    </div>
                    <textarea class="ts-text-input" placeholder="Çeviriyi buraya yazın..." oninput="TranslationStudioPage.updateText('${sub.id}', this.value)">${sub.text}</textarea>
                </div>
                <div class="ts-sub-actions">
                    <button class="ts-action-delete" onclick="TranslationStudioPage.deleteSub('${sub.id}', event)">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    },

    async aiTranslate() {
        if (!this.subtitles.length) {
            Toast.warning('Henüz çevrilecek satır yok!');
            return;
        }

        if (!confirm('Tüm boş satırları AI ile çevirmek istiyor musunuz? (Deneysel)')) return;

        Toast.info('AI Çeviri işlemi başlatıldı...');

        // Simulate progress
        let count = 0;
        for (let sub of this.subtitles) {
            if (!sub.text || sub.text.trim() === '') {
                // Mock Translation - In real world, call an API like Claude or GPT
                sub.text = "[AI Çeviriliyor...] "; // Placeholder
                count++;
            }
        }

        this.renderSubtitles();

        // Mock finalization
        setTimeout(() => {
            for (let sub of this.subtitles) {
                if (sub.text === "[AI Çeviriliyor...] ") {
                    sub.text = "AI tarafından oluşturulan taslak çeviri metni.";
                }
            }
            this.renderSubtitles();
            Toast.success(`${count} satır AI ile çevrildi!`);
        }, 1500);
    },

    openStyleSettings() {
        // Remove existing if any
        const old = document.getElementById('studio-style-modal');
        if (old) old.remove();

        const modal = document.createElement('div');
        modal.id = 'studio-style-modal';
        modal.className = 'studio-mini-modal';
        modal.style.cssText = `
            position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
            background: #1a1a1a; padding: 25px; border-radius: 12px; border: 1px solid #333;
            z-index: 10001; min-width: 300px; box-shadow: 0 10px 40px rgba(0,0,0,0.8);
        `;

        modal.innerHTML = `
            <h3 style="margin-top:0; border-bottom:1px solid #333; padding-bottom:10px;">Altyazı Stili</h3>
            <div style="margin-top:15px; display:flex; flex-direction:column; gap:15px;">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <label>Yazı Tipi Boyutu</label>
                    <input type="range" min="12" max="48" value="${parseInt(this.subStyles.fontSize)}" 
                           oninput="TranslationStudioPage.updateStyle('fontSize', this.value + 'px')">
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <label>Yazı Rengi</label>
                    <input type="color" value="${this.subStyles.color}" 
                           oninput="TranslationStudioPage.updateStyle('color', this.value)">
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <label>Arka Plan</label>
                    <input type="color" value="#000000" id="bg-color-picker"
                           oninput="TranslationStudioPage.updateStyle('backgroundColor', this.value + '99')">
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <label>Kalınlık</label>
                    <select onchange="TranslationStudioPage.updateStyle('fontWeight', this.value)" style="background:#333; color:white; border:1px solid #444; padding:2px 5px; border-radius:4px;">
                        <option value="normal" ${this.subStyles.fontWeight === 'normal' ? 'selected' : ''}>Normal</option>
                        <option value="bold" ${this.subStyles.fontWeight === 'bold' ? 'selected' : ''}>Kalın</option>
                    </select>
                </div>
            </div>
            <div style="margin-top:25px; display:flex; justify-content:flex-end;">
                <button class="btn-studio btn-studio-primary" onclick="document.getElementById('studio-style-modal').remove()">Kapat</button>
            </div>
        `;
        document.body.appendChild(modal);

        // Backdrop
        const backdrop = document.createElement('div');
        backdrop.id = 'studio-modal-backdrop';
        backdrop.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:10000;';
        backdrop.onclick = () => {
            modal.remove();
            backdrop.remove();
        };
        document.body.appendChild(backdrop);
    },

    updateStyle(prop, value) {
        this.subStyles[prop] = value;
        this.applyPreviewStyles();
    },

    applyPreviewStyles() {
        const overlay = document.getElementById('video-overlay-subs');
        if (overlay) {
            Object.assign(overlay.style, this.subStyles);
        }
    },

    addSubtitle() {
        const currentTime = this.videoElement ? this.videoElement.currentTime : 0;
        const start = this.formatTime(currentTime);
        const end = this.formatTime(currentTime + 2);

        const newSub = {
            id: 'sub_' + Date.now(),
            start: start,
            end: end,
            text: ''
        };
        this.subtitles.push(newSub);
        // Sort by start time?
        // this.subtitles.sort(...) 
        this.renderSubtitles();

        // Auto-scroll to bottom
        setTimeout(() => {
            const list = document.getElementById('subtitle-list');
            list.scrollTop = list.scrollHeight;
            document.getElementById(`sub-${newSub.id}`).querySelector('textarea').focus();
        }, 50);
    },

    updateText(id, text) {
        const sub = this.subtitles.find(s => s.id === id);
        if (sub) sub.text = text;
        // Optimization: Don't re-render whole list on text input
    },

    updateTime(id, field, value) {
        const sub = this.subtitles.find(s => s.id === id);
        if (sub) sub[field] = value;
        // Optionally sort if start time changed
    },

    deleteSub(id, event) {
        if (event) event.stopPropagation();
        if (confirm('Bu satırı silmek istiyor musunuz?')) {
            this.subtitles = this.subtitles.filter(s => s.id !== id);
            this.renderSubtitles();
        }
    },

    jumpToSub(id) {
        const sub = this.subtitles.find(s => s.id === id);
        if (sub && this.videoElement) {
            this.videoElement.currentTime = this.parseTime(sub.start);
            this.videoElement.play();
        }

        // Highlight active
        document.querySelectorAll('.img-sub-item').forEach(el => el.classList.remove('active'));
        const el = document.getElementById(`sub-${id}`);
        if (el) el.classList.add('active');
    },

    onVideoTimeUpdate() {
        if (!this.videoElement) return;
        const time = this.videoElement.currentTime;
        const formatted = this.formatTime(time);

        // Find active subtitle
        const overlay = document.getElementById('video-overlay-subs');
        const activeSub = this.subtitles.find(s => {
            const start = this.parseTime(s.start);
            const end = this.parseTime(s.end);
            return time >= start && time <= end;
        });

        if (activeSub) {
            overlay.innerText = activeSub.text;
            overlay.style.display = 'block';
            this.applyPreviewStyles(); // Apply current styles

            // Highlight in list (optional, maybe too jumpy)
            // const el = document.getElementById(`sub-${activeSub.id}`);
            // if (el) {
            //     document.querySelectorAll('.img-sub-item').forEach(e => e.classList.remove('active'));
            //     el.classList.add('active');
            //     el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            // }
        } else {
            overlay.style.display = 'none';
        }
    },

    // --- Helpers ---

    formatTime(seconds) {
        const date = new Date(0);
        date.setSeconds(seconds);
        const timeString = date.toISOString().substr(11, 8);
        const ms = Math.floor((seconds % 1) * 1000);
        return `${timeString}.${ms.toString().padStart(3, '0')}`;
    },

    parseTime(timeString) {
        // HH:MM:SS.mmm
        if (!timeString) return 0;
        const parts = timeString.split(':');
        const secondsParts = parts[2].split('.');
        const hours = parseInt(parts[0]);
        const minutes = parseInt(parts[1]);
        const seconds = parseInt(secondsParts[0]);
        const ms = secondsParts[1] ? parseInt(secondsParts[1]) : 0;

        return (hours * 3600) + (minutes * 60) + seconds + (ms / 1000);
    },

    handleKeydown(e) {
        // Ctrl+S to save
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            this.save();
        }
        // Space to toggle play/pause (if not in textarea)
        if (e.code === 'Space' && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'INPUT') {
            e.preventDefault();
            if (this.videoElement) {
                if (this.videoElement.paused) this.videoElement.play();
                else this.videoElement.pause();
            }
        }
    }
};

// Make global
window.TranslationStudioPage = TranslationStudioPage;
