
if (typeof BlogStudioPage === 'undefined') {
    window.BlogStudioPage = {
        init() {
            this.render();
        },
        initInContainer(container) {
            this.isIntegrated = true;
            this.render(container);
        },
        render(targetContainer = null) {
            // 1. Security Check
            if (!State.currentUser) {
                Toast.warning('Blog stüdyosuna erişmek için giriş yapmalısınız!');
                if (window.Auth) Auth.showLogin();
                return;
            }

            const allowedRoles = ['admin', 'moderator', 'blogger', 'writer'];
            const userBadges = State.currentUser.badges || [];
            const hasPermission = allowedRoles.includes(State.currentUser.role) ||
                userBadges.some(b => ['Yönetici', 'Yazar', 'Editör'].includes(b));

            if (!hasPermission) {
                Toast.error('Bu alana erişim yetkiniz yok!');
                window.location.hash = '#/ana-sayfa';
                return;
            }

            // 2. Setup Full-Screen Container (Standalone Mode)
            if (!targetContainer) {
                // Hide Main App Elements
                const navbar = document.getElementById('main-navbar');
                const appContainer = document.getElementById('app-container');
                if (navbar) navbar.style.display = 'none';
                if (appContainer) appContainer.style.display = 'none';

                // Create or Get Studio Root
                let container = document.getElementById('blog-studio-root');
                if (!container) {
                    container = document.createElement('div');
                    container.id = 'blog-studio-root';
                    container.style.cssText = 'position: fixed; inset: 0; width: 100vw; height: 100vh; z-index: 999999; background: #0f1115; overflow: hidden;';
                    document.body.appendChild(container);
                }
                container.style.display = 'block'; // Ensure it's visible if it was hidden

                this.renderContent(container, false); // false = not integrated (full page)
            } else {
                // Integrated Mode (e.g. inside another panel)
                this.isIntegrated = true;
                this.renderContent(targetContainer, true);
            }
        },

        close() {
            const container = document.getElementById('blog-studio-root');
            if (container) {
                container.remove(); // Or container.style.display = 'none';
            }

            // Restore Main App
            const navbar = document.getElementById('main-navbar');
            const appContainer = document.getElementById('app-container');
            if (navbar) navbar.style.display = 'flex'; // Assuming flex, or block
            if (appContainer) appContainer.style.display = 'block';

            window.location.hash = '#/ana-sayfa';
        },

        renderContent(container, isIntegrated) {
            container.innerHTML = `
                <div class="bs-layout ${isIntegrated ? 'bs-integrated' : ''}">
                    <!-- SIDEBAR -->
                    <aside class="bs-sidebar">
                        <div class="bs-brand">
                            <div class="bs-logo-icon"><i class="fa-solid fa-pen-nib"></i></div>
                            <span class="bs-brand-text">Blog Studio</span>
                        </div>
                        <nav class="bs-nav">
                            <button class="bs-nav-item active" onclick="BlogStudioPage.switchTab('dashboard', this)">
                                <i class="fa-solid fa-chart-line"></i> <span>Genel Bakış</span>
                            </button>
                            <div class="bs-nav-label">İÇERİK</div>
                            <button class="bs-nav-item" onclick="BlogStudioPage.switchTab('posts', this)">
                                <i class="fa-solid fa-layer-group"></i> <span>Yazılarım</span>
                            </button>
                            <button class="bs-nav-item" onclick="BlogStudioPage.switchTab('editor', this)">
                                <i class="fa-solid fa-plus-circle"></i> <span>Yeni Yazı</span>
                            </button>
                             <button class="bs-nav-item" onclick="BlogStudioPage.switchTab('drafts', this)">
                                <i class="fa-solid fa-file-pen"></i> <span>Taslaklar</span>
                            </button>
                            
                            ${(State.currentUser.role === 'admin' || (State.currentUser.badges && State.currentUser.badges.includes('Yönetici'))) ? `
                            <div class="bs-nav-label">YÖNETİM</div>
                            <button class="bs-nav-item" onclick="BlogStudioPage.switchTab('moderation', this)">
                                <i class="fa-solid fa-gavel"></i> <span>Moderasyon</span> <span id="mod-badge" class="bs-badge" style="display:none;">0</span>
                            </button>
                            <button class="bs-nav-item" onclick="BlogStudioPage.switchTab('categories', this)">
                                <i class="fa-solid fa-folder-tree"></i> <span>Kategoriler</span>
                            </button>
                            ` : ''}
                        </nav>
                        ${!isIntegrated ? `
                        <div class="bs-sidebar-footer">
                            <button class="bs-nav-item" onclick="BlogStudioPage.close()">
                                <i class="fa-solid fa-arrow-left"></i> <span>Siteye Dön</span>
                            </button>
                        </div>
                        ` : ''}
                    </aside>
                    
                    <!-- MAIN CONTENT -->
                    <main class="bs-main">
                        <header class="bs-header">
                            <h2 id="bs-page-title">Genel Bakış</h2>
                            <div class="bs-user-profile">
                                <img src="${State.currentUser.avatar || 'assets/logo.png'}" class="bs-avatar">
                                <span class="bs-username">${State.currentUser.username}</span>
                            </div>
                        </header>
                        <div class="bs-content-area" id="blog-studio-content">
                            <!-- Dynamic Content -->
                        </div>
                    </main>
                </div>
            `;

            // Inject styles if not present
            if (!document.getElementById('studio-styles')) {
                const style = document.createElement('style');
                style.id = 'studio-styles';
                style.textContent = `
                    /* variables */
                    :root {
                        --bs-bg: #0f0f12;
                        --bs-sidebar: #161618;
                        --bs-border: #27272a;
                        --bs-accent: #8b5cf6;
                        --bs-text: #e2e8f0;
                        --bs-text-muted: #94a3b8;
                    }

                    .bs-layout { display: flex; height: 100vh; background: var(--bs-bg); color: var(--bs-text); font-family: 'Inter', sans-serif; overflow: hidden; }
                    .bs-integrated { height: 700px; border-radius: 12px; border: 1px solid var(--bs-border); }

                    /* SIDEBAR */
                    .bs-sidebar { width: 260px; background: var(--bs-sidebar); border-right: 1px solid var(--bs-border); display: flex; flex-direction: column; padding: 20px 0; flex-shrink: 0; }
                    
                    .bs-brand { padding: 0 24px 24px; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid var(--bs-border); margin-bottom: 20px; }
                    .bs-logo-icon { width: 36px; height: 36px; background: var(--bs-accent); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; color: white; }
                    .bs-brand-text { font-size: 1.2rem; font-weight: 700; background: linear-gradient(to right, #fff, #aaa); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }

                    .bs-nav { flex: 1; display: flex; flex-direction: column; gap: 4px; padding: 0 12px; overflow-y: auto; }
                    .bs-nav-label { font-size: 0.75rem; color: #555; font-weight: 700; padding: 16px 12px 6px; letter-spacing: 0.5px; }

                    .bs-nav-item {
                        display: flex; align-items: center; gap: 12px; padding: 12px;
                        background: transparent; border: none; border-radius: 8px;
                        color: var(--bs-text-muted); font-size: 0.95rem; font-weight: 500;
                        cursor: pointer; transition: all 0.2s; text-align: left;
                    }
                    .bs-nav-item:hover { background: rgba(255,255,255,0.03); color: var(--bs-text); }
                    .bs-nav-item.active { background: rgba(139, 92, 246, 0.1); color: var(--bs-accent); }
                    .bs-nav-item i { width: 20px; text-align: center; }

                    .bs-sidebar-footer { padding: 12px; border-top: 1px solid var(--bs-border); margin-top: auto; }

                    .bs-badge { background: #ef4444; color: white; padding: 2px 6px; border-radius: 10px; font-size: 0.7rem; margin-left: auto; }

                    /* MAIN */
                    .bs-main { flex: 1; display: flex; flex-direction: column; background: var(--bs-bg); position: relative; overflow: hidden; }
                    
                    .bs-header { height: 70px; border-bottom: 1px solid var(--bs-border); padding: 0 30px; display: flex; align-items: center; justify-content: space-between; background: rgba(22, 22, 24, 0.8); backdrop-filter: blur(10px); z-index: 10; sticky; top: 0; }
                    .bs-header h2 { font-size: 1.2rem; font-weight: 600; margin: 0; }

                    .bs-user-profile { display: flex; align-items: center; gap: 10px; padding: 6px 12px; background: rgba(255,255,255,0.03); border-radius: 20px; border: 1px solid var(--bs-border); }
                    .bs-avatar { width: 28px; height: 28px; border-radius: 50%; object-fit: cover; }
                    .bs-username { font-size: 0.9rem; font-weight: 500; }

                    .bs-content-area { flex: 1; padding: 30px; overflow-y: auto; }

                    /* CARDS used in dashboard/posts */
                    .bs-card { background: var(--bs-sidebar); border: 1px solid var(--bs-border); border-radius: 16px; padding: 24px; }
                    .bs-card:hover { border-color: #3f3f46; box-shadow: 0 10px 30px rgba(0,0,0,0.3); }

                    .bs-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
                    .bs-stat-label { color: var(--bs-text-muted); font-size: 0.9rem; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
                    .bs-stat-val { font-size: 2rem; font-weight: 700; color: white; }

                    .bs-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
                    .bs-post-card { background: var(--bs-sidebar); border-radius: 12px; overflow: hidden; border: 1px solid var(--bs-border); transition: transform 0.2s; cursor: pointer; display: flex; flex-direction: column; }
                    .bs-post-card:hover { transform: translateY(-4px); border-color: var(--bs-accent); }
                    .bs-post-cover { height: 160px; background: #333; position: relative; }
                    .bs-post-cover img { width: 100%; height: 100%; object-fit: cover; }
                    .bs-post-body { padding: 15px; flex: 1; display: flex; flex-direction: column; }
                    .bs-post-title { font-weight: 600; margin-bottom: 8px; font-size: 1.1rem; line-height: 1.4; }
                    .bs-post-meta { font-size: 0.8rem; color: var(--bs-text-muted); margin-bottom: 12px; display: flex; justify-content: space-between; }
                    .bs-post-status { position: absolute; top: 10px; right: 10px; padding: 4px 10px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; backdrop-filter: blur(4px); }
                    .status-published { background: rgba(16, 185, 129, 0.2); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
                    .status-pending { background: rgba(245, 158, 11, 0.2); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.3); }
                    .status-rejected { background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }

                    /* Button Styles */
                    .bs-btn { padding: 8px 16px; border-radius: 8px; border: none; font-weight: 500; cursor: pointer; transition: all 0.2s; display: inline-flex; align-items: center; gap: 8px; }
                    .bs-btn-primary { background: var(--bs-accent); color: white; }
                    .bs-btn-primary:hover { background: #7c3aed; }
                    .bs-btn-outline { background: transparent; border: 1px solid var(--bs-border); color: var(--bs-text); }
                    .bs-btn-outline:hover { border-color: #555; background: rgba(255,255,255,0.05); }

                    /* Form Elements */
                    .bs-input { background: rgba(0,0,0,0.2); border: 1px solid var(--bs-border); padding: 12px; border-radius: 8px; color: white; width: 100%; font-family: inherit; }
                    .bs-input:focus { outline: none; border-color: var(--bs-accent); }
                    .bs-textarea { min-height: 400px; line-height: 1.6; }

                    @media (max-width: 768px) {
                        .bs-layout { flex-direction: column; overflow-y: auto; height: auto; }
                        .bs-sidebar { width: 100%; border-right: none; border-bottom: 1px solid var(--bs-border); }
                        .bs-main { overflow: visible; height: auto; }
                    }
                `;
                document.head.appendChild(style);
            }

            this.switchTab('dashboard');
        },

        switchTab(tab, btn = null) {
            // Highlight active button
            if (btn) {
                document.querySelectorAll('.bs-nav-item').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            } else {
                // Fallback for initial load
                document.querySelectorAll('.bs-nav-item').forEach(b => {
                    if (b.getAttribute('onclick')?.includes(`'${tab}'`)) {
                        b.classList.add('active');
                    } else {
                        b.classList.remove('active');
                    }
                });
            }

            const content = document.getElementById('blog-studio-content');
            if (!content) return;

            if (tab === 'dashboard') this.renderDashboard(content);
            else if (tab === 'posts') this.renderPosts(content);
            else if (tab === 'editor') this.renderEditor(content);
            else if (tab === 'drafts') this.renderDrafts(content);
            else if (tab === 'moderation') this.renderModeration(content);
            else if (tab === 'categories') this.renderCategories(content);
        },

        renderDashboard(container) {
            const posts = (State.data.blogPosts || []).filter(p => p.authorId === State.currentUser.id);
            const totalViews = posts.reduce((sum, p) => sum + (p.views || 0), 0);
            const totalLikes = posts.reduce((sum, p) => sum + (p.likes || 0), 0);

            container.innerHTML = `
                <div class="bs-stat-grid">
                    <div class="bs-card">
                        <div class="bs-stat-label"><i class="fa-solid fa-file-alt"></i> Toplam Yazı</div>
                        <div class="bs-stat-val">${posts.length}</div>
                    </div>
                    <div class="bs-card">
                        <div class="bs-stat-label"><i class="fa-solid fa-eye"></i> Toplam Görüntülenme</div>
                        <div class="bs-stat-val">${totalViews}</div>
                    </div>
                    <div class="bs-card">
                        <div class="bs-stat-label"><i class="fa-solid fa-heart"></i> Toplam Beğeni</div>
                        <div class="bs-stat-val">${totalLikes}</div>
                    </div>
                       <div class="bs-card">
                        <div class="bs-stat-label"><i class="fa-solid fa-star"></i> Ortalama Puan</div>
                        <div class="bs-stat-val">4.8</div>
                    </div>
                </div>

                <h3 style="margin-bottom: 20px;">Son Yazılar</h3>
                 <div class="bs-grid">
                    ${posts.slice(0, 3).map(p => `
                        <div class="bs-post-card" onclick="BlogStudioPage.editPost('${p.id}')">
                            <div class="bs-post-cover">
                                <img src="${p.coverImage || 'img/no-poster.jpg'}" alt="${p.title}">
                                <div class="bs-post-status ${p.approvalStatus === 'published' ? 'status-published' : (p.approvalStatus === 'rejected' ? 'status-rejected' : 'status-pending')}">
                                    ${p.approvalStatus === 'published' ? 'Yayında' : (p.approvalStatus === 'rejected' ? 'Reddedildi' : 'Onay Bekliyor')}
                                </div>
                            </div>
                            <div class="bs-post-body">
                                <div class="bs-post-title">${p.title}</div>
                                <div class="bs-post-meta">
                                    <span>${p.category || 'Genel'}</span>
                                    <span>${new Date(p.createdAt).toLocaleDateString('tr-TR')}</span>
                                </div>
                                <div style="margin-top: auto; display:flex; gap:10px;">
                                    <span style="font-size:0.8rem; color:#888;"><i class="fa-solid fa-eye"></i> ${p.views || 0}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                 </div>
            `;
        },

        renderPosts(container) {
            const posts = (State.data.blogPosts || []).filter(p => p.authorId === State.currentUser.id);

            container.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <h2>Yazılarım</h2>
                    <div style="position: relative;">
                        <input type="text" placeholder="Ara..." class="form-input" style="padding-left: 35px; width: 250px;">
                        <i class="fa-solid fa-search" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-secondary);"></i>
                    </div>
                </div>

    <div class="blog-grid">
        ${posts.length > 0 ? posts.map(p => `
                        <div class="blog-card">
                            <div class="blog-cover" style="height: 160px;">
                                <img src="${p.coverImage || 'img/no-poster.jpg'}" alt="${p.title}">
                                <div style="position: absolute; top: 10px; left: 10px; padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: bold; background: rgba(0,0,0,0.7); color: white;" class="${p.approvalStatus === 'published' ? 'status-published' : (p.approvalStatus === 'rejected' ? 'status-draft' : 'status-pending')}">
                                        ${p.approvalStatus === 'published' ? 'Yayında' : (p.approvalStatus === 'rejected' ? 'Reddedildi' : 'Onay Bekliyor')}
                                </div>
                            </div>
                            <div class="blog-content">
                                 <div class="blog-title" style="font-size: 1.1rem; margin-bottom: 5px;">${p.title}</div>
                                 <div class="blog-meta" style="margin-bottom: 15px;">
                                    ${new Date(p.createdAt).toLocaleDateString('tr-TR')} • ${p.category}
                                 </div>
                                 <div class="blog-footer">
                                    <button class="btn btn-sm btn-outline" style="flex:1; margin-right:5px;" onclick="BlogStudioPage.editPost('${p.id}')"><i class="fa-solid fa-pen"></i> Düzenle</button>
                                    <button class="btn btn-sm btn-danger-outline" style="width: 40px;" onclick="BlogStudioPage.deletePost('${p.id}')"><i class="fa-solid fa-trash"></i></button>
                                 </div>
                            </div>
                        </div>
                     `).join('') : '<p style="text-align: center; color: var(--text-secondary); padding: 40px; grid-column: 1/-1;">Henüz yazı yok.</p>'}
    </div>
`;
        },

        renderEditor(container, draft = null) {
            container.innerHTML = `
                <div style="max-width: 800px; margin: 0 auto;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h2>${draft ? 'Yazıyı Düzenle' : 'Yeni Yazı Yaz'}</h2>
                        <div style="display: flex; gap: 10px;">
                            <button class="btn btn-outline" onclick="BlogStudioPage.saveDraft()">Taslak Kaydet</button>
                            <button class="btn btn-primary" onclick="BlogStudioPage.publishBlog()">Yayınla</button>
                        </div>
                    </div>

                    <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                        <div style="flex: 2;">
                            <input type="text" id="blog-title" class="form-input" placeholder="Yazı Başlığı" style="font-size: 1.5rem; font-weight: bold; padding: 15px;" value="${draft ? draft.title : ''}">
                        </div>
                        <div style="flex: 1;">
                             <select id="blog-category" class="form-input" style="height: 100%;">
                                <option value="news">Haber</option>
                                <option value="review">İnceleme</option>
                                <option value="theory">Teori</option>
                                <option value="guide">Rehber</option>
                            </select>
                        </div>
                    </div>

                    <div style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: 8px; margin-bottom: 20px;">
                        <div style="padding: 10px; border-bottom: 1px solid var(--border-color); display: flex; gap: 5px;">
                            <button class="btn btn-xs btn-text" onclick="BlogStudioPage.formatText('bold')"><i class="fa-solid fa-bold"></i></button>
                            <button class="btn btn-xs btn-text" onclick="BlogStudioPage.formatText('italic')"><i class="fa-solid fa-italic"></i></button>
                            <button class="btn btn-xs btn-text" onclick="BlogStudioPage.insertLink()"><i class="fa-solid fa-link"></i></button>
                            <button class="btn btn-xs btn-text" onclick="BlogStudioPage.insertImage()"><i class="fa-solid fa-image"></i></button>
                            <button class="btn btn-xs btn-text" onclick="BlogStudioPage.insertVideo()"><i class="fa-solid fa-video"></i></button>
                        </div>
                        <textarea id="blog-content" style="width: 100%; height: 400px; background: none; border: none; color: white; padding: 15px; resize: vertical; outline: none;" placeholder="Hikayeni anlat...">${draft ? draft.content : ''}</textarea>
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 5px; color: var(--text-secondary);">Etiketler</label>
                        <input type="text" id="blog-tags" class="form-input" placeholder="Virgülle ayırın (örn: kore, dizi, netflix)" value="${draft ? (draft.tags || '') : ''}">
                    </div>

                   <div style="margin-top: 20px;">
                        <label style="display: block; margin-bottom: 10px; font-weight: bold;">Kapak Görseli</label>
                        <div style="border: 2px dashed var(--border-color); border-radius: 8px; padding: 30px; text-align: center; cursor: pointer; position: relative; overflow: hidden;" onclick="document.getElementById('blog-cover').click()">
                            <input type="file" id="blog-cover" style="display: none;" accept="image/*" onchange="BlogStudioPage.handleImageUpload(event, 'cover')">
                            
                            <div class="upload-placeholder" style="${draft && draft.coverImage ? 'display: none;' : ''}">
                                <i class="fa-solid fa-cloud-upload-alt" style="font-size: 2rem; color: var(--text-secondary); margin-bottom: 10px;"></i>
                                <p style="color: var(--text-secondary);">Görsel seçmek için tıklayın veya sürükleyin</p>
                            </div>
                            
                            <div id="cover-preview" style="display: ${draft && draft.coverImage ? 'block' : 'none'}; position: relative;">
                                <img id="cover-preview-img" src="${draft ? draft.coverImage : ''}" style="max-height: 200px; border-radius: 4px;">
                                <button class="btn btn-danger btn-sm" style="position: absolute; top: 10px; right: 10px;" onclick="event.stopPropagation(); BlogStudioPage.removeCoverImage()">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
    `;

            // Re-attach live preview listener if I want it, or just use simpler editor
            // If I want to reuse BlogEditor logic, I should ensure it talks to these new DOM IDs.
            // Luckily IDs matched (blog-title, blog-content).

            // Setup listeners manually since we just rendered
            const titleInput = document.getElementById('blog-title');
            const contentInput = document.getElementById('blog-content');

            if (draft) {
                this.currentCoverImage = draft.coverImage;
            }
        },

        renderDrafts(container) {
            const saved = localStorage.getItem('blog_draft');

            container.innerHTML = `
                <h2>Taslaklar</h2>
        <div class="post-list" style="margin-top: 20px;">
            ${saved ? (() => {
                    const d = JSON.parse(saved);
                    return `
                         <div class="post-item">
                            <div style="display: flex; gap: 15px; align-items: center;">
                                <div style="width: 60px; height: 40px; background: #333; border-radius: 4px; display: flex; align-items: center; justify-content: center;">
                                    <i class="fa-solid fa-file-pen" style="color: #666;"></i>
                                </div>
                                <div>
                                    <div style="font-weight: bold;">${d.title || '(Başlıksız)'}</div>
                                    <span class="post-status status-draft">Taslak</span>
                                </div>
                            </div>
                            <div style="display: flex; gap: 10px;">
                                <button class="btn btn-sm btn-primary" onclick="BlogStudioPage.editDraft()">Devam Et</button>
                                <button class="btn btn-sm btn-danger" onclick="localStorage.removeItem('blog_draft'); BlogStudioPage.renderDrafts(document.getElementById('blog-studio-content'))"><i class="fa-solid fa-trash"></i></button>
                            </div>
                        </div>
                        `;
                })() : '<p style="text-align: center; color: var(--text-secondary); padding: 40px;">Kayıtlı taslak yok.</p>'}
        </div>
`;
        },

        renderModeration(container) {
            const pendingPosts = (State.data.blogPosts || []).filter(p => p.approvalStatus === 'pending');

            container.innerHTML = `
                <h2>Moderasyon Bekleyen Yazılar</h2>
                <p style="color:var(--text-secondary); margin-bottom:20px;">Onay bekleyen ${pendingPosts.length} yazı var.</p>

                <div class="post-list">
                    ${pendingPosts.length > 0 ? pendingPosts.map(p => `
                        <div class="post-item" style="flex-direction:column; align-items:flex-start; gap:15px;">
                            <div style="display: flex; gap: 15px; align-items: center; width:100%;">
                                <img src="${p.coverImage || 'img/no-poster.jpg'}" style="width: 80px; height: 50px; object-fit: cover; border-radius: 4px;">
                                <div style="flex:1;">
                                    <div style="font-weight: bold;">${p.title}</div>
                                    <div style="font-size:0.8rem; color:var(--text-secondary);">
                                        Yazar: ${p.authorName} • Tarih: ${new Date(p.createdAt).toLocaleDateString('tr-TR')}
                                    </div>
                                </div>
                                 <div style="display: flex; gap: 10px;">
                                    <button class="btn btn-sm btn-outline" onclick="BlogStudioPage.previewPost('${p.id}')"><i class="fa-solid fa-eye"></i> İncele</button>
                                </div>
                            </div>
                            
                            <!-- Review Actions -->
                            <div id="review-panel-${p.id}" style="display:none; width:100%; background:rgba(0,0,0,0.2); padding:15px; border-radius:8px;">
                                <div style="max-height:300px; overflow-y:auto; margin-bottom:15px; background:#111; padding:10px; border-radius:4px;">
                                    <h4 style="margin-bottom:10px;">${p.title}</h4>
                                    <div style="font-size:0.9rem; line-height:1.6;">${p.content}</div>
                                </div>
                                <div style="display:flex; gap:10px; justify-content:flex-end;">
                                    <button class="btn btn-sm btn-danger" onclick="BlogStudioPage.updateStatus('${p.id}', 'rejected')">Reddet</button>
                                    <button class="btn btn-sm btn-success" style="background:#10b981; color:white;" onclick="BlogStudioPage.updateStatus('${p.id}', 'published')">Onayla ve Yayınla</button>
                                </div>
                            </div>
                        </div>
                     `).join('') : '<p style="text-align: center; color: var(--text-secondary); padding: 40px;">Onay bekleyen yazı yok.</p>'}
                </div>
`;
        },

        renderCategories(container) {
            // Initialize categories in State if not present
            if (!State.data.blogCategories) {
                State.data.blogCategories = [
                    { id: 'news', name: 'Haber', icon: 'fa-newspaper' },
                    { id: 'review', name: 'İnceleme', icon: 'fa-star' },
                    { id: 'theory', name: 'Teori', icon: 'fa-lightbulb' },
                    { id: 'guide', name: 'Rehber', icon: 'fa-book' },
                    { id: 'general', name: 'Genel', icon: 'fa-globe' }
                ];
            }

            const categories = State.data.blogCategories;

            container.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <div>
                        <h2>Kategori Yönetimi</h2>
                        <p style="color: var(--text-secondary); margin-top: 5px;">Blog yazıları için kategoriler</p>
                    </div>
                    <button class="btn btn-primary" onclick="BlogStudioPage.showAddCategoryModal()">
                        <i class="fa-solid fa-plus"></i> Yeni Kategori
                    </button>
                </div>

                <div class="categories-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px;">
                    ${categories.map(cat => `
                        <div class="category-card" style="background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: 12px; padding: 20px; display: flex; align-items: center; gap: 15px;">
                            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #7c3aed, #a78bfa); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                                <i class="fa-solid ${cat.icon || 'fa-folder'}" style="color: white; font-size: 1.2rem;"></i>
                            </div>
                            <div style="flex: 1;">
                                <div style="font-weight: 600; font-size: 1.1rem;">${cat.name}</div>
                                <div style="color: var(--text-secondary); font-size: 0.85rem;">ID: ${cat.id}</div>
                            </div>
                            <button class="btn btn-sm btn-danger-outline" onclick="BlogStudioPage.deleteCategory('${cat.id}')" title="Sil">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    `).join('')}
                </div>
            `;
        },

        showAddCategoryModal() {
            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.style.display = 'flex';
            modal.innerHTML = `
                <div class="modal-content" style="max-width: 400px;">
                    <div class="modal-header">
                        <h3>Yeni Kategori Ekle</h3>
                        <button class="modal-close" onclick="this.closest('.modal').remove()">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; font-weight: 500;">Kategori Adı</label>
                            <input type="text" id="new-cat-name" class="form-input" placeholder="örn: Müzik">
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; font-weight: 500;">Kategori ID</label>
                            <input type="text" id="new-cat-id" class="form-input" placeholder="örn: music (küçük harf, tire kullanın)">
                        </div>
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 5px; font-weight: 500;">İkon (FontAwesome)</label>
                            <input type="text" id="new-cat-icon" class="form-input" placeholder="örn: fa-music" value="fa-folder">
                        </div>
                        <button class="btn btn-primary" style="width: 100%;" onclick="BlogStudioPage.addCategory()">Kategori Ekle</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        },

        async addCategory() {
            const name = document.getElementById('new-cat-name').value.trim();
            const id = document.getElementById('new-cat-id').value.trim().toLowerCase().replace(/\s+/g, '-');
            const icon = document.getElementById('new-cat-icon').value.trim() || 'fa-folder';

            if (!name || !id) {
                Toast.warning('Kategori adı ve ID gerekli!');
                return;
            }

            if (!State.data.blogCategories) State.data.blogCategories = [];

            if (State.data.blogCategories.some(c => c.id === id)) {
                Toast.error('Bu ID zaten mevcut!');
                return;
            }

            State.data.blogCategories.push({ id, name, icon });

            if (window.db && db.save) await db.save();

            Toast.success('Kategori eklendi!');
            document.querySelector('.modal')?.remove();
            this.renderCategories(document.getElementById('blog-studio-content'));
        },

        async deleteCategory(id) {
            if (!confirm('Bu kategoriyi silmek istediğinize emin misiniz?')) return;

            if (!State.data.blogCategories) return;

            State.data.blogCategories = State.data.blogCategories.filter(c => c.id !== id);

            if (window.db && db.save) await db.save();

            Toast.success('Kategori silindi!');
            this.renderCategories(document.getElementById('blog-studio-content'));
        },

        previewPost(id) {
            const panel = document.getElementById(`review-panel-${id}`);
            if (panel) {
                panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
            }
        },

        updateStatus(id, status) {
            if (!confirm(status === 'published' ? 'Yazıyı yayınlamak istiyor musunuz?' : 'Yazıyı reddetmek istiyor musunuz?')) return;

            fetch('api/db.php?action=blog-update-status', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ postId: id, status: status })
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        // Update local state
                        const post = State.data.blogPosts.find(p => p.id === id);
                        if (post) post.approvalStatus = status;

                        Toast.success('İşlem başarılı!');
                        this.renderModeration(document.getElementById('blog-studio-content'));
                    } else {
                        Toast.error('Hata: ' + data.message);
                    }
                })
                .catch(e => {
                    console.error(e);
                    Toast.error('Sunucu hatası');
                });

        },

        editPost(id) {
            const post = (State.data.blogPosts || []).find(p => p.id === id);
            this.switchTab('editor'); // Switch tab first to render container

            // Using setTimeout to wait for render (dirty but effective given simple tab logic)
            setTimeout(() => {
                this.renderEditor(document.getElementById('blog-studio-content'), post);
            }, 50);
        },

        editDraft() {
            this.switchTab('editor');
            setTimeout(() => {
                const saved = localStorage.getItem('blog_draft');
                if (saved) {
                    const draft = JSON.parse(saved);
                    this.renderEditor(document.getElementById('blog-studio-content'), draft);
                }
            }, 50);
        },

        // --- EDITOR ACTIONS ---

        handleImageUpload(event, type) {
            const file = event.target.files[0];
            if (!file) return;

            if (file.size > 5 * 1024 * 1024) {
                Toast.error("Görsel boyutu 5MB'dan küçük olmalıdır!");
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                if (type === 'cover') {
                    this.currentCoverImage = e.target.result;
                    const ph = document.querySelector('.upload-placeholder');
                    const cp = document.getElementById('cover-preview');
                    const cpi = document.getElementById('cover-preview-img');

                    if (ph) ph.style.display = 'none';
                    if (cp) cp.style.display = 'block';
                    if (cpi) cpi.src = e.target.result;

                    Toast.success("Kapak görseli yüklendi!");
                }
            };
            reader.readAsDataURL(file);
        },

        removeCoverImage() {
            this.currentCoverImage = null;
            const ph = document.querySelector('.upload-placeholder');
            const cp = document.getElementById('cover-preview');
            const fileIn = document.getElementById('blog-cover');

            if (ph) ph.style.display = 'block';
            if (cp) cp.style.display = 'none';
            if (fileIn) fileIn.value = '';
        },

        formatText(command) {
            const textarea = document.getElementById('blog-content');
            if (!textarea) return;
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const selectedText = textarea.value.substring(start, end);

            if (!selectedText) {
                Toast.warning("Lütfen biçimlendirmek için metin seçin!");
                return;
            }

            let formattedText = selectedText;
            switch (command) {
                case 'bold': formattedText = `**${selectedText}**`; break;
                case 'italic': formattedText = `*${selectedText}*`; break;
            }

            textarea.value = textarea.value.substring(0, start) + formattedText + textarea.value.substring(end);
        },

        insertLink() {
            const url = prompt("Link URL'si (https://...):");
            if (url) {
                const text = prompt("Görüntülenecek metin:") || url;
                const textarea = document.getElementById('blog-content');
                const cursorPos = textarea.selectionStart;
                const linkMarkdown = `[${text}](${url})`;
                textarea.value = textarea.value.substring(0, cursorPos) + linkMarkdown + textarea.value.substring(cursorPos);
            }
        },

        insertImage() {
            const url = prompt("Görsel URL'si (https://...):");
            if (url) {
                const textarea = document.getElementById('blog-content');
                const cursorPos = textarea.selectionStart;
                const imgMarkdown = `\n![Görsel](${url})\n`;
                textarea.value = textarea.value.substring(0, cursorPos) + imgMarkdown + textarea.value.substring(cursorPos);
            }
        },

        insertVideo() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'video/mp4,video/webm';
            input.style.display = 'none';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;
                // Mock upload or real upload if db.php supports
                // For now just simulated or use existing upload logic
                Toast.info("Video yükleme simüle ediliyor...");
            };
            document.body.appendChild(input);
            input.click();
            setTimeout(() => input.remove(), 1000);
        },

        saveDraft() {
            const title = document.getElementById('blog-title').value;
            const content = document.getElementById('blog-content').value;
            const category = document.getElementById('blog-category').value;
            const tags = document.getElementById('blog-tags').value;

            const draft = {
                title, content, category, tags,
                coverImage: this.currentCoverImage,
                savedAt: Date.now()
            };

            localStorage.setItem('blog_draft', JSON.stringify(draft));
            Toast.success("Taslak kaydedildi!");
        },

        publishBlog() {
            const title = document.getElementById('blog-title').value;
            const content = document.getElementById('blog-content').value;
            const category = document.getElementById('blog-category').value;
            const tags = document.getElementById('blog-tags').value;

            if (!title || !content) {
                Toast.warning("Başlık ve içerik gereklidir!");
                return;
            }

            if (content.length < 50) {
                Toast.warning("İçerik çok kısa!");
                return;
            }

            // Ensure BlogSystem exists/loaded
            if (window.BlogSystem && BlogSystem.createPost) {
                BlogSystem.createPost(title, content, category, this.currentCoverImage, tags);

                // Clear and switch
                this.currentCoverImage = null;
                localStorage.removeItem('blog_draft');
                this.switchTab('posts');
            } else {
                Toast.error("Blog sistemi yüklenemedi.");
            }
        },

        deletePost(id) {
            if (!confirm('Bu yazıyı silmek istediğine emin misin?')) return;

            // Optimistic UI Update
            if (State.data.blogPosts) {
                State.data.blogPosts = State.data.blogPosts.filter(p => p.id !== id);
            }

            // Persist via DB if needed (or just let next load handle it, but better to save)
            // Since we don't have a specific delete endpoint yet, we might need one or rely on 'write' 
            // But for now, let's assume we need to implement delete properly or just use local state update + save.
            // Actually, db.php doesn't have blog-delete yet, I should probably add it or relying on save() might overwrite whole State.data. So:
            if (window.db && window.db.save) window.db.save();

            Toast.success('Yazı silindi.');
            this.renderPosts(document.getElementById('blog-studio-content'));
        }
    };
}
