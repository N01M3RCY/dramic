// ============================================
// BLOG EDITOR - Professional Blog Writing
// ============================================

const BlogEditor = {
    currentCoverImage: null,
    currentDraft: null,

    showEditor() {
        if (!BlogSystem.canCreatePost()) {
            Toast.error("Blog yazabilmek için 'Blogger' rozetine sahip olmalısınız!");
            return;
        }

        // Show Modal instead of switching view
        const modal = document.getElementById('blog-editor-modal');
        if (modal) {
            modal.style.display = 'flex';
            this.setupLivePreview();
        }
    },

    hideEditor() {
        // Hide Modal
        const modal = document.getElementById('blog-editor-modal');
        if (modal) modal.style.display = 'none';

        this.clearEditor();
    },

    setupLivePreview() {
        const titleInput = document.getElementById('blog-title');
        const contentInput = document.getElementById('blog-content');

        titleInput.addEventListener('input', () => this.updatePreview());
        contentInput.addEventListener('input', () => this.updatePreview());
    },

    updatePreview() {
        const title = document.getElementById('blog-title').value;
        const content = document.getElementById('blog-content').value;
        const preview = document.getElementById('blog-preview');

        if (!title && !content) {
            preview.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 40px;">Yazmaya başladığınızda önizleme burada görünecek...</p>';
            return;
        }

        let html = '';

        if (this.currentCoverImage) {
            html += `<img src="${this.currentCoverImage}" style="width: 100%; border-radius: 8px; margin-bottom: 20px;">`;
        }

        if (title) {
            html += `<h2 style="margin-bottom: 20px;">${this.escapeHtml(title)}</h2>`;
        }

        if (content) {
            html += `<div style="line-height: 1.8; white-space: pre-wrap;">${this.escapeHtml(content)}</div>`;
        }

        preview.innerHTML = html;
    },

    handleImageUpload(event, type) {
        const file = event.target.files[0];
        if (!file) return;

        // Check file size (5MB max)
        if (file.size > 5 * 1024 * 1024) {
            Toast.error("Görsel boyutu 5MB'dan küçük olmalıdır!");
            return;
        }

        // Check file type
        if (!file.type.startsWith('image/')) {
            Toast.error("Sadece görsel dosyaları yükleyebilirsiniz!");
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            if (type === 'cover') {
                this.currentCoverImage = e.target.result;
                document.querySelector('.upload-placeholder').style.display = 'none';
                document.getElementById('cover-preview').style.display = 'block';
                document.getElementById('cover-preview-img').src = e.target.result;
                this.updatePreview();
                Toast.success("Kapak görseli yüklendi!");
            }
        };
        reader.readAsDataURL(file);
    },

    removeCoverImage() {
        this.currentCoverImage = null;

        const placeholder = document.querySelector('.upload-placeholder');
        if (placeholder) placeholder.style.display = 'block';

        const preview = document.getElementById('cover-preview');
        if (preview) preview.style.display = 'none';

        const input = document.getElementById('blog-cover');
        if (input) input.value = '';

        this.updatePreview();
        Toast.info("Kapak görseli kaldırıldı");
    },

    formatText(command) {
        const textarea = document.getElementById('blog-content');
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selectedText = textarea.value.substring(start, end);

        if (!selectedText) {
            Toast.warning("Lütfen biçimlendirmek için metin seçin!");
            return;
        }

        let formattedText = selectedText;
        switch (command) {
            case 'bold':
                formattedText = `**${selectedText}**`;
                break;
            case 'italic':
                formattedText = `*${selectedText}*`;
                break;
            case 'underline':
                formattedText = `__${selectedText}__`;
                break;
        }

        textarea.value = textarea.value.substring(0, start) + formattedText + textarea.value.substring(end);
        this.updatePreview();
    },

    showInputModal(title, placeholder, callback) {
        // Remove existing modal if any
        const existing = document.getElementById('editor-input-modal');
        if (existing) existing.remove();

        const modal = document.createElement('div');
        modal.id = 'editor-input-modal';
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 400px;">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body" style="padding: 20px;">
                    <input type="text" id="editor-modal-input" class="form-input" placeholder="${placeholder}" autocomplete="off">
                    <button id="editor-modal-confirm" class="btn btn-primary btn-block" style="margin-top: 15px;">Ekle</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        const input = document.getElementById('editor-modal-input');
        const confirmBtn = document.getElementById('editor-modal-confirm');

        input.focus();

        const submit = () => {
            const val = input.value.trim();
            if (val) {
                callback(val);
                modal.remove();
            } else {
                Toast.warning('Lütfen bir değer girin.');
            }
        };

        confirmBtn.onclick = submit;
        input.onkeypress = (e) => {
            if (e.key === 'Enter') submit();
        };
    },

    insertImage() {
        this.showInputModal("Görsel Ekle", "Görsel URL'si (https://...)", (url) => {
            const textarea = document.getElementById('blog-content');
            const cursorPos = textarea.selectionStart;
            const imageMarkdown = `\n![Görsel](${url})\n`;

            textarea.value = textarea.value.substring(0, cursorPos) + imageMarkdown + textarea.value.substring(cursorPos);
            this.updatePreview();
            Toast.success("Görsel eklendi!");
        });
    },

    insertLink() {
        this.showInputModal("Link Ekle", "Link URL'si (https://...)", (url) => {
            this.showInputModal("Link Metni", "Görüntülenecek metin", (text) => {
                const textarea = document.getElementById('blog-content');
                const cursorPos = textarea.selectionStart;
                const linkMarkdown = `[${text}](${url})`;

                textarea.value = textarea.value.substring(0, cursorPos) + linkMarkdown + textarea.value.substring(cursorPos);
                this.updatePreview();
                Toast.success("Link eklendi!");
            });
        });
    },

    insertVideo() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'video/mp4,video/webm,video/ogg';
        input.style.display = 'none';

        input.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Size check (2GB)
            if (file.size > 2 * 1024 * 1024 * 1024) {
                Toast.error('Dosya çok büyük! Max 2GB.');
                return;
            }

            const loadingToast = Toast.info('Video yükleniyor...', 0); // persistent

            const formData = new FormData();
            formData.append('videoFile', file);

            fetch('api/db.php?action=upload-video', {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    // Remove loading toast (simulated by overwriting or timeout, assuming Toast returns ID or object to close)
                    // Since basic Toast usually just shows, we'll show success on top.

                    if (data.success) {
                        const textarea = document.getElementById('blog-content');
                        const cursorPos = textarea.selectionStart;
                        // Insert standard HTML5 video tag or simple link
                        const videoMarkdown = `\n<video controls src="${data.url}" width="100%"></video>\n`;

                        textarea.value = textarea.value.substring(0, cursorPos) + videoMarkdown + textarea.value.substring(cursorPos);
                        this.updatePreview();
                        Toast.success("Video başarıyla yüklendi!");
                    } else {
                        Toast.error('Yükleme Hatası: ' + data.message);
                    }
                })
                .catch(err => {
                    console.error(err);
                    Toast.error('Sunucu bağlantı hatası!');
                });
        };

        document.body.appendChild(input);
        input.click();
        document.body.removeChild(input);
    },

    saveDraft() {
        const title = document.getElementById('blog-title').value;
        const content = document.getElementById('blog-content').value;
        const category = document.getElementById('blog-category').value;
        const tags = document.getElementById('blog-tags').value;

        if (!title || !content) {
            Toast.warning("Başlık ve içerik gereklidir!");
            return;
        }

        const draft = {
            title: title,
            content: content,
            category: category,
            tags: tags,
            coverImage: this.currentCoverImage,
            savedAt: Date.now()
        };

        localStorage.setItem('blog_draft', JSON.stringify(draft));
        Toast.success("Taslak kaydedildi!");
    },

    publishBlog() {
        const title = document.getElementById('blog-title').value;
        const content = document.getElementById('blog-content').value;
        const category = document.getElementById('blog-category').value;
        const tags = document.getElementById('blog-tags').value;

        if (!title || !content) {
            Toast.warning("Başlık ve içerik gereklidir!");
            return;
        }

        if (content.length < 100) {
            Toast.warning("İçerik en az 100 karakter olmalıdır!");
            return;
        }

        // Create blog post
        BlogSystem.createPost(title, content, category, this.currentCoverImage, tags);

        // Clear editor and go back
        this.clearEditor();
        this.hideEditor();
        ViewManager.loadBlog();

        Toast.success("Blog yazısı yayınlandı!");
    },

    clearEditor() {
        document.getElementById('blog-title').value = '';
        document.getElementById('blog-content').value = '';
        document.getElementById('blog-category').value = 'news';
        document.getElementById('blog-tags').value = '';
        this.removeCoverImage();
        this.updatePreview();
    },

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    loadDraft() {
        const saved = localStorage.getItem('blog_draft');
        if (!saved) return;

        const draft = JSON.parse(saved);
        document.getElementById('blog-title').value = draft.title;
        document.getElementById('blog-content').value = draft.content;
        document.getElementById('blog-category').value = draft.category;
        document.getElementById('blog-tags').value = draft.tags;

        if (draft.coverImage) {
            this.currentCoverImage = draft.coverImage;
            document.querySelector('.upload-placeholder').style.display = 'none';
            document.getElementById('cover-preview').style.display = 'block';
            document.getElementById('cover-preview-img').src = draft.coverImage;
        }

        this.updatePreview();
        Toast.info("Taslak yüklendi!");
    }
};

// Update BlogSystem to support cover images and tags
const originalCreatePost = BlogSystem.createPost;
BlogSystem.createPost = function (title, content, category, coverImage, tags) {
    if (!State.currentUser) {
        Toast.warning("Blog yazmak için giriş yapmalısınız!");
        return;
    }

    if (!this.canCreatePost()) {
        Toast.error("Blog yazabilmek için 'Blogger' rozetine sahip olmalısınız!");
        return;
    }

    // Determine Initial Status
    const isAdmin = State.currentUser.role === 'admin' || (State.currentUser.badges && State.currentUser.badges.includes('Yönetici'));
    const status = isAdmin ? 'published' : 'pending';

    const post = {
        id: 'post-' + Date.now(),
        authorId: State.currentUser.id,
        authorName: State.currentUser.username,
        title: title,
        content: content,
        category: category,
        coverImage: coverImage || null,
        tags: tags ? tags.split(',').map(t => t.trim()) : [],
        likes: 0,
        comments: [],
        createdAt: Date.now(),
        approvalStatus: status // New Field
    };

    // Save to Server
    fetch('api/db.php?action=blog-save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post: post })
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                // Update Local State directly
                if (!State.data.blogPosts) State.data.blogPosts = [];
                State.data.blogPosts.unshift(post);

                // Also update legacy BlogSystem if present to prevent errors
                if (window.BlogSystem && BlogSystem.posts) {
                    BlogSystem.posts.unshift(post);
                }

                Gamification.addXP(50, "Blog Yazısı");

                if (status === 'pending') {
                    Toast.info("Yazınız onaya gönderildi. İncelendikten sonra yayınlanacaktır.");
                } else {
                    Toast.success("Blog yazısı başarıyla yayınlandı!");
                }
            } else {
                Toast.error("Kaydetme hatası: " + data.message);
            }
        })
        .catch(err => {
            console.error(err);
            Toast.error("Sunucu hatası!");
        });
};

console.log('✅ Blog Editor Loaded!');
window.BlogEditor = BlogEditor;
