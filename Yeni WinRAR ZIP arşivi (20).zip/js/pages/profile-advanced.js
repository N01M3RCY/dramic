const AdvancedProfile = {
    init() {
        console.log('📊 Advanced Profile System initialized');
    },

    async render(userId) {
        const container = document.getElementById('profile-content-container');
        if (!container) return;

        // Reset container style
        container.innerHTML = '<div class="loading-spinner"></div>';

        // Find User
        let user = State.currentUser;
        if (userId) {
            user = (State.data.users || []).find(u => u.id === userId);
        }

        if (!user) {
            if (!userId) { // Intended to view own profile but not logged in
                Toast.warning('Profilinizi görmek için giriş yapmalısınız.');
                App.router('home');
                return;
            }
            container.innerHTML = '<div style="text-align:center; padding:50px;"><h2>Kullanıcı bulunamadı</h2></div>';
            return;
        }

        // Multi-Profile Support: Use selected profile if it's the current user
        let profileData = user;
        if (user.id === (State.currentUser ? State.currentUser.id : null) && window.ProfileGate && ProfileGate.selectedProfile) {
            profileData = {
                ...user,
                username: ProfileGate.selectedProfile.name,
                avatar: ProfileGate.selectedProfile.avatar,
                stats: ProfileGate.selectedProfile.stats || user.stats,
                watchHistory: ProfileGate.selectedProfile.watchHistory || user.watchHistory,
                watchedEpisodes: ProfileGate.selectedProfile.watchedEpisodes || user.watchedEpisodes
            };
        }

        // Calculate Stats
        const watched = profileData.watchedEpisodes || {};
        const seriesIds = Object.keys(watched);
        const totalSeries = seriesIds.length;
        let totalEpisodes = 0;
        seriesIds.forEach(sid => totalEpisodes += (watched[sid] ? watched[sid].length : 0));

        // Determine Theme
        const shopItems = window.ShopSystem?.items || {};
        const themes = shopItems.themes || [];
        const activeThemeId = profileData.activeItems?.theme || 'theme_standard';
        const activeTheme = themes.find(t => t.id === activeThemeId);
        const themeClass = activeTheme ? activeTheme.value : 'theme-standard';

        // Build Layout
        try {
            const html = `
            <div class="container-xl profile-page-container ${themeClass}" style="max-width: 1200px; margin: 0 auto; padding: 20px;">
                <!-- Premium Header -->
                ${this.renderProfileHeader(profileData)}
                
                <!-- Content Grid -->
                <div class="profile-content-grid" style="display: grid; grid-template-columns: 320px 1fr; gap: 30px; margin-top: 30px;">
                    
                    <!-- Left Sidebar: Stats & About -->
                    <div class="profile-sidebar" style="display: flex; flex-direction: column; gap: 20px;">
                         <!-- Stats Card -->
                         <div class="stat-card icon-box">
                            <h3 style="margin-bottom:20px; font-weight: 700; color: #fff; display: flex; align-items: center; gap: 10px;">
                                <i class="fa-solid fa-chart-simple" style="color: var(--p-accent);"></i> İstatistikler
                            </h3>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                                <div class="stat-item-premium">
                                    <div style="font-size:1.8rem; font-weight:800; color:var(--p-accent);">${profileData.stats?.level || 1}</div>
                                    <div style="font-size:0.75rem; color:var(--text-secondary); text-transform: uppercase; letter-spacing: 1px;">Seviye</div>
                                </div>
                                <div class="stat-item-premium">
                                    <div style="font-size:1.8rem; font-weight:800; color:var(--p-accent);">${profileData.stats?.xp || 0}</div>
                                    <div style="font-size:0.75rem; color:var(--text-secondary); text-transform: uppercase; letter-spacing: 1px;">XP</div>
                                </div>
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                <div class="stat-item-premium">
                                    <div style="font-size:1.8rem; font-weight:800; color:#60a5fa;">${totalSeries}</div>
                                    <div style="font-size:0.75rem; color:var(--text-secondary); text-transform: uppercase; letter-spacing: 1px;">Dizi</div>
                                </div>
                                <div class="stat-item-premium">
                                    <div style="font-size:1.8rem; font-weight:800; color:#a78bfa;">${totalEpisodes}</div>
                                    <div style="font-size:0.75rem; color:var(--text-secondary); text-transform: uppercase; letter-spacing: 1px;">Bölüm</div>
                                </div>
                            </div>
                            
                            <!-- DramiCoin Premium Card -->
                            <div style="margin-top: 20px; padding: 20px; background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(234, 88, 12, 0.2)); border-radius: 18px; border: 1px solid rgba(245, 158, 11, 0.3); text-align: center; box-shadow: 0 10px 20px rgba(0,0,0,0.2);">
                                <div style="font-size: 1.8rem; font-weight: 900; color: #fbbf24; text-shadow: 0 0 15px rgba(251, 191, 36, 0.4);">
                                    <i class="fa-solid fa-coins" style="margin-right:10px;"></i>${profileData.stats?.coins || 0}
                                </div>
                                <div style="font-size: 0.8rem; color: #fbbf24; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; margin-top: 5px;">DramiCoin Bakiyesi</div>
                            </div>
                         </div>
                         
                         <!-- Achievements Card -->
                         <div class="stat-card icon-box">
                            <h3 style="margin-bottom:20px; font-weight: 700; color: #fff; display: flex; align-items: center; gap: 10px;">
                                <i class="fa-solid fa-trophy" style="color:#fbbf24;"></i> Başarımlar
                            </h3>
                            <div id="profile-achievements">
                                <!-- Achievements will be rendered here -->
                            </div>
                         </div>
                         
                         <!-- Friends Preview -->
                         ${window.Social ? `<div id="profile-friends-preview"></div>` : ''}
                    </div>

                    <!-- Right Main: Activity, Lists, Comments -->
                    <div class="profile-main-content">
                        <!-- PREMIUM TABS -->
                        <div class="profile-tabs">
                            <button class="btn btn-ghost active" onclick="AdvancedProfile.switchTab(this, 'activity')">Aktivite</button>
                            <button class="btn btn-ghost" onclick="AdvancedProfile.switchTab(this, 'history')">Geçmiş</button>
                            <button class="btn btn-ghost" onclick="AdvancedProfile.switchTab(this, 'lists')">Listeler</button>
                            <button class="btn btn-ghost" onclick="AdvancedProfile.switchTab(this, 'comments')">Yorumlar</button>
                            <button class="btn btn-ghost" onclick="AdvancedProfile.switchTab(this, 'collection')">Koleksiyon</button>
                            <button class="btn btn-ghost" onclick="AdvancedProfile.switchTab(this, 'inventory')">Envanter</button>
                            <button class="btn btn-ghost" onclick="AdvancedProfile.switchTab(this, 'pass')">Dramic Pass</button>
                        </div>
                        
                        <div id="tab-content-activity" class="profile-tab-content">
                            <h3 style="margin-bottom:20px; font-weight: 800;">Son Aktiviteler</h3>
                            <div id="friend-activities">
                                <!-- Loaded via renderProfileContent -->
                            </div>
                        </div>

                        <div id="tab-content-history" class="profile-tab-content" style="display:none;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap: wrap; gap: 15px;">
                                <h3 style="margin:0; font-weight: 800;">İzleme Geçmişi</h3>
                                <div style="display:flex; gap:12px;">
                                    <input type="text" id="history-search" placeholder="Geçmişte ara..." 
                                           style="padding:10px 16px; border-radius:12px; border:1px solid var(--p-glass-border); background:var(--p-glass-bg); color:white; font-size:0.9rem; width: 200px;"
                                           oninput="AdvancedProfile.filterHistory()">
                                    <select id="history-sort" 
                                            style="padding:10px; border-radius:12px; border:1px solid var(--p-glass-border); background:var(--p-glass-bg); color:white; font-size:0.9rem;"
                                            onchange="AdvancedProfile.filterHistory()">
                                        <option value="recent">En Yeni</option>
                                        <option value="oldest">En Eski</option>
                                        <option value="az">A-Z</option>
                                    </select>
                                    ${State.currentUser && State.currentUser.id === user.id ?
                `<button class="btn btn-outline-danger" style="border-radius: 12px;" onclick="AdvancedProfile.clearHistory()"><i class="fa-solid fa-trash"></i></button>`
                : ''}
                                </div>
                            </div>
                            <div id="profile-history-content" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
                                <!-- History cards loaded here -->
                            </div>
                        </div>

                        <div id="tab-content-lists" class="profile-tab-content" style="display:none;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                                <h3>Listeler</h3>
                                ${State.currentUser && State.currentUser.id === user.id ?
                `<button class="btn btn-sm btn-primary" onclick="ListSystem.createList()"><i class="fa-solid fa-plus"></i> Liste Oluştur</button>`
                : ''}
                            </div>
                            <div id="profile-my-lists-content">
                                <!-- Lists loaded here -->
                                <p class="text-muted">Yükleniyor...</p>
                            </div>
                        </div>
                        
                        <div id="tab-content-comments" class="profile-tab-content" style="display:none;">
                            <h3>Son Yorumlar</h3>
                            <p class="text-muted">Henüz yorum yok.</p>
                        </div>

                        <div id="tab-content-collection" class="profile-tab-content" style="display:none;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px;">
                                <h3 style="margin:0;">Kart Koleksiyonu</h3>
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    <div class="collection-filter-toggle" style="display: flex; background: rgba(255,255,255,0.03); padding: 4px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08);">
                                        <button class="btn btn-sm active" id="coll-filter-owned" onclick="AdvancedProfile.switchCollectionFilter('owned')" style="border-radius: 8px; font-size: 0.75rem; padding: 6px 12px; font-weight: 800; background: var(--premium-violet-glow); color: white; border: none; cursor: pointer; transition: all 0.2s;">Sahip Olduklarım</button>
                                        <button class="btn btn-sm" id="coll-filter-all" onclick="AdvancedProfile.switchCollectionFilter('all')" style="border-radius: 8px; font-size: 0.75rem; padding: 6px 12px; font-weight: 800; background: transparent; color: #94a3b8; border: none; cursor: pointer; transition: all 0.2s;">Tümü</button>
                                    </div>
                                    <div style="font-size: 0.9rem; color: var(--accent-color); font-weight: bold;" id="collection-stats-count">0 / 0 Kart</div>
                                </div>
                            </div>
                            <div id="profile-actor-cards-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 20px;">
                                <!-- Actor Cards Loaded Here -->
                            </div>
                        </div>

                        <div id="tab-content-inventory" class="profile-tab-content" style="display:none;"></div>
                        
                        <div id="tab-content-pass" class="profile-tab-content" style="display:none;"></div>

                    </div>
                </div>
            </div>
            
            <style>
                .profile-page-container {
                    padding: 20px;
                }
                @media (max-width: 768px) {
                    .profile-page-container { padding: 10px; }
                    .profile-content-grid { grid-template-columns: 1fr !important; }
                    .profile-sidebar { order: 2; }
                    .profile-main-content { order: 1; }
                    
                    .profile-cover { height: 160px !important; }
                    .profile-info-section { 
                        margin-top: -40px !important; 
                        padding: 15px !important;
                        text-align: center; 
                    }
                    .profile-info-section h1 { 
                        justify-content: center !important; 
                        font-size: 1.5rem !important;
                    }
                    .profile-info-section .social-links { justify-content: center; }
                    
                    @keyframes glitch {
                        0% { transform: translate(0) }
                        20% { transform: translate(-2px, 2px) }
                        40% { transform: translate(-2px, -2px) }
                        60% { transform: translate(2px, 2px) }
                        80% { transform: translate(2px, -2px) }
                        100% { transform: translate(0) }
                    }
                    
                    .profile-avatar-wrapper {
                        margin: 0 auto !important;
                        width: 100px !important;
                        height: 100px !important;
                    }
                    .profile-avatar-wrapper img {
                        width: 100px !important;
                        height: 100px !important;
                    }
                    
                    .profile-actions-grid {
                        display: grid !important;
                        grid-template-columns: 1fr 1fr !important;
                        gap: 8px !important;
                    }
                    .profile-action-btn {
                        padding: 10px !important;
                        font-size: 0.85rem !important;
                        min-width: unset !important;
                    }
                    .profile-tabs {
                        overflow-x: auto;
                        white-space: nowrap;
                        padding-bottom: 5px;
                        -webkit-overflow-scrolling: touch;
                    }
                    .profile-tabs .btn {
                        padding: 8px 12px !important;
                        font-size: 0.85rem !important;
                    }
                }
            </style>
        `;

        container.innerHTML = html;
        this.renderProfileContent(user.id);

        if (window.Social && window.Social.renderFriendsPreview) {
            Social.renderFriendsPreview('profile-friends-preview', user.id);
        }
        } catch (err) {
            console.error('[AdvancedProfile] Render error:', err);
            container.innerHTML = `<div style="text-align:center; padding:50px;">
                <h2>Profil yüklenirken bir hata oluştu</h2>
                <p style="color:var(--text-secondary);">${err.message}</p>
                <button class="btn btn-primary" onclick="AdvancedProfile.render('${userId || ''}')">Tekrar Dene</button>
            </div>`;
        }
    },

    switchTab(btn, tabId) {
        // Simple tab switcher
        btn.parentElement.querySelectorAll('.btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        document.querySelectorAll('.profile-tab-content').forEach(c => c.style.display = 'none');
        const target = document.getElementById('tab-content-' + tabId);
        if (target) target.style.display = 'block';

        const userId = new URLSearchParams(window.location.hash.split('?')[1]).get('userId') || State.currentUser?.id;

        if (tabId === 'collection') {
            this.renderCollection(userId);
        }

        if (tabId === 'history') {
            let profileData = null;
            if (userId === (State.currentUser ? State.currentUser.id : null) && window.ProfileGate) {
                profileData = ProfileGate.selectedProfile;
            }
            this.renderHistory(userId, profileData);
        }

        if (tabId === 'inventory') {
            this.renderInventoryTab(userId);
        }

        if (tabId === 'pass') {
            this.renderPassTab(userId);
        }
    },

    renderHistory(userId, profileData = null) {
        const grid = document.getElementById('profile-history-content');
        if (!grid) return;

        let history = [];
        if (profileData) {
            history = profileData.watchHistory || [];
        } else {
            const targetUser = (State.data.users || []).find(u => u.id === userId) || State.currentUser;
            history = targetUser ? (targetUser.watchHistory || []) : [];
        }
        this.currentHistoryData = history; // Store for filtering

        if (history.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; padding: 60px; background: rgba(255,255,255,0.02); border-radius: 15px; border: 1px dashed rgba(255,255,255,0.1);">
                    <i class="fa-solid fa-clock-rotate-left" style="font-size: 3rem; color: rgba(255,255,255,0.1); margin-bottom: 20px;"></i>
                    <p style="color: var(--text-secondary); font-size: 1.1rem;">Henüz izleme geçmişiniz bulunmuyor.</p>
                    <a href="#/anasayfa" class="btn btn-primary" style="margin-top: 20px;">Keşfetmeye Başla</a>
                </div>
            `;
            return;
        }

        this.filterHistory();
    },

    filterHistory() {
        const grid = document.getElementById('profile-history-content');
        if (!grid || !this.currentHistoryData) return;

        const search = document.getElementById('history-search')?.value.toLowerCase().trim();
        const sort = document.getElementById('history-sort')?.value || 'recent';

        let filtered = [...this.currentHistoryData].map(h => {
            const series = State.data.series.find(s => s.id === h.seriesId);
            return { ...h, series };
        }).filter(h => h.series);

        if (search) {
            filtered = filtered.filter(h => h.series.title.toLowerCase().includes(search));
        }

        // Sorting
        if (sort === 'az') {
            filtered.sort((a, b) => a.series.title.localeCompare(b.series.title));
        } else if (sort === 'oldest') {
            filtered.sort((a, b) => a.timestamp - b.timestamp);
        } else {
            filtered.sort((a, b) => b.timestamp - a.timestamp);
        }

        if (filtered.length === 0) {
            grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #888;">Eşleşen içerik bulunamadı.</div>';
            return;
        }

        grid.innerHTML = filtered.map(h => this.renderHistoryCard(h)).join('');
    },

    renderHistoryCard(h) {
        const s = h.series;
        const isMe = State.currentUser && State.currentUser.id === h.userId; // Assuming userId is in history item or we track viewing own
        // If it's a profile page, we mostly show the history of the user being viewed.
        const canRemove = State.currentUser && State.currentUser.id === (new URLSearchParams(window.location.hash.split('?')[1]).get('userId') || State.currentUser.id);

        return `
            <div class="history-card" style="display: flex; background: var(--p-glass-bg); border-radius: 20px; overflow: hidden; border: 1px solid var(--p-glass-border); transition: all 0.3s ease; position: relative;">
                <div style="width: 110px; height: 150px; flex-shrink: 0; position: relative; overflow: hidden;">
                    <img src="${s.poster || s.coverImage}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;" class="history-poster">
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(transparent, rgba(0,0,0,0.9)); padding: 8px; text-align: center; backdrop-filter: blur(5px);">
                        <span style="font-size: 0.75rem; color: #fbbf24; font-weight: 800; letter-spacing: 0.5px;">
                             EÖ ${h.episodeIndex + 1}
                        </span>
                    </div>
                </div>
                <div style="flex: 1; padding: 20px; display: flex; flex-direction: column; justify-content: space-between;">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px;">
                            <h4 style="margin: 0; font-size: 1.1rem; font-weight: 700; line-height: 1.3; cursor:pointer; color: #fff;" onclick="App.router('detail', '${s.id}')">${s.title}</h4>
                            ${canRemove ? `
                                <button onclick="AdvancedProfile.removeFromHistory('${s.id}', event)" 
                                        style="background: rgba(255,255,255,0.05); border: none; color: #888; cursor: pointer; padding: 6px; border-radius: 8px; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; transition: all 0.2s;" 
                                        onmouseover="this.style.color='#ef4444'; this.style.background='rgba(239, 68, 68, 0.1)';" 
                                        onmouseout="this.style.color='#888'; this.style.background='rgba(255,255,255,0.05)';"
                                        title="Kaldır">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                            ` : ''}
                        </div>
                        <div style="font-size: 0.8rem; color: #888; margin-top: 8px; display: flex; align-items: center; gap: 5px;">
                            <i class="fa-regular fa-clock"></i> ${this.formatTimeRelative(h.timestamp)}
                        </div>
                    </div>
                    <button class="btn btn-sm btn-primary" style="width: fit-content; padding: 8px 16px; font-size: 0.8rem; border-radius: 10px; font-weight: 700; box-shadow: 0 4px 15px var(--p-accent-glow);" 
                            onclick="App.router('player', '${s.id}', ${h.episodeIndex})">
                        <i class="fa-solid fa-play" style="margin-right: 5px;"></i> İzlemeye Devam
                    </button>
                </div>
            </div>
        `;
    },

    formatTimeRelative(ts) {
        if (!ts) return '';
        const now = Date.now();
        const diff = now - ts;
        const mins = Math.floor(diff / 60000);
        const hours = Math.floor(mins / 60);
        const days = Math.floor(hours / 24);

        if (mins < 1) return 'Az önce';
        if (mins < 60) return `${mins} dk önce`;
        if (hours < 24) return `${hours} saat önce`;
        if (days < 30) return `${days} gün önce`;
        return new Date(ts).toLocaleDateString();
    },

    removeFromHistory(seriesId, event) {
        if (event) event.stopPropagation();
        if (!confirm('Bu içeriği geçmişten kaldırmak istiyor musunuz?')) return;

        if (State.currentUser) {
            State.currentUser.watchHistory = (State.currentUser.watchHistory || []).filter(h => h.seriesId !== seriesId);
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            if (window.db && window.db.updateUser) {
                db.updateUser(State.currentUser.id, { watchHistory: State.currentUser.watchHistory });
            }
            Toast.success('Geçmisten kaldırıldı.');
            this.renderHistory(State.currentUser.id);
        }
    },

    clearHistory() {
        if (!confirm('Tüm izleme geçmişinizi temizlemek istediğinize emin misiniz?')) return;

        if (State.currentUser) {
            State.currentUser.watchHistory = [];
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            if (window.db && window.db.updateUser) {
                db.updateUser(State.currentUser.id, { watchHistory: [] });
            }
            Toast.success('Geçmiş temizlendi.');
            this.renderHistory(State.currentUser.id);
        }
    },

    renderCollection(userId) {
        const grid = document.getElementById('profile-actor-cards-grid');
        if (!grid) return;

        const targetUser = (State.data.users || []).find(u => u.id === userId) || State.currentUser;
        if (!targetUser) return;

        const filterMode = this.currentCollectionFilter || 'owned';
        const gamifCards = targetUser.gamification?.cards || [];
        const allCards = (window.Gamification && Gamification.config?.cards) ? Gamification.config.cards : [];
        
        let ownedCards = allCards.filter(c => gamifCards.includes(c.id));
        if (ownedCards.length === 0 && targetUser.actorCards) {
            ownedCards = targetUser.actorCards;
        }

        // Update stats
        const statsEl = document.getElementById('collection-stats-count');
        if (statsEl) statsEl.textContent = `${ownedCards.length} / ${allCards.length || ownedCards.length} Kart`;

        let cardsToRender = filterMode === 'all' ? allCards : ownedCards;

        if (cardsToRender.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; padding: 40px; background: rgba(255,255,255,0.03); border-radius: 12px; border: 1px dashed rgba(255,255,255,0.1);">
                    <i class="fa-solid fa-address-card" style="font-size: 3rem; color: rgba(255,255,255,0.1); margin-bottom: 15px;"></i>
                    <p style="color: var(--text-secondary);">Gösterilebilecek kart yok.</p>
                    <small style="color: var(--text-muted);">Sandıklar açarak veya görevleri tamamlayarak kart koleksiyonunu doldur!</small>
                </div>
            `;
            return;
        }

        const rarityColors = {
            common: '#94a3b8',
            rare: '#3b82f6',
            epic: '#a855f7',
            legendary: '#ffd700'
        };

        grid.innerHTML = cardsToRender.map(card => {
            const isOwned = gamifCards.includes(card.id) || (targetUser.actorCards && targetUser.actorCards.some(c => c.id === card.id || c.actorName === card.name));
            const cardColor = rarityColors[card.rarity || 'common'] || '#94a3b8';
            
            const cardStyles = isOwned
                ? `border: 2px solid ${cardColor}; box-shadow: 0 5px 15px rgba(0,0,0,0.3);`
                : `border: 2px solid rgba(255,255,255,0.05); filter: grayscale(1) opacity(0.5); cursor: not-allowed;`;

            return `
                <div class="actor-collection-card" style="position: relative; aspect-ratio: 2/3; border-radius: 10px; overflow: hidden; background: #000; animation: cardFadeIn 0.5s ease forwards; ${cardStyles}">
                    <img src="${card.avatar || card.image}" style="width: 100%; height: 100%; object-fit: cover;">
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(transparent, rgba(0,0,0,0.95)); padding: 10px 5px; text-align: center; z-index: 2;">
                        <div style="color: ${cardColor}; font-weight: bold; font-size: 0.85rem; line-height: 1.2;">${card.name || card.actorName}</div>
                        <div style="color: #fff; font-size: 0.6rem; text-transform: uppercase; font-weight: 700; opacity: 0.8; margin-top: 3px;">${card.rarity || 'COMMON'}</div>
                    </div>
                    ${!isOwned ? `
                        <div style="position: absolute; inset: 0; background: rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; z-index: 3;">
                            <div style="background: rgba(0,0,0,0.7); width: 44px; height: 44px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 1px solid rgba(255,255,255,0.15);">
                                <i class="fa-solid fa-lock" style="color: #cbd5e1; font-size: 1.1rem;"></i>
                            </div>
                        </div>
                    ` : '<div class="card-shimmer-mini"></div>'}
                </div>
            `;
        }).join('') + `
            <style>
                @keyframes cardFadeIn {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .actor-collection-card:hover { 
                    transform: scale(1.05); 
                    z-index: 10; 
                }
                .card-shimmer-mini {
                    position: absolute;
                    top: 0;
                    left: -150%;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
                    transform: skewX(-20deg);
                    animation: shimmer 5s infinite;
                }
            </style>
        `;
    },

    getTotalActorCount() {
        // Aggregate all unique actors from series
        if (!State.data || !State.data.series) return 0;
        const actors = new Set();
        State.data.series.forEach(s => {
            if (s.characters) {
                s.characters.forEach(c => {
                    const name = c.actor || c.name;
                    if (name) actors.add(name);
                });
            }
        });
        return actors.size;
    },

    showEditAdvancedProfile() {
        const user = State.currentUser;
        if (!user || user.role === 'guest') {
            Toast.warning('Bu özelliği kullanmak için giriş yapmalısınız!');
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2>Gelişmiş Profil Düzenle</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <form onsubmit="AdvancedProfile.saveAdvancedProfile(event)">
                        <!-- Avatar Section -->
                        <div class="form-group">
                            <label>Profil Fotoğrafı</label>
                            <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 5px;">
                                <input type="file" id="edit-avatar-file" accept="image/png, image/jpeg, image/gif" class="form-input" style="padding: 5px;">
                            </div>
                            <small"><a href="#" onclick="document.getElementById('edit-avatar-url-wrapper').style.display='block'; this.style.display='none'; return false;" style="color:var(--accent-color);">URL kullan</a></small>
                            <div id="edit-avatar-url-wrapper" style="display:none; margin-top:5px;">
                                <input type="url" id="edit-avatar-url" class="form-input" value="${user.avatar || ''}" placeholder="https://...">
                            </div>
                        </div>
                        
                        <!-- Cover Section -->
                        <div class="form-group">
                            <label>Kapak Fotoğrafı</label>
                            <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 5px;">
                                <input type="file" id="edit-cover-file" accept="image/png, image/jpeg, image/gif" class="form-input" style="padding: 5px;">
                            </div>
                            <small"><a href="#" onclick="document.getElementById('edit-cover-url-wrapper').style.display='block'; this.style.display='none'; return false;" style="color:var(--accent-color);">URL kullan</a></small>
                            <div id="edit-cover-url-wrapper" style="display:none; margin-top:5px;">
                                <input type="url" id="edit-cover-url" class="form-input" value="${user.coverPhoto || ''}" placeholder="https://...">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Biyografi</label>
                            <textarea id="edit-bio" class="form-input" rows="4" 
                                placeholder="Kendiniz hakkında birkaç şey yazın...">${user.bio || ''}</textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>Ruh Hali</label>
                            <select id="edit-mood" class="form-input">
                                <option value="" ${!user.mood ? 'selected' : ''}>Ruh Hali Seçin...</option>
                                <option value="Mutlu" ${user.mood === 'Mutlu' ? 'selected' : ''}>😊 Mutlu</option>
                                <option value="Heyecanlı" ${user.mood === 'Heyecanlı' ? 'selected' : ''}>🤩 Heyecanlı</option>
                                <option value="Hüzünlü" ${user.mood === 'Hüzünlü' ? 'selected' : ''}>😔 Hüzünlü</option>
                                <option value="Yorgun" ${user.mood === 'Yorgun' ? 'selected' : ''}>😴 Yorgun</option>
                                <option value="Dizi Modunda" ${user.mood === 'Dizi Modunda' ? 'selected' : ''}>🎬 Dizi Modunda</option>
                                <option value="Aşık" ${user.mood === 'Aşık' ? 'selected' : ''}>😍 Aşık</option>
                                <option value="Kızgın" ${user.mood === 'Kızgın' ? 'selected' : ''}>😡 Kızgın</option>
                                <option value="Düşünceli" ${user.mood === 'Düşünceli' ? 'selected' : ''}>🤔 Düşünceli</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Sosyal Medya Linkleri</label>
                            <div style="display: flex; flex-direction: column; gap: 10px;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <i class="fa-brands fa-twitter" style="width: 20px; color: #1DA1F2;"></i>
                                    <input type="url" id="edit-twitter" class="form-input" 
                                        value="${user.socialLinks?.twitter || ''}" placeholder="https://twitter.com/username">
                                </div>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <i class="fa-brands fa-instagram" style="width: 20px; color: #E4405F;"></i>
                                    <input type="url" id="edit-instagram" class="form-input" 
                                        value="${user.socialLinks?.instagram || ''}" placeholder="https://instagram.com/username">
                                </div>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <i class="fa-brands fa-discord" style="width: 20px; color: #5865F2;"></i>
                                    <input type="text" id="edit-discord" class="form-input" 
                                        value="${user.socialLinks?.discord || ''}" placeholder="username#1234">
                                </div>
                            </div>
                        </div>
                        
                        <div style="background: var(--bg-secondary); padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                            <h4 style="margin-top:0; margin-bottom:10px; color:var(--text-primary);">Görünüm Ayarları</h4>
                            
                            <!-- Frame Selector -->
                            <div class="form-group">
                                <label>Çerçeve</label>
                                <select id="edit-frame" class="form-select">
                                    <option value="">Varsayılan</option>
                                    ${(user.inventory || []).filter(id => id.startsWith('frame_')).map(id => {
            const item = ShopSystem.items.find(i => i.id === id);
            return `<option value="${id}" ${user.activeItems?.frame === id ? 'selected' : ''}>${item ? item.name : id}</option>`;
        }).join('')}
                                </select>
                            </div>

                            <!-- Color Selector -->
                            <div class="form-group">
                                <label>İsim Rengi</label>
                                <select id="edit-color" class="form-select">
                                    <option value="">Varsayılan</option>
                                    ${(user.inventory || []).filter(id => id.startsWith('color_')).map(id => {
            const item = ShopSystem.items.find(i => i.id === id);
            return `<option value="${id}" ${user.activeItems?.color === id ? 'selected' : ''}>${item ? item.name : id}</option>`;
        }).join('')}
                                </select>
                            </div>

                            <!-- Title Selector -->
                            <div class="form-group">
                                <label>Unvan</label>
                                <select id="edit-title" class="form-select">
                                    <option value="">Varsayılan</option>
                                    ${(user.inventory || []).filter(id => id.startsWith('title_')).map(id => {
            const item = ShopSystem.items.find(i => i.id === id);
            return `<option value="${id}" ${user.activeItems?.title === id ? 'selected' : ''}>${item ? item.name : id}</option>`;
        }).join('')}
                                </select>
                            </div>

                            <!-- Gender Selector -->
                            <div class="form-group">
                                <label>Cinsiyet</label>
                                <select id="edit-gender" class="form-select">
                                    <option value="" ${!user.gender ? 'selected' : ''}>Belirtilmemiş</option>
                                    <option value="male" ${user.gender === 'male' ? 'selected' : ''}>Erkek</option>
                                    <option value="female" ${user.gender === 'female' ? 'selected' : ''}>Kız</option>
                                </select>
                            </div>

                        </div>

                        <button type="submit" id="save-profile-btn" class="btn btn-primary btn-block">Kaydet</button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async saveAdvancedProfile(event) {
        event.preventDefault();
        const btn = document.getElementById('save-profile-btn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> İşleniyor...';

        try {
            // Helper to read file as Base64
            const readFile = (file) => {
                return new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result);
                    reader.onerror = reject;
                    reader.readAsDataURL(file);
                });
            };

            const avatarFile = document.getElementById('edit-avatar-file').files[0];
            const coverFile = document.getElementById('edit-cover-file').files[0];

            let avatarUrl = document.getElementById('edit-avatar-url').value;
            let coverUrl = document.getElementById('edit-cover-url').value;

            // Process Avatar
            if (avatarFile) {
                // Limit: 500KB (approx 0.5 MB)
                if (avatarFile.size > 500 * 1024) throw new Error("Profil resmi 500KB'dan küçük olmalı!");
                avatarUrl = await readFile(avatarFile);
            }

            // Process Cover
            if (coverFile) {
                // Limit: 1MB
                if (coverFile.size > 1 * 1024 * 1024) throw new Error("Kapak resmi 1MB'dan küçük olmalı!");
                coverUrl = await readFile(coverFile);
            }

            const updates = {
                avatar: avatarUrl,
                coverPhoto: coverUrl,
                bio: document.getElementById('edit-bio').value,
                mood: document.getElementById('edit-mood').value,
                socialLinks: {
                    twitter: document.getElementById('edit-twitter').value,
                    instagram: document.getElementById('edit-instagram').value,
                    discord: document.getElementById('edit-discord').value
                },
                gender: document.getElementById('edit-gender').value,
                activeItems: {
                    frame: document.getElementById('edit-frame') ? document.getElementById('edit-frame').value : (user.activeItems?.frame || null),
                    color: document.getElementById('edit-color') ? document.getElementById('edit-color').value : (user.activeItems?.color || null),
                    title: document.getElementById('edit-title') ? document.getElementById('edit-title').value : (user.activeItems?.title || null)
                }
            };

            // Use Central DB Update to ensure persistence
            if (window.db && window.db.updateUser) {
                db.updateUser(State.currentUser.id, updates);
                Toast.success('Profil güncellendi!');
            } else {
                // Fallback
                State.currentUser = { ...State.currentUser, ...updates };
                if (State.data && State.data.users) {
                    const idx = State.data.users.findIndex(u => u.id === State.currentUser.id);
                    if (idx !== -1) State.data.users[idx] = State.currentUser;
                }
                localStorage.setItem('dramicbox_users', JSON.stringify(State.data.users));
                sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
                Toast.success('Profil güncellendi (Yerel)!');
            }

            // Update session storage
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));

            Toast.success('Profil güncellendi!');
            document.querySelector('.modal').remove();

            if (typeof App !== 'undefined' && App.renderProfile) {
                App.renderProfile();
            }
            if (typeof Auth !== 'undefined' && Auth.updateAuthUI) {
                Auth.updateAuthUI();
            }

        } catch (error) {
            console.error('Save advanced profile error:', error);
            Toast.error('Hata: ' + error.message);
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.textContent = 'Kaydet';
            }
        }
    },

    renderProfileHeader(targetUser = null) {
        const user = targetUser || State.currentUser;
        if (!user) return '';

        const coverPhoto = user.coverPhoto || 'https://via.placeholder.com/1200x300/1a1a2e/ffffff?text=Cover+Photo';
        // Force string comparison for safer ID matching
        const isMe = State.currentUser && String(State.currentUser.id) === String(user.id);

        // --- SHOP ITEMS VISUALS ---
        // Ensure ShopSystem is available
        const allItems = (window.ShopSystem && window.ShopSystem.items) ? window.ShopSystem.items : [];

        const activeFrame = user.activeItems?.frame ? allItems.find(i => i.id === user.activeItems.frame) : null;
        const activeColor = user.activeItems?.color ? allItems.find(i => i.id === user.activeItems.color) : null;
        const activeTitle = user.activeItems?.title ? allItems.find(i => i.id === user.activeItems.title) : null;

        const frameStyle = activeFrame ? activeFrame.value : 'border: 4px solid var(--bg-card);';
        const nameStyle = activeColor ? (activeColor.value.includes('gradient') ? activeColor.value : `color: ${activeColor.value};`) : '';
        const titleHtml = activeTitle ? `<span class="badge badge-warning" style="margin-left:5px; background:linear-gradient(45deg, #ffd700, #ffa500); color:black;">${activeTitle.value}</span>` : '';

        return `
            <div class="profile-header">
                <div class="profile-cover" style="background-image: url('${coverPhoto}');"></div>
                
                <div class="profile-info-section">
                    <div class="profile-avatar-wrapper">
                         <img src="${user.avatar || 'assets/logo.png'}" alt="${user.username}" style="${frameStyle}">
                    </div>
                    
                    <div class="profile-main-info">
                        <div class="profile-username-row">
                            <h1 class="profile-username" style="${nameStyle}">${user.username}</h1>
                            ${titleHtml}
                            <div style="display:inline-flex; gap:8px;">
                                ${this.renderBadges(user.badges)}
                            </div>
                        </div>
                        ${user.mood ? `<div class="profile-mood" style="font-size: 0.9rem; color: #a78bfa; margin-bottom: 8px; font-weight: 500; display: flex; align-items: center; gap: 8px; justify-content: center;">
                            <i class="fa-solid fa-face-smile"></i> <span>Ruh Hali: ${user.mood}</span>
                        </div>` : ''}
                        ${user.bio ? `<p class="profile-bio">${user.bio}</p>` : ''}
                        ${this.renderSocialLinks(user.socialLinks)}
                    </div>
                </div>
            </div>
            <div style="display: flex; justify-content: center; margin-bottom: 30px;">
                ${isMe ? `
                    <div class="profile-actions-grid" style="display: flex; gap: 15px; flex-wrap: wrap;">
                        <button class="profile-action-btn" onclick="AdvancedProfile.showEditAdvancedProfile()">
                            <i class="fa-solid fa-user-pen"></i> Profili Düzenle
                        </button>
                        <button class="profile-action-btn" onclick="ShopSystem.open()">
                            <i class="fa-solid fa-store"></i> Mağaza
                        </button>
                    </div>
                ` : `
                    <div class="profile-actions-grid" style="display: flex; gap: 15px; flex-wrap: wrap;">
                        <button class="profile-action-btn" style="background: var(--p-accent); border: none;" onclick="SocialFeed.sendFriendRequest('${user.id}')">
                            <i class="fa-solid fa-user-plus"></i> Arkadaş Ekle
                        </button>
                        <button class="profile-action-btn" style="background: rgba(255,255,255,0.1);" onclick="SocialFeed.followUser('${user.id}')">
                            <i class="fa-solid fa-plus"></i> Takip Et
                        </button>
                        <button class="profile-action-btn" style="background: rgba(124, 58, 237, 0.2); color: #a78bfa; border-color: rgba(124, 58, 237, 0.3);" onclick="SocialFeed.startChat('${user.id}')">
                            <i class="fa-solid fa-message"></i> Mesaj Gönder
                        </button>
                    </div>
                `}
            </div>
        `;

    },



    renderBadges(badges) {
        if (!badges || badges.length === 0) {
            return `<span class="badge" style="background:var(--bg-primary); color:var(--text-secondary); padding: 4px 10px; border-radius: 4px; border: 1px solid var(--border-color);"><i class="fa-solid fa-user"></i> Üye</span>`;
        }

        const badgeIcons = {
            'Yönetici': '<i class="fa-solid fa-crown"></i>',
            'Admin': '<i class="fa-solid fa-shield-halved"></i>',
            'Çevirmen': '<i class="fa-solid fa-language"></i>',
            'Blogger': '<i class="fa-solid fa-pen-nib"></i>',
            'VIP': '<i class="fa-solid fa-gem"></i>',
            'Moderatör': '<i class="fa-solid fa-gavel"></i>',
            'Kullanıcı': '<i class="fa-solid fa-user"></i>'
        };

        const badgeColors = {
            'Yönetici': '#ef4444',
            'Admin': '#ef4444',
            'Çevirmen': '#3b82f6',
            'Blogger': '#a855f7',
            'VIP': '#eab308'
        };

        return badges.map(b => {
            const icon = badgeIcons[b] || '<i class="fa-solid fa-medal"></i>';
            const color = badgeColors[b] || '#8b5cf6'; // Default purple

            // Map colors to gradients for modern look
            let style = '';
            if (b === 'VIP' || b === 'Yönetici' || b === 'Admin') {
                style = `background: linear-gradient(135deg, ${color}40, ${color}10); border-color: ${color}60; color: ${color}; box-shadow: 0 0 10px ${color}20;`;
            } else {
                style = `background: ${color}15; border-color: ${color}40; color: ${color};`;
            }

            return `
                <span class="modern-badge" style="${style}">
                    ${icon} ${b}
                </span>`;
        }).join('');
    },

    renderFriendActions(targetUser) {
        if (!State.currentUser) return '';

        const isFriend = State.currentUser.friends?.includes(targetUser.id);

        // Check outgoing request
        const sentRequest = (State.data.friendRequests || []).find(r => r.from === State.currentUser.id && r.to === targetUser.id && r.status === 'pending');

        // Check incoming request
        const receivedRequest = (State.data.friendRequests || []).find(r => r.from === targetUser.id && r.to === State.currentUser.id && r.status === 'pending');

        if (isFriend) {
            return `
                <button class="btn btn-outline" onclick="App.router('social'); setTimeout(() => SocialFeed.switchTab('messages', document.querySelector('.social-hub-tab[data-tab=messages]')), 500)">
                    <i class="fa-solid fa-message"></i> Mesaj Gönder
                </button>
                <button class="btn btn-outline btn-sm" style="margin-left:5px; border-color:var(--success-color); color:var(--success-color);">
                    <i class="fa-solid fa-check"></i> Arkadaş
                </button>
            `;
        }

        if (sentRequest) {
            return '<button class="btn btn-outline" disabled><i class="fa-solid fa-clock"></i> İstek Gönderildi</button>';
        }

        if (receivedRequest) {
            return `
                <div style="display:flex; gap:10px; align-items:center;">
                    <span style="color:var(--text-secondary); font-size:0.9rem;">Sizi arkadaş olarak ekledi</span>
                    <button class="btn btn-success" onclick="SocialFeed.acceptFriendRequest && SocialFeed.acceptFriendRequest(0)">Kabul Et</button>
                    <button class="btn btn-danger" onclick="SocialFeed.rejectFriendRequest && SocialFeed.rejectFriendRequest(0)">Reddet</button>
                </div>
            `;
        }

        return `<button class="btn btn-primary" onclick="SocialFeed.sendFriendRequest && SocialFeed.sendFriendRequest('${targetUser.id}')"><i class="fa-solid fa-user-plus"></i> Arkadaş Ekle</button>`;
    },

    renderProfileContent(userId, profileData = null) {
        const data = profileData || (State.data.users || []).find(u => u.id === userId) || State.currentUser;

        // 1. Stats
        if (window.Statistics) {
            Statistics.renderStats('user-stats-grid', userId, data);
        }

        // 2. Achievements
        if (window.Gamification) {
            Gamification.renderAchievements('profile-achievements', userId, data);
        }

        // 3. Friend Activities
        const activitiesContainer = document.getElementById('friend-activities');
        if (activitiesContainer) {
            // Use ActivityFeed if available, otherwise UserProfiles or just empty
            if (window.ActivityFeed) {
                // Filter activities for this user or their friends if it's 'me'
                // For now, let's just show global or user specific if we can
                // If viewing self: show friends' activities? or own? 
                // "Arkadaş Aktiviteleri" suggests friends.
                // If viewing others: show THEIR activities?

                // For "Arkadaş Aktiviteleri" section, it implies "Friend Activities" logic.
                // Only relevant if viewing OWN profile usually.

                if (State.currentUser && State.currentUser.id === userId) {
                    // Show Friends Activities
                    activitiesContainer.innerHTML = ActivityFeed.render();
                } else {
                    // Viewing someone else: Show THEIR recent activities
                    // ActivityFeed.getRecentActivities needs filtering by user which it doesn't support yet fully
                    // So we can fallback to "No activity" or implement simple list
                    activitiesContainer.innerHTML = '<p class="text-muted">Görüntülenecek aktivite yok.</p>';
                }
            } else {
                activitiesContainer.innerHTML = '<p class="text-muted">Aktivite akışı yüklenemedi.</p>';
            }
        }

        // 4. Custom Lists for Profile Tab
        const listsContainer = document.getElementById('profile-my-lists-content');
        if (listsContainer) {
            const userLists = (State.data.customLists || []).filter(l => l.userId === userId);
            if (userLists.length > 0) {
                listsContainer.innerHTML = userLists.map(list => `
                   <div class="list-card" onclick="ListSystem.viewList('${list.id}')" style="background:rgba(255,255,255,0.05); padding:15px; border-radius:8px; margin-bottom:10px; cursor:pointer; display:flex; justify-content:space-between; align-items:center; transition:background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                       <div style="flex:1;">
                           <h4 style="margin:0; font-size:1rem; color: #fff;">${list.name}</h4>
                           <div style="font-size:0.8rem; color:var(--text-secondary); margin-top:4px;">${list.items.length} içerik • ${list.description || ''}</div>
                       </div>
                       <i class="fa-solid fa-chevron-right" style="color:var(--text-secondary);"></i>
                   </div>
                `).join('');
            } else {
                listsContainer.innerHTML = '<div style="text-align:center; padding:30px; color:var(--text-secondary); border: 1px dashed var(--border-color); border-radius:8px;"><i class="fa-solid fa-clipboard-list" style="font-size:2rem; margin-bottom:10px; opacity:0.5;"></i><p>Henüz liste oluşturulmamış.</p></div>';
            }
        }

        // 4. Watchlist (Re-trigger App logic if needed, or handle here)
        // App.js usually handles this via App.buildGrid but we can reinforce it
        // The container is #profile-watchlist
        // app.js renderProfile already attempts to do this.
    },

        if (links.length === 0) return '';

        return `<div class="social-links" style="display: flex; gap: 15px; align-items: center;">
            ${links.join('')}
        </div>`;
    },

    currentCollectionFilter: 'owned',

    switchCollectionFilter(filterMode) {
        this.currentCollectionFilter = filterMode;
        
        const ownedBtn = document.getElementById('coll-filter-owned');
        const allBtn = document.getElementById('coll-filter-all');
        if (ownedBtn && allBtn) {
            if (filterMode === 'all') {
                allBtn.style.background = 'var(--premium-violet-glow)';
                allBtn.style.color = 'white';
                ownedBtn.style.background = 'transparent';
                ownedBtn.style.color = '#94a3b8';
            } else {
                ownedBtn.style.background = 'var(--premium-violet-glow)';
                ownedBtn.style.color = 'white';
                allBtn.style.background = 'transparent';
                allBtn.style.color = '#94a3b8';
            }
        }
        
        const userId = new URLSearchParams(window.location.hash.split('?')[1]).get('userId') || State.currentUser?.id;
        this.renderCollection(userId);
    },

    renderInventoryTab(userId) {
        const container = document.getElementById('tab-content-inventory');
        if (!container) return;

        const targetUser = (State.data.users || []).find(u => u.id === userId) || State.currentUser;
        if (!targetUser) return;

        const isMe = State.currentUser && String(State.currentUser.id) === String(targetUser.id);
        const gamif = targetUser.gamification || { chests: {} };
        const chests = gamif.chests || {};

        // Normalize counts (combining TR and EN keys)
        const bronzeCount = (chests.bronz || 0) + (chests.bronze || 0);
        const silverCount = (chests.gumus || 0) + (chests.silver || 0);
        const goldCount = (chests.altin || 0) + (chests.gold || 0);
        const legendaryCount = (chests.efsanevi || 0) + (chests.legendary || 0);

        // VIP status details
        let vipCardHTML = '';
        const vipActive = targetUser.vipStatus?.active || targetUser.role === 'vip' || targetUser.isVip;
        const vipExpires = targetUser.vipStatus?.expiresAt;
        const now = Date.now();

        if (vipActive) {
            let daysRemainingText = 'Süresiz';
            let cancelBtn = '';
            if (vipExpires && vipExpires > now) {
                const daysLeft = Math.ceil((vipExpires - now) / (1000 * 60 * 60 * 24));
                daysRemainingText = `${daysLeft} gün kaldı`;
            }
            if (isMe) {
                cancelBtn = `<button class="btn btn-sm btn-outline-danger" onclick="AdvancedProfile.cancelVipMembership()" style="border-radius:12px; font-weight:700; padding:8px 16px;"><i class="fa-solid fa-ban"></i> İptal Et</button>`;
            }
            vipCardHTML = `
                <div class="vip-status-card" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(5, 150, 105, 0.15)); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 20px; padding: 25px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 10px 25px rgba(0,0,0,0.2);">
                    <div>
                        <div style="font-size: 0.75rem; color: #34d399; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 5px;">ÜYELİK DURUMU</div>
                        <h4 style="margin: 0; color: #fff; font-size: 1.3rem; font-weight: 900; display: flex; align-items: center; gap: 8px;"><i class="fa-solid fa-crown" style="color: #fbbf24;"></i> VIP Üyelik Aktif</h4>
                        <p style="margin: 5px 0 0 0; color: #a7f3d0; font-size: 0.85rem; font-weight: 500;">VIP Ayrıcalıklarının tadını çıkarıyorsunuz • <span style="font-weight:700; color:#fff;">${daysRemainingText}</span></p>
                    </div>
                    ${cancelBtn}
                </div>
            `;
        } else {
            vipCardHTML = `
                <div class="vip-status-card" style="background: linear-gradient(135deg, rgba(255, 255, 255, 0.02), rgba(255, 255, 255, 0.04)); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 20px; padding: 25px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
                    <div>
                        <div style="font-size: 0.75rem; color: #94a3b8; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 5px;">ÜYELİK DURUMU</div>
                        <h4 style="margin: 0; color: #cbd5e1; font-size: 1.25rem; font-weight: 800;">Standart Üyelik</h4>
                        <p style="margin: 5px 0 0 0; color: #64748b; font-size: 0.85rem; font-weight: 500;">VIP üye olarak reklamsız video ve özel avantajlara erişebilirsiniz.</p>
                    </div>
                    ${isMe ? `<button class="btn btn-sm btn-primary" onclick="ShopSystem.open('premium')" style="border-radius:12px; font-weight:700; padding:8px 16px;"><i class="fa-solid fa-crown"></i> VIP Ol</button>` : ''}
                </div>
            `;
        }

        // Chest grid rendering
        const chestsConfig = [
            { key: 'bronz', name: 'Bronz Sandık', count: bronzeCount, icon: '📦', color: '#cd7f32', desc: 'Bronz kart sandığı. Ortak ve Nadir kartlar içerir.' },
            { key: 'gumus', name: 'Gümüş Sandık', count: silverCount, icon: '📦', color: '#c0c0c0', desc: 'Gümüş kart sandığı. Nadir ve Epik kart çıkma şansı yüksektir.' },
            { key: 'altin', name: 'Altın Sandık', count: goldCount, icon: '📦', color: '#ffd700', desc: 'Altın kart sandığı. Epik ve Efsanevi kartlar için en iyisi!' },
            { key: 'efsanevi', name: 'Efsanevi Sandık', count: legendaryCount, icon: '📦', color: '#a78bfa', desc: 'Efsanevi kart sandığı. Epik ve Efsanevi kart garantili!' }
        ];

        const chestItemsHTML = chestsConfig.map(chest => {
            const actionBtn = isMe 
                ? `<button class="btn btn-block ${chest.count > 0 ? 'btn-primary' : 'btn-outline'}" ${chest.count <= 0 ? 'disabled' : ''} onclick="Gamification.openChest('${chest.key}', false)" style="width:100%; border-radius:12px; font-weight:800;">${chest.count > 0 ? 'Sandığı Aç' : 'Kilitli'}</button>`
                : `<button class="btn btn-block btn-outline" disabled style="width:100%; border-radius:12px; font-weight:800;">Açamazsınız</button>`;
            
            return `
                <div class="shop-card-v2" style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); border-radius: 20px; padding: 25px; text-align: center; position: relative;">
                    <span style="position: absolute; top: 15px; right: 15px; background: var(--premium-violet-glow); color: white; padding: 4px 10px; border-radius: 10px; font-size: 0.75rem; font-weight: 800;">Adet: ${chest.count}</span>
                    <div style="font-size: 3.5rem; filter: drop-shadow(0 0 15px ${chest.color}); display:flex; align-items:center; justify-content:center; margin-bottom: 15px; height: 80px;">${chest.icon}</div>
                    <div style="font-weight: 800; font-size: 1.1rem; color: #fff; margin-bottom: 5px;">${chest.name}</div>
                    <p style="color: #64748b; font-size: 0.8rem; line-height: 1.4; margin: 0 0 20px 0; min-height: 40px;">${chest.desc}</p>
                    ${actionBtn}
                </div>
            `;
        }).join('');

        container.innerHTML = `
            ${vipCardHTML}
            <h3 style="color:#fff; margin-bottom:15px; font-weight:800; font-size:1.2rem;"><i class="fa-solid fa-box-open" style="color:var(--premium-violet); margin-right:8px;"></i> Sandık Envanterim</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 20px;">
                ${chestItemsHTML}
            </div>
        `;
    },

    async cancelVipMembership() {
        if (!State.currentUser || State.currentUser.role === 'guest') return;

        if (!confirm("VIP üyeliğinizi iptal etmek istediğinize emin misiniz? Bu işlem geri alınamaz ve tüm VIP haklarınız anında sonlandırılacaktır.")) {
            return;
        }

        const updates = {
            role: 'user',
            isVip: false,
            vipStatus: {
                active: false,
                expiresAt: null,
                purchasedAt: null,
                isLifetime: false
            }
        };

        // Remove 'VIP' badge if exists
        let badges = [...(State.currentUser.badges || [])];
        badges = badges.filter(b => b !== 'VIP' && b !== 'VIP+');
        updates.badges = badges;

        try {
            if (window.db && window.db.updateUser) {
                await db.updateUser(State.currentUser.id, updates);
            } else {
                State.currentUser = { ...State.currentUser, ...updates };
                sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            }
            Toast.success('VIP Üyeliğiniz başarıyla iptal edildi.');
            
            // Reload Advanced Profile
            AdvancedProfile.render(State.currentUser.id);
            
            // Update Navbar UI
            if (window.Auth && Auth.updateAuthUI) {
                Auth.updateAuthUI();
            }
        } catch (e) {
            console.error('Cancel VIP error:', e);
            Toast.error('VIP iptali sırasında sunucu hatası oluştu.');
        }
    },

    renderPassTab(userId) {
        const container = document.getElementById('tab-content-pass');
        if (!container) return;

        const targetUser = (State.data.users || []).find(u => u.id === userId) || State.currentUser;
        if (!targetUser) return;

        const isMe = State.currentUser && String(State.currentUser.id) === String(targetUser.id);
        const stats = targetUser.stats || { xp: 0, level: 1 };
        const level = stats.level || 1;
        const xp = stats.xp || 0;

        // Get config tiers or default
        const configPassTiers = (window.Gamification && Gamification.config?.passTiers) 
            ? Gamification.config.passTiers 
            : {
                "2": { free: { type: "coins", value: 50, label: "50 Coin" }, vip: { type: "coins", value: 150, label: "150 Coin" } },
                "3": { free: { type: "chest", value: "bronz", label: "Bronz Sandık" }, vip: { type: "frame", value: "frame_neon_purple", label: "Neon Mor Çerçeve" } },
                "4": { free: { type: "coins", value: 100, label: "100 Coin" }, vip: { type: "chest", value: "altin", label: "Altın Sandık" } },
                "5": { free: { type: "vip_days", value: 1, label: "1 Günlük VIP" }, vip: { type: "coins", value: 400, label: "400 Coin" } },
                "6": { free: { type: "cheer", value: 50, label: "50 Cheer Puanı" }, vip: { type: "cheer", value: 150, label: "150 Cheer Puanı" } },
                "7": { free: { type: "chest", value: "gumus", label: "Gümüş Sandık" }, vip: { type: "chest", value: "altin", label: "Altın Sandık" } },
                "8": { free: { type: "coins", value: 150, label: "150 Coin" }, vip: { type: "coins", value: 500, label: "500 Coin" } },
                "9": { free: { type: "cheer", value: 100, label: "100 Cheer Puanı" }, vip: { type: "chest", value: "efsanevi", label: "Efsanevi Sandık" } },
                "10": { free: { type: "vip_days", value: 3, label: "3 Günlük VIP" }, vip: { type: "frame", value: "frame_gold", label: "Efsanevi Altın Çerçeve" } }
            };

        // Gamification progress bar calculations
        let progressPercent = 0;
        let xpNeeded = 100;
        if (window.Gamification) {
            progressPercent = Gamification.getLevelProgress(xp);
            xpNeeded = Gamification.getNextLevelXP(level) - (level > 1 ? Gamification.getNextLevelXP(level - 1) : 0);
        } else {
            const nextLevelXp = Math.pow(level, 2) * 100;
            const prevLevelXp = level > 1 ? Math.pow(level - 1, 2) * 100 : 0;
            const range = nextLevelXp - prevLevelXp;
            progressPercent = range > 0 ? ((xp - prevLevelXp) / range) * 100 : 0;
            xpNeeded = range;
        }

        const currentLvlXp = xp - (level > 1 ? Math.pow(level - 1, 2) * 100 : 0);
        const hasVip = targetUser.vipStatus?.active || targetUser.role === 'vip' || targetUser.isVip;

        const claimedTiers = (targetUser.gamification && targetUser.gamification.claimedTiers) 
            ? targetUser.gamification.claimedTiers 
            : { free: [], vip: [] };

        // Render pass tiers
        const tierLevels = Object.keys(configPassTiers).map(Number).sort((a,b) => a-b);
        const tiersHTML = tierLevels.map(tierLvl => {
            const def = configPassTiers[tierLvl.toString()];
            const isUnlocked = level >= tierLvl;

            // Free track status
            const freeClaimed = claimedTiers.free?.includes(tierLvl);
            let freeBtn = '';
            if (freeClaimed) {
                freeBtn = `<span style="color:#10b981; font-weight:800; font-size:0.8rem;"><i class="fa-solid fa-circle-check"></i> Alındı</span>`;
            } else if (isUnlocked) {
                freeBtn = isMe 
                    ? `<button class="btn btn-sm btn-primary" onclick="AdvancedProfile.claimPassReward(${tierLvl}, 'free')" style="border-radius:10px; font-size:0.75rem; padding:4px 12px; font-weight:800;">Al</button>`
                    : `<span style="color:#64748b; font-size:0.75rem; font-weight:700;">Alınabilir</span>`;
            } else {
                freeBtn = `<span style="color:#475569; font-size:0.75rem;"><i class="fa-solid fa-lock"></i> Kilitli</span>`;
            }

            // VIP track status
            const vipClaimed = claimedTiers.vip?.includes(tierLvl);
            let vipBtn = '';
            if (vipClaimed) {
                vipBtn = `<span style="color:#10b981; font-weight:800; font-size:0.8rem;"><i class="fa-solid fa-circle-check"></i> Alındı</span>`;
            } else if (isUnlocked) {
                if (hasVip) {
                    vipBtn = isMe 
                        ? `<button class="btn btn-sm btn-primary" onclick="AdvancedProfile.claimPassReward(${tierLvl}, 'vip')" style="border-radius:10px; font-size:0.75rem; padding:4px 12px; font-weight:800; background:linear-gradient(45deg,#d97706,#fbbf24); border:none;">Al</button>`
                        : `<span style="color:#fbbf24; font-size:0.75rem; font-weight:700;">Alınabilir</span>`;
                } else {
                    vipBtn = `<span style="color:#fbbf24; font-size:0.75rem; font-weight:700;"><i class="fa-solid fa-crown"></i> VIP Kilidi</span>`;
                }
            } else {
                vipBtn = `<span style="color:#475569; font-size:0.75rem;"><i class="fa-solid fa-lock"></i> Kilitli</span>`;
            }

            return `
                <div class="pass-tier-row" style="display: grid; grid-template-columns: 80px 1fr 1fr; gap: 20px; align-items: center; padding: 18px 20px; background: ${isUnlocked ? 'rgba(255,255,255,0.02)' : 'rgba(255,255,255,0.005)'}; border-bottom: 1px solid rgba(255,255,255,0.04); opacity: ${isUnlocked ? '1' : '0.6'}; transition: all 0.3s;">
                    <div style="text-align: center;">
                        <span style="font-size: 0.8rem; color: #94a3b8; font-weight: 850; display: block; text-transform: uppercase;">SEVİYE</span>
                        <span style="font-size: 1.6rem; font-weight: 900; color: ${isUnlocked ? 'var(--premium-violet)' : '#475569'};">${tierLvl}</span>
                    </div>
                    <!-- Free Reward Track -->
                    <div style="background: rgba(255,255,255,0.01); border: 1px solid rgba(255,255,255,0.03); border-radius: 12px; padding: 12px 18px; display: flex; justify-content: space-between; align-items: center; gap: 10px;">
                        <div>
                            <div style="font-size: 0.65rem; color: #64748b; font-weight: 800; text-transform: uppercase;">ÜCRETSİZ YOL</div>
                            <div style="font-weight: 800; color: #fff; font-size: 0.9rem; margin-top: 2px;">${def.free.label}</div>
                        </div>
                        ${freeBtn}
                    </div>
                    <!-- VIP Reward Track -->
                    <div style="background: rgba(251,191,36,0.02); border: 1px solid rgba(251,191,36,0.08); border-radius: 12px; padding: 12px 18px; display: flex; justify-content: space-between; align-items: center; gap: 10px;">
                        <div>
                            <div style="font-size: 0.65rem; color: #fbbf24; font-weight: 800; text-transform: uppercase; display: flex; align-items: center; gap: 4px;"><i class="fa-solid fa-crown"></i> VIP YOL</div>
                            <div style="font-weight: 800; color: #fff; font-size: 0.9rem; margin-top: 2px;">${def.vip.label}</div>
                        </div>
                        ${vipBtn}
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = `
            <div class="dramic-pass-header" style="background: linear-gradient(135deg, rgba(124, 58, 237, 0.1), rgba(236, 72, 153, 0.05)); border: 1px solid rgba(124, 58, 237, 0.2); border-radius: 24px; padding: 30px; margin-bottom: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:15px;">
                    <div>
                        <h2 style="margin: 0; font-size: 1.6rem; font-weight: 900; background: linear-gradient(135deg,#a78bfa,#f472b6); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><i class="fa-solid fa-ticket-simple"></i> DRAMIC PASS PROGRESSION</h2>
                        <p style="margin: 5px 0 0 0; color: #94a3b8; font-size: 0.9rem; font-weight: 500;">Dizileri izledikçe Seviye atla ve her seviyede harika ödüllerin kilidini aç!</p>
                    </div>
                    <div style="text-align: right;">
                        <span style="font-size: 0.75rem; color: #a78bfa; font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">Aktif Seviye</span>
                        <div style="font-size: 2rem; font-weight: 950; color: #fff; line-height: 1; margin-top: 3px;">LVL ${level}</div>
                    </div>
                </div>

                <div class="xp-bar-container" style="background: rgba(0,0,0,0.3); border-radius: 12px; padding: 6px; border: 1px solid rgba(255,255,255,0.05);">
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem; font-weight:800; color:#fff; padding:0 8px 4px 8px;">
                        <span>SEVİYE İLERLEMESİ</span>
                        <span>${currentLvlXp} / ${xpNeeded} XP</span>
                    </div>
                    <div style="width: 100%; height: 10px; background: rgba(0,0,0,0.4); border-radius: 6px; overflow: hidden;">
                        <div style="width: ${progressPercent}%; height: 100%; background: linear-gradient(90deg, #7c3aed, #ec4899); border-radius: 6px; box-shadow: 0 0 10px rgba(124, 58, 237, 0.5);"></div>
                    </div>
                </div>
            </div>

            <div class="dramic-pass-tiers-wrapper" style="background: rgba(255,255,255,0.01); border: 1px solid rgba(255,255,255,0.04); border-radius: 24px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
                <div class="pass-tiers-header-row" style="display: grid; grid-template-columns: 80px 1fr 1fr; gap: 20px; align-items: center; padding: 15px 20px; background: rgba(255,255,255,0.03); border-bottom: 2px solid rgba(255,255,255,0.06); font-weight: 850; font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px;">
                    <div style="text-align: center;">Seviye</div>
                    <div>Ücretsiz Ödül Yolu</div>
                    <div><i class="fa-solid fa-crown" style="color:#fbbf24;"></i> VIP Ödül Yolu</div>
                </div>
                <div class="pass-tiers-list">
                    ${tiersHTML}
                </div>
            </div>
        `;
    },

    async claimPassReward(level, track) {
        if (!window.Gamification) {
            Toast.error('Gamification modülü yüklenemedi!');
            return;
        }

        try {
            await Gamification.claimPassTier(level, track);
            // Re-render advanced profile tabs
            this.renderPassTab(State.currentUser.id);
            if (window.Auth && Auth.updateAuthUI) {
                Auth.updateAuthUI();
            }
        } catch (e) {
            console.error('Claim pass reward error:', e);
            Toast.error('Ödül alımı sırasında hata oluştu.');
        }
    },

    renderSocialLinks(socialLinks) {
        if (!socialLinks) return '';

        const links = [];
        if (socialLinks.twitter) {
            links.push(`<a href="${socialLinks.twitter}" target="_blank" class="social-link" title="Twitter">
                <i class="fa-brands fa-twitter"></i>
            </a>`);
        }
        if (socialLinks.instagram) {
            links.push(`<a href="${socialLinks.instagram}" target="_blank" class="social-link" title="Instagram">
                <i class="fa-brands fa-instagram"></i>
            </a>`);
        }
        if (socialLinks.discord) {
            links.push(`<span class="social-link" title="Discord: ${socialLinks.discord}">
                <i class="fa-brands fa-discord"></i> ${socialLinks.discord}
            </span>`);
        }

        if (links.length === 0) return '';

        return `<div class="social-links" style="display: flex; gap: 15px; align-items: center;">
            ${links.join('')}
        </div>`;
    }
};

window.AdvancedProfile = AdvancedProfile;
console.log('✅ Advanced Profile Module Loaded!');
