
// ============================================
// USER PROFILE PAGE (Refactored & Integrated)
// ============================================

const UserProfile = {
    currentUserId: null,
    activeTab: 'overview',
    activeConversationId: null,

    async show(userId) {
        this.currentUserId = userId || State.currentUser?.id;

        if (!this.currentUserId) {
            Toast.error('Kullanıcı bulunamadı');
            App.router('home');
            return;
        }

        const user = this.getUser();
        if (!user) {
            Toast.error('Kullanıcı verisi yüklenemedi');
            return;
        }

        // Ensure social posts are loaded
        await db.ensureCollection('socialPosts');

        const mainContainer = document.getElementById('profile-content-container');
        // Ensure container exists, if not, create it in app-container
        if (!mainContainer) {
            const appContainer = document.getElementById('app-container');
            if (appContainer) {
                appContainer.innerHTML = '<div id="profile-content-container"></div>';
            }
        }

        const container = document.getElementById('profile-content-container');
        if (container) {
            const isFriend = (State.currentUser?.friends || []).includes(user.id);
            const isPrivate = user.isPrivate && !this.isOwnProfile() && !isFriend && State.currentUser?.role !== 'admin';
            
            if (isPrivate) {
                container.innerHTML = this.buildPrivateShell();
            } else {
                container.innerHTML = this.buildShell();
                this.switchTab(this.activeTab);
            }

            // Handle pending actions
            if (this.pendingAction && this.isOwnProfile()) {
                if (this.pendingAction.type === 'openChat') {
                    this.switchTab('messages');
                    setTimeout(() => {
                        if (window.MessageService && MessageService.createConversation) {
                            MessageService.createConversation(this.pendingAction.targetUserId);
                        }
                        this.openChat(this.pendingAction.targetUserId);
                    }, 500); // Small delay to ensure render
                }
                this.pendingAction = null;
            }
        }

        console.log(`👤 Profile Loaded: ${user.username} (${this.currentUserId})`);
    },

    getUser() {
        if (!this.currentUserId) return null;
        
        const searchId = String(this.currentUserId).toLowerCase();

        // 1. Check State.currentUser (Exact ID or Case-insensitive Username)
        if (State.currentUser && (
            State.currentUser.id === this.currentUserId || 
            State.currentUser.username.toLowerCase() === searchId
        )) {
            return State.currentUser;
        }
        
        // 2. Check State.data.users
        if (State.data.users) {
            // Try ID match
            let user = State.data.users.find(u => u.id === this.currentUserId);
            if (user) return user;

            // Try Username match
            user = State.data.users.find(u => u.username && u.username.toLowerCase() === searchId);
            if (user) return user;
        }
        
        return null;
    },

    isOwnProfile() {
        return State.currentUser && State.currentUser.id === this.currentUserId;
    },

    buildPrivateShell() {
        const user = this.getUser();
        return `
        <div class="profile-layout-new" style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; background: #0a0a0c; color: #f8fafc; font-family: 'Outfit', sans-serif; text-align: center; padding: 40px;">
            <div style="position: relative; margin-bottom: 30px;">
                ${this.renderAvatar(user, 160)}
                <div style="position: absolute; bottom: 10px; right: 10px; width: 45px; height: 45px; border-radius: 50%; background: #0a0a0c; display: flex; align-items: center; justify-content: center; border: 4px solid #0a0a0c;">
                    <i class="fa-solid fa-lock" style="color: #8b5cf6; font-size: 1.2rem;"></i>
                </div>
            </div>
            <h2 style="font-size: 2.5rem; font-weight: 900; color: #fff; margin-bottom: 10px;">${user.username}</h2>
            <div class="modern-badge" style="margin-bottom: 30px;"><i class="fa-solid fa-user-shield"></i> Gizli Profil</div>
            
            <div class="glass-panel" style="max-width: 500px; padding: 40px; border-radius: 30px; border: 1px solid rgba(139, 92, 246, 0.2); background: rgba(139, 92, 246, 0.05);">
                <p style="color: #94a3b8; font-size: 1.1rem; line-height: 1.6; margin-bottom: 30px;">
                    Bu kullanıcı profilini gizli yaptı. Paylaşımlarını ve aktivitelerini görmek için arkadaş olmalısınız.
                </p>
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <button class="btn-premium" onclick="UserProfile.sendFriendRequest('${user.id}')" style="padding: 15px 30px;">
                        <i class="fa-solid fa-user-plus"></i> Arkadaşlık İsteği Gönder
                    </button>
                    <button class="btn-secondary" onclick="App.router('home')" style="padding: 15px 30px; background: rgba(255,255,255,0.05); color: #fff; border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; cursor: pointer;">
                        Anasayfaya Dön
                    </button>
                </div>
            </div>
        </div>
        ${this.getStyles()}
        `;
    },

    buildShell() {
        const user = this.getUser();
        const frameColor = this.getFrameColor(user.frame);

        return `
        <div class="profile-layout-new" style="display: flex; min-height: 100vh; background: #0a0a0c; color: #f8fafc; font-family: 'Outfit', 'Inter', sans-serif;">
            <!-- SIDEBAR NAVIGATION -->
            <div class="profile-sidebar" style="width: 320px; background: rgba(15, 15, 20, 0.8); backdrop-filter: blur(40px); border-right: 1px solid rgba(255,255,255,0.03); display: flex; flex-direction: column; position: sticky; top: 0; height: 100vh; z-index: 10; overflow-y: auto; overflow-x: hidden;">
                <div style="padding: 60px 30px; text-align: center;">
                    <div style="position: relative; display: inline-block; padding: 10px;">
                        ${this.renderAvatar(user, 140)}
                        <div style="position: absolute; bottom: 15px; right: 15px; width: 28px; height: 28px; border-radius: 50%; background: #10b981; border: 4px solid #111114; z-index: 2;" title="Çevrimiçi"></div>
                    </div>
                    
                    <h2 style="margin: 25px 0 8px; font-size: 1.8rem; font-weight: 900; color: #fff; letter-spacing: -1px; display: flex; align-items: center; justify-content: center; gap: 8px;">
                        ${user.username}
                        ${(user.isVerified || user.role === 'admin' || user.role === 'moderator') ? '<i class="fa-solid fa-circle-check" style="color: #3b82f6; font-size: 1.25rem;" title="Doğrulanmış Hesap"></i>' : ''}
                    </h2>
                    
                    <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap; margin-top: 15px;">
                        <span class="modern-badge"><i class="fa-solid fa-user-tag"></i> ${this.getRoleText(user.role)}</span>
                        ${this.isVip(user) ? `
                            <span class="modern-badge" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; border: none; box-shadow: 0 4px 15px rgba(245, 158, 11, 0.3);">
                                <i class="fa-solid fa-crown"></i> VIP Üye
                            </span>
                            ${user.vipStatus?.expiresAt ? `
                                <div style="font-size: 0.75rem; color: #f59e0b; margin-top: 8px; font-weight: 700; background: rgba(245,158,11,0.1); padding: 4px 10px; border-radius: 8px;">
                                    Bitiş: ${new Date(user.vipStatus.expiresAt).toLocaleDateString()} 
                                    (${Math.ceil((user.vipStatus.expiresAt - Date.now()) / (1000 * 60 * 60 * 24))} Gün)
                                </div>
                            ` : ''}
                        ` : ''}
                    </div>

                    <!-- Display Badges Section -->
                    ${(user.displayBadges || user.badges || []).length > 0 ? `
                        <div style="display: flex; gap: 8px; justify-content: center; margin-top: 15px; flex-wrap: wrap;">
                            ${(user.displayBadges || user.badges || []).map(badge => `
                                <div title="${badge}" style="width: 38px; height: 38px; background: rgba(255,255,255,0.05); border-radius: 10px; display: flex; align-items: center; justify-content: center; border: 1px solid rgba(255,255,255,0.1); font-size: 1.1rem; color: #fbbf24;">
                                    <i class="fa-solid ${Achievements?.getBadgeIcon ? Achievements.getBadgeIcon(badge) : 'fa-award'}"></i>
                                </div>
                            `).join('')}
                        </div>
                    ` : ''}

                    <!-- Level & Coins Section -->
                    <div style="margin-top: 20px; background: linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(168, 85, 247, 0.1)); padding: 20px; border-radius: 24px; border: 1px solid rgba(139, 92, 246, 0.2); position: relative; overflow: hidden;">
                        <div style="position: absolute; top: -20px; right: -20px; width: 60px; height: 60px; background: rgba(139, 92, 246, 0.1); border-radius: 50%; filter: blur(20px);"></div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <div style="width: 32px; height: 32px; background: linear-gradient(135deg, #6366f1, #a855f7); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.8rem; font-weight: 800; box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);">
                                    ${Gamification && Gamification.getLevel ? Gamification.getLevel(user.stats?.xp || 0) : (user.stats?.level || 1)}
                                </div>
                                <span style="font-size: 0.95rem; font-weight: 800; color: #fff; letter-spacing: 0.5px;">SEVİYE</span>
                            </div>
                            <div style="font-size: 0.9rem; font-weight: 700; color: #fbbf24; background: rgba(251, 191, 36, 0.1); padding: 4px 10px; border-radius: 10px;">
                                <i class="fa-solid fa-coins" style="margin-right: 4px;"></i>${user.stats?.coins || 0}
                            </div>
                        </div>
                        <div style="height: 10px; background: rgba(255, 255, 255, 0.05); border-radius: 20px; overflow: hidden; margin-bottom: 8px; border: 1px solid rgba(255,255,255,0.03);">
                            <div style="height: 100%; background: linear-gradient(90deg, #6366f1, #a855f7, #ec4899); border-radius: 20px; width: ${Gamification && Gamification.getLevelProgress ? Gamification.getLevelProgress(user.stats?.xp || 0) : 0}%; transition: width 1s cubic-bezier(0.34, 1.56, 0.64, 1); box-shadow: 0 0 15px rgba(168, 85, 247, 0.4);"></div>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: #94a3b8; font-weight: 600;">
                            <span>${user.stats?.xp || 0} XP</span>
                            <span>Sonraki: ${Gamification && Gamification.getXpToNextLevel ? Gamification.getXpToNextLevel(user.stats?.xp || 0) : '?'}</span>
                        </div>
                    </div>

                    <div style="margin-top: 20px; display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                         <div style="background: rgba(255,255,255,0.03); padding: 12px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.05);">
                            <div style="font-size: 1.2rem; font-weight: 800; color: #fff;">${user.watchlist?.length || 0}</div>
                            <div style="font-size: 0.7rem; color: #64748b; font-weight: 700; text-transform: uppercase;">Liste</div>
                         </div>
                         <div style="background: rgba(255,255,255,0.03); padding: 12px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.05);">
                            <div style="font-size: 1.2rem; font-weight: 800; color: #fff;">${user.friends?.length || 0}</div>
                            <div style="font-size: 0.7rem; color: #64748b; font-weight: 700; text-transform: uppercase;">Arkadaş</div>
                         </div>
                    </div>
                </div>

                <nav style="flex: 1; padding: 0 20px;">
                    <button class="p-nav-btn active" data-tab="overview" onclick="UserProfile.switchTab('overview')">
                        <i class="fa-solid fa-rocket"></i> <span>Genel Bakış</span>
                    </button>
                    <button class="p-nav-btn" data-tab="friends" onclick="UserProfile.switchTab('friends')">
                        <i class="fa-solid fa-users"></i> <span>Arkadaşlar</span>
                    </button>
                    <button class="p-nav-btn" data-tab="posts" onclick="UserProfile.switchTab('posts')">
                        <i class="fa-solid fa-rss"></i> <span>Paylaşımlarım</span>
                    </button>
                    <button class="p-nav-btn" data-tab="quests" onclick="UserProfile.switchTab('quests')">
                        <i class="fa-solid fa-scroll"></i> <span>Görevler</span>
                    </button>
                    ${this.isOwnProfile() ? `
                    <button class="p-nav-btn" data-tab="gamification" onclick="UserProfile.switchTab('gamification')">
                        <i class="fa-solid fa-box-open" style="color: #a78bfa;"></i> <span>Envanter</span>
                    </button>
                    <button class="p-nav-btn" data-tab="messages" onclick="App.router('social'); setTimeout(() => SocialFeed.switchTab('messages', document.querySelector('.social-hub-tab[data-tab=messages]')), 500)">
                        <i class="fa-solid fa-comment-dots"></i> <span>Mesajlar</span>
                    </button>
                    <button class="p-nav-btn" data-tab="lists" onclick="UserProfile.switchTab('lists')">
                        <i class="fa-solid fa-list-ul"></i> <span>Listelerim</span>
                    </button>
                    <button class="p-nav-btn" data-tab="history" onclick="UserProfile.switchTab('history')">
                        <i class="fa-solid fa-clock-rotate-left"></i> <span>Geçmiş</span>
                    </button>
                    <button class="p-nav-btn" data-tab="analytics" onclick="UserProfile.switchTab('analytics')">
                        <i class="fa-solid fa-chart-line"></i> <span>İstatistikler</span>
                    </button>
                    <button class="p-nav-btn" onclick="ShopSystem.open()">
                        <i class="fa-solid fa-store" style="color: #10b981;"></i> <span>Dramic Market</span>
                    </button>
                    <button class="p-nav-btn" data-tab="requests" onclick="UserProfile.switchTab('requests')">
                        <i class="fa-solid fa-headset"></i> <span>Destek Taleplerim</span>
                    </button>
                    <button class="p-nav-btn" data-tab="blocked" onclick="UserProfile.switchTab('blocked')">
                        <i class="fa-solid fa-ban"></i> <span>Engellenenler</span>
                    </button>
                    <div style="height: 1px; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.05), transparent); margin: 20px 10px;"></div>
                    <button class="p-nav-btn" data-tab="settings" onclick="UserProfile.switchTab('settings')">
                        <i class="fa-solid fa-sliders"></i> <span>Profil Düzenle</span>
                    </button>
                    ` : `
                    <div style="margin-top: 25px; display: flex; flex-direction: column; gap: 12px; padding: 0 10px;">
                        <button class="p-nav-btn" data-tab="collection" onclick="UserProfile.switchTab('collection')" style="justify-content: center; background: rgba(251,191,36,0.05); border: 1px solid rgba(251,191,36,0.1); color: #fbbf24;">
                            <i class="fa-solid fa-id-badge"></i> <span>Kart Koleksiyonu</span>
                        </button>
                        <button class="p-nav-btn primary-msg-btn" onclick="SocialFeed.startChat && SocialFeed.startChat('${user.id}'); App.router('social'); setTimeout(() => SocialFeed.switchTab('messages', document.querySelector('.social-hub-tab[data-tab=messages]')), 500)" 
                                style="background: linear-gradient(135deg, #7c3aed, #6366f1); color: white; box-shadow: 0 4px 20px rgba(124, 58, 237, 0.3); border: none; justify-content: center;">
                            <i class="fa-solid fa-paper-plane"></i> <span>Mesaj Gönder</span>
                        </button>
                        <button class="p-nav-btn" onclick="UserProfile.sendFriendRequest('${user.id}')" 
                                style="background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.2); color: #10b981; justify-content: center;">
                            <i class="fa-solid fa-user-plus"></i> <span>Arkadaş Ekle</span>
                        </button>
                    </div>
                    `}
                </nav>

                <div style="padding: 30px; border-top: 1px solid rgba(255,255,255,0.05);">
                    <button onclick="App.router('home')" style="width: 100%; padding: 14px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; color: #94a3b8; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; font-weight: 700; transition: all 0.3s; font-size: 0.9rem;">
                        <i class="fa-solid fa-arrow-left"></i> Platforma Dön
                    </button>
                </div>
            </div>
            <button class="profile-mobile-toggle" onclick="UserProfile.toggleSidebar()">
                <i class="fa-solid fa-bars"></i>
            </button>

            <!-- MAIN CONTENT -->
            <div class="profile-content-main" style="flex: 1; padding: 40px 80px; overflow-y: auto; background: #070709; position: relative;">
                <div style="position: absolute; top: 0; left: 0; width: 100%; height: 600px; background: radial-gradient(circle at 50% 0%, rgba(139, 92, 246, 0.1), transparent 70%); pointer-events: none;"></div>
                <div id="profile-tab-content" style="max-width: 1100px; margin: 0 auto; position: relative; z-index: 1;">
                    <!-- Content injected here -->
                </div>
            </div>
        </div>
        ${this.getStyles()}
        `;
    },

    getStyles() {
        return `
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;800;900&display=swap');
            
            .p-nav-btn {
                width: 100%; display: flex; align-items: center; gap: 16px; padding: 16px 24px;
                margin-bottom: 6px; background: transparent; border: none; color: #94a3b8;
                cursor: pointer; border-radius: 18px; font-weight: 700; font-size: 0.95rem;
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); text-align: left;
            }
            .p-nav-btn:hover { background: rgba(255, 255, 255, 0.03); color: #fff; transform: translateX(5px); }
            .p-nav-btn.active { background: rgba(139, 92, 246, 0.12); color: #a78bfa; box-shadow: inset 0 0 0 1px rgba(139, 92, 246, 0.2); }
            .p-nav-btn.active i { color: #c084fc; }
            .profile-content-main::-webkit-scrollbar, .profile-sidebar::-webkit-scrollbar { width: 6px; }
            .profile-content-main::-webkit-scrollbar-thumb, .profile-sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.05); border-radius: 10px; }
            
            .stat-card-new {
                background: linear-gradient(145deg, rgba(255, 255, 255, 0.03), rgba(255, 255, 255, 0.01));
                border: 1px solid rgba(255, 255, 255, 0.04);
                border-radius: 30px; padding: 35px; display: flex; flex-direction: column; gap: 15px;
                transition: all 0.4s; backdrop-filter: blur(20px);
            }
            .stat-card-new:hover {
                transform: translateY(-5px); border-color: rgba(139, 92, 246, 0.4);
            }
            .form-input-new {
                width: 100%; padding: 12px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); 
                border-radius: 8px; color: #fff; font-family: inherit; font-size: 0.95rem; outline: none;
            }
            .form-input-new:focus { border-color: #8b5cf6; }
            
            }
            
            /* Mobile Adjustments */
            @media (max-width: 1024px) {
                .profile-layout-new { flex-direction: column; }
                .profile-sidebar { 
                    width: 100% !important; 
                    height: auto !important; 
                    position: relative !important; 
                    border-right: none !important;
                    border-bottom: 1px solid rgba(255,255,255,0.05);
                    padding-bottom: 20px !important;
                }
                .profile-sidebar nav { display: none; padding: 10px 20px; }
                .profile-sidebar nav.show { display: block; }
                .profile-content-main { padding: 30px 20px !important; }
                .profile-mobile-toggle {
                    display: block !important;
                    position: fixed;
                    bottom: 80px;
                    right: 20px;
                    width: 50px;
                    height: 50px;
                    border-radius: 50%;
                    background: var(--p-accent);
                    color: white;
                    border: none;
                    z-index: 100;
                    box-shadow: 0 4px 15px var(--p-accent-glow);
                }
            }
            .profile-mobile-toggle { display: none; }

            .switch-modern { position: relative; display: inline-block; width: 50px; height: 26px; }
            .switch-modern input { opacity: 0; width: 0; height: 0; }
            .slider-modern { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(255,255,255,0.1); transition: .4s; border-radius: 34px; border: 1px solid rgba(255,255,255,0.05); }
            .slider-modern:before { position: absolute; content: ""; height: 18px; width: 18px; left: 4px; bottom: 3px; background-color: #fff; transition: .4s; border-radius: 50%; }
            input:checked + .slider-modern { background-color: #8b5cf6; }
            input:checked + .slider-modern:before { transform: translateX(24px); }
        </style>`;
    },

    switchTab(tab) {
        this.activeTab = tab;
        document.querySelectorAll('.p-nav-btn').forEach(btn => {
            if (btn.dataset.tab) btn.classList.toggle('active', btn.dataset.tab === tab);
        });

        const container = document.getElementById('profile-tab-content');
        if (!container) return;

        container.style.opacity = '0';
        container.style.transform = 'translateY(10px)';

        setTimeout(() => {
            if (tab === 'overview') this.renderOverview(container);
            else if (tab === 'friends') this.renderFriends(container);
            else if (tab === 'quests') this.renderQuests(container);
            else if (tab === 'posts') this.renderSocialPosts(container);
            else if (tab === 'collection') this.renderActorCards(container);
            else if (tab === 'gamification') this.renderGamificationTab(container);
            else if (tab === 'messages' && this.isOwnProfile()) { App.router('social'); return; }
            else if (tab === 'lists' && this.isOwnProfile()) this.renderLists(container);
            else if (tab === 'history' && this.isOwnProfile()) this.renderHistory(container);
            else if (tab === 'analytics' && this.isOwnProfile()) this.renderAnalytics(container);
            else if (tab === 'requests' && this.isOwnProfile()) this.renderRequests(container);
            else if (tab === 'blocked' && this.isOwnProfile()) this.renderBlockedUsers(container);
            else if (tab === 'settings' && this.isOwnProfile()) this.renderSettings(container);

            container.style.transition = 'all 0.3s ease';
            container.style.opacity = '1';
            container.style.transform = 'translateY(0)';
        }, 200);
    },

    toggleSidebar() {
        const nav = document.querySelector('.profile-sidebar nav');
        if (nav) nav.classList.toggle('show');
    },

    // --- RENDERERS ---

    renderOverview(container) {
        const user = this.getUser();
        const activity = typeof ActivityFeed !== 'undefined' ? ActivityFeed.getUserActivity(user.id).slice(0, 10) : [];
        
        container.innerHTML = `
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px;">
                <div style="display: flex; flex-direction: column; gap: 30px;">
                    <!-- Bio Card -->
                    <div class="stat-card-new" style="background: linear-gradient(135deg, rgba(15, 15, 20, 0.4), rgba(139, 92, 246, 0.03)); border: 1px solid rgba(255,255,255,0.05);">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <h3 style="font-size: 1.4rem; font-weight: 800; color: #fff; margin:0;"><i class="fa-solid fa-address-card" style="color:#8b5cf6; margin-right:10px;"></i>Hakkında</h3>
                            <div style="display: flex; gap: 12px;">
                                ${user.socialLinks?.instagram ? `<a href="${user.socialLinks.instagram}" target="_blank" class="social-icon-btn insta"><i class="fa-brands fa-instagram"></i></a>` : ''}
                                ${user.socialLinks?.twitter ? `<a href="${user.socialLinks.twitter}" target="_blank" class="social-icon-btn twitter"><i class="fa-brands fa-twitter"></i></a>` : ''}
                                ${user.socialLinks?.discord ? `<a href="${user.socialLinks.discord}" target="_blank" class="social-icon-btn discord"><i class="fa-brands fa-discord"></i></a>` : ''}
                            </div>
                        </div>
                        <p style="color: #cbd5e1; line-height: 1.7; font-size: 1.05rem; font-family:'Inter'; font-weight:400; font-style: italic;">
                            ${user.bio || 'Bu kullanıcı henüz gizemini koruyor... (Biyografi eklenmemiş)'}
                        </p>
                    </div>

                    <!-- Achievements & Karma -->
                    <div class="stat-card-new pulse-border">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                            <div>
                                <h3 style="font-size: 1.4rem; font-weight: 800; color: #fff; margin: 0;">Başarımlar & İtibar</h3>
                                <div style="font-size: 0.8rem; color: #94a3b8; margin-top: 4px;">Topluluk içerisindeki etkinliğin özeti</div>
                            </div>
                            <div style="display:flex; align-items:center; gap:8px; background:rgba(245, 158, 11, 0.1); padding:8px 16px; border-radius:14px; border:1px solid rgba(245, 158, 11, 0.2);">
                                <i class="fa-solid fa-fire" style="color:#f59e0b;"></i>
                                <span style="font-weight:900; color:#f59e0b; font-size:1.1rem;">${user.socialKarma || 0}</span>
                            </div>
                        </div>
                        
                        <div style="display: flex; gap: 15px; overflow-x: auto; padding: 5px 0 15px;" class="custom-scrollbar hide-scroll">
                            ${Achievements?.getEarnedAchievements ? Achievements.getEarnedAchievements(user).slice(0, 8).map(ach => `
                                <div class="achievement-mini-orb" title="${ach.name}: ${ach.desc}">
                                    <i class="fa-solid ${ach.icon}"></i>
                                </div>
                            `).join('') : '<p style="color: #64748b;">Henüz başarım yok.</p>'}
                            <div class="achievement-mini-orb more" onclick="Achievements.showAllAchievements('${user.id}')">
                                <i class="fa-solid fa-ellipsis"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activity Stream -->
                    <div class="stat-card-new" style="padding: 0; overflow: hidden; border: 1px solid rgba(255,255,255,0.03);">
                        <div style="padding: 25px 30px; border-bottom: 1px solid rgba(255,255,255,0.03); display:flex; justify-content:space-between; align-items:center;">
                            <h3 style="font-size: 1.2rem; font-weight: 800; color: #fff; margin: 0;"><i class="fa-solid fa-bolt" style="color:#fbbf24; margin-right:10px;"></i>Son Aktivite</h3>
                        </div>
                        <div style="max-height: 400px; overflow-y: auto;" class="custom-scrollbar">
                           ${activity.length > 0 ? ActivityFeed.renderList(activity) : '<div style="padding:40px; text-align:center; color:#475569;">Henüz bir iz bırakılmamış.</div>'}
                        </div>
                    </div>
                </div>

                <!-- Right Column: Level & Social Controls -->
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <div class="stat-card-new level-banner" style="text-align: center; padding: 45px 20px; position:relative; overflow:hidden;">
                         <div class="level-glow-bg"></div>
                         <div class="level-circle">
                            <span class="level-num">${Gamification?.getLevel ? Gamification.getLevel(user.stats?.xp || 0) : (user.stats?.level || 1)}</span>
                         </div>
                         <div style="color: #fff; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; margin-top:15px; font-size:1rem;">Mastery Level</div>
                         <div style="font-size:0.8rem; color:rgba(255,255,255,0.6); margin-top:5px;">Sıradaki seviye için ${Gamification?.getXpToNextLevel ? Gamification.getXpToNextLevel(user.stats?.xp || 0) : '?'} XP</div>
                    </div>

                    ${!this.isOwnProfile() ? `
                    <div class="stat-card-new action-grid">
                        <button class="action-btn-p msg" onclick="UserProfile.startConversation('${user.id}')">
                            <i class="fa-solid fa-paper-plane"></i> Mesaj Gönder
                        </button>
                        ${this.renderFriendButton(user)}
                        <button class="action-btn-p tip" onclick="DonationSystem.openModal('${user.id}', '${user.username}')">
                            <i class="fa-solid fa-mug-hot"></i> Kahve Ismarla
                        </button>
                        <div style="grid-column: span 2; height:1px; background:rgba(255,255,255,0.05); margin:10px 0;"></div>
                        <button class="action-btn-p block" onclick="UserProfile.blockUser('${user.id}')" style="grid-column: span 2; background:rgba(239, 68, 68, 0.05); color:#ef4444; border-color:rgba(239, 68, 68, 0.1);">
                            <i class="fa-solid fa-user-slash"></i> Kullanıcıyı Engelle
                        </button>
                    </div>
                    ` : ''}

                    <div class="stat-card-new">
                        <h4 style="color:#94a3b8; font-size:0.8rem; text-transform:uppercase; letter-spacing:1px; margin-bottom:20px;">Koleksiyon Özeti</h4>
                        <div style="display:flex; flex-direction:column; gap:12px;">
                            <div class="summary-item">
                                <span class="label"><i class="fa-solid fa-eye"></i> İzleme</span>
                                <span class="val">${(user.stats?.watchedCount || 0)}</span>
                            </div>
                            <div class="summary-item">
                                <span class="label"><i class="fa-solid fa-comment"></i> Yorum</span>
                                <span class="val">${(user.stats?.commentCount || 0)}</span>
                            </div>
                            <div class="summary-item">
                                <span class="label"><i class="fa-solid fa-star"></i> Puanlama</span>
                                <span class="val">${(user.stats?.ratingCount || 0)}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                .social-icon-btn {
                    width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center;
                    background: rgba(255,255,255,0.05); color: #94a3b8; transition: all 0.3s; font-size: 0.9rem; border: 1px solid rgba(255,255,255,0.05);
                }
                .social-icon-btn:hover { transform: translateY(-3px); color: #fff; background: rgba(255,255,255,0.1); }
                .insta:hover { background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888); }
                .twitter:hover { background: #1da1f2; }
                .discord:hover { background: #5865f2; }

                .achievement-mini-orb {
                    min-width: 54px; height: 54px; border-radius: 16px; background: rgba(139, 92, 246, 0.08);
                    border: 1px solid rgba(139, 92, 246, 0.2); display: flex; align-items: center; justify-content: center;
                    font-size: 1.3rem; color: #a78bfa; transition: all 0.3s; cursor: pointer;
                }
                .achievement-mini-orb:hover { transform: scale(1.1) rotate(5deg); background: rgba(139, 92, 246, 0.15); border-color: #a78bfa; }
                .achievement-mini-orb.more { color: #64748b; background: rgba(255,255,255,0.03); border-color: rgba(255,255,255,0.1); }

                .level-banner { border: 1px solid rgba(139, 92, 246, 0.3); background: rgba(15,15,22,0.6); }
                .level-glow-bg { position: absolute; top: -50%; left: -50%; width: 200%; height: 200%; background: radial-gradient(circle, rgba(139, 92, 246, 0.1) 0%, transparent 60%); pointer-events: none; }
                .level-circle { width: 100px; height: 100px; border-radius: 50%; border: 4px solid #8b5cf6; margin: 0 auto; display: flex; align-items: center; justify-content: center; position: relative; box-shadow: 0 0 30px rgba(139, 92, 246, 0.3); z-index: 1; }
                .level-num { font-size: 3rem; font-weight: 950; color: #fff; text-shadow: 0 0 15px rgba(139, 92, 246, 0.5); }
                
                .action-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; border: 1px solid rgba(255,255,255,0.03); }
                .action-btn-p { 
                    padding: 12px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08); background: rgba(255,255,255,0.02); 
                    color: #fff; font-weight: 700; font-size: 0.85rem; cursor: pointer; transition: all 0.2s; display: flex; align-items: center; justify-content: center; gap: 8px;
                }
                .action-btn-p:hover { transform: translateY(-2px); background: rgba(255,255,255,0.05); }
                .action-btn-p.msg { background: #8b5cf6; border: none; grid-column: span 2; box-shadow: 0 4px 15px rgba(139,92,246,0.3); }
                .action-btn-p.msg:hover { background: #7c3aed; }
                
                .summary-item { display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; background: rgba(255,255,255,0.02); border-radius: 10px; }
                .summary-item .label { color: #64748b; font-size: 0.85rem; display: flex; align-items: center; gap: 8px; }
                .summary-item .val { color: #fff; font-weight: 800; }
                .pulse-border { animation: pulseBorder 3s infinite; }
                @keyframes pulseBorder { 0% { border-color: rgba(139, 92, 246, 0.1); } 50% { border-color: rgba(139, 92, 246, 0.4); } 100% { border-color: rgba(139, 92, 246, 0.1); } }
            </style>
        `;
    },

    renderFriends(container) {
        const user = this.getUser();

        let html = `
            <div style="margin-bottom: 30px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2 style="font-size: 1.8rem; font-weight: 800; color: #fff; margin: 0;">Sosyal</h2>
                </div>
                
                <!-- User Search Bar -->
                <div class="profile-search-container" style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 15px; margin-bottom: 25px; border: 1px solid rgba(255,255,255,0.05);">
                    <div style="position: relative;">
                        <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #64748b;"></i>
                        <input type="text" id="user-search-input" placeholder="Kullanıcı ara (örn: dramicbox_user)..." 
                            style="width: 100%; padding: 12px 12px 12px 45px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; color: #fff; outline: none;"
                            onkeyup="if(event.key === 'Enter') UserProfile.performUserSearch()">
                    </div>
                    <div id="user-search-results" style="margin-top: 15px; display: none;"></div>
                </div>
            </div>`;

        if (this.isOwnProfile() && user.friendRequests?.length > 0) {
            html += `
            <div style="margin-bottom: 30px;">
                <h3 style="color: #fff; margin-bottom: 15px; display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-user-plus" style="color: #8b5cf6;"></i> İstekler (${user.friendRequests.length})
                </h3>
                <div style="display: grid; gap: 10px;">
                    ${user.friendRequests.map(req => `
                        <div style="background: rgba(139, 92, 246, 0.05); padding: 15px; border-radius: 12px; display: flex; justify-content: space-between; align-items: center; border: 1px solid rgba(139, 92, 246, 0.1);">
                            <div style="display: flex; gap: 12px; align-items: center; cursor: pointer;" onclick="App.router('profile', '${req.fromUserId}')">
                                ${this.renderAvatar({ id: req.fromUserId, username: req.fromUsername }, 40)}
                                <span style="font-weight: 600; color: #fff;">${req.fromUsername}</span>
                            </div>
                            <div style="display: flex; gap: 10px;">
                                <button onclick="UserProfile.acceptFriend('${req.fromUserId}')" style="background: #10b981; border: none; color: white; padding: 8px 15px; border-radius: 8px; font-weight: 600; cursor: pointer;">Kabul Et</button>
                                <button onclick="UserProfile.rejectFriend('${req.fromUserId}')" style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); color: #ef4444; padding: 8px 15px; border-radius: 8px; font-weight: 600; cursor: pointer;">Reddet</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>`;
        }

        const friends = user.friends || [];
        html += `<h3 style="color: #fff; margin-bottom: 15px;">Arkadaşlar (${friends.length})</h3>`;

        if (friends.length === 0) {
            html += `<div style="text-align: center; padding: 50px; color: #64748b; background: rgba(255,255,255,0.02); border-radius: 12px; border: 1px dashed rgba(255,255,255,0.1);">Henüz arkadaş eklenmemiş.</div>`;
        } else {
            html += `
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;">
                ${friends.map(fid => {
                const f = State.data.users.find(u => u.id === fid);
                if (!f) return '';
                return `
                    <div style="background: rgba(255,255,255,0.03); padding: 20px; border-radius: 16px; text-align: center; cursor: pointer; border: 1px solid rgba(255,255,255,0.05); transition: all 0.3s;" 
                         onmouseover="this.style.background='rgba(255,255,255,0.06)'; this.style.borderColor='rgba(139, 92, 246, 0.3)'" 
                         onmouseout="this.style.background='rgba(255,255,255,0.03)'; this.style.borderColor='rgba(255,255,255,0.05)'"
                         onclick="App.router('profile', '${f.id}')">
                         ${this.renderAvatar(f, 60)}
                         <div style="margin-top: 12px; font-weight: 700; color: #fff;">${f.username}</div>
                         <div style="font-size: 0.8rem; color: #94a3b8; margin-top: 4px;">${this.getRoleText(f.role)}</div>
                    </div>`;
            }).join('')}
            </div>`;
        }

        container.innerHTML = html;
    },

    // ==================== SOCIAL POSTS TAB ====================
    renderSocialPostsWithSort(sortType) {
        const container = document.getElementById('profile-content-area');
        if (container) this.renderSocialPosts(container, sortType);
    },

    renderSocialPosts(container, sortType = 'latest') {
        const user = this.getUser();
        const userId = user.id;
        const allPosts = State.data.socialPosts || [];
        let userPosts = allPosts.filter(p => p.userId === userId);

        if (sortType === 'popular') {
            userPosts.sort((a, b) => {
                const scoreA = (a.likes?.length || 0) + (a.comments?.length || 0) + (a.tips || 0);
                const scoreB = (b.likes?.length || 0) + (b.comments?.length || 0) + (b.tips || 0);
                return scoreB - scoreA;
            });
        } else {
            userPosts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        }

        let html = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; flex-wrap: wrap; gap: 15px;">
                <h2 style="font-size: 1.8rem; font-weight: 800; color: #fff; margin: 0;">
                    <i class="fa-solid fa-rss" style="color:#a78bfa;"></i> Paylaşımlar
                </h2>
                <div style="display: flex; gap: 10px; background: rgba(255,255,255,0.03); padding: 5px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                    <button onclick="UserProfile.renderSocialPostsWithSort('latest')" 
                            style="padding: 6px 15px; border-radius: 8px; border: none; font-size: 0.85rem; font-weight: 700; cursor: pointer; transition: all 0.3s;
                            ${sortType === 'latest' ? 'background: #8b5cf6; color: white;' : 'background: transparent; color: #94a3b8;'}">
                        Son Eklenen
                    </button>
                    <button onclick="UserProfile.renderSocialPostsWithSort('popular')" 
                            style="padding: 6px 15px; border-radius: 8px; border: none; font-size: 0.85rem; font-weight: 700; cursor: pointer; transition: all 0.3s;
                            ${sortType === 'popular' ? 'background: #f59e0b; color: white;' : 'background: transparent; color: #94a3b8;'}">
                        Popüler
                    </button>
                </div>
                ${this.isOwnProfile() ? `
                <button onclick="App.router('social')" style="background: linear-gradient(135deg,#7c3aed,#6d28d9); border: none; color: white; padding: 10px 20px; border-radius: 12px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 15px rgba(124,58,237,0.3); font-family:'Inter',sans-serif;">
                    <i class="fa-solid fa-plus"></i> Yeni Paylaşım
                </button>` : ''}
            </div>
        `;

        if (userPosts.length === 0) {
            html += `
                <div style="text-align:center; padding:60px 20px; background:rgba(255,255,255,0.02); border-radius:20px; border:1px dashed rgba(255,255,255,0.08);">
                    <i class="fa-solid fa-satellite-dish" style="font-size:3rem; color:#475569; margin-bottom:16px;"></i>
                    <h3 style="color:#94a3b8; font-weight:700; margin-bottom:8px;">Henüz paylaşım yok</h3>
                    ${this.isOwnProfile() ? '<p style="color:#64748b;">Sosyal Hub\'dan ilk paylaşımını yap!</p>' : '<p style="color:#64748b;">Bu kullanıcı henüz bir şey paylaşmamış.</p>'}
                </div>`;
        } else {
            html += `<div style="display: flex; flex-direction: column; gap: 16px;">`;
            userPosts.forEach(post => {
                const timeStr = this.formatTimeShort(post.createdAt);
                const likeCount = post.likes?.length || 0;
                const commentCount = post.comments?.length || 0;
                const isLiked = post.likes?.includes(State.currentUser?.id);
                const content = (post.text || '').replace(/#([a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+)/g, '<span style="color:#a78bfa; font-weight:600;">#$1</span>')
                    .replace(/@([a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+)/g, '<span style="color:#60a5fa; font-weight:600;">@$1</span>');

                let mediaHtml = '';
                if (post.mediaUrl) {
                    if (post.mediaType === 'video') {
                        mediaHtml = `<video src="${post.mediaUrl}" controls playsinline style="width:100%; border-radius:14px; max-height:400px; margin-top:12px;"></video>`;
                    } else {
                        mediaHtml = `<img src="${post.mediaUrl}" style="width:100%; border-radius:14px; max-height:400px; object-fit:cover; margin-top:12px;">`;
                    }
                }

                let pollHtml = '';
                if (post.poll) {
                    const totalVotes = post.poll.options.reduce((s, o) => s + (o.votes || 0), 0);
                    pollHtml = `<div style="margin-top:12px; padding:14px; background:rgba(255,255,255,0.02); border-radius:14px; border:1px solid rgba(255,255,255,0.06);">
                        <div style="font-weight:700; color:#fff; margin-bottom:10px;">${post.poll.question}</div>
                        ${post.poll.options.map(o => {
                        const pct = totalVotes > 0 ? Math.round((o.votes / totalVotes) * 100) : 0;
                        return `<div style="position:relative; padding:8px 12px; margin-bottom:6px; background:rgba(255,255,255,0.03); border-radius:8px; overflow:hidden;">
                                <div style="position:absolute; left:0; top:0; height:100%; width:${pct}%; background:rgba(124,58,237,0.15); border-radius:8px;"></div>
                                <div style="position:relative; display:flex; justify-content:space-between;">
                                    <span style="color:#e2e8f0; font-size:0.85rem;">${o.text}</span>
                                    <span style="color:#a78bfa; font-weight:600; font-size:0.85rem;">${pct}%</span>
                                </div>
                            </div>`;
                    }).join('')}
                        <div style="font-size:0.75rem; color:#64748b; margin-top:6px;"><i class="fa-solid fa-chart-bar"></i> ${totalVotes} oy</div>
                    </div>`;
                }

                let sharedHtml = '';
                if (post.sharedContent) {
                    const sc = post.sharedContent;
                    sharedHtml = `<div style="margin-top:12px; display:flex; gap:12px; padding:12px; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:14px; cursor:pointer;" onclick="App.router('detail', '${sc.seriesId}')">
                        <img src="${sc.poster || 'assets/logo.png'}" style="width:50px; height:70px; border-radius:8px; object-fit:cover;">
                        <div><h4 style="color:#fff; font-weight:700; margin:0 0 4px;">${sc.title}</h4><p style="color:#94a3b8; font-size:0.8rem; margin:0;">${sc.subtitle || ''}</p></div>
                    </div>`;
                }

                html += `
                    <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:20px; padding:20px; transition:all 0.3s;" onmouseenter="this.style.borderColor='rgba(124,58,237,0.2)'" onmouseleave="this.style.borderColor='rgba(255,255,255,0.05)'">
                        ${post.isSpoiler ? `<div style="display:flex; align-items:center; gap:6px; color:#f59e0b; font-size:0.8rem; font-weight:600; margin-bottom:10px; padding:6px 12px; background:rgba(245,158,11,0.08); border-radius:8px; width:fit-content;"><i class="fa-solid fa-eye-slash"></i> Spoiler İçerik</div>` : ''}
                        ${content ? `<div style="color:#e2e8f0; line-height:1.6; font-size:0.95rem;">${content}</div>` : ''}
                        ${mediaHtml}
                        ${sharedHtml}
                        ${pollHtml}
                        <div style="display:flex; align-items:center; gap:20px; margin-top:14px; padding-top:14px; border-top:1px solid rgba(255,255,255,0.04);">
                            <span style="color:${isLiked ? '#ef4444' : '#64748b'}; font-size:0.85rem; display:flex; align-items:center; gap:6px;">
                                <i class="fa-${isLiked ? 'solid' : 'regular'} fa-heart"></i> ${likeCount}
                            </span>
                            <span style="color:#64748b; font-size:0.85rem; display:flex; align-items:center; gap:6px;">
                                <i class="fa-regular fa-comment"></i> ${commentCount}
                            </span>
                            <span style="color:#f59e0b; font-size:0.85rem; display:flex; align-items:center; gap:6px; cursor:pointer;" onclick="DonationSystem.openPostTipModal('${post.id}', '${user.username}')">
                                <i class="fa-solid fa-coins"></i> ${post.tips || 0}
                            </span>
                            <span style="color:#475569; font-size:0.75rem; margin-left:auto;">${timeStr}</span>
                        </div>
                    </div>
                `;
            });
            html += '</div>';
        }

        // Social Karma Stats
        html += `
            <div style="margin-top:30px; background:linear-gradient(135deg, rgba(124,58,237,0.08), rgba(236,72,153,0.08)); border:1px solid rgba(124,58,237,0.15); border-radius:20px; padding:24px; text-align:center;">
                <h3 style="color:#a78bfa; font-weight:800; margin-bottom:16px;"><i class="fa-solid fa-fire-flame-curved" style="color:#f59e0b;"></i> Sosyal İstatistikler</h3>
                <div style="display:grid; grid-template-columns: repeat(4,1fr); gap:14px;">
                    <div style="background:rgba(255,255,255,0.03); padding:16px; border-radius:14px;">
                        <div style="font-size:1.5rem; font-weight:800; color:#a78bfa;">${userPosts.length}</div>
                        <div style="font-size:0.75rem; color:#94a3b8;">Paylaşım</div>
                    </div>
                    <div style="background:rgba(255,255,255,0.03); padding:16px; border-radius:14px;">
                        <div style="font-size:1.5rem; font-weight:800; color:#ef4444;">${userPosts.reduce((s, p) => s + (p.likes?.length || 0), 0)}</div>
                        <div style="font-size:0.75rem; color:#94a3b8;">Beğeni</div>
                    </div>
                    <div style="background:rgba(255,255,255,0.03); padding:16px; border-radius:14px;">
                        <div style="font-size:1.5rem; font-weight:800; color:#10b981;">${userPosts.reduce((s, p) => s + (p.comments?.length || 0), 0)}</div>
                        <div style="font-size:0.75rem; color:#94a3b8;">Yorum</div>
                    </div>
                    <div style="background:rgba(255,255,255,0.03); padding:16px; border-radius:14px;">
                        <div style="font-size:1.5rem; font-weight:800; color:#f59e0b;">${user.socialKarma || 0}</div>
                        <div style="font-size:0.75rem; color:#94a3b8;">Karma</div>
                    </div>
                </div>
            </div>
        `;

        container.innerHTML = html;
    },

    async performUserSearch() {
        const input = document.getElementById('user-search-input');
        const resultsEl = document.getElementById('user-search-results');
        if (!input || !resultsEl) return;

        const query = input.value.trim().toLowerCase();
        if (query.length < 3) {
            resultsEl.style.display = 'none';
            return;
        }

        resultsEl.innerHTML = '<div style="color: #64748b; font-size: 0.9rem; padding: 10px;"><i class="fa-solid fa-spinner fa-spin"></i> Aranıyor...</div>';
        resultsEl.style.display = 'block';

        // Filter from users
        const results = State.data.users.filter(u =>
            u.username.toLowerCase().includes(query) && u.id !== State.currentUser?.id
        ).slice(0, 5);

        if (results.length === 0) {
            resultsEl.innerHTML = '<div style="color: #ef4444; font-size: 0.9rem; padding: 10px;">Kullanıcı bulunamadı.</div>';
            return;
        }

        resultsEl.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 8px;">
                ${results.map(u => `
                    <div class="search-result-item" style="display: flex; align-items: center; justify-content: space-between; padding: 12px; border-radius: 12px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.05);">
                        <div style="display: flex; gap: 12px; align-items: center; cursor: pointer;" onclick="App.router('profile', '${u.id}')">
                            ${this.renderAvatar(u, 40)}
                            <div>
                                <div style="color: #fff; font-weight: 600;">${u.username}</div>
                                <div style="font-size: 0.75rem; color: #94a3b8;">Lvl ${Gamification.getLevel(u.stats?.xp || 0)}</div>
                            </div>
                        </div>
                        <div>
                            ${this.renderFriendButton(u)}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    },

    renderActorCards(container) {
        const user = this.getUser();
        const cardIds = user.gamification?.cards || [];

        if (cardIds.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; padding: 60px 20px; color: #64748b; background: rgba(255,255,255,0.02); border-radius: 20px; border: 1px dashed rgba(255,255,255,0.1);">
                    <i class="fa-solid fa-id-card" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.2;"></i>
                    <h3 style="color: #fff; margin-bottom: 10px;">Henüz oyuncu kartı yok!</h3>
                    <p style="max-width: 400px; margin: 0 auto;">Sandıklar açarak veya diğer kullanıcılarla takas ederek K-Drama oyuncu kartlarını toplayabilirsin.</p>
                </div>
            `;
            return;
        }

        const configCards = window.Gamification?.config?.cards || [];

        container.innerHTML = `
            <div style="margin-bottom: 30px;">
                <h3 style="color: #fff; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-id-badge" style="color: #ffd700;"></i> 
                    Kart Koleksiyonu (${cardIds.length})
                </h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 20px;">
                    ${cardIds.map(cid => {
                        const card = configCards.find(c => c.id === cid);
                        if (!card) return '';
                        return `
                            <div class="actor-card-item rarity-${card.rarity}" style="position: relative; border-radius: 16px; overflow: hidden; background: #000; border: 2px solid ${card.rarity === 'legendary' ? '#fbbf24' : card.rarity === 'epic' ? '#8b5cf6' : card.rarity === 'rare' ? '#3b82f6' : '#94a3b8'}; aspect-ratio: 2/3; box-shadow: 0 5px 15px rgba(0,0,0,0.5); transition: transform 0.3s;" onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
                                <img src="${card.avatar}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 14px;">
                                <div style="position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(transparent, rgba(0,0,0,0.9)); padding: 15px 10px; text-align: center;">
                                    <div style="color: #fff; font-weight: 800; font-size: 0.95rem;">${card.name}</div>
                                    <div style="color: #fbbf24; font-size: 0.7rem; font-weight: 600; margin-top: 2px;">${card.kdrama}</div>
                                    <div style="color: #fff; font-size: 0.6rem; opacity: 0.7; text-transform: uppercase; margin-top: 4px;">${card.rarity.toUpperCase()} Card</div>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
    },

    renderGamificationTab(container) {
        if (!window.Gamification) {
            container.innerHTML = '<p>Gamification modülü yüklenemedi.</p>';
            return;
        }
        Gamification.initUserGamification();
        const user = this.getUser();
        const gamif = user.gamification || { cards: [], chests: { bronz: 0, gumus: 0, altin: 0, efsanevi: 0 }, lastFreeChestTime: 0 };
        const stats = user.stats || { coins: 0, level: 1, xp: 0 };
        const hasVip = user.badges?.includes('VIP') || user.role === 'admin' || user.isVip;

        // Calculate free chest status
        const cooldown = 12 * 60 * 60 * 1000;
        const diff = Date.now() - (gamif.lastFreeChestTime || 0);
        const isChestUnlocked = diff >= cooldown;

        let html = `
            <div style="max-width: 1000px; margin: 0 auto; display: flex; flex-direction: column; gap: 30px;">
                <!-- Header and Info -->
                <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 20px;">
                    <div>
                        <h2 style="font-size: 2rem; font-weight: 800; color: #fff; margin: 0; display: flex; align-items: center; gap: 12px;">
                            <i class="fa-solid fa-box-open" style="color: #a78bfa;"></i> Envanter
                        </h2>
                        <p style="color: #94a3b8; font-size: 0.95rem; margin: 5px 0 0 0;">Günlük sandıklarınız ve sahip olduğunuz sandıkları buradan açın. Kart koleksiyonunuzu yönetin.</p>
                    </div>
                </div>

                <!-- Main Grid: 12-Hour Chest & Owned Chests -->
                <div style="display: grid; grid-template-columns: 3fr 2fr; gap: 30px;">
                    <!-- 12-Hour Chest Portal Card -->
                    <div class="g-portal-card free-chest-portal rarity-${hasVip ? 'rare' : 'common'}" style="margin: 0; padding: 40px; border-radius: 24px; position: relative; overflow: hidden; background: rgba(255, 255, 255, 0.01); border: 1px solid rgba(255, 255, 255, 0.05); text-align: center;">
                        <div class="portal-light"></div>
                        <div style="font-size: 4.5rem; margin-bottom: 15px; filter: drop-shadow(0 0 20px rgba(167, 139, 250, 0.4));">🎁</div>
                        <h3 style="font-size: 1.7rem; font-weight: 900; color: #fff; margin: 0 0 10px 0;">12 Saatlik Ücretsiz Sandık</h3>
                        <p class="desc" style="font-size: 1rem; color: #cbd5e1; margin: 0 0 25px 0; line-height: 1.5;">
                            ${hasVip ? '👑 <span style="color:#fbbf24; font-weight:800;">VIP Ayrıcalığı:</span> Ücretsiz açımlarda yüksek oranda <b>Gümüş Sandık</b> ödülleri kazanırsınız!' : 'Standart Üye: Ücretsiz olarak <b>Bronz Sandık</b> açabilirsiniz. VIP üye olarak direkt <b>Gümüş Sandık</b> elde edebilirsiniz!'}
                        </p>
                        
                        <div class="action-wrap">
                            ${isChestUnlocked ? `
                                <button class="btn btn-primary pulse-btn" onclick="Gamification.openChest('${hasVip ? 'gumus' : 'bronz'}', true)" style="padding: 16px 45px; font-size: 1.15rem; border-radius: 16px; background: linear-gradient(135deg, #7c3aed, #6d28d9); border: none; font-weight: 800; color: #fff; cursor: pointer; box-shadow: 0 8px 25px rgba(124, 58, 237, 0.4);">
                                    <i class="fa-solid fa-gift"></i> Ücretsiz Sandığı Aç!
                                </button>
                            ` : `
                                <div class="timer-badge" style="display: inline-flex; align-items: center; gap: 8px; font-size: 1.1rem; padding: 12px 30px; background: rgba(0, 0, 0, 0.5); border-radius: 20px; border: 1px solid rgba(255, 255, 255, 0.1); color: #fff; font-weight: 800;">
                                    <i class="fa-solid fa-clock-rotate-left" style="color: #a78bfa; margin-right: 8px;"></i> Sonraki Açım: <span id="free-chest-countdown-timer">00:00:00</span>
                                </div>
                            `}
                        </div>
                    </div>

                    <!-- Inventory: Owned Chests -->
                    <div class="stat-card-new" style="display: flex; flex-direction: column; gap: 20px;">
                        <h3 style="font-size: 1.25rem; font-weight: 800; color: #fff; margin: 0; display: flex; align-items: center; gap: 10px;">
                            <i class="fa-solid fa-box" style="color: #a78bfa;"></i> Sandık Envanteri
                        </h3>
                        ${isChestUnlocked ? `
                            <div style="background:linear-gradient(135deg,rgba(124,58,237,0.15),rgba(236,72,153,0.1)); border:1px solid rgba(139,92,246,0.3); border-radius:16px; padding:14px; display:flex; justify-content:space-between; align-items:center;">
                                <div>
                                    <div style="font-weight:800; color:#fff;">🎁 Günlük Sandık Hazır</div>
                                    <div style="font-size:0.8rem; color:#a78bfa;">Envanterine düştü — hemen aç!</div>
                                </div>
                                <button class="btn btn-sm btn-primary" onclick="Gamification.openChest('${hasVip ? 'gumus' : 'bronz'}', true)" style="font-weight:800;">Aç</button>
                            </div>
                        ` : `
                            <div style="background:rgba(255,255,255,0.02); border:1px dashed rgba(255,255,255,0.08); border-radius:14px; padding:12px; font-size:0.85rem; color:#94a3b8;">
                                <i class="fa-solid fa-clock"></i> Günlük sandık envantere düşecek — kalan: <span id="free-chest-countdown-timer-inv">yükleniyor</span>
                            </div>
                        `}
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            ${Object.keys(Gamification.config.chests).map(key => {
                                const count = gamif.chests[key] || 0;
                                const def = Gamification.config.chests[key];
                                const sellValue = Math.round(def.price * 0.5);
                                return `
                                    <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); padding: 15px; border-radius: 16px; display: flex; justify-content: space-between; align-items: center;">
                                        <div>
                                            <div style="font-weight: 800; color: #fff; font-size: 0.95rem;">${def.name}</div>
                                            <div style="font-size: 0.8rem; color: #94a3b8; font-weight: 600; margin-top: 2px;">Adet: <span style="color: #a78bfa; font-weight:800;">${count}</span></div>
                                        </div>
                                        <div style="display: flex; gap: 8px;">
                                            <button class="btn btn-sm btn-primary" ${count <= 0 ? 'disabled' : ''} onclick="Gamification.openChest('${key}', false)" style="padding: 6px 12px; font-weight: 700; border-radius: 8px;">Aç</button>
                                            <button class="btn btn-sm btn-outline" ${count <= 0 ? 'disabled' : ''} onclick="Gamification.sellItemBack('chest', '${key}')" style="padding: 6px 12px; font-weight: 700; border-radius: 8px; border: 1px solid rgba(239, 68, 68, 0.3); color: #ef4444; background: transparent; cursor:pointer;">Sat (+${sellValue})</button>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                </div>

                <!-- Card Collection Section -->
                <div>
                    <h3 style="font-size: 1.4rem; font-weight: 800; color: #fff; margin: 15px 0 15px 0; display: flex; align-items: center; gap: 10px;">
                        <i class="fa-solid fa-id-badge" style="color: #fbbf24;"></i> Oyuncu Kartı Koleksiyonu
                    </h3>
                    <p style="color: #94a3b8; font-size: 0.9rem; margin-bottom: 20px;">Sandıklardan çıkardığınız Koreli aktör/aktris kartlarınız burada sergilenir. Mükerrer kartları anında Coin'e dönüştürebilirsiniz.</p>
                    
                    <div class="cards-gallery-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px;">
                        ${Gamification.config.cards.map(c => {
                            const ownedCount = (gamif.cards || []).filter(cid => cid === c.id).length;
                            const isOwned = ownedCount > 0;
                            return `
                                <div class="gallery-card rarity-${c.rarity} ${isOwned ? '' : 'locked'}" style="margin: 0; background: rgba(15, 15, 20, 0.6); border: 2px solid ${isOwned ? 'rgba(139, 92, 246, 0.3)' : 'rgba(255,255,255,0.03)'}; border-radius: 24px; padding: 25px 20px; text-align: center; position: relative;">
                                    <div class="card-light"></div>
                                    <img src="${c.avatar}" class="card-avatar" alt="${c.name}" style="width: 90px; height: 90px; border-radius: 50%; object-fit: cover; border: 3px solid ${isOwned ? '#8b5cf6' : '#333'}; margin: 0 auto 12px; display: block;">
                                    <div class="card-name" style="font-weight: 900; color: #fff; font-size: 1.1rem;">${c.name}</div>
                                    <div class="card-drama" style="font-size: 0.75rem; color: #64748b; font-weight: 600; margin-top: 4px;">${c.kdrama}</div>
                                    <div class="card-badge" style="display: inline-block; font-size: 0.6rem; font-weight: 900; padding: 2px 8px; border-radius: 5px; text-transform: uppercase; margin-top: 10px; background: rgba(255,255,255,0.08); color: #fff;">${c.rarity.toUpperCase()}</div>
                                    <div class="card-count" style="font-size: 0.72rem; color: #94a3b8; font-weight: 700; margin-top: 12px;">${isOwned ? `Adet: ${ownedCount}` : '🔒 KİLİTLİ'}</div>
                                    ${isOwned ? `
                                        <button class="btn btn-sm btn-outline sell-card-btn" onclick="Gamification.sellItemBack('card', '${c.id}')" style="margin-top: 15px; width: 100%; border: 1px solid rgba(251,191,36,0.3); color: #fbbf24; background: transparent; padding: 8px; border-radius: 10px; font-weight: 700; cursor: pointer; transition: 0.2s;">
                                            Dükkana Sat (+${c.baseValue} Coin)
                                        </button>
                                    ` : ''}
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>

                <!-- Buy Chests Shop -->
                <div>
                    <h3 style="font-size: 1.4rem; font-weight: 800; color: #fff; margin: 15px 0 15px 0; display: flex; align-items: center; gap: 10px;">
                        <i class="fa-solid fa-cart-shopping" style="color: #fbbf24;"></i> Hub Mağazası
                    </h3>
                    <div class="shop-chests-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 20px;">
                        ${Object.keys(Gamification.config.chests).map(key => {
                            const def = Gamification.config.chests[key];
                            const cardChanceText = `${Math.round(def.cardDropChance * 100)}% Kart Şansı`;
                            return `
                                <div class="shop-chest-card rarity-${key === 'bronz' ? 'common' : key === 'gumus' ? 'rare' : key === 'altin' ? 'epic' : 'legendary'}" style="margin: 0; background: rgba(15, 15, 20, 0.6); border: 1px solid rgba(255,255,255,0.05); border-radius: 20px; padding: 25px 15px; text-align: center;">
                                    <div style="font-size: 3rem; margin-bottom: 10px;">📦</div>
                                    <div class="title" style="font-weight: 800; color: #fff; font-size: 0.95rem; margin-bottom: 5px;">${def.name}</div>
                                    <div class="drop-desc" style="font-size: 0.72rem; color: #64748b; font-weight: 600;">🪙 +${def.coinsMin}-${def.coinsMax} | 🌟 +${def.xpMin}-${def.xpMax}</div>
                                    <div class="card-chance" style="font-size: 0.72rem; color: #a78bfa; font-weight: 800; margin-top: 5px;">${cardChanceText}</div>
                                    <div class="price" style="font-size: 1.25rem; color: #fbbf24; font-weight: 900; margin-top: 15px;">${def.price} Coin</div>
                                    <button class="btn btn-sm btn-primary" ${stats.coins < def.price ? 'disabled' : ''} onclick="Gamification.buyChestFromShop('${key}')" style="margin-top: 15px; width: 100%; padding: 10px; border-radius: 10px; font-weight: 700; cursor:pointer;">
                                        Satın Al
                                    </button>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            </div>
        `;
        container.innerHTML = html;
        Gamification.startCooldownTicker();
    },

    renderMessages(container) {
        container.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="font-size: 1.8rem; font-weight: 800; color: #fff; margin: 0;">Mesajlar</h2>
                <button onclick="UserProfile.showFriendSelector()" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white; border: none; padding: 10px 20px; border-radius: 12px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);">
                    <i class="fa-solid fa-plus"></i> Yeni Mesaj
                </button>
            </div>
            <div class="msg-layout" style="display: grid; grid-template-columns: 320px 1fr; height: 750px; background: rgba(15, 15, 20, 0.7); border-radius: 24px; border: 1px solid rgba(255, 255, 255, 0.05); overflow: hidden; backdrop-filter: blur(20px);">
                <div class="msg-list" id="msg-conversations" style="border-right: 1px solid rgba(255,255,255,0.05); overflow-y: auto; background: rgba(255,255,255,0.01);">
                    <div style="padding:40px; text-align:center; color:#64748b;"><i class="fa-solid fa-spinner fa-spin"></i> Sohbetler yükleniyor...</div>
                </div>
                <div class="msg-chat" id="msg-chat-area" style="background: rgba(0,0,0,0.1); position: relative;">
                    <div style="display:flex; align-items:center; justify-content:center; height:100%; color:#475569; flex-direction:column; gap:20px;">
                        <div style="width: 80px; height: 80px; border-radius: 50%; background: rgba(139, 92, 246, 0.05); display: flex; align-items: center; justify-content: center; color: rgba(139, 92, 246, 0.2);">
                            <i class="fa-regular fa-comments" style="font-size: 2.5rem;"></i>
                        </div>
                        <p style="font-weight: 500; letter-spacing: 0.5px;">Sohbet başlatmak için birini seçin.</p>
                    </div>
                </div>
            </div>`;
        this.loadConversations();
    },

    showFriendSelector() {
        const friends = State.currentUser?.friends || [];
        if (friends.length === 0) {
            Toast.info('Henüz arkadaşınız yok. Önce arkadaş eklemelisiniz!');
            return;
        }

        const chatArea = document.getElementById('msg-chat-area');
        if (!chatArea) return;

        chatArea.innerHTML = `
            <div style="padding: 30px; height: 100%; overflow-y: auto;">
                <h3 style="color: #fff; margin-bottom: 25px; display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-user-group" style="color: #a78bfa;"></i> Arkadaş Seç
                </h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;">
                    ${friends.map(fid => {
            const f = State.data.users.find(u => u.id === fid);
            if (!f) return '';
            return `
                            <div onclick="UserProfile.startConversation('${f.id}')" 
                                 style="background: rgba(255,255,255,0.03); padding: 20px; border-radius: 16px; text-align: center; cursor: pointer; border: 1px solid rgba(255,255,255,0.05); transition: all 0.2s;"
                                 onmouseover="this.style.background='rgba(139, 92, 246, 0.1)'; this.style.borderColor='rgba(139, 92, 246, 0.2)'"
                                 onmouseout="this.style.background='rgba(255,255,255,0.03)'; this.style.borderColor='rgba(255,255,255,0.05)'">
                                ${this.renderAvatar(f, 60)}
                                <div style="margin-top: 12px; font-weight: 700; color: #fff;">${f.username}</div>
                                <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 4px;">Lvl ${Gamification.getLevel(f.stats?.xp || 0)}</div>
                            </div>
                        `;
        }).join('')}
                </div>
            </div>
        `;
    },

    startConversation(userId) {
        if (!State.currentUser) {
            Toast.error('Mesajlaşmak için giriş yapmalısınız!');
            return;
        }

        const friend = State.data.users.find(u => u.id === userId);
        if (!friend) return;

        // Force switch to messages tab if not already there
        if (this.activeTab !== 'messages') {
            this.switchTab('messages');
        }

        setTimeout(() => {
            this.activeConversationId = userId;
            this.openChat(userId);
        }, 100);
    },

    renderLists(container) {
        const user = this.getUser();
        const isOwn = this.isOwnProfile();

        container.innerHTML = `
            <div style="max-width: 1000px; margin: 0 auto;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <h2 style="font-size: 2rem; font-weight: 800; color: #fff; margin: 0;">
                        <i class="fa-solid fa-list-ul" style="color: #f472b6; margin-right: 10px;"></i> Listeler
                    </h2>
                    ${isOwn ? `
                        <button onclick="UserProfile.showCreateListModal()" style="background: linear-gradient(135deg, #ec4899, #db2777); color: white; border: none; padding: 10px 20px; border-radius: 10px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                            <i class="fa-solid fa-plus"></i> Yeni Liste
                        </button>
                    ` : ''}
                </div>

                <!-- Default Watchlist -->
                <div class="stat-card-new" style="margin-bottom: 30px;">
                        <span style="font-size: 0.8rem; background: rgba(139, 92, 246, 0.2); padding: 2px 8px; border-radius: 10px; color: #a78bfa;">${user.watchlist?.length || 0}</span>
                        <button onclick="UserProfile.shareList('watchlist')" style="margin-left: auto; background: none; border: none; color: #94a3b8; cursor: pointer; font-size: 0.9rem;"><i class="fa-solid fa-share-nodes"></i> Paylaş</button>
                    </h3>
                    ${(!user.watchlist || user.watchlist.length === 0) ?
                `<p style="color: #64748b; padding: 20px; text-align: center; border: 1px dashed rgba(255,255,255,0.1); border-radius: 10px;">Liste boş.</p>` :
                `<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 15px;">
                            ${this.renderSeriesList(user.watchlist.map(id => State.data.series.find(s => s.id === id)).filter(Boolean))}
                        </div>`
            }
                </div>

                <!-- Custom Lists -->
                <div>
                     <h3 style="margin-bottom: 20px; color: #fff; font-size: 1.5rem;">Özel Listeler</h3>
                     <div id="custom-lists-container" style="display: grid; gap: 20px;">
                        ${this.renderCustomLists(user)}
                     </div>
                </div>
            </div>
        `;
    },

    renderCustomLists(user) {
        const lists = user.customLists || [];
        if (lists.length === 0) {
            return `<div style="text-align: center; padding: 40px; border: 1px dashed rgba(255,255,255,0.1); border-radius: 16px; color: #64748b;">
                <i class="fa-regular fa-folder-open" style="font-size: 2rem; margin-bottom: 15px; opacity: 0.5;"></i>
                <p>Henüz özel bir liste oluşturulmamış.</p>
            </div>`;
        }

        return lists.map(list => {
            const seriesItems = list.items.map(id => State.data.series.find(s => s.id === id)).filter(Boolean).slice(0, 5);
            return `
                <div class="stat-card-new" style="display: flex; gap: 20px; align-items: start;">
                    <div style="flex: 1;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <h4 style="font-size: 1.2rem; margin: 0; color: #fff;">${list.title}</h4>
                            <div style="display: flex; gap: 10px; align-items: center;">
                                <span style="font-size: 0.8rem; color: #94a3b8;">${list.items.length} İçerik</span>
                                <button onclick="UserProfile.shareList('${list.id}')" style="background: none; border: none; color: #94a3b8; cursor: pointer; font-size: 0.9rem;"><i class="fa-solid fa-share-nodes"></i> Paylaş</button>
                            </div>
                        </div>
                        <p style="color: #94a3b8; font-size: 0.9rem; margin-bottom: 15px;">${list.description || 'Açıklama yok.'}</p>
                        
                        <div style="display: flex; gap: 10px; margin-bottom: 15px;">
                            ${seriesItems.map(s => `
                                <img src="${s.poster}" style="width: 40px; height: 60px; object-fit: cover; border-radius: 4px;" title="${s.title}">
                            `).join('')}
                            ${list.items.length > 5 ? `<div style="width: 40px; height: 60px; background: rgba(255,255,255,0.1); border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; color: #fff;">+${list.items.length - 5}</div>` : ''}
                        </div>

                        <div style="display: flex; gap: 10px;">
                            <button onclick="UserProfile.viewList('${list.id}')" style="padding: 8px 16px; background: rgba(255,255,255,0.1); color: #fff; border: none; border-radius: 6px; cursor: pointer;">İncele</button>
                            ${this.isOwnProfile() ? `<button onclick="UserProfile.deleteList('${list.id}')" style="padding: 8px 16px; background: rgba(239, 68, 68, 0.1); color: #ef4444; border: none; border-radius: 6px; cursor: pointer;"><i class="fa-solid fa-trash"></i></button>` : ''}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    },

    showCreateListModal() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 500px;">
                <div class="modal-header">
                    <h2>Yeni Liste Oluştur</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <form onsubmit="UserProfile.createList(event)">
                        <div class="form-group">
                            <label>Liste Adı</label>
                            <input type="text" name="title" class="form-input" required placeholder="Örn: En İyi Kore Dizileri">
                        </div>
                        <div class="form-group">
                            <label>Açıklama</label>
                            <textarea name="description" class="form-input" rows="3" placeholder="Bu liste ne hakkında?"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Oluştur</button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async createList(event) {
        event.preventDefault();
        const form = event.target;
        const title = form.title.value;
        const description = form.description.value;

        if (!State.currentUser.customLists) State.currentUser.customLists = [];

        const newList = {
            id: 'list-' + Date.now(),
            title,
            description,
            items: [],
            createdAt: Date.now()
        };

        State.currentUser.customLists.push(newList);

        try {
            if (window.db) await window.db.updateUser(State.currentUser.id, { customLists: State.currentUser.customLists });
            Toast.success('Liste oluşturuldu!');
            document.querySelector('.modal').remove();
            this.switchTab('lists');
        } catch (e) {
            Toast.error('Hata oluştu.');
        }
    },

    async deleteList(listId) {
        if (!confirm('Bu listeyi silmek istediğinize emin misiniz?')) return;

        State.currentUser.customLists = State.currentUser.customLists.filter(l => l.id !== listId);

        try {
            if (window.db) await window.db.updateUser(State.currentUser.id, { customLists: State.currentUser.customLists });
            Toast.success('Liste silindi.');
            this.switchTab('lists');
        } catch (e) {
            Toast.error('Hata oluştu.');
        }
    },

    renderHistory(container) {
        const user = this.getUser();
        // Filter simplified for demo, ideally group by date
        container.innerHTML = `<div style="text-align: center; padding: 50px; color: #64748b;">İzleme geçmişi özelliği yakında güncellenecek.</div>`;
    },

    renderAnalytics(container) {
        // Show detailed statistics for user
        container.innerHTML = `
            <div style="max-width: 1000px; margin: 0 auto;">
                <h2 style="font-size: 2rem; font-weight: 800; margin-bottom: 30px; color: #fff;">
                    <i class="fa-solid fa-chart-line" style="color: #a78bfa; margin-right: 10px;"></i>
                    İstatistiklerim
                </h2>
                <div id="analytics-content">
                    <div style="text-align: center; padding: 50px;">
                        <i class="fa-solid fa-spinner fa-spin" style="font-size: 2rem; color: #8b5cf6;"></i>
                        <p style="color: #94a3b8; margin-top: 15px;">İstatistikler yükleniyor...</p>
                    </div>
                </div>
            </div>`;

        // Load analytics after render
        setTimeout(() => {
            if (window.AdvancedUserAnalytics && AdvancedUserAnalytics.renderInline) {
                AdvancedUserAnalytics.renderInline('analytics-content');
            } else if (window.AdvancedUserAnalytics) {
                // Fallback: show modal
                AdvancedUserAnalytics.showDetailedAnalytics();
                document.getElementById('analytics-content').innerHTML = `
                    <div style="text-align: center; padding: 50px; color: #94a3b8;">
                        <i class="fa-solid fa-external-link-alt" style="font-size: 2rem; margin-bottom: 15px;"></i>
                        <p>İstatistikler ayrı bir pencerede açıldı.</p>
                        <button onclick="AdvancedUserAnalytics.showDetailedAnalytics()" class="btn btn-primary" style="margin-top: 15px;">
                            <i class="fa-solid fa-chart-line"></i> Tekrar Aç
                        </button>
                    </div>`;
            } else {
                document.getElementById('analytics-content').innerHTML = `
                    <div style="text-align: center; padding: 50px; color: #94a3b8;">
                        <i class="fa-solid fa-chart-bar" style="font-size: 3rem; margin-bottom: 15px; color: #64748b;"></i>
                        <p>Henüz yeterli veri yok. Diziler izleyerek istatistiklerinizin burada görüntülenmesini sağlayın!</p>
                    </div>`;
            }
        }, 300);
    },

    async renderRequests(container) {
        // Local-First Support Ticket System
        const allTickets = State.data.tickets || [];
        const tickets = allTickets.filter(t => t.userId === State.currentUser?.id);

        container.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="font-size: 1.8rem; font-weight: 800; color: #fff; margin: 0;">Destek Merkezi</h2>
                <button onclick="UserProfile.openNewTicketModal()" class="btn btn-primary" style="padding: 10px 20px; border-radius: 12px; font-weight: 700;">
                    <i class="fa-solid fa-plus"></i> Yeni Talep
                </button>
            </div>

            <div class="tickets-list">
                ${tickets.length === 0 ? `
                    <div style="text-align: center; padding: 60px; background: rgba(255,255,255,0.02); border-radius: 20px; border: 1px dashed rgba(255,255,255,0.1);">
                        <i class="fa-solid fa-headset" style="font-size: 3rem; color: #475569; margin-bottom: 20px;"></i>
                        <h3 style="color: #94a3b8;">Henüz destek talebiniz bulunmuyor.</h3>
                        <p style="color: #64748b;">Bir sorun mu yaşıyorsunuz? Yeni bir talep oluşturarak bize iletebilirsiniz.</p>
                    </div>
                ` : tickets.map(t => `
                    <div class="ticket-card glass-panel" style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); padding: 20px; border-radius: 20px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; transition: 0.3s;" onclick="UserProfile.viewTicketDetails('${t.id}')">
                        <div>
                            <div style="font-size:0.8rem; color: #8b5cf6; font-weight: 700; margin-bottom: 5px;">#${t.id.split('-')[1].toUpperCase()}</div>
                            <h4 style="color: #fff; margin: 0; font-size: 1.1rem;">${t.subject}</h4>
                            <div style="font-size: 0.85rem; color: #64748b; margin-top: 8px;">
                                <i class="fa-regular fa-calendar"></i> ${new Date(t.createdAt).toLocaleDateString()}
                                <span style="margin-left: 15px;"><i class="fa-regular fa-message"></i> ${t.messages.length} Mesaj</span>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <span class="status-badge ${t.status}" style="padding: 6px 12px; border-radius: 8px; font-size: 0.8rem; font-weight: 800; text-transform: uppercase;">
                                ${t.status === 'open' ? 'Bekliyor' : (t.status === 'replied' ? 'Yanıtlandı' : 'Kapalı')}
                            </span>
                            <div style="margin-top:10px; color: #94a3b8; font-size: 0.8rem;">İncele <i class="fa-solid fa-chevron-right"></i></div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    },

    openNewTicketModal() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'new-ticket-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width: 500px; padding:30px;">
                <div class="modal-header" style="margin-bottom:20px;">
                    <h2 style="margin:0;">Yeni Destek Talebi</h2>
                    <button onclick="this.closest('.modal').remove()" style="background:none; border:none; color:white; font-size:1.5rem; cursor:pointer;">&times;</button>
                </div>
                <div class="form-group" style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-size:0.9rem; color:#94a3b8;">Konu</label>
                    <input type="text" id="t-subject" class="form-input-new" placeholder="Sorununuzun özeti">
                </div>
                <div class="form-group" style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-size:0.9rem; color:#94a3b8;">Öncelik</label>
                    <select id="t-priority" class="form-input-new">
                        <option value="normal">Normal</option>
                        <option value="high">Yüksek</option>
                        <option value="urgent">Acil</option>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom:20px;">
                    <label style="display:block; margin-bottom:5px; font-size:0.9rem; color:#94a3b8;">Mesajınız</label>
                    <textarea id="t-message" class="form-input-new" style="height:150px;" placeholder="Lütfen detaylı bilgi verin..."></textarea>
                </div>
                <div style="display:flex; gap:10px;">
                    <button onclick="this.closest('.modal').remove()" class="btn btn-secondary" style="flex:1;">Vazgeç</button>
                    <button onclick="UserProfile.submitTicket()" class="btn btn-primary" style="flex:1;">Talebi Gönder</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async submitTicket() {
        const subject = document.getElementById('t-subject').value;
        const priority = document.getElementById('t-priority').value;
        const message = document.getElementById('t-message').value;

        if (!subject || !message) {
            Toast.error('Lütfen tüm alanları doldurun.');
            return;
        }

        // Local-First Ticket Creation
        const ticketId = 'TKT-' + Math.random().toString(36).substr(2, 9).toUpperCase();
        const newTicket = {
            id: ticketId,
            userId: State.currentUser.id,
            username: State.currentUser.username,
            subject,
            priority,
            status: 'open',
            createdAt: new Date().toISOString(),
            messages: [{
                id: 'm1',
                author: 'user',
                userId: State.currentUser.id,
                username: State.currentUser.username,
                text: message,
                time: new Date().toISOString()
            }]
        };

        if (!State.data.tickets) State.data.tickets = [];
        State.data.tickets.unshift(newTicket);
        
        db.save();
        Toast.success('Destek talebiniz oluşturuldu.');
        const modal = document.getElementById('new-ticket-modal');
        if (modal) modal.remove();
        this.renderRequests(document.getElementById('profile-tab-content'));
    },

    async viewTicketDetails(ticketId) {
        const tickets = State.data.tickets || [];
        const ticket = tickets.find(t => t.id === ticketId);
        
        if (!ticket) return;

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.style.zIndex = '2001';
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width: 700px; max-height: 80vh; padding: 0; overflow: hidden; display: flex; flex-direction: column;">
                <div class="modal-header" style="padding: 20px; background: rgba(255,255,255,0.02); border-bottom: 1px solid rgba(255,255,255,0.05);">
                    <div>
                        <h2 style="font-size: 1.2rem; margin: 0;">${ticket.subject}</h2>
                        <span style="font-size: 0.75rem; color: #8b5cf6;">#${ticket.id.split('-')[1].toUpperCase()}</span>
                    </div>
                    <button class="modal-close" onclick="this.closest('.modal').remove()" style="background:none; border:none; color:white; font-size:1.5rem; cursor:pointer;">×</button>
                </div>
                
                <div class="ticket-messages custom-scrollbar" style="flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 15px;">
                    ${ticket.messages.map(m => `
                        <div style="max-width: 80%; ${m.author === 'admin' ? 'align-self: flex-start;' : 'align-self: flex-end;'}">
                            <div style="font-size: 0.7rem; color: #64748b; margin-bottom: 5px; ${m.author === 'admin' ? '' : 'text-align: right;'}">
                                <b>${m.username}</b> • ${new Date(m.time).toLocaleTimeString()}
                            </div>
                            <div style="padding: 12px 16px; border-radius: 12px; font-size: 0.95rem; line-height: 1.5; 
                                ${m.author === 'admin' ? 'background: rgba(139, 92, 246, 0.1); border: 1px solid rgba(139, 92, 246, 0.2); color: #fff;' : 'background: rgba(255,255,255,0.05); color: #e2e8f0; border: 1px solid rgba(255,255,255,0.05);'}">
                                ${m.text}
                            </div>
                        </div>
                    `).join('')}
                </div>

                ${ticket.status !== 'closed' ? `
                    <div style="padding: 20px; background: rgba(255,255,255,0.02); border-top: 1px solid rgba(255,255,255,0.05);">
                        <div style="display: flex; gap: 10px;">
                            <input type="text" id="reply-text-${ticket.id}" class="form-input-new" placeholder="Mesajınızı yazın..." style="flex:1;">
                            <button onclick="UserProfile.replyToTicket('${ticket.id}')" class="btn btn-primary" style="padding: 0 20px;"><i class="fa-solid fa-paper-plane"></i></button>
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
        document.body.appendChild(modal);
    },

    async replyToTicket(ticketId) {
        const input = document.getElementById(`reply-text-${ticketId}`);
        const text = input ? input.value : '';
        if (!text) return;

        const ticket = (State.data.tickets || []).find(t => t.id === ticketId);
        if (ticket) {
            ticket.messages.push({
                id: 'm' + (ticket.messages.length + 1),
                author: 'user',
                userId: State.currentUser.id,
                username: State.currentUser.username,
                text: text,
                time: new Date().toISOString()
            });
            ticket.status = 'open'; // Reset status to waiting if user replies
            db.save();
            Toast.success('Yanıt iletildi.');
            
            // Refresh modal content
            const modal = document.querySelector('.modal[style*="z-index: 2001"]');
            if (modal) modal.remove();
            this.viewTicketDetails(ticketId);
        }
    },

    viewList(listId) {
        const user = this.getUser();
        const list = user.customLists?.find(l => l.id === listId);
        if (!list) return Toast.error('Liste bulunamadı');

        const container = document.getElementById('profile-tab-content');
        container.innerHTML = `
            <div style="max-width: 1000px; margin: 0 auto;">
                <div style="margin-bottom: 30px;">
                    <button onclick="UserProfile.switchTab('lists')" style="background: none; border: none; color: #94a3b8; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 1rem; margin-bottom: 15px;">
                        <i class="fa-solid fa-arrow-left"></i> Listelere Dön
                    </button>
                    <h2 style="font-size: 2rem; font-weight: 800; color: #fff; margin: 0 0 10px 0;">${list.title}</h2>
                    <p style="color: #94a3b8; font-size: 1.1rem; line-height: 1.6;">${list.description || ''}</p>
                </div>
                
                <div class="stat-card-new" style="margin-bottom: 30px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h3 style="color: #fff; margin: 0;">İçerikler (${list.items.length})</h3>
                        ${this.isOwnProfile() ? '<button class="btn btn-primary" onclick="Toast.info(\'İçerik ekleme özelliği yakında gelecek! Şimdilik manuel eklenemiyor.\')"><i class="fa-solid fa-plus"></i> Ekle</button>' : ''}
                    </div>
                    ${list.items.length === 0 ?
                `<p style="color: #64748b; padding: 20px; text-align: center; border: 1px dashed rgba(255,255,255,0.1); border-radius: 10px;">Bu listede henüz içerik yok.</p>` :
                `<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 20px;">
                            ${this.renderSeriesList(list.items.map(id => State.data.series.find(s => s.id === id)).filter(Boolean))}
                        </div>`
            }
                </div>
            </div>
        `;
    },

    renderSettings(container) {
        const user = this.getUser();
        container.innerHTML = `
            <div style="max-width: 800px; margin: 0 auto;">
                <h2 style="font-size: 2rem; font-weight: 800; margin-bottom: 30px; color: #fff;">Profili Düzenle</h2>
                
                <div class="stat-card-new" style="margin-bottom: 30px;">
                    <h3 style="margin-bottom: 20px; color: #a78bfa;">Kişisel Bilgiler</h3>
                    <div style="display: grid; gap: 20px;">
                        <div>
                            <label style="display: block; color: #94a3b8; margin-bottom: 8px;">Kullanıcı Adı</label>
                            <input type="text" value="${user.username}" disabled class="form-input-new" style="opacity:0.6;">
                        </div>
                        <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(139, 92, 246, 0.05); padding: 15px; border-radius: 12px; border: 1px solid rgba(139, 92, 246, 0.2);">
                            <div>
                                <div style="font-weight: 800; color: #fff;">Gizli Profil</div>
                                <div style="font-size: 0.8rem; color: #94a3b8;">Sadece arkadaşların aktivitelerini görebilir.</div>
                            </div>
                            <label class="switch-modern">
                                <input type="checkbox" id="settings-is-private" ${user.isPrivate ? 'checked' : ''}>
                                <span class="slider-modern"></span>
                            </label>
                        </div>
                        <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(139, 92, 246, 0.05); padding: 15px; border-radius: 12px; border: 1px solid rgba(139, 92, 246, 0.2);">
                            <div>
                                <div style="font-weight: 800; color: #fff;">İki Aşamalı Doğrulama (2FA)</div>
                                <div style="font-size: 0.8rem; color: #94a3b8;">Giriş yaparken e-postanıza gönderilen doğrulama kodunu zorunlu kılar.</div>
                            </div>
                            <label class="switch-modern">
                                <input type="checkbox" id="settings-2fa" ${user.twoFactorEnabled ? 'checked' : ''}>
                                <span class="slider-modern"></span>
                            </label>
                        </div>
                        ${(() => {
                            if (user.isVerified) {
                                return `
                                    <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(16, 185, 129, 0.05); padding: 15px; border-radius: 12px; border: 1px solid rgba(16, 185, 129, 0.2);">
                                        <div>
                                            <div style="font-weight: 800; color: #fff;">Doğrulanmış Hesap</div>
                                            <div style="font-size: 0.8rem; color: #94a3b8;">Hesabınız resmi olarak doğrulanmıştır ve mavi tik rozetiniz etkindir.</div>
                                        </div>
                                        <span style="color: #3b82f6; font-size: 1.5rem;"><i class="fa-solid fa-circle-check"></i></span>
                                    </div>
                                `;
                            } else if (user.verificationRequested && user.verificationStatus === 'pending') {
                                return `
                                    <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(245, 158, 11, 0.05); padding: 15px; border-radius: 12px; border: 1px solid rgba(245, 158, 11, 0.2);">
                                        <div>
                                            <div style="font-weight: 800; color: #fff;">Mavi Tik Başvurusu Beklemede</div>
                                            <div style="font-size: 0.8rem; color: #94a3b8;">Doğrulama talebiniz ekip tarafından incelenmektedir.</div>
                                        </div>
                                        <span style="color: #f59e0b; font-size: 0.9rem; font-weight: 700;">Beklemede</span>
                                    </div>
                                `;
                            } else {
                                return `
                                    <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(255, 255, 255, 0.02); padding: 15px; border-radius: 12px; border: 1px solid rgba(255, 255, 255, 0.05);">
                                        <div>
                                            <div style="font-weight: 800; color: #fff;">Mavi Tik Başvurusu</div>
                                            <div style="font-size: 0.8rem; color: #94a3b8;">Güvenilir bir topluluk üyesi olarak mavi tik almak için başvurun.</div>
                                        </div>
                                        <button type="button" onclick="UserProfile.requestVerification()" class="btn btn-outline" style="padding: 8px 16px; font-size: 0.8rem;">Başvur</button>
                                    </div>
                                `;
                            }
                        })()}
                        <div>
                            <label style="display: block; color: #94a3b8; margin-bottom: 8px;">Hakkında (Bio)</label>
                            <textarea id="settings-bio" rows="4" class="form-input-new">${user.bio || ''}</textarea>
                        </div>
                        <div>
                            <label style="display: block; color: #94a3b8; margin-bottom: 8px;">Doğum Tarihi (Sorumluluk reddi gereği değiştirilemez!)</label>
                            <input type="date" id="settings-birth-date" value="${user.birthDate || ''}" class="form-input-new" ${user.birthDate ? 'disabled style="opacity:0.6; cursor:not-allowed;"' : ''}>
                            <p style="font-size: 0.75rem; color: #64748b; margin-top: 5px;">⚠️ 18+ ve 21+ içeriklere erişim için gereklidir. Bir kez kaydedildikten sonra değiştirilemez.</p>
                        </div>
                        <div>
                             <label style="display: block; color: #94a3b8; margin-bottom: 8px;">Profil Resmi (Maks. 2MB)</label>
                            <div style="display: flex; gap: 15px; align-items: center;">
                                ${this.renderAvatar(user, 60)}
                                <div style="flex: 1;">
                                    <input type="file" id="settings-avatar-file" accept="image/*" class="form-input-new" style="padding: 8px;">
                                    <input type="hidden" id="settings-avatar-url" value="${user.avatar || ''}">
                                    <p style="font-size: 0.75rem; color: #64748b; margin-top: 5px;">Dosya seçin veya bir URL girin (alttaki kutu)</p>
                                    <input type="text" id="settings-avatar-text" value="${user.avatar || ''}" class="form-input-new" style="margin-top: 5px; font-size: 0.8rem;" placeholder="https://...">
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="stat-card-new" style="margin-bottom: 30px;">
                    <h3 style="margin-bottom: 20px; color: #ec4899;">Sosyal Medya</h3>
                     <div style="display: grid; gap: 15px;">
                        <div style="position: relative;">
                            <i class="fa-brands fa-instagram" style="position: absolute; left: 12px; top: 14px; color: #e1306c;"></i>
                            <input type="text" id="settings-insta" value="${user.socialLinks?.instagram || ''}" class="form-input-new" style="padding-left: 40px;" placeholder="Instagram">
                        </div>
                         <div style="position: relative;">
                            <i class="fa-brands fa-twitter" style="position: absolute; left: 12px; top: 14px; color: #1da1f2;"></i>
                            <input type="text" id="settings-twitter" value="${user.socialLinks?.twitter || ''}" class="form-input-new" style="padding-left: 40px;" placeholder="Twitter">
                        </div>
                        <div style="position: relative;">
                            <i class="fa-brands fa-discord" style="position: absolute; left: 12px; top: 14px; color: #5865F2;"></i>
                            <input type="text" id="settings-discord" value="${user.socialLinks?.discord || ''}" class="form-input-new" style="padding-left: 40px;" placeholder="Discord">
                        </div>
                     </div>
                </div>
                
                <div class="stat-card-new" style="margin-bottom: 30px;">
                     <h3 style="margin-bottom: 20px; color: #f59e0b;">Çerçeve Seçimi</h3>
                     <div style="display: flex; gap: 15px; flex-wrap: wrap;" id="frame-selector-container">
                        ${this.renderFrameSelector(user)}
                     </div>
                </div>

                <div class="stat-card-new" style="margin-bottom: 30px;">
                     <h3 style="margin-bottom: 15px; color: #10b981;">Gösterilecek Rozetler (Maks. 3)</h3>
                     <p style="color: #64748b; font-size: 0.85rem; margin-bottom: 15px;">Bu rozetler yorumlarınızda ve diğer yerlerde görünecektir.</p>
                     <div style="display: flex; gap: 10px; flex-wrap: wrap;" id="badge-selector-container">
                        ${this.renderBadgeSelector(user)}
                     </div>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 15px;">
                    <button onclick="UserProfile.switchTab('overview')" style="padding: 12px 25px; background: transparent; color: #94a3b8; border: 1px solid rgba(255,255,255,0.2); border-radius: 10px; cursor: pointer;">İptal</button>
                    <button onclick="UserProfile.saveSettings()" style="padding: 12px 30px; background: #8b5cf6; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 700;">Kaydet</button>
                </div>
            </div>`;
    },

    // --- LOGIC METHODS ---

    renderVipStatusCard(user) {
        const vipStatus = user.vipStatus;
        if (!vipStatus || !vipStatus.active) {
            // Not VIP - show upgrade option
            if (this.isOwnProfile()) {
                return `
                    <div class="stat-card-new" style="background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(236, 72, 153, 0.1)); border-color: rgba(139, 92, 246, 0.2);">
                        <div style="text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 10px;">✨</div>
                            <h4 style="color: #fff; margin-bottom: 10px;">VIP Üye Ol</h4>
                            <p style="color: #94a3b8; font-size: 0.85rem; margin-bottom: 15px;">Özel çerçeveler, rozetler ve daha fazlası!</p>
                            <button onclick="ShopSystem.open(); setTimeout(() => ShopSystem.switchTab('premium'), 100)" style="width: 100%; padding: 12px; background: linear-gradient(135deg, #8b5cf6, #ec4899); color: white; border: none; border-radius: 10px; font-weight: 700; cursor: pointer;">
                                <i class="fa-solid fa-crown"></i> VIP'e Yükselt
                            </button>
                        </div>
                    </div>`;
            }
            return '';
        }

        const now = Date.now();
        const expiresAt = vipStatus.expiresAt;
        const isLifetime = vipStatus.isLifetime || expiresAt > 9999999999990;
        const daysLeft = isLifetime ? '∞' : Math.max(0, Math.ceil((expiresAt - now) / (1000 * 60 * 60 * 24)));

        const badgeHTML = (user.badges || []).filter(b => ['VIP', 'VIP+', '👑'].includes(b))
            .map(b => `<span style="display: inline-block; padding: 4px 10px; background: rgba(255,215,0,0.2); color: #ffd700; border-radius: 20px; font-size: 0.75rem; font-weight: 700; margin-right: 5px;">${b}</span>`)
            .join('');

        return `
            <div class="stat-card-new" style="background: linear-gradient(135deg, rgba(255, 215, 0, 0.1), rgba(255, 140, 0, 0.1)); border: 1px solid rgba(255, 215, 0, 0.3); position: relative; overflow: hidden;">
                <div style="position: absolute; top: -10px; right: -10px; font-size: 4rem; opacity: 0.1; transform: rotate(15deg);">👑</div>
                <div style="display: flex; align-items: center; gap: 15px;">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #ffd700, #ff8c00); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; color: #fff; box-shadow: 0 5px 15px rgba(255, 215, 0, 0.4);">
                        <i class="fa-solid fa-crown"></i>
                    </div>
                    <div style="flex: 1;">
                        <div style="font-weight: 800; color: #ffd700; font-size: 1.1rem;">${isLifetime ? 'VIP+ Üye' : 'VIP Üye'}</div>
                        <div style="color: #94a3b8; font-size: 0.85rem; margin-top: 3px;">
                            ${isLifetime ? 'Ömür Boyu Aktif' : `Kalan: <strong style="color: #10b981;">${daysLeft} Gün</strong>`}
                        </div>
                    </div>
                </div>
                ${badgeHTML ? `<div style="margin-top: 15px;">${badgeHTML}</div>` : ''}
                ${vipStatus.purchasedAt ? `<div style="margin-top: 10px; font-size: 0.75rem; color: #64748b;">Üyelik: ${new Date(vipStatus.purchasedAt).toLocaleDateString('tr-TR')}</div>` : ''}
            </div>`;
    },

    renderFriendButton(user) {
        const currentUser = State.currentUser;
        if (!currentUser || currentUser.id === user.id) return '';

        const isFriend = currentUser.friends?.includes(user.id);
        const hasSentRequest = currentUser.friendRequestsSent?.includes(user.id);
        const hasReceivedRequest = currentUser.friendRequests?.find(r => r.fromUserId === user.id);

        if (isFriend) {
            return `
                <button class="p-nav-btn" onclick="UserProfile.removeFriend('${user.id}')" 
                        style="margin-bottom: 0; background: rgba(239, 68, 68, 0.08); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.2); justify-content: center;">
                    <i class="fa-solid fa-user-minus"></i> <span>Arkadaşlıktan Çıkar</span>
                </button>`;
        }
        if (hasSentRequest) {
            return `
                <button class="p-nav-btn" disabled 
                        style="margin-bottom: 0; background: rgba(245, 158, 11, 0.08); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.2); justify-content: center; cursor: default; transform: none; opacity: 0.8;">
                    <i class="fa-solid fa-clock"></i> <span>İstek Gönderildi</span>
                </button>`;
        }
        if (hasReceivedRequest) {
            return `
                <button class="p-nav-btn" onclick="UserProfile.acceptFriend('${user.id}')" 
                        style="margin-bottom: 0; background: rgba(16, 185, 129, 0.08); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.2); justify-content: center;">
                    <i class="fa-solid fa-check"></i> <span>İsteği Kabul Et</span>
                </button>`;
        }
        return `
            <button class="p-nav-btn" onclick="UserProfile.sendFriendRequest('${user.id}')" 
                    style="margin-bottom: 0; background: rgba(59, 130, 246, 0.08); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.2); justify-content: center;">
                <i class="fa-solid fa-user-plus"></i> <span>Arkadaş Ekle</span>
            </button>`;
    },

    renderFrameSelector(user) {
        // Get frames from ShopSystem if available, otherwise use defaults
        let frames = [{ id: 'default', name: 'Varsayılan', class: '', color: '#fff' }];

        if (window.ShopSystem && ShopSystem.items && ShopSystem.items.frames) {
            frames = frames.concat(ShopSystem.items.frames.map(f => ({
                id: f.id,
                name: f.name,
                class: f.class,
                color: this.getFrameColor(f.class)
            })));
        }

        // Get user's inventory (purchased items)
        const inventory = user.inventory || State.currentUser?.inventory || [];
        const activeFrame = user.activeFrame || State.currentUser?.activeFrame || 'default';

        return frames.map(f => {
            const isUnlocked = f.id === 'default' || inventory.includes(f.id);
            const isSelected = (this.currentSelectedFrame || activeFrame) === f.id;
            return `
            <div onclick="${isUnlocked ? `UserProfile.selectFrame('${f.id}')` : 'ShopSystem.open()'}" 
                 style="width: 70px; height: 70px; border-radius: 50%; border: 3px solid ${f.color}; position: relative; cursor: pointer; opacity: ${isUnlocked ? 1 : 0.5}; transform: scale(${isSelected ? 1.1 : 1}); box-shadow: ${isSelected ? `0 0 15px ${f.color}` : 'none'}; transition: all 0.2s ease;"
                 title="${f.name}${!isUnlocked ? ' (Mağazadan alınabilir)' : ''}">
                ${!isUnlocked ? '<div style="position: absolute; inset:0; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.5); border-radius:50%;"><i class="fa-solid fa-lock"></i></div>' : ''}
            </div>`;
        }).join('');
    },

    getFrameColor(frameClass) {
        const colors = {
            'frame-neon-purple': '#8b5cf6',
            'frame-gold-royal': '#f59e0b',
            'frame-fire-vortex': '#ef4444',
            'frame-diamond-glimmer': '#06b6d4',
            'frame-ice-crystal': '#93c5fd',
            'frame-emerald-shine': '#10b981',
            'frame-sunset-glow': '#f97316',
            'frame-galaxy': '#6366f1'
        };
        return colors[frameClass] || '#fff';
    },

    selectFrame(frameId) {
        this.currentSelectedFrame = frameId;
        const container = document.getElementById('frame-selector-container');
        if (container) container.innerHTML = this.renderFrameSelector(this.getUser());
    },

    renderBadgeSelector(user) {
        const allBadges = user.badges || [];
        const displayBadges = user.displayBadges || [];

        if (allBadges.length === 0) {
            return '<p style="color: #64748b; font-size: 0.9rem;">Henüz rozetiniz yok. Mağazadan veya aktivitelerle rozet kazanabilirsiniz.</p>';
        }

        return allBadges.map(badge => {
            const isSelected = displayBadges.includes(badge);
            return `
                <div class="badge-selector-item ${isSelected ? 'selected' : ''}" 
                     data-badge="${badge}"
                     onclick="UserProfile.toggleBadge('${badge}')"
                     style="padding: 10px 15px; background: ${isSelected ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255,255,255,0.05)'}; 
                            border: 2px solid ${isSelected ? '#10b981' : 'rgba(255,255,255,0.1)'}; 
                            border-radius: 10px; cursor: pointer; transition: all 0.2s; 
                            display: flex; align-items: center; gap: 8px;">
                    ${isSelected ? '<i class="fa-solid fa-check" style="color: #10b981;"></i>' : ''}
                    <span style="font-size: 1rem;">${badge}</span>
                </div>`;
        }).join('');
    },

    toggleBadge(badge) {
        const item = document.querySelector(`.badge-selector-item[data-badge="${badge}"]`);
        if (!item) return;

        const isSelected = item.classList.contains('selected');
        const selectedCount = document.querySelectorAll('.badge-selector-item.selected').length;

        if (!isSelected && selectedCount >= 3) {
            Toast.warning('En fazla 3 rozet seçebilirsiniz!');
            return;
        }

        item.classList.toggle('selected');
        // Update styles
        if (item.classList.contains('selected')) {
            item.style.background = 'rgba(16, 185, 129, 0.2)';
            item.style.borderColor = '#10b981';
            item.innerHTML = `<i class="fa-solid fa-check" style="color: #10b981;"></i><span style="font-size: 1rem;">${badge}</span>`;
        } else {
            item.style.background = 'rgba(255,255,255,0.05)';
            item.style.borderColor = 'rgba(255,255,255,0.1)';
            item.innerHTML = `<span style="font-size: 1rem;">${badge}</span>`;
        }
    },

    async saveSettings() {
        const bio = document.getElementById('settings-bio').value;
        const avatarText = document.getElementById('settings-avatar-text').value;
        const avatarFile = document.getElementById('settings-avatar-file').files[0];
        const instagram = document.getElementById('settings-insta').value;
        const twitter = document.getElementById('settings-twitter').value;
        const discord = document.getElementById('settings-discord').value;
        const birthDate = document.getElementById('settings-birth-date').value;

        // Validation for Birth Date if it's first time
        if (!State.currentUser.birthDate && !birthDate) {
            Toast.warning('Lütfen yaş sınırlı içerikler için doğum tarihinizi girin.');
            return;
        }


        let avatarUrl = avatarText;

        // If file selected, upload it first
        if (avatarFile) {
            // Check size (2MB)
            if (avatarFile.size > 2 * 1024 * 1024) {
                Toast.error('Dosya boyutu 2MB\'dan büyük olamaz!');
                return;
            }

            const formData = new FormData();
            formData.append('media', avatarFile);

            Toast.info('Resim işleniyor...');
            try {
                // Use Local-First MediaDB instead of remote upload
                const mediaId = await MediaDB.saveMedia(avatarFile, 'avatar');
                avatarUrl = 'media-idb:' + mediaId;
                console.log('✅ Avatar saved to MediaDB:', mediaId);
            } catch (e) {
                Toast.error('Yükleme sırasında bir hata oluştu.');
                return;
            }
        }

        // Get selected display badges
        const displayBadges = Array.from(document.querySelectorAll('.badge-selector-item.selected'))
            .map(el => el.dataset.badge)
            .slice(0, 3);

        const updates = {
            bio, avatar: avatarUrl,
            isPrivate: document.getElementById('settings-is-private')?.checked || false,
            twoFactorEnabled: document.getElementById('settings-2fa')?.checked || false,
            socialLinks: { instagram, twitter, discord },
            activeFrame: this.currentSelectedFrame || State.currentUser.activeFrame || 'default',
            displayBadges: displayBadges
        };

        // Only update birthDate if not already set
        if (!State.currentUser.birthDate && birthDate) {
            updates.birthDate = birthDate;
        }


        try {
            Object.assign(State.currentUser, updates);
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            if (window.db) await db.updateUser(State.currentUser.id, updates);
            if (window.Auth && Auth.updateAuthUI) Auth.updateAuthUI();
            Toast.success('Profil güncellendi!');
            this.switchTab('overview');
            this.show(State.currentUser.id); // Reload shell
        } catch (e) {
            Toast.error('Hata: ' + e.message);
        }
    },

    async requestVerification() {
        if (!State.currentUser) return;
        Toast.info('Başvuru iletiliyor...');
        try {
            const updates = { verificationRequested: true, verificationStatus: 'pending' };
            Object.assign(State.currentUser, updates);
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            if (window.db) await db.updateUser(State.currentUser.id, updates);
            Toast.success('Mavi Tik başvurunuz başarıyla iletildi! İncelendikten sonra e-postanıza onay bağlantısı gönderilecektir.');
            this.switchTab('settings');
        } catch (e) {
            Toast.error('Başvuru yapılamadı.');
        }
    },

    async sendFriendRequest(targetId) {
        if (typeof Social !== 'undefined' && Social.sendFriendRequest) {
            await Social.sendFriendRequest(targetId);
            this.show(this.currentUserId);
        } else {
            Toast.error('Sosyal servis aktif değil.');
        }
    },

    async acceptFriend(targetId) {
        if (typeof Social !== 'undefined' && Social.acceptFriendRequest) {
            await Social.acceptFriendRequest(targetId);
            this.show(this.currentUserId);
        } else {
            Toast.error('Sosyal servis aktif değil.');
        }
    },

    async removeFriend(targetId) {
        if (typeof Social !== 'undefined' && Social.removeFriend) {
            await Social.removeFriend(targetId);
            this.show(this.currentUserId);
        }
    },

    async blockUser(targetId) {
        if (!State.currentUser) return;

        if (!State.currentUser.blockedUsers) State.currentUser.blockedUsers = [];
        if (State.currentUser.blockedUsers.includes(targetId)) {
            Toast.info('Kullanıcı zaten engellenmiş.');
            return;
        }

        if (confirm('Bu kullanıcıyı engellemek istediğinize emin misiniz?')) {
            State.currentUser.blockedUsers.push(targetId);

            // Remove from friends and following if present
            if (State.currentUser.friends) {
                State.currentUser.friends = State.currentUser.friends.filter(id => id !== targetId);
            }
            if (State.currentUser.following) {
                State.currentUser.following = State.currentUser.following.filter(id => id !== targetId);
            }

            if (window.db) {
                await db.updateUser(State.currentUser.id, {
                    blockedUsers: State.currentUser.blockedUsers,
                    friends: State.currentUser.friends,
                    following: State.currentUser.following
                });
            } else if (window.App && App.saveState) {
                App.saveState();
            }

            Toast.success('Kullanıcı engellendi.');
            this.show(this.currentUserId);
        }
    },

    async unblockUser(targetId) {
        if (!State.currentUser || !State.currentUser.blockedUsers) return;

        State.currentUser.blockedUsers = State.currentUser.blockedUsers.filter(id => id !== targetId);

        if (window.db) {
            await db.updateUser(State.currentUser.id, { blockedUsers: State.currentUser.blockedUsers });
        } else if (window.App && App.saveState) {
            App.saveState();
        }

        Toast.success('Engelleme kaldırıldı.');
        this.show(this.currentUserId);
    },

    renderAvatar(user, size) {
        const frameColor = this.getFrameColor(user.frame);
        return `<img src="${user.avatar || 'assets/logo.png'}" style="width: ${size}px; height: ${size}px; border-radius: 50%; border: 3px solid ${frameColor}; object-fit: cover;">`;
    },

    getFrameColor(frameId) {
        const map = { 'default': '#fff', 'neon_purple': '#8b5cf6', 'gold_vip': '#f59e0b', 'rose_gold': '#e11d48' };
        return map[frameId] || '#fff';
    },

    getRoleText(role) {
        const map = { 'admin': 'Yönetici', 'user': 'Kullanıcı', 'translator': 'Çevirmen' };
        return map[role] || 'Kullanıcı';
    },

    isVip(user) {
        return user.isVip || (user.vipUntil && new Date(user.vipUntil) > new Date());
    },

    // Messaging Logic
    async loadConversations() {
        if (!window.MessageService && window.App) await App.loadModule('MessageService');
        if (!window.MessageService) return;

        const list = document.getElementById('msg-conversations');
        if (!list) return;

        // Refresh messages first
        if (window.MessageService.fetchMessages) await MessageService.fetchMessages(State.currentUser.id);

        const conversations = MessageService.getConversations(State.currentUser.id);
        if (conversations.length === 0) {
            list.innerHTML = '<div style="padding:20px; text-align:center; color: #64748b;">Henüz mesaj yok.</div>';
            return;
        }

        list.innerHTML = conversations.map(c => {
            const isActive = this.activeConversationId === c.userId;
            return `
           <div class="msg-item ${isActive ? 'active' : ''}" onclick="UserProfile.openChat('${c.userId}')" 
                style="padding: 15px; cursor: pointer; border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s; background: ${isActive ? 'rgba(255,255,255,0.05)' : 'transparent'};">
               <div style="display: flex; gap: 10px; align-items: center;">
                   ${this.renderAvatar({ avatar: c.avatar, frame: c.frame }, 40)}
                   <div style="flex: 1; overflow: hidden;">
                       <div style="display: flex; justify-content: space-between;">
                           <div style="font-weight: 700; color: #fff; font-size: 0.95rem;">${c.username}</div>
                           <div style="font-size: 0.7rem; color: #64748b;">${this.formatTimeShort(c.lastMessage.timestamp)}</div>
                       </div>
                       <div style="font-size: 0.85rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; ${c.unreadCount > 0 ? 'font-weight: 700; color: #fff;' : ''}">
                           ${c.lastMessage.from === State.currentUser.id ? 'Siz: ' : ''}${c.lastMessage.text}
                       </div>
                   </div>
                   ${c.unreadCount > 0 ? `<div style="background: #8b5cf6; color: white; padding: 2px 6px; border-radius: 10px; font-size: 0.7rem; font-weight: 800;">${c.unreadCount}</div>` : ''}
               </div>
           </div>
        `}).join('');
    },

    openChat(userId) {
        this.activeConversationId = userId;
        this.loadConversations(); // Update active state

        const conversations = MessageService.getConversations(State.currentUser.id);
        let convo = conversations.find(c => c.userId === userId);
        
        if (!convo) {
            const targetUser = State.data.users?.find(u => u.id === userId) || { username: 'Bilinmeyen Kullanıcı', avatar: 'assets/logo.png' };
            convo = {
                userId: userId,
                username: targetUser.username,
                avatar: targetUser.avatar,
                frame: targetUser.frame,
                messages: [],
                unreadCount: 0
            };
        }

        // Mark as read
        convo.messages.forEach(m => {
            if (m.to === State.currentUser.id && !m.read) MessageService.markAsRead(m.id);
        });

        const chatArea = document.getElementById('msg-chat-area');
        chatArea.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 15px 20px; border-bottom: 1px solid rgba(255,255,255,0.05); background: rgba(0,0,0,0.2);">
                <div style="display: flex; align-items: center;">
                    ${this.renderAvatar({ avatar: convo.avatar, frame: convo.frame }, 36)}
                    <div style="margin-left: 12px;">
                        <div style="font-weight: 700; color: #fff;">${convo.username}</div>
                        <div style="font-size: 0.75rem; color: #10b981;">Çevrimiçi</div>
                    </div>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button onclick="UserProfile.openTradeModal('${userId}')" 
                            style="background: rgba(124, 58, 237, 0.1); border: 1px solid rgba(124, 58, 237, 0.3); color: #a78bfa; padding: 6px 14px; border-radius: 20px; font-size: 0.8rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 6px; transition: all 0.3s ease;"
                            onmouseover="this.style.background='rgba(124, 58, 237, 0.2)'"
                            onmouseout="this.style.background='rgba(124, 58, 237, 0.1)'">
                        <i class="fa-solid fa-handshake"></i> Takas Teklifi
                    </button>
                    <button onclick="DonationSystem.openModal('${userId}', '${convo.username}')" 
                            style="background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); color: #f59e0b; padding: 6px 14px; border-radius: 20px; font-size: 0.8rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 6px; transition: all 0.3s ease;"
                            onmouseover="this.style.background='rgba(245, 158, 11, 0.2)'"
                            onmouseout="this.style.background='rgba(245, 158, 11, 0.1)'">
                        <i class="fa-solid fa-coins"></i> Transfer
                    </button>
                </div>
            </div>
            <div id="chat-bubbles" style="flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 10px;">
                ${convo.messages.map(m => {
                    const isOwn = m.from === State.currentUser.id;
                    if (m.type === 'trade' && m.tradeDetails) {
                        const offeredCardIds = m.tradeDetails.offeredCardIds || [];
                        const offeredCoins = m.tradeDetails.offeredCoins || 0;
                        const requestedCardIds = m.tradeDetails.requestedCardIds || [];
                        
                        // Look up cards
                        const configCards = window.Gamification?.config?.cards || [];
                        const offeredCards = offeredCardIds.map(id => configCards.find(c => c.id === id)).filter(Boolean);
                        const requestedCards = requestedCardIds.map(id => configCards.find(c => c.id === id)).filter(Boolean);
                        
                        let statusHTML = '';
                        if (m.status === 'pending') {
                            if (isOwn) {
                                statusHTML = `<button onclick="UserProfile.cancelTradeOffer('${m.id}')" style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:#cbd5e1; padding:6px 12px; border-radius:8px; font-size:0.75rem; font-weight:800; cursor:pointer; width:100%;">İptal Et</button>`;
                            } else {
                                statusHTML = `
                                    <div style="display:flex; gap:8px;">
                                        <button onclick="UserProfile.acceptTradeOffer('${m.id}')" style="background:#10b981; border:none; color:#fff; padding:6px 12px; border-radius:8px; font-size:0.75rem; font-weight:800; cursor:pointer; flex:1;">Kabul Et</button>
                                        <button onclick="UserProfile.rejectTradeOffer('${m.id}')" style="background:rgba(239,68,68,0.1); border:1px solid #ef4444; color:#ef4444; padding:6px 12px; border-radius:8px; font-size:0.75rem; font-weight:800; cursor:pointer; flex:1;">Reddet</button>
                                    </div>
                                `;
                            }
                        } else if (m.status === 'accepted') {
                            statusHTML = `<span style="font-size:0.8rem; color:#10b981; font-weight:800; text-transform:uppercase; letter-spacing:0.5px; display:block; text-align:center;">✓ Takas Gerçekleşti</span>`;
                        } else if (m.status === 'rejected') {
                            statusHTML = `<span style="font-size:0.8rem; color:#ef4444; font-weight:800; text-transform:uppercase; letter-spacing:0.5px; display:block; text-align:center;">✗ Reddedildi</span>`;
                        } else {
                            statusHTML = `<span style="font-size:0.8rem; color:#64748b; font-weight:800; text-transform:uppercase; letter-spacing:0.5px; display:block; text-align:center;">✗ İptal Edildi</span>`;
                        }

                        return `
                            <div style="align-self: ${isOwn ? 'flex-end' : 'flex-start'}; 
                                        max-width: 290px; padding: 18px; border-radius: 20px;
                                        background: ${isOwn ? 'rgba(124, 58, 237, 0.15)' : 'rgba(255,255,255,0.03)'}; 
                                        border: 2px solid ${isOwn ? '#7c3aed' : 'rgba(255,255,255,0.08)'};
                                        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
                                        margin-bottom: 5px;">
                                <div style="display:flex; align-items:center; gap:8px; font-weight:900; color:${isOwn ? '#a78bfa' : '#fbbf24'}; font-size:0.95rem; margin-bottom:12px; text-transform:uppercase; letter-spacing:0.5px;">
                                    <i class="fa-solid fa-handshake"></i> Takas Teklifi
                                </div>
                                
                                <div style="font-size:0.75rem; color:#94a3b8; font-weight:700; text-transform:uppercase; margin-bottom:6px;">Sunulan:</div>
                                <div style="background:rgba(0,0,0,0.2); border-radius:12px; padding:8px 12px; margin-bottom:10px; border:1px solid rgba(255,255,255,0.03);">
                                    ${offeredCards.length > 0 ? `
                                        <div style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:8px;">
                                            ${offeredCards.map(c => `<img src="${c.avatar}" style="width:32px; height:32px; border-radius:50%; object-fit:cover; border:2px solid ${c.rarity === 'legendary' ? '#fbbf24' : '#8b5cf6'};" title="${c.name} (${c.rarity})">`).join('')}
                                        </div>
                                    ` : ''}
                                    ${offeredCoins > 0 ? `
                                        <div style="font-size:0.85rem; color:#fbbf24; font-weight:800; display:flex; align-items:center; gap:5px;">
                                            <i class="fa-solid fa-coins"></i> ${offeredCoins} Coin
                                        </div>
                                    ` : offeredCards.length === 0 ? '<span style="color:#64748b; font-size:0.8rem;">Hiçbir şey</span>' : ''}
                                </div>

                                <div style="font-size:0.75rem; color:#94a3b8; font-weight:700; text-transform:uppercase; margin-bottom:6px;">İstenen:</div>
                                <div style="background:rgba(0,0,0,0.2); border-radius:12px; padding:8px 12px; margin-bottom:15px; border:1px solid rgba(255,255,255,0.03);">
                                    ${requestedCards.length > 0 ? `
                                        <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                            ${requestedCards.map(c => `<img src="${c.avatar}" style="width:32px; height:32px; border-radius:50%; object-fit:cover; border:2px solid ${c.rarity === 'legendary' ? '#fbbf24' : '#8b5cf6'};" title="${c.name} (${c.rarity})">`).join('')}
                                        </div>
                                    ` : '<span style="color:#64748b; font-size:0.8rem;">Hediye / Ücretsiz</span>'}
                                </div>

                                ${statusHTML}
                            </div>
                        `;
                    }
                    return `
                        <div style="align-self: ${isOwn ? 'flex-end' : 'flex-start'}; 
                                    max-width: 70%; padding: 10px 15px; border-radius: 12px; font-size: 0.95rem; line-height: 1.4;
                                    background: ${isOwn ? '#8b5cf6' : 'rgba(255,255,255,0.1)'}; 
                                    color: ${isOwn ? '#fff' : '#e2e8f0'};
                                    border-bottom-${isOwn ? 'right' : 'left'}-radius: 2px;">
                            ${m.text}
                        </div>
                    `;
                }).join('')}
            </div>
            <div style="padding: 15px; border-top: 1px solid rgba(255,255,255,0.05); display: flex; gap: 10px;">
                <input type="text" id="msg-input" placeholder="Bir mesaj yazın..." 
                       style="flex: 1; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 20px; padding: 10px 20px; color: #fff; outline: none;"
                       onkeypress="if(event.key==='Enter') UserProfile.sendMessage('${userId}')">
                <button onclick="UserProfile.sendMessage('${userId}')" style="background: #8b5cf6; border: none; color: white; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center;">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
        `;

        const bubbles = document.getElementById('chat-bubbles');
        if (bubbles) bubbles.scrollTop = bubbles.scrollHeight;
    },

    },

    openTradeModal(userId) {
        if (!window.Gamification) {
            Toast.error('Gamification modülü yüklenemedi.');
            return;
        }

        const recipientUser = State.data.users.find(u => u.id === userId);
        if (!recipientUser) {
            Toast.error('Kullanıcı bulunamadı.');
            return;
        }

        // Get own cards
        Gamification.initUserGamification();
        const myCards = State.currentUser.gamification?.cards || [];
        const partnerCards = recipientUser.gamification?.cards || [];
        const configCards = Gamification.config.cards || [];

        // Count occurrences
        const ownCounts = {};
        myCards.forEach(cid => ownCounts[cid] = (ownCounts[cid] || 0) + 1);

        const partnerCounts = {};
        partnerCards.forEach(cid => partnerCounts[cid] = (partnerCounts[cid] || 0) + 1);

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'trade-offer-modal';
        modal.style.display = 'flex';
        modal.style.zIndex = '3000';
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width: 650px; padding: 25px; max-height: 90vh; overflow-y: auto; background: rgba(10, 10, 15, 0.95); border: 1px solid rgba(255,255,255,0.08); border-radius: 24px; color:#fff;">
                <div class="modal-header" style="margin-bottom: 20px; display:flex; justify-content:space-between; align-items:center;">
                    <h2 style="margin:0; display:flex; align-items:center; gap:8px; font-size:1.4rem; font-weight:900;"><i class="fa-solid fa-handshake" style="color:#a78bfa;"></i> Takas Teklifi Oluştur</h2>
                    <button onclick="this.closest('.modal').remove()" style="background:none; border:none; color:white; font-size:1.5rem; cursor:pointer;">&times;</button>
                </div>
                
                <div class="modal-body" style="display:flex; flex-direction:column; gap:20px;">
                    <!-- Section 1: My Offer -->
                    <div>
                        <h3 style="font-size:1.05rem; color:#fff; margin-bottom:10px; font-weight:800;">1. Senin Teklifin (En Fazla 3 Kart)</h3>
                        <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap:10px; max-height: 200px; overflow-y:auto; padding:8px; background:rgba(0,0,0,0.3); border-radius:12px;" class="custom-scrollbar">
                            ${Object.keys(ownCounts).map(cid => {
                                const card = configCards.find(c => c.id === cid);
                                if (!card) return '';
                                return `
                                    <label style="display:flex; flex-direction:column; align-items:center; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:10px; border-radius:10px; cursor:pointer; text-align:center; position:relative; user-select:none;">
                                        <input type="checkbox" name="offeredCards" value="${card.id}" onchange="UserProfile.handleTradeCheckboxLimit(this, 3)" style="position:absolute; top:8px; left:8px; width:16px; height:16px; cursor:pointer;">
                                        <img src="${card.avatar}" style="width:45px; height:45px; border-radius:50%; object-fit:cover; margin-bottom:5px; border: 2px solid ${card.rarity === 'legendary' ? '#fbbf24' : '#8b5cf6'};">
                                        <span style="font-size:0.8rem; font-weight:800; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; width:100%;">${card.name}</span>
                                        <span style="font-size:0.7rem; color:#94a3b8;">Adet: ${ownCounts[cid]}</span>
                                    </label>
                                `;
                            }).join('') || '<div style="grid-column:1/-1; padding:20px; text-align:center; color:#64748b;">Envanterinizde hiç kart yok.</div>'}
                        </div>
                    </div>

                    <!-- Coin Offer -->
                    <div style="display:flex; align-items:center; justify-content:space-between; background:rgba(251,191,36,0.05); padding:12px 18px; border-radius:14px; border:1px solid rgba(251,191,36,0.15);">
                        <span style="font-weight:700; color:#fbbf24; display:flex; align-items:center; gap:8px;"><i class="fa-solid fa-coins"></i> Coin Teklif Et (Bakiye: ${State.currentUser.stats?.coins || 0})</span>
                        <input type="number" id="trade-offer-coins" min="0" max="${State.currentUser.stats?.coins || 0}" value="0" style="width:100px; padding:6px 12px; background:rgba(0,0,0,0.3); border:1px solid rgba(251,191,36,0.3); border-radius:8px; color:#fff; font-weight:800; outline:none; text-align:right;">
                    </div>

                    <!-- Section 2: Requested Cards -->
                    <div>
                        <h3 style="font-size:1.05rem; color:#fff; margin-bottom:10px; font-weight:800;">2. Karşı Taraftan İstenen (En Fazla 3 Kart)</h3>
                        <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap:10px; max-height: 200px; overflow-y:auto; padding:8px; background:rgba(0,0,0,0.3); border-radius:12px;" class="custom-scrollbar">
                            ${Object.keys(partnerCounts).map(cid => {
                                const card = configCards.find(c => c.id === cid);
                                if (!card) return '';
                                return `
                                    <label style="display:flex; flex-direction:column; align-items:center; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); padding:10px; border-radius:10px; cursor:pointer; text-align:center; position:relative; user-select:none;">
                                        <input type="checkbox" name="requestedCards" value="${card.id}" onchange="UserProfile.handleTradeCheckboxLimit(this, 3)" style="position:absolute; top:8px; left:8px; width:16px; height:16px; cursor:pointer;">
                                        <img src="${card.avatar}" style="width:45px; height:45px; border-radius:50%; object-fit:cover; margin-bottom:5px; border: 2px solid ${card.rarity === 'legendary' ? '#fbbf24' : '#8b5cf6'};">
                                        <span style="font-size:0.8rem; font-weight:800; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; width:100%;">${card.name}</span>
                                        <span style="font-size:0.7rem; color:#94a3b8;">Adet: ${partnerCounts[cid]}</span>
                                    </label>
                                `;
                            }).join('') || '<div style="grid-column:1/-1; padding:20px; text-align:center; color:#64748b;">Karşı tarafın envanterinde kart yok.</div>'}
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <button onclick="UserProfile.submitTradeOffer('${userId}')" style="background: linear-gradient(135deg, #7c3aed, #6d28d9); border:none; color:white; padding:14px; border-radius:12px; font-weight:800; cursor:pointer; margin-top:10px; box-shadow: 0 4px 15px rgba(124, 58, 237, 0.3); font-family:inherit;">
                        <i class="fa-solid fa-paper-plane"></i> Takas Teklifini Gönder
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    handleTradeCheckboxLimit(checkbox, limit) {
        const name = checkbox.name;
        const checked = document.querySelectorAll(`input[name="${name}"]:checked`);
        if (checked.length > limit) {
            checkbox.checked = false;
            Toast.warning(`En fazla ${limit} kart seçebilirsiniz!`);
        }
    },

    async submitTradeOffer(toUserId) {
        const offeredCheckboxes = document.querySelectorAll('input[name="offeredCards"]:checked');
        const requestedCheckboxes = document.querySelectorAll('input[name="requestedCards"]:checked');
        const coinsInput = document.getElementById('trade-offer-coins');
        const coins = parseInt(coinsInput ? coinsInput.value : '0');

        const offeredCardIds = Array.from(offeredCheckboxes).map(cb => cb.value);
        const requestedCardIds = Array.from(requestedCheckboxes).map(cb => cb.value);

        if (offeredCardIds.length === 0 && coins <= 0) {
            Toast.error('Lütfen en az bir kart veya Coin teklif edin!');
            return;
        }

        if (coins > (State.currentUser.stats?.coins || 0)) {
            Toast.error('Yetersiz Coin bakiyesi!');
            return;
        }

        const tradeDetails = {
            offeredCardIds,
            offeredCoins: coins,
            requestedCardIds
        };

        const res = await MessageService.sendTradeMessage(toUserId, tradeDetails);
        if (res.success) {
            Toast.success('Takas teklifiniz başarıyla gönderildi!');
            document.getElementById('trade-offer-modal').remove();
            this.openChat(toUserId);
        } else {
            Toast.error('Teklif gönderilemedi.');
        }
    },

    async acceptTradeOffer(msgId) {
        const msg = State.data.messages.find(m => m.id === msgId);
        if (!msg || msg.status !== 'pending') return;

        const sender = State.data.users.find(u => u.id === msg.from) || (msg.from === State.currentUser.id ? State.currentUser : null);
        const recipient = State.data.users.find(u => u.id === msg.to) || (msg.to === State.currentUser.id ? State.currentUser : null);

        if (!sender || !recipient) {
            Toast.error('Kullanıcı bulunamadı!');
            return;
        }

        // Validate Sender has the offered cards and coins
        const senderCoins = sender.stats?.coins || 0;
        const offeredCoins = parseInt(msg.tradeDetails.offeredCoins || '0');
        if (senderCoins < offeredCoins) {
            Toast.error('Teklifi gönderen kişinin yeterli coini yok!');
            return;
        }

        const senderCards = sender.gamification?.cards || [];
        const offeredCardIds = msg.tradeDetails.offeredCardIds || [];
        // Check if sender has all offered cards
        const tempSenderCards = [...senderCards];
        for (const cid of offeredCardIds) {
            const index = tempSenderCards.indexOf(cid);
            if (index === -1) {
                Toast.error('Teklifi gönderen kişi artık bu kartlara sahip değil!');
                return;
            }
            tempSenderCards.splice(index, 1);
        }

        // Validate Recipient has the requested cards
        const recipientCards = recipient.gamification?.cards || [];
        const requestedCardIds = msg.tradeDetails.requestedCardIds || [];
        const tempRecipientCards = [...recipientCards];
        for (const cid of requestedCardIds) {
            const index = tempRecipientCards.indexOf(cid);
            if (index === -1) {
                Toast.error('İstenen kartlar envanterinizde bulunamadı!');
                return;
            }
            tempRecipientCards.splice(index, 1);
        }

        // Process Trade!
        // 1. Move offered cards and coins from Sender to Recipient
        if (!recipient.stats) recipient.stats = { coins: 0, level: 1, xp: 0 };
        if (!sender.stats) sender.stats = { coins: 0, level: 1, xp: 0 };
        sender.stats.coins -= offeredCoins;
        recipient.stats.coins += offeredCoins;

        if (!sender.gamification) sender.gamification = { cards: [] };
        if (!recipient.gamification) recipient.gamification = { cards: [] };

        offeredCardIds.forEach(cid => {
            const idx = sender.gamification.cards.indexOf(cid);
            if (idx !== -1) sender.gamification.cards.splice(idx, 1);
            if (!recipient.gamification.cards) recipient.gamification.cards = [];
            recipient.gamification.cards.push(cid);
        });

        // 2. Move requested cards from Recipient to Sender
        requestedCardIds.forEach(cid => {
            const idx = recipient.gamification.cards.indexOf(cid);
            if (idx !== -1) recipient.gamification.cards.splice(idx, 1);
            if (!sender.gamification.cards) sender.gamification.cards = [];
            sender.gamification.cards.push(cid);
        });

        // 3. Mark message as accepted
        msg.status = 'accepted';
        msg.text = '🤝 Takas Başarıyla Gerçekleşti!';
        
        // Save to Database
        if (window.db) {
            await db.updateUser(sender.id, { stats: sender.stats, gamification: sender.gamification });
            await db.updateUser(recipient.id, { stats: recipient.stats, gamification: recipient.gamification });
            db.save();
        }

        // Send system update through API
        await fetch(`api/db.php?action=message-send`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(msg)
        });

        Toast.success('Takas başarıyla gerçekleşti! Envanterinizi kontrol edin.');
        
        // Refresh UI
        this.openChat(msg.from === State.currentUser.id ? msg.to : msg.from);
    },

    async rejectTradeOffer(msgId) {
        const msg = State.data.messages.find(m => m.id === msgId);
        if (!msg || msg.status !== 'pending') return;

        msg.status = 'rejected';
        msg.text = '❌ Takas Teklifi Reddedildi.';
        
        if (window.db) db.save();

        await fetch(`api/db.php?action=message-send`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(msg)
        });

        Toast.info('Takas teklifini reddettiniz.');
        this.openChat(msg.from === State.currentUser.id ? msg.to : msg.from);
    },

    async cancelTradeOffer(msgId) {
        const msg = State.data.messages.find(m => m.id === msgId);
        if (!msg || msg.status !== 'pending') return;

        msg.status = 'cancelled';
        msg.text = '🚫 Takas Teklifi İptal Edildi.';
        
        if (window.db) db.save();

        await fetch(`api/db.php?action=message-send`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(msg)
        });

        Toast.info('Takas teklifini iptal ettiniz.');
        this.openChat(msg.from === State.currentUser.id ? msg.to : msg.from);
    },

    startConversation(userId) {
        if (!State.currentUser) {
            Toast.error('Mesaj göndermek için giriş yapmalısınız');
            return;
        }

        // Set pending action
        this.pendingAction = {
            type: 'openChat',
            targetUserId: userId
        };

        // Router to own profile
        App.router('profile', State.currentUser.id);
    },

    formatTimeShort(ts) {
        if (!ts) return '';
        const d = new Date(ts);
        return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    },

    renderSeriesList(seriesList) {
        if (!seriesList || seriesList.length === 0) {
            return '<p style="color: #64748b; text-align: center; padding: 30px;">Hay\u0131r, hen\u00fcz eklenmi\u015f bir i\u00e7erik yok.</p>';
        }
        return seriesList.map(s => `
            <div class="std-card" onclick="App.router('detail', '${s.id}')" style="cursor: pointer;">
                <img src="${s.poster || 'assets/poster-placeholder.jpg'}" style="width: 100%; border-radius: 12px;" />
                <p style="margin-top: 8px; font-weight: 600; color: #e2e8f0; font-size: 0.85rem;">${s.title}</p>
            </div>
        `).join('');
    },

    // ==================== BLOCKED USERS ====================
    renderBlockedUsers(container) {
        const user = State.currentUser;
        const blocked = user?.blockedUsers || [];

        let html = `
            <div style="margin-bottom: 30px;">
                <h2 style="color: #fff; font-weight: 800; font-size: 1.4rem; margin-bottom: 8px;">
                    <i class="fa-solid fa-ban" style="color: #ef4444;"></i> Engellenen Kullan\u0131c\u0131lar
                </h2>
                <p style="color: #64748b; font-size: 0.9rem;">Engelledi\u011finiz kullan\u0131c\u0131lar\u0131n postlar\u0131n\u0131 g\u00f6remezsiniz ve onlar da sizin postlar\u0131n\u0131z\u0131 g\u00f6remez.</p>
            </div>
        `;

        if (blocked.length === 0) {
            html += `
                <div style="text-align: center; padding: 60px 20px;">
                    <i class="fa-solid fa-shield-check" style="font-size: 3rem; color: rgba(16,185,129,0.3); margin-bottom: 16px;"></i>
                    <h3 style="color: #94a3b8; font-weight: 600; margin-bottom: 8px;">Hi\u00e7 engellenen kullan\u0131c\u0131 yok</h3>
                    <p style="color: #475569; font-size: 0.85rem;">Sosyal ak\u0131\u015fta bir ki\u015finin post men\u00fcs\u00fcnden (\u22ee) engelleyebilirsiniz.</p>
                </div>
            `;
        } else {
            html += `
                <div style="background: rgba(239,68,68,0.04); border: 1px solid rgba(239,68,68,0.1); border-radius: 16px; padding: 14px 18px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-circle-info" style="color: #f87171;"></i>
                    <span style="color: #f87171; font-size: 0.82rem; font-weight: 500;">${blocked.length} kullan\u0131c\u0131 engellendi. Engeli kald\u0131rmak i\u00e7in a\u015fa\u011f\u0131daki butonlar\u0131 kullanabilirsiniz.</span>
                </div>
                <div style="display: grid; gap: 10px;">
            `;

            blocked.forEach(bid => {
                const bu = (State.data.users || []).find(u => u.id === bid);
                const username = bu?.username || bid;
                const avatar = bu?.avatar || 'assets/logo.png';

                html += `
                    <div style="display: flex; align-items: center; gap: 14px; padding: 14px 18px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); border-radius: 14px; transition: all 0.2s;">
                        <img src="${avatar}" style="width: 42px; height: 42px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(239,68,68,0.2);" onerror="this.src='assets/logo.png'">
                        <div style="flex: 1; min-width: 0;">
                            <div style="font-weight: 700; color: #e2e8f0; font-size: 0.9rem;">${username}</div>
                            <div style="font-size: 0.75rem; color: #64748b;">Engellendi</div>
                        </div>
                        <button onclick="UserProfile.unblockUser('${bid}')" 
                            style="padding: 8px 16px; background: rgba(16,185,129,0.08); border: 1px solid rgba(16,185,129,0.2); color: #10b981; border-radius: 10px; cursor: pointer; font-weight: 700; font-size: 0.8rem; font-family: 'Inter', sans-serif; transition: all 0.2s;"
                            onmouseenter="this.style.background='rgba(16,185,129,0.15)'"
                            onmouseleave="this.style.background='rgba(16,185,129,0.08)'">
                            <i class="fa-solid fa-unlock"></i> Engeli Kald\u0131r
                        </button>
                    </div>
                `;
            });

            html += '</div>';
        }

        container.innerHTML = html;
    },

    unblockFromProfile(userId) {
        if (!State.currentUser?.blockedUsers) return;
        const idx = State.currentUser.blockedUsers.indexOf(userId);
        if (idx > -1) {
            State.currentUser.blockedUsers.splice(idx, 1);
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            db.save();
            if (window.Toast) Toast.success('Engel kald\u0131r\u0131ld\u0131. \u2705');
            // Re-render
            const container = document.getElementById('profile-tab-content');
            if (container) this.renderBlockedUsers(container);
        }
    },

    shareList(listId) {
        const user = this.getUser();
        let url = '';
        if (listId === 'watchlist') {
            url = `${window.location.origin}/profile/${user.id}?tab=lists&view=watchlist`;
        } else {
            url = `${window.location.origin}/profile/${user.id}?tab=lists&view=${listId}`;
        }

        navigator.clipboard.writeText(url).then(() => {
            Toast.success('Liste linki kopyalandı! \ud83d\udd17');
        }).catch(err => {
            console.error('Copy failed:', err);
            Toast.info(`Link: ${url}`);
        });
    },

    renderQuests(container) {
        const user = this.getUser();
        const parliamentProgress = user.stats?.parliamentParticipation || 0;
        const seriesProgress = (user.stats?.watchedSeries || []).length;
        
        const quests = [
            { id: 'parlament', title: 'Parlamento Delege', desc: 'Parlamento oturumlarına katılarak diplomasi yeteneğini kanıtla.', icon: '⚖️', progress: parliamentProgress, total: 5, action: 'UserProfile.participateParliament()' },
            { id: 'watcher', title: 'Dizi Kurdu', desc: '10 farklı diziyi tamamen bitirerek gerçek bir uzman ol.', icon: '📺', progress: seriesProgress, total: 10, completed: seriesProgress >= 10 },
            { id: 'social', title: 'Sosyal Kelebek', desc: 'Social Karma puanını 100\'e çıkar.', icon: '🦋', progress: user.socialKarma || 0, total: 100 }
        ];

        container.innerHTML = `
            <div style="margin-bottom: 30px;">
                <h2 style="font-size: 1.8rem; font-weight: 800; color: #fff; margin-bottom: 10px;">Günlük & Sosyal Görevler</h2>
                <p style="color: #64748b;">Görevleri tamamlayarak XP, DramiCoin ve özel rozetler kazanabilirsin.</p>
            </div>
            <div style="display: grid; gap: 15px;">
                ${quests.map(q => {
                    const percent = Math.min(100, (q.progress / q.total) * 100);
                    return `
                        <div style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); padding: 25px; border-radius: 24px; display: flex; align-items: center; gap: 20px; transition: all 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.04)'; this.style.borderColor='rgba(139, 92, 246, 0.2)'" onmouseout="this.style.background='rgba(255,255,255,0.02)'; this.style.borderColor='rgba(255,255,255,0.05)'">
                            <div style="width: 70px; height: 70px; background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1)); border-radius: 20px; display: flex; align-items: center; justify-content: center; font-size: 2rem; border: 1px solid rgba(139, 92, 246, 0.1);">
                                ${q.icon}
                            </div>
                            <div style="flex: 1;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                    <h4 style="margin: 0; font-size: 1.2rem; font-weight: 800; color: #fff;">${q.title}</h4>
                                    <span style="font-size: 0.9rem; font-weight: 800; color: #a78bfa; background: rgba(167, 139, 250, 0.1); padding: 4px 12px; border-radius: 10px;">${q.progress} / ${q.total}</span>
                                </div>
                                <p style="margin: 0 0 15px; font-size: 0.9rem; color: #94a3b8; line-height: 1.4;">${q.desc}</p>
                                <div style="height: 8px; background: rgba(255,255,255,0.05); border-radius: 10px; overflow: hidden; border: 1px solid rgba(255,255,255,0.02);">
                                    <div style="height: 100%; width: ${percent}%; background: linear-gradient(90deg, #8b5cf6, #3b82f6); border-radius: 10px; box-shadow: 0 0 10px rgba(139, 92, 246, 0.3);"></div>
                                </div>
                            </div>
                            ${q.action && this.isOwnProfile() ? `
                                <button onclick="${q.action}" class="btn btn-primary" style="padding: 12px 24px; border-radius: 14px; font-weight: 800; background: linear-gradient(135deg, #7c3aed, #6366f1); border: none; box-shadow: 0 4px 15px rgba(124, 58, 237, 0.2);">Katıl</button>
                            ` : (q.completed ? '<div style="color: #10b981; font-size: 1.5rem;"><i class="fa-solid fa-circle-check"></i></div>' : '')}
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    },

    async participateParliament() {
        if (!State.currentUser) return;
        
        Toast.info('Parlamento oturumuna katılıyor...');
        
        // Use a timeout to simulate network/simulation delay
        setTimeout(async () => {
            if (!State.currentUser.stats) State.currentUser.stats = {};
            if (!State.currentUser.stats.parliamentParticipation) State.currentUser.stats.parliamentParticipation = 0;
            
            State.currentUser.stats.parliamentParticipation++;
            
            // Add XP via Gamification if available
            if (typeof Gamification !== 'undefined') {
                Gamification.addXP(20, 'Parlamento Katılımı');
            }
            
            // Save to DB
            if (window.db && db.updateUser) {
                await db.updateUser(State.currentUser.id, { stats: State.currentUser.stats });
            }
            
            // Update Session Storage
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            
            // Check for badges
            if (typeof BadgeSystem !== 'undefined') {
                BadgeSystem.checkAndAward(State.currentUser);
            }
            
            // Re-render current tab
            const container = document.getElementById('profile-tab-content');
            if (container) this.renderQuests(container);
            Toast.success('Parlamento oturumuna katıldınız! +20 XP kazandınız.');
        }, 800);
    },
};

window.UserProfile = UserProfile;
