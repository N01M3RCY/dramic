// ============================================
// STUDIO DASHBOARD PAGE
// Main dashboard for translators to manage assigned series and webtoons
// ============================================

window.StudioDashboard = {
    currentUser: null,
    currentTab: 'series', // 'series', 'webtoons', or 'shorts'
    assignedSeries: [],
    assignedWebtoons: [],
    allSeries: [],
    allWebtoons: [],
    allShorts: [],
    creatorStats: null,
    isAdmin: false,
    heroEditor: {
        currentSlideIndex: null,
        isEditing: false
    },

    async init() {
        console.log('🎬 StudioDashboard initializing...');
        this.currentUser = State.currentUser;

        if (!this.currentUser) {
            Toast.error('Lütfen giriş yapın');
            return;
        }

        // Auto-switch to webtoons tab for webtoon translators
        if (this.currentUser.role === 'webtoon-translator') {
            this.currentTab = 'webtoons';
        }

        this.isAdmin = this.currentUser.role === 'admin' || (this.currentUser.badges && this.currentUser.badges.includes('Yönetici'));

        await this.loadAssignments();
        await this.loadContent();
    },

    getEpisodeCount(series) {
        if (!series) return 0;
        if (series.episodes) return series.episodes.length;
        if (series.seasons) {
            return series.seasons.reduce((acc, s) => acc + (s.episodes ? s.episodes.length : 0), 0);
        }
        return 0;
    },

    getCompletedEpisodeCount(series) {
        if (!series) return 0;
        let count = 0;

        const countInList = (list) => {
            return list.filter(ep => ep.sources && ep.sources.length > 0).length;
        };

        if (series.episodes) count += countInList(series.episodes);
        if (series.seasons) {
            series.seasons.forEach(s => {
                if (s.episodes) count += countInList(s.episodes);
            });
        }
        return count;
    },

    async loadAssignments() {
        // Local-First Assignments
        this.assignedSeries = (State.data.seriesAssignments || []).filter(a =>
            a.translatorId === this.currentUser.id && a.status === 'active'
        );

        this.assignedWebtoons = (State.data.webtoonAssignments || []).filter(a =>
            a.translatorId === this.currentUser.id && a.status === 'active'
        );

        console.log('[StudioDashboard] Loaded assignments from State:', {
            series: this.assignedSeries.length,
            webtoons: this.assignedWebtoons.length
        });
    },

    async loadContent() {
        // Get assigned IDs
        const assignedSeriesIds = this.assignedSeries.map(a => a.seriesId);
        const assignedWebtoonIds = this.assignedWebtoons.map(a => a.webtoonId);

        // Filter based on role
        if (this.isAdmin) {
            // Admin sees everything
            this.allSeries = State.data.series || [];
            this.allWebtoons = State.data.webtoons || [];
        } else if (this.currentUser.role === 'translator') {
            // Series translator sees only assigned series
            this.allSeries = (State.data.series || []).filter(s =>
                assignedSeriesIds.includes(s.id)
            );
            this.allWebtoons = []; // No webtoons
        } else if (this.currentUser.role === 'webtoon-translator') {
            // Webtoon translator sees only assigned webtoons
            this.allSeries = []; // No series
            this.allWebtoons = (State.data.webtoons || []).filter(w =>
                assignedWebtoonIds.includes(w.id)
            );
        } else {
            // Default: show assigned only
            this.allSeries = (State.data.series || []).filter(s =>
                assignedSeriesIds.includes(s.id)
            );
            this.allWebtoons = (State.data.webtoons || []).filter(w =>
                assignedWebtoonIds.includes(w.id)
            );
        }


        // Load shorts (admin only for now)
        if (this.isAdmin) {
            try {
                // Check if API endpoint exists first or handle 404
                const shortsRes = await fetch('api/db.php?action=shorts-get');
                // Note: using db.php standard or specific endpoint? 
                // Original code used /api/shorts.php. Let's revert to that or use a safe empty array if not sure.
                // For now, let's look at the original intent. 
                // If /api/shorts.php doesn't exist, this throws. 
                // Let's safe guard it.
                if (shortsRes.ok) {
                    const shortsData = await shortsRes.json();
                    this.allShorts = shortsData.success ? shortsData.data : [];
                } else {
                    this.allShorts = [];
                }
            } catch (e) {
                console.warn('Shorts yüklenemedi (API mevcut olmayabilir):', e);
                this.allShorts = [];
            }
        }

        console.log('[StudioDashboard] Loaded content:', {
            series: this.allSeries.length,
            webtoons: this.allWebtoons.length,
            shorts: this.allShorts ? this.allShorts.length : 0,
            role: this.currentUser.role
        });

        this.render();
    },

    async switchTab(tab) {
        this.currentTab = tab;
        const area = document.getElementById('studio-content-area');
        if (!area) return;

        // Update Title & Subtitle based on tab
        const titleEl = document.getElementById('admin-page-title');
        const subEl = document.getElementById('admin-page-subtitle');

        // Update Sidebar Active State
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('onclick')?.includes(`'${tab}'`)) link.classList.add('active');
        });

        area.innerHTML = '<div class="loading-spinner">Yükleniyor...</div>';

        try {
            switch (tab) {
                case 'dashboard':
                    titleEl.innerText = 'Dramicbox Studio';
                    subEl.innerText = 'Bugün stüdyonun genel durumu bu şekilde. 👋';
                    area.innerHTML = this.renderDashboard();
                    break;
                case 'series':
                    titleEl.innerText = 'Dizi Yönetimi';
                    subEl.innerText = 'Sistemdeki tüm dizileri buradan yönetebilirsiniz.';
                    await db.loadData(['series']);
                    this.allSeries = (State.data.series || []).filter(s => s.type !== 'movie' && s.type !== 'anime');
                    area.innerHTML = this.renderSeriesGrid();
                    break;
                case 'anime':
                    titleEl.innerText = 'Anime Yönetimi';
                    subEl.innerText = 'Sistemdeki tüm animeleri buradan yönetebilirsiniz.';
                    await db.loadData(['series']);
                    area.innerHTML = this.renderAnimeGrid();
                    break;
                case 'movies':
                    titleEl.innerText = 'Film Yönetimi';
                    subEl.innerText = 'Sistemdeki tüm filmleri buradan yönetebilirsiniz.';
                    await db.loadData(['series']);
                    area.innerHTML = this.renderMoviesGrid();
                    break;
                case 'webtoons':
                    titleEl.innerText = 'Webtoon Yönetimi';
                    subEl.innerText = 'Sistemdeki tüm webtoonları buradan yönetebilirsiniz.';
                    await db.loadData(['webtoons']);
                    this.allWebtoons = State.data.webtoons || [];
                    area.innerHTML = this.renderWebtoonsGrid();
                    break;
                case 'users':
                    titleEl.innerText = 'Üye Yönetimi';
                    subEl.innerText = 'Tüm kullanıcıları ve yetkilerini buradan yönetin.';
                    area.innerHTML = await this.renderUserCenter();
                    break;
                case 'reports':
                    titleEl.innerText = 'Şikayet Merkezi';
                    subEl.innerText = 'Kullanıcılardan gelen hataları ve şikayetleri inceleyin.';
                    area.innerHTML = await this.renderReportCenter();
                    break;
                case 'production':
                    titleEl.innerText = 'Üretim Akışı';
                    subEl.innerText = 'Hazırlık aşamasındaki bölümleri takip edin.';
                    area.innerHTML = this.renderProductionFlow();
                    break;
                case 'settings':
                    titleEl.innerText = 'Sistem Ayarları';
                    subEl.innerText = 'Veritabanı ve genel sistem yapılandırmasını yönetin.';
                    area.innerHTML = this.renderSystemSettings();
                    break;
            }
        } catch (e) {
            console.error('Tab switch error:', e);
            area.innerHTML = '<p class="error">Veriler yüklenemedi.</p>';
        }
    },

    toggleCategory(catId) {
        const sub = document.getElementById(`nav-sub-${catId}`);
        if (sub) {
            sub.style.display = sub.style.display === 'none' ? 'block' : 'none';
        }
    },

    renderDashboard() {
        const stats = this.getGlobalStats();
        return `
            <div class="m-hub-dashboard">
                <div class="dashboard-stats-row">
                    <div class="dashboard-hero-card">
                        <h2>Hoşgeldin, ${this.currentUser.username}!</h2>
                        <p>Bugün stüdyonun genel durumu bu şekilde. 👋</p>
                    </div>
                    
                    <div class="stat-mini-card">
                        <div class="mini-label">Sistem Trafik Trendi</div>
                        <div class="mini-chart">
                            <!-- SVG Chart Simulation -->
                            <svg viewBox="0 0 100 40" class="sparkline">
                                <path d="M0,35 Q20,10 40,25 T80,5 T100,20" fill="none" stroke="var(--m-accent-cyan)" stroke-width="2" />
                            </svg>
                        </div>
                    </div>

                    <div class="stat-mini-card">
                        <div class="mini-label">Son Aktiviteler</div>
                        <div class="mini-activity-list">
                            <div class="mini-act"><i class="fa-solid fa-film"></i> Yeni Dizi Eklendi</div>
                            <div class="mini-act"><i class="fa-solid fa-bullhorn"></i> Duyuru Yayınlandı</div>
                        </div>
                    </div>
                </div>

                <div class="dashboard-main-grid">
                    <div class="glass-panel">
                        <h3>Son Eklenen İçerikler</h3>
                        <div class="m-table-wrap">
                            <table class="m-hub-table">
                                <thead>
                                    <tr>
                                        <th>İçerik</th>
                                        <th>Tür</th>
                                        <th>Durum</th>
                                        <th>İşlem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${this.allSeries.slice(0, 5).map(s => `
                                        <tr>
                                            <td><div class="table-user-cell"><img src="${s.poster}"> <span>${s.title}</span></div></td>
                                            <td><span class="type-badge ${s.type}">${s.type === 'drama' ? 'Dizi' : s.type}</span></td>
                                            <td><span class="status-badge ${s.status}">${s.status}</span></td>
                                            <td><button onclick="AdminContent.showAddSeriesModal('${s.id}')"><i class="fa-solid fa-pen"></i></button></td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="glass-panel">
                        <h3>İçerik Dağılımı</h3>
                        <div class="chart-container" style="height: 200px; display: flex; align-items: center; justify-content: center;">
                            <div class="pie-sim" style="width: 150px; height: 150px; border-radius: 50%; background: conic-gradient(var(--m-accent-cyan) 40%, var(--m-accent-violet) 40% 70%, var(--m-accent-pink) 70%);"></div>
                        </div>
                        <div class="chart-legend" style="margin-top: 20px; display: grid; gap: 10px;">
                            <div style="display: flex; align-items: center; gap: 10px;"><div style="width:12px;height:12px;border-radius:3px;background:var(--m-accent-cyan);"></div> Diziler</div>
                            <div style="display: flex; align-items: center; gap: 10px;"><div style="width:12px;height:12px;border-radius:3px;background:var(--m-accent-violet);"></div> Animeler</div>
                            <div style="display: flex; align-items: center; gap: 10px;"><div style="width:12px;height:12px;border-radius:3px;background:var(--m-accent-pink);"></div> Webtoonlar</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    getGlobalStats() {
        return {
            totalContent: (State.data.series?.length || 0) + (State.data.webtoons?.length || 0),
            totalUsers: State.data.users?.length || 0,
            activeVisitors: 42 // Simulated
        };
    },

    async renderUserCenter() {
        await db.loadData(['users']);
        const users = State.data.users || [];
        return `
            <div class="glass-panel">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h3>Üye Merkezi (${users.length})</h3>
                    <input type="text" placeholder="Üye ara..." class="m-input" style="width:200px; padding:8px 15px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff;">
                </div>
                <div class="m-table-wrap">
                    <table class="m-hub-table">
                        <thead>
                            <tr>
                                <th>Üye</th>
                                <th>Rol</th>
                                <th>Seviye</th>
                                <th>Kayıt Tarihi</th>
                                <th>Durum</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${users.map(u => `
                                <tr>
                                    <td><div class="table-user-cell"><img src="${u.avatar || 'assets/logo.png'}"> <span>${u.username}</span></div></td>
                                    <td><span class="role-badge ${u.role}">${u.role}</span></td>
                                    <td>Lv. ${u.stats?.level || 1}</td>
                                    <td>${u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '-'}</td>
                                    <td><span class="status-dot ${this.isOnline(u) ? 'online' : 'offline'}"></span> ${this.isOnline(u) ? 'Çevrimiçi' : 'Çevrimdışı'}</td>
                                    <td>
                                        <button onclick="StudioDashboard.editUser('${u.id}')" class="m-action-btn"><i class="fa-solid fa-user-gear"></i></button>
                                        <button onclick="StudioDashboard.banUser('${u.id}')" class="m-action-btn delete"><i class="fa-solid fa-user-slash"></i></button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    },

    async renderReportCenter() {
        const res = await fetch('api/index.php?action=report-list');
        const data = await res.json();
        const reports = data.success ? data.data : [];

        return `
            <div class="glass-panel" style="animation: fadeIn 0.5s ease;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:25px; padding-bottom:15px; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <div style="display:flex; align-items:center; gap:12px;">
                        <div style="width:40px; height:40px; background:rgba(239, 68, 68, 0.1); border-radius:12px; display:flex; align-items:center; justify-content:center; border:1px solid rgba(239, 68, 68, 0.2);">
                            <i class="fa-solid fa-triangle-exclamation" style="color:#ef4444;"></i>
                        </div>
                        <h3 style="margin:0;">Şikayet & Telif İhbarları (${reports.length})</h3>
                    </div>
                </div>
                ${reports.length === 0 ? `
                    <div style="text-align:center; padding:50px; color:var(--m-text-muted);">
                        <i class="fa-solid fa-circle-check" style="font-size:3rem; margin-bottom:15px; opacity:0.3; color:var(--m-accent-cyan);"></i>
                        <p>Henüz aktif şikayet veya telif bildirimi bulunmuyor.</p>
                    </div>
                ` : `
                    <div class="m-table-wrap">
                        <table class="m-hub-table">
                            <thead>
                                <tr>
                                    <th>İçerik/URL</th>
                                    <th>Bildiren</th>
                                    <th>İletişim</th>
                                    <th>Tarih</th>
                                    <th>Durum</th>
                                    <th>İşlem</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${reports.map(r => `
                                    <tr>
                                        <td><div style="max-width:300px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${r.url}">${r.url}</div></td>
                                        <td>${r.owner || r.username || 'Anonim'}</td>
                                        <td>${r.email || '-'}</td>
                                        <td>${new Date(r.createdAt).toLocaleDateString()}</td>
                                        <td><span class="status-badge ${r.status === 'open' || r.status === 'pending' ? 'pending' : 'completed'}">${r.status === 'pending' ? 'Bekliyor' : 'İncelendi'}</span></td>
                                        <td>
                                            <button onclick="StudioDashboard.viewReportDetails('${r.id}')" class="m-action-btn" title="Detaylar"><i class="fa-solid fa-eye"></i></button>
                                            <button onclick="StudioDashboard.deleteReport('${r.id}')" class="m-action-btn delete" title="Sil"><i class="fa-solid fa-trash-can"></i></button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `}
            </div>
        `;
    },

    async deleteReport(id) {
        if (!confirm('Bu raporu kalıcı olarak silmek istediğinize emin misiniz?')) return;
        try {
            const res = await fetch(`api/index.php?action=report-delete&id=${id}`);
            const data = await res.json();
            if (data.success) {
                Toast.success('Rapor başarıyla silindi.');
                this.switchTab('reports');
            } else {
                Toast.error(data.error || 'Hata oluştu.');
            }
        } catch (e) { Toast.error('Sunucu hatası.'); }
    },

    viewReportDetails(id) {
        // Simple alert for now, can be expanded to a modal
        Toast.info('Rapor detayları konsolda görüntülendi.');
        console.log('Report Detail:', id);
    },

    isOnline(user) {
        if (!user.lastActive) return false;
        const diff = Date.now() - new Date(user.lastActive).getTime();
        return diff < 5 * 60 * 1000; // 5 minutes
    },

    renderProductionFlow() {
        return `
            <div class="glass-panel">
                <h3>Üretim Akışı</h3>
                <p>Yakında aktif edilecek...</p>
            </div>
        `;
    },

    renderSystemSettings() {
        return `
            <div class="glass-panel" style="max-width: 800px; animation: fadeIn 0.5s ease;">
                <div style="display:flex; align-items:center; gap:15px; margin-bottom:30px; padding-bottom:20px; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <div style="width:50px; height:50px; background:rgba(139, 92, 246, 0.1); border-radius:15px; display:flex; align-items:center; justify-content:center; border:1px solid rgba(139, 92, 246, 0.2);">
                        <i class="fa-solid fa-gears" style="color:var(--m-accent-violet); font-size:1.5rem;"></i>
                    </div>
                    <div>
                        <h3 style="margin:0; font-family:'Outfit', sans-serif;">Sistem & Veritabanı Yapılandırması</h3>
                        <p style="margin:5px 0 0; font-size:0.85rem; color:var(--m-text-muted);">InfinityFree veya diğer hosting MySQL bilgilerini buradan ayarlayın.</p>
                    </div>
                </div>

                <div class="settings-form" style="display:grid; gap:20px;">
                    <div class="m-form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                        <div class="m-form-group">
                            <label style="display:block; margin-bottom:8px; font-size:0.8rem; font-weight:700; color:var(--m-text-muted); text-transform:uppercase; letter-spacing:1px;">MySQL Host (Sunucu)</label>
                            <input type="text" id="db-host" class="m-input" placeholder="örn: sql311.infinityfree.com" style="width:100%;" value="localhost">
                        </div>
                        <div class="m-form-group">
                            <label style="display:block; margin-bottom:8px; font-size:0.8rem; font-weight:700; color:var(--m-text-muted); text-transform:uppercase; letter-spacing:1px;">Veritabanı Adı (DB Name)</label>
                            <input type="text" id="db-name" class="m-input" placeholder="örn: if0_38294_dramicbox" style="width:100%;" value="dramicbox">
                        </div>
                    </div>

                    <div class="m-form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                        <div class="m-form-group">
                            <label style="display:block; margin-bottom:8px; font-size:0.8rem; font-weight:700; color:var(--m-text-muted); text-transform:uppercase; letter-spacing:1px;">Veritabanı Kullanıcısı (DB User)</label>
                            <input type="text" id="db-user" class="m-input" placeholder="örn: if0_38294" style="width:100%;" value="root">
                        </div>
                        <div class="m-form-group">
                            <label style="display:block; margin-bottom:8px; font-size:0.8rem; font-weight:700; color:var(--m-text-muted); text-transform:uppercase; letter-spacing:1px;">Veritabanı Şifresi (DB Password)</label>
                            <input type="password" id="db-pass" class="m-input" placeholder="MySQL şifreniz" style="width:100%;">
                        </div>
                    </div>

                    <div style="margin-top:20px; padding:20px; background:rgba(139, 92, 246, 0.05); border:1px solid rgba(139, 92, 246, 0.1); border-radius:15px; display:flex; gap:15px; align-items:flex-start;">
                        <i class="fa-solid fa-circle-info" style="color:var(--m-accent-violet); margin-top:3px;"></i>
                        <div>
                            <h4 style="margin:0 0 5px 0; font-size:0.9rem; color:#fff;">Önemli Bilgi</h4>
                            <p style="margin:0; font-size:0.8rem; line-height:1.5; color:var(--m-text-muted);">
                                Bilgileri kaydedince <code>api/config.php</code> dosyası güncellenecektir. 
                                Bağlantı başarılı olduktan sonra aşağıdaki <b>"Verileri SQL'e Taşı"</b> butonu ile eski JSON dosyalarınızı veritabanına aktarabilirsiniz.
                            </p>
                        </div>
                    </div>

                    <div style="display:flex; gap:15px; margin-top:10px;">
                        <button onclick="StudioDashboard.saveSystemConfig()" class="btn btn-primary" style="flex:1; padding:15px; border-radius:12px; font-weight:800; letter-spacing:1px;">
                            <i class="fa-solid fa-floppy-disk"></i> AYARLARI KAYDET
                        </button>
                        <button onclick="StudioDashboard.runMigration()" class="btn btn-secondary" style="flex:1; padding:15px; border-radius:12px; font-weight:800; letter-spacing:1px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1);">
                            <i class="fa-solid fa-database"></i> VERİLERİ SQL'E TAŞI
                        </button>
                    </div>
                </div>
            </div>
        `;
    },

    async saveSystemConfig() {
        const host = document.getElementById('db-host').value;
        const name = document.getElementById('db-name').value;
        const user = document.getElementById('db-user').value;
        const pass = document.getElementById('db-pass').value;

        if(!host || !name || !user) return Toast.warning('Şifre hariç tüm alanlar zorunludur!');

        Toast.info('Konfigürasyon güncelleniyor...');
        try {
            const res = await fetch('api/db.php?action=save-config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ db_host: host, db_name: name, db_user: user, db_pass: pass })
            });
            const data = await res.json();
            if (data.success) {
                Toast.success(data.message);
            } else {
                Toast.error(data.error || 'Hata oluştu');
            }
        } catch (e) {
            Toast.error('Sunucu bağlantı hatası.');
            console.error(e);
        }
    },

    async runMigration() {
        if (!confirm('Tüm JSON verileri MySQL veritabanına taşınacak. Emin misiniz?')) return;
        
        Toast.info('Migration başlatıldı, lütfen bekleyin...');
        try {
            const res = await fetch('api/migrate_to_mysql.php');
            const text = await res.text();
            if (text.toLowerCase().includes('success') || text.toLowerCase().includes('tamamlandı')) {
                Toast.success('Veriler başarıyla MySQL\'e taşındı!');
            } else {
                if (text.toLowerCase().includes('error') || text.toLowerCase().includes('failed')) {
                    Toast.error('Migration hatası. Detaylar konsolda.');
                    console.error(text);
                } else {
                    Toast.success('İşlem tamamlandı. Detayları konsoldan kontrol edin.');
                    console.log(text);
                }
            }
        } catch (e) {
            Toast.error('Migration scripti çalıştırılamadı.');
        }
    },

    async initView(container) {
        if (typeof container === 'string') container = document.getElementById(container);
        if (!container) return;
        
        this.containerOverride = container;
        await this.init();
    },

    show() {
        this.init().then(() => {
            this.render();
        });
    },

    getCurrentContent() {
        if (this.currentTab === 'series') {
            return this.allSeries || [];
        } else if (this.currentTab === 'webtoons') {
            return this.allWebtoons || [];
        } else if (this.currentTab === 'shorts') {
            return this.allShorts || [];
        } else {
            return []; // Stats tab doesn't have a content list in the same way
        }
    },

    renderWebtoonsGrid() {
        return this.allWebtoons.map(webtoon => {
            const assignedTo = webtoon.assignedTranslators || [];

            // Calculate progress (simulated for now as webtoons structure varies)
            // Assuming webtoons have episodes/chapters similar to series or different
            const episodeCount = webtoon.uploadedChapters || webtoon.episodes?.length || 0;
            // Completed count logic would depend on what constitutes "completed" for a translator assignment
            // For now, let's assume if it has source it's done, similar to series
            const completedCount = webtoon.episodes?.filter(ep => ep.sources && ep.sources.length > 0).length || 0;
            const progress = episodeCount > 0 ? (completedCount / episodeCount) * 100 : 0;

            return `
                <div class="series-card" data-webtoon-id="${webtoon.id}">
                    <img src="${webtoon.coverImage || webtoon.poster}" 
                         alt="${webtoon.name}" 
                         class="series-card-poster"
                         onerror="this.src='assets/placeholder.jpg'">
                    <div class="series-card-content">
                        <h3 class="series-card-title">${webtoon.name}</h3>
                        <div class="series-card-meta">
                            <span><i class="fa-solid fa-book-open"></i> ${episodeCount} Bölüm</span>
                            <span><i class="fa-solid fa-eye"></i> ${webtoon.views || 0}</span>
                        </div>
                        <div class="series-card-progress">
                             <div class="progress-bar">
                                 <div class="progress-fill" style="width: ${progress}%"></div>
                            </div>
                            <div class="progress-text">${Math.round(progress)}% Tamamlandı</div>
                        </div>
                        <div class="series-card-actions">
                            <button class="btn-studio" onclick="StudioDashboard.openWebtoonStudio('${webtoon.id}')" style="background: #8b5cf6;">
                                <i class="fa-solid fa-layer-group"></i> Bölüm Yönetimi
                            </button>
                             <button class="btn-edit" onclick="StudioDashboard.showEditWebtoonModal('${webtoon.id}')" style="background: #1e293b; color: #fff;">
                                <i class="fa-solid fa-edit"></i> Düzenle
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    },


    render() {
        // Use dedicated view container logic
        let container = this.containerOverride || document.getElementById('studio-dashboard-view');
        // Fix: Use admin-content-area if in admin panel, otherwise app-container
        const mainContent = document.getElementById('admin-content-area') || document.getElementById('app-container');

        if (!container && mainContent) {
            container = document.createElement('div');
            container.id = 'studio-dashboard-view';
            container.className = 'view-section studio-view';
            mainContent.appendChild(container);
        }

        if (!container) return;

        container.innerHTML = `
            <div class="m-hub-container">
                <!-- Sidebar -->
                <div class="m-hub-sidebar">
                    <div class="m-hub-logo">
                        <img src="assets/logo.png" alt="Logo">
                        <span>DRAMICBOX</span>
                        <div style="font-size: 0.6rem; color: var(--m-accent-violet); font-weight: 800; margin-top: -5px; opacity: 0.8;">YÖNETİM PANELİ</div>
                    </div>

                    <div class="m-hub-nav">
                        <!-- GENEL SECTION -->
                        <div class="nav-category">MENÜ</div>
                        <a href="#" class="nav-link ${this.currentTab === 'dashboard' ? 'active' : ''}" onclick="StudioDashboard.switchTab('dashboard')">
                            <i class="fa-solid fa-gauge-high"></i> Genel Durum
                        </a>

                        <!-- OPERASYONEL BİRİMLER -->
                        <div class="nav-category">OPERASYONEL BİRİMLER</div>
                        <a href="#" class="nav-link ${['series', 'movies', 'anime'].includes(this.currentTab) ? 'active' : ''}" onclick="StudioDashboard.toggleCategory('content')">
                            <i class="fa-solid fa-clapperboard"></i> İçerik Yönetimi
                            <i class="fa-solid fa-chevron-down" style="font-size: 0.7rem; margin-left: auto;"></i>
                        </a>
                        <div class="nav-sub" id="nav-sub-content" style="display: ${['series', 'movies', 'anime', 'webtoons'].includes(this.currentTab) ? 'block' : 'none'};">
                            <a href="#" class="nav-link-sub ${this.currentTab === 'series' ? 'active' : ''}" onclick="StudioDashboard.switchTab('series')">Diziler</a>
                            <a href="#" class="nav-link-sub ${this.currentTab === 'anime' ? 'active' : ''}" onclick="StudioDashboard.switchTab('anime')">Animeler</a>
                            <a href="#" class="nav-link-sub ${this.currentTab === 'movies' ? 'active' : ''}" onclick="StudioDashboard.switchTab('movies')">Filmler</a>
                            <a href="#" class="nav-link-sub ${this.currentTab === 'webtoons' ? 'active' : ''}" onclick="StudioDashboard.switchTab('webtoons')">Webtoonlar</a>
                        </div>

                        <a href="#" class="nav-link" onclick="BlogStudio.init()">
                            <i class="fa-solid fa-newspaper"></i> Blog Merkezi
                        </a>
                        <a href="#" class="nav-link" onclick="Journal.openManager()">
                            <i class="fa-solid fa-book-open"></i> E-Dergi Yönetimi
                        </a>

                        <!-- ÜRETİM & YAYIN HATTI -->
                        <div class="nav-category">ÜRETİM & YAYIN HATTI</div>
                        <a href="#" class="nav-link ${this.currentTab === 'production' ? 'active' : ''}" onclick="StudioDashboard.switchTab('production')">
                            <i class="fa-solid fa-list-check"></i> Üretim Akışı
                        </a>
                        <a href="#" class="nav-link" onclick="TranslationStudio.init()">
                            <i class="fa-solid fa-closed-captioning"></i> Altyazı Stüdyosu
                        </a>

                        <!-- SİSTEM DENETİMİ -->
                        <div class="nav-category">SİSTEM DENETİMİ</div>
                        <a href="#" class="nav-link" onclick="StudioDashboard.switchTab('actors')">
                            <i class="fa-solid fa-user-tie"></i> Oyuncu Merkezi
                        </a>
                        <a href="#" class="nav-link" onclick="StudioDashboard.switchTab('users')">
                            <i class="fa-solid fa-users"></i> Üye Merkezi
                        </a>
                        <a href="#" class="nav-link" onclick="StudioDashboard.switchTab('reports')">
                            <i class="fa-solid fa-triangle-exclamation"></i> Şikayet Merkezi
                        </a>
                        <a href="#" class="nav-link ${this.currentTab === 'analytics' ? 'active' : ''}" onclick="StudioDashboard.switchTab('analytics')">
                            <i class="fa-solid fa-chart-pie"></i> Analiz Merkezi
                        </a>
                        <a href="#" class="nav-link ${this.currentTab === 'settings' ? 'active' : ''}" onclick="StudioDashboard.switchTab('settings')">
                            <i class="fa-solid fa-screwdriver-wrench"></i> Sistem Ayarları
                        </a>
                        <a href="#" class="nav-link" onclick="StudioDashboard.switchTab('software')">
                            <i class="fa-solid fa-code"></i> Yazılım Merkezi <i class="fa-solid fa-lock" style="font-size:0.7rem;"></i>
                        </a>
                    </div>

                    <div class="m-hub-user-puck" onclick="App.router('profile', '${this.currentUser.id}')" style="cursor:pointer;">
                        <img src="${this.currentUser.avatar || 'assets/logo.png'}" alt="Avatar">
                        <div class="puck-info">
                            <div class="puck-name">${this.currentUser.username}</div>
                            <div class="puck-role">Verified Admin</div>
                        </div>
                        <i class="fa-solid fa-chevron-right" style="font-size: 0.8rem; opacity: 0.5;"></i>
                    </div>
                </div>

                <!-- Main Content Area -->
                <div class="m-hub-main">
                    <div class="m-hub-header">
                        <div>
                            <h1 id="admin-page-title">Yönetim Paneli</h1>
                            <p id="admin-page-subtitle">Hoşgeldin, ${this.currentUser.username}! İşte bugünlük durumun.</p>
                        </div>
                        <div class="header-actions" style="display: flex; gap: 15px;">
                            <button class="btn btn-secondary" onclick="StudioDashboard.repairSystem()">
                                <i class="fa-solid fa-screwdriver-wrench"></i> SİSTEMİ ONAR
                            </button>
                            <button class="btn btn-primary" onclick="AdminContent.showAddSeriesModal()">
                                <i class="fa-solid fa-plus"></i> YENİ İÇERİK EKLE
                            </button>
                        </div>
                    </div>

                    <div id="studio-content-area">
                        <!-- Dynamic Content Loaded Here -->
                        <div class="loading-spinner">Yükleniyor...</div>
                    </div>
                </div>
            </div>
        `;

        // Switch to default tab if needed
        if (this.currentTab === 'series') this.switchTab('series');
        else this.switchTab(this.currentTab);
    },

    renderSeriesGrid() {
        return `
            <div class="studio-grid">
                ${this.allSeries.map(s => `
                    <div class="studio-card">
                        <img src="${s.poster || 'assets/logo.png'}" class="studio-card-img">
                        <div class="studio-card-body">
                            <h3 class="studio-card-title">${s.title}</h3>
                            <div class="studio-card-meta">
                                <span><i class="fa-solid fa-eye"></i> ${s.views || 0}</span>
                                <span><i class="fa-solid fa-star"></i> ${s.rating || 0}</span>
                            </div>
                            <div class="studio-card-actions">
                                <button onclick="AdminContent.showAddSeriesModal('${s.id}')" class="btn btn-sm btn-outline">Düzenle</button>
                                <button onclick="StudioDashboard.showEpisodeManager('${s.id}')" class="btn btn-sm btn-primary">Bölümler</button>
                            </div>
                        </div>
                    </div>
                `).join('')}
                ${this.allSeries.length === 0 ? '<p style="color: #64748b; text-align: center; grid-column: 1/-1;">Henüz içerik eklememişsin.</p>' : ''}
            </div>
        `;
    },

    renderMoviesGrid() {
        const movies = (State.data.series || []).filter(s => s.type === 'movie');
        return `
            <div class="studio-grid">
                ${movies.map(m => `
                    <div class="studio-card">
                        <img src="${m.poster || 'assets/logo.png'}" class="studio-card-img">
                        ${m.status === 'Yakında' ? '<div style="position:absolute;top:10px;left:10px;background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;padding:4px 12px;border-radius:50px;font-size:0.7rem;font-weight:700;z-index:2;">🕐 Yakında</div>' : ''}
                        <div class="studio-card-body">
                            <h3 class="studio-card-title">${m.title}</h3>
                            <div class="studio-card-meta">
                                <span><i class="fa-solid fa-film"></i> Film</span>
                                <span><i class="fa-solid fa-eye"></i> ${m.views || 0}</span>
                                <span><i class="fa-solid fa-star"></i> ${m.rating || 0}</span>
                            </div>
                            <div class="studio-card-actions">
                                <button onclick="AdminContent.showAddSeriesModal('${m.id}')" class="btn btn-sm btn-outline">Düzenle</button>
                                <button onclick="StudioDashboard.showEpisodeManager('${m.id}')" class="btn btn-sm btn-primary">Bölümler</button>
                            </div>
                        </div>
                    </div>
                `).join('')}
                ${movies.length === 0 ? '<p style="color: #64748b; text-align: center; grid-column: 1/-1;">Henüz film eklenmemiş. "Yeni İçerik" butonuyla Film ekleyebilirsiniz.</p>' : ''}
            </div>
        `;
    },

    renderAnimeGrid() {
        const anime = (State.data.series || []).filter(s => s.type === 'anime');
        return `
            <div class="studio-grid">
                ${anime.map(a => `
                    <div class="studio-card">
                        <img src="${a.poster || 'assets/logo.png'}" class="studio-card-img">
                        ${a.status === 'Yakında' ? '<div style="position:absolute;top:10px;left:10px;background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;padding:4px 12px;border-radius:50px;font-size:0.7rem;font-weight:700;z-index:2;">🕐 Yakında</div>' : ''}
                        <div class="studio-card-body">
                            <h3 class="studio-card-title">${a.title}</h3>
                            <div class="studio-card-meta">
                                <span><i class="fa-solid fa-dragon"></i> Anime</span>
                                <span><i class="fa-solid fa-eye"></i> ${a.views || 0}</span>
                                <span><i class="fa-solid fa-star"></i> ${a.rating || 0}</span>
                            </div>
                            <div class="studio-card-actions">
                                <button onclick="AdminContent.showAddSeriesModal('${a.id}')" class="btn btn-sm btn-outline">Düzenle</button>
                                <button onclick="StudioDashboard.showEpisodeManager('${a.id}')" class="btn btn-sm btn-primary">Bölümler</button>
                            </div>
                        </div>
                    </div>
                `).join('')}
                ${anime.length === 0 ? '<p style="color: #64748b; text-align: center; grid-column: 1/-1;">Henüz anime eklenmemiş. "Yeni İçerik" butonuyla Anime ekleyebilirsiniz.</p>' : ''}
            </div>
        `;
    },
    showEpisodeManager(seriesId) {
        const series = (State.data.series || []).find(s => s.id === seriesId);
        if (!series) return;

        // Collect all episodes
        let allEpisodes = [];
        if (series.seasons) {
            series.seasons.forEach(s => {
                if (s.episodes) allEpisodes = allEpisodes.concat(s.episodes);
            });
        }
        if (series.episodes) {
            allEpisodes = allEpisodes.concat(series.episodes);
        }
        allEpisodes.sort((a, b) => a.number - b.number);

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'studio-episode-manager';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto;">
                <div class="modal-header">
                    <h2>${series.title} - Bölüm Yönetimi</h2>
                    <button class="modal-close" onclick="document.getElementById('studio-episode-manager').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div style="margin-bottom: 20px; display: flex; justify-content: flex-end;">
                        <button class="btn btn-success" onclick="StudioDashboard.showEpisodeEditor('${series.id}', null)">
                            <i class="fa-solid fa-plus"></i> Yeni Bölüm Ekle
                        </button>
                    </div>

                    <div class="episode-list" style="display: flex; flex-direction: column; gap: 10px;">
                        ${allEpisodes.length > 0 ? allEpisodes.map(ep => `
                            <div style="background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <div style="font-weight: bold; color: #e2e8f0;">${ep.number}. Bölüm: ${ep.title || 'Başlıksız'}</div>
                                    <div style="font-size: 12px; color: #94a3b8;">
                                        ${ep.sources && ep.sources.length > 0 ? '<span style="color:#10b981">Kaynak Var</span>' : '<span style="color:#f59e0b">Kaynak Yok</span>'}
                                    </div>
                                </div>
                                <div style="display: flex; gap: 8px;">
                                    <button class="btn btn-sm" onclick="VideoStudioPage.render({ seriesId: '${series.id}', episodeNumber: '${ep.number}', episodeId: '${ep.id}' })" style="background: #8b5cf6; color: white;">
                                        <i class="fa-solid fa-wand-magic-sparkles"></i> Studio
                                    </button>
                                    <button class="btn btn-sm btn-primary" onclick="StudioDashboard.showEpisodeEditor('${series.id}', '${ep.number}')">
                                        <i class="fa-solid fa-pen-to-square"></i> Düzenle
                                    </button>
                                </div>
                            </div>
                        `).join('') : '<p style="text-align: center; color: #94a3b8;">Henüz bölüm bulunmuyor.</p>'}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    showEpisodeEditor(seriesId, episodeNumber) {
        const series = this.allSeries.find(s => s.id === seriesId);
        if (!series) return;

        let episode = null;
        if (episodeNumber) {
            // Find episode
            if (series.seasons) {
                series.seasons.forEach(s => {
                    const found = s.episodes?.find(e => e.number == episodeNumber);
                    if (found) episode = found;
                });
            } else if (series.episodes) {
                episode = series.episodes.find(e => e.number == episodeNumber);
            }
        }

        // Determine current values
        const currentMaturity = series.ageRating || '13+';
        const epNum = episode ? episode.number : (this.getNextEpisodeNumber(series));
        const epTitle = episode ? (episode.title || '') : '';
        // Sources will be handled dynamically
        const existingSources = episode ? (episode.sources || []) : [];

        if (document.getElementById('studio-episode-manager')) {
            document.getElementById('studio-episode-manager').remove();
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'studio-episode-editor';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px; width: 90%;">
                <div class="modal-header">
                    <h2>${episode ? 'Bölümü Düzenle' : 'Yeni Bölüm Ekle'}</h2>
                    <button class="modal-close" onclick="document.getElementById('studio-episode-editor').remove(); StudioDashboard.showEpisodeManager('${series.id}')">×</button>
                </div>
                <div class="modal-body">
                    <form onsubmit="event.preventDefault(); StudioDashboard.saveEpisode('${series.id}')">
                        <div class="form-group">
                            <label>Bölüm Numarası</label>
                            <input type="number" id="studio-ep-num" class="form-input" value="${epNum}" required ${episode ? 'readonly' : ''}>
                        </div>
                        <div class="form-group">
                            <label>Bölüm Başlığı</label>
                            <input type="text" id="studio-ep-title" class="form-input" value="${epTitle}" placeholder="Örn: Final">
                        </div>

                        <!-- NEW: Access Control -->
                        <div class="form-group" style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; background: rgba(139, 92, 246, 0.05); padding:15px; border-radius:8px; border:1px solid rgba(139, 92, 246, 0.1);">
                            <div>
                                <label>Erişim Tipi</label>
                                <select id="studio-ep-lock" class="form-input" onchange="document.getElementById('coin-price-group').style.display = this.value === 'coin' ? 'block' : 'none'">
                                    <option value="free" ${!episode?.lockType || episode.lockType === 'free' ? 'selected' : ''}>Herkese Aç (Ücretsiz)</option>
                                    <option value="vip" ${episode?.lockType === 'vip' ? 'selected' : ''}>Sadece VIP</option>
                                    <option value="coin" ${episode?.lockType === 'coin' ? 'selected' : ''}>Coin ile Satın Al</option>
                                </select>
                            </div>
                            <div id="coin-price-group" style="display: ${episode?.lockType === 'coin' ? 'block' : 'none'};">
                                <label>Coin Fiyatı</label>
                                <input type="number" id="studio-ep-coin" class="form-input" value="${episode?.coinPrice || 10}" placeholder="Örn: 10">
                            </div>
                        </div>

                        <!-- Dynamic Sources Section -->
                        <div class="form-group" style="background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px;">
                            <label style="margin-bottom: 10px; display: block;">Video Kaynakları</label>
                            <div id="studio-sources-container">
                                ${existingSources.length > 0 ? existingSources.map((source, index) => `
                                    <div class="source-item" style="display: flex; gap: 10px; margin-bottom: 10px;">
                                        <input type="text" name="sourceName[]" class="form-input source-name" placeholder="Kaynak Adı (Örn: YouTube)" value="${source.platform || 'Custom'}" style="width: 30%;">
                                        <input type="text" name="sourceUrl[]" class="form-input source-url" placeholder="Kaynak URL" value="${source.url}" style="flex: 1;" required>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.source-item').remove()">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                `).join('') : `
                                    <div class="source-item" style="display: flex; gap: 10px; margin-bottom: 10px;">
                                        <input type="text" name="sourceName[]" class="form-input source-name" placeholder="Kaynak Adı (Örn: YouTube)" style="width: 30%;">
                                        <input type="text" name="sourceUrl[]" class="form-input source-url" placeholder="Kaynak URL" style="flex: 1;" required>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.source-item').remove()">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                `}
                            </div>
                            <button type="button" class="btn btn-sm btn-outline" onclick="StudioDashboard.addSourceField()">
                                <i class="fa-solid fa-plus"></i> Kaynak Ekle
                            </button>
                            <small style="color: #94a3b8; font-size: 11px; display: block; margin-top: 5px;">MP4, HLS (.m3u8), YouTube veya Embed kodu</small>
                        </div>

                        <div class="form-group">
                            <label>Alt Yazı Dosyası (.srt, .vtt) - <span style="font-size:11px; color:#cbd5e1;">(Opsiyonel)</span></label>
                            <input type="file" id="studio-ep-subtitle" class="form-input" accept=".srt,.vtt">
                            <small style="color: #94a3b8; font-size: 11px;">Eğer bir dosya seçerseniz, admin onayından sonra sisteme eklenecektir.</small>
                        </div>
                        
                        <!-- Detailed Progress Section -->
                        <div class="form-group" style="padding: 15px; background: rgba(59, 130, 246, 0.05); border: 1px solid rgba(59, 130, 246, 0.2); border-radius: 8px; margin: 15px 0;">
                            <label style="color: #60a5fa; font-weight: bold; display: flex; align-items: center; gap: 8px;">
                                <i class="fa-solid fa-spinner"></i> Bölüm Hazırlık İlerlemesi (%)
                            </label>
                            
                            <div class="progress-sliders" style="margin-top: 15px; display: grid; gap: 12px;">
                                <div class="slider-item">
                                    <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 5px;">
                                        <span>Çeviri</span>
                                        <b id="val-trans">${episode?.progress?.translation || 0}%</b>
                                    </div>
                                    <input type="range" id="progress-translation" class="form-range" min="0" max="100" value="${episode?.progress?.translation || 0}" oninput="document.getElementById('val-trans').innerText = this.value + '%'">
                                </div>
                                
                                <div class="slider-item">
                                    <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 5px;">
                                        <span>Kontrol / Redaksiyon</span>
                                        <b id="val-ctrl">${episode?.progress?.control || 0}%</b>
                                    </div>
                                    <input type="range" id="progress-control" class="form-range" min="0" max="100" value="${episode?.progress?.control || 0}" oninput="document.getElementById('val-ctrl').innerText = this.value + '%'">
                                </div>

                                <div class="slider-item">
                                    <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 5px;">
                                        <span>Zamanlama / Encoder</span>
                                        <b id="val-time">${episode?.progress?.timing || 0}%</b>
                                    </div>
                                    <input type="range" id="progress-timing" class="form-range" min="0" max="100" value="${episode?.progress?.timing || 0}" oninput="document.getElementById('val-time').innerText = this.value + '%'">
                                </div>
                            </div>
                        </div>

                        <div class="form-group" style="padding: 15px; background: rgba(139, 92, 246, 0.1); border-radius: 8px; margin: 15px 0;">
                            <label style="color: #a78bfa; font-weight: bold;">Dizi Yetişkinlik Düzeyi</label>
                            <select id="studio-series-maturity" class="form-select" style="background: rgba(0,0,0,0.3);">
                                <option value="G" ${currentMaturity === 'G' ? 'selected' : ''}>Genel İzleyici (G)</option>
                                <option value="13+" ${currentMaturity === '13+' ? 'selected' : ''}>13+ (13 Yaş ve Üzeri)</option>
                                <option value="16+" ${currentMaturity === '16+' ? 'selected' : ''}>16+ (16 Yaş ve Üzeri)</option>
                                <option value="18+" ${currentMaturity === '18+' ? 'selected' : ''}>18+ (Yetişkin)</option>
                            </select>
                            <small style="color: #cbd5e1; display: block; margin-top: 5px;">Bu ayar dizinin genel yaş sınırını günceller.</small>
                        </div>

                        <div class="form-actions" style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                            <button type="button" class="btn btn-outline" onclick="document.getElementById('studio-episode-editor').remove(); StudioDashboard.showEpisodeManager('${series.id}')">İptal</button>
                            <button type="submit" class="btn btn-primary">Kaydet</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    addSourceField() {
        const container = document.getElementById('studio-sources-container');
        const div = document.createElement('div');
        div.className = 'source-item';
        div.style.cssText = 'display: flex; gap: 10px; margin-bottom: 10px;';
        div.innerHTML = `
            <input type="text" name="sourceName[]" class="form-input source-name" placeholder="Kaynak Adı (Örn: Drive)" style="width: 30%;">
            <input type="text" name="sourceUrl[]" class="form-input source-url" placeholder="Kaynak URL" style="flex: 1;" required>
            <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.source-item').remove()">
                <i class="fa-solid fa-trash"></i>
            </button>
        `;
        container.appendChild(div);
    },

    getNextEpisodeNumber(series) {
        let max = 0;
        if (series.seasons) {
            series.seasons.forEach(s => {
                s.episodes?.forEach(e => {
                    if (e.number > max) max = e.number;
                });
            });
        }
        if (series.episodes) {
            series.episodes.forEach(e => {
                if (e.number > max) max = e.number;
            });
        }
        return max + 1;
    },

    async saveEpisode(seriesId) {
        if (window.Toast) Toast.info('Kaydediliyor...', 2000); else console.log('Kaydediliyor...');

        const epNum = document.getElementById('studio-ep-num').value;
        const epTitle = document.getElementById('studio-ep-title').value;
        const maturity = document.getElementById('studio-series-maturity').value;
        const subtitleFile = document.getElementById('studio-ep-subtitle').files[0];

        // Collect Progress
        const transProgress = parseInt(document.getElementById('progress-translation')?.value || 0);
        const ctrlProgress = parseInt(document.getElementById('progress-control')?.value || 0);
        const timeProgress = parseInt(document.getElementById('progress-timing')?.value || 0);

        // Collect Lock Data
        const lockType = document.getElementById('studio-ep-lock')?.value || 'free';
        const coinPrice = parseInt(document.getElementById('studio-ep-coin')?.value || 0);

        const isAdmin = this.currentUser.role === 'admin' || this.currentUser.badges?.includes('Yönetici');

        // Collect Source Data
        const sourceInputs = document.querySelectorAll('.source-url');
        const nameInputs = document.querySelectorAll('.source-name');

        const sourceUrls = Array.from(sourceInputs).map(input => input.value);
        const sourceNames = Array.from(nameInputs).map(input => input.value);

        const sources = [];
        sourceUrls.forEach((url, index) => {
            if (url && url.trim() !== '') {
                sources.push({
                    url: url,
                    quality: 'Auto',
                    platform: sourceNames[index] || 'Custom',
                    addedBy: State.currentUser.id,
                    addedAt: new Date().toISOString(),
                    isApproved: isAdmin // Non-admins wait for approval
                });
            }
        });

        if (!epNum || sources.length === 0) {
            if (window.Toast) Toast.warning('Lütfen bölüm numarası ve en az bir kaynak ekleyin');
            return;
        }

        const series = this.allSeries.find(s => s.id === seriesId);
        if (!series) return;

        // Helper to process saving based on role
        const processSave = async (subtitleData = null) => {
            // Logic: Update episode data object to include all sources
            // Since we are likely replacing the episode or adding new, we need to handle format expected by backend/admin

            // If we are passing direct data to saveEpisodeDirectly, let's ensure it handles array of sources or we adapt
            // But saveEpisodeDirectly (assumed in admin-content or locally) might expect a single source?
            // Let's modify the call to pass the first source as "primary" if legacy, or pass the full array if supported.
            // Actually, the previous implementation replaced "sourceData" (single object) with what we now have "sources" (array).
            // We'll pass the array but we need to check if saveEpisodeDirectly can handle it.
            // Since I can't see saveEpisodeDirectly implementation here, I will assume I need to pass the array.
            // If not, I might need to send sources separately. 
            // However, for Approval System, we submit 'sourceData'. It's usually one source.

            if (this.currentUser.role === 'admin' || this.currentUser.badges?.includes('Yönetici')) {
                // Admin: Direct Save
                await this.saveEpisodeDirectly(series, epNum, epTitle, sources, maturity, subtitleData, {
                    translation: transProgress,
                    control: ctrlProgress,
                    timing: timeProgress
                }, {
                    lockType,
                    coinPrice
                });
            } else {
                // Translator: Request Approval (Local-First)
                for (const source of sources) {
                    const sourceToSubmit = { ...source };
                    if (subtitleData) sourceToSubmit.subtitle = subtitleData;

                    if (window.SourceApprovalSystem) {
                        await SourceApprovalSystem.submitForApproval({
                            seriesId: series.id,
                            seriesTitle: series.title,
                            episodeNumber: epNum,
                            sourceObject: sourceToSubmit,
                            lockType,
                            coinPrice
                        });
                    }
                }

                document.getElementById('studio-episode-editor').remove();
                this.showEpisodeManager(seriesId);
                if (window.Toast) Toast.success('Kaynaklar onaya gönderildi');
            }
        };

        // Handle Subtitle File
        if (subtitleFile) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const content = e.target.result;
                const subtitleData = {
                    name: subtitleFile.name,
                    content: content,
                    type: subtitleFile.name.endsWith('.vtt') ? 'vtt' : 'srt'
                };
                processSave(subtitleData);
            };
            reader.onerror = () => {
                Toast.error('Alt yazı dosyası okunamadı');
            };
            // Read as text to send content via JSON
            reader.readAsText(subtitleFile);
        } else {
            processSave();
        }
    },



    async saveEpisodeDirectly(series, epNum, epTitle, sources, maturity, subtitleData, progress = null, lockData = null) {
        // Updated to support multiple sources
        const episodeData = {
            id: 'ep-' + Date.now(),
            number: parseInt(epNum),
            title: epTitle,
            sources: Array.isArray(sources) ? sources : [sources],
            progress: progress,
            releaseDate: new Date().toISOString()
        };

        if (lockData) Object.assign(episodeData, lockData);

        if (subtitleData && episodeData.sources.length > 0) {
            episodeData.sources[0].subtitle = subtitleData;
        }

        // Local-First Update
        const targetSeries = State.data.series.find(s => s.id === series.id);
        if (targetSeries) {
            targetSeries.ageRating = maturity;
            if (!targetSeries.episodes) targetSeries.episodes = [];
            
            const existingIdx = targetSeries.episodes.findIndex(e => e.number == epNum);
            if (existingIdx > -1) {
                targetSeries.episodes[existingIdx] = { ...targetSeries.episodes[existingIdx], ...episodeData };
            } else {
                targetSeries.episodes.push(episodeData);
            }
            
            await db.save();
            Toast.success('Bölüm başarıyla kaydedildi!');
            
            document.getElementById('studio-episode-editor').remove();
            await this.loadContent();
            this.showEpisodeManager(series.id);
        } else {
            Toast.error('Dizi bulunamadı.');
        }
    },

    showSeriesManagement() {
        if (window.AdminPanelHub) {
            AdminPanelHub.switchTab('series');
        } else {
            Toast.error('Admin paneli modülü bulunamadı.');
        }
    },

    showWebtoonManagement() {
        if (window.AdminPanelHub) {
            AdminPanelHub.switchTab('webtoons');
        } else {
            Toast.error('Admin paneli modülü bulunamadı.');
        }
    },

    openWebtoonStudio(webtoonId) {
        // TODO: Navigate to webtoon studio/reader
        Toast.info('Webtoon stüdyosu yakında...');
    },

    addWebtoonEpisode(webtoonId) {
        WebtoonUploadModal.show(webtoonId);
    },

    getFirstEpisode(series) {
        if (series.seasons && series.seasons[0] && series.seasons[0].episodes) {
            return series.seasons[0].episodes[0];
        }
        if (series.episodes && series.episodes[0]) {
            return series.episodes[0];
        }
        return null;
    },

    quickEdit(seriesId) {
        QuickEditModal.show(seriesId);
    },

    showApprovals() {
        ApprovalManager.show();
    },


    showAssignmentManager() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 1200px; max-height: 90vh;">
                <div class="modal-header">
                    <h2><i class="fa-solid fa-user-group"></i> Atama Yönetimi</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body" style="overflow-y: auto;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
                        <!-- Left: Translators -->
                        <div>
                            <h3 style="margin-bottom: 16px;">
                                <i class="fa-solid fa-users"></i> Çevirmenler
                            </h3>
                            <div id="translator-list" style="display: grid; gap: 12px;">
                                ${this.renderTranslatorList()}
                            </div>
                        </div>
                        
                        <!-- Right: Content -->
                        <div>
                            <h3 style="margin-bottom: 16px;">
                                <i class="fa-solid fa-film"></i> İçerik
                            </h3>
                            
                            <div style="margin-bottom: 16px;">
                                <select id="content-type-filter" class="form-select" onchange="StudioDashboard.filterAssignmentContent(this.value)">
                                    <option value="all">Tümü</option>
                                    <option value="series">Diziler</option>
                                    <option value="webtoon">Webtoonlar</option>
                                </select>
                            </div>
                            
                            <div id="content-list" style="display: grid; gap: 12px; max-height: 500px; overflow-y: auto;">
                                ${this.renderContentList()}
                            </div>
                        </div>
                    </div>
                    
                    <div style="margin-top: 24px; padding-top: 24px; border-top: 2px solid rgba(139, 92, 246, 0.2);">
                        <h3 style="margin-bottom: 16px;">
                            <i class="fa-solid fa-link"></i> Toplu İşlemler
                        </h3>
                        <div style="display: flex; gap: 12px; align-items: center;">
                            <select id="bulk-translator" class="form-select" style="flex: 1;">
                                <option value="">Çevirmen Seç</option>
                                ${this.renderTranslatorOptions()}
                            </select>
                            <button class="btn btn-primary" onclick="StudioDashboard.bulkAssign()">
                                <i class="fa-solid fa-check-double"></i> Seçililere Ata
                            </button>
                            <button class="btn btn-outline" onclick="StudioDashboard.clearSelection()">
                                <i class="fa-solid fa-times"></i> Seçimi Temizle
                            </button>
                        </div>
                        <p style="color: #94a3b8; font-size: 12px; margin-top: 8px;">
                            İçerik kartlarına tıklayarak seçim yapın, ardından toplu atama yapabilirsiniz.
                        </p>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Initialize selection tracking
        this.selectedContent = [];
    },

    renderTranslatorList() {
        const users = State.data?.users || [];
        const translators = users.filter(u =>
            u.role === 'translator' ||
            u.role === 'webtoon-translator' ||
            u.badges?.includes('Çevirmen')
        );

        if (translators.length === 0) {
            return '<p style="color: #64748b; text-align: center; padding: 40px;">Henüz çevirmen yok</p>';
        }

        return translators.map(translator => `
            <div class="translator-card" style="
                background: rgba(30, 41, 59, 0.5);
                border: 1px solid rgba(139, 92, 246, 0.2);
                border-radius: 8px;
                padding: 16px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            ">
                <div>
                    <h4 style="margin: 0 0 4px 0;">
                        <i class="fa-solid fa-user"></i> ${translator.username}
                    </h4>
                    <p style="margin: 0; color: #94a3b8; font-size: 12px;">
                        ${translator.role === 'webtoon-translator' ? 'Webtoon Çevirmen' : 'Çevirmen'}
                    </p>
                </div>
                <button class="btn btn-sm btn-outline" onclick="StudioDashboard.viewTranslatorAssignments('${translator.id}')">
                    <i class="fa-solid fa-list"></i> Atamaları Gör
                </button>
            </div>
        `).join('');
    },

    renderContentList(filter = 'all') {
        const series = State.data?.series || [];
        const webtoons = State.data?.webtoons || [];

        let content = [];

        if (filter === 'all' || filter === 'series') {
            content = content.concat(series.map(s => ({ ...s, type: 'series' })));
        }

        if (filter === 'all' || filter === 'webtoon') {
            content = content.concat(webtoons.map(w => ({ ...w, type: 'webtoon' })));
        }

        if (content.length === 0) {
            return '<p style="color: #64748b; text-align: center; padding: 40px;">İçerik bulunamadı</p>';
        }

        return content.map(item => {
            const assignedTo = item.assignedTranslators || [];
            const isSelected = this.selectedContent?.includes(item.id) || false;

            return `
                <div class="content-card ${isSelected ? 'selected' : ''}" 
                     data-content-id="${item.id}"
                     onclick="StudioDashboard.toggleContentSelection('${item.id}')"
                     style="
                        background: ${isSelected ? 'rgba(139, 92, 246, 0.2)' : 'rgba(30, 41, 59, 0.5)'};
                        border: 2px solid ${isSelected ? '#8b5cf6' : 'rgba(139, 92, 246, 0.2)'};
                        border-radius: 8px;
                        padding: 16px;
                        cursor: pointer;
                        transition: all 0.3s;
                    ">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                        <div style="flex: 1;">
                            <h4 style="margin: 0 0 4px 0;">
                                ${item.type === 'series' ? '🎬' : '📚'} ${item.title || item.name}
                            </h4>
                            <p style="margin: 0; color: #94a3b8; font-size: 12px;">
                                ${item.type === 'series' ? 'Dizi' : 'Webtoon'}
                                ${assignedTo.length > 0 ? ` • ${assignedTo.length} çevirmen atandı` : ' • Atama yok'}
                            </p>
                        </div>
                        ${isSelected ? '<i class="fa-solid fa-check-circle" style="color: #8b5cf6; font-size: 20px;"></i>' : ''}
                    </div>
                    ${assignedTo.length > 0 ? `
                        <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(139, 92, 246, 0.2);">
                            <div style="display: flex; flex-wrap: wrap; gap: 6px;">
                                ${assignedTo.map(translatorId => {
                const translator = State.data?.users?.find(u => u.id === translatorId);
                return translator ? `
                                        <span style="
                                            background: rgba(139, 92, 246, 0.2);
                                            color: #8b5cf6;
                                            padding: 4px 8px;
                                            border-radius: 12px;
                                            font-size: 11px;
                                            display: inline-flex;
                                            align-items: center;
                                            gap: 4px;
                                        ">
                                            <i class="fa-solid fa-user"></i> ${translator.username}
                                            <i class="fa-solid fa-times" onclick="event.stopPropagation(); StudioDashboard.removeAssignment('${item.id}', '${translatorId}')" style="cursor: pointer;"></i>
                                        </span>
                                    ` : '';
            }).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            `;
        }).join('');
    },

    renderTranslatorOptions() {
        const users = State.data?.users || [];
        const translators = users.filter(u =>
            u.role === 'translator' ||
            u.role === 'webtoon-translator' ||
            u.badges?.includes('Çevirmen')
        );

        return translators.map(t => `
            <option value="${t.id}">${t.username}</option>
        `).join('');
    },

    filterAssignmentContent(type) {
        const contentList = document.getElementById('content-list');
        if (contentList) {
            contentList.innerHTML = this.renderContentList(type);
        }
    },

    toggleContentSelection(contentId) {
        if (!this.selectedContent) this.selectedContent = [];

        const index = this.selectedContent.indexOf(contentId);
        if (index > -1) {
            this.selectedContent.splice(index, 1);
        } else {
            this.selectedContent.push(contentId);
        }

        // Refresh content list
        const filter = document.getElementById('content-type-filter')?.value || 'all';
        this.filterAssignmentContent(filter);
    },

    clearSelection() {
        this.selectedContent = [];
        const filter = document.getElementById('content-type-filter')?.value || 'all';
        this.filterAssignmentContent(filter);
        Toast.info('Seçim temizlendi');
    },

    bulkAssign() {
        const translatorId = document.getElementById('bulk-translator')?.value;

        if (!translatorId) {
            Toast.warning('Lütfen bir çevirmen seçin');
            return;
        }

        if (!this.selectedContent || this.selectedContent.length === 0) {
            Toast.warning('Lütfen atama yapılacak içerikleri seçin');
            return;
        }

        const translator = State.data?.users?.find(u => u.id === translatorId);
        if (!translator) {
            Toast.error('Çevirmen bulunamadı');
            return;
        }

        // Assign to all selected content
        this.selectedContent.forEach(contentId => {
            this.assignTranslator(contentId, translatorId);
        });

        Toast.success(`${this.selectedContent.length} içerik ${translator.username} kullanıcısına atandı`);

        // Clear selection and refresh
        this.selectedContent = [];
        const filter = document.getElementById('content-type-filter')?.value || 'all';
        this.filterAssignmentContent(filter);
    },

    assignTranslator(contentId, translatorId) {
        // Find content in series or webtoons
        let content = State.data?.series?.find(s => s.id === contentId);
        let type = 'series';

        if (!content) {
            content = State.data?.webtoons?.find(w => w.id === contentId);
            type = 'webtoon';
        }

        if (!content) return;

        // Initialize assignedTranslators if not exists
        if (!content.assignedTranslators) {
            content.assignedTranslators = [];
        }

        // Add translator if not already assigned
        if (!content.assignedTranslators.includes(translatorId)) {
            content.assignedTranslators.push(translatorId);

            // Save to backend
            if (window.db && window.db.save) {
                window.db.save();
            }
        }
    },

    removeAssignment(contentId, translatorId) {
        // Find content
        let content = State.data?.series?.find(s => s.id === contentId);

        if (!content) {
            content = State.data?.webtoons?.find(w => w.id === contentId);
        }

        if (!content || !content.assignedTranslators) return;

        // Remove translator
        content.assignedTranslators = content.assignedTranslators.filter(id => id !== translatorId);

        // Save
        if (window.db && window.db.save) {
            window.db.save();
        }

        Toast.success('Atama kaldırıldı');

        // Refresh
        const filter = document.getElementById('content-type-filter')?.value || 'all';
        this.filterAssignmentContent(filter);
    },

    viewTranslatorAssignments(translatorId) {
        const translator = State.data?.users?.find(u => u.id === translatorId);
        if (!translator) return;

        const series = State.data?.series?.filter(s => s.assignedTranslators?.includes(translatorId)) || [];
        const webtoons = State.data?.webtoons?.filter(w => w.assignedTranslators?.includes(translatorId)) || [];

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2><i class="fa-solid fa-list"></i> ${translator.username} - Atamalar</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <h3>Diziler (${series.length})</h3>
                    ${series.length > 0 ? `
                        <ul style="list-style: none; padding: 0;">
                            ${series.map(s => `<li style="padding: 8px 0;">🎬 ${s.title}</li>`).join('')}
                        </ul>
                    ` : '<p style="color: #64748b;">Atanmış dizi yok</p>'}
                    
                    <h3 style="margin-top: 20px;">Webtoonlar (${webtoons.length})</h3>
                    ${webtoons.length > 0 ? `
                        <ul style="list-style: none; padding: 0;">
                            ${webtoons.map(w => `<li style="padding: 8px 0;">📚 ${w.name}</li>`).join('')}
                        </ul>
                    ` : '<p style="color: #64748b;">Atanmış webtoon yok</p>'}
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },


    // Content Management Methods
    showAddSeriesForm() {
        if (window.AdminContent) {
            AdminContent.showAddSeriesModal();
        } else {
            Toast.error('İçerik modülü yüklenemedi');
        }
    },

    showSeriesManagement() {
        if (window.AdminContent) {
            AdminContent.showSeriesManagement();
        } else {
            Toast.error('İçerik modülü yüklenemedi');
        }
    },

    showAddWebtoonForm() {
        if (window.AdminContent) {
            AdminContent.showAddWebtoonModal();
        } else {
            Toast.error('İçerik modülü yüklenemedi');
        }
    },

    showWebtoonManagement() {
        if (window.AdminContent) {
            AdminContent.showWebtoonManagement();
        } else {
            Toast.error('İçerik modülü yüklenemedi');
        }
    },

    // ============================================
    // SHORTS MANAGEMENT 
    // ============================================

    renderShortsGrid() {
        return this.allShorts.map(short => {
            const totalEps = short.totalEpisodes || short.episodes?.length || 0;
            const freeEps = short.freeEpisodes || 0;

            return `
                <div class="series-card" data-short-id="${short.id}">
                    <img src="${short.poster || '/assets/placeholder.jpg'}" 
                         alt="${short.title}" 
                         class="series-card-poster"
                         onerror="this.src='/assets/placeholder.jpg'">
                    <div class="series-card-content">
                        <h3 class="series-card-title">${short.title}</h3>
                        <div class="series-card-meta">
                            <span><i class="fa-solid fa-video"></i> ${totalEps} Bölüm</span>
                            <span><i class="fa-solid fa-gift"></i> ${freeEps} Ücretsiz</span>
                        </div>
                        <div class="series-card-meta" style="margin-top: 6px;">
                            <span><i class="fa-solid fa-coins"></i> ${short.defaultCoinPrice || 0} Coin</span>
                            ${short.vipOnly ? '<span style="color: #f59e0b;"><i class="fa-solid fa-crown"></i> VIP</span>' : ''}
                        </div>
                        <div class="series-card-actions" style="margin-top: 12px;">
                            <button class="btn-studio" onclick="StudioDashboard.showShortEpisodeManager('${short.id}')">
                                <i class="fa-solid fa-list-check"></i> Bölümler
                            </button>
                             <button class="btn-edit" onclick="StudioDashboard.editShort('${short.id}')">
                                <i class="fa-solid fa-edit"></i> Düzenle
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    },

    showAddShortForm() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'add-short-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px; width: 90%;">
                <div class="modal-header" style="background: linear-gradient(135deg, #7c3aed, #a78bfa);">
                    <h2><i class="fa-solid fa-plus"></i> Yeni Kısa Drama Ekle</h2>
                    <button class="modal-close" onclick="document.getElementById('add-short-modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <form onsubmit="event.preventDefault(); StudioDashboard.saveNewShort()">
                        <div class="form-group">
                            <label>Başlık *</label>
                            <input type="text" id="short-title" class="form-input" required placeholder="Kısa drama adı">
                        </div>
                        <div class="form-group">
                            <label>Açıklama</label>
                            <textarea id="short-description" class="form-input" rows="3" placeholder="Kısa drama açıklaması"></textarea>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                            <div class="form-group">
                                <label>Poster URL</label>
                                <input type="url" id="short-poster" class="form-input" placeholder="https://...">
                            </div>
                            <div class="form-group">
                                <label>Çevirmen</label>
                                <input type="text" id="short-translator" class="form-input" placeholder="Çevirmen adı">
                            </div>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
                            <div class="form-group">
                                <label>Ücretsiz Bölüm</label>
                                <input type="number" id="short-free-eps" class="form-input" value="5" min="0">
                            </div>
                            <div class="form-group">
                                <label>Coin Fiyatı</label>
                                <input type="number" id="short-coin-price" class="form-input" value="30" min="0">
                            </div>
                            <div class="form-group">
                                <label>VIP Only</label>
                                <select id="short-vip-only" class="form-input">
                                    <option value="false">Hayır</option>
                                    <option value="true">Evet</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-actions" style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                            <button type="button" class="btn btn-outline" onclick="document.getElementById('add-short-modal').remove()">İptal</button>
                            <button type="submit" class="btn btn-primary">Kaydet</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async saveNewShort() {
        const shortData = {
            id: 'short-' + Date.now(),
            title: document.getElementById('short-title').value,
            description: document.getElementById('short-description').value,
            poster: document.getElementById('short-poster').value,
            translator: document.getElementById('short-translator').value,
            freeEpisodes: parseInt(document.getElementById('short-free-eps').value) || 5,
            defaultCoinPrice: parseInt(document.getElementById('short-coin-price').value) || 30,
            vipOnly: document.getElementById('short-vip-only').value === 'true',
            episodes: [],
            totalEpisodes: 0,
            createdAt: new Date().toISOString()
        };

        try {
            const response = await fetch('/api/shorts.php?action=create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(shortData)
            });
            const result = await response.json();

            if (result.success) {
                Toast.success('Kısa drama oluşturuldu!');
                document.getElementById('add-short-modal').remove();
                this.allShorts.push(shortData);
                this.render();
            } else {
                Toast.error(result.message || 'Bir hata oluştu');
            }
        } catch (error) {
            console.error('Short oluşturma hatası:', error);
            Toast.error('Sunucu hatası');
        }
    },

    showShortEpisodeManager(shortId) {
        const short = this.allShorts.find(s => s.id === shortId);
        if (!short) return;

        const episodes = short.episodes || [];

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'short-episode-manager';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 700px; width: 90%; max-height: 80vh; overflow-y: auto;">
                <div class="modal-header">
                    <h2>${short.title} - Bölüm Yönetimi</h2>
                    <button class="modal-close" onclick="document.getElementById('short-episode-manager').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #94a3b8;">Toplam ${episodes.length} bölüm</span>
                        <button class="btn btn-success" onclick="StudioDashboard.showAddShortEpisodeForm('${shortId}')">
                            <i class="fa-solid fa-plus"></i> Yeni Bölüm Ekle
                        </button>
                    </div>

                    <div class="episode-list" style="display: flex; flex-direction: column; gap: 10px;">
                        ${episodes.length > 0 ? episodes.map(ep => `
                            <div style="background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <div style="font-weight: bold; color: #e2e8f0;">${ep.number}. Bölüm: ${ep.title || 'Başlıksız'}</div>
                                    <div style="font-size: 12px; color: #94a3b8; margin-top: 4px;">
                                        ${ep.number <= short.freeEpisodes ? '<span style="color:#10b981">Ücretsiz</span>' : '<span style="color:#f59e0b">' + (ep.coinPrice || short.defaultCoinPrice) + ' Coin</span>'}
                                        ${ep.videoUrl ? ' • <span style="color:#10b981">Video Var</span>' : ' • <span style="color:#ef4444">Video Yok</span>'}
                                    </div>
                                </div>
                                <button class="btn btn-sm btn-primary" onclick="StudioDashboard.editShortEpisode('${shortId}', ${ep.number})">
                                    <i class="fa-solid fa-pen-to-square"></i> Düzenle
                                </button>
                            </div>
                        `).join('') : '<p style="text-align: center; color: #94a3b8;">Henüz bölüm bulunmuyor.</p>'}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    showAddShortEpisodeForm(shortId) {
        const short = this.allShorts.find(s => s.id === shortId);
        if (!short) return;

        const nextEpNum = (short.episodes?.length || 0) + 1;

        // Remove existing modal
        if (document.getElementById('short-episode-manager')) {
            document.getElementById('short-episode-manager').remove();
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'add-short-episode-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px; width: 90%;">
                <div class="modal-header">
                    <h2>Yeni Bölüm Ekle</h2>
                    <button class="modal-close" onclick="document.getElementById('add-short-episode-modal').remove(); StudioDashboard.showShortEpisodeManager('${shortId}')">×</button>
                </div>
                <div class="modal-body">
                    <form onsubmit="event.preventDefault(); StudioDashboard.saveShortEpisode('${shortId}')">
                        <div class="form-group">
                            <label>Bölüm Numarası</label>
                            <input type="number" id="short-ep-num" class="form-input" value="${nextEpNum}" required>
                        </div>
                        <div class="form-group">
                            <label>Bölüm Başlığı</label>
                            <input type="text" id="short-ep-title" class="form-input" placeholder="Opsiyonel">
                        </div>
                        
                        <!-- Video Sources Section -->
                        <div class="form-group">
                            <label style="display: flex; justify-content: space-between; align-items: center;">
                                <span>Video Kaynakları</span>
                                <button type="button" class="btn btn-sm btn-outline" onclick="StudioDashboard.addSourceField()">
                                    <i class="fa-solid fa-plus"></i> Kaynak Ekle
                                </button>
                            </label>
                            <div id="sources-container">
                                <div class="source-item" style="display: flex; gap: 10px; margin-bottom: 10px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 8px;">
                                    <select class="form-input source-type" style="width: 120px;">
                                        <option value="mp4">MP4</option>
                                        <option value="hls">HLS (m3u8)</option>
                                        <option value="youtube">YouTube</option>
                                        <option value="embed">Embed</option>
                                    </select>
                                    <input type="text" class="form-input source-url" placeholder="Video URL" style="flex: 1;">
                                    <input type="text" class="form-input source-quality" placeholder="Kalite (720p)" style="width: 100px;">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Coin Fiyatı (boş bırakılırsa varsayılan: ${short.defaultCoinPrice})</label>
                            <input type="number" id="short-ep-coin" class="form-input" placeholder="${short.defaultCoinPrice}">
                        </div>
                        
                        <div class="form-group">
                            <label class="checkbox-label" style="display: flex; align-items: center; gap: 10px;">
                                <input type="checkbox" id="short-ep-free">
                                <span>Bu bölüm ücretsiz olsun</span>
                            </label>
                        </div>
                        
                        <div class="form-actions" style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                            <button type="button" class="btn btn-outline" onclick="document.getElementById('add-short-episode-modal').remove(); StudioDashboard.showShortEpisodeManager('${shortId}')">İptal</button>
                            <button type="submit" class="btn btn-primary">Kaydet</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    addSourceField() {
        const container = document.getElementById('sources-container');
        const sourceItem = document.createElement('div');
        sourceItem.className = 'source-item';
        sourceItem.style.cssText = 'display: flex; gap: 10px; margin-bottom: 10px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 8px;';
        sourceItem.innerHTML = `
            <select class="form-input source-type" style="width: 120px;">
                <option value="mp4">MP4</option>
                <option value="hls">HLS (m3u8)</option>
                <option value="youtube">YouTube</option>
                <option value="embed">Embed</option>
            </select>
            <input type="text" class="form-input source-url" placeholder="Video URL" style="flex: 1;">
            <input type="text" class="form-input source-quality" placeholder="Kalite (720p)" style="width: 100px;">
            <button type="button" class="btn btn-sm btn-danger" onclick="this.parentElement.remove()">
                <i class="fa-solid fa-trash"></i>
            </button>
        `;
        container.appendChild(sourceItem);
    },

    async saveShortEpisode(shortId) {
        const short = this.allShorts.find(s => s.id === shortId);
        if (!short) return;

        // Collect sources from form
        const sources = [];
        document.querySelectorAll('#sources-container .source-item').forEach(item => {
            const type = item.querySelector('.source-type').value;
            const url = item.querySelector('.source-url').value.trim();
            const quality = item.querySelector('.source-quality').value.trim() || '720p';
            if (url) {
                sources.push({ type, url, quality });
            }
        });

        if (sources.length === 0) {
            Toast.warning('En az bir video kaynağı ekleyin!');
            return;
        }

        const epData = {
            number: parseInt(document.getElementById('short-ep-num').value),
            title: document.getElementById('short-ep-title').value || '',
            sources: sources,
            videoUrl: sources[0]?.url || '', // Keep for backward compatibility
            coinPrice: parseInt(document.getElementById('short-ep-coin').value) || short.defaultCoinPrice,
            isFree: document.getElementById('short-ep-free').checked
        };

        const isAdmin = State.currentUser.role === 'admin' || State.currentUser.badges?.includes('Yönetici');

        if (isAdmin) {
            // Add to local array
            if (!short.episodes) short.episodes = [];
            short.episodes.push(epData);
            short.totalEpisodes = short.episodes.length;

            try {
                // EXISTING ADMIN SAVE LOGIC
                // We'll just call the existing logic or reconstruct it.
                // The logical block below handles the save.
                // Since I am inside saveShortEpisode, I can just proceed.
                // BUT I need to skip this block if not admin.
            } catch (e) { }
        } else {
            // Submit for approval
            try {
                await fetch('api/db.php?action=admin-submit-approval', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        type: 'short',
                        data: {
                            shortId: short.id,
                            episode: epData
                        },
                        userId: State.currentUser.id,
                        username: State.currentUser.username
                    })
                });
                Toast.success('Bölüm onaya gönderildi');
                document.getElementById('add-short-modal')?.remove(); // Close modal if open (varies by context, checking ID)
                // Actually ID is add-short-episode-modal
                document.getElementById('add-short-episode-modal').remove();
                return;
            } catch (e) {
                Toast.error('Gönderilemedi');
                return;
            }
        }

        // Add to local array (ADMIN ONLY CONTINUATION)
        if (!short.episodes) short.episodes = [];
        short.episodes.push(epData);
        short.totalEpisodes = short.episodes.length;

        // Save to API
        try {
            const response = await fetch('/api/shorts.php?action=update&id=' + shortId, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(short)
            });
            const result = await response.json();

            if (result.success) {
                Toast.success('Bölüm eklendi!');
                document.getElementById('add-short-episode-modal').remove();
                this.showShortEpisodeManager(shortId);
            } else {
                Toast.error('Hata: ' + (result.message || 'Bilinmeyen hata'));
            }
        } catch (error) {
            console.error('Episode kaydetme hatası:', error);
            Toast.error('Sunucu hatası');
        }
    },

    editShort(shortId) {
        Toast.info('Kısa drama düzenleme yakında eklenecek');
    },

    editShortEpisode(shortId, epNumber) {
        Toast.info('Bölüm düzenleme yakında eklenecek');
    },

    renderStats() {
        if (!this.creatorStats) return '<p style="padding: 40px; text-align: center;">İstatistikler yükleniyor...</p>';
        const stats = this.creatorStats;
        const userEarnings = this.currentUser.stats?.earnings || 0;

        // Schedule chart init
        setTimeout(() => this.initStatsChart(), 100);

        return `
            <div class="stats-container-premium">
                <!-- Summary Cards -->
                <div class="stats-summary">
                    <div class="stat-card-modern">
                        <div class="stat-icon" style="background: rgba(255, 215, 0, 0.1); color: #ffd700;">
                            <i class="fa-solid fa-mug-hot"></i>
                        </div>
                        <div class="stat-info">
                            <span class="stat-label">Toplam Kazanç</span>
                            <span class="stat-value">${userEarnings} Coin</span>
                        </div>
                    </div>
                    <div class="stat-card-modern">
                        <div class="stat-icon" style="background: rgba(139, 92, 246, 0.1); color: #8b5cf6;">
                            <i class="fa-solid fa-eye"></i>
                        </div>
                        <div class="stat-info">
                            <span class="stat-label">Toplam İzlenme</span>
                            <span class="stat-value">${stats.totalViews}</span>
                        </div>
                    </div>
                    <div class="stat-card-modern" style="border-right: none;">
                        <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1); color: #10b981;">
                            <i class="fa-solid fa-thumbs-up"></i>
                        </div>
                        <div class="stat-info">
                            <span class="stat-label">Toplam Beğeni</span>
                            <span class="stat-value">${stats.totalLikes}</span>
                        </div>
                    </div>
                </div>

                <div class="stats-main-row">
                    <!-- Chart Section -->
                    <div class="stats-chart-section glass-panel">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                            <h3 style="margin: 0;">İçerik Performansı</h3>
                            <button class="btn btn-sm btn-outline" onclick="StudioDashboard.showGoalEditor()">
                                <i class="fa-solid fa-bullseye"></i> Hedef Belirle
                            </button>
                        </div>
                        
                        <!-- Goal Bar (if exists) -->
                        ${this.currentUser.stats?.goal ? `
                            <div class="creator-goal-dashboard" style="margin-bottom: 25px; background: rgba(0,0,0,0.2); padding: 15px; border-radius: 12px; border: 1px dashed rgba(255,215,0,0.3);">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 13px;">
                                    <span><strong>Hedef:</strong> ${this.currentUser.stats.goal.title}</span>
                                    <span>${this.currentUser.stats.goal.current} / ${this.currentUser.stats.goal.target} Coin</span>
                                </div>
                                <div class="goal-progress-bg" style="height: 10px; background: rgba(255,255,255,0.1); border-radius: 5px; overflow: hidden;">
                                    <div class="goal-progress-fill" style="width: ${Math.min(100, (this.currentUser.stats.goal.current / this.currentUser.stats.goal.target) * 100)}%; height: 100%; background: linear-gradient(90deg, #ffd700, #ff8c00); box-shadow: 0 0 10px rgba(255,215,0,0.5);"></div>
                                </div>
                            </div>
                        ` : ''}

                        <div style="height: 300px; position: relative;">
                            <canvas id="creator-engagement-chart"></canvas>
                        </div>
                    </div>

                    <!-- Recent Donations -->
                    <div class="stats-donations-section glass-panel">
                        <h3 style="margin-bottom: 15px;">Son Kahveler (Bağışlar)</h3>
                        <div class="donations-list">
                            ${(this.currentUser.donationsReceived || []).length > 0 ?
                this.currentUser.donationsReceived.slice(-5).reverse().map(don => `
                                    <div class="donation-item-dashboard">
                                        <div class="don-user-info">
                                            <strong>${don.fromName}</strong>
                                            <span style="font-size: 11px; opacity: 0.6;">${new Date(don.date).toLocaleDateString('tr-TR')}</span>
                                        </div>
                                        <div class="don-amount">
                                            <i class="fa-solid fa-mug-hot" style="color: #ffd700;"></i> +${don.amount}
                                        </div>
                                        ${don.note ? `<div class="don-note">"${don.note}"</div>` : ''}
                                    </div>
                                `).join('') :
                '<p style="color: #64748b; font-size: 14px;">Henüz kahve ısmarlayan olmadı. İçerik üretmeye devam et!</p>'
            }
                        </div>
                    </div>
                </div>

                <div class="stats-items-table glass-panel">
                    <h3>Atanan İçerik Detayları</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Başlık</th>
                                <th>Tür</th>
                                <th>İzlenme</th>
                                <th>Beğeni</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${stats.items.map(item => `
                                <tr>
                                    <td>${item.title}</td>
                                    <td><span class="type-tag ${item.type}">${item.type}</span></td>
                                    <td>${item.views}</td>
                                    <td>${item.likes}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>

            <style>
                .stats-container-premium { padding: 10px; }
                .stats-summary {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 20px;
                    margin-bottom: 30px;
                }
                .stat-card-modern {
                    background: rgba(30, 41, 59, 0.5);
                    border: 1px solid rgba(139, 92, 246, 0.2);
                    border-radius: 16px;
                    padding: 24px;
                    display: flex;
                    align-items: center;
                    gap: 20px;
                }
                .stat-icon {
                    width: 56px;
                    height: 56px;
                    border-radius: 14px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 1.6rem;
                }
                .stat-label {
                    display: block;
                    font-size: 13px;
                    color: #94a3b8;
                    font-weight: 500;
                    margin-bottom: 6px;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                }
                .stat-value {
                    display: block;
                    font-size: 1.5rem;
                    font-weight: 800;
                    color: #fff;
                }
                .stats-main-row {
                    display: grid;
                    grid-template-columns: 2fr 1fr;
                    gap: 24px;
                    margin-bottom: 24px;
                }
                .stats-chart-section, .stats-donations-section, .stats-items-table {
                    background: rgba(30, 41, 59, 0.4);
                    border-radius: 20px;
                    padding: 24px;
                    border: 1px solid rgba(255, 255, 255, 0.05);
                }
                .stats-items-table table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                .stats-items-table th {
                    text-align: left;
                    padding: 12px 16px;
                    color: #94a3b8;
                    font-weight: 600;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }
                .stats-items-table td {
                    padding: 16px;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
                }
                .type-tag {
                    padding: 4px 10px;
                    border-radius: 6px;
                    font-size: 11px;
                    font-weight: 700;
                    text-transform: uppercase;
                }
                .type-tag.blog { background: rgba(59, 130, 246, 0.2); color: #3b82f6; }
                .type-tag.drama { background: rgba(139, 92, 246, 0.2); color: #8b5cf6; }
                .type-tag.webtoon { background: rgba(16, 185, 129, 0.2); color: #10b981; }

                .donation-item-dashboard {
                    padding: 15px;
                    background: rgba(255, 255, 255, 0.03);
                    border-radius: 12px;
                    margin-bottom: 12px;
                    border: 1px solid rgba(255, 255, 255, 0.05);
                }
                .don-amount {
                    font-size: 1.1rem;
                    font-weight: 800;
                    margin: 8px 0;
                }
                .don-note {
                    font-size: 12px;
                    color: #94a3b8;
                    background: rgba(0, 0, 0, 0.2);
                    padding: 8px;
                    border-radius: 6px;
                }

                @media (max-width: 1000px) {
                    .stats-main-row { grid-template-columns: 1fr; }
                    .stats-summary { grid-template-columns: 1fr; }
                }
            </style>
        `;
    },

    initStatsChart() {
        const canvas = document.getElementById('creator-engagement-chart');
        if (!canvas || !this.creatorStats) return;

        // Clear existing chart if any
        if (this.perfChart) this.perfChart.destroy();

        const ctx = canvas.getContext('2d');
        this.perfChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: this.creatorStats.items.map(i => i.title.length > 20 ? i.title.substring(0, 18) + '...' : i.title),
                datasets: [{
                    label: 'İzlenme',
                    data: this.creatorStats.items.map(i => i.views),
                    backgroundColor: 'rgba(139, 92, 246, 0.6)',
                    borderColor: '#8b5cf6',
                    borderWidth: 2,
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255,255,255,0.05)', drawBorder: false },
                        ticks: { color: '#94a3b8' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#94a3b8' }
                    }
                }
            }
        });
    },

    getRankIcon(rank) {
        const icons = {
            'Stajyer Çevirmen': '🌱',
            'Kadrolu Çevirmen': '📜',
            'Uzman Çevirmen': '🛡️',
            'Efsanevi Çevirmen': '👑'
        };
        return icons[rank] || '🖋️';
    },

    getNextLevelXP(level) {
        return 50 * Math.pow(level, 2);
    },

    calculateXPProgress() {
        if (!this.currentUser) return 0;
        const stats = this.currentUser.creatorStats || { xp: 0, level: 1 };
        const currentXP = stats.xp || 0;
        const currentLevel = stats.level || 1;
        const currentLevelXP = 50 * Math.pow(currentLevel - 1, 2);
        const nextLevelXP = 50 * Math.pow(currentLevel, 2);

        const progress = ((currentXP - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;
        return Math.min(Math.max(progress, 0), 100);
    },

    // --- ASSIGNMENT MANAGER ---
    showAssignmentManager() {
        if (this.currentUser.role !== 'admin') {
            Toast.error('Yetkiniz yok!');
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'assignment-manager-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 900px; height: 80vh; display:flex; flex-direction:column;">
                <div class="modal-header">
                    <h2><i class="fa-solid fa-tasks"></i> Atama Yönetimi</h2>
                    <button class="modal-close" onclick="document.getElementById('assignment-manager-modal').remove()">×</button>
                </div>
                <div class="modal-body" style="flex:1; display:grid; grid-template-columns: 1fr 1fr; gap:20px; overflow:hidden; padding:20px;">
                    
                    <!-- Translators List -->
                    <div class="glass-panel" style="display:flex; flex-direction:column; overflow:hidden;">
                        <h3 style="margin-bottom:10px; color:#a78bfa;">Çevirmenler</h3>
                        <div class="search-box" style="margin-bottom:10px;">
                            <i class="fa-solid fa-search"></i>
                            <input type="text" placeholder="Çevirmen ara..." oninput="StudioDashboard.filterTranslators(this.value)">
                        </div>
                        <div id="am-translator-list" style="flex:1; overflow-y:auto; padding-right:5px;">
                            <!-- Populated via JS -->
                            <div style="text-align:center; padding:20px;">Yükleniyor...</div>
                        </div>
                    </div>

                    <!-- Content List -->
                    <div class="glass-panel" style="display:flex; flex-direction:column; overflow:hidden;">
                        <h3 style="margin-bottom:10px; color:#f472b6;">İçerikler</h3>
                         <div class="search-box" style="margin-bottom:10px;">
                            <i class="fa-solid fa-search"></i>
                            <input type="text" placeholder="İçerik ara..." oninput="StudioDashboard.filterAssignableContent(this.value)">
                        </div>
                         <div style="display:flex; gap:5px; margin-bottom:10px;">
                            <button class="btn btn-xs btn-outline active" onclick="StudioDashboard.loadAssignableContent('all')">Tümü</button>
                            <button class="btn btn-xs btn-outline" onclick="StudioDashboard.loadAssignableContent('series')">Diziler</button>
                            <button class="btn btn-xs btn-outline" onclick="StudioDashboard.loadAssignableContent('webtoon')">Webtoon</button>
                        </div>
                        <div id="am-content-list" style="flex:1; overflow-y:auto; padding-right:5px;">
                             <!-- Populated via JS -->
                             <div style="text-align:center; padding:20px;">Yükleniyor...</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        this.loadTranslators();
        this.loadAssignableContent();
    },

    async loadTranslators() {
        // Mock data or fetch from API
        // In real app: fetch('/api/users?role=translator')
        const translators = State.data.users.filter(u => u.role === 'translator' || u.role === 'admin'); // Admins can also translate
        this.renderTranslatorsList(translators);
    },

    renderTranslatorsList(list) {
        const container = document.getElementById('am-translator-list');
        if (!container) return;

        container.innerHTML = list.map(u => `
            <div class="am-item" onclick="StudioDashboard.selectTranslator('${u.id}', this)" style="padding:10px; margin-bottom:8px; background:rgba(255,255,255,0.05); border-radius:8px; cursor:pointer; display:flex; align-items:center; gap:10px; border:1px solid transparent;">
                <img src="${u.avatar || 'assets/logo.png'}" style="width:32px; height:32px; border-radius:50%;">
                <div style="flex:1;">
                    <div style="font-weight:600;">${u.username}</div>
                    <div style="font-size:0.8rem; color:#888;">${u.creatorStats?.rank || 'Çevirmen'} • ${(u.assignedContent || []).length} Görev</div>
                </div>
                ${this.selectedTranslatorId === u.id ? '<i class="fa-solid fa-check-circle" style="color:#10b981;"></i>' : ''}
            </div>
        `).join('');
    },

    selectTranslator(id, el) {
        // Toggle selection
        document.querySelectorAll('#am-translator-list .am-item').forEach(e => e.style.borderColor = 'transparent');

        if (this.selectedTranslatorId === id) {
            this.selectedTranslatorId = null;
        } else {
            this.selectedTranslatorId = id;
            el.style.borderColor = '#8b5cf6';
        }
        // Re-render to show checkmark (optional or simple class toggle)
    },

    async loadAssignableContent(type = 'all') {
        let content = [];
        if (type === 'all' || type === 'series') content = [...content, ...this.allSeries];
        if (type === 'all' || type === 'webtoon') content = [...content, ...this.allWebtoons];

        // Filter those needing assignment (optional logic)
        this.renderAssignableContentList(content);
    },

    renderAssignableContentList(list) {
        const container = document.getElementById('am-content-list');
        if (!container) return;

        container.innerHTML = list.map(c => `
            <div class="am-item" style="padding:10px; margin-bottom:8px; background:rgba(255,255,255,0.05); border-radius:8px; display:flex; align-items:center; gap:10px;">
                <img src="${c.poster}" style="width:30px; height:45px; object-fit:cover; border-radius:4px;">
                <div style="flex:1;">
                    <div style="font-weight:600; font-size:0.9rem;">${c.title}</div>
                    <div style="font-size:0.75rem; color:#888;">${c.translator ? `<i class="fa-solid fa-user"></i> ${c.translator}` : '<span style="color:#ef4444">Atanmamış</span>'}</div>
                </div>
                <button class="btn btn-sm btn-primary" onclick="StudioDashboard.assignContent('${c.id}')" ${!this.selectedTranslatorId ? 'disabled' : ''}>
                    Atama Yap
                </button>
            </div>
         `).join('');
    },

    filterTranslators(query) {
        const translators = State.data.users.filter(u => u.role === 'translator' || u.role === 'admin');
        const filtered = translators.filter(u => u.username.toLowerCase().includes(query.toLowerCase()));
        this.renderTranslatorsList(filtered);
    },

    filterAssignableContent(query) {
        // Simple search on currently loaded allSeries/allWebtoons
        // For brevity, just re-calling load with filter
        const all = [...this.allSeries, ...this.allWebtoons];
        const filtered = all.filter(c => c.title.toLowerCase().includes(query.toLowerCase()));
        this.renderAssignableContentList(filtered);
    },

    async assignContent(contentId) {
        if (!this.selectedTranslatorId) {
            Toast.warning('Önce bir çevirmen seçin!');
            return;
        }

        const translator = State.data.users.find(u => u.id === this.selectedTranslatorId);
        if (!translator) return;

        // API Call
        // await fetch(...)

        Toast.success('Atama başarıyla yapıldı!');
        // Update local data primarily for UI
        const item = [...this.allSeries, ...this.allWebtoons].find(c => c.id === contentId);
        if (item) item.translator = translator.username;
        this.loadAssignableContent(); // Refresh UI
    },

    showXPGain(xpData) {
        if (!xpData) return;

        Toast.success(`+${xpData.xpGained} Creator XP kazandınız!`);

        if (xpData.leveledUp) {
            Toast.success(`🎉 TEBRİKLER! ${xpData.newRank} (Seviye ${xpData.newLevel}) oldunuz!`);
            if (window.confetti) confetti();
        }

        // Update local user state
        if (this.currentUser.id === State.currentUser.id) {
            State.currentUser.creatorStats = {
                ...State.currentUser.creatorStats,
                xp: (State.currentUser.creatorStats?.xp || 0) + xpData.xpGained,
                level: xpData.newLevel,
                rank: xpData.newRank
            };
            this.currentUser = State.currentUser; // Update local ref
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            this.render(); // Refresh dashboard
        }
    },

    renderSettings() {
        if (this.currentUser.role !== 'admin') return '<p>Yetkiniz yok.</p>';
        const shortsEnabled = (typeof DramaShorts !== 'undefined') ? DramaShorts.isEnabled : true;
        return `
            <div class="settings-panel" style="background: rgba(30, 41, 59, 0.4); padding: 30px; border-radius: 12px; border: 1px solid rgba(139, 92, 246, 0.2);">
                <h2 style="margin-bottom: 25px;"><i class="fa-solid fa-gears"></i> Global Özellik Yönetimi</h2>
                <div class="setting-row" style="display: flex; justify-content: space-between; align-items: center; padding: 15px; background: rgba(0,0,0,0.2); border-radius: 10px; margin-bottom: 15px;">
                    <div>
                        <div style="font-weight: 700; font-size: 1.1rem;">Drama Shorts (TikTok Modu)</div>
                        <div style="color: #94a3b8; font-size: 0.85rem;">Ana sayfadaki dikey kısa video akışını aktif eder veya gizler.</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="toggle-shorts" ${shortsEnabled ? 'checked' : ''} onchange="DramaShorts.toggleFromAdmin(this.checked)">
                        <span class="slider round"></span>
                    </label>
                </div>
                <div class="setting-row" style="display: flex; justify-content: space-between; align-items: center; padding: 15px; background: rgba(0,0,0,0.2); border-radius: 10px; margin-bottom: 15px;">
                    <div>
                        <div style="font-weight: 700; font-size: 1.1rem;">Mağaza & Ekonomi</div>
                        <div style="color: #94a3b8; font-size: 0.85rem;">Kullanıcıların coin harcayarak öğe almasını yönetir.</div>
                    </div>
                    <label class="switch">
                        <input type="checkbox" checked disabled>
                        <span class="slider round"></span>
                    </label>
                </div>
                <style>
                    .switch { position: relative; display: inline-block; width: 60px; height: 34px; }
                    .switch input { opacity: 0; width: 0; height: 0; }
                    .slider { position: absolute; cursor: pointer; inset: 0; background-color: #334155; transition: .4s; border-radius: 34px; }
                    .slider:before { position: absolute; content: ""; height: 26px; width: 26px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; }
                    input:checked + .slider { background-color: #8b5cf6; }
                    input:checked + .slider:before { transform: translateX(26px); }
                </style>
            </div>
        `;
    },

    renderRequests() {
        if (this.currentUser.role !== 'admin') return '<p>Yetkiniz yok.</p>';
        return RequestSystem.renderAdminList();
    },

    renderHeroSliderEditor() {
        const container = document.getElementById('studio-content-grid');
        if (!State.data.heroSlides) State.data.heroSlides = [];

        container.innerHTML = `
            <div class="studio-section" style="padding: 20px;">
                <div class="section-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <div>
                        <h2 style="margin: 0; color: #fff;"><i class="fa-solid fa-images" style="color: #8b5cf6; margin-right: 12px;"></i> Hero Slider Yönetimi</h2>
                        <p style="margin: 5px 0 0; color: #94a3b8; font-size: 0.9rem;">Ana sayfadaki büyük slayt geçişlerini buradan yönetebilirsiniz.</p>
                    </div>
                    <button class="btn btn-primary" onclick="StudioDashboard.openSlideEditor()" style="padding: 12px 24px; border-radius: 12px; font-weight: 700;">
                        <i class="fa-solid fa-plus"></i> Yeni Slayt Ekle
                    </button>
                </div>
                
                <div class="slides-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 25px;">
                    ${State.data.heroSlides.map((slide, index) => `
                        <div class="slide-card-modern" style="background: rgba(30, 41, 59, 0.4); border: 1px solid rgba(139, 92, 246, 0.2); border-radius: 20px; overflow: hidden; transition: all 0.3s ease; position: relative;">
                            <div class="slide-preview" style="height: 180px; background-image: url('${slide.poster || slide.coverImage}'); background-size: cover; background-position: center;">
                                <div class="slide-overlay" style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(15, 23, 42, 0.9), transparent); display: flex; align-items: flex-end; padding: 15px;">
                                    <div style="display: flex; gap: 8px; position: absolute; top: 12px; right: 12px;">
                                        <button class="btn-icon" onclick="StudioDashboard.openSlideEditor(${index})" style="background: #3b82f6; color: white; width: 36px; height: 36px; border-radius: 10px; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s;"><i class="fa-solid fa-pen"></i></button>
                                        <button class="btn-icon" onclick="StudioDashboard.deleteSlide(${index})" style="background: #ef4444; color: white; width: 36px; height: 36px; border-radius: 10px; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s;"><i class="fa-solid fa-trash"></i></button>
                                    </div>
                                    ${slide.isVip ? '<span style="background: linear-gradient(135deg, #f59e0b, #d97706); color: white; padding: 4px 10px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);">VIP</span>' : ''}
                                </div>
                            </div>
                            <div class="slide-details" style="padding: 18px;">
                                <h4 style="margin: 0; font-size: 1.1rem; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${slide.title}</h4>
                                <p style="margin: 8px 0 0; font-size: 0.85rem; color: #94a3b8; line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${slide.description || 'Açıklama belirtilmemiş.'}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                ${State.data.heroSlides.length === 0 ? `
                    <div style="padding: 80px 20px; text-align: center; background: rgba(30, 41, 59, 0.2); border: 2px dashed rgba(139, 92, 246, 0.1); border-radius: 24px;">
                        <i class="fa-solid fa-images" style="font-size: 4rem; color: #334155; margin-bottom: 20px; display: block;"></i>
                        <h3 style="color: #94a3b8;">Henüz slayt eklenmemiş</h3>
                        <p style="color: #64748b; margin-top: 10px;">İlk slaytınızı eklemek için sağ üstteki butonu kullanın.</p>
                    </div>
                ` : ''}
            </div>
            
            <!-- Slide Editor Modal -->
            <div id="slide-editor-overlay" style="display: none; position: fixed; inset: 0; background: rgba(2, 6, 23, 0.85); z-index: 10000; backdrop-filter: blur(12px); align-items: center; justify-content: center; padding: 20px;">
                <div style="background: #1e293b; border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 28px; width: 100%; max-width: 650px; max-height: 90vh; overflow-y: auto; box-shadow: 0 30px 60px -12px rgba(0,0,0,0.6);">
                    <div style="padding: 24px 30px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.05);">
                        <h3 id="slide-editor-title" style="margin: 0; font-size: 1.5rem; color: #fff;">Slayt Düzenle</h3>
                        <button onclick="StudioDashboard.closeSlideEditor()" style="background: rgba(255,255,255,0.05); color: #fff; border: none; width: 40px; height: 40px; border-radius: 12px; cursor: pointer; display: flex; align-items: center; justify-content: center;"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                    <form id="slide-editor-form" style="padding: 30px; display: flex; flex-direction: column; gap: 20px;">
                        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                            <div>
                                <label style="display: block; margin-bottom: 8px; font-size: 0.9rem; color: #94a3b8; font-weight: 600;">İçerik Başlığı</label>
                                <input type="text" id="slide-title" required placeholder="Örn: Squid Game" style="width: 100%; padding: 14px 18px; background: #0f172a; border: 1px solid #334155; border-radius: 12px; color: white; font-size: 1rem;">
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 8px; font-size: 0.9rem; color: #94a3b8; font-weight: 600;">VIP Durumu</label>
                                <div style="padding: 12px; background: #0f172a; border: 1px solid #334155; border-radius: 12px; display: flex; align-items: center; gap: 10px;">
                                    <input type="checkbox" id="slide-is-vip" style="width: 20px; height: 20px; cursor: pointer; accent-color: #8b5cf6;">
                                    <span style="color: #e2e8f0; font-size: 0.95rem;">Sadece VIP</span>
                                </div>
                            </div>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                            <div>
                                <label style="display: block; margin-bottom: 8px; font-size: 0.9rem; color: #94a3b8; font-weight: 600;">Arka Plan / Afiş URL</label>
                                <input type="text" id="slide-poster" required placeholder="https://..." style="width: 100%; padding: 14px 18px; background: #0f172a; border: 1px solid #334155; border-radius: 12px; color: white; font-size: 0.9rem;">
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 8px; font-size: 0.9rem; color: #94a3b8; font-weight: 600;">Logo URL (Şeffaf PNG)</label>
                                <input type="text" id="slide-logo" placeholder="https://..." style="width: 100%; padding: 14px 18px; background: #0f172a; border: 1px solid #334155; border-radius: 12px; color: white; font-size: 0.9rem;">
                            </div>
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 8px; font-size: 0.9rem; color: #94a3b8; font-weight: 600;">Kısa Açıklama</label>
                            <textarea id="slide-desc" rows="3" placeholder="İçerik hakkında kısa, vurucu bir açıklama yazın..." style="width: 100%; padding: 14px 18px; background: #0f172a; border: 1px solid #334155; border-radius: 12px; color: white; resize: none; line-height: 1.6; font-size: 0.95rem;"></textarea>
                        </div>
                        <div style="display: flex; gap: 15px; margin-top: 10px;">
                            <button type="button" class="btn" style="flex: 1; padding: 14px; background: rgba(255,255,255,0.05); color: #fff; font-weight: 600;" onclick="StudioDashboard.closeSlideEditor()">Vazgeç</button>
                            <button type="submit" class="btn btn-primary" style="flex: 2; padding: 14px; background: linear-gradient(135deg, #8b5cf6, #7c3aed); box-shadow: 0 10px 20px rgba(139, 92, 246, 0.3); font-weight: 700;">Değişiklikleri Kaydet</button>
                        </div>
                    </form>
                </div>
            </div>
        `;

        const form = document.getElementById('slide-editor-form');
        if (form) {
            form.onsubmit = (e) => {
                e.preventDefault();
                this.saveSlide();
            };
        }
    },

    openSlideEditor(index = null) {
        this.heroEditor.currentSlideIndex = index;
        const overlay = document.getElementById('slide-editor-overlay');
        const titleEl = document.getElementById('slide-editor-title');

        if (overlay) {
            overlay.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            titleEl.textContent = index !== null ? 'Slaytı Düzenle' : 'Yeni Slayt Ekle';

            if (index !== null) {
                const s = State.data.heroSlides[index];
                document.getElementById('slide-title').value = s.title || '';
                document.getElementById('slide-poster').value = s.poster || s.coverImage || '';
                document.getElementById('slide-logo').value = s.logo || '';
                document.getElementById('slide-desc').value = s.description || '';
                document.getElementById('slide-is-vip').checked = s.isVip || false;
            } else {
                document.getElementById('slide-editor-form').reset();
            }
        }
    },

    closeSlideEditor() {
        const overlay = document.getElementById('slide-editor-overlay');
        if (overlay) overlay.style.display = 'none';
        document.body.style.overflow = '';
        this.heroEditor.currentSlideIndex = null;
    },

    async saveSlide() {
        const title = document.getElementById('slide-title').value;
        const poster = document.getElementById('slide-poster').value;
        const logo = document.getElementById('slide-logo').value;
        const description = document.getElementById('slide-desc').value;
        const isVip = document.getElementById('slide-is-vip').checked;

        if (!State.data.heroSlides) State.data.heroSlides = [];

        const slideData = {
            id: this.heroEditor.currentSlideIndex !== null ? State.data.heroSlides[this.heroEditor.currentSlideIndex].id : Date.now().toString(),
            title,
            poster,
            logo,
            description,
            isVip,
            updatedAt: new Date().toISOString()
        };

        if (this.heroEditor.currentSlideIndex !== null) {
            State.data.heroSlides[this.heroEditor.currentSlideIndex] = slideData;
        } else {
            State.data.heroSlides.unshift(slideData);
        }

        if (window.db && db.saveData) await db.saveData(State.data);

        Toast.success('Slider güncellendi!');
        this.closeSlideEditor();
        this.render();
    },

    async deleteSlide(index) {
        if (!confirm('Bu slaytı silmek istediğinize emin misiniz? Bu işlem geri alınamaz.')) return;

        State.data.heroSlides.splice(index, 1);
        if (window.db && db.saveData) await db.saveData(State.data);

        Toast.success('Slayt silindi');
        this.render();
    },

    calculateXPProgress() {
        // Dummy progress for now
        return 65;
    }
};


// ==========================================
// TRANSLATOR CHAT MODULE
// ==========================================
const TranslatorChat = {
    isOpen: false,

    toggle() {
        this.isOpen = !this.isOpen;
        const chatBox = document.getElementById('translator-chat-box');

        if (this.isOpen) {
            if (!chatBox) this.createChatBox();
            else chatBox.style.display = 'flex';
            this.scrollToBottom();
        } else {
            if (chatBox) chatBox.style.display = 'none';
        }
    },

    createChatBox() {
        const div = document.createElement('div');
        div.id = 'translator-chat-box';
        div.style.cssText = `
            position: fixed; bottom: 20px; right: 20px; width: 350px; height: 500px;
            background: #161618; border: 1px solid #333; border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.5); z-index: 1000;
            display: flex; flex-direction: column; overflow: hidden;
            animation: slideInUp 0.3s ease;
        `;

        div.innerHTML = `
            <div style="padding: 15px; background: #1f1f23; border-bottom: 1px solid #333; display: flex; justify-content: space-between; align-items: center;">
                <h3 style="margin:0; font-size:1rem; display:flex; align-items:center; gap:8px;">
                    <i class="fa-solid fa-comments" style="color:#8b5cf6;"></i> Çevirmen Odası
                </h3>
                <button onclick="TranslatorChat.toggle()" style="background:none; border:none; color:#888; cursor:pointer; font-size:1.2rem;">&times;</button>
            </div>
            <div id="tc-messages" style="flex: 1; padding: 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px;">
                <!-- Messages -->
                <div style="text-align:center; color:#666; font-size:0.8rem; margin-top:20px;">Sohbet başladı...</div>
            </div>
            <div style="padding: 15px; background: #1f1f23; border-top: 1px solid #333; display:flex; gap:10px;">
                <input type="text" id="tc-input" placeholder="Bir şeyler yaz..." style="flex:1; background:#111; border:1px solid #333; border-radius:20px; padding:10px 15px; color:white; outline:none;" onkeypress="if(event.key==='Enter') TranslatorChat.send()">
                <button onclick="TranslatorChat.send()" style="width: 40px; height: 40px; border-radius: 50%; background: #8b5cf6; border: none; color: white; cursor: pointer;">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
        `;

        document.body.appendChild(div);
        this.loadMessages();
    },

    loadMessages() {
        // In reality, fetch from API /api/chat?room=translators
        // For now, mock or load from localStorage
        const msgs = JSON.parse(localStorage.getItem('tc_messages') || '[]');
        this.renderMessages(msgs);
    },

    renderMessages(msgs) {
        const container = document.getElementById('tc-messages');
        if (!container) return;

        // Clear except header if any
        container.innerHTML = '<div style="text-align:center; color:#666; font-size:0.8rem; margin-top:20px;">Sohbet başladı...</div>';

        msgs.forEach(m => {
            const isMe = State.currentUser && m.userId === State.currentUser.id;
            const bubble = document.createElement('div');
            bubble.style.cssText = `
                max-width: 80%; padding: 8px 12px; border-radius: 12px;
                font-size: 0.9rem; line-height: 1.4; position: relative;
                align-self: ${isMe ? 'flex-end' : 'flex-start'};
                background: ${isMe ? '#8b5cf6' : '#333'};
                color: ${isMe ? 'white' : '#ddd'};
                border-bottom-${isMe ? 'right' : 'left'}-radius: 2px;
            `;
            bubble.innerHTML = `
                ${!isMe ? `<div style="font-size:0.7rem; color:rgba(255,255,255,0.6); margin-bottom:2px;">${m.username}</div>` : ''}
                ${m.text}
            `;
            container.appendChild(bubble);
        });
        this.scrollToBottom();
    },

    send() {
        const input = document.getElementById('tc-input');
        const text = input.value.trim();
        if (!text) return;

        if (!State.currentUser) {
            Toast.error('Giriş yapmalısınız');
            return;
        }

        const msg = {
            id: Date.now(),
            userId: State.currentUser.id,
            username: State.currentUser.username,
            text: text,
            timestamp: Date.now()
        };

        // Save
        const msgs = JSON.parse(localStorage.getItem('tc_messages') || '[]');
        msgs.push(msg);
        localStorage.setItem('tc_messages', JSON.stringify(msgs)); // Mock Persistence

        input.value = '';
        this.renderMessages(msgs);
    },

    scrollToBottom() {
        const container = document.getElementById('tc-messages');
        if (container) container.scrollTop = container.scrollHeight;
    }
};

// ==========================================
// ADMIN CONTENT MANAGEMENT (NEW)
// ==========================================
const AdminContent = {
    showAddSeriesModal(seriesId = null) {
        const series = seriesId ? State.data.series.find(s => s.id === seriesId) : null;
        
        const modal = document.createElement('div');
        modal.className = 'create-post-modal-overlay';
        modal.id = 'admin-edit-modal';
        modal.innerHTML = `
            <div class="create-post-modal" style="max-width: 700px;">
                <div class="create-post-modal-header">
                    <h2>${series ? 'İçeriği Düzenle' : 'Yeni İçerik Ekle'}</h2>
                    <button class="close-btn" onclick="document.getElementById('admin-edit-modal').remove()">×</button>
                </div>
                <div style="padding: 20px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div>
                        <label style="display:block; margin-bottom:5px; font-weight:700;">Başlık</label>
                        <input type="text" id="edit-title" class="m-input" value="${series?.title || ''}" style="width:100%;">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:5px; font-weight:700;">Tür</label>
                        <select id="edit-type" class="m-input" style="width:100%;">
                            <option value="drama" ${series?.type === 'drama' ? 'selected' : ''}>Dizi</option>
                            <option value="movie" ${series?.type === 'movie' ? 'selected' : ''}>Film</option>
                            <option value="anime" ${series?.type === 'anime' ? 'selected' : ''}>Anime</option>
                        </select>
                    </div>
                    <div style="grid-column: span 2;">
                        <label style="display:block; margin-bottom:5px; font-weight:700;">Afiş URL</label>
                        <input type="text" id="edit-poster" class="m-input" value="${series?.poster || ''}" style="width:100%;">
                    </div>
                    <div style="grid-column: span 2;">
                        <button class="btn btn-primary" onclick="AdminContent.saveSeries('${seriesId}')" style="width:100%;">KAYDET</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    saveSeries(id) {
        const title = document.getElementById('edit-title').value;
        const type = document.getElementById('edit-type').value;
        const poster = document.getElementById('edit-poster').value;

        if (!title || !poster) return Toast.error('Tüm alanları doldurun!');

        const data = {
            id: id !== 'null' ? id : Date.now().toString(),
            title, type, poster,
            updatedAt: new Date().toISOString()
        };

        if (id !== 'null') {
            const idx = State.data.series.findIndex(s => s.id === id);
            if (idx > -1) State.data.series[idx] = { ...State.data.series[idx], ...data };
        } else {
            State.data.series.unshift(data);
        }

        db.syncItem('series', data);
        Toast.success('İçerik kaydedildi!');
        document.getElementById('admin-edit-modal').remove();
        StudioDashboard.switchTab(StudioDashboard.currentTab);
    }
};

window.AdminContent = AdminContent;

// Add repairSystem to StudioDashboard
StudioDashboard.repairSystem = function() {
    Toast.info('Sistem onarılıyor...');
    setTimeout(() => {
        db.saveData(State.data);
        Toast.success('Sistem onarıldı ve veriler senkronize edildi!');
        location.reload();
    }, 1500);
};

// Initialize on load
if (typeof window !== 'undefined') {
    window.StudioDashboard = StudioDashboard;
    window.TranslatorChat = TranslatorChat;
}
