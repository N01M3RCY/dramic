// Advanced Analytics - Yearly Wrapped & Insights
const AdvancedAnalytics = {
    init() {
        console.log('📊 Advanced Analytics initialized');
    },

    // Spotify Wrapped tarzı yıllık özet
    showYearlyWrapped(year = new Date().getFullYear()) {
        const data = this.calculateYearlyStats(year);

        const modal = document.createElement('div');
        modal.className = 'modal wrapped-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content wrapped-container" style="max-width: 800px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0; overflow: hidden;">
                <button class="modal-close" onclick="this.closest('.modal').remove()" style="color: white; z-index: 10;">×</button>
                
                <div class="wrapped-slides" id="wrapped-slides">
                    ${this.renderWrappedSlides(data, year)}
                </div>
                
                <div class="wrapped-navigation" style="position: absolute; bottom: 30px; left: 50%; transform: translateX(-50%); display: flex; gap: 10px;">
                    <button onclick="AdvancedAnalytics.previousSlide()" class="btn btn-outline" style="color: white; border-color: white;">
                        <i class="fa-solid fa-chevron-left"></i>
                    </button>
                    <button onclick="AdvancedAnalytics.nextSlide()" class="btn btn-outline" style="color: white; border-color: white;">
                        <i class="fa-solid fa-chevron-right"></i>
                    </button>
                    <button onclick="AdvancedAnalytics.shareWrapped()" class="btn btn-primary">
                        <i class="fa-solid fa-share"></i> Paylaş
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        this.currentSlide = 0;
        this.showSlide(0);
    },

    calculateYearlyStats(year) {
        const history = State.currentUser?.watchHistory || [];
        const yearHistory = history.filter(h => {
            const watchYear = new Date(h.watchedAt).getFullYear();
            return watchYear === year;
        });

        const totalMinutes = yearHistory.reduce((sum, h) => sum + (h.duration / 60), 0);
        const totalHours = Math.floor(totalMinutes / 60);
        const totalEpisodes = yearHistory.length;

        // En çok izlenen tür
        const genres = {};
        yearHistory.forEach(h => {
            const series = State.data?.series?.find(s => s.id === h.seriesId);
            if (series && series.genre) {
                series.genre.forEach(g => {
                    genres[g] = (genres[g] || 0) + 1;
                });
            }
        });
        const topGenre = Object.keys(genres).sort((a, b) => genres[b] - genres[a])[0] || 'Aksiyon';

        // En çok izlenen dizi
        const seriesCount = {};
        yearHistory.forEach(h => {
            seriesCount[h.seriesId] = (seriesCount[h.seriesId] || 0) + 1;
        });
        const topSeriesId = Object.keys(seriesCount).sort((a, b) => seriesCount[b] - seriesCount[a])[0];
        const topSeries = State.data?.series?.find(s => s.id === topSeriesId);

        // En aktif ay
        const months = {};
        yearHistory.forEach(h => {
            const month = new Date(h.watchedAt).getMonth();
            months[month] = (months[month] || 0) + 1;
        });
        const topMonth = Object.keys(months).sort((a, b) => months[b] - months[a])[0];
        const monthNames = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];

        return {
            year,
            totalHours,
            totalMinutes,
            totalEpisodes,
            topGenre,
            topSeries: topSeries?.title || 'Bilinmiyor',
            topMonth: monthNames[topMonth] || 'Ocak',
            avgPerDay: Math.floor(totalMinutes / 365),
            prediction: Math.floor((totalEpisodes / new Date().getMonth() || 1) * 12)
        };
    },

    renderWrappedSlides(data, year) {
        return `
            <div class="wrapped-slide" data-slide="0">
                <div style="padding: 80px 60px; text-align: center; min-height: 600px; display: flex; flex-direction: column; justify-content: center;">
                    <h1 style="font-size: 4rem; margin-bottom: 20px; animation: fadeInUp 0.8s ease;">🎬</h1>
                    <h2 style="font-size: 2.5rem; margin-bottom: 10px; animation: fadeInUp 0.8s ease 0.2s; opacity: 0; animation-fill-mode: forwards;">
                        ${year} Yılı Özetiniz
                    </h2>
                    <p style="font-size: 1.2rem; opacity: 0.9; animation: fadeInUp 0.8s ease 0.4s; opacity: 0; animation-fill-mode: forwards;">
                        ${State.currentUser?.username}, bu yıl neler izlediniz?
                    </p>
                </div>
            </div>

            <div class="wrapped-slide" data-slide="1">
                <div style="padding: 80px 60px; text-align: center; min-height: 600px; display: flex; flex-direction: column; justify-content: center;">
                    <h3 style="font-size: 1.5rem; margin-bottom: 30px; opacity: 0.9;">Toplam İzleme Süreniz</h3>
                    <div style="font-size: 6rem; font-weight: 900; margin-bottom: 20px; text-shadow: 0 4px 20px rgba(0,0,0,0.3);">
                        ${data.totalHours}
                    </div>
                    <p style="font-size: 2rem; margin-bottom: 10px;">saat</p>
                    <p style="font-size: 1.2rem; opacity: 0.8;">
                        Bu ${Math.floor(data.totalHours / 24)} gün demek! 🤯
                    </p>
                </div>
            </div>

            <div class="wrapped-slide" data-slide="2">
                <div style="padding: 80px 60px; text-align: center; min-height: 600px; display: flex; flex-direction: column; justify-content: center;">
                    <h3 style="font-size: 1.5rem; margin-bottom: 30px; opacity: 0.9;">İzlediğiniz Bölüm Sayısı</h3>
                    <div style="font-size: 6rem; font-weight: 900; margin-bottom: 20px;">
                        ${data.totalEpisodes}
                    </div>
                    <p style="font-size: 1.5rem; margin-bottom: 10px;">bölüm</p>
                    <p style="font-size: 1.2rem; opacity: 0.8;">
                        Günde ortalama ${data.avgPerDay} dakika! ⏱️
                    </p>
                </div>
            </div>

            <div class="wrapped-slide" data-slide="3">
                <div style="padding: 80px 60px; text-align: center; min-height: 600px; display: flex; flex-direction: column; justify-content: center;">
                    <h3 style="font-size: 1.5rem; margin-bottom: 30px; opacity: 0.9;">En Sevdiğiniz Tür</h3>
                    <div style="font-size: 4rem; font-weight: 900; margin-bottom: 20px;">
                        ${data.topGenre}
                    </div>
                    <p style="font-size: 1.2rem; opacity: 0.8;">
                        ${data.topGenre} türünde uzmanlaştınız! 🎭
                    </p>
                </div>
            </div>

            <div class="wrapped-slide" data-slide="4">
                <div style="padding: 80px 60px; text-align: center; min-height: 600px; display: flex; flex-direction: column; justify-content: center;">
                    <h3 style="font-size: 1.5rem; margin-bottom: 30px; opacity: 0.9;">En Çok İzlediğiniz Dizi</h3>
                    <div style="font-size: 3rem; font-weight: 900; margin-bottom: 20px;">
                        ${data.topSeries}
                    </div>
                    <p style="font-size: 1.2rem; opacity: 0.8;">
                        Favoriniz belli! ⭐
                    </p>
                </div>
            </div>

            <div class="wrapped-slide" data-slide="5">
                <div style="padding: 80px 60px; text-align: center; min-height: 600px; display: flex; flex-direction: column; justify-content: center;">
                    <h3 style="font-size: 1.5rem; margin-bottom: 30px; opacity: 0.9;">En Aktif Ayınız</h3>
                    <div style="font-size: 4rem; font-weight: 900; margin-bottom: 20px;">
                        ${data.topMonth}
                    </div>
                    <p style="font-size: 1.2rem; opacity: 0.8;">
                        ${data.topMonth} ayında rekor kırdınız! 📅
                    </p>
                </div>
            </div>

            <div class="wrapped-slide" data-slide="6">
                <div style="padding: 80px 60px; text-align: center; min-height: 600px; display: flex; flex-direction: column; justify-content: center;">
                    <h3 style="font-size: 1.5rem; margin-bottom: 30px; opacity: 0.9;">Tahmin</h3>
                    <p style="font-size: 1.5rem; margin-bottom: 20px; opacity: 0.9;">
                        Bu hızla ${year + 1} yılında
                    </p>
                    <div style="font-size: 5rem; font-weight: 900; margin-bottom: 20px;">
                        ${data.prediction}
                    </div>
                    <p style="font-size: 1.5rem;">bölüm izleyeceksiniz! 🚀</p>
                </div>
            </div>

            <div class="wrapped-slide" data-slide="7">
                <div style="padding: 80px 60px; text-align: center; min-height: 600px; display: flex; flex-direction: column; justify-content: center;">
                    <h2 style="font-size: 2.5rem; margin-bottom: 30px;">Teşekkürler! 🎉</h2>
                    <p style="font-size: 1.3rem; margin-bottom: 40px; opacity: 0.9;">
                        ${year} harika bir yıldı!
                    </p>
                    <button onclick="AdvancedAnalytics.exportWrappedPDF()" class="btn btn-primary" style="margin: 0 auto;">
                        <i class="fa-solid fa-download"></i> PDF İndir
                    </button>
                </div>
            </div>
        `;
    },

    currentSlide: 0,
    totalSlides: 8,

    showSlide(index) {
        const slides = document.querySelectorAll('.wrapped-slide');
        slides.forEach((slide, i) => {
            slide.style.display = i === index ? 'block' : 'none';
        });
        this.currentSlide = index;
    },

    nextSlide() {
        if (this.currentSlide < this.totalSlides - 1) {
            this.showSlide(this.currentSlide + 1);
        }
    },

    previousSlide() {
        if (this.currentSlide > 0) {
            this.showSlide(this.currentSlide - 1);
        }
    },

    shareWrapped() {
        Toast.success('Paylaşma özelliği yakında eklenecek!');
    },

    exportWrappedPDF() {
        Toast.info('PDF export özelliği yakında eklenecek!');
        // TODO: html2pdf.js kullanarak PDF oluştur
    },

    // Geçen ay karşılaştırması
    getMonthlyComparison() {
        const now = new Date();
        const thisMonth = now.getMonth();
        const lastMonth = thisMonth - 1;

        const history = State.currentUser?.watchHistory || [];

        const thisMonthData = history.filter(h => {
            const date = new Date(h.watchedAt);
            return date.getMonth() === thisMonth && date.getFullYear() === now.getFullYear();
        });

        const lastMonthData = history.filter(h => {
            const date = new Date(h.watchedAt);
            return date.getMonth() === lastMonth;
        });

        const thisMonthMinutes = thisMonthData.reduce((sum, h) => sum + (h.duration / 60), 0);
        const lastMonthMinutes = lastMonthData.reduce((sum, h) => sum + (h.duration / 60), 0);

        const change = lastMonthMinutes > 0
            ? ((thisMonthMinutes - lastMonthMinutes) / lastMonthMinutes * 100).toFixed(1)
            : 100;

        return {
            thisMonth: Math.floor(thisMonthMinutes),
            lastMonth: Math.floor(lastMonthMinutes),
            change: parseFloat(change),
            episodes: {
                thisMonth: thisMonthData.length,
                lastMonth: lastMonthData.length
            }
        };
    }
};

// Keyboard navigation for wrapped
document.addEventListener('keydown', (e) => {
    if (document.querySelector('.wrapped-modal')) {
        if (e.key === 'ArrowRight') AdvancedAnalytics.nextSlide();
        if (e.key === 'ArrowLeft') AdvancedAnalytics.previousSlide();
    }
});

console.log('✅ Advanced Analytics Module Loaded!');
