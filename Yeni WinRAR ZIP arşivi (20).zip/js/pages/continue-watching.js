// ============================================
// CONTINUE WATCHING SYSTEM
// Shows next unwatched episode for user
// ============================================

const ContinueWatching = {
    init() {
        // Check if user previously dismissed the section
        const dismissed = localStorage.getItem('dramicbox_cw_dismissed');
        const section = document.getElementById('continue-watching-section');
        if (dismissed === 'true' && section) {
            section.style.display = 'none';
            return;
        }
        this.renderContinueWatching();
    },

    dismissSection() {
        const section = document.getElementById('continue-watching-section');
        if (section) {
            section.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
            section.style.opacity = '0';
            section.style.transform = 'translateY(-20px)';
            setTimeout(() => {
                section.style.display = 'none';
                section.style.opacity = '';
                section.style.transform = '';
            }, 400);
        }
        localStorage.setItem('dramicbox_cw_dismissed', 'true');
        if (window.UserCustomization) {
            UserCustomization.settings.showContinueWatching = false;
            UserCustomization.saveSettings();
        }
        if (window.Toast) Toast.info('Devam Et bölümü gizlendi. Profil ayarlarından tekrar açabilirsiniz.');
    },

    restoreSection() {
        localStorage.removeItem('dramicbox_cw_dismissed');
        if (window.UserCustomization) {
            UserCustomization.settings.showContinueWatching = true;
            UserCustomization.saveSettings();
        }
        const section = document.getElementById('continue-watching-section');
        if (section) {
            section.style.display = 'block';
            this.renderContinueWatching();
        }
        if (window.Toast) Toast.success('Devam Et bölümü tekrar gösterildi!');
    },

    // Get series user is currently watching with next episode
    getContinueWatchingSeries() {
        if (!State.currentUser) return [];

        const history = State.currentUser.watchHistory || [];
        const watchedEpisodes = State.currentUser.watchedEpisodes || {};

        // Use a Map to store unique series to prevent duplicates
        // Key: SeriesID, Value: Series Object
        const candidateSeriesIds = new Set();
        history.forEach(h => candidateSeriesIds.add(String(h.seriesId)));
        Object.keys(watchedEpisodes).forEach(id => candidateSeriesIds.add(id));

        const candidates = [];
        const processedSeriesIds = new Set(); // To double check duplicates

        for (const sId of candidateSeriesIds) {
            // Prevent processing the same series ID twice
            if (processedSeriesIds.has(sId)) continue;
            processedSeriesIds.add(sId);

            if (typeof db === 'undefined' || !db.getSeries) continue;

            const series = db.getSeries(sId);
            if (!series || !series.episodes || series.episodes.length === 0) continue;

            const seriesWatched = watchedEpisodes[sId] || [];

            // Sort episodes by number
            const sortedEpisodes = [...series.episodes].sort((a, b) => a.number - b.number);

            let nextEpisode = null;
            let progressPercent = 0;

            for (const ep of sortedEpisodes) {
                if (!seriesWatched.includes(ep.number)) {
                    nextEpisode = ep;
                    break;
                }
            }

            // If no next episode, series is finished
            if (!nextEpisode) continue;

            // Calculate progress
            progressPercent = Math.round((seriesWatched.length / sortedEpisodes.length) * 100);

            // Find last interaction time
            const historyEntry = history.find(h => String(h.seriesId) === sId);
            const lastWatchedAt = historyEntry ? historyEntry.watchedAt : 0;

            candidates.push({
                series: series,
                nextEpisode: nextEpisode,
                lastWatchedAt: lastWatchedAt,
                progress: progressPercent
            });
        }

        // Sort by most recently interacted
        candidates.sort((a, b) => b.lastWatchedAt - a.lastWatchedAt);

        return candidates;
    },

    renderContinueWatching() {
        const container = document.getElementById('continue-watching-grid');
        if (!container) return;

        // Check customization preference
        if (window.UserCustomization && UserCustomization.settings && UserCustomization.settings.showContinueWatching === false) {
            const section = document.getElementById('continue-watching-section');
            if (section) section.style.display = 'none';
            return;
        }

        const continueWatching = this.getContinueWatchingSeries();

        if (continueWatching.length === 0) {
            const section = document.getElementById('continue-watching-section');
            // If showContinueWatching is true but history is empty, show empty state or hide it gracefully.
            // Let's keep empty message inside grid.
            container.innerHTML = `
                <div style="text-align: center; padding: 40px 20px; width: 100%;">
                    <p style="color: var(--text-secondary); font-size: 1rem;">Takip ettiğiniz dizi yok.</p>
                </div>
            `;
            return;
        }

        const section = document.getElementById('continue-watching-section');
        if (section) section.style.display = 'block';

        container.innerHTML = continueWatching.map(item => {
            const nextEp = item.nextEpisode;
            const progress = item.progress || 0;
            // Prioritize landscape image (coverImage or backdrop) for landscape continue watching cards
            const bg = item.series.coverImage || item.series.backdrop || item.series.poster || 'assets/poster-placeholder.jpg';
            
            return `
                <div class="continue-card-premium" onclick="App.router('detail', '${item.series.id}')">
                    <div class="continue-poster-wrap">
                        <img src="${bg}" class="continue-poster" alt="${item.series.title}" loading="lazy">
                        <div class="continue-progress">
                            <div class="continue-progress-fill" style="width: ${progress}%"></div>
                        </div>
                        <div class="continue-ep-tag">Bölüm ${nextEp.number}</div>
                    </div>
                    <div class="continue-info">
                        <h3 class="continue-title">${item.series.title}</h3>
                        <p class="continue-ep-title">${nextEp.title || 'Sıradaki Bölüm'} • <span class="continue-progress-text">%${progress} İzlendi</span></p>
                        <div class="continue-actions">
                            <button class="continue-play-btn"><i class="fa-solid fa-play"></i> Kaldığın Yerden</button>
                            <button class="continue-check-btn" onclick="ContinueWatching.markAsWatched('${item.series.id}', ${nextEp.number}, event)" title="İzledim Olarak İşaretle">
                                <i class="fa-solid fa-check"></i>
                            </button>
                        </div>
                    </div>
                    <button class="continue-close-btn" onclick="ContinueWatching.removeFromContinueWatching('${item.series.id}', event)" title="Listeden Kaldır">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
            `;
        }).join('');
    },

    removeFromContinueWatching(seriesId, event) {
        if (event) event.stopPropagation();
        if (!confirm('Bu diziyi "Devam Et" listesinden kaldırmak istediğinize emin misiniz?')) return;

        if (State.currentUser) {
            // Remove from watchHistory
            if (State.currentUser.watchHistory) {
                State.currentUser.watchHistory = State.currentUser.watchHistory.filter(h => String(h.seriesId) !== String(seriesId));
            }
            // Remove from watchedEpisodes (optional, but keep it clean)
            if (State.currentUser.watchedEpisodes) {
                delete State.currentUser.watchedEpisodes[seriesId];
            }
            db.save();
            this.renderContinueWatching();
            Toast.success('Listeden kaldırıldı.');
        }
    },

    markAsWatched(seriesId, episodeNumber, event) {
        if (event) event.stopPropagation();

        if (typeof WatchTimeTracker !== 'undefined' && WatchTimeTracker.toggleEpisodeWatched) {
            WatchTimeTracker.toggleEpisodeWatched(seriesId, episodeNumber, event);
        } else {
            console.error('WatchTimeTracker not found');
            Toast.error('Bir hata oluştu.');
        }
    },

    calculateProgress(series, lastWatchedEpisode) {
        if (!series.episodes || series.episodes.length === 0) return 0;
        return Math.round((lastWatchedEpisode / series.episodes.length) * 100);
    },

    timeAgo(timestamp) {
        const seconds = Math.floor((Date.now() - timestamp) / 1000);

        if (seconds < 60) return 'Az önce';
        if (seconds < 3600) return Math.floor(seconds / 60) + ' dakika önce';
        if (seconds < 86400) return Math.floor(seconds / 3600) + ' saat önce';
        if (seconds < 604800) return Math.floor(seconds / 86400) + ' gün önce';

        return new Date(timestamp).toLocaleDateString('tr-TR');
    }
};

// Initialize
// Expose globally
window.ContinueWatching = ContinueWatching;

// Initialize if App is ready, otherwise wait
if (window.App && State.data) {
    ContinueWatching.init();
} else {
    document.addEventListener('AppReady', () => {
        ContinueWatching.init();
    });
}

console.log('✅ Continue Watching System Loaded!');
