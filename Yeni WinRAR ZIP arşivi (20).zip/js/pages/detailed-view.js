if (typeof window.DetailedView === 'undefined') {
    window.DetailedView = {
        async render(seriesIdOrObj, initialTab = 'episodes') {
        let series = typeof seriesIdOrObj === 'object' && seriesIdOrObj !== null ? seriesIdOrObj : null;
        const seriesId = series ? series.id : seriesIdOrObj;

        if (!series && db) {
            if (typeof db.ensureSeries === 'function') {
                series = await db.ensureSeries(seriesId);
            } else {
                if (typeof db.syncDatabaseFromJson === 'function') await db.syncDatabaseFromJson(seriesId);
                series = db.getSeries(seriesId);
            }
        }

        if (!series) {
            Toast.error('İçerik bulunamadı veya henüz yüklenmedi.');
            App.router('home');
            return;
        }

        // --- VISIBILITY CHECK ---
        if (typeof db.checkVisibility === 'function' && !db.checkVisibility(series)) {
            Toast.error("Bu içeriğe erişim izniniz yok! (Üye olmanız veya VIP olmanız gerekebilir)");
            App.router('home');
            return;
        }
        // ------------------------

        this.currentSeries = series;
        State.currentSeries = series;

        // --- DRAMI CONTEXT ---
        if (window.Drami) {
            Drami.setContext(series, null);
            Drami.renderElements();
        }
        // ---------------------

        document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');

        const legacyDetail = document.getElementById('new-detail-view');
        if (legacyDetail) legacyDetail.remove();

        const detailView = document.getElementById('detail-view');
        if (!detailView) {
            console.error('detail-view container not found');
            return;
        }
        detailView.style.display = 'block';

        document.body.classList.add('premium-theme');
        try {
            await this.createDetailStructure(series, initialTab);
        } catch (err) {
            console.error('Detail render error:', err);
            const detailView = document.getElementById('detail-view');
            if (detailView) {
                detailView.innerHTML = `
                    <div style="padding:120px 40px; text-align:center; color:#94a3b8;">
                        <i class="fa-solid fa-triangle-exclamation" style="font-size:3rem; color:#f59e0b; margin-bottom:20px;"></i>
                        <h2 style="color:#fff;">Sayfa yüklenirken hata oluştu</h2>
                        <p style="margin:15px 0 25px;">${err.message || 'Bilinmeyen hata'}</p>
                        <button class="btn btn-primary" onclick="DetailedView.render('${series.id}')">Tekrar Dene</button>
                        <button class="btn btn-outline" onclick="App.router('home')" style="margin-left:10px;">Ana Sayfa</button>
                    </div>`;
                detailView.style.display = 'block';
            }
        }
    },

    async createDetailStructure(series, activeTab = 'episodes') {
        const rating = this.getAverageRating(series.id) || series.rating || 4.5;

        // Calculate dynamic counts
        const allEpisodes = [];
        if (series.seasons) {
            series.seasons.forEach(s => {
                if (s.episodes) allEpisodes.push(...s.episodes);
            });
        } else if (series.episodes) {
            allEpisodes.push(...series.episodes);
        }
        const episodeCount = allEpisodes.length;

        let rawCast = series.cast || series.characters || [];
        if (typeof rawCast === 'string') {
            rawCast = rawCast.split(',').map(name => ({ name: name.trim(), character: 'Oyuncu' }));
        }
        const castList = rawCast.filter(c => c !== null && c !== undefined);
        const castCount = castList.length;

        const posts = State.data?.socialPosts || [];
        const reviewsCount = posts.filter(p => 
            p.isReview === true && 
            (p.sharedContent?.id === series.id || p.sharedContent?.seriesId === series.id)
        ).length;

        const commentsCount = (series.comments || []).length;

        const html = `
        <div class="detail-page-root view-fade-in" style="background: #07070a; min-height: 100vh; color: #f8fafc; padding-top: 0;">
            <!-- Premium Hero Backdrop Section -->
            <div class="premium-hero-backdrop">
                <div class="hero-backdrop-image-container">
                    <div class="hero-backdrop-image" style="background-image: url('${series.backdrop || series.poster}')"></div>
                </div>
                <div class="hero-overlay-cinematic"></div>
                
                <div class="detail-hero-container-modern" style="position: relative; z-index: 2; width: 100%; max-width: 1250px; margin: 0 auto; padding: 0 40px; display: grid; grid-template-columns: 320px 1fr; gap: 60px; align-items: end;">
                    <!-- LEFT: Modern Poster with Reflection -->
                    <div class="detail-poster-section-modern">
                        <div class="premium-poster-card">
                            <img id="d-poster" src="${series.poster}" class="detail-poster-large" alt="${series.title}" style="width: 100%; height: auto; display: block; aspect-ratio: 2/3; object-fit: cover;">
                            ${series.isVip ? '<div class="vip-tag-premium" style="position: absolute; top: 20px; right: 20px; background: linear-gradient(135deg, #ffd700, #ff8c00); color: black; padding: 6px 15px; border-radius: 20px; font-weight: 800; font-size: 0.8rem; box-shadow: 0 4px 15px rgba(255, 215, 0, 0.4);">VIP</div>' : ''}
                        </div>
                    </div>
                    
                    <!-- RIGHT: Cinematic Info Panel -->
                    <div class="detail-info-section-premium" style="padding-bottom: 20px;">
                        <div class="detail-meta-tags-modern" id="d-meta-tags" style="display: flex; gap: 12px; margin-bottom: 25px; flex-wrap: wrap;"></div>
                        
                        <h1 id="d-title" class="detail-title-cinematic" style="font-size: 4rem; font-weight: 900; line-height: 1.1; margin: 0 0 10px; background: linear-gradient(to bottom, #ffffff, #cbd5e1); -webkit-background-clip: text; -webkit-text-fill-color: transparent; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.4));">${series.title}</h1>
                        <div class="detail-original-title-sub" id="d-original-title" style="font-size: 1.4rem; color: #94a3b8; font-weight: 500; margin-bottom: 30px; opacity: 0.8; letter-spacing: 0.5px;">${series.originalTitle || ''}</div>
                                            <div style="display: flex; gap: 10px; margin-bottom: 20px;">
                            <span class="badge badge-accent">${series.status || 'Aktif'}</span>
                            <span class="badge badge-secondary"><i class="fa-solid fa-eye"></i> ${(series.views || 0).toLocaleString()} İzlenme</span>
                            ${series.isVip ? '<span class="badge" style="background: linear-gradient(135deg, #ffd700, #b8860b); color: #000; font-weight: 900;"><i class="fa-solid fa-crown"></i> VIP ÖZEL</span>' : ''}
                            ${series.isPrivate ? '<span class="badge" style="background: rgba(255,255,255,0.1); color: #94a3b8;"><i class="fa-solid fa-lock"></i> SADECE ÜYELERE</span>' : ''}
                        </div>
                        <div class="glass-panel" style="padding: 12px 25px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.1); display: flex; flex-direction: column; gap: 5px;">
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    <div id="d-rating-container" style="display: flex; gap: 6px; color: #fbbf24; font-size: 1.2rem;"></div>
                                    <div style="font-size: 1.1rem; color: #fff; font-weight: 800;">${rating} <small style="color:#64748b; font-weight:600;">/ 10</small></div>
                                </div>
                                <div id="d-user-rating-text" style="display:none; font-size:0.8rem; color:#a78bfa; font-weight:700; text-align:center; width:100%;"></div>
                            </div>
                            
                            <!-- Reaction Pills -->
                            <div class="glass-panel" style="display: flex; gap: 5px; padding: 8px 15px; border-radius: 50px; border: 1px solid rgba(255,255,255,0.1);">
                                <div class="reaction-item" onclick="DetailedView.react('🔥')" style="padding: 5px 12px;">🔥 <small id="react-count-fire" style="color:#94a3b8;">0</small></div>
                                <div class="reaction-item" onclick="DetailedView.react('❤️')" style="padding: 5px 12px;">❤️ <small id="react-count-heart" style="color:#94a3b8;">0</small></div>
                                <div class="reaction-item" onclick="DetailedView.react('😂')" style="padding: 5px 12px;">😂 <small id="react-count-lol" style="color:#94a3b8;">0</small></div>
                                <div class="reaction-item" onclick="DetailedView.react('😢')" style="padding: 5px 12px;">😢 <small id="react-count-sad" style="color:#94a3b8;">0</small></div>
                                <div class="reaction-item" onclick="DetailedView.react('😮')" style="padding: 5px 12px;">😮 <small id="react-count-wow" style="color:#94a3b8;">0</small></div>
                            </div>
                        </div>

                        <div id="d-description" class="glass-panel" style="font-size: 1.1rem; line-height: 1.8; color: #cbd5e1; margin-bottom: 35px; max-width: 850px; padding: 25px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.08);">${series.description || 'Açıklama yok.'}</div>
                        
                        <!-- Action Group -->
                        <div class="action-group" style="display: flex; gap: 15px; margin-top: 10px;">
                            <button id="action-play-btn" class="btn-premium-glow" style="background: linear-gradient(135deg, #8b5cf6, #ec4899); box-shadow: 0 10px 25px rgba(139, 92, 246, 0.4); padding: 15px 45px; font-size: 1.1rem;">
                                <i class="fa-solid fa-play"></i> Hemen İzle
                            </button>
                            <button id="action-list-btn" class="btn-premium-outline">
                                <i class="fa-solid fa-plus"></i> Listeme Ekle
                            </button>
                            <button id="action-share-btn" class="btn-premium-outline">
                                <i class="fa-solid fa-share-nodes"></i> Paylaş
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Content Area (Floating Pill Tabs) -->
            <div class="detail-content-wrapper-modern" style="max-width: 1200px; margin: 40px auto; padding: 0 40px;">
                <div class="detail-main-col">
                    <!-- Genre Pills -->
                    <div class="detail-genres-modern" id="d-genres" style="display: flex; gap: 10px; margin-bottom: 35px; flex-wrap: wrap;"></div>
                    
                    <!-- TAB SYSTEM (MODERN PILLS) -->
                    <div class="modern-tab-bar" id="detail-tabs" style="display: flex; gap: 8px; background: rgba(255,255,255,0.05); padding: 8px; border-radius: 50px; width: fit-content; margin-bottom: 40px; border: 1px solid rgba(255,255,255,0.05); backdrop-filter: blur(10px);">
                        <button class="modern-pill-tab active" data-tab="episodes" style="padding: 10px 30px; border-radius: 50px; border: none; background: transparent; color: #94a3b8; font-weight: 700; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Bölümler <span style="font-size:0.8rem; opacity:0.7; font-weight:500;">(${episodeCount})</span></button>
                        <button class="modern-pill-tab" data-tab="ost" id="tab-btn-ost" style="padding: 10px 30px; border-radius: 50px; border: none; background: transparent; color: #94a3b8; font-weight: 700; cursor: pointer; transition: all 0.3s; font-size: 0.95rem; display: none;">OST</button>
                        <button class="modern-pill-tab" data-tab="about" style="padding: 10px 30px; border-radius: 50px; border: none; background: transparent; color: #94a3b8; font-weight: 700; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Hakkında</button>
                        <button class="modern-pill-tab" data-tab="reviews" style="padding: 10px 30px; border-radius: 50px; border: none; background: transparent; color: #94a3b8; font-weight: 700; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">İncelemeler <span style="font-size:0.8rem; opacity:0.7; font-weight:500;">(${reviewsCount})</span></button>
                        <button class="modern-pill-tab" data-tab="cast" style="padding: 10px 30px; border-radius: 50px; border: none; background: transparent; color: #94a3b8; font-weight: 700; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Oyuncular <span style="font-size:0.8rem; opacity:0.7; font-weight:500;">(${castCount})</span></button>
                        <button class="modern-pill-tab" data-tab="fancenter" style="padding: 10px 30px; border-radius: 50px; border: none; background: transparent; color: #94a3b8; font-weight: 700; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Fan Merkezi <span class="badge-new" style="background:#ef4444; color:#fff; font-size:0.6rem; padding:2px 6px; border-radius:4px; margin-left:5px;">YENİ</span></button>
                        <button class="modern-pill-tab" data-tab="comments" style="padding: 10px 30px; border-radius: 50px; border: none; background: transparent; color: #94a3b8; font-weight: 700; cursor: pointer; transition: all 0.3s; font-size: 0.95rem;">Yorumlar <span style="font-size:0.8rem; opacity:0.7; font-weight:500;">(${commentsCount})</span></button>
                    </div>
                    
                    <!-- TAB CONTENTS -->
                    <div class="modern-tab-content-area" style="min-height: 400px;">
                        <div class="modern-tab-pane active" id="tab-episodes"></div>
                        <div class="modern-tab-pane" id="tab-ost" style="display: none;">
                            <div id="ost-grid" class="ost-modern-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px;"></div>
                        </div>
                        <div class="modern-tab-pane" id="tab-about" style="display: none;">
                            <h3 style="margin-bottom: 20px; font-size: 1.5rem; font-weight: 800;">Hikaye</h3>
                            <p id="d-full-description" style="color: #94a3b8; line-height: 1.8; font-size: 1.1rem; text-align: justify;"></p>
                            <div class="detail-info-content" style="margin-top: 40px; display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;"></div>
                        </div>
                        <div class="modern-tab-pane" id="tab-reviews" style="display: none;">
                            <div id="reviews-grid" style="display: grid; grid-template-columns: 1fr; gap: 20px;">
                                <div style="text-align: center; padding: 40px; color: #64748b;">
                                    <i class="fa-solid fa-spinner fa-spin" style="font-size: 2rem; margin-bottom: 10px;"></i>
                                    <p>İncelemeler yükleniyor...</p>
                                </div>
                            </div>
                        </div>
                        <div class="modern-tab-pane" id="tab-cast" style="display: none;">
                            <div class="cast-grid" id="d-cast-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 25px;"></div>
                        </div>
                        <div class="modern-tab-pane" id="tab-fancenter" style="display: none;">
                            <div id="d-fancenter-root"></div>
                        </div>
                        <div class="modern-tab-pane" id="tab-comments" style="display: none;">
                            <div id="detail-comments-container"></div>
                        </div>
                    </div>
                </div>

                <!-- Custom Styling for Modern Elements -->
                <style>
                    .modern-pill-tab.active {
                        background: rgba(255, 255, 255, 0.1) !important;
                        color: white !important;
                        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                    }
                    .modern-pill-tab:hover:not(.active) {
                        background: rgba(255, 255, 255, 0.05);
                        color: #e2e8f0;
                    }
                    .modern-btn-primary:hover {
                        transform: translateY(-3px);
                        box-shadow: 0 15px 35px rgba(124, 58, 237, 0.5);
                        background: linear-gradient(135deg, #8b5cf6, #7c3aed);
                    }
                    .modern-btn-glass:hover {
                        background: rgba(255,255,255,0.15);
                        transform: translateY(-3px);
                    }
                    .modern-btn-icon {
                        width: 50px; 
                        height: 50px; 
                        border-radius: 50%; 
                        background: rgba(255,255,255,0.1); 
                        color: white; 
                        border: 1px solid rgba(255,255,255,0.1); 
                        display: flex; 
                        align-items: center; 
                        justify-content: center; 
                        cursor: pointer; 
                        transition: all 0.3s;
                    }
                    .modern-btn-icon:hover {
                        background: rgba(255,255,255,0.2);
                        transform: translateY(-3px) scale(1.05);
                    }
                    .detail-poster-section-modern:hover .modern-poster-frame {
                        transform: perspective(1000px) rotateY(0deg) scale(1.02);
                        box-shadow: 0 35px 60px -15px rgba(124, 58, 237, 0.3);
                    }
                    
                    @media (max-width: 1000px) {
                        .detail-hero-container-modern { grid-template-columns: 1fr !important; text-align: center; padding: 0 20px !important; gap: 30px !important; }
                        .detail-poster-section-modern { display: flex; justify-content: center; margin-bottom: 0px; }
                        .premium-poster-card { width: 220px; max-width: 100%; margin: 0 auto; border-radius: 16px; overflow: hidden; }
                        .detail-title-cinematic { font-size: 2.2rem !important; }
                        .detail-action-group-modern { justify-content: center; }
                        .modern-tab-bar { margin: 0 auto 30px auto; flex-wrap: wrap; justify-content: center; border-radius: 20px !important; }
                        .detail-meta-tags-modern { justify-content: center; }
                        #d-description { margin: 0 auto 35px auto; text-align: center; }
                        .modern-pill-tab { padding: 8px 15px !important; font-size: 0.85rem !important; }
                    }
                </style>

                <!-- Top 3 Premium Reviews Section -->
                <div class="top-reviews-section" id="top-reviews-container" style="margin-top: 40px; padding: 0 20px; max-width: 1200px; margin-left: auto; margin-right: auto; display: none;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:25px;">
                        <h3 style="margin:0; font-size:1.5rem; font-weight:800; color: #fff; display:flex; align-items:center;">
                            <i class="fa-solid fa-star-half-stroke" style="color: #fbbf24; margin-right: 12px; filter: drop-shadow(0 0 10px rgba(251,191,36,0.3));"></i>
                            En Beğenilen İncelemeler
                        </h3>
                        <button class="btn btn-outline btn-sm" onclick="DetailedView.switchTab('reviews')" style="border-radius:20px; padding:6px 18px; font-size:0.8rem;">Tümünü Gör</button>
                    </div>
                    <div class="top-reviews-grid" id="top-reviews-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 20px;"></div>
                </div>

                <!-- SIMILAR SERIES RECOMENDATIONS -->
                <div class="similar-series-section" id="similar-series-container" style="margin-top: 50px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 30px; padding-bottom: 50px; display: none;">
                    <h3 style="margin-bottom: 20px; font-size: 1.2rem; color: #e2e8f0; display:flex; align-items:center;">
                        <i class="fa-solid fa-wand-magic-sparkles" style="color: var(--accent-color); margin-right: 10px;"></i>
                        Bunu İzleyenler Bunları da Beğendi
                    </h3>
                    <div class="similar-scroll-wrapper" style="overflow-x: auto; padding-bottom: 20px;">
                        <div class="similar-grid" id="similar-list" style="display: flex; gap: 15px;">
                            <!-- Items Injected Here -->
                        </div>
                    </div>
                </div>
            </div>
        `;

        const detailView = document.getElementById('detail-view');
        if (!detailView) return;
        detailView.innerHTML = html;
        detailView.style.display = 'block';


        // --- POPULATE DATA ---

        // Images
        const coverImage = series.poster || series.coverImage || 'https://via.placeholder.com/300x450?text=No+Image';
        document.getElementById('d-poster').src = coverImage;

        // Meta Tags
        const metaContainer = document.getElementById('d-meta-tags');
        if (metaContainer) {
            const views = series.views || 0;
            const avgRating = this.getAverageRating(series.id) || series.rating || 0;
            const ageRating = series.ageRating || 'Genel';
            const ageClass = (ageRating === '18+' || ageRating === '21+') ? 'age-mature' : 'age-safe';
            
            const allEpisodes = [];
            if (series.seasons) {
                series.seasons.forEach(s => {
                    if (s.episodes) allEpisodes.push(...s.episodes);
                });
            } else if (series.episodes) {
                allEpisodes.push(...series.episodes);
            }
            
            let metaHtml = `
                <span class="detail-tag">${series.year}</span>
                <span class="detail-tag">${this.getFlag(series.country)} ${series.country || "Kore"}</span>
                <span class="detail-tag age-badge ${ageClass}">${ageRating}</span>
                <span class="detail-tag">${this.getStatusText(series.status)}</span>
                ${series.totalEpisodes ? `<span class="detail-tag" title="Planlanan Toplam Bölüm"><i class="fa-solid fa-layer-group"></i> ${allEpisodes.length} / ${series.totalEpisodes} Mevcut</span>` : `<span class="detail-tag"><i class="fa-solid fa-layer-group"></i> ${allEpisodes.length} Bölüm</span>`}
                <span class="detail-tag" title="Görüntülenme"><i class="fa-solid fa-eye"></i> <span id="detail-view-count">${this.formatNumber(views)}</span></span>
                <span class="detail-tag" style="background: rgba(255, 215, 0, 0.2); color: #ffd700; border-color: rgba(255, 215, 0, 0.3);">
                    <i class="fa-solid fa-star" style="margin-right:5px;"></i> ${avgRating > 0 ? avgRating : '0.0'}
                </span>
            `;
            metaContainer.innerHTML = metaHtml;
        }

        // --- AD INJECTION ---
        this.injectAds();


        // Texts
        document.getElementById('d-title').textContent = series.title;
        const koreanOrOriginal = series.koreanTitle || series.originalTitle || '';
        document.getElementById('d-original-title').textContent = koreanOrOriginal;
        document.getElementById('d-description').textContent = series.description || 'Açıklama bulunmuyor.';
        document.getElementById('d-full-description').textContent = series.description || 'Açıklama bulunmuyor.';

        // Genres & Hashtags
        const genresContainer = document.getElementById('d-genres');
        const genres = series.genres || series.genre || [];
        const hashtags = series.hashtags || [];
        const genreList = Array.isArray(genres) ? genres : genres.split(',');
        
        let tagsHtml = genreList.map(g => `<span class="genre-badge">${g}</span>`).join('');
        tagsHtml += hashtags.map(h => `<span class="hashtag-badge" onclick="DetailedView.searchByHashtag('${h}')" style="cursor:pointer; background:rgba(124,58,237,0.1); color:#a78bfa; border:1px solid rgba(124,58,237,0.2); padding:4px 12px; border-radius:20px; font-size:0.8rem; font-weight:700;">${h}</span>`).join('');
        
        if (genresContainer) genresContainer.innerHTML = tagsHtml;

        // --- PREPARE CREATOR INFO ---
        const creatorId = series.episodes?.[0]?.sources?.[0]?.addedBy ||
            series.seasons?.[0]?.episodes?.[0]?.sources?.[0]?.addedBy || 'admin';
        const translatorName = series.translator || 'Çevirmen Ekibi';

        // Action Buttons
        const isWebtoon = series.type === 'webtoon';
        
        

        const episodeHasSource = (ep) => {
            if (ep.sources?.length) return ep.sources.some(s => s?.url);
            return !!(ep.videoUrl || ep.url);
        };
        const hasPlayableEpisodes = allEpisodes.some(episodeHasSource);
        const firstPlayableIdx = allEpisodes.findIndex(episodeHasSource);
        const hasEpisodes = allEpisodes.length > 0;
        
        let actionIcon = isWebtoon ? 'fa-book-open' : 'fa-play';
        let actionText = isWebtoon ? 'İlk Bölümü Oku' : 'İlk Bölümü İzle';
        let resumeIndex = firstPlayableIdx >= 0 ? firstPlayableIdx : 0;

        if (State.currentUser && State.currentUser.watchedEpisodes && State.currentUser.watchedEpisodes[series.id]) {
            const watched = State.currentUser.watchedEpisodes[series.id];
            if (watched.length > 0) {
                actionText = isWebtoon ? 'Kaldığın Yerden Oku' : 'Kaldığın Yerden İzle';
                const watchedIdx = Math.min(watched.length, allEpisodes.length - 1);
                resumeIndex = episodeHasSource(allEpisodes[watchedIdx]) ? watchedIdx : (firstPlayableIdx >= 0 ? firstPlayableIdx : 0);
            }
        }

        if (!hasPlayableEpisodes) {
            actionText = 'Yakında';
            actionIcon = 'fa-clock';
        }

        const playBtn = document.getElementById('action-play-btn');
        this.renderSourcePreview(series, allEpisodes, hasPlayableEpisodes);

        const isAdmin = State.currentUser && (State.currentUser.role === 'admin' || State.currentUser.badges?.includes('Admin') || State.currentUser.badges?.includes('Yönetici'));
        if (isAdmin) {
            const actionGroup = document.querySelector('#detail-view .action-group');
            if (actionGroup && !document.getElementById('detail-admin-edit-btn')) {
                const editBtn = document.createElement('button');
                editBtn.id = 'detail-admin-edit-btn';
                editBtn.className = 'btn-premium-outline';
                editBtn.innerHTML = '<i class="fa-solid fa-pen"></i> Düzenle';
                editBtn.onclick = () => App.router('edit-series', series.id);
                actionGroup.appendChild(editBtn);
            }
        }

        if (playBtn) {
            playBtn.innerHTML = `<i class="fa-solid ${actionIcon}"></i> ${actionText}`;
            if (!hasPlayableEpisodes) {
                playBtn.disabled = true;
                playBtn.style.opacity = '0.65';
                playBtn.style.cursor = 'not-allowed';
            } else {
                playBtn.disabled = false;
                playBtn.style.opacity = '';
                playBtn.style.cursor = '';
            }
            playBtn.onclick = () => {
                if (!hasPlayableEpisodes) {
                    Toast.warning('Kaynak bulunamadı. Bu bölüm henüz yüklenmedi.');
                    return;
                }
                
                const startContent = () => {
                    if (isWebtoon) {
                        App.router('reader', series.id, resumeIndex);
                    } else {
                        App.router('player', series.id, resumeIndex);
                    }
                };

                const ageRating = series.ageRating || 'Genel';
                if (ageRating === '18+' || ageRating === '21+') {
                    this.showMatureDisclaimer(ageRating, startContent);
                    return;
                }

                if (typeof AdService !== 'undefined' && AdService.shouldShowAds()) {
                    AdService.showPreRoll(startContent);
                } else {
                    startContent();
                }
            };
        }

        // Watchlist Button
        const isInWatchlist = State.currentUser && State.currentUser.watchlist && State.currentUser.watchlist.includes(series.id);
        const watchlistBtn = document.getElementById('action-list-btn');
        if (watchlistBtn) {
            watchlistBtn.innerHTML = isInWatchlist ? '<i class="fa-solid fa-check"></i> Listeden Çıkar' : '<i class="fa-solid fa-plus"></i> Listeme Ekle';
            if (isInWatchlist) watchlistBtn.classList.add('active');
            watchlistBtn.onclick = () => DetailedView.toggleWatchlist(watchlistBtn, series.id);
        }

        // Share Button
        const shareBtn = document.getElementById('action-share-btn');
        if (shareBtn) shareBtn.onclick = () => DetailedView.shareSeries(series.title);

        // Rating
        const userRating = this.getUserRating(series.id);
        const ratingContainer = document.getElementById('d-rating-container');
        if (ratingContainer) ratingContainer.innerHTML = this.renderStars(userRating);

        // --- NEW: CREATOR GOAL BAR (Local State) ---
        const creatorData = State.data.users?.find(u => u.id === creatorId);
        if (creatorData && creatorData.stats?.goal) {
            const goal = creatorData.stats.goal;
            const goalHtml = `
                <div class="creator-goal-box" style="margin-top: 15px; background: rgba(255, 215, 0, 0.05); border: 1px solid rgba(255, 215, 0, 0.2); padding: 12px; border-radius: 12px;">
                    <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 8px;">
                        <span style="color: #ffd700;"><i class="fa-solid fa-bullseye"></i> ${goal.title}</span>
                        <span style="color: #fff;">${goal.current} / ${goal.target} Coin</span>
                    </div>
                    <div style="height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; overflow: hidden;">
                        <div style="width: ${Math.min(100, (goal.current / goal.target) * 100)}%; height: 100%; background: linear-gradient(90deg, #ffd700, #ff8c00); box-shadow: 0 0 10px rgba(255,215,0,0.3);"></div>
                    </div>
                </div>
            `;
            const container = document.querySelector('.detail-info-content');
            if (container) container.insertAdjacentHTML('beforeend', goalHtml);
        }
        // --- NEW: TRANSLATOR & CREATOR INFO ---
        const translatorSection = `
            <div class="translator-box-premium" style="margin-top: 15px; background: rgba(139, 92, 246, 0.05); border: 1px solid rgba(139, 92, 246, 0.2); padding: 15px; border-radius: 16px; display: flex; align-items: center; gap: 15px;">
                <div style="width: 45px; height: 45px; border-radius: 50%; background: var(--ultra-accent); display: flex; align-items: center; justify-content: center; color: white;">
                    <i class="fa-solid fa-language" style="font-size: 1.2rem;"></i>
                </div>
                <div>
                    <div style="font-size: 0.75rem; color: #a78bfa; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">Çeviri & Edit</div>
                    <div style="font-size: 1rem; color: #fff; font-weight: 800;">${series.translator || 'Dramicbox Ekibi'}</div>
                </div>
            </div>
        `;
        
        const infoContent = document.querySelector('.detail-info-section-premium');
        if (infoContent) {
            infoContent.insertAdjacentHTML('beforeend', translatorSection);
        }

        if (userRating > 0) {
            const ratingText = document.getElementById('d-user-rating-text');
            if (ratingText) {
                ratingText.style.display = 'block';
                ratingText.textContent = `Puanınız: ${userRating}/10`;
            }
        }

        // --- TABS & CONTENT ---

        // Cast
        const castContainer = document.getElementById('d-cast-grid');
        

        if (castList.length > 0) {
            castContainer.innerHTML = castList.map(c => {
                const name = typeof c === 'string' ? c : (c.name || c.actor || c.originalName || 'İsimsiz');
                const role = typeof c === 'string' ? 'Oyuncu' : (c.character || c.role || 'Oyuncu');
                const roleType = typeof c === 'string' ? 'main' : (c.roleType || 'main');
                const roleTypeLabel = roleType === 'main' ? 'Başrol' : (roleType === 'support' ? 'Yan Rol' : 'Konuk');
                
                const globalActor = (State.data.actors || []).find(a => a.id === (c.id || '') || a.name === name);
                const actorRouteKey = globalActor?.id || (typeof c === 'object' ? c.id : null) || name;
                const image = (typeof c === 'object' ? c.image : null) || globalActor?.avatar || 'assets/logo.png';
                const koreanName = (typeof c === 'object' ? c.koreanName : null) || globalActor?.koreanName || '';
                const height = (typeof c === 'object' ? c.height : null) || globalActor?.height || '';
                const weight = (typeof c === 'object' ? c.weight : null) || globalActor?.weight || '';

                return `
                <div class="cast-card-modern" onclick="App.router('actor-detail', '${encodeURIComponent(actorRouteKey)}');" 
                     style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 15px; text-align: center; transition: 0.3s; cursor: pointer; position: relative; overflow: hidden;">
                    <div style="position: absolute; top: 10px; right: 10px; font-size: 0.65rem; background: var(--premium-violet-glow); color: white; padding: 2px 8px; border-radius: 10px; font-weight: 700; text-transform: uppercase;">${roleTypeLabel}</div>
                    <div style="width: 100px; height: 100px; margin: 0 auto 12px auto; overflow: hidden; border-radius: 50%; border: 2px solid var(--premium-violet-glow);">
                        <img src="${image}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='assets/logo.png'">
                    </div>
                    <div style="font-weight: 800; color: #fff; font-size: 1rem; margin-bottom: 3px;">${name}</div>
                    ${koreanName ? `<div style="font-size: 0.8rem; color: #a78bfa; margin-bottom: 5px; font-family: 'Noto Sans KR', sans-serif;">${koreanName}</div>` : ''}
                    <div style="font-size: 0.8rem; color: #94a3b8; font-weight: 500;">${role}</div>
                    ${height ? `<div style="font-size: 0.7rem; color: var(--premium-violet); margin-top: 5px; font-weight: 700;">${height}cm • ${weight}kg</div>` : ''}
                    <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); DetailedView.switchTab('fancenter', '${series.title.replace(/'/g, "\\'")}', '${series.type}', '${series.year}', '${series.id}')" style="margin-top: 10px; font-size: 0.7rem; border-radius: 20px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; border:none;">Fan Merkezi</button>
                </div>
            `}).join('');
        } else {
            castContainer.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; padding: 50px; color: #64748b;">
                    <i class="fa-solid fa-users-slash" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                    <p>Oyuncu bilgisi bulunmuyor.</p>
                </div>
            `;
        }

        // Episodes - Inject directly into the tab content
        const episodeTabContent = document.getElementById('tab-episodes');
        if (episodeTabContent) {
            episodeTabContent.innerHTML = `
                <div style="display: flex; justify-content: flex-end; margin-bottom: 15px;">
                    <button class="btn btn-sm btn-outline" onclick="DetailedView.refreshEpisodes('${series.id}')" style="font-size: 0.75rem; border-radius: 20px; padding: 5px 15px;">
                        <i class="fa-solid fa-rotate"></i> Verileri Yenile
                    </button>
                </div>
                ${this.renderEpisodeList(series)}
            `;
        }

        // Tabs Logic
        const tabs = document.querySelectorAll('#detail-tabs .modern-pill-tab');
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.tab;

                // UI Toggle
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');

                document.querySelectorAll('.modern-tab-pane').forEach(c => c.style.display = 'none');
                document.getElementById(`tab-${tabName}`).style.display = 'block';

                // Logic sync
                this.switchTab(tabName, series.title, series.type, series.year, series.id);
            });
        });

        // Activate Initial Tab
        if (activeTab !== 'episodes') {
            const initialTabBtn = document.querySelector(`#detail-tabs .modern-pill-tab[data-tab="${activeTab}"]`);
            if (initialTabBtn) initialTabBtn.click();
        }

        // Initialize comments
        if (typeof EnhancedComments !== 'undefined') EnhancedComments.displayComments(series, 'detail-comments-container');

        // Start REAL view counter
        this.startViewCounter(series.id);

        // Render Recommendations
        this.renderRecommendations(series);

        // Render Top 3 Liked Reviews
        this.renderTopReviews(series.id);

        // --- OST RENDER ---
        if (series.ost && series.ost.length > 0) {
            const ostTabBtn = document.getElementById('tab-btn-ost');
            const ostGrid = document.getElementById('ost-grid');
            if (ostTabBtn) ostTabBtn.style.display = 'block';
            if (ostGrid) {
                ostGrid.innerHTML = series.ost.map(id => `
                    <div class="ost-item" style="background: rgba(255,255,255,0.03); padding: 5px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                        <iframe width="100%" height="200" src="https://www.youtube.com/embed/${id}" frameborder="0" allowfullscreen style="border-radius: 10px;"></iframe>
                    </div>
                `).join('');
            }
        }

        // --- REACTION INITIALIZATION ---
        this.initReactions(series.id);
    },

    injectAds() {
        const ads = db.getAds('home_top'); // Reuse for detail top
        if (ads.length > 0) {
            const ad = ads[0];
            const adHtml = `
                <div class="detail-ad-banner" style="margin-bottom:20px; border-radius:12px; overflow:hidden; border:1px solid rgba(255,255,255,0.05);">
                    <a href="${ad.linkUrl}" target="_blank">
                        <img src="${ad.imageUrl}" style="width:100%; display:block;">
                    </a>
                </div>
            `;
            const header = document.querySelector('.detail-info-section-premium');
            if (header) header.insertAdjacentHTML('afterbegin', adHtml);
        }
    },

    showMatureDisclaimer(rating, onConfirm) {
        const user = State.currentUser;
        if (!user || user.role === 'guest') {
            return Toast.warning('Mature içerikleri izlemek için giriş yapmalısınız.');
        }

        // Check if user has birth date
        if (!user.birthDate) {
            this.showBirthDateModal(rating, onConfirm);
            return;
        }

        // Check age
        const birthDate = new Date(user.birthDate);
        const age = new Date().getFullYear() - birthDate.getFullYear();
        const requiredAge = parseInt(rating);
        
        if (age < requiredAge) {
            return Toast.error(`Bu içerik ${rating} yaş ve üzeridir. İzleme yetkiniz yok.`);
        }

        // Show Disclaimer Modal
        const modal = document.getElementById('m-hub-modal'); // Generic modal
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width:500px; text-align:center;">
                <div style="font-size:3rem; color:#ef4444; margin-bottom:20px;"><i class="fa-solid fa-triangle-exclamation"></i></div>
                <h2 style="color:#fff; margin-bottom:15px;">Sorumluluk Reddi ve Uyarı</h2>
                <p style="color:#94a3b8; line-height:1.6; margin-bottom:25px;">
                    Bu içerik <b>${rating}</b> yaş altı izleyiciler için uygun olmayan temalar, dil veya görüntüler içerebilir. 
                    Devam ederek tüm sorumluluğu üstlendiğinizi ve yasal yaş sınırında olduğunuzu beyan edersiniz.
                </p>
                <div style="display:grid; gap:10px;">
                    <button class="btn btn-primary" onclick="DetailedView.confirmMatureContent()">Onaylıyorum ve Devam Et</button>
                    <button class="btn btn-secondary" onclick="ManagementHub.closeModal()">Vazgeç</button>
                </div>
            </div>
        `;
        modal.style.display = 'flex';
        this._matureCallback = onConfirm;
    },

    confirmMatureContent() {
        document.getElementById('m-hub-modal').style.display = 'none';
        if (this._matureCallback) this._matureCallback();
    },

    showBirthDateModal(rating, onConfirm) {
        const modal = document.getElementById('m-hub-modal');
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width:400px; text-align:center;">
                <h2 style="color:#fff; margin-bottom:15px;">Yaş Doğrulaması</h2>
                <p style="color:#94a3b8; margin-bottom:20px;">Mature içeriklere erişmek için doğum tarihinizi girmeniz gerekmektedir. Bu tarih daha sonra <b>değiştirilemez</b>.</p>
                <div class="form-group">
                    <input type="date" id="verify-birth-date" class="form-input" style="width:100%;">
                </div>
                <button class="btn btn-primary btn-block" onclick="DetailedView.verifyAge('${rating}')">Doğrula ve Kaydet</button>
            </div>
        `;
        modal.style.display = 'flex';
        this._matureCallback = onConfirm;
    },

    async verifyAge(rating) {
        const dateStr = document.getElementById('verify-birth-date').value;
        if (!dateStr) return Toast.warning('Lütfen bir tarih seçin.');
        
        const success = await db.saveUserBirthDate(State.currentUser.id, dateStr);
        if (success) {
            Toast.success('Doğum tarihiniz kaydedildi.');
            ManagementHub.closeModal();
            this.showMatureDisclaimer(rating, this._matureCallback);
        } else {
            Toast.error('Tarih kaydedilemedi.');
        }
    },


    initReactions(seriesId) {
        // Simulating reaction counts using localStorage or global state
        const reactions = JSON.parse(localStorage.getItem(`reactions_${seriesId}`) || '{"🔥":0, "❤️":0, "😂":0, "😢":0, "😮":0}');
        
        const setReaction = (id, count) => {
            const el = document.getElementById(id);
            if (el) el.textContent = count || 0;
        };

        setReaction('react-count-fire', reactions['🔥']);
        setReaction('react-count-heart', reactions['❤️']);
        setReaction('react-count-lol', reactions['😂']);
        setReaction('react-count-sad', reactions['😢']);
        setReaction('react-count-wow', reactions['😮']);
    },

    async react(emoji) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Reaksiyon göstermek için giriş yapmalısınız!');
            return;
        }

        const seriesId = this.currentSeries.id;
        
        // Use syncAction to persist in MySQL
        const res = await db.syncAction('social-toggle-reaction', { 
            postId: seriesId, 
            emoji: emoji 
        });

        if (res.success || res.localOnly) {
            Toast.success(`${emoji} Reaksiyonunuz iletildi!`);
            this.initReactions(seriesId); // Refresh UI
            if (typeof Gamification !== 'undefined') Gamification.addXP(2, 'Reaksiyon');
        }
    },

    renderTopReviews(seriesId) {
        const container = document.getElementById('top-reviews-container');
        const grid = document.getElementById('top-reviews-grid');
        if (!container || !grid) return;

        const posts = State.data.socialPosts || [];
        const reviews = posts.filter(p => 
            p.isReview === true && 
            (p.sharedContent?.id === seriesId || p.sharedContent?.seriesId === seriesId)
        );

        if (reviews.length === 0) return;

        container.style.display = 'block';
        const top3 = reviews
            .sort((a, b) => (b.likes?.length || 0) - (a.likes?.length || 0))
            .slice(0, 3);

        grid.innerHTML = top3.map(post => this.renderReviewCard(post)).join('');
    },

    renderRecommendations(currentSeries) {
        const container = document.getElementById('similar-series-container');
        const list = document.getElementById('similar-list');
        if (!container || !list) return;

        // Smart Recommendation Logic
        const getGenreArray = (item) => {
            if (Array.isArray(item.genres)) return item.genres;
            if (Array.isArray(item.genre)) return item.genre;
            if (typeof item.genre === 'string') return item.genre.split(',').map(g => g.trim());
            if (typeof item.genres === 'string') return item.genres.split(',').map(g => g.trim());
            return [];
        };
        const currentGenres = getGenreArray(currentSeries);

        let candidates = State.data.series.filter(s => s.id !== currentSeries.id);

        candidates = candidates.map(s => {
            let score = 0;
            const sGenres = getGenreArray(s);

            const overlap = sGenres.filter(g => currentGenres.includes(g)).length;
            score += overlap * 2;

            if (s.country === currentSeries.country) score += 1;

            const rating = this.getAverageRating(s.id);
            if (rating > 8) score += 1;

            return { ...s, score };
        });

        const similar = candidates
            .filter(s => s.score > 0)
            .sort((a, b) => b.score - a.score)
            .slice(0, 10);

        if (similar.length === 0) return;

        container.style.display = 'block';
        list.innerHTML = similar.map(s => `
            <div class="similar-card" style="min-width: 140px; width: 140px; cursor: pointer;" onclick="App.navigate('detail', '${s.id}')">
                <div style="position: relative; border-radius: 8px; overflow: hidden; aspect-ratio: 2/3; margin-bottom: 8px;">
                    <img src="${s.poster}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
                    <div style="position: absolute; top: 5px; right: 5px; background: rgba(0,0,0,0.7); color: #ffd700; font-size: 0.7rem; padding: 2px 4px; border-radius: 4px; font-weight: bold;">
                        <i class="fa-solid fa-star"></i> ${this.getAverageRating(s.id) || 'N/A'}
                    </div>
                </div>
                <div style="font-size: 0.85rem; font-weight: 600; color: white; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${s.title}</div>
            </div>
        `).join('');
    },

    renderEpisodeList(series) {
        if (!series) return '';

        let seasons = [];
        if (series.seasons && series.seasons.length > 0) {
            seasons = series.seasons;
        } else {
            seasons = [{ number: 1, episodes: series.episodes || [] }];
        }

        let html = `
            <div class="modern-episode-container-v2" style="padding-top: 10px;">
                <div class="season-selector-bar" style="display: flex; gap: 10px; margin-bottom: 25px; overflow-x: auto; padding-bottom: 10px;">
                    ${seasons.map((s, idx) => `
                        <button class="season-pill-btn ${idx === 0 ? 'active' : ''}" 
                                onclick="DetailedView.switchSeasonView(this, ${s.number})"
                                style="padding: 8px 20px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.1); background: rgba(255,255,255,0.05); color: #94a3b8; font-weight: 600; cursor: pointer; white-space: nowrap; transition: all 0.3s;">
                            ${s.name || s.number + '. Sezon'}
                        </button>
                    `).join('')}
                </div>
                
                <div class="modern-episode-list-v2" style="display: flex; flex-direction: column; gap: 12px;">
        `;

        seasons.forEach((season, sIdx) => {
            html += `<div class="season-group season-${season.number}" style="display: ${sIdx === 0 ? 'grid' : 'none'}; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 15px;">`;

            if (season.episodes && season.episodes.length > 0) {
                season.episodes.forEach((ep) => {
                    const isWatched = State.currentUser?.watchedEpisodes?.[series.id]?.includes(ep.number);
                    const thumb = ep.image || series.coverImage || series.poster || 'assets/poster-placeholder.jpg';
                    const epAge = ep.ageRating || series.ageRating || '';
                    const transStatus = (ep.progress !== undefined && ep.progress < 100) ? `%${ep.progress}` : '';
                    const canWatch = db.checkVisibility(ep);

                    html += `
                        <div class="episode-item-modern ${isWatched ? 'watched' : ''} ${!canWatch ? 'locked' : ''}" 
                             onclick="${canWatch ? `DetailedView.playEpisode('${series.id}', ${season.number}, ${ep.number})` : `Toast.warning('Bu bölüm VIP üyelere özeldir!')`}"
                             style="display: flex; gap: 15px; background: rgba(255,255,255,0.03); padding: 12px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.05); cursor: pointer; transition: all 0.3s; position: relative; overflow: hidden;">
                            <div class="episode-thumb-modern" style="width: 110px; height: 62px; border-radius: 10px; overflow: hidden; flex-shrink: 0; position: relative;">
                                <img src="${thumb}" alt="Bölüm ${ep.number}" style="width: 100%; height: 100%; object-fit: cover; ${!canWatch ? 'filter: blur(4px) brightness(0.5);' : ''}">
                                <div class="play-icon-overlay" style="position: absolute; inset: 0; background: rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.3s;">
                                    <i class="fa-solid ${canWatch ? 'fa-play' : 'fa-lock'}" style="color: white; font-size: 1rem;"></i>
                                </div>
                                ${ep.isVip ? '<div style="position: absolute; top: 3px; right: 3px; background: #ffd700; color: black; font-size: 0.55rem; font-weight: 800; padding: 2px 4px; border-radius: 4px; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"><i class="fa-solid fa-crown" style="font-size:0.5rem;"></i> VIP</div>' : ''}
                            </div>
                            <div class="episode-info-modern" style="flex-grow: 1; display: flex; flex-direction: column; justify-content: center;">
                                <div style="font-weight: 700; color: #f1f5f9; font-size: 0.9rem; margin-bottom: 2px;">Bölüm ${ep.number}</div>
                                <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                                    ${epAge ? `<span style="font-size: 0.65rem; color: #ef4444; background: rgba(239, 68, 68, 0.1); padding: 1px 5px; border-radius: 4px; font-weight: 700;">${epAge}</span>` : ''}
                                    ${transStatus ? `<span style="font-size: 0.65rem; color: #60a5fa; background: rgba(96, 165, 250, 0.1); padding: 1px 5px; border-radius: 4px; font-weight: 700;">${transStatus}</span>` : ''}
                                    ${(!ep.sources || ep.sources.length === 0) ? '<span style="font-size: 0.65rem; color: #f59e0b; background: rgba(245, 158, 11, 0.1); padding: 1px 5px; border-radius: 4px; font-weight: 700;">YAKINDA</span>' : ''}
                                </div>
                            </div>
                            <div class="episode-status-modern" style="display: flex; align-items: center; color: ${isWatched ? '#10b981' : '#475569'}; font-size: 0.8rem;">
                                ${!canWatch ? '<i class="fa-solid fa-lock" style="color:#ffd700;"></i>' : '<i class="fa-solid fa-chevron-right"></i>'}
                            </div>
                        </div>
                    `;
                });
            } else {
                html += `<div style="grid-column: 1 / -1; padding: 40px; text-align: center; color: #64748b;">Bu sezonda henüz bölüm bulunmuyor.</div>`;
            }
            html += `</div>`;
        });

        html += `
                </div>
            </div>
            <style>
                .season-pill-btn.active {
                    background: #7c3aed !important;
                    color: white !important;
                    border-color: #7c3aed !important;
                    box-shadow: 0 4px 15px rgba(124, 58, 237, 0.3);
                }
                .episode-item-modern:hover {
                    background: rgba(255,255,255,0.08) !important;
                    border-color: rgba(124, 58, 237, 0.3) !important;
                    transform: translateX(5px);
                }
                .episode-item-modern:hover .play-icon-overlay {
                    opacity: 1 !important;
                }
            </style>
        `;

        window.DetailedView.switchSeasonView = (btn, seasonNum) => {
            document.querySelectorAll('.season-pill-btn').forEach(el => el.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.season-group').forEach(el => el.style.display = 'none');
            const group = document.querySelector(`.season-group.season-${seasonNum}`);
            if (group) group.style.display = 'grid'; 
        };

        return html;
    },

    renderStars(rating) {
        let html = '<div style="display: flex; gap: 4px; align-items: center;">';
        for (let i = 1; i <= 10; i++) {
            const isFilled = i <= rating;
            const starClass = isFilled ? 'fa-solid fa-star' : 'fa-regular fa-star';
            const color = isFilled ? '#fbbf24' : 'rgba(255,255,255,0.25)';
            html += `<i class="${starClass}" style="color: ${color}; cursor: pointer; transition: transform 0.2s; font-size: 1.1rem;" 
                        onclick="DetailedView.rateSeries(${i})" 
                        onmouseover="this.style.transform='scale(1.25)'; this.style.color='#fbbf24';" 
                        onmouseout="this.style.transform='scale(1)'; this.style.color='${color}';"
                        title="${i}/10 Puan Ver"></i>`;
        }
        html += '</div>';
        return html;
    },

    renderSourcePreview(series, allEpisodes, hasPlayable) {
        const existing = document.getElementById('detail-source-preview');
        if (existing) existing.remove();
        const wrapper = document.querySelector('#detail-view .detail-content-wrapper-modern');
        if (!wrapper) return;

        const poster = series.poster || series.coverImage || 'assets/poster-placeholder.jpg';
        const block = document.createElement('div');
        block.id = 'detail-source-preview';
        block.className = 'glass-panel';
        block.style.cssText = 'margin-bottom: 30px; border-radius: 20px; overflow: hidden; position: relative; min-height: 220px;';

        if (hasPlayable) {
            block.innerHTML = `
                <div style="position:relative; aspect-ratio:16/9; max-height:320px; background:#000;">
                    <img src="${poster}" alt="" style="width:100%; height:100%; object-fit:cover; opacity:0.35; filter:blur(2px);">
                    <div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center;">
                        <button type="button" class="btn-premium-glow" style="padding:14px 36px; border:none; border-radius:50px; color:#fff; font-weight:800; cursor:pointer;" onclick="document.getElementById('action-play-btn')?.click()">
                            <i class="fa-solid fa-play"></i> Önizleme — İzlemeye Başla
                        </button>
                    </div>
                </div>`;
        } else {
            block.innerHTML = `
                <div style="position:relative; aspect-ratio:16/9; max-height:320px; background:#0a0a10;">
                    <img src="${poster}" alt="" style="width:100%; height:100%; object-fit:cover; opacity:0.25;">
                    <div style="position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; background:rgba(0,0,0,0.55); backdrop-filter:blur(12px); padding:24px; text-align:center;">
                        <i class="fa-solid fa-circle-exclamation" style="font-size:2.5rem; color:#f59e0b; margin-bottom:16px;"></i>
                        <h3 style="color:#fff; margin:0 0 8px; font-size:1.35rem; font-weight:800;">Kaynak bulunamadı</h3>
                        <p style="color:#94a3b8; margin:0 0 20px; max-width:420px;">Bu içerik için henüz oynatılabilir video kaynağı eklenmemiş. Çeviri veya yükleme tamamlandığında burada izleyebilirsiniz.</p>
                        <button type="button" class="btn-premium-outline" style="padding:10px 24px; border-radius:12px; cursor:pointer;" onclick="App.router('home')">
                            <i class="fa-solid fa-arrow-left"></i> Ana Sayfaya Dön
                        </button>
                    </div>
                </div>`;
        }
        const tabs = document.getElementById('detail-tabs');
        if (tabs) wrapper.insertBefore(block, tabs);
        else wrapper.prepend(block);
    },

    getAbsoluteIndex(series, seasonNum, epNum) {
        let count = 0;
        if (series.seasons) {
            for (let s of series.seasons) {
                if (s.number < seasonNum) {
                    count += (s.episodes ? s.episodes.length : 0);
                } else if (s.number === seasonNum) {
                    if (s.episodes) {
                        for (let i = 0; i < s.episodes.length; i++) {
                            if (s.episodes[i].number === epNum) return count + i;
                        }
                    }
                }
            }
        } else {
            return epNum - 1; 
        }
        return 0;
    },

    getStatusText(status) {
        const statusMap = {
            'ongoing': 'Devam Ediyor',
            'completed': 'Tamamlandı',
            'upcoming': 'Yakında',
            'hiatus': 'Ara',
            'Tamamlandı': 'Tamamlandı',
            'Devam Ediyor': 'Devam Ediyor',
            'Final': 'Tamamlandı',
            'Bitti': 'Tamamlandı'
        };
        return statusMap[status] || 'Bilinmiyor';
    },

    generateSlug(series) {
        if (!series || !series.title) return '';
        return series.title
            .toLowerCase()
            .replace(/[^a-z0-9\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .trim();
    },

    playEpisode(seriesId, seasonNum, epNum) {
        const series = State.data?.series?.find(s => s.id === seriesId) || db.getSeries(seriesId);
        const index = this.getAbsoluteIndex(series, seasonNum, epNum);
        
        const play = () => {
            if (typeof App !== 'undefined' && App.router) {
                App.router('player', seriesId, index);
            }
        };

        if (typeof AdService !== 'undefined' && AdService.shouldShowAds && AdService.shouldShowAds()) {
            AdService.showPreRoll(play);
        } else {
            play();
        }
    },

    shareSeries(title) {
        const series = State.currentSeries;
        const url = window.location.href;

        const modal = document.createElement('div');
        modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.7); backdrop-filter:blur(8px); z-index:9999; display:flex; align-items:center; justify-content:center;';
        modal.onclick = (e) => { if (e.target === modal) modal.remove(); };
        modal.innerHTML = `
            <div style="background:#0f0f13; border:1px solid rgba(255,255,255,0.08); border-radius:20px; padding:28px; max-width:400px; width:90%; text-align:center;">
                <h3 style="color:#fff; font-size:1.2rem; margin-bottom:20px;">Paylaş</h3>
                <div style="display:flex; flex-direction:column; gap:10px;">
                    <button onclick="SocialFeed.shareToSocial({type:'series', title:'${(series?.title || title).replace(/'/g, "\\'")}', subtitle:'${series?.genre || ''}', poster:'${series?.poster || ''}', seriesId:'${series?.id || ''}'}); this.closest('div[style]').parentElement.remove();"
                        style="padding:14px; background:linear-gradient(135deg,#7c3aed,#6d28d9); border:none; color:white; border-radius:14px; font-weight:700; cursor:pointer; font-size:0.95rem; display:flex; align-items:center; justify-content:center; gap:10px; font-family:'Inter',sans-serif;">
                        <i class="fa-solid fa-earth-americas"></i> Sosyal'de Paylaş
                    </button>
                    <button onclick="navigator.clipboard.writeText('${url}'); Toast.success('Link kopyalandı!'); this.closest('div[style]').parentElement.remove();"
                        style="padding:14px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:#e2e8f0; border-radius:14px; font-weight:600; cursor:pointer; font-size:0.95rem; display:flex; align-items:center; justify-content:center; gap:10px; font-family:'Inter',sans-serif;">
                        <i class="fa-solid fa-link"></i> Linki Kopyala
                    </button>
                </div>
                <button onclick="this.closest('div[style]').parentElement.remove()" style="margin-top:14px; background:none; border:none; color:#64748b; cursor:pointer; font-size:0.85rem;">Kapat</button>
            </div>
        `;
        document.body.appendChild(modal);
    },

    switchTab(tabName, title, type, year, id) {
        document.querySelectorAll('.modern-pill-tab').forEach(t => t.classList.remove('active'));

        const tab = document.querySelector(`.modern-pill-tab[data-tab="${tabName}"]`);
        if (tab) tab.classList.add('active');

        document.querySelectorAll('.modern-tab-pane').forEach(c => c.style.display = 'none');
        const targetTab = document.getElementById(`tab-${tabName}`);
        if (targetTab) {
            targetTab.style.display = 'block';
            
            // Render specific content if needed
            if (tabName === 'fancenter') {
                let series = db.getSeries(id);
                if (!series) series = (State.data.webtoons || []).find(w => w.id === id);
                if (!series) series = (State.data.actors || []).find(a => a.name === id || a.id === id);
                
                if (series) this.renderFanCenter(series);
            }
        }

        if (tabName === 'reviews' && this.currentSeries) {
            this.renderAllReviews(this.currentSeries);
        }

        if (title) {
            const slug = title.toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-') + (year ? '-' + year : '');

            const reverseTabMap = {
                'about': 'hakkinda',
                'episodes': 'bolumler',
                'ost': 'ost',
                'cast': 'karakterler',
                'comments': 'yorumlar',
                'reviews': 'incelemeler',
                'fancenter': 'fanmerkezi'
            };

            const tabSlug = reverseTabMap[tabName];
            if (tabSlug) {
                const contentParam = type === 'webtoon' ? 'webtoon' : 'dizi';
                const targetHash = `#/${contentParam}/${slug}/${tabSlug}`;

                if (window.location.hash !== targetHash) {
                    App.navigate(contentParam, slug, tabSlug);
                }
            }
        }
    },

    renderAllReviews(series) {
        const grid = document.getElementById('reviews-grid');
        if (!grid) return;

        const posts = State.data.socialPosts || [];
        const seriesId = series.id;

        const reviews = posts.filter(p => 
            p.isReview === true && 
            (p.sharedContent?.id === seriesId || p.sharedContent?.seriesId === seriesId)
        );

        if (reviews.length === 0) {
            grid.innerHTML = `
                <div style="text-align:center; padding:80px; background:rgba(255,255,255,0.02); border:1px dashed rgba(255,255,255,0.1); border-radius:20px;">
                    <i class="fa-solid fa-comment-slash" style="font-size:3rem; color:#475569; margin-bottom:20px; opacity:0.3;"></i>
                    <p style="color:#64748b; font-size:1.1rem; margin-bottom:20px;">Henüz bu içerik hakkında inceleme yazılmamış.</p>
                    <button onclick="SocialFeed.shareToSocial({id: '${series.id}', title: '${series.title.replace(/'/g, "\\'")}', poster: '${series.poster || series.coverImage}', type: 'review'})" 
                            class="btn btn-primary">
                        <i class="fa-solid fa-pen-fancy"></i> İlk İncelemeyi Sen Yaz
                    </button>
                </div>
            `;
            return;
        }

        grid.innerHTML = reviews.map(post => this.renderReviewCard(post)).join('');
        
        if (window.SocialFeed) {
            SocialFeed.resolveMedia(grid);
        }
    },

    renderReviewCard(post) {
        const user = State.data.users?.find(u => u.id === post.userId) || { username: post.username, avatar: post.avatar };
        const likesCount = post.likes?.length || 0;
        const score = post.reviewData?.overallScore || 0;
        const timeAgo = window.SocialFeed ? SocialFeed.timeAgo(post.createdAt) : new Date(post.createdAt).toLocaleDateString('tr-TR');
        
        return `
            <div class="review-card-premium glass-panel" style="padding:20px; border-radius:20px; border:1px solid rgba(255,255,255,0.05); transition:all 0.3s; cursor:pointer;" onclick="App.router('social', 'feed', 'post-${post.id}')" onmouseenter="this.style.borderColor='rgba(139,92,246,0.3)'; this.style.transform='translateY(-5px)'" onmouseleave="this.style.borderColor='rgba(255,255,255,0.05)'; this.style.transform='translateY(0)'">
                <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:15px;">
                    <div style="display:flex; align-items:center; gap:12px;">
                        <img src="${user.avatar || 'assets/logo.png'}" style="width:40px; height:40px; border-radius:12px; object-fit:cover; border:2px solid rgba(139,92,246,0.3);">
                        <div>
                            <div style="font-weight:800; color:#fff; font-size:0.9rem;">${user.username}</div>
                            <div style="font-size:0.7rem; color:#64748b;">${timeAgo}</div>
                        </div>
                    </div>
                    <div style="background: rgba(251, 191, 36, 0.1); color: #fbbf24; padding: 4px 12px; border-radius: 10px; font-weight: 800; font-size: 0.9rem; display:flex; align-items:center; gap:5px;">
                        <i class="fa-solid fa-star"></i> ${score}
                    </div>
                </div>
                <p style="color:#cbd5e1; font-size:0.9rem; line-height:1.6; margin-bottom:15px; display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden;">
                    ${post.text}
                </p>
                ${post.mediaUrl ? `
                    <div class="review-media-preview" style="margin-bottom:15px; border-radius:12px; overflow:hidden; border:1px solid rgba(255,255,255,0.05);">
                        ${post.mediaType === 'video' ? `
                            <video ${post.mediaUrl.startsWith('media-idb:') ? `data-media-idb="${post.mediaUrl.replace('media-idb:', '')}"` : `src="${post.mediaUrl}"`} style="width:100%; max-height:200px; object-fit:cover;"></video>
                        ` : `
                            <img ${post.mediaUrl.startsWith('media-idb:') ? `data-media-idb="${post.mediaUrl.replace('media-idb:', '')}"` : `src="${post.mediaUrl}"`} style="width:100%; max-height:200px; object-fit:cover;">
                        `}
                    </div>
                ` : ''}
                <div style="display:flex; justify-content:space-between; align-items:center; padding-top:15px; border-top:1px solid rgba(255,255,255,0.05);">
                    <div style="display:flex; gap:10px;">
                        <span style="font-size:0.75rem; color:#64748b;"><i class="fa-solid fa-heart" style="color:#ec4899;"></i> ${likesCount} Beğeni</span>
                    </div>
                    <div style="color:var(--premium-violet); font-size:0.7rem; font-weight:800;">DETAYLI İNCELEME <i class="fa-solid fa-chevron-right"></i></div>
                </div>
            </div>
        `;
    },

    formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    },

    /**
     * Increments view count globally
     */
    async startViewCounter(seriesId) {
        if (!seriesId) return;
        
        try {
            // Use real sync action for global counting
            await db.syncAction('increment-view', { id: seriesId });
            
            // Update local UI immediately
            const series = db.getSeries(seriesId);
            if (series) {
                series.views = (series.views || 0) + 1;
                const viewEl = document.getElementById('detail-view-count');
                if (viewEl) viewEl.innerText = (series.views).toLocaleString();
            }
        } catch (e) {
            console.warn('View count sync failed:', e);
        }
        
        // Prevent duplicate counts in same session
        const viewedKey = `viewed_${seriesId}`;
        if (sessionStorage.getItem(viewedKey)) return;

        // Mark as viewed
        sessionStorage.setItem(viewedKey, 'true');
    },

    getAverageRating(seriesId) {
        if (!State.data || !State.data.users) return 0;

        let totalRating = 0;
        let ratingCount = 0;

        State.data.users.forEach(user => {
            if (user.ratings && user.ratings[seriesId]) {
                totalRating += user.ratings[seriesId];
                ratingCount++;
            }
        });

        if (ratingCount === 0) return 0;
        return (totalRating / ratingCount).toFixed(1);
    },

    getUserRating(seriesId) {
        if (!State.currentUser || State.currentUser.role === 'guest') return 0;
        const ratings = State.currentUser.ratings || {};
        return ratings[seriesId] || 0;
    },

    rateSeries(rating) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Puan vermek için giriş yapmalısınız!');
            return;
        }

        const seriesId = State.currentSeries.id;

        if (!State.currentUser.ratings) {
            State.currentUser.ratings = {};
        }

        State.currentUser.ratings[seriesId] = rating;

        if (State.data && State.data.users && Array.isArray(State.data.users)) {
            const userIndex = State.data.users.findIndex(u => u.id === State.currentUser.id);
            if (userIndex !== -1) {
                State.data.users[userIndex].ratings = State.currentUser.ratings;
            }
        }

        localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        db.updateUser(State.currentUser.id, { ratings: State.currentUser.ratings });

        Toast.success(`${rating}/10 puanınız kaydedildi!`);

        if (typeof DailyQuests !== 'undefined') DailyQuests.updateProgress('rate_3');
        const ratingContainer = document.getElementById('d-rating-container');
        if (ratingContainer) ratingContainer.innerHTML = this.renderStars(rating);
        
        const ratingText = document.getElementById('d-user-rating-text');
        if (ratingText) {
            ratingText.style.display = 'block';
            ratingText.textContent = `Puanınız: ${rating}/10`;
        }
    },

    getFlag(country) {
        if (!country) return '';
        if (typeof CountryFlags !== 'undefined' && CountryFlags.getFlag) {
            return CountryFlags.getFlag(country);
        }
        const flags = {
            'Güney Kore': '🇰🇷', 'Kore': '🇰🇷', 'South Korea': '🇰🇷',
            'Japonya': '🇯🇵', 'Japan': '🇯🇵',
            'Çin': '🇨🇳', 'China': '🇨🇳',
            'Tayvan': '🇹🇼', 'Taiwan': '🇹🇼',
            'Tayland': '🇹🇭', 'Thailand': '🇹🇭',
            'Türkiye': '🇹🇷', 'Turkey': '🇹🇷',
            'ABD': '🇺🇸', 'USA': '🇺🇸', 'Amerika': '🇺🇸'
        };
        return flags[country] || '🌏';
    },

    async renderActorPage(actorName) {
        if (window.ActorDetail) {
            ActorDetail.render(actorName);
            return;
        }
        if (!actorName) return;
        const container = document.getElementById('actor-detail-view');
        if (!container) return;

        document.body.classList.add('premium-theme');
        container.innerHTML = '<div style="padding:100px; text-align:center;"><i class="fas fa-spinner fa-spin fa-3x" style="color:var(--premium-violet);"></i></div>';

        let dbActor = null;
        if (State.data && State.data.actors) {
            dbActor = State.data.actors.find(a => a.name === actorName);
        }

        let seriesWithActor = [];
        let fallbackImage = 'https://via.placeholder.com/300';
        if (State.data && State.data.series) {
            State.data.series.forEach(s => {
                let cast = s.characters || s.cast || [];
                if (typeof cast === 'string') {
                    cast = cast.split(',').map(name => ({ name: name.trim(), actor: name.trim() }));
                } else if (Array.isArray(cast)) {
                    cast = cast.map(c => {
                        if (typeof c === 'string') {
                            return { name: c, actor: c };
                        }
                        return c;
                    });
                } else {
                    cast = [];
                }
                const char = cast.find(c => c && (c.actor === actorName || c.name === actorName || c.actorName === actorName));
                if (char) {
                    seriesWithActor.push({ series: s, role: char.role || 'Oyuncu' });
                    if (char.image) fallbackImage = char.image;
                }
            });
        }

        const actor = {
            name: actorName,
            image: dbActor?.image || fallbackImage,
            bio: dbActor?.bio || 'Biyografi bulunmuyor.',
            wiki: dbActor?.wiki || '',
            ...dbActor
        };

        const isAdmin = State.currentUser && ['admin', 'manager'].includes(State.currentUser.role);
        const editBtn = isAdmin ? `<button class="glass-panel" style="padding: 10px 20px; font-size: 0.9rem; color: #fff; cursor: pointer; margin-left: 15px;" onclick="DetailedView.editActorProfile('${actorName.replace(/'/g, "\\'")}')"><i class="fa-solid fa-pen"></i> Düzenle</button>` : '';

        container.innerHTML = `
            <div class="premium-hero-backdrop" style="min-height: 500px; align-items: center; padding-top: 60px;">
                <div class="hero-backdrop-image-container">
                    <div class="hero-backdrop-image" style="background-image: url('${actor.image}'); filter: blur(40px) brightness(0.3);"></div>
                </div>
                <div class="hero-overlay-cinematic" style="background: linear-gradient(to top, var(--premium-bg), transparent);"></div>
                
                <div class="container" style="max-width: 1200px; margin: 0 auto; position: relative; z-index: 2; width: 100%; padding: 0 40px;">
                    <div style="display: flex; gap: 50px; align-items: center; flex-wrap: wrap;">
                        <div class="premium-poster-card" style="flex: 0 0 320px; transform: none; box-shadow: 0 30px 60px rgba(0,0,0,0.8);">
                            <img src="${actor.image}" style="width: 100%; aspect-ratio: 2/3; object-fit: cover; display: block;">
                        </div>
                        <div style="flex: 1; min-width: 300px;">
                            <div class="shc-badges" style="margin-bottom: 20px; display: flex; gap: 10px;">
                                <span class="glass-panel" style="padding: 6px 15px; font-size: 0.8rem; font-weight: 700; color: var(--premium-violet); text-transform: uppercase;">A-List Star</span>
                                ${actor.birthDate ? `<span class="glass-panel" style="padding: 6px 15px; font-size: 0.8rem; color: #94a3b8;">${actor.birthDate}</span>` : ''}
                            </div>
                            <h1 style="font-size: 4.5rem; font-weight: 900; margin: 0 0 25px; line-height: 1; background: linear-gradient(to bottom, #fff, #cbd5e1); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">${actor.name} ${editBtn}</h1>
                            
                            <div class="actor-stats-grid">
                                <div class="premium-stat-pill">
                                    <i class="fa-solid fa-ruler-vertical premium-stat-icon"></i>
                                    <span class="premium-stat-value">${actor.height || '---'}</span>
                                    <span class="premium-stat-label">BOY</span>
                                </div>
                                <div class="premium-stat-pill">
                                    <i class="fa-solid fa-eye premium-stat-icon" style="color:#3b82f6;"></i>
                                    <span class="premium-stat-value">${actor.eyeColor || '---'}</span>
                                    <span class="premium-stat-label">GÖZ RENNGİ</span>
                                </div>
                                <div class="premium-stat-pill">
                                    <i class="fa-solid fa-shoe-prints premium-stat-icon" style="color:#10b981;"></i>
                                    <span class="premium-stat-value">${actor.footSize || '---'}</span>
                                    <span class="premium-stat-label">AYAKKABI NO</span>
                                </div>
                                <div class="premium-stat-pill">
                                    <i class="fa-solid fa-star-and-crescent premium-stat-icon" style="color:#f59e0b;"></i>
                                    <span class="premium-stat-value">${actor.zodiac || '---'}</span>
                                    <span class="premium-stat-label">BURÇ</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container" style="max-width: 1200px; margin: 60px auto; padding: 0 40px;">
                <div style="display: grid; grid-template-columns: 1fr 350px; gap: 60px;">
                    <div>
                        <h2 style="font-size: 2rem; font-weight: 800; margin-bottom: 25px; display: flex; align-items: center; gap: 15px;">
                            <i class="fa-solid fa-book-open" style="color: var(--premium-violet);"></i> Biyografi
                        </h2>
                        <div class="glass-panel" style="padding: 40px; line-height: 1.8; color: #cbd5e1; font-size: 1.15rem; border-radius: 30px; text-align: justify;">
                            ${actor.bio}
                        </div>

                        <div class="actor-filmography" style="margin-top: 60px;">
                            <h2 style="font-size: 2rem; font-weight: 800; margin-bottom: 30px; display:flex; align-items:center; gap:15px;">
                                <i class="fa-solid fa-clapperboard" style="color: var(--premium-violet);"></i> Filmografi
                            </h2>
                            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 25px;">
                                ${seriesWithActor.length > 0 ? seriesWithActor.map(item => `
                                    <div onclick="window.location.href='#/detail/${item.series.id}'; window.location.reload();" class="premium-poster-card" style="transform:none; cursor:pointer;">
                                        <img src="${item.series.poster}" style="width: 100%; aspect-ratio: 2/3; object-fit: cover; display:block;">
                                        <div style="padding: 15px; background:rgba(0,0,0,0.5); backdrop-filter:blur(5px);">
                                            <div style="font-weight: 700; font-size:1rem; color:#fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${item.series.title}</div>
                                            <div style="font-size: 0.8rem; color: var(--premium-violet); font-weight:600; margin-top:4px;">${item.role}</div>
                                        </div>
                                    </div>
                                `).join('') : '<div style="color: #64748b;">Henüz eklenmiş yapımı bulunmuyor.</div>'}
                            </div>
                        </div>
                    </div>

                    <div class="actor-side-stats">
                        <div class="glass-panel" style="padding: 30px; border-radius: 30px; position: sticky; top: 100px;">
                            <h3 style="font-size: 1.3rem; font-weight: 800; margin-bottom: 25px;">Kişisel Bilgiler</h3>
                            <div style="display: flex; flex-direction: column; gap: 20px;">
                                <div style="display:flex; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:10px;">
                                    <span style="color:#94a3b8; font-weight:600;">Kan Grubu</span>
                                    <span style="color:#fff; font-weight:700;">${actor.bloodType || 'Bilinmiyor'}</span>
                                </div>
                                <div style="display:flex; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:10px;">
                                    <span style="color:#94a3b8; font-weight:600;">Kilo</span>
                                    <span style="color:#fff; font-weight:700;">${actor.weight || 'Bilinmiyor'}</span>
                                </div>
                                <div style="display:flex; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:10px;">
                                    <span style="color:#94a3b8; font-weight:600;">Ajans</span>
                                    <span style="color:#fff; font-weight:700;">${actor.agency || 'Freelance'}</span>
                                </div>
                            </div>
                            
                            ${actor.wiki ? `
                                <a href="${actor.wiki}" target="_blank" class="btn-premium-glow" style="margin-top: 30px; width:100%; padding:15px; font-size:0.9rem;">
                                    <i class="fa-brands fa-wikipedia-w"></i> Wikipedia
                                </a>
                            ` : ''}

                            <!-- NEW: ACTOR FAN CENTER BOX -->
                            <div style="margin-top: 30px; padding: 20px; background: linear-gradient(135deg, rgba(139, 92, 246, 0.2), rgba(236, 72, 153, 0.1)); border-radius: 20px; border: 1px solid rgba(139, 92, 246, 0.3); text-align: center;">
                                <div style="font-size: 1.5rem; margin-bottom: 10px;">👑</div>
                                <h4 style="margin: 0 0 10px 0; color: #fff;">${actor.name} Fan Kulübü</h4>
                                <p style="font-size: 0.8rem; color: #cbd5e1; margin-bottom: 15px;">Özel paylaşımlar ve etkinlikler için katılın!</p>
                                <button class="btn btn-primary btn-sm btn-block" onclick="DetailedView.joinActorFanClub('${actor.name.replace(/'/g, "\\'")}')">KULÜBE KATIL</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    editActorProfile(actorName) {
        const data = (State.data.actors || []).find(a => a.name === actorName) || { name: actorName };

        const editor = document.createElement('div');
        editor.className = 'modal';
        editor.style.display = 'flex';
        editor.style.zIndex = '10002';
        editor.innerHTML = `
            <div class="modal-content" style="max-width: 500px;">
                <div class="modal-header">
                    <h2>Düzenle: ${actorName}</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Resim URL</label>
                        <input type="text" id="edit-actor-image" class="form-input" value="${data.image || ''}">
                    </div>
                    <div class="form-group">
                        <label>Doğum Tarihi</label>
                        <input type="text" id="edit-actor-birth" class="form-input" value="${data.birthDate || ''}" placeholder="Örn: 1 Ocak 1990">
                    </div>
                    <div class="form-group">
                        <label>Wikipedia URL</label>
                        <input type="text" id="edit-actor-wiki" class="form-input" value="${data.wiki || ''}">
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="form-group">
                            <label>Boy</label>
                            <input type="text" id="edit-actor-height" class="form-input" value="${data.height || ''}" placeholder="1.85 m">
                        </div>
                        <div class="form-group">
                            <label>Kilo</label>
                            <input type="text" id="edit-actor-weight" class="form-input" value="${data.weight || ''}" placeholder="70 kg">
                        </div>
                        <div class="form-group">
                            <label>Kan Grubu</label>
                            <input type="text" id="edit-actor-blood" class="form-input" value="${data.bloodType || ''}" placeholder="A+">
                        </div>
                        <div class="form-group">
                            <label>Göz Rengi</label>
                            <input type="text" id="edit-actor-eye" class="form-input" value="${data.eyeColor || ''}" placeholder="Kahverengi">
                        </div>
                        <div class="form-group">
                            <label>Burç</label>
                            <input type="text" id="edit-actor-zodiac" class="form-input" value="${data.zodiac || ''}" placeholder="Aslan">
                        </div>
                        <div class="form-group">
                            <label>Ayak Numarası</label>
                            <input type="text" id="edit-actor-foot" class="form-input" value="${data.footSize || ''}" placeholder="42">
                        </div>
                        <div class="form-group">
                            <label>Sevdiği Renk</label>
                            <input type="text" id="edit-actor-fav-color" class="form-input" value="${data.favoriteColor || ''}">
                        </div>
                        <div class="form-group">
                            <label>Ajans</label>
                            <input type="text" id="edit-actor-agency" class="form-input" value="${data.agency || ''}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Diğer Özellikler (Liste)</label>
                        <textarea id="edit-actor-others" class="form-input" rows="3" placeholder="- Yüzmeyi sever&#10;- Gitar çalar...">${data.otherFeatures || ''}</textarea>
                    </div>
                    <div class="form-group">
                        <label>Biyografi (Blog Tarzı)</label>
                        <textarea id="edit-actor-bio" class="form-input" rows="6" placeholder="Detaylı biyografi yazın...">${data.bio || ''}</textarea>
                    </div>
                    <button class="btn btn-primary btn-block" onclick="DetailedView.saveActorProfile('${actorName.replace(/'/g, "\\'")}')">Kaydet</button>
                </div>
            </div>
        `;
        document.body.appendChild(editor);
    },

    saveActorProfile(actorName) {
        const data = {
            name: actorName,
            image: document.getElementById('edit-actor-image').value,
            birthDate: document.getElementById('edit-actor-birth').value,
            wiki: document.getElementById('edit-actor-wiki').value,
            bio: document.getElementById('edit-actor-bio').value,
            height: document.getElementById('edit-actor-height').value,
            weight: document.getElementById('edit-actor-weight').value,
            bloodType: document.getElementById('edit-actor-blood').value,
            eyeColor: document.getElementById('edit-actor-eye').value,
            zodiac: document.getElementById('edit-actor-zodiac').value,
            footSize: document.getElementById('edit-actor-foot').value,
            favoriteColor: document.getElementById('edit-actor-fav-color').value,
            agency: document.getElementById('edit-actor-agency').value,
            otherFeatures: document.getElementById('edit-actor-others').value
        };

        if (!State.data.actors) State.data.actors = [];
        const idx = State.data.actors.findIndex(a => a.name === actorName);
        if (idx > -1) {
            State.data.actors[idx] = { ...State.data.actors[idx], ...data };
        } else {
            State.data.actors.push(data);
        }

        db.save().then(() => {
            Toast.success('Oyuncu profili güncellendi!');
            const modals = document.querySelectorAll('.modal');
            if (modals.length > 0) modals[modals.length - 1].remove();
            this.renderActorPage(actorName);
        }).catch(err => {
            console.error('Actor save error:', err);
            Toast.error('Kaydedilemedi');
        });
    },

    toggleWatchlist(button, seriesId) {
        if (!State.currentUser) {
            Toast.error('Listeme eklemek için giriş yapmalısınız!');
            Auth.showLogin();
            return;
        }

        const user = State.currentUser;
        const watchlist = user.watchlist || [];
        const index = watchlist.indexOf(seriesId);

        if (index > -1) {
            watchlist.splice(index, 1);
            button.innerHTML = '<i class="fa-solid fa-plus"></i> Listeme Ekle';
            button.classList.remove('active');
            Toast.success('Listeden çıkarıldı!');
        } else {
            watchlist.push(seriesId);
            button.innerHTML = '<i class="fa-solid fa-check"></i> Listeden Çıkar';
            button.classList.add('active');
            Toast.success('Listeme eklendi!');
        }

        user.watchlist = watchlist;
        State.currentUser = user;

        const dataUser = State.data.users?.find(u => u.id === user.id);
        if (dataUser) dataUser.watchlist = watchlist;

        sessionStorage.setItem('dramicbox_user', JSON.stringify(user));
        if (typeof db !== 'undefined' && db.save) {
            db.save();
        } else if (typeof db !== 'undefined' && db.updateUser) {
            db.updateUser(user.id, { watchlist: watchlist });
        }
    },

    incrementViews(seriesId) {
        // Increment locally
        const series = db.getSeries(seriesId);
        if (series) {
            series.views = (series.views || 0) + 1;
            db.save();

            // Update view count in DOM if visible
            const viewEl = document.getElementById('view-count-display');
            if (viewEl) viewEl.innerText = this.formatNumber(series.views);
            
            console.log(`👁️ View incremented for ${seriesId}: ${series.views}`);
        }
    },

    isFollowing(seriesId) {
        return State.currentUser && State.currentUser.following && State.currentUser.following.includes(seriesId);
    },

    toggleFollow(seriesId) {
        if (!State.currentUser) {
            Toast.warning("Takip etmek için giriş yapmalısınız!");
            return;
        }

        if (!State.currentUser.following) State.currentUser.following = [];

        const index = State.currentUser.following.indexOf(seriesId);
        const btn = document.getElementById(`follow-btn-${seriesId}`);

        if (index === -1) {
            // Follow
            State.currentUser.following.push(seriesId);
            if (btn) btn.innerHTML = '<i class="fa-solid fa-bell-slash"></i> Takibi Bırak';
            Toast.success("Dizi takip ediliyor! Yeni bölüm gelince bildirim alacaksınız.");
            Gamification.addXP(10, 'Takip Etme');
        } else {
            // Unfollow
            State.currentUser.following.splice(index, 1);
            if (btn) btn.innerHTML = '<i class="fa-solid fa-bell"></i> Takip Et';
            Toast.info("Takip bırakıldı.");
        }

        if (window.db && window.db.save) window.db.save();
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
    },

    // ... existing shareSeries ...
    shareSeries(title) {
        const series = State.currentSeries;
        const url = window.location.href;

        // Show share options modal
        const modal = document.createElement('div');
        modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.7); backdrop-filter:blur(8px); z-index:9999; display:flex; align-items:center; justify-content:center;';
        modal.onclick = (e) => { if (e.target === modal) modal.remove(); };
        modal.innerHTML = `
            <div style="background:#0f0f13; border:1px solid rgba(255,255,255,0.08); border-radius:20px; padding:28px; max-width:400px; width:90%; text-align:center;">
                <h3 style="color:#fff; font-size:1.2rem; margin-bottom:20px;">Paylaş</h3>
                <div style="display:flex; flex-direction:column; gap:10px;">
                    <button onclick="SocialFeed.shareToSocial({type:'series', title:'${(series?.title || title).replace(/'/g, "\\'")}', subtitle:'${series?.genre || ''}', poster:'${series?.poster || ''}', seriesId:'${series?.id || ''}'}); this.closest('div[style]').parentElement.remove();"
                        style="padding:14px; background:linear-gradient(135deg,#7c3aed,#6d28d9); border:none; color:white; border-radius:14px; font-weight:700; cursor:pointer; font-size:0.95rem; display:flex; align-items:center; justify-content:center; gap:10px; font-family:'Inter',sans-serif;">
                        <i class="fa-solid fa-earth-americas"></i> Sosyal'de Paylaş
                    </button>
                    <button onclick="navigator.clipboard.writeText('${url}'); Toast.success('Link kopyalandı!'); this.closest('div[style]').parentElement.remove();"
                        style="padding:14px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:#e2e8f0; border-radius:14px; font-weight:600; cursor:pointer; font-size:0.95rem; display:flex; align-items:center; justify-content:center; gap:10px; font-family:'Inter',sans-serif;">
                        <i class="fa-solid fa-link"></i> Linki Kopyala
                    </button>
                </div>
                <button onclick="this.closest('div[style]').parentElement.remove()" style="margin-top:14px; background:none; border:none; color:#64748b; cursor:pointer; font-size:0.85rem;">Kapat</button>
            </div>
        `;
        document.body.appendChild(modal);
    },
    
    async refreshEpisodes(seriesId) {
        Toast.info('Veriler senkronize ediliyor...');
        const success = await db.syncDatabaseFromJson(seriesId);
        if (success) {
            Toast.success('Bölüm listesi güncellendi.');
            const series = db.getSeries(seriesId);
            if (series) this.render(series);
        } else {
            Toast.error('Veri senkronizasyonu başarısız oldu.');
        }
    },

    // --- NEW: FAN CENTER SYSTEM ---
    renderFanCenter(series) {
        const root = document.getElementById('d-fancenter-root');
        if (!root) return;

        const fc = series.fanCenter || { members: [], polls: [] };
        const isMember = State.currentUser && fc.members?.includes(State.currentUser.id);
        const fanPosts = (State.data.socialPosts || []).filter(p => 
            p.metadata?.seriesId === series.id || 
            (p.sharedContent?.id === series.id && p.isFanPost === true)
        ).sort((a, b) => b.createdAt - a.createdAt);

        root.innerHTML = `
            <div class="fan-center-container" style="display: grid; grid-template-columns: 1fr 320px; gap: 30px;">
                <div class="fan-main-col">
                    <!-- Fan Header Card -->
                    <div class="glass-panel" style="padding: 30px; border-radius: 24px; margin-bottom: 30px; background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(236, 72, 153, 0.05)); border: 1px solid rgba(255,255,255,0.1);">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h3 style="margin: 0; font-size: 1.8rem; font-weight: 900; color: #fff;">${series.title} Fan Kulübü</h3>
                                <p style="color: #94a3b8; margin: 10px 0 0 0; font-size: 1rem;">
                                    <i class="fa-solid fa-users"></i> ${fc.members?.length || 0} Üye • 
                                    <i class="fa-solid fa-fire"></i> ${(fanPosts.length * 5) + (fc.members?.length || 0) * 10} Fan Puanı
                                </p>
                            </div>
                            ${isMember ? 
                                `<span class="badge-premium" style="background: rgba(16, 185, 129, 0.1); color: #10b981; border: 1px solid #10b981; padding: 10px 20px; border-radius: 12px; font-weight: 800;"><i class="fa-solid fa-check"></i> ÜYESİNİZ</span>` :
                                `<button class="btn btn-primary" onclick="DetailedView.joinFanClub('${series.id}')" style="padding: 12px 30px; border-radius: 12px; font-weight: 800;">KULÜBE KATIL</button>`
                            }
                        </div>
                    </div>

                    <!-- Post Feed -->
                    <div class="fan-posts-section">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                            <h4 style="margin: 0; font-size: 1.4rem; font-weight: 800;">Hayran Paylaşımları</h4>
                            <button class="btn btn-outline btn-sm" onclick="DetailedView.openFanPostModal('${series.id}')">
                                <i class="fa-solid fa-pen-nib"></i> Paylaşım Yap
                            </button>
                        </div>
                        <div class="fan-posts-grid" style="display: grid; gap: 20px;">
                            ${fanPosts.map(p => this.renderFanPostItem(p)).join('') || `
                                <div style="text-align: center; padding: 60px; background: rgba(255,255,255,0.02); border-radius: 20px; border: 1px dashed rgba(255,255,255,0.1);">
                                    <p style="color: #64748b;">Henüz paylaşım yok. İlk hayran gönderisini sen paylaş!</p>
                                </div>
                            `}
                        </div>
                    </div>
                </div>

                <div class="fan-side-col">
                    <!-- Poll Card -->
                    <div class="glass-panel" style="padding: 20px; border-radius: 20px; margin-bottom: 25px;">
                        <h4 style="margin: 0 0 15px 0; font-size: 1.1rem; color: #fff;">Aktif Oylama</h4>
                        ${fc.polls && fc.polls.length > 0 ? `
                            <div class="poll-box">
                                <p style="font-weight: 700; font-size: 0.95rem; margin-bottom: 15px; color: #e2e8f0;">${fc.polls[0].question}</p>
                                <div style="display: grid; gap: 10px;">
                                    ${fc.polls[0].options.map((opt, idx) => `
                                        <div class="poll-opt-mini" onclick="DetailedView.voteFanPoll('${series.id}', 0, ${idx})" style="position: relative; background: rgba(255,255,255,0.05); padding: 12px; border-radius: 10px; cursor: pointer; border: 1px solid rgba(255,255,255,0.05);">
                                            <div style="position: relative; z-index: 2; display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: 700;">
                                                <span>${opt.text}</span>
                                                <span>%${opt.votes || 0}</span>
                                            </div>
                                            <div style="position: absolute; left: 0; top: 0; height: 100%; width: ${opt.votes || 0}%; background: rgba(139, 92, 246, 0.2); border-radius: 10px; z-index: 1;"></div>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        ` : '<p style="color: #64748b; font-size: 0.9rem; text-align: center; padding: 20px 0;">Şu an aktif oylama yok.</p>'}
                    </div>

                    <!-- Top Fans -->
                    <div class="glass-panel" style="padding: 20px; border-radius: 20px;">
                        <h4 style="margin: 0 0 15px 0; font-size: 1.1rem; color: #fff;">En Aktif Hayranlar</h4>
                        <div style="display: grid; gap: 12px;">
                            ${[1, 2, 3].map(i => `
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <div style="width: 35px; height: 35px; border-radius: 50%; background: #2d2d3a; display: flex; align-items: center; justify-content: center; font-weight: 900; color: #8b5cf6;">${i}</div>
                                    <img src="https://i.pravatar.cc/100?u=${i}" style="width: 40px; height: 40px; border-radius: 12px; object-fit: cover;">
                                    <div style="flex: 1;">
                                        <div style="font-size: 0.9rem; font-weight: 700;">Hayran_${i * 42}</div>
                                        <div style="font-size: 0.75rem; color: #64748b;">${1200 - (i * 200)} Puan</div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    renderFanPostItem(p) {
        const user = State.data.users?.find(u => u.id === p.authorId) || { username: p.author || 'Anonim', avatar: 'assets/logo.png' };
        return `
            <div class="glass-panel" style="padding: 20px; border-radius: 20px; background: rgba(255,255,255,0.03);">
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                    <img src="${user.avatar}" style="width: 45px; height: 45px; border-radius: 14px; border: 2px solid rgba(139, 92, 246, 0.2);">
                    <div>
                        <div style="font-weight: 800; color: #fff;">${user.username}</div>
                        <div style="font-size: 0.75rem; color: #64748b;">${new Date(p.createdAt).toLocaleDateString('tr-TR')}</div>
                    </div>
                </div>
                <p style="color: #e2e8f0; line-height: 1.6; margin-bottom: 15px;">${p.content || p.text}</p>
                ${p.metadata?.image ? `<img src="${p.metadata.image}" style="width: 100%; border-radius: 12px; margin-bottom: 15px;">` : ''}
                <div style="display: flex; gap: 20px; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 15px;">
                    <div style="color: #94a3b8; font-size: 0.9rem; font-weight: 700; cursor: pointer;" onclick="SocialFeed.likePost('${p.id}')"><i class="fa-regular fa-heart"></i> ${p.likes?.length || 0}</div>
                    <div style="color: #94a3b8; font-size: 0.9rem; font-weight: 700;"><i class="fa-regular fa-comment"></i> ${p.comments?.length || 0}</div>
                </div>
            </div>
        `;
    },

    async joinFanClub(seriesId) {
        if (!State.currentUser || State.currentUser.role === 'guest') return Toast.warning('Katılmak için giriş yapın!');
        const series = db.getSeries(seriesId);
        if (!series) return;

        if (!series.fanCenter) series.fanCenter = { members: [], polls: [] };
        if (series.fanCenter.members.includes(State.currentUser.id)) return;

        series.fanCenter.members.push(State.currentUser.id);
        await db.syncItem('series', series, false);
        Toast.success('Fan kulübüne katıldınız! 🎉');
        this.renderFanCenter(series);
    },

    async joinActorFanClub(actorName) {
        if (!State.currentUser || State.currentUser.role === 'guest') return Toast.warning('Katılmak için giriş yapın!');
        
        let actor = (State.data.actors || []).find(a => a.name === actorName);
        if (!actor) {
            actor = { name: actorName, fanCenter: { members: [], polls: [] } };
            if (!State.data.actors) State.data.actors = [];
            State.data.actors.push(actor);
        }

        if (!actor.fanCenter) actor.fanCenter = { members: [], polls: [] };
        if (actor.fanCenter.members.includes(State.currentUser.id)) return Toast.info('Zaten üyesiniz!');

        actor.fanCenter.members.push(State.currentUser.id);
        await db.syncItem('actors', actor, false);
        Toast.success(`${actorName} fan kulübüne katıldınız! 🎉`);
        this.renderActorPage(actorName);
    },

    openFanPostModal(seriesId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Hayran paylaşımı yapmak için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        const series = db.getSeries(seriesId);
        const modal = document.getElementById('m-hub-modal') || document.getElementById('d-global-modal');
        if (!modal) return;

        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width: 450px; padding: 30px; border-radius: 24px;">
                <h2 style="margin-bottom: 20px; color: #fff; font-weight: 900;">Fan Paylaşımı</h2>
                <div class="form-group" style="margin-bottom: 15px;">
                    <textarea id="fan-post-text" class="form-input" style="width: 100%; min-height: 120px;" placeholder="Bu içerik hakkında ne düşünüyorsun?"></textarea>
                </div>
                <div class="form-group" style="margin-bottom: 25px;">
                    <input type="text" id="fan-post-image" class="form-input" placeholder="Resim URL (Opsiyonel)">
                </div>
                <div style="display: grid; gap: 10px;">
                    <button class="btn btn-primary" onclick="DetailedView.submitFanPost('${seriesId}')">Yayınla</button>
                    <button class="btn btn-secondary" onclick="ManagementHub.closeModal()">Vazgeç</button>
                </div>
            </div>
        `;
        modal.style.display = 'flex';
    },

    async submitFanPost(seriesId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Hayran paylaşımı yapmak için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        const text = document.getElementById('fan-post-text').value;
        const img = document.getElementById('fan-post-image').value;
        if (!text.trim()) return Toast.warning('Lütfen bir mesaj yazın.');

        const series = db.getSeries(seriesId);
        const newPost = {
            id: 'fp-' + Date.now(),
            authorId: State.currentUser.id,
            author: State.currentUser.username,
            content: text,
            isFanPost: true,
            createdAt: Date.now(),
            likes: [],
            comments: [],
            metadata: {
                seriesId: seriesId,
                image: img || null
            }
        };

        if (!State.data.socialPosts) State.data.socialPosts = [];
        await db.syncItem('socialPosts', newPost);
        
        ManagementHub.closeModal();
        Toast.success('Paylaşımınız yayınlandı!');
        this.renderFanCenter(series);
    },

    async voteFanPoll(seriesId, pollIdx, optIdx) {
        if (!State.currentUser || State.currentUser.role === 'guest') return Toast.warning('Oy kullanmak için giriş yapın!');
        const series = db.getSeries(seriesId);
        if (!series || !series.fanCenter.polls[pollIdx]) return;

        const poll = series.fanCenter.polls[pollIdx];
        if (!poll.voters) poll.voters = [];
        if (poll.voters.includes(State.currentUser.id)) return Toast.info('Zaten oy kullandınız.');

        poll.options[optIdx].votes = (poll.options[optIdx].votes || 0) + 1;
        poll.voters.push(State.currentUser.id);
        
        // Recalculate percentages
        const total = poll.options.reduce((sum, o) => sum + (o.votes || 0), 0);
        poll.options.forEach(o => {
            o.votes = Math.round(((o.votes || 0) / total) * 100);
        });

        await db.syncItem('series', series, false);
        Toast.success('Oyunuz kaydedildi.');
        this.renderFanCenter(series);
    }
};
}
console.log('✅ Detailed View Module Loaded!');
