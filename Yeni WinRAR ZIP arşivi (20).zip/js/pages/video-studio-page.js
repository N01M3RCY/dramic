// ============================================
// VIDEO STUDIO PRO - PAGE-BASED VERSION
// ============================================

if (typeof VideoStudioPage === 'undefined') {
    window.VideoStudioPage = {
        project: {
            tracks: { video: [], audio: [], text: [], subtitle: [] },
            duration: 0
        },
        selectedClip: null,
        isPlaying: false,
        zoomLevel: 40,
        currentTime: 0,
        player: null,
        context: {
            seriesId: null,
            seriesTitle: '',
            episodeNumber: '',
            episodeId: null
        },

        init() {
            console.log('🎬 Video Studio Page Initialized');
        },

        render(context = {}) {
            // Store context
            this.context = {
                seriesId: context.seriesId || null,
                seriesTitle: context.seriesTitle || '',
                episodeNumber: context.episodeNumber || '',
                episodeId: context.episodeId || null
            };

            // Check role-based access
            const hasAdminBadge = State.currentUser?.badges?.includes('Yönetici') || State.currentUser?.badges?.includes('Admin');
            const allowedRoles = ['admin', 'translator', 'webtoon-translator', 'moderator'];
            
            if (!State.currentUser || (!allowedRoles.includes(State.currentUser.role) && !hasAdminBadge)) {
                Toast.error('Bu sayfaya erişim yetkiniz yok!');
                window.location.hash = '#/ana-sayfa';
                return;
            }

            // PERMISSION CHECK for Translators
            if (State.currentUser.role === 'translator') {
                const series = State.data.series.find(s => s.id == this.context.seriesId);
                if (!series) {
                    Toast.error('Dizi bulunamadı!');
                    this.close();
                    return;
                }
                if (series.translatorId !== State.currentUser.id && (!series.translators || !series.translators.includes(State.currentUser.id))) {
                    Toast.error('Bu diziyi düzenleme yetkiniz yok! Sadece size atanan dizileri düzenleyebilirsiniz.');
                    this.close();
                    return;
                }
            }

            // Hide Main App
            const navbar = document.getElementById('main-navbar');
            const appContainer = document.getElementById('app-container');
            if (navbar) navbar.style.display = 'none';
            if (appContainer) appContainer.style.display = 'none';

            // Use dedicated container
            let container = document.getElementById('video-studio-root');
            if (!container) {
                container = document.createElement('div');
                container.id = 'video-studio-root';
                // Fix: Ensure it covers everything
                container.style.cssText = 'position: fixed; inset: 0; width: 100vw; height: 100vh; z-index: 999999; background: #0f1115;';
                document.body.appendChild(container);
            }
            container.innerHTML = `
            <div class="video-studio-page" style="display: flex; flex-direction: column; height: 100%; width: 100%; color: #e2e8f0; font-family: 'Inter', sans-serif; overflow: hidden;">
                <style>
                    /* Tree View Styles */
                    .vs-tree-item { padding: 4px 0; font-size: 13px; color: #cbd5e1; cursor: pointer; user-select: none; }
                    .vs-tree-item:hover > .vs-tree-content { background: rgba(255,255,255,0.05); color: white; }
                    .vs-tree-content { display: flex; align-items: center; gap: 6px; padding: 4px 8px; border-radius: 4px; transition: all 0.1s; }
                    .vs-tree-children { margin-left: 20px; border-left: 1px solid rgba(255,255,255,0.1); padding-left: 4px; display: none; }
                    .vs-tree-children.open { display: block; }
                    .vs-tree-toggle { width: 16px; height: 16px; display: inline-flex; align-items: center; justify-content: center; transform: rotate(-90deg); transition: transform 0.2s; }
                    .vs-tree-folder.open > .vs-tree-content .vs-tree-toggle { transform: rotate(0deg); }
                    
                    /* Timeline Scroll */
                    #vs-timeline-container { overflow-x: auto; overflow-y: hidden; }
                    #vs-timeline-tracks { min-width: 100%; width: max-content; }
                    ::-webkit-scrollbar { width: 8px; height: 8px; }
                    ::-webkit-scrollbar-track { background: #0f1115; }
                    ::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
                    ::-webkit-scrollbar-thumb:hover { background: #475569; }
                </style>
                
                <!-- Header -->
                <header style="height: 56px; border-bottom: 1px solid #1e293b; background: #16191f; display: flex; align-items: center; justify-content: space-between; padding: 0 24px; flex-shrink: 0;">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <div style="background: #3b82f6; padding: 6px; border-radius: 8px;">
                            <i class="fa-solid fa-video" style="color: white; font-size: 20px;"></i>
                        </div>
                        <h1 style="font-size: 18px; font-weight: 700; margin: 0;">
                            DramicBox <span style="color: #a78bfa;">Editor</span>
                        </h1>
                        ${this.context.seriesTitle ? `
                            <span style="color: #64748b; font-size: 14px; margin-left: 12px; border-left: 1px solid #334155; padding-left: 12px;">
                                ${this.context.seriesTitle} <span style="color: #475569;">/</span> Bölüm ${this.context.episodeNumber}
                            </span>
                        ` : ''}
                        
                        <!-- Active Users (Collaborative Editing) -->
                        <div id="vs-active-users" style="display: flex; align-items: center; gap: 8px; margin-left: 20px; padding-left: 20px; border-left: 1px solid #1e293b;">
                            <i class="fa-solid fa-users" style="color: #8b5cf6; font-size: 14px;"></i>
                            <div id="vs-user-avatars" style="display: flex; gap: -8px;">
                                <!-- User avatars will be inserted here -->
                            </div>
                        </div>
                    </div>
                    <div style="display: flex; gap: 12px;">
                        <button onclick="VideoStudioPage.saveDraft()" style="padding: 6px 12px; border-radius: 6px; background: rgba(59, 130, 246, 0.1); border: 1px solid rgba(59, 130, 246, 0.3); color: #60a5fa; cursor: pointer; font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 6px;">
                            <i class="fa-solid fa-save"></i> Taslağı Kaydet
                        </button>
                        <button onclick="VideoStudioPage.submitForApproval()" style="padding: 6px 12px; border-radius: 6px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); color: #34d399; cursor: pointer; font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 6px;">
                            <i class="fa-solid fa-check"></i> Onaya Gönder
                        </button>
                        <div style="width: 1px; background: #334155; margin: 0 4px;"></div>
                        <button onclick="VideoStudioPage.close()" style="padding: 6px 16px; border-radius: 6px; background: transparent; border: 1px solid #334155; color: #e2e8f0; cursor: pointer; font-size: 14px; font-weight: 500;">
                            Kapat
                        </button>
                        <button onclick="VideoStudioPage.saveAndUpload()" style="padding: 6px 16px; border-radius: 6px; background: #8b5cf6; border: none; color: white; cursor: pointer; font-size: 14px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
                            <i class="fa-solid fa-cloud-arrow-up"></i> Yayınla
                        </button>
                    </div>
                </header>

                <!-- Main Grid - FIXED WITH EXPLICIT LAYOUT -->
                <main style="flex: 1; display: flex; overflow: hidden; min-height: 0;">
                    
                    <!-- Left Panel: Media Browser -->
                    <aside style="width: 280px; flex-shrink: 0; background: #16191f; border-right: 1px solid #1e293b; padding: 16px; overflow-y: auto; display: flex; flex-direction: column;">
                        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 24px; font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 1.5px;">
                            <i class="fa-solid fa-upload" style="font-size: 14px;"></i> Kaynak Yönetimi
                        </div>
                        
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            <label style="display: block; cursor: pointer;">
                                <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #1c2128; border: 1px solid rgba(51, 65, 85, 0.5); border-radius: 12px; transition: all 0.2s;">
                                    <i class="fa-solid fa-video" style="font-size: 20px; color: #8b5cf6;"></i>
                                    <div style="text-align: left;">
                                        <div style="font-size: 14px; font-weight: 600;">Video Ekle</div>
                                        <div style="font-size: 10px; color: #64748b;">MP4, WEBM</div>
                                    </div>
                                    <input type="file" id="vs-video-input" style="display: none;" accept="video/*" onchange="VideoStudioPage.handleVideoUpload(this)">
                                </div>
                            </label>

                            <button onclick="VideoStudioPage.addFromUrl()" style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #1c2128; border: 1px solid rgba(51, 65, 85, 0.5); border-radius: 12px; cursor: pointer; width: 100%; text-align: left;">
                                <i class="fa-solid fa-link" style="font-size: 20px; color: #3b82f6;"></i>
                                <div>
                                    <div style="font-size: 14px; font-weight: 600; color: #e2e8f0;">URL ile Ekle</div>
                                    <div style="font-size: 10px; color: #64748b;">Harici Video Linki</div>
                                </div>
                            </button>

                            <label style="display: block; cursor: pointer;">
                                <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #1c2128; border: 1px solid rgba(51, 65, 85, 0.5); border-radius: 12px; transition: all 0.2s;">
                                    <i class="fa-solid fa-closed-captioning" style="font-size: 20px; color: #a78bfa;"></i>
                                    <div style="text-align: left;">
                                        <div style="font-size: 14px; font-weight: 600;">SRT Aktar</div>
                                        <div style="font-size: 10px; color: #64748b;">Altyazı Dosyası</div>
                                    </div>
                                    <input type="file" id="vs-srt-input" style="display: none;" accept=".srt" onchange="VideoStudioPage.handleSRTUpload(this)">
                                </div>
                            </label>

                            <button onclick="VideoStudioPage.addText()" style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #1c2128; border: 1px solid rgba(51, 65, 85, 0.5); border-radius: 12px; cursor: pointer; width: 100%; text-align: left;">
                                <i class="fa-solid fa-font" style="font-size: 20px; color: #fbbf24;"></i>
                                <div>
                                    <div style="font-size: 14px; font-weight: 600; color: #e2e8f0;">Metin Ekle</div>
                                    <div style="font-size: 10px; color: #64748b;">Video Üzeri Yazı</div>
                                </div>
                            </button>

                            <button onclick="VideoStudioPage.showVidmolySettings()" style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #1c2128; border: 1px solid rgba(139, 92, 246, 0.2); border-radius: 12px; cursor: pointer; width: 100%; text-align: left; margin-top: 8px;">
                                <i class="fa-solid fa-cloud" style="font-size: 20px; color: #8b5cf6;"></i>
                                <div>
                                    <div style="font-size: 14px; font-weight: 600; color: #e2e8f0;">Vidmoly Hesabı</div>
                                    <div style="font-size: 10px; color: #a78bfa;">Otomatik Yükleme</div>
                                </div>
                            </button>
                        </div>

                        <div style="margin-top: 24px;">
                            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px; font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 1.5px;">
                                <i class="fa-solid fa-folder-open" style="font-size: 14px;"></i> Proje Dosyaları
                            </div>
                            </div>
                            <div style="padding: 10px; background: #0f1115; border: 1px solid #1e293b; border-radius: 8px; flex: 1; display: flex; flex-direction: column; overflow: hidden;">
                                <div style="display: flex; align-items: center; gap: 8px; padding-bottom: 8px; border-bottom: 1px solid #1e293b; margin-bottom: 8px; color: #94a3b8; font-size: 12px; font-family: monospace;">
                                    <i class="fa-solid fa-server" style="color: #8b5cf6;"></i> /diziler/${this.context.seriesTitle ? this.context.seriesTitle.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '') : '...'}
                                </div>
                                <div id="vs-media-list" style="flex: 1; overflow-y: auto; padding-right: 4px;">
                                    <div style="text-align:center; padding: 20px; color: #64748b; font-size: 12px;">
                                        <i class="fa-solid fa-sync fa-spin"></i> Dosyalar taranıyor...
                                    </div>
                                </div>
                            </div>
                    </aside>

                    <!-- Center + Right Column -->
                    <div style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
                        
                        <!-- Top Row: Player + Inspector -->
                        <div style="flex: 1; display: flex; min-height: 0;">
                            
                            <!-- Center: Player -->
                            <section style="flex: 1; background: black; display: flex; flex-direction: column; min-width: 0;">
                                <div id="vs-player-container" style="flex: 1; position: relative; display: flex; align-items: center; justify-content: center; overflow: hidden; background: #000;">
                                    <video id="vs-player" style="max-width: 100%; max-height: 100%; display: block;"></video>
                                    <iframe id="vs-preview-iframe" style="width: 100%; height: 100%; display: none; border: none;" allowfullscreen></iframe>
                                    <div id="vs-overlay-layer" style="position: absolute; inset: 0; pointer-events: none;"></div>
                                    <div id="vs-placeholder" style="position: absolute; text-align: center; color: #475569; opacity: 0.2;">
                                        <i class="fa-solid fa-film" style="font-size: 80px; margin-bottom: 16px;"></i>
                                        <p style="font-size: 20px; font-weight: 700;">Lütfen Medya Yükleyin</p>
                                    </div>
                                </div>

                                <!-- Player Controls -->
                                <div style="height: 56px; background: #16191f; border-top: 1px solid #1e293b; display: flex; align-items: center; justify-content: center; gap: 32px; flex-shrink: 0;">
                                    <button onclick="VideoStudioPage.seek(-5)" style="background: none; border: none; color: #94a3b8; cursor: pointer; padding: 8px;">
                                        <i class="fa-solid fa-backward" style="font-size: 20px;"></i>
                                    </button>
                                    <button id="vs-play-btn" onclick="VideoStudioPage.togglePlay()" style="width: 40px; height: 40px; border-radius: 50%; background: #8b5cf6; border: none; display: flex; align-items: center; justify-content: center; cursor: pointer;">
                                        <i id="vs-play-icon" class="fa-solid fa-play" style="color: white; font-size: 16px;"></i>
                                    </button>
                                    <button onclick="VideoStudioPage.seek(5)" style="background: none; border: none; color: #94a3b8; cursor: pointer; padding: 8px;">
                                        <i class="fa-solid fa-forward" style="font-size: 20px;"></i>
                                    </button>
                                    <div id="vs-time-display" style="position: absolute; right: 24px; font-family: monospace; font-size: 14px; font-weight: 700; color: #64748b;">
                                        00:00 / 00:00
                                    </div>
                                </div>
                            </section>

                            <!-- Right Panel: Tabs (Inspector / Subtitles) -->
                            <aside style="width: 320px; flex-shrink: 0; background: #16191f; border-left: 1px solid #1e293b; display: flex; flex-direction: column;">
                                <!-- Tabs -->
                                <div style="display: flex; border-bottom: 1px solid #1e293b;">
                                    <button onclick="VideoStudioPage.switchTab('properties')" id="tab-properties" class="vs-tab active" style="flex: 1; padding: 12px; background: none; border: none; color: #94a3b8; font-weight: 600; cursor: pointer; border-bottom: 2px solid transparent;">Özellikler</button>
                                    <button onclick="VideoStudioPage.switchTab('subtitles')" id="tab-subtitles" class="vs-tab" style="flex: 1; padding: 12px; background: none; border: none; color: #94a3b8; font-weight: 600; cursor: pointer; border-bottom: 2px solid transparent;">Altyazılar</button>
                                </div>

                                <!-- Tab Content -->
                                <div id="vs-tab-content" style="flex: 1; overflow-y: auto; padding: 16px;">
                                    
                                    <!-- PROPERTIES TAB -->
                                    <div id="vs-panel-properties">
                                        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 24px; font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 1.5px;">
                                            <i class="fa-solid fa-sliders" style="font-size: 14px;"></i> Seçili Klip
                                        </div>
                                        <div id="vs-inspector-content">
                                            <div style="height: 160px; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #475569; border: 2px dashed #1e293b; border-radius: 16px;">
                                                <i class="fa-solid fa-sliders" style="font-size: 32px; margin-bottom: 8px; opacity: 0.2;"></i>
                                                <p style="font-size: 12px;">Klip seçilmedi</p>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- SUBTITLES TAB -->
                                    <div id="vs-panel-subtitles" style="display: none;">
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                                            <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 1.5px;">
                                                <i class="fa-solid fa-list" style="font-size: 14px;"></i> Altyazı Listesi
                                            </div>
                                            <button onclick="VideoStudioPage.addSubtitle()" style="padding: 4px 12px; background: #3b82f6; border: none; border-radius: 4px; color: white; cursor: pointer; font-size: 12px;">
                                                <i class="fa-solid fa-plus"></i> Ekle
                                            </button>
                                        </div>
                                        <div id="vs-subtitle-list" style="display: flex; flex-direction: column; gap: 8px;">
                                            <!-- Subtitles rendered here -->
                                        </div>
                                    </div>

                                </div>
                            </aside>
                        </div>

                        <!-- Bottom: Timeline -->
                        <section style="height: 320px; flex-shrink: 0; background: #121418; border-top: 1px solid #1e293b; display: flex; flex-direction: column; overflow: hidden;">
                            <div style="height: 40px; background: #16191f; border-bottom: 1px solid #1e293b; display: flex; align-items: center; padding: 0 16px; gap: 16px; flex-shrink: 0;">
                                <div style="display: flex; gap: 8px;">
                                    <button onclick="VideoStudioPage.deleteClip()" style="padding: 6px; background: none; border: none; color: #64748b; cursor: pointer; border-radius: 4px;" title="Sil">
                                        <i class="fa-solid fa-trash" style="font-size: 14px;"></i>
                                    </button>
                                    <button style="padding: 6px; background: none; border: none; color: #64748b; cursor: pointer; border-radius: 4px;" title="Böl">
                                        <i class="fa-solid fa-scissors" style="font-size: 14px;"></i>
                                    </button>
                                </div>
                                <div style="height: 16px; width: 1px; background: #1e293b;"></div>
                                <div style="font-size: 10px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 1.5px;">Timeline Editor</div>
                            </div>

                            <div id="vs-timeline-container" style="flex: 1; overflow: auto; position: relative; background: #0f1115;">
                                <div id="vs-playhead" style="position: absolute; top: 0; bottom: 0; width: 2px; background: #ef4444; z-index: 50; pointer-events: none; left: 120px;">
                                    <div style="position: absolute; top: -4px; left: -6px; width: 12px; height: 12px; background: #ef4444; transform: rotate(45deg);"></div>
                                </div>
                                <div id="vs-timeline-tracks"></div>
                            </div>
                        </section>
                    </div>

                </main>
            </div>
        `;

            console.log('🎬 Video Studio HTML injected');

            // Debug: Check if elements exist
            setTimeout(() => {
                const player = document.getElementById('vs-player');
                const playerContainer = document.getElementById('vs-player-container');
                const timeline = document.getElementById('vs-timeline-container');
                const inspector = document.getElementById('vs-inspector-content');

                console.log('🔍 Element check:', {
                    player: !!player,
                    playerContainer: !!playerContainer,
                    timeline: !!timeline,
                    inspector: !!inspector
                });

                if (playerContainer) {
                    console.log('📐 Player container dimensions:', {
                        width: playerContainer.offsetWidth,
                        height: playerContainer.offsetHeight,
                        display: window.getComputedStyle(playerContainer).display
                    });
                }
            }, 100);

            this.player = document.getElementById('vs-player');
            if (this.player) {
                console.log('✅ Video player element found');
            } else {
                console.error('❌ Video player element NOT found!');
            }

            this.bindEvents();
            this.renderTimeline();
            this.fetchProjectFiles();

            // COLLABORATIVE EDITING: Join session
            if (typeof CollaborationService !== 'undefined' && this.context.seriesId && this.context.episodeNumber) {
                CollaborationService.joinSession(this.context.seriesId, this.context.episodeNumber);
                this.setupCollaborationListeners();
            }

            // CHAT: Initialize
            if (typeof VideoStudioChat !== 'undefined') {
                setTimeout(() => VideoStudioChat.init(this.context), 1000);
            }

            // TRANSLATOR WATERMARK: Show on video player
            setTimeout(() => {
                const playerContainer = document.querySelector('.video-player-container') ||
                    document.getElementById('vs-player-container');
                if (playerContainer && typeof TranslatorWatermark !== 'undefined') {
                    TranslatorWatermark.show(playerContainer, {
                        seriesTitle: this.context.seriesTitle,
                        episodeNumber: this.context.episodeNumber
                    });
                    console.log('[VideoStudio] Watermark added');
                }
            }, 500);
        },

        setupCollaborationListeners() {
            // Listen for user join/leave
            CollaborationService.on('user-joined', (user) => {
                Toast.info(`👋 ${user.username} katıldı`);
                this.updateActiveUsers();
            });

            CollaborationService.on('user-left', (user) => {
                Toast.info(`👋 ${user.username} ayrıldı`);
                this.updateActiveUsers();
            });

            CollaborationService.on('users-updated', () => {
                this.updateActiveUsers();
            });

            // ... existing collaborative listeners ...


            CollaborationService.on('remote-state-change', (state) => {
                // Handle remote changes (e.g., timeline updates)
                console.log('[VideoStudio] Remote state change:', state);

                if (state.timelineClips) {
                    this.mergeRemoteTimelineClips(state.timelineClips, state.userId);
                }

                if (state.selectedClipId) {
                    this.highlightRemoteSelection(state.selectedClipId, state.userId);
                }
            });

            CollaborationService.on('conflict-resolved', (resolution) => {
                console.log('[VideoStudio] Conflict resolved:', resolution);

                if (resolution.strategy === 'last-write-wins' && resolution.winner === 'remote') {
                    // Apply remote changes
                    if (resolution.remoteState.timelineClips) {
                        this.project.tracks = resolution.remoteState.timelineClips;
                        this.renderTimeline();
                    }
                }
            });

            CollaborationService.on('lock-denied', (data) => {
                Toast.warning(`🔒 ${data.lockedBy} bu klibi düzenliyor`);
            });
        },

        // Merge remote timeline clips
        mergeRemoteTimelineClips(remoteClips, userId) {
            console.log('[VideoStudio] Merging remote clips from user:', userId);

            // Simple merge: add clips that don't exist locally
            remoteClips.forEach(remoteClip => {
                const exists = this.project.tracks.video.some(clip => clip.id === remoteClip.id);
                if (!exists) {
                    this.project.tracks.video.push({
                        ...remoteClip,
                        remoteUser: userId // Mark as remote
                    });
                }
            });

            this.renderTimeline();
        },

        // Highlight remote user's selection
        highlightRemoteSelection(clipId, userId) {
            const clipElement = document.querySelector(`[data-clip-id="${clipId}"]`);
            if (clipElement) {
                clipElement.style.border = '2px solid #fbbf24';
                clipElement.setAttribute('title', `Düzenleniyor: ${userId}`);

                // Remove highlight after 3 seconds
                setTimeout(() => {
                    clipElement.style.border = '';
                    clipElement.removeAttribute('title');
                }, 3000);
            }
        },

        // Update collaboration state when timeline changes
        updateCollaborationState() {
            if (typeof CollaborationService !== 'undefined' && CollaborationService.isActive) {
                CollaborationService.updateState({
                    timelineClips: this.project.tracks.video,
                    selectedClipId: this.selectedClip?.id,
                    currentTime: this.currentTime
                });
            }
        },

        updateActiveUsers() {
            const users = CollaborationService.getOtherUsers();
            const container = document.getElementById('vs-user-avatars');
            if (!container) return;

            // Update LIVE indicator in header
            const activeUsersDiv = document.getElementById('vs-active-users');
            if (activeUsersDiv) {
                if (users.length > 0) {
                    if (!document.getElementById('vs-live-badge')) {
                        const badge = document.createElement('div');
                        badge.id = 'vs-live-badge';
                        badge.innerHTML = `<span class="vs-pulse"></span> CANLI`;
                        badge.style.cssText = 'background: #ef4444; color: white; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: 800; margin-right: 8px; display: flex; align-items: center; gap: 4px;';

                        // Add pulse animation style if not exists
                        if (!document.getElementById('vs-pulse-style')) {
                            const s = document.createElement('style');
                            s.id = 'vs-pulse-style';
                            s.innerHTML = `@keyframes vsPulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } } .vs-pulse { width: 6px; height: 6px; background: white; border-radius: 50%; animation: vsPulse 1.5s infinite; }`;
                            document.head.appendChild(s);
                        }

                        activeUsersDiv.insertBefore(badge, activeUsersDiv.firstChild);
                    }
                } else {
                    const badge = document.getElementById('vs-live-badge');
                    if (badge) badge.remove();
                }
            }

            container.innerHTML = users.map(user => `
            <div style="position: relative; width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #8b5cf6, #a78bfa); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 12px; border: 2px solid #16191f; margin-left: -8px; cursor: pointer;" title="${user.username}">
                ${user.username.charAt(0).toUpperCase()}
                <div style="position: absolute; bottom: 0; right: 0; width: 10px; height: 10px; background: #10b981; border: 2px solid #16191f; border-radius: 50%;"></div>
            </div>
        `).join('');
        },

        fetchProjectFiles() {
            const list = document.getElementById('vs-media-list');
            if (!list) return;

            // Convert series title to lowercase slug for folder structure
            const seriesSlug = this.context.seriesTitle
                .toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .replace(/^-|-$/g, '');

            console.log('[VideoStudio] Fetching files for slug:', seriesSlug);

            const formData = new FormData();
            formData.append('seriesTitle', seriesSlug);

            fetch('api/db.php?action=list-project-files', {
                method: 'POST',
                body: formData
            })
                .then(res => {
                    console.log('[VideoStudio] Response status:', res.status);
                    console.log('[VideoStudio] Response headers:', res.headers.get('content-type'));
                    return res.text(); // Get as text first to see what we're receiving
                })
                .then(text => {
                    console.log('[VideoStudio] Raw response:', text.substring(0, 500)); // Log first 500 chars
                    try {
                        const data = JSON.parse(text);
                        if (data.success) {
                            if (data.files.length === 0) {
                                list.innerHTML = `<div style="text-align:center; padding: 20px; color: #64748b; font-size: 12px;">Klasör boş.</div>`;
                            } else {
                                list.innerHTML = this.renderFileTree(data.files);
                            }
                        } else {
                            list.innerHTML = `<div style="color: #ef4444; font-size: 12px;">Hata: ${data.message}</div>`;
                        }
                    } catch (parseError) {
                        console.error('[VideoStudio] JSON parse failed:', parseError);
                        console.error('[VideoStudio] Response text:', text);
                        list.innerHTML = `<div style="color: #ef4444; font-size: 12px;">Sunucu geçersiz yanıt döndü.</div>`;
                    }
                })
                .catch(err => {
                    console.error('File list error:', err);
                    list.innerHTML = `<div style="color: #ef4444; font-size: 12px;">Dosyalar yüklenemedi. Sunucu hatası.</div>`;
                });
        },

        renderFileTree(nodes, level = 0) {
            return nodes.map(node => {
                if (node.type === 'folder') {
                    const isOpen = node.name.includes(`${this.context.episodeNumber}-bolum`); // Auto-open current episode folder
                    return `
                    <div class="vs-tree-item vs-tree-folder ${isOpen ? 'open' : ''}">
                        <div class="vs-tree-content" onclick="this.parentElement.classList.toggle('open'); this.nextElementSibling.classList.toggle('open');">
                            <span class="vs-tree-toggle"><i class="fa-solid fa-chevron-down" style="font-size: 10px;"></i></span>
                            <i class="fa-regular fa-folder" style="color: #64748b;"></i>
                            <span>${node.name}</span>
                        </div>
                        <div class="vs-tree-children ${isOpen ? 'open' : ''}">
                            ${this.renderFileTree(node.children, level + 1)}
                        </div>
                    </div>
                `;
                } else {
                    // File
                    const isVideo = node.name.match(/\.(mp4|webm|mkv)$/i);
                    const isSubtitle = node.name.match(/\.(srt|vtt)$/i);
                    const icon = isVideo ? 'fa-file-video' : (isSubtitle ? 'fa-file-lines' : 'fa-file');
                    const color = isVideo ? '#8b5cf6' : (isSubtitle ? '#f59e0b' : '#64748b');

                    // For onclick, pass url and name
                    return `
                    <div class="vs-tree-item" data-url="${node.url}">
                        <div class="vs-tree-content" onclick="VideoStudioPage.loadRemoteFile('${node.url}', '${node.name}')">
                            <i class="fa-solid ${icon}" style="color: ${color}; margin-left: 16px;"></i>
                            <span style="flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${node.name}</span>
                            
                            <button onclick="event.stopPropagation(); VideoStudioPage.requestFileDeletion('${this.context.seriesId}', '${this.context.episodeNumber}', '${node.url}')" 
                                class="vs-delete-btn"
                                style="background: none; border: none; color: #475569; cursor: pointer; padding: 4px;">
                                <i class="fa-solid fa-trash" style="font-size: 10px;"></i>
                            </button>
                        </div>
                    </div>
                `;
                }
            }).join('');
        },

        requestFileDeletion(seriesId, episodeNumber, url) {
            if (!confirm('Bu dosyayı silmek için istek göndermek istediğinize emin misiniz?')) return;

            const formData = new FormData();
            formData.append('seriesId', seriesId);
            formData.append('episodeNumber', episodeNumber);
            formData.append('clipId', url); // Using URL as ID
            formData.append('reason', 'User requested deletion via Studio');

            fetch('api/db.php?action=request-delete', {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        Toast.success('Silme isteği gönderildi (Admin onayı bekleniyor)');
                    } else {
                        Toast.error(data.message || 'Hata oluştu');
                    }
                });
        },

        loadRemoteFile(url, name) {
            if (!url) return;

            const track = {
                id: 'v_' + Date.now(),
                start: 0,
                duration: 0,
                name: name,
                url: url,
                type: 'video',
                isRemote: true
            };

            this.project.tracks.video = [track];
            document.getElementById('vs-placeholder').style.display = 'none';
            this.renderTimeline();

            this.loadClipToPlayer(track);
            Toast.success('Dosya projeye yüklendi');
        },

        loadClipToPlayer(clip) {
            if (!clip || !clip.url) return;

            const player = document.getElementById('vs-player');
            const iframe = document.getElementById('vs-preview-iframe');

            if (!player || !iframe) return;

            // Reset
            player.style.display = 'none';
            iframe.style.display = 'none';
            player.pause();
            iframe.src = '';

            // Check content type
            const isDrive = clip.url.includes('drive.google.com');
            const isYouTube = clip.url.includes('youtube.com') || clip.url.includes('youtu.be');
            const isEmbed = clip.url.includes('<iframe') || !clip.url.match(/\.(mp4|webm|mkv|mov)$/i);

            if (isDrive || isYouTube || (isEmbed && !clip.url.includes('uploads/'))) {
                // IFRAME MODE
                iframe.style.display = 'block';
                let src = clip.url;

                // Fix Drive URL for preview
                if (isDrive && !src.includes('/preview')) {
                    const idMatch = src.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
                    if (idMatch && idMatch[1]) {
                        src = `https://drive.google.com/file/d/${idMatch[1]}/preview`;
                    }
                }

                iframe.src = src;
            } else {
                // VIDEO MODE
                player.style.display = 'block';
                player.src = clip.url;
                player.load();
            }
        },

        bindEvents() {
            if (!this.player) return;

            this.player.addEventListener('timeupdate', () => this.updateTime());
            this.player.addEventListener('loadedmetadata', () => {
                this.project.duration = this.player.duration;
                if (this.project.tracks.video.length > 0) {
                    this.project.tracks.video[0].duration = this.player.duration;
                }
                this.renderTimeline();
            });
            this.player.addEventListener('click', () => this.togglePlay());
        },

        handleVideoUpload(input) {
            const file = input.files[0];
            if (!file) return;

            // 1. Start Upload immediately
            const uploadId = UploadManager.startUpload(file, {
                seriesId: this.context.seriesId,
                seriesTitle: this.context.seriesTitle,
                episodeNumber: this.context.episodeNumber
            });

            // 2. Add temporary placeholder to list
            const mediaList = document.getElementById('vs-media-list');
            const tempId = `temp-${uploadId}`;

            // Check if there is a 'Uploading' section or just append
            // We'll prepend to make it visible
            const tempItem = document.createElement('div');
            tempItem.id = tempId;
            tempItem.className = 'vs-upload-item';
            tempItem.style.cssText = 'padding: 10px; background: rgba(59, 130, 246, 0.1); border-radius: 8px; margin-bottom: 8px; position: relative; overflow: hidden;';
            tempItem.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                <div style="display: flex; align-items: center; gap: 8px; overflow: hidden;">
                    <i class="fa-solid fa-spinner fa-spin" style="color: #3b82f6;"></i>
                    <span style="font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 150px;">${file.name}</span>
                </div>
                <span class="vs-upload-percent" style="font-size: 10px; font-weight: 700; color: #3b82f6;">0%</span>
            </div>
            <div style="height: 4px; background: rgba(59, 130, 246, 0.2); border-radius: 2px; overflow: hidden;">
                <div class="vs-upload-bar" style="height: 100%; background: #3b82f6; width: 0%; transition: width 0.2s;"></div>
            </div>
        `;

            // Prepend to list
            if (mediaList.firstChild) {
                mediaList.insertBefore(tempItem, mediaList.firstChild);
            } else {
                mediaList.appendChild(tempItem);
            }

            // 3. Listen for events
            const updateProgress = (upload) => {
                if (upload.id !== uploadId) return;
                const el = document.getElementById(tempId);
                if (!el) return;

                el.querySelector('.vs-upload-percent').innerText = Math.round(upload.progress) + '%';
                el.querySelector('.vs-upload-bar').style.width = upload.progress + '%';
            };

            const onComplete = (upload) => {
                if (upload.id !== uploadId) return;
                UploadManager.off('progress', updateProgress);
                UploadManager.off('complete', onComplete);

                const el = document.getElementById(tempId);
                if (el) el.remove();

                Toast.success('Dosya yüklendi');
                this.fetchProjectFiles(); // Refresh list to get the real file
            };

            const onError = (upload) => {
                if (upload.id !== uploadId) return;
                UploadManager.off('progress', updateProgress);
                UploadManager.off('complete', onComplete);

                const el = document.getElementById(tempId);
                if (el) {
                    el.style.background = 'rgba(239, 68, 68, 0.1)';
                    el.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 8px; color: #ef4444;">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <span style="font-size: 11px;">Yükleme Hatası</span>
                    </div>
                `;
                }
                Toast.error('Yükleme başarısız');
            };

            UploadManager.on('progress', updateProgress);
            UploadManager.on('complete', onComplete);
            UploadManager.on('error', onError);
        },

        handleSRTUpload(input) {
            const file = input.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (e) => {
                const srtData = this.parseSRT(e.target.result);
                this.project.tracks.subtitle = srtData.map((s, i) => ({
                    id: 'srt_' + i,
                    start: s.start,
                    duration: s.duration,
                    name: 'Altyazı ' + (i + 1),
                    text: s.text,
                    type: 'subtitle',
                    file: file
                }));

                this.renderTimeline();

                const mediaList = document.getElementById('vs-media-list');
                mediaList.innerHTML += `
                <div style="padding: 10px; background: rgba(167, 139, 250, 0.1); border-radius: 8px; margin-bottom: 8px;">
                    <i class="fa-solid fa-closed-captioning" style="color: #a78bfa;"></i> ${file.name} (${srtData.length} blok)
                </div>
            `;

                Toast.success(`${srtData.length} altyazı bloğu yüklendi`);
            };
            reader.readAsText(file);
        },

        parseSRT(data) {
            // Normalize line endings and split double newlines
            const blocks = data.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n\n');
            const items = [];
            // Robust regex: allows dot or comma for ms, flexible spacing
            const timeRegex = /(\d{1,2}:\d{2}:\d{2}[,.]\d{3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[,.]\d{3})/;

            blocks.forEach((block, idx) => {
                const lines = block.trim().split('\n');
                if (lines.length >= 2) {
                    // Try to find timing in 2nd line, or fallback to 1st if no index line
                    let timeLine = lines[1];
                    let textLines = lines.slice(2);

                    // Check if first line is actually timestamp (missing index case)
                    if (timeRegex.test(lines[0])) {
                        timeLine = lines[0];
                        textLines = lines.slice(1);
                    }

                    const match = timeRegex.exec(timeLine);
                    if (match) {
                        const start = this.srtTimeToSeconds(match[1]);
                        const end = this.srtTimeToSeconds(match[2]);

                        if (!isNaN(start) && !isNaN(end)) {
                            items.push({
                                start: start,
                                duration: end - start,
                                text: textLines.join(' ')
                            });
                        }
                    }
                }
            });
            console.log(`[VideoStudio] Parsed ${items.length} subtitle items.`);
            return items;
        },

        srtTimeToSeconds(timeStr) {
            if (!timeStr) return 0;
            // Handle comma or dot
            const [hms, ms] = timeStr.replace('.', ',').split(',');
            const [h, m, s] = hms.split(':').map(parseFloat);
            return (h * 3600) + (m * 60) + s + (parseFloat(ms) / 1000);
        },

        async addFromUrl() {
            const url = prompt("Lütfen video bağlantısını (MP4/M3U8) veya Google Drive linkini girin:");
            if (!url) return;

            let finalUrl = url.trim();
            let isDirect = false;
            let defaultName = 'Remote Video';

            // --- Google Drive Converter ---
            const gDriveMatch = finalUrl.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
            if (gDriveMatch && gDriveMatch[1]) {
                const fileId = gDriveMatch[1];
                // Use PREVIEW link for Studio playback/iframe
                finalUrl = `https://drive.google.com/file/d/${fileId}/preview`;
                isDirect = false; // It's an embed now
                defaultName = 'DRB (Drive)';
                Toast.info('Google Drive önizleme linkine dönüştürüldü.');
            }
            // --- Dropbox Converter ---
            else if (finalUrl.includes('dropbox.com')) {
                finalUrl = finalUrl.replace('dl=0', 'dl=1').replace('raw=0', 'raw=1');
                isDirect = true;
            }

            // --- Iframe / Embed Handling ---
            if (finalUrl.startsWith('<iframe') || finalUrl.includes('src=')) {
                const srcMatch = finalUrl.match(/src=["'](.*?)["']/);
                if (srcMatch && srcMatch[1]) {
                    finalUrl = srcMatch[1];
                    Toast.info('Iframe içinden URL alındı.');
                }
            }

            // Validation
            if (!finalUrl.startsWith('http') && !finalUrl.includes('drive.google.com')) {
                Toast.error('Geçerli bir URL girmelisiniz.');
                return;
            }

            // Ask for Name (with smart default)
            const sourceName = prompt("Kaynak adı ne olsun?", defaultName);
            if (!sourceName) return; // User cancelled

            const id = 'video-' + Date.now();
            const newTrack = {
                id: id,
                type: 'video',
                name: sourceName,
                src: finalUrl,
                isRemote: true,
                start: 0,
                duration: 600,
                offset: 0
            };

            this.project.tracks.video.push(newTrack);
            this.renderTimeline();

            this.selectClip(newTrack.id, 'video');

            // Try to load metadata to get duration
            const tempVideo = document.createElement('video');
            tempVideo.src = finalUrl;
            tempVideo.onloadedmetadata = () => {
                newTrack.duration = tempVideo.duration;
                this.renderTimeline();
                this.loadClipToPlayer(newTrack);
            };
            // Fallback load
            this.loadClipToPlayer(newTrack);

            Toast.success(`"${sourceName}" eklendi!`);
        },

        addText() {
            const id = `txt-${Date.now()}`;
            const newText = {
                id,
                start: this.currentTime,
                duration: 5,
                name: 'Yeni Metin',
                text: 'BURAYA YAZIN',
                type: 'text',
                style: { color: '#ffffff', size: 24 }
            };
            this.project.tracks.text.push(newText);
            this.renderTimeline();
            this.selectClip(newText);
            Toast.info('Metin eklendi');
        },

        togglePlay() {
            if (!this.player) return;

            if (this.player.paused) {
                this.player.play();
                this.isPlaying = true;
            } else {
                this.player.pause();
                this.isPlaying = false;
            }

            const icon = document.getElementById('vs-play-icon');
            if (icon) {
                icon.className = this.isPlaying ? 'fa-solid fa-pause' : 'fa-solid fa-play';
            }
        },

        seek(delta) {
            if (this.player) {
                this.player.currentTime = Math.max(0, Math.min(this.project.duration, this.player.currentTime + delta));
            }
        },

        updateTime() {
            this.currentTime = this.player.currentTime;
            const fmt = (t) => {
                const m = Math.floor(t / 60);
                const s = Math.floor(t % 60);
                return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            };

            const timeDisplay = document.getElementById('vs-time-display');
            if (timeDisplay) {
                timeDisplay.innerText = `${fmt(this.currentTime)} / ${fmt(this.project.duration)}`;
            }

            const playhead = document.getElementById('vs-playhead');
            if (playhead) {
                playhead.style.left = (this.currentTime * this.zoomLevel + 120) + 'px';
            }

            this.renderSubtitleDisplay();
        },

        renderSubtitleDisplay() {
            const layer = document.getElementById('vs-overlay-layer');
            if (!layer) return;

            const activeSub = this.project.tracks.subtitle.find(s =>
                this.currentTime >= s.start && this.currentTime <= (s.start + s.duration)
            );

            if (activeSub) {
                let el = document.getElementById('vs-active-subtitle');
                if (!el) {
                    el = document.createElement('div');
                    el.id = 'vs-active-subtitle';
                    el.style.cssText = 'position: absolute; bottom: 15%; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,0.7); color: white; padding: 8px 24px; border-radius: 8px; font-size: 20px; text-align: center; max-width: 80%; font-weight: 500;';
                    layer.appendChild(el);
                }
                el.innerText = activeSub.text;
                el.style.opacity = '1';
            } else {
                const el = document.getElementById('vs-active-subtitle');
                if (el) el.style.opacity = '0';
            }
        },

        renderTimeline() {
            const container = document.getElementById('vs-timeline-tracks');
            if (!container) return;

            const trackTypes = [
                { key: 'video', label: 'VIDEO', icon: 'fa-video', color: '#2563eb' },
                { key: 'audio', label: 'AUDIO', icon: 'fa-music', color: '#059669' },
                { key: 'subtitle', label: 'SUBTITLE', icon: 'fa-closed-captioning', color: '#7c3aed' },
                { key: 'text', label: 'TEXT', icon: 'fa-font', color: '#d97706' }
            ];

            // Ensure styles are present
            if (!document.getElementById('vs-timeline-styles')) {
                const style = document.createElement('style');
                style.id = 'vs-timeline-styles';
                style.innerHTML = `
                .vs-clip { transition: opacity 0.2s; user-select: none; }
                .vs-clip:hover { z-index: 100 !important; }
                .vs-resize-handle {
                    position: absolute; top: 0; bottom: 0; width: 10px; cursor: col-resize; z-index: 20;
                    display: flex; align-items: center; justify-content: center;
                    opacity: 0; transition: opacity 0.1s; background: rgba(0,0,0,0.2);
                }
                .vs-clip:hover .vs-resize-handle, .vs-clip.selected .vs-resize-handle { opacity: 1; }
                .vs-resize-handle.left { left: 0; border-radius: 6px 0 0 6px; border-right: 1px solid rgba(255,255,255,0.3); }
                .vs-resize-handle.right { right: 0; border-radius: 0 6px 6px 0; border-left: 1px solid rgba(255,255,255,0.3); }
                .vs-resize-handle::after { content: ''; height: 12px; width: 2px; background: white; border-radius: 1px; }
            `;
                document.head.appendChild(style);
            }

            container.innerHTML = trackTypes.map(track => {
                const clips = this.project.tracks[track.key] || [];
                return `
                <div style="height: 48px; border-bottom: 1px solid rgba(30, 41, 59, 0.5); display: flex; align-items: center; position: relative;">
                    <div style="width: 120px; flex-shrink: 0; height: 100%; background: #16191f; border-right: 1px solid #1e293b; display: flex; align-items: center; padding: 0 16px; position: sticky; left: 0; z-index: 30;">
                        <span style="font-size: 9px; font-weight: 900; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">
                            <i class="fa-solid ${track.icon}" style="font-size: 12px; color: ${track.color}; margin-right: 8px;"></i>
                            ${track.label}
                        </span>
                    </div>
                    <div style="flex: 1; height: 100%; position: relative; min-width: 3000px; background: repeating-linear-gradient(90deg, #1e293b 0, #1e293b 1px, transparent 1px, transparent 100px) 0 0 / 100px 100%;">
                        ${clips.map(clip => {
                    const isSelected = this.selectedClip && this.selectedClip.id === clip.id;
                    return `
                                <div 
                                    class="vs-clip ${isSelected ? 'selected' : ''}"
                                    data-clip-id="${clip.id}"
                                    data-track-type="${track.key}"
                                    onclick="event.stopPropagation(); VideoStudioPage.selectClip('${clip.id}', '${track.key}')"
                                    style="position: absolute; top: 6px; height: 32px; left: ${clip.start * this.zoomLevel}px; width: ${clip.duration * this.zoomLevel}px; background: ${track.color}; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 700; color: white; ${isSelected ? 'outline: 2px solid white; z-index: 20;' : 'opacity: 0.8;'} border-top: 1px solid rgba(255,255,255,0.1); overflow: visible;">
                                    
                                    <!-- Resize Handles -->
                                    <div class="vs-resize-handle left" onmousedown="event.stopPropagation(); VideoStudioPage.startResize(event, '${clip.id}', '${track.key}', 'left')"></div>
                                    
                                    <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; padding: 0 12px; pointer-events: none;">${clip.name}</span>
                                    
                                    <div class="vs-resize-handle right" onmousedown="event.stopPropagation(); VideoStudioPage.startResize(event, '${clip.id}', '${track.key}', 'right')"></div>
                                </div>
                            `;
                }).join('')}
                    </div>
                </div>
            `;
            }).join('');
        },

        startResize(e, clipId, trackType, handle) {
            e.preventDefault();
            this.resizeState = {
                active: true,
                clipId,
                trackType,
                handle,
                startX: e.clientX,
                originalStart: 0,
                originalDuration: 0,
                clip: null
            };

            const clip = this.project.tracks[trackType].find(c => c.id === clipId);
            if (!clip) return;

            this.resizeState.clip = clip;
            this.resizeState.originalStart = clip.start;
            this.resizeState.originalDuration = clip.duration;

            // Add global listeners
            document.addEventListener('mousemove', this.handleResizeMove);
            document.addEventListener('mouseup', this.handleResizeUp);
        },

        handleResizeMove: (e) => {
            // Must use VideoStudioPage reference since this is unbound
            const vs = VideoStudioPage;
            if (!vs.resizeState || !vs.resizeState.active) return;

            const deltaPixels = e.clientX - vs.resizeState.startX;
            const deltaSeconds = deltaPixels / vs.zoomLevel;
            const clip = vs.resizeState.clip;

            if (vs.resizeState.handle === 'right') {
                // Adjust duration
                const newDuration = Math.max(0.1, vs.resizeState.originalDuration + deltaSeconds);
                clip.duration = newDuration;
            } else if (vs.resizeState.handle === 'left') {
                // Adjust start and duration (start moves right = duration shrinks)
                // Ensure start >= 0
                const newStart = Math.max(0, vs.resizeState.originalStart + deltaSeconds);
                const durationChange = vs.resizeState.originalStart - newStart; // if start increased, duration decreases

                // Limit: can't make duration < 0.1
                // Max start is originalStart + originalDuration - 0.1
                if (newStart < (vs.resizeState.originalStart + vs.resizeState.originalDuration - 0.1)) {
                    clip.start = newStart;
                    clip.duration = vs.resizeState.originalDuration - (newStart - vs.resizeState.originalStart);
                }
            }

            vs.renderTimeline();
        },

        handleResizeUp: () => {
            const vs = VideoStudioPage;
            if (vs.resizeState && vs.resizeState.active) {
                vs.resizeState.active = false;
                document.removeEventListener('mousemove', vs.handleResizeMove);
                document.removeEventListener('mouseup', vs.handleResizeUp);
                vs.renderInspector(); // Update values in inspector
                vs.updateCollaborationState();
            }
        },

        selectClip(clipId, trackType) {
            if (typeof clipId === 'object') {
                // Legacy support if object is passed directly
                this.selectedClip = clipId;
            } else {
                this.selectedClip = this.project.tracks[trackType].find(c => c.id === clipId);
            }

            this.renderTimeline();
            this.renderInspector();

            // Auto-switch tabs based on type
            if (this.selectedClip && (this.selectedClip.type === 'subtitle' || trackType === 'subtitle')) {
                this.switchTab('subtitles');
                this.renderSubtitleList(); // Ensure list highlights the item
            } else {
                this.switchTab('properties');
            }
        },

        renderInspector() {
            const container = document.getElementById('vs-inspector-content');
            if (!container) return;

            if (!this.selectedClip) {
                container.innerHTML = `
                <div style="height: 160px; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #475569; border: 2px dashed #1e293b; border-radius: 16px;">
                    <i class="fa-solid fa-sliders" style="font-size: 32px; margin-bottom: 8px; opacity: 0.2;"></i>
                    <p style="font-size: 12px;">Klip seçilmedi</p>
                </div>
            `;
                return;
            }

            container.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 24px;">
                <div>
                    <label style="display: block; font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: 700; margin-bottom: 8px;">Klip İsmi</label>
                    <input type="text" value="${this.selectedClip.name}" onchange="VideoStudioPage.updateClipProp('name', this.value)" style="width: 100%; background: #0f1115; border: 1px solid #334155; border-radius: 6px; padding: 8px; color: #e2e8f0; font-size: 14px;">
                </div>

                ${(this.selectedClip.type === 'text' || this.selectedClip.type === 'subtitle') ? `
                    <div>
                        <label style="display: block; font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: 700; margin-bottom: 8px;">İçerik</label>
                        <textarea rows="4" onchange="VideoStudioPage.updateClipProp('text', this.value)" style="width: 100%; background: #0f1115; border: 1px solid #334155; border-radius: 6px; padding: 8px; color: #e2e8f0; font-size: 14px; resize: none;">${this.selectedClip.text || ''}</textarea>
                    </div>
                ` : ''}

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div>
                        <label style="display: block; font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: 700; margin-bottom: 8px;">Başlangıç (sn)</label>
                        <input type="number" value="${this.selectedClip.start.toFixed(2)}" disabled style="width: 100%; background: rgba(15, 17, 21, 0.5); border: 1px solid #1e293b; border-radius: 6px; padding: 8px; color: #64748b; font-size: 14px;">
                    </div>
                    <div>
                        <label style="display: block; font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: 700; margin-bottom: 8px;">Süre (sn)</label>
                        <input type="number" value="${this.selectedClip.duration.toFixed(2)}" disabled style="width: 100%; background: rgba(15, 17, 21, 0.5); border: 1px solid #1e293b; border-radius: 6px; padding: 8px; color: #64748b; font-size: 14px;">
                    </div>
                </div>

                <button onclick="VideoStudioPage.deleteClip()" style="width: 100%; padding: 8px; background: rgba(127, 29, 29, 0.2); border: 1px solid rgba(127, 29, 29, 0.3); color: #ef4444; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <i class="fa-solid fa-trash-can-arrow-up" style="font-size: 14px;"></i> Klip Silme İsteği Gönder
                </button>
            </div>
        `;
        },

        updateClipProp(prop, value) {
            if (!this.selectedClip) return;

            this.selectedClip[prop] = value;

            Object.keys(this.project.tracks).forEach(type => {
                const idx = this.project.tracks[type].findIndex(c => c.id === this.selectedClip.id);
                if (idx !== -1) {
                    this.project.tracks[type][idx][prop] = value;
                }
            });

            this.renderTimeline();
            this.renderSubtitleDisplay();
        },

        async deleteClip() {
            if (!this.selectedClip) {
                Toast.warning('Klip seçilmedi');
                return;
            }

            const isAdmin = State.currentUser && State.currentUser.role === 'admin';

            // ADMIN LOGIC: Direct Delete
            if (isAdmin) {
                const confirmed = confirm('Bu klip kalıcı olarak silinecek. Emin misiniz?');
                if (!confirmed) return;

                // Logic to remove from tracks
                Object.keys(this.project.tracks).forEach(type => {
                    this.project.tracks[type] = this.project.tracks[type].filter(c => c.id !== this.selectedClip.id);
                });

                this.selectedClip = null;
                this.renderTimeline();
                this.renderInspector();
                this.renderSubtitleDisplay();
                Toast.success('Klip başarıyla silindi.');
                return;
            }

            // TRANSLATOR LOGIC: Request Delete
            const confirmed = confirm('Bu klibi silmek için yönetici onayı gerekmektedir. Silme isteği gönderilsin mi?');
            if (!confirmed) return;

            // Reason prompt
            const reason = prompt('Lütfen silme sebebinizi belirtin:', 'Hatalı yükleme');
            if (reason === null) return;

            try {
                // Send request to backend
                const formData = new FormData();
                formData.append('seriesId', this.context.seriesId);
                formData.append('episodeNumber', this.context.episodeNumber);
                // CRITICAL: Send URL if available, fallback to ID. Backend needs URL to match source.
                formData.append('clipId', this.selectedClip.url || this.selectedClip.id);
                formData.append('reason', reason);

                const response = await fetch('api/db.php?action=request-delete', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    Toast.success('Silme isteği yöneticiye gönderildi. Onaylandığında işlem tamamlanacaktır.');
                    this.selectedClip = null;
                    this.renderInspector();
                } else {
                    Toast.error('Hata: ' + (data.message || 'İstek gönderilemedi'));
                }
            } catch (e) {
                console.error(e);
                Toast.error('Bir hata oluştu');
            }


        },

        async saveAndUpload() {
            if (!confirm('Bu işlem videoyu sunucuya yükleyecektir (veya linkleri kaydedecektir). Devam edilsin mi?')) return;

            const videoTracks = this.project.tracks.video;
            if (videoTracks.length === 0) {
                alert('Yüklenecek video yok.');
                return;
            }

            const seriesTitle = this.context.seriesTitle;
            const episodeNumber = this.context.episodeNumber;

            // 1. Handle Remote Videos (No Upload Needed)
            const remoteTracks = videoTracks.filter(t => t.isRemote && t.src);
            for (const track of remoteTracks) {
                console.log('Saving remote track:', track.src);
                // Pass the custom name (e.g. "Drive", "Moly") to the function
                await this.addToEpisodeSources(track.src, track.name || 'Remote Video');
            }

            // 2. Handle File Uploads
            const filesToUpload = videoTracks.filter(t => t.file instanceof File);

            if (filesToUpload.length > 0) {
                if (typeof UploadManager === 'undefined') {
                    Toast.error('UploadManager bulunamadı!');
                    return;
                }

                for (const videoTrack of filesToUpload) {
                    const uploadId = UploadManager.startUpload(videoTrack.file, {
                        seriesId: this.context.seriesId,
                        seriesTitle: seriesTitle,
                        episodeNumber: episodeNumber
                    });
                }

                Toast.info('Video yüklemesi baloncuk sistemine eklendi. Arka planda devam edecek.');
            } else {
                // Already remote URL?
                Toast.info('Bu video zaten yüklü görünüyor veya URL tabanlı.');
            }

            // Add all remote tracks (including the one if it's the only one)
            // This logic needed fixing to ensure remote tracks are added
            if (remoteTracks.length > 0) {
                Toast.success('Video kaynakları güncellendi.');
            }

            // Subtitle Upload (Fast, so do it sync)
            if (this.project.tracks.subtitle.length > 0) {
                const hasNewSubtitle = this.project.tracks.subtitle.some(s => s.file);
                if (hasNewSubtitle) {
                    try {
                        await this.uploadSubtitle(seriesTitle, episodeNumber);
                        Toast.success('Altyazı güncellendi.');
                    } catch (e) {
                        console.error('Subtitle upload failed', e);
                        Toast.warning('Altyazı yüklenemedi: ' + e.message);
                    }
                }
            }

            // Close Studio logic - Allow UI to update first
            setTimeout(() => {
                this.close();
                // Refresh Admin Content if active
                if (typeof AdminContent !== 'undefined' && typeof AdminContent.showContentManagement === 'function') {
                    AdminContent.showContentManagement();
                }
            }, 1500);
        },

        async uploadSubtitle(seriesTitle, episodeNumber) {
            // Handle all new subtitle files
            const newSubs = this.project.tracks.subtitle.filter(s => s.file);
            if (newSubs.length === 0) return;

            const srtClip = newSubs[0];

            try {
                const formData = new FormData();
                formData.append('seriesTitle', seriesTitle);
                formData.append('episodeNumber', episodeNumber);
                formData.append('subtitle', srtClip.file);

                const response = await fetch('api/db.php?action=upload-subtitle', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();
                if (!result.success) {
                    throw new Error(result.message);
                }
            } catch (error) {
                throw error;
            }
        },

        async addToEpisodeSources(videoUrl, sourceName = 'DRB') {
            try {
                console.log('[VideoStudio] Adding source to episode:', {
                    seriesId: this.context.seriesId,
                    episodeNumber: this.context.episodeNumber,
                    url: videoUrl,
                    name: sourceName
                });

                // Get series from State.data instead of db helper
                const series = State.data.series.find(s => s.id == this.context.seriesId);
                if (!series) {
                    console.error('[VideoStudio] Series not found:', this.context.seriesId);
                    Toast.error('Dizi bulunamadı!');
                    return;
                }

                let episode = null;
                let foundInSeasons = false;

                // Check if series has seasons
                if (series.seasons && Array.isArray(series.seasons)) {
                    // Search in seasons
                    for (let season of series.seasons) {
                        if (season.episodes && Array.isArray(season.episodes)) {
                            episode = season.episodes.find(ep => ep.number == this.context.episodeNumber);
                            if (episode) {
                                foundInSeasons = true;
                                break;
                            }
                        }
                    }
                }

                // If not found in seasons, check flat episodes array
                if (!episode && series.episodes && Array.isArray(series.episodes)) {
                    episode = series.episodes.find(ep => ep.number == this.context.episodeNumber);
                }

                if (!episode) {
                    console.error('[VideoStudio] Episode not found:', this.context.episodeNumber);
                    Toast.error('Bölüm bulunamadı!');
                    return;
                }

                // Initialize sources array if not exists
                if (!episode.sources) {
                    episode.sources = [];
                }

                // Check for duplicates
                const isDuplicate = episode.sources.some(s =>
                    (s.url === videoUrl) || (s.src === videoUrl)
                );

                if (isDuplicate) {
                    console.log('[VideoStudio] Source already exists, skipping');
                    Toast.info('Bu kaynak zaten ekli.');
                    return;
                }

                // Add new source with dual format
                const newSource = {
                    name: sourceName,
                    url: videoUrl,
                    // New format for compatibility
                    label: sourceName,
                    src: videoUrl,
                    type: 'video/mp4',
                    quality: '1080p'
                };

                episode.sources.push(newSource);

                // Also update videoUrl for backward compatibility
                if (!episode.videoUrl) {
                    episode.videoUrl = videoUrl;
                }

                console.log('[VideoStudio] Source added successfully:', newSource);

                // Save to database
                await db.updateSeries(this.context.seriesId, series);

                Toast.success(`"${sourceName}" kaynağı eklendi!`);

                console.log('[VideoStudio] Database updated successfully');
            } catch (error) {
                console.error('[VideoStudio] Add to sources error:', error);
                Toast.error('Kaynak eklenirken hata oluştu: ' + error.message);
            }
        },

        // --- NEW TABS & SUBTITLE LOGIC ---

        switchTab(tabName) {
            document.querySelectorAll('.vs-tab').forEach(t => {
                t.style.color = '#94a3b8';
                t.style.borderBottomColor = 'transparent';
            });
            document.getElementById(`tab-${tabName}`).style.color = '#e2e8f0';
            document.getElementById(`tab-${tabName}`).style.borderBottomColor = '#8b5cf6';

            document.getElementById('vs-panel-properties').style.display = tabName === 'properties' ? 'block' : 'none';
            document.getElementById('vs-panel-subtitles').style.display = tabName === 'subtitles' ? 'block' : 'none';

            if (tabName === 'subtitles') {
                this.renderSubtitleList();
            }
        },

        renderSubtitleList() {
            const container = document.getElementById('vs-subtitle-list');
            if (!container) return;

            // Sort subtitles by start time
            const subs = this.project.tracks.subtitle.sort((a, b) => a.start - b.start);

            container.innerHTML = subs.map((sub, index) => `
            <div id="sub-item-${sub.id}" class="vs-sub-item ${this.selectedClip && this.selectedClip.id === sub.id ? 'active' : ''}" 
                 style="background: #1e293b; border: 1px solid ${this.selectedClip && this.selectedClip.id === sub.id ? '#8b5cf6' : '#334155'}; border-radius: 6px; padding: 10px; cursor: pointer; transition: all 0.2s;"
                 onclick="VideoStudioPage.jumpToSubtitle('${sub.id}')">
                
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 11px; color: #94a3b8;">
                    <span>#${index + 1}</span>
                    <div style="display: flex; gap: 8px;">
                        <span style="font-family: monospace;">${this.formatTime(sub.start)}</span>
                        <span>-</span>
                        <span style="font-family: monospace;">${this.formatTime(sub.start + sub.duration)}</span>
                    </div>
                </div>

                <textarea 
                    oninput="VideoStudioPage.updateSubtitleText('${sub.id}', this.value)"
                    onclick="event.stopPropagation()"
                    style="width: 100%; background: #0f1115; border: 1px solid #334155; border-radius: 4px; padding: 6px; color: #e2e8f0; font-size: 13px; resize: none; min-height: 50px;">${sub.text || ''}</textarea>
                
                <div style="display: flex; justify-content: flex-end; margin-top: 4px;">
                     <button onclick="event.stopPropagation(); VideoStudioPage.deleteSubtitle('${sub.id}')" style="background: none; border: none; color: #ef4444; cursor: pointer; font-size: 11px;">
                        <i class="fa-solid fa-trash"></i> Sil
                     </button>
                </div>
            </div>
        `).join('');

            // Auto-scroll to active
            if (this.selectedClip) {
                const el = document.getElementById(`sub-item-${this.selectedClip.id}`);
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        },

        addSubtitle() {
            const currentTime = this.player ? this.player.currentTime : 0;
            const newSub = {
                id: 'srt_' + Date.now(),
                start: currentTime,
                duration: 2, // Default 2 seconds
                name: 'Yeni Altyazı',
                text: '',
                type: 'subtitle',
                style: { color: '#ffffff' }
            };

            this.project.tracks.subtitle.push(newSub);
            this.renderTimeline();
            this.switchTab('subtitles'); // Switch to tab
            this.selectClip(newSub, 'subtitle'); // Select it

            // Focus textarea
            setTimeout(() => {
                const el = document.getElementById(`sub-item-${newSub.id}`);
                if (el) {
                    const ta = el.querySelector('textarea');
                    if (ta) ta.focus();
                }
            }, 100);
        },

        updateSubtitleText(id, text) {
            const sub = this.project.tracks.subtitle.find(s => s.id === id);
            if (sub) {
                sub.text = text;
                this.renderSubtitleDisplay(); // Update live overlay
            }
        },

        jumpToSubtitle(id) {
            const sub = this.project.tracks.subtitle.find(s => s.id === id);
            if (sub) {
                this.player.currentTime = sub.start;
                this.selectClip(sub, 'subtitle');
            }
        },

        deleteSubtitle(id) {
            if (confirm('Bu altyazıyı silmek istediğinize emin misiniz?')) {
                this.project.tracks.subtitle = this.project.tracks.subtitle.filter(s => s.id !== id);
                this.renderTimeline();
                this.renderSubtitleList();
                this.renderSubtitleDisplay();
            }
        },

        formatTime(seconds) {
            if (!seconds && seconds !== 0) return '00:00';
            const m = Math.floor(seconds / 60);
            const s = Math.floor(seconds % 60);
            const ms = Math.floor((seconds % 1) * 10);
            return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}.${ms}`;
        },

        async saveDraft(showToast = true) {
            try {
                // First we need to extract subtitles from tracks
                const subtitleTrack = this.project.tracks.subtitle || [];
                if (subtitleTrack.length === 0 && !confirm('Altyazı bulunamadı. Boş taslak kaydedilsin mi?')) return;

                // Map internal tracks to simple subtitle format
                const simpleSubs = subtitleTrack.map(s => ({
                    id: s.id,
                    start: s.start,
                    end: s.start + s.duration, // Convert duration back to end time if needed or store duration
                    duration: s.duration,
                    text: s.text
                }));

                const payload = {
                    seriesId: this.context.seriesId,
                    epNum: this.context.episodeNumber,
                    subtitles: simpleSubs,
                    userId: State.currentUser ? State.currentUser.username : 'Guest'
                };

                const res = await fetch('api/db.php?action=translation-save', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const result = await res.json();

                if (result.success) {
                    if (showToast) Toast.success('Taslak başarıyla sunucuya kaydedildi.');
                } else {
                    Toast.error('Kaydetme hatası: ' + result.message);
                }
            } catch (e) {
                console.error('Save failed', e);
                Toast.error('Kaydetme başarısız: Sunucu hatası');
            }
        },

        async submitForApproval() {
            if (!confirm('Çeviriyi tamamladıysanız yönetici onayına gönderilecektir. Devam edilsin mi?')) return;

            // Save first to ensure latest version is submitted
            await this.saveDraft(false);

            try {
                const res = await fetch('api/db.php?action=translation-submit', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        seriesId: this.context.seriesId,
                        epNum: this.context.episodeNumber
                    })
                });
                const result = await res.json();

                if (result.success) {
                    Toast.success('Başarıyla onaya gönderildi! Yönetici paneline iletildi.');
                    this.close();
                } else {
                    Toast.error('Gönderim hatası: ' + result.message);
                }
            } catch (e) {
                console.error('Submit failed', e);
                Toast.error('Gönderim başarısız');
            }
        },

        close() {
            console.log('🔴 Closing Video Studio');

            // Leave collaborative session
            if (typeof CollaborationService !== 'undefined' && CollaborationService.isActive) {
                CollaborationService.leaveSession();
            }

            // Cleanup Plyr
            if (this.player && this.player.plyr) {
                this.player.plyr.destroy();
            }

            // Remove container
            const container = document.getElementById('video-studio-root');
            if (container) {
                container.remove();
            }

            // Show main app
            const navbar = document.getElementById('main-navbar');
            const appContainer = document.getElementById('app-container');
            if (navbar) navbar.style.display = '';
            if (appContainer) appContainer.style.display = '';

            // Navigate back if we arrived via hash, otherwise just stay here
            if (window.location.hash.includes('studio') || window.location.hash.includes('video-studio')) {
                window.history.back();
            } else {
                // If opened as overlay, ensure we are back to a safe state
                if (window.AdminPanel && typeof AdminPanel.show === 'function') {
                    // Re-render admin panel if we were there
                }
            }
        },


        showVidmolySettings() {
            const isAdmin = State.currentUser?.role === 'admin' || State.currentUser?.badges?.includes('Admin');
            const modal = document.createElement('div');
            modal.className = 'modal auth-modal show';
            modal.style.display = 'flex';
            modal.id = 'vidmoly-settings-modal';
            modal.innerHTML = `
                <div class="modal-content" style="max-width: 450px; padding: 30px; border-radius: 24px; background: #0f172a; border: 1px solid rgba(139, 92, 246, 0.4); box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);">
                    <div style="text-align: center; margin-bottom: 25px;">
                        <div style="width: 64px; height: 64px; background: linear-gradient(135deg, #1e293b, #0f172a); border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 18px; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;">
                            <i class="fa-solid fa-cloud-arrow-up" style="font-size: 32px; color: #8b5cf6;"></i>
                        </div>
                        <h2 style="color: #fff; margin: 0; font-size: 1.6rem; font-weight: 800; letter-spacing: -0.5px;">Vidmoly Stüdyo</h2>
                        <p style="color: #64748b; font-size: 0.95rem; margin-top: 8px;">Merkezi Dramicbox hesabına video yükleyin.</p>
                    </div>

                    <div id="vidmoly-upload-section" style="padding: 24px; background: rgba(255,255,255,0.03); border: 1px dashed rgba(139, 92, 246, 0.2); border-radius: 20px; transition: all 0.2s;">
                        <label style="display: block; cursor: pointer; text-align: center;">
                            <i class="fa-solid fa-file-video" style="font-size: 40px; color: #6366f1; margin-bottom: 12px; opacity: 0.8;"></i>
                            <div style="font-size: 14px; font-weight: 700; color: #e2e8f0; margin-bottom: 4px;">Video Dosyası Seç</div>
                            <div style="font-size: 11px; color: #64748b;">(Maksimum 2GB)</div>
                            <input type="file" id="vidmoly-file-input" accept="video/*" style="display:none;" onchange="VideoStudioPage.handleVidmolyFileChange(this)">
                        </label>
                    </div>

                    <div id="vidmoly-upload-progress" style="display: none; margin-top: 20px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                            <span style="font-size: 12px; color: #94a3b8; font-weight: 600;" id="vidmoly-upload-name">Yükleniyor...</span>
                            <span style="font-size: 12px; color: #8b5cf6; font-weight: 800;" id="vidmoly-upload-pct">0%</span>
                        </div>
                        <div style="height: 6px; background: rgba(139, 92, 246, 0.1); border-radius: 3px; overflow: hidden;">
                            <div id="vidmoly-upload-bar" style="height: 100%; background: linear-gradient(90deg, #8b5cf6, #d946ef); width: 0%; transition: width 0.3s cubic-bezier(0.1, 0.7, 0.1, 1);"></div>
                        </div>
                    </div>

                    <div id="vidmoly-result-section" style="display: none; margin-top: 20px; padding: 16px; background: rgba(16, 185, 129, 0.05); border: 1px solid rgba(16, 185, 129, 0.2); border-radius: 14px;">
                        <div style="display: flex; align-items: center; gap: 10px; color: #10b981; font-weight: 700; font-size: 13px; margin-bottom: 8px;">
                            <i class="fa-solid fa-circle-check"></i> Başarıyla Vidmoly'e Yüklendi!
                        </div>
                        <div style="display: flex; gap: 8px;">
                            <input type="text" id="vidmoly-result-url" readonly style="flex: 1; padding: 8px 12px; background: #000; border: 1px solid #334155; border-radius: 8px; color: #e2e8f0; font-size: 11px; font-family: monospace;">
                            <button onclick="VideoStudioPage.copyVidmolyUrl()" style="padding: 8px 12px; background: #334155; border: none; border-radius: 8px; color: #fff; cursor: pointer;"><i class="fa-solid fa-copy"></i></button>
                        </div>
                        <button onclick="VideoStudioPage.applyVidmolyToProject()" style="width: 100%; margin-top: 12px; padding: 10px; background: #10b981; border: none; border-radius: 8px; color: #fff; font-weight: 700; cursor: pointer;">Projeye Ekle</button>
                    </div>

                    <div style="margin-top: 35px; border-top: 1px solid #1e293b; padding-top: 20px;">
                        <button onclick="document.getElementById('vidmoly-settings-modal').remove()" 
                                style="width: 100%; padding: 12px; background: transparent; border: 1px solid #334155; border-radius: 12px; color: #94a3b8; font-weight: 600; cursor: pointer; transition: all 0.2s;">Pencereyi Kapat</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        },

        handleVidmolyFileChange(input) {
            const file = input.files[0];
            if (!file) return;

            // Start Upload
            this.uploadToVidmolyShared(file);
        },

        async uploadToVidmolyShared(file) {
            const section = document.getElementById('vidmoly-upload-section');
            const progress = document.getElementById('vidmoly-upload-progress');
            const nameLabel = document.getElementById('vidmoly-upload-name');
            const bar = document.getElementById('vidmoly-upload-bar');
            const pct = document.getElementById('vidmoly-upload-pct');

            if (section) section.style.display = 'none';
            if (progress) progress.style.display = 'block';
            if (nameLabel) nameLabel.innerText = file.name;

            const formData = new FormData();
            formData.append('file', file);

            try {
                // Use custom XHR to track server-side proxy progress if possible?
                // Actually Backend -> Vidmoly upload won't show browser progress easily unless we use a different strategy.
                // But for now, Browser -> Backend upload WILL show progress.
                
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'api/index.php?action=vidmoly-upload', true);

                xhr.upload.onprogress = (e) => {
                    if (e.lengthComputable) {
                        const percent = (e.loaded / e.total) * 100;
                        if (bar) bar.style.width = percent + '%';
                        if (pct) pct.innerText = Math.round(percent) + '%';
                        
                        if (percent >= 99) {
                            nameLabel.innerText = "Vidmoly sunucusuna aktarılıyor (Lütfen bekleyin)...";
                            pct.innerText = "🔄";
                        }
                    }
                };

                xhr.onload = () => {
                    if (xhr.status === 200) {
                        try {
                            const data = JSON.parse(xhr.responseText);
                            if (data.success) {
                                this.showVidmolyResult(data.url, data.file_code);
                                Toast.success('Vidmoly yüklemesi tamamlandı!');
                            } else {
                                throw new Error(data.message);
                            }
                        } catch (e) {
                            Toast.error(e.message || 'Yanıt işlenemedi.');
                            if (section) section.style.display = 'block';
                            if (progress) progress.style.display = 'none';
                        }
                    } else {
                        Toast.error('Sunucu hatası: ' + xhr.status);
                    }
                };

                xhr.send(formData);

            } catch (e) {
                console.error('Vidmoly upload failed', e);
                Toast.error('Yükleme sırasında hata oluştu.');
                if (section) section.style.display = 'block';
                if (progress) progress.style.display = 'none';
            }
        },

        showVidmolyResult(url, code) {
            const progress = document.getElementById('vidmoly-upload-progress');
            const result = document.getElementById('vidmoly-result-section');
            const input = document.getElementById('vidmoly-result-url');

            if (progress) progress.style.display = 'none';
            if (result) result.style.display = 'block';
            if (input) {
                input.value = url;
                input.dataset.code = code;
            }
        },

        copyVidmolyUrl() {
            const input = document.getElementById('vidmoly-result-url');
            if (input) {
                input.select();
                document.execCommand('copy');
                Toast.success('Link kopyalandı!');
            }
        },

        applyVidmolyToProject() {
            const input = document.getElementById('vidmoly-result-url');
            if (input && input.value) {
                this.loadRemoteFile(input.value, 'Vidmoly Video (' + (input.dataset.code || '') + ')');
                document.getElementById('vidmoly-settings-modal').remove();
            }
        }
    };
}



