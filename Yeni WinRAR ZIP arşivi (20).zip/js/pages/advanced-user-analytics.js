// Advanced Analytics - Premium Redesign
const AdvancedUserAnalytics = {
    init() {
        console.log('📊 Advanced User Analytics initialized');
    },

    showDetailedAnalytics() {
        if (!State.currentUser) {
            Toast.error("Analitikleri görmek için giriş yapmalısınız.");
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content analytics-premium-modal" style="max-width: 1400px; max-height: 92vh; overflow: hidden; background: linear-gradient(135deg, rgba(15, 23, 42, 0.95) 0%, rgba(30, 41, 59, 0.95) 100%); backdrop-filter: blur(20px); border: 1px solid rgba(124, 58, 237, 0.2); box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);">
                <div class="modal-header" style="background: linear-gradient(135deg, rgba(124, 58, 237, 0.15) 0%, rgba(167, 139, 250, 0.1) 100%); border-bottom: 1px solid rgba(124, 58, 237, 0.2); padding: 24px 32px;">
                    <div style="display: flex; align-items: center; gap: 16px;">
                        <div style="width: 48px; height: 48px; background: linear-gradient(135deg, #7c3aed 0%, #a78bfa 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px;">📊</div>
                        <div>
                            <h2 style="margin: 0; font-size: 1.75rem; font-weight: 700; background: linear-gradient(135deg, #fff 0%, #a78bfa 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">Detaylı Analitikler</h2>
                            <p style="margin: 4px 0 0 0; font-size: 0.875rem; color: rgba(255, 255, 255, 0.6);">İzleme alışkanlıklarınızı keşfedin</p>
                        </div>
                    </div>
                    <button class="modal-close" onclick="this.closest('.modal').remove()" style="width: 40px; height: 40px; background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 10px; font-size: 24px; transition: all 0.3s ease;">×</button>
                </div>
                <div class="modal-body" style="padding: 32px; overflow-y: auto; max-height: calc(92vh - 120px);">
                    <!-- Premium Tabs -->
                    <div class="analytics-tabs-container" style="display: flex; gap: 8px; margin-bottom: 32px; padding: 6px; background: rgba(15, 23, 42, 0.6); border-radius: 16px; border: 1px solid rgba(124, 58, 237, 0.15);">
                        <button class="analytics-tab-premium active" onclick="AdvancedUserAnalytics.switchTab('calendar')" data-tab="calendar">
                            <span style="font-size: 1.2rem;">📅</span>
                            <span>Takvim</span>
                        </button>
                        <button class="analytics-tab-premium" onclick="AdvancedUserAnalytics.switchTab('genres')" data-tab="genres">
                            <span style="font-size: 1.2rem;">🎭</span>
                            <span>Türler</span>
                        </button>
                        <button class="analytics-tab-premium" onclick="AdvancedUserAnalytics.switchTab('time')" data-tab="time">
                            <span style="font-size: 1.2rem;">🕐</span>
                            <span>Zaman</span>
                        </button>
                        <button class="analytics-tab-premium" onclick="AdvancedUserAnalytics.switchTab('compare')" data-tab="compare">
                            <span style="font-size: 1.2rem;">👥</span>
                            <span>Karşılaştır</span>
                        </button>
                        <button class="analytics-tab-premium" onclick="AdvancedUserAnalytics.switchTab('goals')" data-tab="goals">
                            <span style="font-size: 1.2rem;">🎯</span>
                            <span>Hedefler</span>
                        </button>
                    </div>

                    <!-- Tab Content -->
                    <div id="analytics-tab-content">
                        ${this.renderCalendarTab()}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Add premium styles
        const style = document.createElement('style');
        style.textContent = `
            .analytics-premium-modal .modal-close:hover {
                background: rgba(239, 68, 68, 0.2) !important;
                border-color: rgba(239, 68, 68, 0.5) !important;
                color: #ef4444 !important;
                transform: rotate(90deg);
            }

            .analytics-tab-premium {
                flex: 1;
                background: transparent;
                border: none;
                padding: 12px 20px;
                cursor: pointer;
                color: rgba(255, 255, 255, 0.6);
                border-radius: 12px;
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
                font-size: 0.95rem;
                font-weight: 500;
                position: relative;
                overflow: hidden;
            }

            .analytics-tab-premium::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: linear-gradient(135deg, rgba(124, 58, 237, 0.1) 0%, rgba(167, 139, 250, 0.05) 100%);
                opacity: 0;
                transition: opacity 0.3s ease;
            }

            .analytics-tab-premium:hover {
                color: rgba(255, 255, 255, 0.9);
                transform: translateY(-2px);
            }

            .analytics-tab-premium:hover::before {
                opacity: 1;
            }

            .analytics-tab-premium.active {
                background: linear-gradient(135deg, rgba(124, 58, 237, 0.3) 0%, rgba(167, 139, 250, 0.2) 100%);
                color: white;
                border: 1px solid rgba(124, 58, 237, 0.4);
                box-shadow: 0 4px 12px rgba(124, 58, 237, 0.3);
            }

            .analytics-tab-premium.active::before {
                opacity: 0;
            }

            .premium-heatmap-container {
                background: rgba(15, 23, 42, 0.4);
                border: 1px solid rgba(124, 58, 237, 0.15);
                border-radius: 20px;
                padding: 32px;
                margin-top: 24px;
            }

            .heatmap-cell {
                transition: all 0.2s ease;
                cursor: pointer;
                position: relative;
            }

            .heatmap-cell:hover {
                transform: scale(1.3);
                z-index: 10;
                box-shadow: 0 4px 12px rgba(124, 58, 237, 0.5);
            }

            .heatmap-legend {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 20px;
                background: rgba(124, 58, 237, 0.05);
                border-radius: 12px;
                margin-top: 24px;
                border: 1px solid rgba(124, 58, 237, 0.1);
            }

            .section-title-premium {
                font-size: 1.5rem;
                font-weight: 700;
                background: linear-gradient(135deg, #fff 0%, #a78bfa 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
                margin-bottom: 8px;
                display: flex;
                align-items: center;
                gap: 12px;
            }

            .section-subtitle-premium {
                color: rgba(255, 255, 255, 0.5);
                font-size: 0.95rem;
                margin-bottom: 24px;
            }
        `;
        document.head.appendChild(style);
    },

    switchTab(tabName) {
        // Update active tab
        document.querySelectorAll('.analytics-tab-premium').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update content with fade animation
        const content = document.getElementById('analytics-tab-content');
        content.style.opacity = '0';
        content.style.transform = 'translateY(10px)';

        setTimeout(() => {
            switch (tabName) {
                case 'calendar':
                    content.innerHTML = this.renderCalendarTab();
                    break;
                case 'genres':
                    content.innerHTML = this.renderGenresTab();
                    break;
                case 'time':
                    content.innerHTML = this.renderTimeTab();
                    break;
                case 'compare':
                    content.innerHTML = this.renderCompareTab();
                    break;
                case 'goals':
                    content.innerHTML = this.renderGoalsTab();
                    break;
            }

            content.style.transition = 'all 0.3s ease';
            content.style.opacity = '1';
            content.style.transform = 'translateY(0)';
        }, 150);
    },

    renderCalendarTab() {
        const watchHistory = State.currentUser?.watchHistory || [];

        // Create heatmap for last 365 days
        const today = new Date();
        const todayStr = today.toISOString().split('T')[0];
        const heatmapData = {};
        const episodeDetails = {}; // Store episode details for each date

        for (let i = 364; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            const dateStr = date.toISOString().split('T')[0];
            heatmapData[dateStr] = 0;
            episodeDetails[dateStr] = [];
        }

        watchHistory.forEach(h => {
            if (!h.watchedAt) return;
            try {
                const dateObj = new Date(h.watchedAt);
                if (isNaN(dateObj.getTime())) return;
                const dateStr = dateObj.toISOString().split('T')[0];
                if (heatmapData[dateStr] !== undefined) {
                    heatmapData[dateStr]++;
                    episodeDetails[dateStr].push(h);
                }
            } catch (e) {
                console.warn('Invalid date in history:', h);
            }
        });

        const maxCount = Math.max(...Object.values(heatmapData));
        const totalWatched = Object.values(heatmapData).reduce((a, b) => a + b, 0);

        // Organize by months
        const monthsData = {};
        Object.entries(heatmapData).forEach(([date, count]) => {
            const dateObj = new Date(date);
            const monthKey = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, '0')}`;
            if (!monthsData[monthKey]) {
                monthsData[monthKey] = [];
            }
            monthsData[monthKey].push({ date, count, details: episodeDetails[date] });
        });

        // Generate month sections
        const monthSections = Object.entries(monthsData).reverse().map(([monthKey, days]) => {
            const [year, month] = monthKey.split('-');
            const monthName = new Date(year, parseInt(month) - 1, 1).toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' });

            return `
                <div style="margin-bottom: 32px;">
                    <h4 style="color: rgba(255, 255, 255, 0.8); font-size: 1rem; margin-bottom: 12px; font-weight: 600;">${monthName}</h4>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, 18px); gap: 4px;">
                        ${days.map(({ date, count, details }) => {
                const intensity = maxCount > 0 ? Math.min(count / maxCount, 1) : 0;
                let color;
                if (count === 0) {
                    color = 'rgba(30, 41, 59, 0.6)';
                } else if (intensity < 0.25) {
                    color = 'rgba(124, 58, 237, 0.3)';
                } else if (intensity < 0.5) {
                    color = 'rgba(124, 58, 237, 0.5)';
                } else if (intensity < 0.75) {
                    color = 'rgba(124, 58, 237, 0.7)';
                } else {
                    color = 'rgba(124, 58, 237, 1)';
                }

                const dateObj = new Date(date);
                const formattedDate = dateObj.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
                const isToday = date === todayStr;

                // Create episode list for tooltip/click
                const episodeList = details.map(d => {
                    const series = State.data?.series?.find(s => s.id === d.seriesId);
                    return series ? `${series.title} - Bölüm ${d.episodeIndex + 1}` : 'Bilinmeyen';
                }).join('\\n');

                return `<div class="heatmap-cell" 
                                onclick="AdvancedUserAnalytics.showDayDetails('${date}', ${count}, '${formattedDate}')" 
                                style="width: 18px; height: 18px; background: ${color}; border-radius: 4px; border: ${isToday ? '2px solid #fbbf24' : '1px solid rgba(124, 58, 237, 0.2)'}; ${isToday ? 'box-shadow: 0 0 8px rgba(251, 191, 36, 0.6);' : ''}" 
                                title="${formattedDate}: ${count} bölüm${count > 0 ? '\\n' + episodeList : ''}"></div>`;
            }).join('')}
                    </div>
                </div>
            `;
        }).join('');

        return `
            <div class="section-title-premium">
                <span style="font-size: 2rem;">📅</span>
                İzleme Takvimi
            </div>
            <p class="section-subtitle-premium">Son 365 günde ${totalWatched} bölüm izlediniz</p>

            <div class="premium-heatmap-container">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <div style="display: flex; gap: 24px;">
                        <div>
                            <div style="font-size: 2rem; font-weight: 700; color: #7c3aed;">${totalWatched}</div>
                            <div style="font-size: 0.875rem; color: rgba(255, 255, 255, 0.5);">Toplam Bölüm</div>
                        </div>
                        <div>
                            <div style="font-size: 2rem; font-weight: 700; color: #a78bfa;">${maxCount}</div>
                            <div style="font-size: 0.875rem; color: rgba(255, 255, 255, 0.5);">En Aktif Gün</div>
                        </div>
                        <div>
                            <div style="font-size: 2rem; font-weight: 700; color: #8b5cf6;">${Math.round(totalWatched / 365)}</div>
                            <div style="font-size: 0.875rem; color: rgba(255, 255, 255, 0.5);">Günlük Ortalama</div>
                        </div>
                    </div>
                </div>

                <div style="overflow-x: auto; overflow-y: auto; max-height: 500px; padding: 10px 0;">
                    ${monthSections}
                </div>

                <div class="heatmap-legend">
                    <span style="color: rgba(255, 255, 255, 0.6); font-size: 0.875rem; font-weight: 500;">Daha Az</span>
                    <div style="width: 18px; height: 18px; background: rgba(30, 41, 59, 0.6); border-radius: 4px; border: 1px solid rgba(124, 58, 237, 0.2);"></div>
                    <div style="width: 18px; height: 18px; background: rgba(124, 58, 237, 0.3); border-radius: 4px; border: 1px solid rgba(124, 58, 237, 0.2);"></div>
                    <div style="width: 18px; height: 18px; background: rgba(124, 58, 237, 0.5); border-radius: 4px; border: 1px solid rgba(124, 58, 237, 0.2);"></div>
                    <div style="width: 18px; height: 18px; background: rgba(124, 58, 237, 0.7); border-radius: 4px; border: 1px solid rgba(124, 58, 237, 0.2);"></div>
                    <div style="width: 18px; height: 18px; background: rgba(124, 58, 237, 1); border-radius: 4px; border: 1px solid rgba(124, 58, 237, 0.2);"></div>
                    <span style="color: rgba(255, 255, 255, 0.6); font-size: 0.875rem; font-weight: 500;">Daha Çok</span>
                    <div style="width: 18px; height: 18px; background: transparent; border: 2px solid #fbbf24; border-radius: 4px; margin-left: 16px;"></div>
                    <span style="color: rgba(255, 255, 255, 0.6); font-size: 0.875rem; font-weight: 500;">Bugün</span>
                </div>
            </div>
        `;
    },

    showDayDetails(date, count, formattedDate) {
        if (count === 0) {
            Toast.info('Bu günde hiç bölüm izlemediniz');
            return;
        }

        const watchHistory = State.currentUser?.watchHistory || [];
        const dayEpisodes = watchHistory.filter(h => {
            const dateStr = new Date(h.watchedAt).toISOString().split('T')[0];
            return dateStr === date;
        });

        const episodeList = dayEpisodes.map(h => {
            const series = State.data?.series?.find(s => s.id === h.seriesId);
            const seriesTitle = series ? series.title : 'Bilinmeyen Dizi';
            return `
                <div style="padding: 12px; background: rgba(124, 58, 237, 0.1); border-radius: 8px; margin-bottom: 8px; border: 1px solid rgba(124, 58, 237, 0.2);">
                    <div style="font-weight: 600; color: white; margin-bottom: 4px;">${seriesTitle}</div>
                    <div style="font-size: 0.875rem; color: rgba(255, 255, 255, 0.6);">Bölüm ${h.episodeIndex + 1}</div>
                </div>
            `;
        }).join('');

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 500px; background: linear-gradient(135deg, rgba(15, 23, 42, 0.95) 0%, rgba(30, 41, 59, 0.95) 100%); backdrop-filter: blur(20px); border: 1px solid rgba(124, 58, 237, 0.2);">
                <div class="modal-header" style="background: linear-gradient(135deg, rgba(124, 58, 237, 0.15) 0%, rgba(167, 139, 250, 0.1) 100%); border-bottom: 1px solid rgba(124, 58, 237, 0.2);">
                    <h2 style="margin: 0; font-size: 1.5rem;">📅 ${formattedDate}</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div style="margin-bottom: 16px;">
                        <div style="font-size: 2rem; font-weight: 700; color: #7c3aed; margin-bottom: 4px;">${count} Bölüm</div>
                        <div style="font-size: 0.875rem; color: rgba(255, 255, 255, 0.6);">Bu günde izlediğiniz içerikler:</div>
                    </div>
                    ${episodeList}
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    renderGenresTab() {
        return `
            <div class="section-title-premium">
                <span style="font-size: 2rem;">🎭</span>
                Tür Analizi
            </div>
            <p class="section-subtitle-premium">En çok izlediğiniz türler ve detaylı istatistikler</p>
            <div style="background: rgba(15, 23, 42, 0.4); border: 1px solid rgba(124, 58, 237, 0.15); border-radius: 20px; padding: 40px; text-align: center;">
                <canvas id="genre-detail-chart" style="max-height: 400px;"></canvas>
            </div>
        `;
    },

    renderTimeTab() {
        return `
            <div class="section-title-premium">
                <span style="font-size: 2rem;">🕐</span>
                Zaman Analizi
            </div>
            <p class="section-subtitle-premium">Hangi saatlerde ve günlerde daha aktifsiniz?</p>
            <div style="background: rgba(15, 23, 42, 0.4); border: 1px solid rgba(124, 58, 237, 0.15); border-radius: 20px; padding: 40px; text-align: center;">
                <canvas id="time-analysis-chart" style="max-height: 400px;"></canvas>
            </div>
        `;
    },

    renderCompareTab() {
        const friends = State.currentUser?.friends || [];

        return `
            <div class="section-title-premium">
                <span style="font-size: 2rem;">👥</span>
                Arkadaş Karşılaştırma
            </div>
            <p class="section-subtitle-premium">İzleme istatistiklerinizi arkadaşlarınızla karşılaştırın</p>
            ${friends.length > 0 ? `
                <div style="background: rgba(15, 23, 42, 0.4); border: 1px solid rgba(124, 58, 237, 0.15); border-radius: 20px; padding: 32px;">
                    <select id="compare-friend-select" class="form-select" style="margin-bottom: 20px; background: rgba(30, 41, 59, 0.6); border: 1px solid rgba(124, 58, 237, 0.3); border-radius: 12px; padding: 12px 16px; color: white;">
                        <option value="">Arkadaş seçin...</option>
                        ${friends.map(friendId => {
            const friend = State.data.users.find(u => u.id === friendId);
            return friend ? `<option value="${friendId}">${friend.username}</option>` : '';
        }).join('')}
                    </select>
                    <button class="btn btn-primary" onclick="AdvancedUserAnalytics.compareFriend()" style="background: linear-gradient(135deg, #7c3aed 0%, #a78bfa 100%); border: none; padding: 12px 24px; border-radius: 12px; font-weight: 600;">
                        <i class="fa-solid fa-chart-line"></i> Karşılaştır
                    </button>
                    <div id="comparison-results" style="margin-top: 24px;"></div>
                </div>
            ` : `
                <div style="background: rgba(15, 23, 42, 0.4); border: 1px solid rgba(124, 58, 237, 0.15); border-radius: 20px; padding: 60px; text-align: center;">
                    <div style="font-size: 4rem; margin-bottom: 16px;">👥</div>
                    <p style="color: rgba(255, 255, 255, 0.6); font-size: 1.1rem;">
                        Karşılaştırma yapmak için arkadaş ekleyin
                    </p>
                </div>
            `}
        `;
    },

    renderGoalsTab() {
        return `
            <div class="section-title-premium">
                <span style="font-size: 2rem;">🎯</span>
                Hedeflerim
            </div>
            <p class="section-subtitle-premium">İzleme hedeflerinizi belirleyin ve takip edin</p>
            
            <button class="btn btn-primary" onclick="AdvancedUserAnalytics.createGoal()" style="background: linear-gradient(135deg, #7c3aed 0%, #a78bfa 100%); border: none; padding: 12px 24px; border-radius: 12px; font-weight: 600; margin-bottom: 24px;">
                <i class="fa-solid fa-plus"></i> Yeni Hedef Ekle
            </button>
            <div id="goals-list">
                ${this.renderGoalsList()}
            </div>
        `;
    },

    renderGoalsList() {
        const goals = State.currentUser?.goals || [];

        if (goals.length === 0) {
            return `
                <div style="background: rgba(15, 23, 42, 0.4); border: 1px solid rgba(124, 58, 237, 0.15); border-radius: 20px; padding: 60px; text-align: center;">
                    <div style="font-size: 4rem; margin-bottom: 16px;">🎯</div>
                    <p style="color: rgba(255, 255, 255, 0.6); font-size: 1.1rem;">Henüz hedef eklenmemiş</p>
                </div>
            `;
        }

        return goals.map(goal => {
            const progress = (goal.current / goal.target * 100).toFixed(1);
            return `
                <div style="background: rgba(15, 23, 42, 0.4); border: 1px solid rgba(124, 58, 237, 0.15); border-radius: 16px; padding: 24px; margin-bottom: 16px; transition: all 0.3s ease;" onmouseenter="this.style.transform='translateY(-4px)'; this.style.boxShadow='0 8px 24px rgba(124, 58, 237, 0.3)';" onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='none';">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                        <h4 style="margin: 0; font-size: 1.125rem; color: white;">${goal.title}</h4>
                        <span style="color: rgba(255, 255, 255, 0.6); font-weight: 600;">${goal.current} / ${goal.target}</span>
                    </div>
                    <div style="width: 100%; height: 10px; background: rgba(30, 41, 59, 0.6); border-radius: 10px; overflow: hidden; border: 1px solid rgba(124, 58, 237, 0.2);">
                        <div style="width: ${progress}%; height: 100%; background: linear-gradient(90deg, #7c3aed 0%, #a78bfa 100%); transition: width 0.5s ease; box-shadow: 0 0 10px rgba(124, 58, 237, 0.5);"></div>
                    </div>
                    <div style="margin-top: 12px; color: rgba(255, 255, 255, 0.6); font-size: 0.875rem; font-weight: 500;">
                        <i class="fa-solid fa-chart-line"></i> ${progress}% tamamlandı
                    </div>
                </div>
            `;
        }).join('');
    },

    createGoal() {
        Toast.info('Hedef oluşturma özelliği yakında eklenecek!');
    },

    compareFriend() {
        Toast.info('Arkadaş karşılaştırma özelliği yakında eklenecek!');
    }
};

console.log('✅ Advanced User Analytics Module Loaded (Premium Edition)!');
