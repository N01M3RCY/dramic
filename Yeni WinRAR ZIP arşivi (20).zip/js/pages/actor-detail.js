const ActorDetail = {
    currentTab: 'bio',
    currentActorKey: null,

    async render(actorName) {
        const view = document.getElementById('actor-detail-view');
        if (view) {
            document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
            view.style.display = 'block';
        }

        const container = document.querySelector('#actor-detail-view .container');
        if (!container) return;

        container.innerHTML = '<div class="loading-spinner"></div>';

        if (!actorName) {
            console.error("ActorDetail.render: actorName is missing or invalid");
            container.innerHTML = '<div class="error-message" style="text-align:center; padding:50px; color:#ef4444; font-weight:bold;">Oyuncu adı belirtilmemiş.</div>';
            return;
        }

        let name = '';
        try {
            name = decodeURIComponent(actorName).trim();
        } catch (e) {
            name = String(actorName).trim();
        }

        if (!name || name.toLowerCase() === 'undefined' || name.toLowerCase() === 'null') {
            container.innerHTML = '<div class="error-message" style="text-align:center; padding:50px; color:#ef4444; font-weight:bold;">Geçersiz oyuncu adı.</div>';
            return;
        }

        const normalize = (str) => {
            if (!str) return '';
            return str.toLowerCase()
                .replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ş/g, 's')
                .replace(/ı/g, 'i').replace(/ö/g, 'o').replace(/ç/g, 'c')
                .replace(/[^a-z0-9]/g, '');
        };
        const searchName = normalize(name);
        this.currentActorKey = name;

        let actorData = null;
        if (State.data && State.data.actors) {
            actorData = State.data.actors.find(a =>
                String(a.id) === String(name) ||
                String(a.id) === String(actorName) ||
                a.name === name ||
                normalize(a.name) === searchName ||
                normalize(a.id) === searchName
            );
        }

        // If not found in local memory, try to load it from the database API
        if (!actorData) {
            try {
                const response = await fetch(`api/db.php?action=actor-get&name=${encodeURIComponent(name)}`);
                if (response.ok) {
                    const result = await response.json();
                    if (result.success && result.actor && result.actor.name) {
                        actorData = result.actor;
                        // Cache it in State.data.actors
                        if (!State.data.actors) State.data.actors = [];
                        if (!State.data.actors.some(a => a.name === actorData.name)) {
                            State.data.actors.push(actorData);
                        }
                    }
                }
            } catch (e) {
                console.error("Error fetching actor data:", e);
            }
        }

        // If still not found, initialize a default placeholder
        if (!actorData) {
            const displayName = name && name !== actorName ? name : (actorName || 'Bilinmeyen Oyuncu');
            actorData = {
                id: 'actor_' + searchName,
                name: displayName,
                bio: 'Bu oyuncu hakkında henüz biyografi eklenmemiş.',
                avatar: 'assets/default-avatar.png',
                nationality: 'Güney Kore',
                birthYear: '',
                height: '-',
                weight: '-',
                bloodType: '-',
                zodiac: '-',
                footSize: '-',
                koreanName: '-',
                ratings: [],
                fanCenter: {
                    polls: [],
                    members: [],
                    gallery: [],
                    weeklyCheers: 0
                }
            };
            if (!State.data.actors) State.data.actors = [];
            State.data.actors.push(actorData);
        }

        const creditList = [];
        const seenSeriesIds = new Set();
        if (State.data && State.data.series) {
            State.data.series.forEach(series => {
                if (!series || seenSeriesIds.has(series.id)) return;
                let castList = series.cast || series.characters || [];
                if (typeof castList === 'string') {
                    castList = castList.split(',').map(name => name.trim());
                }
                if (Array.isArray(castList)) {
                    const person = castList.find(c => {
                        if (!c) return false;
                        if (typeof c === 'string') return normalize(c) === searchName;
                        if (typeof c === 'object') {
                            return normalize(c.name || '') === searchName || normalize(c.actor || '') === searchName || normalize(c.actorName || '') === searchName;
                        }
                        return false;
                    });
                    if (person) {
                        creditList.push(series);
                        seenSeriesIds.add(series.id);
                    }
                }
            });
        }

        const actorImage = actorData?.avatar || actorData?.image || 'assets/default-avatar.png';
        const birthYear = actorData?.birthYear || '';
        const isAdmin = State.currentUser && (State.currentUser.role === 'admin' || State.currentUser.badges?.includes('Yönetici'));

        container.innerHTML = `
            <div class="actor-page-wrapper" style="padding: 40px 0;">
                <div class="actor-hero" style="display: flex; gap: 40px; align-items: start; margin-bottom: 40px; position: relative;">
                    <!-- Huge soft light halo (neon glow) behind avatar -->
                    <div style="position: absolute; top: -100px; left: -100px; width: 600px; height: 600px; background: radial-gradient(circle, rgba(139, 92, 246, 0.15) 0%, transparent 70%); border-radius: 50%; pointer-events: none; z-index: 0;"></div>
                    <div style="position: absolute; bottom: -50px; right: -50px; width: 500px; height: 500px; background: radial-gradient(circle, rgba(236, 72, 153, 0.1) 0%, transparent 70%); border-radius: 50%; pointer-events: none; z-index: 0;"></div>
                    
                    <div class="actor-avatar-container" style="flex-shrink: 0; width: 260px; z-index: 1;">
                        <div class="actor-avatar-frame" style="aspect-ratio: 2/3; border-radius: 24px; overflow: hidden; box-shadow: 0 20px 50px rgba(0,0,0,0.6), 0 0 30px rgba(139, 92, 246, 0.2); border: 1px solid rgba(255,255,255,0.15); position: relative; transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);">
                            <img src="${actorImage}" alt="${name}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                            <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(15,15,20,0.4) 0%, transparent 50%); pointer-events: none;"></div>
                        </div>
                        
                        <!-- Rating Panel -->
                        <div class="glass-panel rating-panel" style="margin-top: 25px; border-radius: 24px; padding: 22px; border: 1px solid rgba(255,255,255,0.06); background: rgba(255,255,255,0.02); backdrop-filter: blur(10px); box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;">
                                <div style="font-size: 0.8rem; color: #94a3b8; text-transform: uppercase; font-weight: 800; letter-spacing: 1px;">Topluluk Puanı</div>
                                <div style="font-size: 1.6rem; font-weight: 900; color: #f59e0b; text-shadow: 0 0 10px rgba(245, 158, 11, 0.3);" id="actor-rating-val">${this.calculateRating(actorData)}</div>
                            </div>
                            
                            <div class="actor-star-rating-10" style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px;">
                                ${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => `
                                    <div class="star-unit" onclick="ActorDetail.submitRating('${actorData?.id}', ${n})" onmouseover="ActorDetail.hoverRating(${n})" onmouseout="ActorDetail.resetRating()" 
                                        style="cursor:pointer; text-align:center; transition: all 0.2s ease; font-size:1.3rem; color: ${this.getUserRating(actorData) >= n ? '#f59e0b' : '#334155'}; filter: drop-shadow(0 0 5px rgba(245, 158, 11, 0.15));">
                                        <i class="fa-solid fa-star"></i>
                                    </div>
                                `).join('')}
                            </div>
                            <div style="text-align:center; margin-top:12px; font-size:0.75rem; color:#64748b; font-weight: 600;">(10 Üzerinden Puanlayın)</div>
                        </div>
                    </div>

                    <div class="actor-info" style="flex: 1; z-index: 1;">
                        <div style="display:flex; align-items:center; gap:20px; margin-bottom:12px; flex-wrap: wrap;">
                            <h1 style="font-size: 3.8rem; font-weight: 900; margin: 0; background: linear-gradient(135deg, #fff 30%, #c084fc 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; letter-spacing: -1.5px; text-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                                ${name}
                            </h1>
                            ${isAdmin ? `<button onclick="ManagementHub.openActorModal('${actorData?.id}')" class="btn-icon-modern" style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:#fff; width:45px; height:45px; border-radius:50%; cursor:pointer; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.3);"><i class="fa-solid fa-pen" style="font-size: 0.95rem;"></i></button>` : ''}
                        </div>
                        
                        <div style="display: flex; gap: 20px; color: #94a3b8; font-size: 1.05rem; margin-bottom: 30px; align-items: center; font-weight: 600; flex-wrap: wrap;">
                            <span class="info-badge-classic"><i class="fa-solid fa-flag" style="margin-right: 8px; color: #a78bfa;"></i>${actorData?.nationality || 'Güney Kore'}</span>
                            ${birthYear ? `<span class="info-badge-classic"><i class="fa-regular fa-calendar" style="margin-right: 8px; color: #a78bfa;"></i>${birthYear}</span>` : ''}
                            <span style="background: linear-gradient(135deg, rgba(124, 58, 237, 0.2), rgba(219, 39, 119, 0.2)); border: 1px solid rgba(139, 92, 246, 0.3); color: #e9d5ff; padding: 6px 16px; border-radius: 50px; font-size: 0.8rem; font-weight: 800; letter-spacing: 0.5px;">AKTÖR</span>
                        </div>

                        <!-- Personal Info Glassmorphic Grid -->
                        <div class="actor-stats-table glass-panel" style="background: rgba(255, 255, 255, 0.01); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 24px; padding: 0; margin-bottom: 35px; overflow: hidden; backdrop-filter: blur(15px); box-shadow: 0 20px 40px rgba(0,0,0,0.3);">
                            <div style="padding: 22px 30px; border-bottom: 1px solid rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: space-between;">
                                <h3 style="margin: 0; font-size: 0.95rem; font-weight: 850; color: #c084fc; text-transform: uppercase; letter-spacing: 1.5px;"><i class="fa-solid fa-id-card-clip" style="margin-right: 8px;"></i> Künye ve Detaylar</h3>
                                <div style="font-size: 0.75rem; color: #64748b; font-weight: 800; letter-spacing: 1px;">#OYUNCU_PROFILI</div>
                            </div>
                            <div class="stats-grid" style="display: grid; grid-template-columns: 1fr 1fr; border-bottom: 1px solid rgba(255,255,255,0.06);">
                                <div class="stat-row">
                                    <span class="stat-label-modern"><i class="fa-solid fa-arrows-up-down"></i> BOY</span>
                                    <span class="stat-value-modern">${actorData?.height || '-'} cm</span>
                                </div>
                                <div class="stat-row" style="border-left: 1px solid rgba(255,255,255,0.06);">
                                    <span class="stat-label-modern"><i class="fa-solid fa-weight-scale"></i> KİLO</span>
                                    <span class="stat-value-modern">${actorData?.weight || '-'} kg</span>
                                </div>
                            </div>
                            <div class="stats-grid" style="display: grid; grid-template-columns: 1fr 1fr; border-bottom: 1px solid rgba(255,255,255,0.06);">
                                <div class="stat-row">
                                    <span class="stat-label-modern"><i class="fa-solid fa-droplet"></i> KAN GRUBU</span>
                                    <span class="stat-value-modern">${actorData?.bloodType || '-'}</span>
                                </div>
                                <div class="stat-row" style="border-left: 1px solid rgba(255,255,255,0.06);">
                                    <span class="stat-label-modern"><i class="fa-solid fa-moon"></i> BURÇ</span>
                                    <span class="stat-value-modern">${actorData?.zodiac || '-'}</span>
                                </div>
                            </div>
                            <div class="stats-grid" style="display: grid; grid-template-columns: 1fr 1fr; border-bottom: 1px solid rgba(255,255,255,0.06);">
                                <div class="stat-row">
                                    <span class="stat-label-modern"><i class="fa-solid fa-shoe-prints"></i> AYAK NO</span>
                                    <span class="stat-value-modern">${actorData?.footSize || '-'}</span>
                                </div>
                                <div class="stat-row" style="border-left: 1px solid rgba(255,255,255,0.06);">
                                    <span class="stat-label-modern"><i class="fa-solid fa-calendar-days"></i> DOĞUM TARİHİ</span>
                                    <span class="stat-value-modern" style="font-size: 0.95rem;">${actorData?.birthDate ? new Date(actorData.birthDate).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short', year: 'numeric' }) : (actorData?.birthYear || '-')}</span>
                                </div>
                            </div>
                            <div class="stats-grid" style="display: grid; grid-template-columns: 1fr;">
                                <div class="stat-row" style="justify-content: center; background: rgba(167, 139, 250, 0.02); padding: 18px;">
                                    <span class="stat-label-modern" style="margin-right: 15px; letter-spacing: 0.5px;">KORECE İSİM:</span>
                                    <span class="stat-value-modern" style="color: #c084fc; font-family: 'Noto Sans KR', sans-serif; font-size: 1.05rem; letter-spacing: 0.5px;">${actorData?.koreanName || '-'}</span>
                                </div>
                            </div>
                        </div>

                        <!-- Tab Selection Header -->
                        <div class="actor-tabs" style="display: flex; gap: 10px; margin-bottom: 30px; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 12px; flex-wrap: wrap;">
                            <button class="tab-btn ${this.currentTab === 'bio' ? 'active' : ''}" onclick="ActorDetail.switchTab('bio')">Biyografi</button>
                            <button class="tab-btn ${this.currentTab === 'works' ? 'active' : ''}" onclick="ActorDetail.switchTab('works')">Filmografi (${creditList.length})</button>
                            <button class="tab-btn ${this.currentTab === 'fan' ? 'active' : ''}" onclick="ActorDetail.switchTab('fan')">Fan Merkezi <span class="badge-new">YENİ</span></button>
                            <button class="tab-btn ${this.currentTab === 'gallery' ? 'active' : ''}" onclick="ActorDetail.switchTab('gallery')">Foto Galeri</button>
                        </div>

                        <!-- Tab Content Body -->
                        <div id="actor-tab-content" style="position: relative; min-height: 200px;">
                            ${this.renderTabContent(actorData, creditList, name)}
                        </div>
                    </div>
                </div>
                
                <!-- Page Split Layout -->
                <div style="border-top: 1px solid rgba(255,255,255,0.06); padding-top: 40px; display: grid; grid-template-columns: 1fr 380px; gap: 40px;" class="split-layout">
                    <div style="z-index: 1;">
                        <h2 style="font-size: 1.9rem; font-weight: 850; margin-bottom: 25px; display: flex; align-items: center; gap: 15px; color: #fff;">
                            <i class="fa-solid fa-comments" style="color: #a78bfa;"></i> Topluluk Tartışmaları
                        </h2>
                        <div id="actor-comments-enhanced" class="glass-panel" style="padding: 25px; border-radius: 24px; border: 1px solid rgba(255,255,255,0.05); background: rgba(255,255,255,0.01); backdrop-filter: blur(10px);">
                            <!-- Enhanced Comments Logic -->
                        </div>
                    </div>
                    <div class="fan-sidebar" style="z-index: 1;">
                        ${this.renderFanSidebar(actorData)}
                    </div>
                </div>
            </div>
            
            <style>
                .actor-avatar-frame:hover {
                    transform: translateY(-8px) scale(1.02);
                    box-shadow: 0 30px 60px rgba(0,0,0,0.7), 0 0 40px rgba(139, 92, 246, 0.4);
                    border-color: rgba(139, 92, 246, 0.35);
                }
                .actor-avatar-frame:hover img {
                    transform: scale(1.05);
                }
                .btn-icon-modern:hover {
                    background: rgba(255,255,255,0.15) !important;
                    border-color: rgba(139, 92, 246, 0.4) !important;
                    color: #c084fc !important;
                    transform: rotate(15deg);
                }
                .info-badge-classic {
                    background: rgba(255,255,255,0.03);
                    border: 1px solid rgba(255,255,255,0.06);
                    padding: 6px 16px;
                    border-radius: 50px;
                    display: inline-flex;
                    align-items: center;
                    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                }
                .stat-row { display: flex; align-items: center; justify-content: space-between; padding: 18px 25px; transition: all 0.3s ease; }
                .stat-row:hover { background: rgba(255, 255, 255, 0.02); }
                .stat-label-modern { color: #94a3b8; font-size: 0.75rem; font-weight: 850; display: flex; align-items: center; gap: 10px; letter-spacing: 0.5px; }
                .stat-label-modern i { color: #a78bfa; width: 14px; text-align: center; font-size: 0.85rem; }
                .stat-value-modern { color: #fff; font-weight: 850; font-size: 1rem; }

                .tab-btn { background: none; border: none; color: #64748b; font-weight: 800; padding: 12px 24px; cursor: pointer; transition: all 0.3s ease; border-radius: 12px; font-size: 0.95rem; }
                .tab-btn:hover { color: #fff; background: rgba(255,255,255,0.04); }
                .tab-btn.active { color: #fff; background: linear-gradient(135deg, #7c3aed, #6d28d9); box-shadow: 0 8px 20px rgba(124, 58, 237, 0.35); }
                .badge-new { background: linear-gradient(135deg, #ef4444, #b91c1c); color: #fff; font-size: 0.6rem; padding: 2px 8px; border-radius: 50px; vertical-align: middle; margin-left: 6px; font-weight: 900; letter-spacing: 0.5px; }
                
                @media (max-width: 992px) {
                    .actor-hero { flex-direction: column; align-items: center; text-align: center; }
                    .actor-avatar-container { width: 220px; }
                    .stats-grid { grid-template-columns: 1fr !important; }
                    .stat-row { border-left: none !important; }
                    .split-layout { grid-template-columns: 1fr !important; }
                    .actor-tabs { justify-content: center; }
                }
            </style>
        `;

        if (window.EnhancedComments && EnhancedComments.renderInline) {
            EnhancedComments.renderInline('actor-comments-enhanced', 'actor_' + (actorData ? actorData.id : searchName));
        }
    },

    switchTab(tab) {
        this.currentTab = tab;
        this.render(this.currentActorKey || '');
    },

    renderTabContent(actor, works, name) {
        switch(this.currentTab) {
            case 'bio':
                return `
                    <div class="tab-fade-in" style="line-height: 1.9; color: #cbd5e1; font-size: 1.1rem; text-align: justify;">
                        <p>${actor?.bio || 'Bu oyuncu hakkında henüz biyografi eklenmemiş.'}</p>
                        ${actor?.social?.instagram ? `
                            <div style="margin-top: 35px;">
                                <a href="https://instagram.com/${actor.social.instagram}" target="_blank" class="social-chip">
                                    <i class="fa-brands fa-instagram"></i> @${actor.social.instagram}
                                </a>
                            </div>
                        ` : ''}
                    </div>
                    <style>
                        .social-chip { display: inline-flex; align-items: center; gap: 10px; background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888); padding: 12px 25px; border-radius: 50px; color: #fff; text-decoration: none; font-weight: 800; transition: all 0.3s ease; box-shadow: 0 5px 15px rgba(220, 39, 67, 0.2); }
                        .social-chip:hover { transform: translateY(-4px); box-shadow: 0 12px 25px rgba(220, 39, 67, 0.45); }
                    </style>
                `;
            case 'works':
                return `
                    <div class="series-grid tab-fade-in" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(165px, 1fr)); gap: 25px;">
                        ${works.map(item => StandardCard.render(item)).join('')}
                    </div>
                `;
            case 'fan':
                return this.renderFanCenter(actor);
            case 'gallery':
                return this.renderFanGallery(actor);
        }
    },

    renderFanCenter(actor) {
        if (!actor) return '<div class="glass-panel" style="padding:40px; text-align:center;">Bu özellik için oyuncunun resmi veritabanında olması gerekiyor.</div>';
        
        const fc = actor.fanCenter || { polls: [], members: [], pendingMembers: [], gallery: [], weeklyCheers: 0 };
        const president = State.data.users?.find(u => u.id === fc.presidentId) || State.data.users?.find(u => u.username === fc.presidentId);
        const vicePresident = State.data.users?.find(u => u.id === fc.vicePresidentId) || State.data.users?.find(u => u.username === fc.vicePresidentId);
        const isMember = State.currentUser && fc.members && fc.members.includes(State.currentUser.id);
        const isPresident = State.currentUser && (State.currentUser.id === fc.presidentId || State.currentUser.username === fc.presidentId);
        const isVicePresident = State.currentUser && (State.currentUser.id === fc.vicePresidentId || State.currentUser.username === fc.vicePresidentId);
        const isManager = isPresident || isVicePresident || (State.currentUser && State.currentUser.role === 'admin');
        const isPending = State.currentUser && fc.pendingMembers && fc.pendingMembers.includes(State.currentUser.id);
        
        const fanPosts = (State.data.socialPosts || []).filter(p => p.metadata?.actorId === actor.id);
        
        return `
            <div class="fan-center-grid tab-fade-in" style="display: flex; flex-direction: column; gap: 30px;">
                <!-- Welcome & Membership Card Hero -->
                <div class="fan-welcome-hero glass-panel" style="padding: 40px; background: linear-gradient(135deg, rgba(124, 58, 237, 0.15), rgba(0,0,0,0.5)); border: 1px solid rgba(124, 58, 237, 0.3); border-radius: 30px; position: relative; overflow: hidden; box-shadow: 0 15px 35px rgba(0,0,0,0.3);">
                    <div style="position: absolute; top: -50px; right: -50px; width: 250px; height: 250px; background: rgba(139, 92, 246, 0.2); filter: blur(70px); opacity: 0.4; pointer-events: none;"></div>
                    
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:25px; position: relative; z-index: 2;">
                        <div style="display: flex; align-items: center; gap: 25px;">
                            <div style="position: relative; flex-shrink: 0;">
                                <img src="${actor.avatar || actor.image || 'assets/logo.png'}" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 4px solid #8b5cf6; box-shadow: 0 0 25px rgba(139, 92, 246, 0.5);">
                                <div style="position: absolute; bottom: 0; right: 0; background: #f59e0b; color: #000; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid #0f0f13; font-size: 0.85rem; font-weight: bold;"><i class="fa-solid fa-crown"></i></div>
                            </div>
                            <div>
                                <h3 style="margin:0; font-size:2.2rem; font-weight:900; background: linear-gradient(135deg, #fff 30%, #a78bfa 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">${actor.name} Fan Kulübü</h3>
                                <p style="color:#cbd5e1; margin:8px 0 0; font-weight: 600; font-size: 1.1rem; display: flex; align-items: center; gap: 10px;">
                                    <span style="color: #8b5cf6; display: inline-flex;"><i class="fa-solid fa-users"></i></span> ${fc.members?.length || 0} Sadık Üye
                                    <span style="color: rgba(255,255,255,0.15);">|</span>
                                    <span style="color: #ec4899; display: inline-flex;"><i class="fa-solid fa-heart"></i></span> ${fanPosts.length} Paylaşım
                                </p>
                            </div>
                        </div>
                        ${isMember ? `
                            <div style="background:rgba(16,185,129,0.08); border:1px solid rgba(16,185,129,0.35); color:#10b981; padding:15px 35px; border-radius:18px; font-weight:900; display: flex; align-items: center; gap: 10px; font-size: 1.1rem; box-shadow: 0 10px 20px rgba(16,185,129,0.1); letter-spacing: 0.5px;">
                                <i class="fa-solid fa-circle-check" style="font-size: 1.2rem;"></i> KULÜP ÜYESİSİNİZ
                            </div>
                        ` : isPending ? `
                            <div style="background:rgba(245,158,11,0.08); border:1px solid rgba(245,158,11,0.35); color:#f59e0b; padding:15px 35px; border-radius:18px; font-weight:900; display: flex; align-items: center; gap: 10px; font-size: 1.1rem; box-shadow: 0 10px 20px rgba(245,158,11,0.1); letter-spacing: 0.5px;">
                                <i class="fa-solid fa-clock" style="font-size: 1.2rem;"></i> ONAY BEKLENİYOR
                            </div>
                        ` : `
                            <button class="btn-hero-primary" onclick="ActorDetail.joinFanClub('${actor.id}')" style="padding: 16px 40px; font-size: 1.1rem; border-radius: 18px; font-weight: 850; background: linear-gradient(135deg, #7c3aed, #db2777); color: #fff; border: none; cursor: pointer; transition: all 0.3s; box-shadow: 0 10px 30px rgba(124,58,237,0.35); display: flex; align-items: center; gap: 10px;">
                                <i class="fa-solid fa-heart"></i> Kulübe Katıl (Onaylı)
                            </button>
                        `}
                        ${isManager ? `
                            <button onclick="ActorDetail.openManagementPanel('${actor.id}')" style="margin-left:15px; padding: 16px 25px; font-size: 1.1rem; border-radius: 18px; font-weight: 850; background: rgba(255,255,255,0.05); color: #fff; border: 1px solid rgba(255,255,255,0.2); cursor: pointer; transition: all 0.3s; display: flex; align-items: center; gap: 10px;">
                                <i class="fa-solid fa-gear"></i> Yönetim Paneli
                            </button>
                        ` : ''}
                    </div>
                </div>

                <!-- Stats & Polls Row -->
                <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap:25px;">
                    <!-- President Panel -->
                    <div class="election-panel glass-panel" style="padding:30px; border-radius: 24px; border: 1px solid rgba(245, 158, 11, 0.25); background: rgba(245, 158, 11, 0.02); backdrop-filter: blur(10px); box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                            <h4 style="margin:0; color:#f59e0b; font-size: 1.3rem; font-weight: 900; display: flex; align-items: center; gap: 8px;"><i class="fa-solid fa-crown"></i> Kulüp Başkanı</h4>
                            <span style="font-size: 0.7rem; background: rgba(245, 158, 11, 0.15); color: #f59e0b; padding: 4px 12px; border-radius: 50px; font-weight: 900; letter-spacing: 0.5px;">RESMİ BAŞKANLIK</span>
                        </div>
                        <div style="display:flex; align-items:center; gap:25px; background: rgba(255,255,255,0.03); padding: 20px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.05);">
                            <div style="position: relative; flex-shrink: 0;">
                                <img src="${president?.avatar || 'assets/logo.png'}" style="width:75px; height:75px; border-radius:20px; border:3px solid #f59e0b; object-fit:cover; box-shadow: 0 8px 15px rgba(0,0,0,0.3);">
                            </div>
                            <div>
                                <div style="font-weight:900; color:#fff; font-size: 1.25rem; letter-spacing: -0.5px;">${president?.username || 'Başkan Seçilmedi'}</div>
                                <div style="font-size:0.8rem; color:#f59e0b; text-transform:uppercase; font-weight:900; margin-top: 5px; letter-spacing: 0.5px;">Kulüp Temsilcisi</div>
                            </div>
                        </div>
                        <div style="margin-top: 25px; display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                            <div style="text-align: center; padding: 15px; background: rgba(255,255,255,0.02); border-radius: 15px; border: 1px solid rgba(255,255,255,0.04);">
                                <div style="font-size: 0.7rem; color: #94a3b8; font-weight: 850; margin-bottom: 5px;">GÖREV SÜRESİ</div>
                                <div style="color: #fff; font-weight: 800; font-size: 1.05rem;">12 Gün</div>
                            </div>
                            <div style="text-align: center; padding: 15px; background: rgba(255,255,255,0.02); border-radius: 15px; border: 1px solid rgba(255,255,255,0.04);">
                                <div style="font-size: 0.7rem; color: #94a3b8; font-weight: 850; margin-bottom: 5px;">GÜVEN OYU</div>
                                <div style="color: #10b981; font-weight: 800; font-size: 1.05rem;">%94</div>
                            </div>
                        </div>
                    </div>

                    <!-- Polls Panel -->
                    <div class="active-poll glass-panel" style="padding:30px; border-radius: 24px; border: 1px solid rgba(236, 72, 153, 0.25); background: rgba(236, 72, 153, 0.02); backdrop-filter: blur(10px); box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                            <h4 style="margin:0; color:#ec4899; font-size: 1.3rem; font-weight: 900; display: flex; align-items: center; gap: 8px;"><i class="fa-solid fa-square-poll-vertical"></i> Aktif Oylama</h4>
                            <span class="pulse-dot" style="width: 8px; height: 8px; background: #ec4899; border-radius: 50%; box-shadow: 0 0 12px #ec4899;"></span>
                        </div>
                        ${fc.polls && fc.polls.length > 0 ? `
                            <div class="poll-content">
                                <p style="font-weight:800; margin-bottom:20px; color: #fff; font-size: 1.1rem; line-height: 1.4; letter-spacing: -0.2px;">${fc.polls[0].question}</p>
                                <div class="poll-options">
                                    ${(() => {
                                        const totalVotes = fc.polls[0].options.reduce((sum, o) => sum + (o.votes || 0), 0);
                                        return fc.polls[0].options.map((opt, i) => {
                                            const percentage = totalVotes > 0 ? Math.round(((opt.votes || 0) / totalVotes) * 100) : 0;
                                            return `
                                                <div class="poll-opt" onclick="ActorDetail.vote('${actor.id}', 0, ${i})" style="margin-bottom: 15px;">
                                                    <span style="font-weight: 800; position: relative; z-index: 2; color: #fff;">${opt.text}</span>
                                                    <div class="poll-bar" style="--target-width: ${percentage}%;"></div>
                                                    <span style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); z-index: 2; font-weight: 900; color: #fff; font-size: 0.95rem; text-shadow: 0 1px 3px rgba(0,0,0,0.5);">${percentage}%</span>
                                                </div>
                                            `;
                                        }).join('');
                                    })()}
                                </div>
                            </div>
                        ` : '<div style="text-align: center; padding: 40px 0;"><i class="fa-solid fa-inbox" style="font-size: 2.5rem; color: #475569; margin-bottom: 15px; opacity: 0.35;"></i><p style="color:#64748b; font-size:1rem; font-weight: 750;">Şu an aktif bir oylama bulunmuyor.</p></div>'}
                    </div>
                </div>

                <!-- Fan Feed Section -->
                <div class="fan-feed-section">
                    ${(isMember || isManager) ? `
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; flex-wrap: wrap; gap: 15px;">
                        <div>
                            <h4 style="margin:0; font-size: 1.7rem; font-weight: 900; color: #fff; letter-spacing: -0.5px;">Topluluk Paylaşımları</h4>
                            <p style="color: #64748b; font-size: 0.95rem; margin-top: 5px; font-weight: 600;">Hayranların ${actor.name} hakkındaki en yeni gönderileri</p>
                        </div>
                        <button class="btn-hero-secondary" onclick="ActorDetail.openPostModal('${actor.id}')" style="padding: 14px 28px; border-radius: 14px; font-weight: 850; border: 1px solid rgba(255,255,255,0.15); background: rgba(255,255,255,0.03); color: #fff; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.2);"><i class="fa-solid fa-pen-nib" style="color: #a78bfa;"></i> Bir Şeyler Paylaş</button>
                    </div>
                    
                    <div class="fan-posts-grid" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap:25px;">
                        ${fanPosts.map(p => {
                            const postUser = State.data.users?.find(u => u.id === p.authorId) || { username: p.author || 'Anonim', avatar: 'assets/logo.png' };
                            return `
                            <div class="social-post-card glass-card" style="padding: 0; overflow: hidden; display: flex; flex-direction: column; border-radius: 24px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); box-shadow: 0 8px 30px rgba(0,0,0,0.3);">
                                ${p.metadata?.image ? `<div style="height: 220px; overflow: hidden; position: relative;"><img src="${p.metadata.image}" style="width:100%; height:100%; object-fit:cover; transition: transform 0.5s;"> <div style="position: absolute; inset: 0; background: linear-gradient(transparent, rgba(15,15,20,0.6));"></div></div>` : ''}
                                <div style="padding: 25px; flex: 1; display: flex; flex-direction: column;">
                                    <div style="display:flex; align-items:center; gap:15px; margin-bottom: 20px;">
                                        <img src="${postUser.avatar}" style="width:46px; height:46px; border-radius:15px; object-fit:cover; border: 2px solid rgba(139, 92, 246, 0.3); box-shadow: 0 4px 10px rgba(0,0,0,0.2);">
                                        <div>
                                            <div style="font-weight:800; color:#fff; font-size: 1.05rem;">${postUser.username}</div>
                                            <div style="font-size:0.75rem; color:#64748b; font-weight: 700;">${new Date(p.createdAt || Date.now()).toLocaleDateString('tr-TR')}</div>
                                        </div>
                                    </div>
                                    <p style="color:#cbd5e1; font-size:1.05rem; line-height: 1.6; margin:0 0 20px 0; flex: 1; font-weight: 500; text-align: justify;">${p.content || p.text}</p>
                                    <div style="display:flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 20px;">
                                        <div style="display: flex; gap: 20px;">
                                            <div style="color: #94a3b8; font-size: 0.95rem; display: flex; align-items: center; gap: 8px; font-weight: 750; cursor: pointer; transition: 0.2s;" onclick="SocialFeed && typeof SocialFeed.likePost === 'function' ? SocialFeed.likePost('${p.id}') : ''"><i class="fa-regular fa-heart"></i> ${p.likes?.length || 0}</div>
                                            <div style="color: #94a3b8; font-size: 0.95rem; display: flex; align-items: center; gap: 8px; font-weight: 750;"><i class="fa-regular fa-comment"></i> ${p.comments?.length || 0}</div>
                                        </div>
                                        <div style="color: rgba(139, 92, 246, 0.6); font-size: 0.8rem; font-weight: 900; text-transform: uppercase; letter-spacing: 0.5px;">#FanCenter</div>
                                    </div>
                                </div>
                            </div>
                        `}).join('') || `
                            <div style="grid-column: 1/-1; text-align: center; padding: 60px; background: rgba(255,255,255,0.02); border-radius: 24px; border: 1px dashed rgba(255,255,255,0.1); backdrop-filter: blur(10px);">
                                <i class="fa-solid fa-feather-pointed" style="font-size: 3rem; color: #475569; margin-bottom: 20px; opacity: 0.35;"></i>
                                <h3 style="color: #fff; margin: 0 0 10px 0; font-weight: 800;">Henüz Paylaşım Yok</h3>
                                <p style="color: #64748b; font-weight: 600;">Bu oyuncu hakkında ilk paylaşımı sen yap!</p>
                            </div>
                        `}
                    </div>
                    ` : `
                    <div style="grid-column: 1/-1; text-align: center; padding: 60px; background: rgba(255,255,255,0.02); border-radius: 24px; border: 1px dashed rgba(255,255,255,0.1); backdrop-filter: blur(10px); margin-top: 20px;">
                        <i class="fa-solid fa-lock" style="font-size: 3rem; color: #475569; margin-bottom: 20px; opacity: 0.35;"></i>
                        <h3 style="color: #fff; margin: 0 0 10px 0; font-weight: 800;">Gizli İçerik</h3>
                        <p style="color: #64748b; font-weight: 600;">Topluluk paylaşımlarını görebilmek için kulübe üye olmalısınız.</p>
                    </div>
                    `}
                </div>
            </div>
            <style>
                .poll-opt { position:relative; background:rgba(255,255,255,0.02); padding:20px; border-radius:16px; cursor:pointer; overflow:hidden; border: 1px solid rgba(255,255,255,0.05); transition: all 0.3s ease; display: flex; align-items: center; justify-content: space-between; }
                .poll-opt:hover { background: rgba(255,255,255,0.05); border-color: rgba(139, 92, 246, 0.45); transform: translateX(5px); }
                .poll-bar { position:absolute; left:0; top:0; height:100%; background: linear-gradient(90deg, rgba(124, 58, 237, 0.35), rgba(236, 72, 153, 0.15)); z-index:0; animation: expandWidth 1.2s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
                .social-post-card:hover { transform: translateY(-8px); box-shadow: 0 25px 50px rgba(0,0,0,0.55); border-color: rgba(139, 92, 246, 0.35) !important; }
                .social-post-card:hover img { transform: scale(1.04); }
                .btn-hero-secondary:hover { background: rgba(255,255,255,0.08) !important; border-color: rgba(139, 92, 246, 0.4) !important; transform: translateY(-2px); }
                @keyframes pulse-light { 0% { opacity: 0.4; } 50% { opacity: 1; } 100% { opacity: 0.4; } }
                .pulse-dot { animation: pulse-light 2.5s infinite; }
            </style>
        `;
    },

    renderFanSidebar(actor) {
        if (!actor) return '';
        const fc = actor.fanCenter || { members: [], gallery: [], weeklyCheers: 0 };
        const isMember = State.currentUser && fc.members && fc.members.includes(State.currentUser.id);
        const userXP = (State.currentUser && State.currentUser.fanLevels && State.currentUser.fanLevels[actor.id]) || 0;
        const cardGlow = 'rgba(124, 58, 237, 0.4)';

        let cardHTML = '';
        if (State.currentUser) {
            if (isMember) {
                const { level, title } = this.getFanLevel(userXP);
                const currentLevelMinXP = (level - 1) * 50;
                const levelProgress = userXP - currentLevelMinXP;
                const levelProgressPercent = (levelProgress / 50) * 100;
                
                let memberCardGlow = cardGlow;
                let cardBg = 'linear-gradient(135deg, #4f46e5 0%, #7c3aed 50%, #db2777 100%)';
                if (level >= 5) {
                    cardBg = 'linear-gradient(135deg, #b45309 0%, #f59e0b 50%, #d97706 100%)';
                    memberCardGlow = 'rgba(245, 158, 11, 0.5)';
                } else if (level === 4) {
                    cardBg = 'linear-gradient(135deg, #be185d 0%, #ec4899 50%, #a21caf 100%)';
                    memberCardGlow = 'rgba(236, 72, 153, 0.5)';
                } else if (level === 3) {
                    cardBg = 'linear-gradient(135deg, #0d9488 0%, #06b6d4 50%, #0284c7 100%)';
                    memberCardGlow = 'rgba(6, 182, 212, 0.45)';
                }

                const today = new Date().toDateString();
                const lastCheer = localStorage.getItem(`dramicbox_cheer_date_${actor.id}_${State.currentUser.id}`);
                const hasCheeredToday = lastCheer === today;

                cardHTML = `
                    <div class="membership-card-wrap" style="position: relative; margin-bottom: 25px;">
                        <div class="membership-card" style="background: ${cardBg}; border-radius: 20px; padding: 25px; color: #fff; position: relative; overflow: hidden; box-shadow: 0 15px 35px ${memberCardGlow}; border: 1px solid rgba(255,255,255,0.2); aspect-ratio: 1.586/1; display: flex; flex-direction: column; justify-content: space-between; transition: all 0.3s ease; cursor: default;">
                            <div class="card-shimmer"></div>
                            
                            <div style="display: flex; justify-content: space-between; align-items: start; z-index: 2;">
                                <div>
                                    <div style="font-size: 0.65rem; font-weight: 800; text-transform: uppercase; letter-spacing: 2px; color: rgba(255,255,255,0.85);">HAYRAN KARTI</div>
                                    <div style="font-size: 1.15rem; font-weight: 900; letter-spacing: -0.5px; text-shadow: 0 2px 4px rgba(0,0,0,0.25);">${actor.name} Club</div>
                                </div>
                                <div style="font-size: 1.4rem; font-weight: 950; color: rgba(255,255,255,0.85); font-style: italic; letter-spacing: -1.5px; text-shadow: 0 2px 4px rgba(0,0,0,0.25);">DBox</div>
                            </div>
                            
                            <div style="display: flex; align-items: center; gap: 15px; margin: 15px 0; z-index: 2;">
                                <img src="${State.currentUser.avatar || 'assets/default-avatar.png'}" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(255,255,255,0.8); box-shadow: 0 4px 10px rgba(0,0,0,0.3);">
                                <div>
                                    <div style="font-size: 1.05rem; font-weight: 850; text-shadow: 0 2px 4px rgba(0,0,0,0.25);">${State.currentUser.username}</div>
                                    <div style="font-size: 0.75rem; font-weight: 800; color: rgba(255,255,255,0.95); background: rgba(0,0,0,0.3); padding: 3px 10px; border-radius: 50px; display: inline-block; margin-top: 4px; border: 1px solid rgba(255,255,255,0.15);">LVL ${level} - ${title}</div>
                                </div>
                            </div>
                            
                            <div style="z-index: 2;">
                                <div style="display: flex; justify-content: space-between; font-size: 0.65rem; font-weight: 800; color: rgba(255,255,255,0.85); margin-bottom: 5px; letter-spacing: 0.5px;">
                                    <span>SEVİYE İLERLEMESİ</span>
                                    <span>${levelProgress} / 50 XP</span>
                                </div>
                                <div style="width: 100%; height: 6px; background: rgba(0,0,0,0.25); border-radius: 3px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05);">
                                    <div style="width: ${levelProgressPercent}%; height: 100%; background: #fff; border-radius: 3px; box-shadow: 0 0 8px #fff;"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="glass-panel" style="padding: 22px; text-align: center; border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); background: rgba(255,255,255,0.01); margin-bottom: 25px; backdrop-filter: blur(10px); box-shadow: 0 8px 25px rgba(0,0,0,0.2);">
                        <h5 style="margin: 0 0 6px 0; color: #fff; font-size: 1.05rem; font-weight: 850;">Günlük Destek Gönder</h5>
                        <p style="color: #64748b; font-size: 0.8rem; margin: 0 0 16px 0; font-weight: 600; line-height: 1.4;">Destek göndererek haftalık popülarite puanını artır ve +10 XP kazan!</p>
                        
                        <button class="cheer-btn ${hasCheeredToday ? 'cheered' : ''}" onclick="ActorDetail.cheerActor('${actor.id}', event)" ${hasCheeredToday ? 'disabled' : ''} style="width: 100%; padding: 14px; border-radius: 12px; border: none; font-weight: 850; font-size: 0.95rem; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; justify-content: center; gap: 8px; background: ${hasCheeredToday ? 'rgba(255,255,255,0.05)' : 'linear-gradient(135deg, #ec4899, #db2777)'}; color: ${hasCheeredToday ? '#64748b' : '#fff'}; box-shadow: ${hasCheeredToday ? 'none' : '0 8px 22px rgba(236,72,153,0.3)'};">
                            <i class="fa-solid ${hasCheeredToday ? 'fa-circle-check' : 'fa-heart-circle-plus'}"></i>
                            ${hasCheeredToday ? 'Bugün Desteklediniz' : 'Destek Gönder (+10 XP)'}
                        </button>
                    </div>

                    <div class="glass-panel" style="padding: 22px; text-align: center; border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); background: rgba(255,255,255,0.01); margin-bottom: 25px; backdrop-filter: blur(10px); box-shadow: 0 8px 25px rgba(0,0,0,0.2);">
                        <h5 style="margin: 0 0 6px 0; color: #fff; font-size: 1.05rem; font-weight: 850;">Cheer Puanı Gönder</h5>
                        <div style="font-size: 1.3rem; font-weight: 900; color: #ec4899; margin: 10px 0 8px 0; display: flex; align-items: center; justify-content: center; gap: 6px;">
                            <i class="fa-solid fa-heart animate-pulse"></i> <span>${State.currentUser.stats?.cheerPoints || 0} Cheer</span>
                        </div>
                        <p style="color: #64748b; font-size: 0.8rem; margin: 0 0 16px 0; font-weight: 600; line-height: 1.4;">50 Cheer Puanı harcayarak haftalık popülarite puanını 50 artır ve +25 Hayran XP kazan!</p>
                        
                        <button class="cheer-btn" onclick="ActorDetail.sendCheerPoints('${actor.id}', event)" style="width: 100%; padding: 14px; border-radius: 12px; border: none; font-weight: 850; font-size: 0.95rem; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; justify-content: center; gap: 8px; background: linear-gradient(135deg, #7c3aed, #db2777); color: #fff; box-shadow: 0 8px 22px rgba(124,58,237,0.3);">
                            <i class="fa-solid fa-heart-pulse"></i>
                            Cheer Gönder (50 Cheer)
                        </button>
                    </div>
                `;
            } else {
                cardHTML = `
                    <div class="glass-panel" style="padding: 25px; text-align: center; border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); background: rgba(255,255,255,0.02); margin-bottom: 25px; backdrop-filter: blur(10px); box-shadow: 0 8px 25px rgba(0,0,0,0.2);">
                        <i class="fa-solid fa-address-card" style="font-size: 2.5rem; color: #475569; margin-bottom: 15px; opacity: 0.45;"></i>
                        <h5 style="margin: 0 0 8px 0; color: #fff; font-size: 1.15rem; font-weight: 850;">Hayran Kartı Alın</h5>
                        <p style="color: #94a3b8; font-size: 0.85rem; margin: 0 0 20px 0; line-height: 1.5; font-weight: 600;">Özel Hayran Kartı kazanmak, destek göndermek ve seviye atlamak için kulübe katılmalısınız.</p>
                        <button onclick="ActorDetail.joinFanClub('${actor.id}')" class="btn btn-primary" style="width: 100%; padding: 14px; border-radius: 12px; font-weight: 850; background: linear-gradient(135deg, #7c3aed, #6d28d9); color:#fff; border:none; cursor:pointer; box-shadow: 0 8px 20px rgba(124,58,237,0.3);">Kulübe Katıl</button>
                    </div>
                `;
            }
        } else {
            cardHTML = `
                <div class="glass-panel" style="padding: 25px; text-align: center; border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); background: rgba(255,255,255,0.02); margin-bottom: 25px; backdrop-filter: blur(10px); box-shadow: 0 8px 25px rgba(0,0,0,0.2);">
                    <i class="fa-solid fa-lock" style="font-size: 2.5rem; color: #475569; margin-bottom: 15px; opacity: 0.45;"></i>
                    <h5 style="margin: 0 0 8px 0; color: #fff; font-size: 1.15rem; font-weight: 850;">Hayran Kulübü</h5>
                    <p style="color: #94a3b8; font-size: 0.85rem; margin: 0 0 20px 0; line-height: 1.5; font-weight: 600;">Kulübe katılarak Hayran Kartı sahibi olmak ve günlük destek göndermek için giriş yapmalısınız.</p>
                    <button onclick="Auth && typeof Auth.showLogin === 'function' ? Auth.showLogin() : App.router('giris-yap')" class="btn btn-primary" style="width: 100%; padding: 14px; border-radius: 12px; font-weight: 850; background: linear-gradient(135deg, #7c3aed, #6d28d9); color:#fff; border:none; cursor:pointer; box-shadow: 0 8px 20px rgba(124,58,237,0.3);">Giriş Yap</button>
                </div>
            `;
        }

        return `
            ${cardHTML}
            
            <!-- Fan Stats Panel -->
            <div class="glass-panel" style="padding: 22px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); background: rgba(255,255,255,0.02); backdrop-filter: blur(10px); box-shadow: 0 8px 25px rgba(0,0,0,0.2);">
                <h4 style="margin: 0 0 15px 0; font-size: 1.15rem; color: #fff; font-weight: 850; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-chart-line" style="color: #f59e0b;"></i> İstatistikler
                </h4>
                <div style="display: grid; gap: 14px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 700;">Haftalık Destek Puanı</span>
                        <span style="color: #f59e0b; font-weight: 900; font-size: 1rem;">💖 ${fc.weeklyCheers || 0} Cheer</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 700;">Toplam Üye Sayısı</span>
                        <span style="color: #10b981; font-weight: 900; font-size: 1rem;">👤 ${fc.members?.length || 0}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 700;">Galeri Fotoğrafları</span>
                        <span style="color: #c084fc; font-weight: 900; font-size: 1rem;">📸 ${fc.gallery?.length || 0}</span>
                    </div>
                </div>
            </div>
            
            <style>
                .membership-card:hover {
                    transform: translateY(-5px) scale(1.02);
                    box-shadow: 0 25px 50px ${cardGlow};
                }
                .card-shimmer {
                    position: absolute;
                    inset: 0;
                    background: linear-gradient(120deg, transparent 30%, rgba(255,255,255,0.2) 40%, rgba(255,255,255,0.2) 50%, transparent 60%);
                    transform: translateX(-100%);
                    transition: 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
                    z-index: 1;
                    pointer-events: none;
                }
                .membership-card:hover .card-shimmer {
                    transform: translateX(100%);
                }
                .cheer-btn:not(:disabled):hover {
                    transform: translateY(-2px);
                    box-shadow: 0 10px 25px rgba(236,72,153,0.4);
                    background: linear-gradient(135deg, #f43f5e, #db2777) !important;
                }
            </style>
        `;
    },

    getRatingsArray(actor) {
        if (!actor || !actor.ratings) return [];
        if (Array.isArray(actor.ratings)) {
            return actor.ratings.map(r => {
                if (typeof r === 'object' && r !== null) {
                    return { userId: r.userId, score: Number(r.score || r.rating || 0) };
                } else {
                    return { userId: null, score: Number(r) };
                }
            });
        }
        if (typeof actor.ratings === 'object') {
            return Object.entries(actor.ratings).map(([userId, val]) => {
                if (typeof val === 'object' && val !== null) {
                    return { userId: val.userId || userId, score: Number(val.score || val.rating || 0) };
                }
                return { userId: userId, score: Number(val) };
            });
        }
        return [];
    },

    calculateRating(actor) {
        const ratings = this.getRatingsArray(actor);
        if (ratings.length === 0) return "8.5";
        const sum = ratings.reduce((s, r) => s + r.score, 0);
        return (sum / ratings.length).toFixed(1);
    },

    getUserRating(actor) {
        const ratings = this.getRatingsArray(actor);
        if (ratings.length === 0) return 0;
        const currentUserId = State.currentUser?.id;
        if (!currentUserId) return 0;
        return ratings.find(r => String(r.userId) === String(currentUserId))?.score || 0;
    },

    async submitRating(actorId, score) {
        if (!State.currentUser) return Toast.warning('Puan vermek için giriş yapın!');
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return Toast.error('Oyuncu bulunamadı.');
        
        try {
            const response = await fetch('api/db.php?action=actor-fan-action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ actorId, type: 'rating', score })
            });
            const result = await response.json();
            if (result.success && result.actor) {
                // Update actor locally
                const idx = State.data.actors.findIndex(a => a.id === actorId);
                if (idx > -1) {
                    State.data.actors[idx] = result.actor;
                }
                Toast.success('Puanınız kaydedildi!');
                this.render(actor.name);
            } else {
                Toast.error(result.message || 'Puan kaydedilemedi.');
            }
        } catch (e) {
            console.error(e);
            Toast.error('Bir bağlantı hatası oluştu.');
        }
    },

    hoverRating(n) {
        const stars = document.querySelectorAll('.actor-star-rating-10 .star-unit');
        stars.forEach((star, idx) => {
            if (idx < n) {
                star.style.color = '#f59e0b';
            } else {
                star.style.color = '#334155';
            }
        });
    },

    resetRating() {
        const container = document.querySelector('.actor-star-rating-10');
        if (!container) return;
        const nameHeader = document.querySelector('.actor-info h1');
        const name = nameHeader ? nameHeader.textContent.trim() : '';
        const normalize = (str) => {
            if (!str) return '';
            return str.toLowerCase()
                .replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ş/g, 's')
                .replace(/ı/g, 'i').replace(/ö/g, 'o').replace(/ç/g, 'c')
                .replace(/[^a-z0-9]/g, '');
        };
        const searchName = normalize(name);
        const actor = State.data.actors.find(a => a.name === name || normalize(a.name) === searchName);
        const userRating = this.getUserRating(actor);
        const stars = container.querySelectorAll('.star-unit');
        stars.forEach((star, idx) => {
            if (idx < userRating) {
                star.style.color = '#f59e0b';
            } else {
                star.style.color = '#334155';
            }
        });
    },

    async startElection(actorId) {
        if (!confirm('Fan kulübü başkanlığı için yeni bir oylama başlatılsın mı?')) return;
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;
        
        actor.fanCenter.polls.unshift({
            id: 'poll-' + Date.now(),
            question: 'Yeni Fan Kulübü Başkanı Kim Olmalı?',
            options: [
                { text: 'Aday: Melis_KDrama', votes: 15 },
                { text: 'Aday: OppaLover99', votes: 22 },
                { text: 'Aday: DramicBox_Admin', votes: 45 }
            ],
            type: 'election'
        });
        
        await db.saveItem('actors', actor.name, actor);
        Toast.success('Seçim süreci başlatıldı! Tüm hayranlar bildirim aldı.');
        this.render(actor.name);
    },

    async joinFanClub(actorId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Fan Kulübüne katılmak için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;
        
        try {
            const response = await fetch('api/db.php?action=actor-fan-action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ actorId, type: 'join' })
            });
            const result = await response.json();
            if (result.success && result.actor) {
                const idx = State.data.actors.findIndex(a => a.id === actorId);
                if (idx > -1) {
                    State.data.actors[idx] = result.actor;
                }
                Toast.success(result.message || 'İşlem başarılı!');
                this.render(actor.name);
            } else {
                Toast.error(result.message || 'Katılım işlemi başarısız oldu.');
            }
        } catch (e) {
            console.error(e);
            Toast.error('Bir bağlantı hatası oluştu.');
        }
    },

    async vote(actorId, pollIdx, optIdx) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Oy kullanmak için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;
        
        try {
            const response = await fetch('api/db.php?action=actor-fan-action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ actorId, type: 'vote', pollIdx, optIdx })
            });
            const result = await response.json();
            if (result.success && result.actor) {
                const idx = State.data.actors.findIndex(a => a.id === actorId);
                if (idx > -1) {
                    State.data.actors[idx] = result.actor;
                }
                Toast.success('Oyunuz kaydedildi.');
                this.render(actor.name);
            } else {
                Toast.error(result.message || 'Oy kullanma işlemi başarısız oldu.');
            }
        } catch (e) {
            console.error(e);
            Toast.error('Bir bağlantı hatası oluştu.');
        }
    },

    openPostModal(actorId) {
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;
        
        const modal = document.getElementById('d-global-modal');
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width:400px; padding:30px; border-radius:24px; border:1px solid rgba(255,255,255,0.1); background:rgba(15,15,20,0.95); backdrop-filter:blur(20px);">
                <div class="modal-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2 style="margin:0; font-size:1.4rem; font-weight:800; color:#fff;">Fan Paylaşımı</h2>
                    <button onclick="ActorDetail.closePostModal()" style="background:none; border:none; color:#64748b; font-size:1.5rem; cursor:pointer;">&times;</button>
                </div>
                <div class="form-group" style="margin-bottom:20px;">
                    <label style="display:block; margin-bottom:8px; font-size:0.8rem; color:#94a3b8; font-weight:700;">MESAJINIZ</label>
                    <textarea id="fan-post-text" style="width:100%; min-height:100px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.1); border-radius:12px; color:#fff; padding:12px; font-family:inherit;" placeholder="Oyuncu hakkında bir şeyler yazın..."></textarea>
                </div>
                <div class="form-group" style="margin-bottom:25px;">
                    <label style="display:block; margin-bottom:8px; font-size:0.8rem; color:#94a3b8; font-weight:700;">RESİM URL (OPSİYONEL)</label>
                    <input type="text" id="fan-post-img" style="width:100%; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.1); border-radius:12px; color:#fff; padding:12px;" placeholder="https://...">
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary btn-block" style="width:100%; background:linear-gradient(135deg,#7c3aed,#6d28d9); border:none; padding:14px; border-radius:14px; font-weight:800; color:#fff; cursor:pointer;" onclick="ActorDetail.saveFanPost('${actorId}')">Paylaşımı Yayınla</button>
                </div>
            </div>
        `;
        modal.style.display = 'flex';
    },

    closePostModal() {
        const modal = document.getElementById('d-global-modal');
        if (modal) {
            modal.style.display = 'none';
            modal.innerHTML = '';
        }
    },

    async saveFanPost(actorId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Paylaşım yapmak için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        const text = document.getElementById('fan-post-text').value;
        const img = document.getElementById('fan-post-img').value;
        if (!text && !img) return Toast.warning('Boş paylaşım yapılamaz.');
        
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;
        
        const newSocialPost = {
            id: 'soc_' + Date.now(),
            userId: State.currentUser.id,
            content: text,
            type: 'actor-fan',
            metadata: {
                actorId: actor.id,
                actorName: actor.name,
                image: img || null
            },
            likes: [],
            comments: [],
            createdAt: Date.now()
        };

        await db.syncItem('socialPosts', newSocialPost);
        
        Toast.success("Paylaşımınız Hayran Merkezine ve Sosyal Hub'a eklendi!");
        this.closePostModal();
        this.render(actor.name);
    },

    getFanLevel(xp) {
        const level = Math.floor((xp || 0) / 50) + 1;
        let title = "Yeni Hayran";
        if (level === 2) title = "Destekçi";
        else if (level === 3) title = "Sadık Hayran";
        else if (level === 4) title = "Süper Hayran";
        else if (level >= 5) title = "Efsanevi Hayran";
        return { level, title };
    },

    showCheerAnimation(event) {
        const emojis = ['❤️', '💖', '🥰', '✨', '🌸', '👑'];
        const container = document.body;
        const startX = event ? event.clientX : window.innerWidth / 2;
        const startY = event ? event.clientY : window.innerHeight / 2;

        for (let i = 0; i < 12; i++) {
            const span = document.createElement('span');
            span.innerText = emojis[Math.floor(Math.random() * emojis.length)];
            span.style.position = 'fixed';
            span.style.left = `${startX}px`;
            span.style.top = `${startY}px`;
            span.style.pointerEvents = 'none';
            span.style.fontSize = `${Math.random() * 20 + 20}px`;
            span.style.zIndex = '99999';
            span.style.transition = 'all 1.2s cubic-bezier(0.1, 0.8, 0.3, 1)';
            
            container.appendChild(span);

            span.offsetWidth; // force layout reflow

            const angle = (Math.random() * Math.PI) - Math.PI;
            const distance = Math.random() * 150 + 100;
            const targetX = startX + Math.cos(angle) * distance;
            const targetY = startY + Math.sin(angle) * distance;

            span.style.transform = 'translate(-50%, -50%)';
            span.style.left = `${targetX}px`;
            span.style.top = `${targetY}px`;
            span.style.opacity = '0';
            span.style.filter = 'blur(1px)';

            setTimeout(() => {
                span.remove();
            }, 1200);
        }
    },

    async cheerActor(actorId, event) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Destek göndermek için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;
        
        const fc = actor.fanCenter || { members: [] };
        if (!fc.members || !fc.members.includes(State.currentUser.id)) {
            return Toast.warning('Önce hayran kulübüne katılmalısınız!');
        }

        const today = new Date().toDateString();
        const lastCheer = localStorage.getItem(`dramicbox_cheer_date_${actorId}_${State.currentUser.id}`);
        if (lastCheer === today) {
            return Toast.info('Bugün zaten destek gönderdiniz! Yarın tekrar gelin.');
        }

        try {
            const response = await fetch('api/db.php?action=actor-fan-action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ actorId, type: 'cheer' })
            });
            const result = await response.json();
            
            if (result.success && result.actor) {
                const idx = State.data.actors.findIndex(a => a.id === actorId);
                if (idx > -1) {
                    State.data.actors[idx] = result.actor;
                }

                if (!State.currentUser.fanLevels) State.currentUser.fanLevels = {};
                const currentXP = State.currentUser.fanLevels[actorId] || 0;
                const newXP = currentXP + 10;
                const fanLevels = { ...State.currentUser.fanLevels };
                fanLevels[actorId] = newXP;
                
                await db.updateUser(State.currentUser.id, { fanLevels });

                localStorage.setItem(`dramicbox_cheer_date_${actorId}_${State.currentUser.id}`, today);

                this.showCheerAnimation(event);
                
                const oldLevel = Math.floor(currentXP / 50) + 1;
                const newLevel = Math.floor(newXP / 50) + 1;
                
                Toast.success('Desteğiniz ulaştı! +10 XP Kazandınız 💖');
                
                if (newLevel > oldLevel) {
                    const { title: newTitle } = this.getFanLevel(newXP);
                    setTimeout(() => {
                        Toast.success(`🎉 TEBRİKLER! Seviye atladınız! Yeni Unvanınız: ${newTitle} (Seviye ${newLevel})`);
                    }, 1500);
                }
                
                this.render(actor.name);
            } else {
                Toast.error(result.message || 'Destek gönderme başarısız.');
            }
        } catch (e) {
            console.error(e);
            Toast.error('Bir hata oluştu.');
        }
    },

    async sendCheerPoints(actorId, event) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Cheer göndermek için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;
        
        const fc = actor.fanCenter || { members: [] };
        if (!fc.members || !fc.members.includes(State.currentUser.id)) {
            return Toast.warning('Önce hayran kulübüne katılmalısınız!');
        }

        const currentCheerPoints = State.currentUser.stats?.cheerPoints || 0;
        if (currentCheerPoints < 50) {
            return Toast.warning('Yetersiz Cheer Puanı! Sandıklar açarak Cheer Puanı kazanabilirsiniz.');
        }

        try {
            // Deduct 50 points
            if (!State.currentUser.stats) State.currentUser.stats = {};
            State.currentUser.stats.cheerPoints = currentCheerPoints - 50;

            // Grant user fan club XP: +25 XP
            if (!State.currentUser.fanLevels) State.currentUser.fanLevels = {};
            const currentXP = State.currentUser.fanLevels[actorId] || 0;
            const newXP = currentXP + 25;
            State.currentUser.fanLevels[actorId] = newXP;

            // Update user in Database
            await db.updateUser(State.currentUser.id, { 
                stats: State.currentUser.stats, 
                fanLevels: State.currentUser.fanLevels 
            });

            // Update actor weeklyCheers
            if (!actor.fanCenter) {
                actor.fanCenter = { polls: [], members: [], gallery: [], weeklyCheers: 0 };
            }
            actor.fanCenter.weeklyCheers = (actor.fanCenter.weeklyCheers || 0) + 50;

            // Save actor in Database
            await db.saveItem('actors', actor.name, actor);

            // Show hearts animation
            this.showCheerAnimation(event);

            const oldLevel = Math.floor(currentXP / 50) + 1;
            const newLevel = Math.floor(newXP / 50) + 1;

            Toast.success('50 Cheer Puanı gönderildi! +25 Hayran XP Kazandınız 💖');

            if (newLevel > oldLevel) {
                const { title: newTitle } = this.getFanLevel(newXP);
                setTimeout(() => {
                    Toast.success(`🎉 TEBRİKLER! Seviye atladınız! Yeni Unvanınız: ${newTitle} (Seviye ${newLevel})`);
                }, 1500);
            }

            this.render(actor.name);
        } catch (e) {
            console.error('sendCheerPoints error:', e);
            Toast.error('Cheer gönderilirken bir hata oluştu.');
        }
    },

    renderFanGallery(actor) {
        if (!actor) return '<div class="glass-panel" style="padding:40px; text-align:center;">Önce oyuncu verisi yüklenmeli.</div>';
        const fc = actor.fanCenter || { gallery: [], members: [] };
        const gallery = fc.gallery || [];
        const isMember = State.currentUser && fc.members && fc.members.includes(State.currentUser.id);

        return `
            <div class="gallery-wrapper tab-fade-in" style="display: flex; flex-direction: column; gap: 25px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h4 style="margin:0; font-size: 1.6rem; font-weight: 900; color: #fff;">Fotoğraf Galerisi</h4>
                        <p style="color: #64748b; font-size: 0.95rem; margin-top: 5px; font-weight: 600;">${actor.name} fan topluluğunun paylaştığı özel fotoğraflar</p>
                    </div>
                    ${isMember ? `
                        <button class="btn-hero-primary" onclick="ActorDetail.openUploadPhotoModal('${actor.id}')" style="padding: 14px 28px; border-radius: 14px; font-weight: 850; border: none; background: linear-gradient(135deg, #7c3aed, #db2777); color: #fff; cursor: pointer; transition: all 0.3s ease; display: flex; align-items: center; gap: 8px; box-shadow: 0 8px 20px rgba(124,58,237,0.3);">
                            <i class="fa-solid fa-cloud-arrow-up"></i> Fotoğraf Ekle
                        </button>
                    ` : `
                        <div style="font-size:0.85rem; color:#64748b; font-weight:700; background:rgba(255,255,255,0.02); padding:10px 20px; border-radius:10px; border:1px solid rgba(255,255,255,0.05); backdrop-filter: blur(10px);">
                            Galeriye fotoğraf eklemek için hayran kulübüne katılın.
                        </div>
                    `}
                </div>

                ${gallery.length > 0 ? `
                    <div class="gallery-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px;">
                        ${gallery.map(photo => `
                            <div class="gallery-item-card" onclick="ActorDetail.openLightbox('${photo.url}', '${photo.username}')" style="position: relative; aspect-ratio: 1; border-radius: 16px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05); cursor: pointer; transition: all 0.3s ease;">
                                <img src="${photo.url}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                                <div class="gallery-hover-overlay" style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.85) 0%, transparent 70%); display: flex; flex-direction: column; justify-content: flex-end; padding: 15px; opacity: 0; transition: opacity 0.3s ease; pointer-events: none; z-index: 2;">
                                    <div style="color: #fff; font-weight: 850; font-size: 0.85rem; display: flex; align-items: center; gap: 6px;">
                                        <i class="fa-solid fa-circle-user" style="color: #c084fc;"></i> ${photo.username}
                                    </div>
                                    <div style="color: #94a3b8; font-size: 0.7rem; font-weight: 700; margin-top: 4px;">
                                        ${new Date(photo.createdAt).toLocaleDateString('tr-TR')}
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                ` : `
                    <div style="text-align: center; padding: 60px; background: rgba(255,255,255,0.02); border-radius: 24px; border: 1px dashed rgba(255,255,255,0.1); backdrop-filter: blur(10px);">
                        <i class="fa-regular fa-image" style="font-size: 3rem; color: #475569; margin-bottom: 20px; opacity: 0.35;"></i>
                        <h3 style="color: #fff; margin: 0 0 10px 0; font-weight: 800;">Galeri Henüz Boş</h3>
                        <p style="color: #64748b; font-weight: 600;">Bu oyuncunun galerisine ilk fotoğrafı sen yükle!</p>
                    </div>
                `}
            </div>

            <style>
                .gallery-item-card:hover {
                    transform: scale(1.03) translateY(-3px);
                    box-shadow: 0 15px 35px rgba(0,0,0,0.6);
                    border-color: rgba(139, 92, 246, 0.45);
                }
                .gallery-item-card:hover img {
                    transform: scale(1.06);
                }
                .gallery-item-card:hover .gallery-hover-overlay {
                    opacity: 1;
                }
            </style>
        `;
    },

    openUploadPhotoModal(actorId) {
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;

        const modal = document.getElementById('d-global-modal');
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width:400px; padding:30px; border-radius:24px; border:1px solid rgba(255,255,255,0.15); background:rgba(15,15,20,0.96); backdrop-filter:blur(25px); box-shadow: 0 25px 50px rgba(0,0,0,0.5);">
                <div class="modal-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2 style="margin:0; font-size:1.45rem; font-weight:900; color:#fff; background: linear-gradient(135deg, #fff, #c084fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Galeriye Fotoğraf Ekle</h2>
                    <button onclick="ActorDetail.closePostModal()" style="background:none; border:none; color:#64748b; font-size:1.6rem; cursor:pointer; display: flex; align-items: center; justify-content: center; width: 30px; height: 30px; transition: 0.2s;">&times;</button>
                </div>
                <div class="form-group" style="margin-bottom:25px;">
                    <label style="display:block; margin-bottom:10px; font-size:0.8rem; color:#94a3b8; font-weight:800; letter-spacing: 0.5px;">RESİM BAĞLANTISI (URL)</label>
                    <input type="text" id="fan-photo-url" style="width:100%; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.1); border-radius:12px; color:#fff; padding:14px; font-size: 0.95rem; transition: all 0.3s;" placeholder="https://...">
                    <div style="font-size: 0.75rem; color: #64748b; margin-top: 8px; font-weight: 600; line-height: 1.4;">Dış bağlantı (link) olarak geçerli bir resim adresi girin.</div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary btn-block" style="width:100%; background:linear-gradient(135deg,#7c3aed,#db2777); border:none; padding:15px; border-radius:14px; font-weight:900; color:#fff; cursor:pointer; font-size: 1rem; transition: all 0.3s; box-shadow: 0 8px 20px rgba(124,58,237,0.3);" onclick="ActorDetail.savePhoto('${actorId}')">Fotoğrafı Yükle</button>
                </div>
            </div>
        `;
        modal.style.display = 'flex';
    },

    async savePhoto(actorId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Fotoğraf eklemek için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        const photoUrl = document.getElementById('fan-photo-url').value.trim();
        if (!photoUrl) return Toast.warning('Resim URL adresi boş olamaz.');

        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;

        try {
            const response = await fetch('api/db.php?action=actor-fan-action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ actorId, type: 'upload-photo', photoUrl })
            });
            const result = await response.json();
            if (result.success && result.actor) {
                const idx = State.data.actors.findIndex(a => a.id === actorId);
                if (idx > -1) {
                    State.data.actors[idx] = result.actor;
                }
                Toast.success('Fotoğrafınız başarıyla galeriye eklendi! 📸');
                this.closePostModal();
                this.render(actor.name);
            } else {
                Toast.error(result.message || 'Yükleme başarısız.');
            }
        } catch (e) {
            console.error(e);
            Toast.error('Bir bağlantı hatası oluştu.');
        }
    },

    openLightbox(url, username) {
        let lightbox = document.getElementById('d-gallery-lightbox');
        if (!lightbox) {
            lightbox = document.createElement('div');
            lightbox.id = 'd-gallery-lightbox';
            lightbox.style.cssText = `
                position: fixed;
                inset: 0;
                background: rgba(10, 10, 12, 0.95);
                backdrop-filter: blur(15px);
                z-index: 999999;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                opacity: 0;
                transition: opacity 0.3s ease;
            `;
            lightbox.onclick = () => this.closeLightbox();
            document.body.appendChild(lightbox);
        }

        lightbox.innerHTML = `
            <button onclick="ActorDetail.closeLightbox()" style="position: absolute; top: 25px; right: 25px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; width: 50px; height: 50px; border-radius: 50%; font-size: 1.5rem; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: 0.2s;"><i class="fa-solid fa-xmark"></i></button>
            <div style="max-width: 90%; max-height: 80%; display: flex; align-items: center; justify-content: center; overflow: hidden; border-radius: 20px; box-shadow: 0 25px 60px rgba(0,0,0,0.8); border: 1px solid rgba(255,255,255,0.15);">
                <img src="${url}" style="max-width: 100%; max-height: 100%; object-fit: contain;">
            </div>
            <div style="margin-top: 20px; color: #fff; font-size: 1.1rem; font-weight: 850; background: rgba(255,255,255,0.05); padding: 12px 30px; border-radius: 50px; border: 1px solid rgba(255,255,255,0.08); display: inline-flex; align-items: center; gap: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.3);">
                <i class="fa-solid fa-circle-user" style="color: #c084fc; font-size: 1.25rem;"></i> Paylaşan: @${username}
            </div>
        `;

        lightbox.style.display = 'flex';
        lightbox.offsetWidth;
        lightbox.style.opacity = '1';
    },

    closeLightbox() {
        const lightbox = document.getElementById('d-gallery-lightbox');
        if (lightbox) {
            lightbox.style.opacity = '0';
            setTimeout(() => {
                lightbox.style.display = 'none';
            }, 300);
        }
    },

    openManagementPanel(actorId) {
        const actor = State.data.actors.find(a => a.id === actorId);
        if (!actor) return;
        const fc = actor.fanCenter || { pendingMembers: [] };
        const pending = fc.pendingMembers || [];
        
        const pendingHtml = pending.length > 0 ? pending.map(userId => {
            const u = State.data.users?.find(user => user.id === userId) || { username: 'Bilinmeyen Kullanıcı' };
            return `
                <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.05); padding:10px 15px; border-radius:10px; margin-bottom:10px;">
                    <div style="color:#fff; font-weight:700;">${u.username}</div>
                    <div style="display:flex; gap:10px;">
                        <button onclick="ActorDetail.approvePendingMember('${actorId}', '${userId}')" style="background:#10b981; border:none; padding:5px 15px; border-radius:8px; color:#fff; cursor:pointer; font-weight:bold;">Onayla</button>
                        <button onclick="ActorDetail.rejectPendingMember('${actorId}', '${userId}')" style="background:#ef4444; border:none; padding:5px 15px; border-radius:8px; color:#fff; cursor:pointer; font-weight:bold;">Reddet</button>
                    </div>
                </div>
            `;
        }).join('') : '<div style="color:#94a3b8; font-size:0.9rem;">Bekleyen onay isteği bulunmuyor.</div>';

        const modal = document.getElementById('d-global-modal');
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width:500px; padding:30px; border-radius:24px; border:1px solid rgba(255,255,255,0.15); background:rgba(15,15,20,0.96); backdrop-filter:blur(25px); max-height:80vh; overflow-y:auto;">
                <div class="modal-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2 style="margin:0; font-size:1.45rem; font-weight:900; color:#fff;">Kulüp Yönetim Paneli</h2>
                    <button onclick="ActorDetail.closePostModal()" style="background:none; border:none; color:#64748b; font-size:1.6rem; cursor:pointer;">&times;</button>
                </div>
                
                <h3 style="color:#a78bfa; font-size:1.1rem; margin-bottom:15px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">Bekleyen Başvurular</h3>
                <div style="margin-bottom:30px;">
                    ${pendingHtml}
                </div>

                <h3 style="color:#ec4899; font-size:1.1rem; margin-bottom:15px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:10px;">Yeni Anket Oluştur</h3>
                <div class="form-group" style="margin-bottom:15px;">
                    <input type="text" id="poll-question" placeholder="Anket Sorusu..." style="width:100%; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff; padding:10px;">
                </div>
                <div class="form-group" style="margin-bottom:15px;">
                    <input type="text" id="poll-opt-1" placeholder="Seçenek 1" style="width:100%; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff; padding:10px; margin-bottom:10px;">
                    <input type="text" id="poll-opt-2" placeholder="Seçenek 2" style="width:100%; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff; padding:10px; margin-bottom:10px;">
                    <input type="text" id="poll-opt-3" placeholder="Seçenek 3 (Opsiyonel)" style="width:100%; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff; padding:10px;">
                </div>
                <button onclick="ActorDetail.submitNewPoll('${actorId}')" style="width:100%; background:linear-gradient(135deg, #db2777, #9d174d); border:none; padding:12px; border-radius:10px; color:#fff; font-weight:bold; cursor:pointer;">Anketi Başlat</button>
            </div>
        `;
        modal.style.display = 'flex';
    },

    async processMemberAction(actorId, targetUserId, actionType) {
        try {
            const response = await fetch('api/db.php?action=actor-fan-action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ actorId, type: actionType, targetUserId })
            });
            const result = await response.json();
            if (result.success && result.actor) {
                const idx = State.data.actors.findIndex(a => a.id === actorId);
                if (idx > -1) State.data.actors[idx] = result.actor;
                Toast.success(result.message || 'İşlem başarılı!');
                this.render(result.actor.name);
                this.openManagementPanel(actorId);
            } else {
                Toast.error(result.message || 'İşlem başarısız.');
            }
        } catch(e) {
            console.error(e);
            Toast.error('Bir bağlantı hatası oluştu.');
        }
    },

    approvePendingMember(actorId, targetUserId) {
        this.processMemberAction(actorId, targetUserId, 'approve-join');
    },
    
    rejectPendingMember(actorId, targetUserId) {
        this.processMemberAction(actorId, targetUserId, 'reject-join');
    },

    async submitNewPoll(actorId) {
        const question = document.getElementById('poll-question').value.trim();
        const opt1 = document.getElementById('poll-opt-1').value.trim();
        const opt2 = document.getElementById('poll-opt-2').value.trim();
        const opt3 = document.getElementById('poll-opt-3').value.trim();

        if(!question || !opt1 || !opt2) {
            return Toast.warning('Lütfen soruyu ve en az 2 seçeneği doldurun.');
        }

        const options = [opt1, opt2];
        if(opt3) options.push(opt3);

        try {
            const response = await fetch('api/db.php?action=actor-fan-action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ actorId, type: 'create-poll', question, options })
            });
            const result = await response.json();
            if (result.success && result.actor) {
                const idx = State.data.actors.findIndex(a => a.id === actorId);
                if (idx > -1) State.data.actors[idx] = result.actor;
                Toast.success(result.message || 'Anket oluşturuldu!');
                this.closePostModal();
                this.render(result.actor.name);
            } else {
                Toast.error(result.message || 'İşlem başarısız.');
            }
        } catch(e) {
            console.error(e);
            Toast.error('Bir bağlantı hatası oluştu.');
        }
    }
};

window.ActorDetail = ActorDetail;
