/**
 * Dramicbox Live Player - The "Twitch/Kick" Experience
 */
var LivePlayer = {
    currentStream: null,
    chatInterval: null,
    messages: [],

    init(streamId) {
        this.renderLayout();
        this.loadStream(streamId);
    },

    renderLayout() {
        const view = document.getElementById('live-view');
        if (!view) return;

        view.innerHTML = `
            <div class="live-player-container">
                <div class="live-main-content">
                    <!-- Video Area -->
                    <div class="live-video-wrapper glass-panel">
                        <video id="live-video-element" autoplay playsinline></video>
                        <div id="live-video-overlay-alerts" class="video-overlay-alerts"></div>
                        <div id="live-poll-overlay" class="poll-overlay"></div>
                        <div id="live-overlay" class="live-overlay">
                            <div class="live-badge">LIVE</div>
                            <div class="viewer-count"><i class="fa-solid fa-eye"></i> <span id="live-viewer-count">0</span></div>
                            <button class="theater-toggle" onclick="LivePlayer.toggleTheater()"><i class="fa-solid fa-expand"></i></button>
                        </div>
                    </div>

                    <!-- Stream Info -->
                    <div class="live-info-panel glass-panel">
                        <div class="broadcaster-header">
                            <div class="broadcaster-info">
                                <img id="broadcaster-avatar" src="assets/logo.png">
                                <div>
                                    <h2 id="stream-title">Yükleniyor...</h2>
                                    <p id="broadcaster-name">Yayıncı</p>
                                    <div id="stream-tags" class="stream-tags-list"></div>
                                </div>
                            </div>
                            <div class="stream-actions">
                                <button class="btn btn-primary" onclick="LivePlayer.follow()"><i class="fa-solid fa-heart"></i> Takip Et</button>
                                <button class="btn btn-secondary" onclick="LivePlayer.showDonateModal()"><i class="fa-solid fa-coins"></i> Destek Ol</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Chat Area -->
                <div class="live-chat-panel glass-panel">
                    <div class="chat-header">
                        <h3>Canlı Sohbet</h3>
                        <div class="chat-settings"><i class="fa-solid fa-gear"></i></div>
                    </div>
                    <div id="chat-messages" class="chat-messages">
                        <div class="chat-welcome">Sohbet odasına hoş geldiniz! Topluluk kurallarına uymayı unutmayın.</div>
                    </div>
                    <div class="chat-input-area">
                        <div class="coin-bar-container">
                            <div class="coin-bar-progress" id="coin-bar-fill" style="width: 0%"></div>
                            <span id="coin-bar-text">Hedef: 0 / 1000 Coins</span>
                        </div>
                        <div class="input-wrapper">
                            <input type="text" id="chat-input" placeholder="Mesaj gönder..." onkeydown="if(event.key==='Enter') LivePlayer.sendMessage()">
                            <button onclick="LivePlayer.sendMessage()"><i class="fa-solid fa-paper-plane"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    async loadStream(streamId) {
        // 1. Get stream data from API
        const res = await fetch('api/db.php?action=live-action&live_action=get-active-streams');
        const data = await res.json();
        const stream = data.streams.find(s => s.id === streamId);
        
        if (!stream) {
            Toast.error('Yayın bulunamadı veya sona erdi.');
            App.router('home');
            return;
        }

        this.currentStream = stream;
        document.getElementById('stream-title').textContent = stream.title;
        document.getElementById('broadcaster-name').innerHTML = `${stream.broadcasterName} <span class="broadcaster-lvl">LVL ${stream.broadcasterLevel || 1}</span>`;
        document.getElementById('live-viewer-count').textContent = stream.viewerCount || 0;

        const tagsContainer = document.getElementById('stream-tags');
        if (tagsContainer) {
            tagsContainer.innerHTML = (stream.tags || []).map(t => `<span class="stream-tag">#${t}</span>`).join('');
        }

        // 2. Start WebRTC connection via LiveService
        if (window.LiveService) {
            const remoteStream = await LiveService.joinStream(streamId);
            if (remoteStream) {
                const video = document.getElementById('live-video-element');
                video.srcObject = remoteStream;
            }
        }

        // 3. Start Chat Polling
        this.startChatPolling();
    },

    startChatPolling() {
        if (this.chatInterval) clearInterval(this.chatInterval);
        this.chatInterval = setInterval(async () => {
            const data = await LiveService.getChat(this.currentStream.id);
            if (data.success) {
                this.updateChat(data.messages);
                this.checkPoll();
            }
        }, 3000);
    },

    updateChat(newMessages) {
        const container = document.getElementById('chat-messages');
        if (!container) return;

        // Only update if there are new messages
        if (newMessages.length === this.messages.length) return;
        
        this.messages = newMessages;
        container.innerHTML = this.messages.map(m => {
            if (m.type === 'donation') {
                return `
                    <div class="chat-msg donation">
                        <div class="donation-header"><b>${m.username}</b> ${m.amount} Coins gönderdi!</div>
                        <div class="donation-body">${m.message}</div>
                    </div>
                `;
            }
            
            const isMod = m.role === 'admin' || m.role === 'moderator' || (this.currentStream.moderators || []).includes(m.userId);
            const modBadge = isMod ? '<i class="fa-solid fa-shield-halved chat-mod-badge"></i>' : '';
            const broadcasterBadge = m.userId === this.currentStream.broadcasterId ? '<i class="fa-solid fa-crown chat-crown-badge"></i>' : '';

            return `
                <div class="chat-msg">
                    <span class="chat-author" style="color: ${this.getUserColor(m.username)}">${modBadge}${broadcasterBadge}${m.username}:</span>
                    <span class="chat-text">${m.message}</span>
                </div>
            `;
        }).join('');
        
        // Handle new donation alerts
        newMessages.forEach(m => {
            if (m.type === 'donation' && !this.messages.find(prev => prev.id === m.id)) {
                this.showDonationAlert(m);
            }
        });

        this.messages = newMessages;
        container.scrollTop = container.scrollHeight;
        this.updateCoinBar();
    },

    updateCoinBar() {
        const totalDonations = this.messages
            .filter(m => m.type === 'donation')
            .reduce((sum, m) => sum + (m.amount || 0), 0);
        
        const goal = 1000;
        const percent = Math.min((totalDonations / goal) * 100, 100);
        
        const bar = document.getElementById('coin-bar-fill');
        const text = document.getElementById('coin-bar-text');
        
        if (bar) bar.style.width = percent + '%';
        if (text) text.textContent = `Hedef: ${totalDonations} / ${goal} Coins`;
    },

    getUserColor(username) {
        const colors = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];
        let hash = 0;
        for (let i = 0; i < username.length; i++) hash = username.charCodeAt(i) + ((hash << 5) - hash);
        return colors[Math.abs(hash) % colors.length];
    },

    async sendMessage() {
        const input = document.getElementById('chat-input');
        const text = input.value.trim();
        if (!text) return;

        const res = await LiveService.sendChat(this.currentStream.id, text);
        if (res.success) {
            input.value = '';
            // Immediately add to UI for responsiveness
            this.updateChat([...this.messages, res.message]);
        }
    },

    showDonateModal() {
        const modal = document.getElementById('m-hub-modal');
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width:400px; text-align:center;">
                <div class="modal-header">
                    <h2>Yayıncıyı Destekle</h2>
                    <button onclick="ManagementHub.closeModal()">&times;</button>
                </div>
                <p style="color:#64748b;">DramicCoin göndererek yayıncıya destek olabilir ve adınızı sohbette duyurabilirsiniz!</p>
                <div class="donation-options" style="display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin:20px 0;">
                    <button class="btn btn-secondary" onclick="LivePlayer.donate(100)">100 <i class="fa-solid fa-coins"></i></button>
                    <button class="btn btn-secondary" onclick="LivePlayer.donate(500)">500 <i class="fa-solid fa-coins"></i></button>
                    <button class="btn btn-secondary" onclick="LivePlayer.donate(1000)">1000 <i class="fa-solid fa-coins"></i></button>
                    <button class="btn btn-secondary" onclick="LivePlayer.donate(5000)">5000 <i class="fa-solid fa-coins"></i></button>
                </div>
                <div class="form-group">
                    <label>Özel Miktar</label>
                    <input type="number" id="custom-donation" class="form-input" placeholder="Miktar girin...">
                </div>
                <button class="btn btn-primary btn-block" style="margin-top:15px;" onclick="LivePlayer.donate(document.getElementById('custom-donation').value)">Gönder</button>
            </div>
        `;
        modal.style.display = 'flex';
    },

    async donate(amount) {
        amount = parseInt(amount);
        if (!amount || amount <= 0) return Toast.error('Geçerli bir miktar girin.');

        const res = await LiveService.sendCoins(this.currentStream.id, amount);
        if (res.success) {
            Toast.success(`${amount} DramicCoin başarıyla gönderildi!`);
            ManagementHub.closeModal();
            // Update local user coins
            if (State.currentUser) State.currentUser.stats.coins = res.newBalance;
        } else {
            Toast.error(res.message || 'Bir hata oluştu.');
        }
    },

    toggleTheater() {
        const container = document.querySelector('.live-player-container');
        container.classList.toggle('theater-mode');
        Toast.info(container.classList.contains('theater-mode') ? 'Tiyatro Modu Aktif' : 'Normal Görünüm');
    },

    showDonationAlert(m) {
        const container = document.getElementById('live-video-overlay-alerts');
        if (!container) return;

        const alert = document.createElement('div');
        alert.className = 'donation-alert-popup animate-bounce-in';
        alert.innerHTML = `
            <div class="alert-icon"><i class="fa-solid fa-coins"></i></div>
            <div class="alert-content">
                <div class="alert-user">${m.username}</div>
                <div class="alert-amount">${m.amount} DramicCoin!</div>
                <div class="alert-msg">${m.message || 'Harika yayın!'}</div>
            </div>
        `;
        
        container.appendChild(alert);
        
        // Play notification sound
        const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
        audio.volume = 0.5;
        audio.play().catch(e => console.log("Sound blocked by browser policy"));

        setTimeout(() => {
            alert.classList.add('animate-fade-out');
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    }
    },

    async checkPoll() {
        if (!this.currentStream) return;
        // The currentStream data might be old, let's refresh it occasionally or rely on the chat/poll specific API if we had one.
        // For now, let's fetch the stream object again to get the latest poll.
        const res = await fetch(`api/db.php?action=live-action&live_action=get-active-streams`);
        const data = await res.json();
        const stream = data.streams.find(s => s.id === this.currentStream.id);
        
        if (stream && stream.activePoll) {
            this.renderPoll(stream.activePoll);
        } else {
            document.getElementById('live-poll-overlay').innerHTML = '';
        }
    },

    renderPoll(poll) {
        const container = document.getElementById('live-poll-overlay');
        if (poll.expiresAt < Math.floor(Date.now() / 1000)) {
            container.innerHTML = '';
            return;
        }

        const hasVoted = poll.voters.includes(State.currentUser?.id);
        
        container.innerHTML = `
            <div class="poll-card glass-panel">
                <div class="poll-header">
                    <h4>${poll.question}</h4>
                    <div class="poll-timer"><i class="fa-solid fa-clock"></i> ${Math.max(0, poll.expiresAt - Math.floor(Date.now() / 1000))}s</div>
                </div>
                <div class="poll-options">
                    ${poll.options.map((opt, idx) => {
                        const percent = poll.totalVotes > 0 ? Math.round((opt.votes / poll.totalVotes) * 100) : 0;
                        return `
                            <div class="poll-option ${hasVoted ? 'voted' : ''}" onclick="${!hasVoted ? `LivePlayer.votePoll(${idx})` : ''}">
                                <div class="option-bg" style="width: ${percent}%"></div>
                                <div class="option-text">
                                    <span>${opt.text}</span>
                                    ${hasVoted ? `<span>%${percent}</span>` : ''}
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
                <div class="poll-footer">${poll.totalVotes} oy kullanıldı</div>
            </div>
        `;
    },

    async votePoll(optionIdx) {
        if (!State.currentUser) return Toast.error('Oy kullanmak için giriş yapmalısınız.');
        
        const res = await fetch('api/db.php?action=live-action&live_action=poll-vote', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                streamId: this.currentStream.id,
                optionIndex: optionIdx
            })
        });

        const data = await res.json();
        if (data.success) {
            Toast.success('Oyunuz kaydedildi!');
            this.renderPoll(data.poll);
        } else {
            Toast.error(data.message || 'Hata oluştu.');
        }
    }
};
