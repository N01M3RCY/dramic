/**
 * Dramicbox Broadcaster Studio - Streamer Dashboard
 */
var BroadcasterStudio = {
    localStream: null,
    previewMode: null,
    isLive: false,
    chatInterval: null,
    messages: [],

    init() {
        this.renderLayout();
    },

    renderLayout() {
        const view = document.getElementById('live-view');
        if (!view) return;

        view.innerHTML = `
            <div class="studio-container">
                <div class="studio-main">
                    <div class="studio-header glass-panel">
                        <div style="display:flex; align-items:center; gap:15px;">
                            <div class="studio-icon"><i class="fa-solid fa-video"></i></div>
                            <div>
                                <h2 style="margin:0; color:#fff;">Yayıncı Stüdyosu</h2>
                                <p style="margin:5px 0 0; color:#64748b; font-size:0.85rem;">Platformda canlı yayına geçin ve topluluğunuzla etkileşim kurun.</p>
                            </div>
                        </div>
                        <div id="studio-status" class="status-offline">OFFLINE</div>
                    </div>

                    <div class="studio-grid">
                        <!-- Preview Area -->
                        <div class="studio-preview-card glass-panel">
                            <div class="preview-header">Önizleme</div>
                            <div class="preview-video-container">
                                <video id="studio-preview-video" autoplay muted playsinline></video>
                                <div id="live-video-overlay-alerts" class="video-overlay-alerts"></div>
                                <div id="preview-placeholder">Yayın başlatılmadı</div>
                            </div>
                            <div class="preview-controls">
                                <div class="form-group" style="flex:1;">
                                    <input type="text" id="stream-title-input" class="form-input" placeholder="Yayın Başlığı girin...">
                                </div>
                                <div class="form-group" style="flex:1;">
                                    <input type="text" id="stream-tags-input" class="form-input" placeholder="Etiketler (virgül ile ayırın)">
                                </div>
                                <div class="stream-source-toggles">
                                    <button id="toggle-camera" class="btn btn-secondary" onclick="BroadcasterStudio.setupPreview('camera')"><i class="fa-solid fa-camera"></i> Kamera</button>
                                    <button id="toggle-screen" class="btn btn-secondary" onclick="BroadcasterStudio.setupPreview('screen')"><i class="fa-solid fa-desktop"></i> Ekran</button>
                                </div>
                            </div>
                        </div>

                        <!-- Quick Stats -->
                        <div class="studio-stats-card glass-panel">
                            <div class="stat-item">
                                <div class="stat-label">İzleyici</div>
                                <div class="stat-value" id="stat-viewers">0</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-label">Süre</div>
                                <div class="stat-value" id="stat-duration">00:00:00</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-label">Coins</div>
                                <div class="stat-value" id="stat-coins">0</div>
                            </div>
                            <button id="broadcast-btn" class="btn btn-primary btn-block" style="margin-top:20px; font-weight:800;" onclick="BroadcasterStudio.toggleBroadcast()">YAYINA BAŞLA</button>
                        </div>
                    </div>
                </div>

                <!-- Chat & Mod Hub -->
                <div class="studio-sidebar glass-panel">
                    <div class="sidebar-tabs">
                        <button class="active">Sohbet</button>
                        <button onclick="BroadcasterStudio.showModTools()">Moderatör</button>
                    </div>
                    <div id="studio-chat-messages" class="chat-messages"></div>
                    <div class="chat-input-area">
                        <input type="text" id="studio-chat-input" placeholder="Sohbetçilere cevap ver..." onkeydown="if(event.key==='Enter') BroadcasterStudio.sendMessage()">
                    </div>
                </div>
            </div>
        `;
    },

    async setupPreview(mode) {
        try {
            if (this.localStream) {
                this.localStream.getTracks().forEach(t => t.stop());
            }

            if (mode === 'camera') {
                this.localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            } else {
                this.localStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
            }

            this.previewMode = mode;
            const video = document.getElementById('studio-preview-video');
            video.srcObject = this.localStream;
            document.getElementById('preview-placeholder').style.display = 'none';
            video.style.display = 'block';
            
            Toast.success(`${mode === 'camera' ? 'Kamera' : 'Ekran'} kaynağı hazır.`);
        } catch (err) {
            Toast.error('Kaynak alınamadı: ' + err.message);
        }
    },

    async toggleBroadcast() {
        if (!this.isLive) {
            const title = document.getElementById('stream-title-input').value.trim();
            const tagsStr = document.getElementById('stream-tags-input').value.trim();
            if (!title) return Toast.error('Lütfen bir yayın başlığı girin.');
            if (!this.localStream) return Toast.error('Lütfen önce bir görüntü kaynağı seçin (Kamera veya Ekran).');

            const tags = tagsStr.split(',').map(t => t.trim()).filter(t => t);

            // 1. Call LiveService (mevcut önizleme akışını kullan)
            const stream = await LiveService.startBroadcast({
                title,
                tags,
                mode: this.previewMode || 'camera',
                existingStream: this.localStream
            });
            if (stream) {
                this.isLive = true;
                this.updateUIStatus(true);
                this.startChatPolling();
                this.startClock();
            } else {
                Toast.error('Yayın başlatılamadı. Kamera/ekran izni ve yayın yetkisini kontrol edin.');
            }
        } else {
            if (confirm('Yayını sonlandırmak istediğinize emin misiniz?')) {
                await LiveService.stopBroadcast();
                this.isLive = false;
                this.updateUIStatus(false);
                clearInterval(this.chatInterval);
                clearInterval(this.clockInterval);
            }
        }
    },

    updateUIStatus(live) {
        const status = document.getElementById('studio-status');
        const btn = document.getElementById('broadcast-btn');
        if (live) {
            status.textContent = 'LIVE';
            status.className = 'status-online';
            btn.textContent = 'YAYINI DURDUR';
            btn.className = 'btn red-btn btn-block';
        } else {
            status.textContent = 'OFFLINE';
            status.className = 'status-offline';
            btn.textContent = 'YAYINA BAŞLA';
            btn.className = 'btn btn-primary btn-block';
        }
    },

    startClock() {
        let seconds = 0;
        this.clockInterval = setInterval(() => {
            seconds++;
            const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
            const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
            const s = (seconds % 60).toString().padStart(2, '0');
            document.getElementById('stat-duration').textContent = `${h}:${m}:${s}`;
            
            // Heartbeat every 30 seconds
            if (seconds % 30 === 0) {
                LiveService.heartbeat();
            }

            // Capture Thumbnail every 60 seconds
            if (seconds % 60 === 0) {
                this.captureThumbnail();
            }
        }, 1000);
    },

    async captureThumbnail() {
        const video = document.getElementById('studio-preview-video');
        if (!video || video.style.display === 'none') return;

        const canvas = document.createElement('canvas');
        canvas.width = 640;
        canvas.height = 360;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const thumbnail = canvas.toDataURL('image/jpeg', 0.7);
        
        await fetch('api/db.php?action=live-action&live_action=update-stream', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                streamId: LiveService.currentStreamId,
                thumbnail: thumbnail
            })
        });
        
        console.log("Stream thumbnail updated.");
    },

    startChatPolling() {
        if (this.chatInterval) clearInterval(this.chatInterval);
        this.chatInterval = setInterval(async () => {
            const data = await LiveService.getChat(LiveService.currentStreamId);
            if (data.success) {
                this.updateChat(data.messages);
            }
        }, 3000);
    },

    updateChat(newMessages) {
        const container = document.getElementById('studio-chat-messages');
        if (!container || newMessages.length === this.messages.length) return;

        this.messages = newMessages;
        container.innerHTML = this.messages.map(m => `
            <div class="chat-msg ${m.type === 'donation' ? 'donation' : ''}">
                <div style="display:flex; justify-content:space-between;">
                    <b>${m.username}:</b>
                    <button class="chat-delete-btn" onclick="BroadcasterStudio.deleteMessage('${m.id}')"><i class="fa-solid fa-trash"></i></button>
                </div>
                <div>${m.message}</div>
                ${m.amount ? `<div style="color:#ffd700; font-weight:800;">+${m.amount} Coins</div>` : ''}
            </div>
        `).join('');
        container.scrollTop = container.scrollHeight;

        // Handle new donation alerts for streamer
        newMessages.forEach(m => {
            if (m.type === 'donation' && !this.messages.find(prev => prev.id === m.id)) {
                this.showDonationAlert(m);
                // Update total coins stat
                const total = document.getElementById('stat-coins');
                if (total) {
                    const current = parseInt(total.textContent) || 0;
                    total.textContent = current + (m.amount || 0);
                }
            }
        });
    },

    showDonationAlert(m) {
        const container = document.getElementById('live-video-overlay-alerts');
        if (!container) return;

        const alert = document.createElement('div');
        alert.className = 'donation-alert-popup animate-bounce-in';
        alert.style.transform = 'translate(-50%, -50%) scale(0.8)'; // Slightly smaller for studio
        alert.innerHTML = `
            <div class="alert-icon"><i class="fa-solid fa-coins"></i></div>
            <div class="alert-content">
                <div class="alert-user">${m.username}</div>
                <div class="alert-amount">${m.amount} DramicCoin!</div>
                <div class="alert-msg">${m.message || 'Harika yayın!'}</div>
            </div>
        `;
        
        container.appendChild(alert);

        // Play notification sound
        const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
        audio.volume = 0.6;
        audio.play().catch(e => console.log("Sound blocked by browser policy"));

        setTimeout(() => {
            alert.classList.add('animate-fade-out');
            setTimeout(() => alert.remove(), 500);
        }, 6000);
    },

    async deleteMessage(msgId) {
        if (!confirm('Bu mesajı silmek istediğinize emin misiniz?')) return;
        const res = await fetch('api/db.php?action=live-action&live_action=chat-delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ msgId })
        });
        const data = await res.json();
        if (data.success) {
            Toast.success('Mesaj silindi.');
            this.messages = this.messages.filter(m => m.id !== msgId);
            this.updateChat(this.messages);
        }
    },

    async sendMessage() {
        const input = document.getElementById('studio-chat-input');
        const text = input.value.trim();
        if (!text || !LiveService.currentStreamId) return;

        const res = await LiveService.sendChat(LiveService.currentStreamId, text);
        if (res.success) {
            input.value = '';
            this.updateChat([...this.messages, res.message]);
        }
    },

    showModTools() {
        const sidebar = document.querySelector('.studio-sidebar');
        sidebar.innerHTML = `
            <div class="sidebar-tabs">
                <button onclick="BroadcasterStudio.init()">Sohbet</button>
                <button class="active">Moderatör</button>
            </div>
            <div class="mod-hub-content" style="padding:20px; overflow-y:auto; flex:1;">
                <div class="glass-panel" style="padding:15px; margin-bottom:20px; border:1px solid rgba(124, 58, 237, 0.2);">
                    <h4 style="margin:0 0 10px; color:#fff;"><i class="fa-solid fa-square-poll-vertical"></i> Canlı Anket Başlat</h4>
                    <div class="form-group">
                        <input type="text" id="poll-question" class="form-input" placeholder="Soru nedir?">
                    </div>
                    <div class="form-group" style="margin-top:10px;">
                        <input type="text" id="poll-options" class="form-input" placeholder="Seçenekler (Virgül ile ayırın)">
                    </div>
                    <button class="btn btn-primary btn-block" style="margin-top:10px;" onclick="BroadcasterStudio.createPoll()">ANKETİ BAŞLAT</button>
                </div>

                <div id="active-poll-results" class="glass-panel" style="padding:15px; display:none;">
                    <h4 style="margin:0 0 10px; color:#fff;">Aktif Anket Durumu</h4>
                    <div id="poll-results-body"></div>
                </div>
            </div>
        `;
    },

    async createPoll() {
        const question = document.getElementById('poll-question').value.trim();
        const optionsStr = document.getElementById('poll-options').value.trim();
        if (!question || !optionsStr) return Toast.error('Soru ve seçenekler zorunludur.');

        const options = optionsStr.split(',').map(s => s.trim()).filter(s => s);
        if (options.length < 2) return Toast.error('En az 2 seçenek gereklidir.');

        const res = await fetch('api/db.php?action=live-action&live_action=poll-create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                streamId: LiveService.currentStreamId,
                question,
                options
            })
        });

        const data = await res.json();
        if (data.success) {
            Toast.success('Anket başlatıldı!');
            document.getElementById('poll-question').value = '';
            document.getElementById('poll-options').value = '';
        }
    },
};
