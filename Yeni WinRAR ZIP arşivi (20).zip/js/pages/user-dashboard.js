/**
 * DramicBox - User Dashboard (Personalized Home)
 * Premium UI for logged-in users
 */

const UserDashboard = {
    init() {
        console.log('🏠 User Dashboard Initializing...');
        this.render();
    },

    render() {
        const user = State.currentUser;
        if (!user) return;

        if (localStorage.getItem('hide_welcome_banner') === 'true') {
            console.log('🏠 User Dashboard hidden by user preference');
            return;
        }

        const container = document.getElementById('home-view');
        if (!container) return;

        // Create or get the personalized area
        let dashArea = document.getElementById('user-personalized-area');
        if (!dashArea) {
            dashArea = document.createElement('div');
            dashArea.id = 'user-personalized-area';
            dashArea.className = 'dashboard-wrapper';
            dashArea.style = 'background: rgba(15, 12, 41, 0.7); backdrop-filter: blur(20px); border-bottom: 2px solid var(--accent-color); margin-bottom: 30px; padding-bottom: 40px; position: relative; z-index: 100;';
            container.prepend(dashArea);
        }

        dashArea.innerHTML = `
            <div class="dashboard-hero section" style="padding-top: 100px; margin-bottom: 20px;">
                <div class="container">
                    <div class="welcome-header" style="display: flex; align-items: center; gap: 25px; margin-bottom: 30px; position: relative;">
                        <!-- Close Button -->
                        <button class="banner-close" 
                                onclick="document.getElementById('user-personalized-area').remove(); localStorage.setItem('hide_welcome_banner', 'true'); Toast.info('Tavsiye alanı kapatıldı. Tekrar açmak için profil ayarlarınızı kullanabilirsiniz.')" 
                                style="position: absolute; top: 0; right: 0; background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.4); color: #ef4444; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; transition: all 0.3s ease;"
                                onmouseover="this.style.background='#ef4444'; this.style.color='white'"
                                onmouseout="this.style.background='rgba(239, 68, 68, 0.2)'; this.style.color='#ef4444'">
                            <i class="fa-solid fa-xmark"></i>
                        </button>

                        <div class="user-avatar-main" style="position: relative;">
                            <img src="${user.avatar || 'assets/logo.png'}" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 4px solid var(--accent-color); box-shadow: 0 0 30px rgba(124, 58, 237, 0.3);">
                            <div style="position: absolute; bottom: 0; right: 0; background: var(--accent-color); color: white; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 800; box-shadow: 0 4px 10px rgba(0,0,0,0.5);">
                                LVL ${Gamification?.getLevel(user.stats?.xp || 0) || 1}
                            </div>
                        </div>
                        <div>
                            <h1 style="font-size: 2.5rem; font-weight: 800; margin-bottom: 5px;">Merhaba, ${user.username}! 👋</h1>
                            <p style="color: var(--text-secondary); font-size: 1.1rem;">Bugün senin için harika içeriklerimiz var.</p>
                            <div style="display: flex; gap: 15px; margin-top: 15px;">
                                ${user.vipUntil ? `
                                    <div style="background: linear-gradient(135deg, #f59e0b, #d97706); padding: 8px 18px; border-radius: 12px; color: #fff; font-size: 0.9rem; font-weight: 800; display: flex; align-items: center; gap: 10px; box-shadow: 0 4px 15px rgba(245, 158, 11, 0.3);">
                                        <i class="fa-solid fa-crown"></i> VIP ÜYE (${Math.ceil((new Date(user.vipUntil) - new Date()) / (1000 * 60 * 60 * 24))} Gün Kaldı)
                                    </div>
                                ` : ''}
                                <div style="background: rgba(124, 58, 237, 0.2); border: 1px solid rgba(124, 58, 237, 0.3); padding: 8px 18px; border-radius: 12px; color: #a78bfa; font-size: 0.9rem; font-weight: 800; display: flex; align-items: center; gap: 10px;">
                                    <i class="fa-solid fa-star"></i> ${user.role?.toUpperCase() || 'ÜYE'}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container" style="display: flex; flex-direction: column; gap: 40px;">
                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 40px;">
                    <div style="display: flex; flex-direction: column; gap: 40px;">
                        <!-- Continue Watching (Dashboard version) -->
                        <section id="dash-continue" class="section-mini" style="display: none;">
                            <h2 style="font-size: 1.3rem; font-weight: 700; color: white; margin-bottom: 15px;"><i class="fa-solid fa-play" style="color: var(--accent-color); margin-right: 10px;"></i> İzlemeye Devam Et</h2>
                            <div id="dash-continue-grid" class="media-grid" style="grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));"></div>
                        </section>

                        <!-- Personalized Mix -->
                        <section id="dash-recommendations" class="section-mini">
                            <h2 style="font-size: 1.3rem; font-weight: 700; color: white; margin-bottom: 15px;"><i class="fa-solid fa-wand-magic-sparkles" style="color: #ec4899; margin-right: 10px;"></i> Senin İçin Seçtiklerimiz</h2>
                            <div id="dash-mix-grid" class="media-grid" style="grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));"></div>
                        </section>
                    </div>

                    <!-- Sidebar -->
                    <div style="display: flex; flex-direction: column; gap: 25px;">
                         <!-- Support Tickets -->
                         <section id="dash-support" class="section-mini" style="background: rgba(124, 58, 237, 0.05); border-radius: 20px; border: 1px solid rgba(124, 58, 237, 0.15); padding: 20px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                                <h3 style="font-size: 1.1rem; font-weight: 700; color: white; margin:0;"><i class="fa-solid fa-headset" style="color: #a78bfa; margin-right: 10px;"></i> Destek Talepleri</h3>
                                <button onclick="UserDashboard.openTicketModal()" class="btn-icon-small" title="Yeni Talep"><i class="fa-solid fa-plus"></i></button>
                            </div>
                            <div id="dash-tickets-list" style="display:flex; flex-direction:column; gap:8px;">
                                <!-- Tickets Load Here -->
                            </div>
                            <style>
                                .btn-icon-small { width: 30px; height: 30px; border-radius: 8px; background: #7c3aed; border: none; color: white; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: 0.3s; }
                                .btn-icon-small:hover { transform: scale(1.1); background: #8b5cf6; }
                                .ticket-mini-card { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); padding: 10px; border-radius: 12px; cursor: pointer; transition: 0.2s; }
                                .ticket-mini-card:hover { background: rgba(255,255,255,0.08); border-color: rgba(124, 58, 237, 0.3); }
                                .ticket-mini-card .status-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; margin-right: 5px; }
                                .status-açık { background: #10b981; }
                                .status-yanıtlandı { background: #3b82f6; box-shadow: 0 0 8px #3b82f6; }
                                .status-kapalı { background: #64748b; }
                            </style>
                        </section>

                         <section id="dash-social" class="section-mini" style="background: rgba(255,255,255,0.02); border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); padding: 20px;">
                            <h3 style="font-size: 1.1rem; font-weight: 700; color: white; margin-bottom: 15px;"><i class="fa-solid fa-user-group" style="color: #3b82f6; margin-right: 10px;"></i> Arkadaş Aktivite</h3>
                            <div id="dash-social-feed" style="max-height: 200px; overflow-y: auto;">
                                <p style="color: var(--text-secondary); text-align: center; padding: 20px; font-size: 0.8rem;">Takip ettiğin kimse yok!</p>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        `;

        this.loadContinueWatching();
        this.loadPopularMovies();
        this.loadRecommendations();
        this.loadFollowedSeries();
        this.loadSocialFeed();
        this.loadTickets();
    },

    loadTickets() {
        const user = State.currentUser;
        const container = document.getElementById('dash-tickets-list');
        if (!container) return;

        const tickets = (State.data.tickets || []).filter(t => t.userId === user.id);
        if (tickets.length === 0) {
            container.innerHTML = `<p style="color:#64748b; font-size:0.8rem; text-align:center;">Henüz bir talebin yok.</p>`;
            return;
        }

        container.innerHTML = tickets.map(t => `
            <div class="ticket-mini-card" onclick="UserDashboard.openTicketDetails('${t.id}')">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div style="font-size:0.85rem; color:#fff; font-weight:700;">${t.subject}</div>
                    <span class="status-dot status-${t.status}"></span>
                </div>
                <div style="font-size:0.7rem; color:#94a3b8; margin-top:4px;">${new Date(t.updatedAt || t.createdAt).toLocaleDateString()}</div>
            </div>
        `).join('');
    },

    openTicketModal() {
        const modal = document.createElement('div');
        modal.className = 'modal show';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width: 450px;">
                <div class="modal-header">
                    <h2>Yeni Destek Talebi</h2>
                    <button onclick="this.closest('.modal').remove()">&times;</button>
                </div>
                <div class="form-group">
                    <label>Konu</label>
                    <input type="text" id="ticket-subject" placeholder="Örn: Sorun Bildirimi">
                </div>
                <div class="form-group">
                    <label>Kategori</label>
                    <select id="ticket-category">
                        <option value="Hata Bildirimi">Hata Bildirimi</option>
                        <option value="Öneri">Öneri</option>
                        <option value="Üyelik İşlemleri">Üyelik İşlemleri</option>
                        <option value="Telif / DMCA">Telif / DMCA</option>
                        <option value="Diğer">Diğer</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Mesajınız</label>
                    <textarea id="ticket-message" placeholder="Size nasıl yardımcı olabiliriz?" style="min-height:100px;"></textarea>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary btn-block" onclick="UserDashboard.createTicket(this)">Talep Oluştur</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async createTicket(btn) {
        const subject = document.getElementById('ticket-subject').value.trim();
        const category = document.getElementById('ticket-category').value;
        const message = document.getElementById('ticket-message').value.trim();

        if (!subject || !message) return Toast.warning('Lütfen konu ve mesaj alanlarını doldurun.');

        const newTicket = {
            id: 'tkt-' + Date.now(),
            userId: State.currentUser.id,
            username: State.currentUser.username,
            subject,
            category,
            message,
            status: 'açık',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            conversations: []
        };

        if (!State.data.tickets) State.data.tickets = [];
        State.data.tickets.unshift(newTicket);
        await db.save();

        Toast.success('Talebiniz başarıyla oluşturuldu!');
        btn.closest('.modal').remove();
        this.loadTickets();
    },

    openTicketDetails(id) {
        const ticket = State.data.tickets.find(t => t.id === id);
        if (!ticket) return;

        const modal = document.createElement('div');
        modal.className = 'modal show';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width: 500px;">
                <div class="modal-header">
                    <h2>${ticket.subject} <small style="font-size:0.8rem; color:var(--accent-color);">[${ticket.status}]</small></h2>
                    <button onclick="this.closest('.modal').remove()">&times;</button>
                </div>
                <div style="max-height: 300px; overflow-y: auto; padding:10px; background:rgba(0,0,0,0.2); border-radius:12px; margin-bottom:15px;">
                    <div style="margin-bottom:15px; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:10px;">
                        <span style="font-weight:700; color:#fff;">Siz:</span>
                        <p style="margin:5px 0; font-size:0.9rem; color:#cbd5e1;">${ticket.message}</p>
                    </div>
                    ${ticket.conversations.map(c => `
                        <div style="margin-bottom:15px; text-align: ${c.role === 'staff' ? 'left' : 'right'}">
                            <span style="font-size:0.75rem; color:${c.role === 'staff' ? '#7c3aed' : '#94a3b8'}; font-weight:800;">${c.senderName}:</span>
                            <div style="background: ${c.role === 'staff' ? 'rgba(124,58,237,0.1)' : 'rgba(255,255,255,0.05)'}; padding:8px 12px; border-radius:10px; margin-top:3px; font-size:0.9rem;">${c.text}</div>
                        </div>
                    `).join('')}
                </div>
                ${ticket.status !== 'kapalı' ? `
                    <div class="form-group">
                        <textarea id="ticket-reply-user" placeholder="Bir şey eklemek isterseniz..." style="min-height:60px;"></textarea>
                    </div>
                    <button class="btn btn-primary btn-block" onclick="UserDashboard.replyToTicket('${ticket.id}', this)">Yanıt Gönder</button>
                ` : '<div style="text-align:center; color:#64748b;">Bu talep sonlandırılmıştır.</div>'}
            </div>
        `;
        document.body.appendChild(modal);
    },

    async replyToTicket(id, btn) {
        const text = document.getElementById('ticket-reply-user').value.trim();
        if (!text) return;

        const ticket = State.data.tickets.find(t => t.id === id);
        if (ticket) {
            ticket.conversations.push({
                role: 'user',
                senderName: State.currentUser.username,
                text,
                at: new Date().toISOString()
            });
            ticket.status = 'açık';
            ticket.updatedAt = new Date().toISOString();
            await db.save();
            Toast.success('Yanıtınız iletildi.');
            btn.closest('.modal').remove();
            this.openTicketDetails(id);
        }
    },

    openCopyrightModal() {
        const modal = document.createElement('div');
        modal.className = 'modal show';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width: 500px;">
                <div class="modal-header">
                    <h2>Copyright / DMCA Report</h2>
                    <button onclick="this.closest('.modal').remove()">&times;</button>
                </div>
                <form onsubmit="UserDashboard.submitCopyright(event)">
                    <div class="form-group">
                        <label>Your Name / Organization</label>
                        <input type="text" name="reporterName" required>
                    </div>
                    <div class="form-group">
                        <label>Your Contact Email</label>
                        <input type="email" name="reporterEmail" required>
                    </div>
                    <div class="form-group">
                        <label>Infringed Content Name</label>
                        <input type="text" name="contentTitle" placeholder="Series name..." required>
                    </div>
                    <div class="form-group">
                        <label>Evidence Link (Official Web, etc.)</label>
                        <input type="url" name="evidenceLink" required>
                    </div>
                    <div class="form-group">
                        <label>Detailed Explanation</label>
                        <textarea name="reason" style="min-height:80px;" required></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary btn-block">Submit Report</button>
                    </div>
                </form>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async submitCopyright(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());

        const report = {
            id: 'cr-' + Date.now(),
            ...data,
            status: 'beklemede',
            createdAt: new Date().toISOString()
        };

        if (!State.data.copyrightReports) State.data.copyrightReports = [];
        State.data.copyrightReports.push(report);
        await db.save();

        Toast.success('Report submitted. We will review it shortly.');
        e.target.closest('.modal').remove();
    },

    renderDashboardCard(series, isHistory = false) {
        if (window.StandardCard) {
            return StandardCard.render(series, isHistory ? { episode: series.lastEp + 1 } : {});
        }
        
        // Fallback if component not loaded
        const img = series.poster || series.coverImage || 'assets/logo.png';
        return `
            <div class="premium-card" onclick="App.router('detail', '${series.id}')">
                <img src="${img}" class="card-poster" loading="lazy">
                <div class="card-overlay">
                    <h3 class="card-title">${series.title}</h3>
                </div>
            </div>
        `;
    }
};

window.UserDashboard = UserDashboard;
