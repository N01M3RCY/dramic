// Dramicbox Ultimate Player Module v2.1
const Player = {
    currentSeries: null,
    currentEpisode: null,
    plyrInstance: null,
    hlsInstance: null,
    playerEditMode: false,
    defaultLayout: ['video', 'meta', 'details', 'comments'],

    getPlayerLayout() {
        return [...this.defaultLayout];
    },

    savePlayerLayout(layout) {
        // Drag-drop layout customization is disabled
    },

    toggleEditMode() {
        // Drag-drop layout customization is disabled
    },

    resetPlayerLayout() {
        // Drag-drop layout customization is disabled
    },

    initDragDrop() {
        // Drag-drop layout customization is disabled
    },

    refreshDropZones() {
        // Drag-drop layout customization is disabled
    },

    /**
     * Main entry point for playing any content
     */
    async play(seriesId, episodeIndex = 0) {
        let epIdx = parseInt(episodeIndex);
        if (isNaN(epIdx) || epIdx === null || epIdx === undefined) {
            epIdx = 0;
        }
        console.log(`%c[Player] Initiating play for ${seriesId} at index: ${epIdx}`, 'color: #7c3aed; font-weight: bold');

        // 1. Ensure Data is Loaded
        if (db && typeof db.syncDatabaseFromJson === 'function') {
            await db.syncDatabaseFromJson(seriesId);
        }
        const series = db.getSeries(seriesId);
        
        if (!series) {
            if (window.db && (!db.loadedCollections || !db.loadedCollections.has('series'))) {
                console.log('⏳ [Player] Series data still loading, retrying in 300ms...');
                setTimeout(() => this.play(seriesId, episodeIndex), 300);
                return;
            }
            console.warn('[Player] İçerik bulunamadı:', seriesId);
            if (typeof Toast !== 'undefined') {
                Toast.error('İçerik bulunamadı! Lütfen daha sonra tekrar deneyin.');
            }
            // Redirect to home safely
            if (window.App && App.router) {
                App.router('home');
            }
            return;
        }

        // Flatten episodes
        let allEpisodes = [];
        if (series.seasons && Array.isArray(series.seasons)) {
            series.seasons.forEach(s => {
                if (s.episodes) allEpisodes = allEpisodes.concat(s.episodes);
            });
        } else {
            allEpisodes = series.episodes || [];
        }

        if (allEpisodes.length === 0) {
            this.renderComingSoon(series, epIdx);
            return;
        }

        // 2. Resolve Episode
        const episode = allEpisodes[epIdx];
        if (!episode) {
            console.warn('[Player] Bölüm bulunamadı index:', epIdx);
            return;
        }

        // 3. Determine Type
        if (series.type === 'webtoon') {
            this.renderWebtoonReader(series, epIdx);
            return;
        }

        this.currentSeries = series;
        this.currentEpisode = episode;

        // 4. Access Control
        if (!this.checkAccess(series, episode, epIdx)) {
            return; 
        }

        // 5. Adult Content Check
        const ageRating = series.ageRating || (series.is18Plus ? '+18' : 'Genel');
        const isAdult = ageRating.includes('18') || ageRating.includes('21');
        if (isAdult && !sessionStorage.getItem('adult_consent_' + seriesId)) {
            this.showAdultWarning(series, epIdx, ageRating);
            return;
        }

        // 6. Update URL
        this.updateUrl(series, episode);

        // 7. Render Player UI
        const episodeHasSource = (ep) => {
            if (!ep) return false;
            if (ep.sources?.length) return ep.sources.some(s => s?.url);
            return !!(ep.videoUrl || ep.url);
        };
        const comingSoonMode = !episodeHasSource(episode) || series.status === 'Yakında';
        this.renderVideoPlayer(series, allEpisodes, epIdx, comingSoonMode);

        // 8. Track Progress (Auto)
        this.trackView(series.id, epIdx);
    },

    /**
     * Renders the Video Player UI
     */
    renderVideoPlayer(series, allEpisodes, episodeIndex, comingSoonMode = false) {
        let playerView = document.getElementById('player-view');
        if (!playerView) {
            playerView = document.createElement('div');
            playerView.id = 'player-view';
            playerView.className = 'view-section';
            
            // Try to find the main container, otherwise append to body
            const container = document.querySelector('main') || document.body;
            container.appendChild(playerView);
        }

        document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
        playerView.style.display = 'block';
        window.scrollTo(0, 0);

        const episode = allEpisodes[episodeIndex];
        const nextEpIdx = episodeIndex + 1 < allEpisodes.length ? episodeIndex + 1 : null;
        const prevEpIdx = episodeIndex - 1 >= 0 ? episodeIndex - 1 : null;
        
        let sources = episode.sources || [];
        if (sources.length === 0 && episode.videoUrl) {
            sources.push({ name: 'Varsayılan', url: episode.videoUrl });
        }
        
        const currentSource = sources[0] || null;
        const posterUrl = episode.cover || series.backdrop || series.poster || 'assets/poster-placeholder.jpg';

        playerView.innerHTML = `
            <style>
                .premium-cinema-wrapper { position: relative; width: 100%; min-height: 100vh; padding-top: 20px; background: #0f111a; }
                #ambient-glow-container { position: absolute; top: 0; left: 0; width: 100%; height: 70vh; background: radial-gradient(circle at 50% 30%, rgba(139, 92, 246, 0.15) 0%, transparent 60%); z-index: 0; pointer-events: none; }
                #ambient-glow-container.active { background: radial-gradient(circle at 50% 30%, rgba(139, 92, 246, 0.25) 0%, transparent 70%); }
                .player-main-layout { display: grid; grid-template-columns: 1fr 380px; gap: 30px; max-width: 1600px; margin: 0 auto; padding: 0 30px; position: relative; z-index: 1; }
                @media (max-width: 1200px) { .player-main-layout { grid-template-columns: 1fr 300px; } }
                @media (max-width: 992px) { .player-main-layout { grid-template-columns: 1fr; } }
                .video-stage { position: relative; width: 100%; aspect-ratio: 16/9; background: #000; border-radius: 24px; overflow: hidden; box-shadow: 0 20px 50px rgba(0,0,0,0.5); margin-bottom: 30px; border: 1px solid rgba(255,255,255,0.05); }
                #video-overlay { position: absolute; inset: 0; background-size: cover; background-position: center; display: flex; align-items: center; justify-content: center; z-index: 2; transition: opacity 0.5s; }
                .overlay-gradient { position: absolute; inset: 0; background: linear-gradient(to top, rgba(15,17,26,1) 0%, rgba(15,17,26,0.3) 50%, rgba(15,17,26,0.8) 100%); backdrop-filter: blur(2px); }
                .play-trigger-btn { position: relative; z-index: 3; width: 100px; height: 100px; border-radius: 50%; background: rgba(139, 92, 246, 0.9); border: none; color: #fff; font-size: 2.5rem; cursor: pointer; display: flex; align-items: center; justify-content: center; padding-left: 8px; box-shadow: 0 0 40px rgba(139, 92, 246, 0.6); transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
                .play-trigger-btn:hover { transform: scale(1.1); background: #a78bfa; box-shadow: 0 0 60px rgba(167, 139, 250, 0.8); }
                .video-nav-controls { position: absolute; bottom: 20px; right: 20px; display: flex; gap: 15px; z-index: 4; }
                .nav-control-btn { width: 45px; height: 45px; border-radius: 14px; background: rgba(0,0,0,0.6); border: 1px solid rgba(255,255,255,0.1); color: #fff; font-size: 1.1rem; cursor: pointer; transition: all 0.2s; backdrop-filter: blur(10px); }
                .nav-control-btn:hover { background: #8b5cf6; border-color: #a78bfa; transform: translateY(-3px); }
                
                /* Unified glass page styles instead of modular blocks */
                .player-meta-glass { background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-bottom: none; backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border-radius: 24px 24px 0 0; padding: 35px; margin-bottom: 0; position: relative; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
                .player-meta-glass::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 1px; background: linear-gradient(90deg, transparent, rgba(139, 92, 246, 0.5), transparent); }
                .pm-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 25px; flex-wrap: wrap; gap: 20px; }
                .pm-series-title { font-size: 2.2rem; font-weight: 800; color: #fff; margin: 0 0 8px 0; letter-spacing: -0.5px; background: linear-gradient(135deg, #fff 0%, #a78bfa 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
                .pm-ep-info { font-size: 1.1rem; color: #a78bfa; font-weight: 600; display: inline-flex; align-items: center; gap: 8px; background: rgba(139, 92, 246, 0.1); padding: 6px 16px; border-radius: 20px; border: 1px solid rgba(139, 92, 246, 0.2); }
                .pm-actions { display: flex; gap: 12px; }
                .pm-action-btn { width: 48px; height: 48px; border-radius: 16px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); color: #94a3b8; font-size: 1.2rem; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; justify-content: center; }
                .pm-action-btn:hover, .pm-action-btn.active { background: rgba(139, 92, 246, 0.15); color: #a78bfa; border-color: rgba(139, 92, 246, 0.3); transform: translateY(-2px); }
                .pm-description { font-size: 1rem; color: #94a3b8; line-height: 1.7; margin-bottom: 25px; font-weight: 400; }
                .pm-tags { display: flex; flex-wrap: wrap; gap: 10px; }
                .pm-tags .badge { background: rgba(255,255,255,0.05); color: #cbd5e1; border: 1px solid rgba(255,255,255,0.1); padding: 6px 14px; border-radius: 12px; font-size: 0.85rem; font-weight: 600; }
                .pm-tags .badge-accent { background: rgba(234, 179, 8, 0.1); color: #fde047; border-color: rgba(234, 179, 8, 0.2); }
                
                .player-sidebar-glass { background: rgba(20, 22, 33, 0.6); border: 1px solid rgba(255,255,255,0.05); backdrop-filter: blur(30px); border-radius: 24px; display: flex; flex-direction: column; height: calc(100vh - 120px); position: sticky; top: 100px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.3); }
                .sidebar-header-v2 { padding: 25px; border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.01); }
                .sidebar-header-v2 h3 { margin: 0; color: #fff; font-size: 1.2rem; font-weight: 700; display: flex; align-items: center; gap: 10px; }
                .sidebar-header-v2 h3 i { color: #8b5cf6; }
                .sidebar-episodes-list { flex: 1; overflow-y: auto; padding: 15px; display: flex; flex-direction: column; gap: 10px; }
                .side-ep-card { display: flex; gap: 15px; padding: 12px; border-radius: 16px; background: rgba(255,255,255,0.02); border: 1px solid transparent; cursor: pointer; transition: all 0.2s; position: relative; overflow: hidden; }
                .side-ep-card:hover { background: rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.1); }
                .side-ep-card.active { background: rgba(139, 92, 246, 0.1); border-color: rgba(139, 92, 246, 0.3); }
                .side-ep-card.active::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px; background: #a78bfa; }
                .ep-card-img { position: relative; width: 110px; height: 68px; border-radius: 10px; overflow: hidden; flex-shrink: 0; }
                .ep-card-img img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s; }
                .side-ep-card:hover .ep-card-img img { transform: scale(1.05); }
                .ep-num { position: absolute; bottom: 5px; left: 5px; background: rgba(0,0,0,0.8); color: #fff; padding: 2px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; backdrop-filter: blur(4px); }
                .ep-card-info { display: flex; flex-direction: column; justify-content: center; flex: 1; min-width: 0; }
                .ep-card-title { color: #fff; font-size: 0.95rem; font-weight: 600; margin-bottom: 6px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
                .ep-card-meta { display: flex; justify-content: space-between; align-items: center; color: #64748b; font-size: 0.8rem; }
                .watch-toggle-btn { background: none; border: none; color: #64748b; cursor: pointer; font-size: 1.1rem; padding: 0; transition: color 0.2s; }
                .watch-toggle-btn:hover { color: #a78bfa; }
                .side-ep-card.watched .watch-toggle-btn { color: #10b981; }
                .playing-now-ripple { position: absolute; inset: 0; border: 2px solid #a78bfa; border-radius: 10px; animation: ripple 1.5s infinite; }
                @keyframes ripple { 0% { transform: scale(1); opacity: 1; } 100% { transform: scale(1.1); opacity: 0; } }

                .player-series-hub-glass { background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-top: 1px solid rgba(255,255,255,0.02); border-bottom: none; backdrop-filter: blur(20px); border-radius: 0; padding: 35px; margin-top: 0; }
                .info-pill-glass { display: flex; flex-direction: column; background: rgba(0,0,0,0.2); padding: 12px 16px; border-radius: 14px; border: 1px solid rgba(255,255,255,0.03); }
                .info-pill-glass span { color: #64748b; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
                .info-pill-glass b { color: #fff; font-size: 0.9rem; }
                
                .cast-item-premium { text-align: center; background: rgba(255,255,255,0.02); padding: 15px 10px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.03); transition: all 0.3s; cursor: pointer; }
                .cast-item-premium:hover { background: rgba(255,255,255,0.05); transform: translateY(-3px); }
                .cast-item-premium img { width: 64px; height: 64px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(139, 92, 246, 0.3); margin-bottom: 10px; padding: 2px; }

                /* Source Warning Banner */
                #source-warning-banner { display: flex; align-items: flex-start; gap: 14px; background: rgba(234, 179, 8, 0.08); border: 1px solid rgba(234, 179, 8, 0.25); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border-radius: 16px; padding: 16px 20px; margin-top: 16px; margin-bottom: 8px; animation: warningFadeIn 0.4s ease-out; position: relative; }
                #source-warning-banner .warning-icon { color: #fbbf24; font-size: 1.3rem; flex-shrink: 0; margin-top: 2px; }
                #source-warning-banner .warning-text { color: #fde68a; font-size: 0.9rem; line-height: 1.6; flex: 1; }
                #source-warning-banner .warning-close { background: none; border: none; color: rgba(253, 230, 138, 0.5); font-size: 1.1rem; cursor: pointer; padding: 4px 8px; border-radius: 8px; transition: all 0.2s; flex-shrink: 0; }
                #source-warning-banner .warning-close:hover { color: #fde68a; background: rgba(234, 179, 8, 0.15); }
                @keyframes warningFadeIn { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: translateY(0); } }

                /* Source Selector */
                .source-selector { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 16px; margin-bottom: 8px; align-items: center; }
                .source-selector-label { color: #94a3b8; font-size: 0.85rem; font-weight: 600; margin-right: 6px; display: flex; align-items: center; gap: 6px; }
                .source-selector-label i { color: #8b5cf6; }
                .source-btn { padding: 8px 18px; border-radius: 12px; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); color: #cbd5e1; font-size: 0.85rem; font-weight: 600; cursor: pointer; transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1); display: flex; align-items: center; gap: 7px; }
                .source-btn:hover { background: rgba(139, 92, 246, 0.12); border-color: rgba(139, 92, 246, 0.3); color: #e2e8f0; transform: translateY(-2px); }
                .source-btn.active { background: rgba(139, 92, 246, 0.2); border-color: #a78bfa; color: #fff; box-shadow: 0 0 20px rgba(139, 92, 246, 0.2); }
                .source-btn .source-dot { width: 6px; height: 6px; border-radius: 50%; background: #64748b; transition: background 0.2s; }
                .source-btn.active .source-dot { background: #a78bfa; box-shadow: 0 0 8px rgba(167, 139, 250, 0.6); }

                /* Discussions unified styling */
                .player-discussions-v2 { background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-top: 1px solid rgba(255,255,255,0.02); backdrop-filter: blur(20px); border-radius: 0 0 24px 24px; padding: 0; margin-top: 0; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
                .pd-header { display: flex; justify-content: space-between; align-items: center; padding: 25px 35px 15px; }
                .comment-input-glass { padding: 25px 35px; border-bottom: 1px solid rgba(255,255,255,0.05); }

                /* Responsive Layout Sizing Fixes */
                .player-details-grid { display: grid; grid-template-columns: 1.2fr 1fr; gap: 40px; }
                .player-info-pills-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }

                @media (max-width: 768px) {
                    .player-meta-glass { border-radius: 16px 16px 0 0 !important; padding: 20px !important; }
                    .player-series-hub-glass { border-radius: 0 !important; padding: 20px !important; }
                    .player-discussions-v2 { border-radius: 0 0 16px 16px !important; padding: 0 !important; }
                    .pd-header { padding: 20px 20px 10px !important; }
                    .comment-input-glass { padding: 15px 20px !important; }
                    .player-details-grid { grid-template-columns: 1fr !important; gap: 25px !important; }
                    .player-info-pills-grid { grid-template-columns: 1fr !important; }
                    .player-sidebar-v2 { background: #0f111a !important; }
                }
            </style>
            
            <div class="premium-cinema-wrapper view-fade-in">
                <div id="ambient-glow-container"></div>
                
                <div class="player-main-layout">
                    <!-- Left Column: Player & Meta -->
                    <div class="player-content-area">
                        <div class="player-module" data-module-id="video">
                        <div class="video-stage">
                            <div id="video-overlay" style="background-image: url('${posterUrl}');">
                                <div class="overlay-gradient"></div>
                                <button onclick="Player.startPlayback('${currentSource?.url}', '${series.id}', ${episodeIndex}, '${currentSource?.type || ''}')" 
                                        class="play-trigger-btn" ${(!currentSource || comingSoonMode) ? 'style="display:none;"' : ''}>
                                    <i class="fa-solid fa-play" style="margin-left: 4px;"></i>
                                </button>
                                ${(!currentSource || comingSoonMode) ? `<div class="player-coming-soon-overlay" style="position: absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; background:rgba(0,0,0,0.55); backdrop-filter:blur(12px); z-index:5;">
                                    <i class="fa-solid fa-hourglass-half" style="font-size: 3.5rem; color: #a78bfa; margin-bottom: 20px;"></i>
                                    <h3 style="color:#fff; font-size:1.8rem; font-weight:800; margin:0; text-shadow: 0 2px 10px rgba(0,0,0,0.5);">${comingSoonMode ? series.title + ' — Çok Yakında!' : 'Kaynak bulunamadı'}</h3>
                                    <p style="color:rgba(255,255,255,0.75); margin-top:8px; font-size: 1.05rem; text-align:center; max-width:420px; padding:0 20px;">${comingSoonMode ? 'Bu bölüm henüz hazırlanma aşamasında. Takipte kalın!' : 'Bu bölüm için henüz video kaynağı eklenmemiş.'}</p>
                                    <button type="button" class="btn-premium-outline" style="margin-top:16px; padding:10px 22px; border-radius:12px; cursor:pointer; background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.15); color:#fff;" onclick="App.router('detail', '${series.id}')"><i class="fa-solid fa-arrow-left"></i> Detaya Dön</button>
                                </div>` : ''}
                            </div>
                            <div id="video-embed-wrapper" style="display: none; width:100%; height:100%; position:absolute; top:0; left:0; background: #000;"></div>
                            
                            ${(!currentSource && (episode.releaseDate || episode.status === 'pending')) ? this.renderCountdown(episode) : ''}

                            <div class="video-nav-controls">
                                ${prevEpIdx !== null ? `<button onclick="Player.play('${series.id}', ${prevEpIdx})" class="nav-control-btn" title="Önceki Bölüm"><i class="fa-solid fa-chevron-left"></i></button>` : '<div></div>'}
                                ${nextEpIdx !== null ? `<button onclick="Player.play('${series.id}', ${nextEpIdx})" class="nav-control-btn" title="Sonraki Bölüm"><i class="fa-solid fa-chevron-right"></i></button>` : '<div></div>'}
                            </div>
                        </div>
                        ${sources.length > 1 ? this.renderSourceSelector(sources, series.id, episodeIndex) : ''}
                        ${currentSource && this.isWarningSource(currentSource.name, currentSource.url) ? this.renderSourceWarning(currentSource.name, currentSource.url) : ''}
                        </div>

                        <div class="player-module" data-module-id="meta">
                        <div class="player-meta-glass animate-up">
                            <div class="pm-header">
                                <div class="pm-title-stack">
                                    <h1 class="pm-series-title">${series.title}</h1>
                                    <div class="pm-ep-info"><i class="fa-solid fa-play"></i> Bölüm ${episode.number}: ${episode.title || 'Yeni Bölüm'}</div>
                                </div>
                                <div class="pm-actions">
                                    <button class="pm-action-btn ${State.currentUser?.watchlist?.includes(series.id) ? 'active' : ''}" onclick="Player.toggleWatchlist('${series.id}', this)" title="Listeme Ekle">
                                        <i class="fa-${State.currentUser?.watchlist?.includes(series.id) ? 'solid' : 'regular'} fa-bookmark"></i>
                                    </button>
                                    <button class="pm-action-btn" onclick="Player.share()" title="Paylaş"><i class="fa-solid fa-share-nodes"></i></button>
                                    <button class="pm-action-btn" onclick="Player.toggleAmbientMode()" id="ambient-toggle-btn" title="Sinema Modu"><i class="fa-solid fa-wand-magic-sparkles"></i></button>
                                    <button class="pm-action-btn" onclick="Player.showReportModal()" title="Sorun Bildir"><i class="fa-solid fa-flag"></i></button>
                                </div>
                            </div>
                            
                            <div class="pm-description">${episode.description || series.description || 'Bu bölüm için henüz detaylı bir açıklama girilmemiş.'}</div>
                            
                            <div class="pm-tags">
                                ${(series.genres || []).map(g => `<span class="badge">${g}</span>`).join('')}
                                <span class="badge badge-accent"><i class="fa-solid fa-star"></i> ${series.rating || 'N/A'} Puan</span>
                            </div>
                        </div>
                        </div>

                        <!-- Series Info & Cast (Premium Hub) -->
                        <div class="player-module" data-module-id="details">
                        <div class="player-series-hub-glass animate-up">
                            <div class="player-details-grid">
                                <div>
                                    <h3 style="color: #fff; font-size: 1.3rem; margin-top:0; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                                        <i class="fa-solid fa-film" style="color: #8b5cf6;"></i> Dizi Hakkında
                                    </h3>
                                    <p style="color: #94a3b8; line-height: 1.7; font-size: 0.95rem; margin-bottom: 25px;">${series.description || 'Dizi detayları yakında eklenecektir.'}</p>
                                    
                                    <div class="player-info-pills-grid">
                                        <div class="info-pill-glass"><span>Yayın Yılı</span><b>${series.year || 'Bilinmiyor'}</b></div>
                                        <div class="info-pill-glass"><span>Ülke</span><b>${series.country || 'Güney Kore'}</b></div>
                                        <div class="info-pill-glass"><span>Tür</span><b style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${(series.genres || []).join(', ') || '-'}</b></div>
                                        <div class="info-pill-glass"><span>Durum</span><b>${series.status || 'Devam Ediyor'}</b></div>
                                    </div>
                                </div>
                                <div>
                                    <h3 style="color: #fff; font-size: 1.3rem; margin-top:0; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                                        <i class="fa-solid fa-users" style="color: #8b5cf6;"></i> Başrol Oyuncuları
                                    </h3>
                                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); gap: 12px;">
                                        ${(series.cast || []).filter(c => c !== null && c !== undefined).slice(0, 6).map(c => {
                                            const name = typeof c === 'string' ? c : (c.name || 'Oyuncu');
                                            const image = (typeof c === 'object' ? c.image : null) || 'assets/logo.png';
                                            const character = typeof c === 'string' ? 'Oyuncu' : (c.character || 'Oyuncu');
                                            return `
                                            <div class="cast-item-premium">
                                                <img src="${image}" onerror="this.src='assets/logo.png'">
                                                <div style="font-size: 0.75rem; color: #fff; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 2px;">${name}</div>
                                                <div style="font-size: 0.65rem; color: #64748b; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${character}</div>
                                            </div>
                                            `;
                                        }).join('') || '<div style="color:#64748b; font-size:0.85rem; padding: 20px; background: rgba(0,0,0,0.2); border-radius: 12px; text-align: center; grid-column: 1/-1;">Oyuncu kadrosu yakında eklenecek.</div>'}
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>

                        <!-- Discussions -->
                        <div class="player-module" data-module-id="comments">
                        <div class="player-discussions-v2 animate-up">
                            <div class="pd-header">
                                <h2 style="margin:0;"><i class="fa-solid fa-comments"></i> Bölüm Tartışması</h2>
                                <span id="comment-count-badge" class="badge" style="background: rgba(139, 92, 246, 0.2); color: #a78bfa; padding: 6px 12px; border-radius: 10px;">0 Yorum</span>
                            </div>
                            
                            <div class="comment-input-glass">
                                <div class="ci-avatar-row" style="display:flex; gap: 20px;">
                                    <img src="${State.currentUser?.avatar || 'assets/logo.png'}" class="ci-avatar" style="width: 50px; height: 50px; border-radius: 50%; border: 2px solid rgba(255,255,255,0.1);">
                                    <div class="ci-content" style="flex:1;">
                                        <textarea id="player-comment-input" style="width:100%; min-height: 80px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); border-radius: 14px; padding: 15px; color: #fff; resize: vertical; font-family: inherit; font-size: 0.95rem;" placeholder="${State.currentUser?.role === 'guest' ? 'Yorum yapmak için giriş yapmalısınız...' : 'Bu bölüm hakkında ne düşünüyorsun?'}" ${State.currentUser?.role === 'guest' ? 'disabled' : ''}></textarea>
                                        <div class="ci-footer" style="display:flex; justify-content: space-between; align-items: center; margin-top: 12px;">
                                            <div style="display: flex; gap: 15px; align-items: center;">
                                                <label class="spoiler-check" style="color: #94a3b8; font-size: 0.85rem; cursor: pointer; display: flex; align-items: center; gap: 6px;">
                                                    <input type="checkbox" id="player-comment-spoiler-cb" style="accent-color: #ef4444;"> <span style="color: #ef4444; font-weight: 600;">Spoiler İçerir</span>
                                                </label>
                                            </div>
                                            <button onclick="Player.postComment('${series.id}', ${episode.number})" class="btn-hero-primary" style="padding: 10px 28px; border-radius: 12px; font-weight: 600;" ${State.currentUser?.role === 'guest' ? 'disabled' : ''}>Paylaş</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="player-comments-list" class="animate-up"></div>
                        </div>
                        </div>

                    </div>

                    <!-- Right Column: Sidebar -->
                    <aside class="player-sidebar-glass player-sidebar-v2 animate-up" style="animation-delay: 0.2s;">
                        <div class="sidebar-header-v2">
                            <h3><i class="fa-solid fa-list-ul"></i> Bölümler</h3>
                            <span class="badge" style="background: rgba(255,255,255,0.1); color: #fff; padding: 4px 10px; border-radius: 8px;">${allEpisodes.filter(e => (e.sources && e.sources.length > 0) || e.videoUrl).length} Bölüm</span>
                        </div>
                        <div class="sidebar-episodes-list custom-scrollbar">
                            ${allEpisodes.map((ep, idx) => {
                                const isActive = idx === episodeIndex;
                                const isWatched = State.currentUser?.watchedEpisodes?.[series.id]?.includes(ep.number);
                                const hasSource = (ep.sources && ep.sources.length > 0) || ep.videoUrl;
                                
                                return `
                                    <div class="side-ep-card ${isActive ? 'active' : ''} ${isWatched ? 'watched' : ''}" 
                                         ${hasSource ? `onclick="Player.play('${series.id}', ${idx})"` : 'style="opacity: 0.4; cursor: not-allowed;"'} >
                                        <div class="ep-card-img">
                                            <img src="${ep.cover || series.poster || 'assets/poster-placeholder.jpg'}" loading="lazy" onerror="this.src='assets/poster-placeholder.jpg'">
                                            <div class="ep-num">Bölüm ${ep.number}</div>
                                            ${isActive ? '<div class="playing-now-ripple"></div>' : ''}
                                            ${!db.checkVisibility(ep) ? '<div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.7); backdrop-filter:blur(2px);"><i class="fa-solid fa-crown" style="color:#fbbf24; font-size: 1.2rem;"></i></div>' : ''}
                                        </div>
                                        <div class="ep-card-info">
                                            <div class="ep-card-title">${ep.title || `Bölüm ${ep.number}`}</div>
                                            <div class="ep-card-meta">
                                                <span>${ep.duration || '60 dk'}</span>
                                                <button class="watch-toggle-btn" onclick="Player.toggleWatched('${series.id}', ${ep.number}, event)" title="${isWatched ? 'İzlenmedi olarak işaretle' : 'İzlendi olarak işaretle'}">
                                                    <i class="fa-${isWatched ? 'solid' : 'regular'} fa-circle-check"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </aside>
                </div>
            </div>
        `;

        // Mobile Sidebar Toggle
        const sidebar = playerView.querySelector('.player-sidebar-v2');
        if (sidebar && !playerView.querySelector('.mobile-sidebar-toggle-btn')) {
            const toggle = document.createElement('button');
            toggle.innerHTML = '<i class="fa-solid fa-list"></i>';
            toggle.className = 'mobile-sidebar-toggle-btn';
            toggle.onclick = () => sidebar.classList.toggle('active');
            playerView.querySelector('.player-main-layout').appendChild(toggle);
        }

        this.renderComments(series.id, episode.number);
        this.initAmbientMode();
    },

    applyPlayerLayout() {
        const layout = this.getPlayerLayout();
        const contentArea = document.querySelector('.player-content-area');
        if (!contentArea || !layout || layout.length === 0) return;

        // Reorder modules based on saved layout
        layout.forEach(moduleId => {
            const mod = contentArea.querySelector(`.player-module[data-module-id="${moduleId}"]`);
            if (mod) contentArea.appendChild(mod);
        });
        this.refreshDropZones();
    },

    /**
     * Toggles watched status manually
     */
    toggleWatched(seriesId, epNum, event) {
        if (event) event.stopPropagation();
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Bunu yapabilmek için giriş yapmalısınız!');
            return;
        }

        if (!State.currentUser.watchedEpisodes) State.currentUser.watchedEpisodes = {};
        if (!State.currentUser.watchedEpisodes[seriesId]) State.currentUser.watchedEpisodes[seriesId] = [];

        const index = State.currentUser.watchedEpisodes[seriesId].indexOf(epNum);
        if (index > -1) {
            State.currentUser.watchedEpisodes[seriesId].splice(index, 1);
            Toast.info('İzlenmedi olarak işaretlendi.');
        } else {
            State.currentUser.watchedEpisodes[seriesId].push(epNum);
            Toast.success('İzlendi olarak işaretlendi.');
        }

        db.save();
        
        // Update UI
        if (this.currentSeries?.id === seriesId) {
            const allEpisodes = [];
            if (this.currentSeries.seasons) this.currentSeries.seasons.forEach(s => { if (s.episodes) allEpisodes.push(...s.episodes); });
            else allEpisodes.push(...(this.currentSeries.episodes || []));

            const activeIdx = allEpisodes.findIndex(e => e.number === this.currentEpisode.number);
            if (activeIdx !== -1) {
                this.renderVideoPlayer(this.currentSeries, allEpisodes, activeIdx);
            }
        }
    },

    /**
     * Start actual video playback
     */
    startPlayback(url, seriesId, episodeIndex, type = null) {
        const overlay = document.getElementById('video-overlay');
        const wrapper = document.getElementById('video-embed-wrapper');
        if (!url || !wrapper) return;

        // Source warning banner logic
        const existingBanner = document.getElementById('source-warning-banner');
        if (existingBanner) existingBanner.remove();

        if (this.isWarningSource(null, url)) {
            const videoModule = wrapper.closest('.player-module[data-module-id="video"]');
            if (videoModule) {
                const bannerHTML = this.renderSourceWarning(null, url);
                // Remove old banner if any, then insert after source selector or video-stage
                const existingSelector = videoModule.querySelector('.source-selector');
                const insertAfter = existingSelector || videoModule.querySelector('.video-stage');
                if (insertAfter) {
                    insertAfter.insertAdjacentHTML('afterend', bannerHTML);
                }
            }
        }

        // Update active source button
        document.querySelectorAll('.source-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.sourceUrl === url);
        });

        overlay.style.display = 'none';
        wrapper.style.display = 'block';
        wrapper.innerHTML = '';

        const isTs = url.includes('.ts');
        const isM3u8 = url.includes('.m3u8');
        const isMp4 = url.includes('.mp4') || url.includes('.webm') || url.includes('.mkv');
        const isLocal = url.startsWith('Database/') || url.startsWith('public/Database/') || url.startsWith('uploads/');

        if (isTs || isM3u8 || isMp4 || isLocal) {
            let encodedUrl = url;
            if (isLocal) {
                const parts = url.split('/');
                encodedUrl = parts.map(p => encodeURIComponent(p)).join('/');
            }

            wrapper.innerHTML = `
                <video id="plyr-player" playsinline controls crossorigin>
                    <source src="${encodedUrl}" type="video/mp4">
                </video>
            `;

            const videoEl = document.getElementById('plyr-player');
            
            if ((isTs || isM3u8) && typeof Hls !== 'undefined' && Hls.isSupported()) {
                const hls = new Hls();
                if (isTs) {
                    const absoluteUrl = new URL(encodedUrl, window.location.href).href;
                    const m3u8Content = `#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:9999\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:9999,\n${absoluteUrl}\n#EXT-X-ENDLIST`;
                    const blob = new Blob([m3u8Content], { type: 'application/vnd.apple.mpegurl' });
                    hls.loadSource(URL.createObjectURL(blob));
                } else {
                    hls.loadSource(encodedUrl);
                }
                hls.attachMedia(videoEl);
                this.hlsInstance = hls;
            } else {
                videoEl.src = encodedUrl;
            }

            this.initPlyr('#plyr-player');
        } else {
            // Iframe
            let embedUrl = url;
            if (url.includes('youtube.com/watch?v=')) embedUrl = url.replace('watch?v=', 'embed/');
            else if (url.includes('youtu.be/')) embedUrl = url.replace('youtu.be/', 'youtube.com/embed/');

            wrapper.innerHTML = `<iframe src="${embedUrl}" frameborder="0" allowfullscreen style="width:100%; height:100%; border-radius:12px; background:#000;"></iframe>`;
        }
    },

    initPlyr(selector) {
        if (typeof Plyr === 'undefined') {
            Loader.loadScript('https://cdn.plyr.io/3.7.8/plyr.js').then(() => this.initPlyr(selector));
            Loader.loadStyle('https://cdn.plyr.io/3.7.8/plyr.css');
            return;
        }

        const player = new Plyr(selector, {
            controls: ['play-large', 'play', 'progress', 'current-time', 'duration', 'mute', 'volume', 'captions', 'settings', 'pip', 'fullscreen'],
            settings: ['quality', 'speed'],
            speed: { selected: 1, options: [0.5, 0.75, 1, 1.25, 1.5, 2] }
        });

        player.on('ended', () => {
            Toast.info('Bölüm bitti. Sonraki bölüme geçiliyor...');
            setTimeout(() => this.playNext(), 2000);
        });

        this.plyrInstance = player;
    },

    playNext() {
        if (!this.currentSeries) return;
        const episodes = [];
        if (this.currentSeries.seasons) this.currentSeries.seasons.forEach(s => { if (s.episodes) episodes.push(...s.episodes); });
        else episodes.push(...(this.currentSeries.episodes || []));

        const currentIndex = episodes.findIndex(e => e.number === this.currentEpisode.number);
        if (currentIndex !== -1 && currentIndex < episodes.length - 1) {
            this.play(this.currentSeries.id, currentIndex + 1);
        }
    },

    renderWebtoonReader(series, episodeIndex) {
        const playerView = document.getElementById('player-view');
        if (!playerView) return;

        document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
        playerView.style.display = 'block';
        window.scrollTo(0, 0);

        const episodes = series.episodes || [];
        const episode = episodes[episodeIndex] || { number: episodeIndex + 1, pages: [] };
        this.currentEpisode = episode;
        this.currentSeries = series;

        playerView.innerHTML = `
            <div class="webtoon-reader-wrapper view-fade-in">
                <div class="reader-header glass-card">
                    <button onclick="App.router('detail', '${series.id}')" class="back-btn"><i class="fa-solid fa-arrow-left"></i></button>
                    <div class="reader-title">
                        <h2>${series.title}</h2>
                        <span>Bölüm ${episode.number}: ${episode.title || ''}</span>
                    </div>
                </div>

                <div class="reader-content-v2">
                    ${(episode.pages || []).length > 0 ? 
                        episode.pages.map(p => `<img src="${p}" class="reader-page" loading="lazy" onerror="this.src='assets/poster-placeholder.jpg'">`).join('') :
                        `<div class="no-pages-placeholder">
                            <i class="fa-solid fa-image"></i>
                            <p>Bu bölüm için görsel bulunamadı.</p>
                         </div>`
                    }
                </div>

                <div class="reader-navigation glass-card">
                    ${episodeIndex > 0 ? `<button onclick="Player.play('${series.id}', ${episodeIndex - 1})" class="nav-btn"><i class="fa-solid fa-chevron-left"></i> Önceki</button>` : '<span></span>'}
                    <div class="chapter-selector">Bölüm ${episode.number} / ${episodes.length}</div>
                    ${episodeIndex < episodes.length - 1 ? `<button onclick="Player.play('${series.id}', ${episodeIndex + 1})" class="nav-btn">Sonraki <i class="fa-solid fa-chevron-right"></i></button>` : '<span></span>'}
                </div>
            </div>
        `;
        
        this.trackView(series.id, episodeIndex);
    },

    updateUrl(series, episode) {
        if (!series || !episode) return;
        const slug = series.slug || series.id;
        const hash = `#/player/${slug}/${episode.number}`;
        if (window.location.hash !== hash) {
            history.replaceState(null, '', hash);
        }
    },

    checkAccess(series, episode, episodeIndex) {
        const user = State.currentUser;
        if (user?.role === 'admin') return true;

        if (!db.checkVisibility(episode)) {
            if (!user || user.role === 'guest') {
                Toast.error('Bu bölümü izlemek için giriş yapmalısınız!');
                App.router('giris-yap');
                return false;
            }
            this.showLockOverlay('VIP', 'Bu bölüm sadece VIP üyeler içindir.');
            return false;
        }

        if (!db.checkVisibility(series)) {
            if (!user || user.role === 'guest') {
                Toast.error('Bu içeriği görmek için giriş yapmalısınız!');
                App.router('giris-yap');
                return false;
            }
            this.showLockOverlay('GİZLİ', 'Bu içerik şu anda kısıtlı erişim modundadır.');
            return false;
        }

        return true;
    },

    showLockOverlay(type, message) {
        let playerView = document.getElementById('player-view');
        if (!playerView) {
            playerView = document.createElement('div');
            playerView.id = 'player-view';
            playerView.className = 'view-section';
            const container = document.querySelector('main') || document.body;
            container.appendChild(playerView);
        }

        document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
        playerView.style.display = 'block';
        window.scrollTo(0, 0);

        playerView.innerHTML = `
            <div class="player-lock-overlay">
                <div class="lock-card glass-card">
                    <i class="fa-solid fa-${type === 'VIP' ? 'crown' : 'lock'}"></i>
                    <h2>${type} İçerik</h2>
                    <p>${message}</p>
                    <button onclick="App.router('home')" class="btn-hero-primary">Anasayfaya Dön</button>
                </div>
            </div>
        `;
    },

    showAdultWarning(series, episodeIndex, rating) {
        const modal = document.createElement('div');
        modal.className = 'modal view-fade-in';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content glass-card" style="max-width: 450px; text-align: center;">
                <div style="font-size: 4rem; color: #ef4444; margin-bottom: 20px;"><i class="fa-solid fa-triangle-exclamation"></i></div>
                <h2>Yaş Sınırı: ${rating}</h2>
                <p style="color: #94a3b8; margin: 20px 0;">Bu içerik yetişkin temalar içermektedir. Devam ederek 18 yaşından büyük olduğunuzu onaylıyorsunuz.</p>
                <div style="display: grid; gap: 10px;">
                    <button class="btn-hero-primary" onclick="sessionStorage.setItem('adult_consent_${series.id}', 'true'); this.closest('.modal').remove(); Player.play('${series.id}', ${episodeIndex})">Onaylıyorum ve Devam Et</button>
                    <button class="btn-hero-secondary" onclick="App.router('home')">Vazgeç</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    trackView(seriesId, episodeIndex) {
        db.syncAction('view-increment', { id: seriesId });

        if (!State.currentUser || State.currentUser.role === 'guest') return;
        if (!State.currentUser.watchedEpisodes) State.currentUser.watchedEpisodes = {};
        if (!State.currentUser.watchedEpisodes[seriesId]) State.currentUser.watchedEpisodes[seriesId] = [];
        
        const epNum = this.currentEpisode.number;
        if (!State.currentUser.watchedEpisodes[seriesId].includes(epNum)) {
            State.currentUser.watchedEpisodes[seriesId].push(epNum);
            db.save();
        }
    },

    renderComments(seriesId, episodeNumber) {
        const container = document.getElementById('player-comments-list');
        const badge = document.getElementById('comment-count-badge');
        if (!container) return;

        const key = `${seriesId}_ep${episodeNumber}`;
        const comments = State.data.episodeComments?.[key] || [];
        if (badge) badge.innerText = `${comments.length} Yorum`;

        if (comments.length === 0) {
            container.innerHTML = `<div class="no-comments">Henüz yorum yapılmamış. İlk yorumu sen yap!</div>`;
            return;
        }

        container.innerHTML = comments.map(c => `
            <div class="comment-card-premium">
                <img src="${c.avatar || 'assets/logo.png'}" class="comment-avatar" onerror="this.src='assets/logo.png'">
                <div class="comment-body">
                    <div class="comment-header">
                        <span class="user-name">${c.username}</span>
                        <span class="time">${new Date(c.timestamp).toLocaleDateString('tr-TR')}</span>
                    </div>
                    <div class="comment-text">${c.text.replace('[SPOILER]', '<span class="spoiler-text">').replace('[/SPOILER]', '</span>')}</div>
                    <div class="comment-footer-actions">
                         <button class="c-action-btn"><i class="fa-regular fa-heart"></i> ${c.likes || 0}</button>
                    </div>
                </div>
            </div>
        `).join('');
    },

    postComment(seriesId, episodeNumber) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.error('Yorum yapmak için giriş yapmalısınız!');
            return;
        }

        const input = document.getElementById('player-comment-input');
        const text = input.value.trim();
        const isSpoiler = document.getElementById('player-comment-spoiler-cb')?.checked;
        if (!text) return Toast.warning('Yorum yazmalısınız!');

        const key = `${seriesId}_ep${episodeNumber}`;
        if (!State.data.episodeComments) State.data.episodeComments = {};
        if (!State.data.episodeComments[key]) State.data.episodeComments[key] = [];

        const comment = {
            id: Date.now(),
            userId: State.currentUser.id,
            username: State.currentUser.username,
            avatar: State.currentUser.avatar,
            text: isSpoiler ? `[SPOILER]${text}[/SPOILER]` : text,
            timestamp: Date.now(),
            likes: 0
        };

        State.data.episodeComments[key].unshift(comment);
        
        // Sync to cloud
        db.syncAction('comment-submit', { 
            seriesId, 
            episodeNumber, 
            comment,
            key: key 
        });

        db.save();
        input.value = '';
        this.renderComments(seriesId, episodeNumber);
        Toast.success('Yorumun paylaşıldı!');
    },

    toggleAmbientMode() {
        const container = document.getElementById('ambient-glow-container');
        if (!container) return;
        const isActive = container.classList.toggle('active');
        document.getElementById('ambient-toggle-btn')?.classList.toggle('active', isActive);
        Toast.info(`Ambient Mode: ${isActive ? 'AÇIK' : 'KAPALI'}`);
    },

    initAmbientMode() {
        const container = document.getElementById('ambient-glow-container');
        if (container) container.classList.add('active');
    },

    share() {
        const url = window.location.href;
        navigator.clipboard.writeText(url).then(() => Toast.success('Bağlantı kopyalandı!'));
    },

    showReportModal() {
        const modal = document.createElement('div');
        modal.className = 'modal view-fade-in';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content glass-card" style="max-width: 450px;">
                <div class="modal-header">
                    <h2><i class="fa-solid fa-circle-exclamation"></i> Sorun Bildir</h2>
                    <button onclick="this.closest('.modal').remove()" class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:15px;">Bildiriminiz doğrudan çeviri ekibine iletilecektir.</p>
                    <div class="form-group">
                        <label>Sorun Türü</label>
                        <select id="report-type" class="form-select">
                            <option value="video">Video açılmıyor / Bozuk</option>
                            <option value="subtitle">Altyazı hatalı</option>
                            <option value="translation">Çeviri hatası</option>
                            <option value="other">Diğer</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Detaylar</label>
                        <textarea id="report-desc" class="form-input" placeholder="Detaylandırın..."></textarea>
                    </div>
                    <button class="btn btn-primary btn-block" onclick="Player.submitReport()">Bildirimi Gönder</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    submitReport() {
        if (!State.currentUser || State.currentUser.role === 'guest') return Toast.warning('Giriş yapmalısınız!');
        const type = document.getElementById('report-type').value;
        const desc = document.getElementById('report-desc').value;
        
        if (window.ApprovalService) {
            ApprovalService.submitReport({
                type: 'player_issue',
                subType: type,
                targetTeam: type === 'translation' || type === 'subtitle' ? 'translation' : 'admin',
                description: desc,
                seriesId: this.currentSeries.id,
                episodeNumber: this.currentEpisode.number,
                userId: State.currentUser.id
            });
            Toast.success('Bildirim iletildi!');
            document.querySelector('.modal').remove();
        }
    },

    renderComingSoon(series, episodeIndex = 0) {
        const placeholderEpisodes = [
            { number: 1, title: 'Bölüm 1', sources: [], status: 'coming_soon' }
        ];
        if (!series.episodes?.length) series.episodes = placeholderEpisodes;
        this.currentSeries = series;
        this.currentEpisode = series.episodes[0];
        this.updateUrl(series, this.currentEpisode);

        let playerView = document.getElementById('player-view');
        if (!playerView) {
            playerView = document.createElement('div');
            playerView.id = 'player-view';
            playerView.className = 'view-section';
            const container = document.querySelector('main') || document.body;
            container.appendChild(playerView);
        }
        document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
        playerView.style.display = 'block';
        window.scrollTo(0, 0);

        const epIdx = Math.min(episodeIndex, (series.episodes?.length || 1) - 1);
        this.renderVideoPlayer(series, series.episodes, epIdx, true);
    },

    renderCountdown(episode) {
        if (!episode.releaseDate) return '';
        const id = `countdown-${Date.now()}`;
        return `<div class="player-countdown-badge"><i class="fa-solid fa-clock"></i> <span id="${id}">Yakında...</span></div>`;
    },

    /**
     * Checks if a source is VK, OK, or Moly (case-insensitive)
     */
    isWarningSource(name, url) {
        const patterns = ['vk.com', 'ok.ru', 'vidmoly', 'moly'];
        const nameStr = (name || '').toLowerCase();
        const urlStr = (url || '').toLowerCase();
        return patterns.some(p => nameStr.includes(p) || urlStr.includes(p));
    },

    /**
     * Renders a dismissible warning banner for VK/OK/Moly sources
     */
    renderSourceWarning(sourceName, sourceUrl) {
        const urlStr = (sourceUrl || '').toLowerCase();
        const nameStr = (sourceName || '').toLowerCase();

        // Get site settings from State
        const settingsArray = State.data?.settings || [];
        const settings = Array.isArray(settingsArray) 
            ? (settingsArray.find(s => s.id === 'site_settings') || {}) 
            : (settingsArray || {});

        let customWarning = '';
        if (urlStr.includes('vk.com') || nameStr.includes('vk')) {
            customWarning = settings.warningVK;
        } else if (urlStr.includes('ok.ru') || nameStr.includes('ok')) {
            customWarning = settings.warningOK;
        } else if (urlStr.includes('vidmoly') || urlStr.includes('moly') || nameStr.includes('moly')) {
            customWarning = settings.warningMoly;
        }

        const warningMsg = customWarning || "VK/OK/Moly kaynaklarında yaşanan sorunlar genellikle kendi internetiniz ile ilgilidir. Bağlantı sorunu yaşarsanız VPN kullanmayı veya farklı bir kaynak seçmeyi deneyiniz.";

        return `
            <div id="source-warning-banner">
                <i class="fa-solid fa-triangle-exclamation warning-icon"></i>
                <div class="warning-text">${warningMsg}</div>
                <button class="warning-close" onclick="document.getElementById('source-warning-banner')?.remove()" title="Kapat">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
        `;
    },

    /**
     * Renders source selector buttons below the video player
     */
    renderSourceSelector(sources, seriesId, episodeIndex) {
        if (!sources || sources.length <= 1) return '';
        const firstUrl = sources[0]?.url || '';
        const buttons = sources.map((src, idx) => {
            const isActive = idx === 0;
            const isWarn = this.isWarningSource(src.name, src.url);
            return `
                <button class="source-btn ${isActive ? 'active' : ''}" 
                        data-source-url="${src.url}"
                        onclick="Player.startPlayback('${src.url}', '${seriesId}', ${episodeIndex}, '${src.type || ''}')">
                    <span class="source-dot"></span>
                    ${src.name || 'Kaynak ' + (idx + 1)}
                    ${isWarn ? '<i class="fa-solid fa-triangle-exclamation" style="color:#fbbf24; font-size:0.75rem;"></i>' : ''}
                </button>
            `;
        }).join('');

        return `
            <div class="source-selector">
                <span class="source-selector-label"><i class="fa-solid fa-server"></i> Kaynaklar:</span>
                ${buttons}
            </div>
        `;
    }
};

window.Player = Player;
console.log('🚀 Player v2.2 Initialized');
