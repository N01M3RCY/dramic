// Enhanced Video Player Wrapper
const EnhancedPlayer = {
    currentPlayer: null,

    init() {
        console.log('🎬 Enhanced Player initialized');
        this.setupKeyboardShortcuts();
    },

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            const player = document.querySelector('iframe');
            if (!player) return;

            // Don't trigger if user is typing in an input
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

            switch (e.key) {
                case ' ':
                    e.preventDefault();
                    this.togglePlayPause();
                    break;
                case 'f':
                case 'F':
                    this.toggleFullscreen();
                    break;
                case 'm':
                case 'M':
                    this.toggleMute();
                    break;
                case 'ArrowLeft':
                    e.preventDefault();
                    Toast.info('⏪ 10 saniye geri');
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    Toast.info('⏩ 10 saniye ileri');
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    Toast.info('🔊 Ses arttı');
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    Toast.info('🔉 Ses azaldı');
                    break;
            }
        });
    },

    wrapPlayer(iframe, episode = null) {
        if (!iframe) return;

        const wrapper = document.createElement('div');
        wrapper.className = 'enhanced-player-wrapper';
        wrapper.id = 'active-player-wrapper';
        wrapper.innerHTML = `
            <div class="player-controls-overlay" style="display: none;">
                <div class="player-controls">
                    <button onclick="EnhancedPlayer.togglePlayPause()" class="player-btn" title="Oynat/Duraklat (Space)">
                        <i class="fa-solid fa-play"></i>
                    </button>
                    <button onclick="EnhancedPlayer.toggleFullscreen()" class="player-btn" title="Tam Ekran (F)">
                        <i class="fa-solid fa-expand"></i>
                    </button>
                    <button onclick="EnhancedPlayer.toggleTheaterMode()" class="player-btn" title="Tiyatro Modu (T)">
                        <i class="fa-solid fa-tv"></i>
                    </button>
                    <button onclick="EnhancedPlayer.toggleAmbilight()" class="player-btn ambilight-btn" title="Ambilight (A)">
                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                    </button>
                    <button onclick="EnhancedPlayer.toggleMute()" class="player-btn" title="Sessiz (M)">
                        <i class="fa-solid fa-volume-high"></i>
                    </button>
                    <button onclick="EnhancedPlayer.showPlayerSettings()" class="player-btn" title="Ayarlar">
                        <i class="fa-solid fa-gear"></i>
                    </button>
                </div>
            </div>
            <div id="live-badges-container" style="position: absolute; top: 10px; right: 10px; z-index: 20; display: flex; gap: 10px;"></div>
        `;

        iframe.parentNode.insertBefore(wrapper, iframe);
        wrapper.appendChild(iframe);

        // Ambilight Glow Element
        const glow = document.createElement('div');
        glow.className = 'player-ambilight-glow';
        wrapper.insertBefore(glow, iframe);
        
        if (episode && State.currentSeries?.poster) {
            glow.style.backgroundImage = `url(${State.currentSeries.poster})`;
        }

        // Show controls on hover
        wrapper.addEventListener('mouseenter', () => {
            wrapper.querySelector('.player-controls-overlay').style.display = 'flex';
        });
        wrapper.addEventListener('mouseleave', () => {
            wrapper.querySelector('.player-controls-overlay').style.display = 'none';
        });

        this.currentPlayer = iframe;

        // Check for Premiere/Live Status
        if (episode && episode.premiereDate) {
            this.checkPremiereStatus(episode, wrapper);
        } else {
            // Start VOD simulation (Skip Intro, etc)
            // Note: We need seriesId. Assuming episode obj has it or we can pass it if we modify call site.
            // For now, let's look at `episode` structure usage.
            if (episode) this.startVideoSimulation(episode, episode.seriesId || State.currentSeries?.id);
        }
    },

    togglePlayPause() {
        // Attempt to control generic players via postMessage
        if (this.currentPlayer) {
            // YouTube / Generic approach
            const cmd = {
                event: 'command',
                func: 'playVideo'
            };
            // Note: We can't easily know current state to toggle without state tracking.
            // But for now, let's just show toast as fallback
        }
        Toast.info('⏯️ Oynat/Duraklat (Tarayıcı kısıtlamaları nedeniyle her playerda çalışmayabilir)');
    },

    toggleFullscreen() {
        const wrapper = document.querySelector('.enhanced-player-wrapper');
        if (!wrapper) return;

        if (!document.fullscreenElement) {
            wrapper.requestFullscreen().catch(err => {
                console.error('Fullscreen error:', err);
            });
        } else {
            document.exitFullscreen();
        }
    },

    toggleTheaterMode() {
        document.body.classList.toggle('theater-mode-active');
        const wrapper = document.getElementById('active-player-wrapper');

        if (document.body.classList.contains('theater-mode-active')) {
            if (wrapper) wrapper.classList.add('theater-player-container');
            Toast.info("🎭 Tiyatro Modu Açık");
        } else {
            if (wrapper) wrapper.classList.remove('theater-player-container');
            Toast.info("🎭 Tiyatro Modu Kapalı");
        }
    },

    toggleAmbilight() {
        const wrapper = document.getElementById('active-player-wrapper');
        if (!wrapper) return;
        
        wrapper.classList.toggle('ambilight-active');
        const isActive = wrapper.classList.contains('ambilight-active');
        
        if (isActive) {
            this.startAmbilightCycle();
            Toast.info("✨ Ambilight Açıldı");
        } else {
            this.stopAmbilightCycle();
            Toast.info("✨ Ambilight Kapatıldı");
        }
    },

    startAmbilightCycle() {
        this.stopAmbilightCycle();
        const glow = document.querySelector('.player-ambilight-glow');
        if (!glow) return;

        // Dynamic color simulation
        this.ambilightInterval = setInterval(() => {
            const hue = (Date.now() / 50) % 360;
            const saturation = 70 + Math.sin(Date.now() / 1000) * 10;
            const lightness = 40 + Math.sin(Date.now() / 1500) * 5;
            
            glow.style.boxShadow = `0 0 100px 30px hsla(${hue}, ${saturation}%, ${lightness}%, 0.4)`;
            glow.style.filter = `blur(80px) saturate(2)`;
            
            // If we have a poster, blend it
            if (State.currentSeries?.poster) {
                glow.style.backgroundImage = `url(${State.currentSeries.poster})`;
                glow.style.backgroundBlendMode = 'overlay';
                glow.style.backgroundColor = `hsla(${hue}, ${saturation}%, ${lightness}%, 0.3)`;
            }
        }, 100);
    },

    stopAmbilightCycle() {
        if (this.ambilightInterval) clearInterval(this.ambilightInterval);
        const glow = document.querySelector('.player-ambilight-glow');
        if (glow) {
            glow.style.boxShadow = '';
            glow.style.filter = '';
            glow.style.backgroundColor = '';
        }
    },

    toggleMute() {
        Toast.info('🔇 Sessiz mod (video player tarafından kontrol edilir)');
    },

    checkPremiereStatus(episode, wrapper) {
        const now = new Date();
        const premiere = new Date(episode.premiereDate);
        const durationMs = (episode.duration || 45) * 60 * 1000;
        const end = new Date(premiere.getTime() + durationMs);

        const badgeContainer = wrapper.querySelector('#live-badges-container');

        if (now < premiere) {
            // COUNTDOWN MODE
            const diffMs = premiere - now;

            const overlay = document.createElement('div');
            overlay.className = 'live-countdown';
            overlay.innerHTML = `
                <div>
                    <h2>YAYININ BAŞLAMASINA</h2>
                    <div class="countdown-timer" id="premiere-timer">--:--:--</div>
                    <p>${episode.title}</p>
                    <p style="font-size: 0.9rem; margin-top: 10px; color: #aaa;">Yayın tarihi: ${premiere.toLocaleString('tr-TR')}</p>
                </div>
            `;
            wrapper.appendChild(overlay);

            // Hide/Disable iframe interaction
            if (this.currentPlayer) this.currentPlayer.style.pointerEvents = 'none';

            // Start Timer
            const timerEl = overlay.querySelector('#premiere-timer');
            const interval = setInterval(() => {
                const currentNow = new Date();
                const left = premiere - currentNow;

                if (left <= 0) {
                    clearInterval(interval);
                    overlay.remove();
                    if (this.currentPlayer) this.currentPlayer.style.pointerEvents = 'auto';
                    this.checkPremiereStatus(episode, wrapper); // Re-check to enter Live Mode
                    return;
                }

                const hours = Math.floor(left / (1000 * 60 * 60));
                const minutes = Math.floor((left % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((left % (1000 * 60)) / 1000);
                timerEl.innerText = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }, 1000);

        } else if (now >= premiere && now < end) {
            // LIVE MODE
            const badge = document.createElement('div');
            badge.className = 'live-badge';
            badge.innerHTML = 'CANLI';
            badgeContainer.appendChild(badge);

            // Disable seeking (simulation - since we can't truly control iframe seeking without API)
            // We can show a toast or overlay saying "Canlı yayındasınız - Geri alma devre dışı"
            Toast.info("🔴 CANLI YAYIN: Geri sarma devre dışı.");

            // Open Live Chat
            this.initLiveChat(wrapper);

        } else {
            // VOD MODE (Ended)
            // Normal behavior
            console.log('Premiere ended, playing as VOD');

            // Remove chat if exists
            const chatSidebar = document.querySelector('.theater-chat-sidebar');
            if (chatSidebar) {
                chatSidebar.remove();
                if (wrapper) {
                    wrapper.style.display = '';
                    if (wrapper.querySelector('iframe')) wrapper.querySelector('iframe').style.flex = '';
                }
            }

            // Remove live badge if exists
            const badge = wrapper.querySelector('.live-badge');
            if (badge) badge.remove();
        }
    },

    initLiveChat(wrapper) {
        // Only if theater mode or fullscreen? 
        // For now, let's just create a sidebar if in theater mode
        if (document.body.classList.contains('theater-mode-active')) {
            const chatSidebar = document.createElement('div');
            chatSidebar.className = 'theater-chat-sidebar';
            chatSidebar.innerHTML = `
                <div style="padding: 15px; border-bottom: 1px solid #333; font-weight: bold; display: flex; justify-content: space-between;">
                    <span>💬 Canlı Sohbet</span>
                </div>
                <div id="live-chat-messages" style="flex: 1; overflow-y: auto; padding: 15px;">
                    <div style="color: #666; font-size: 0.9rem; text-align: center;">Sohbete hoş geldin!</div>
                </div>
                <div style="padding: 10px; border-top: 1px solid #333;">
                    <input type="text" placeholder="Bir şeyler yaz..." style="width: 100%; background: #222; border: 1px solid #444; color: white; padding: 8px; border-radius: 4px;" onkeydown="if(event.key === 'Enter') EnhancedPlayer.sendLiveMessage(this)">
                </div>
            `;
            wrapper.parentElement.appendChild(chatSidebar); // Append next to wrapper? 
            // Actually theater-player-container is the wrapper. We might need a parent flex container.

            // Adjust wrapper styling to accomodate chat
            wrapper.style.display = 'flex';
            wrapper.appendChild(chatSidebar);
            wrapper.querySelector('iframe').style.flex = '1';
        }
    },

    sendLiveMessage(input) {
        const text = input.value.trim();
        if (!text) return;

        // Banned word check could be here too

        const container = document.getElementById('live-chat-messages');
        const msgDiv = document.createElement('div');
        msgDiv.style.marginBottom = '8px';
        msgDiv.innerHTML = `<strong style="color: var(--accent-color);">${State.currentUser?.username || 'Misafir'}:</strong> <span style="color: #ddd;">${text}</span>`;
        container.appendChild(msgDiv);
        container.scrollTop = container.scrollHeight;
        input.value = '';
    },

    showPlayerSettings() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 400px;">
                <div class="modal-header">
                    <h2>⚙️ Player Ayarları</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Klavye Kısayolları</label>
                        <div style="background: var(--bg-secondary); padding: 15px; border-radius: 8px; font-size: 0.9rem;">
                            <div style="margin-bottom: 8px;"><kbd>Space</kbd> - Oynat/Duraklat</div>
                            <div style="margin-bottom: 8px;"><kbd>F</kbd> - Tam Ekran</div>
                            <div style="margin-bottom: 8px;"><kbd>M</kbd> - Sessiz</div>
                            <div style="margin-bottom: 8px;"><kbd>←</kbd> <kbd>→</kbd> - Geri/İleri (10sn)</div>
                            <div><kbd>↑</kbd> <kbd>↓</kbd> - Ses Ayarı</div>
                        </div>
                    </div>

                    <div class="form-group" style="margin-top: 15px;">
                        <label>
                            <input type="checkbox" id="auto-track-watch" checked> 
                            İzleme geçmişini otomatik kaydet
                        </label>
                    </div>

                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="auto-next-episode" checked> 
                            Sonraki bölümü otomatik oynat
                        </label>
                    </div>

                    <div style="margin-top: 20px; padding: 15px; background: rgba(124, 58, 237, 0.1); border-radius: 8px; font-size: 0.85rem; color: var(--text-secondary);">
                        <i class="fa-solid fa-info-circle"></i> 
                        Video player VK, Moly gibi harici platformlar tarafından sağlanmaktadır. 
                        Bazı özellikler platform kısıtlamaları nedeniyle çalışmayabilir.
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    startVideoSimulation(episode, seriesId) {
        // Since we can't reliably get events from iframes, we simulate timing features
        // 1. Skip Intro (Show after 10s, hide after 120s)
        setTimeout(() => {
            this.showSkipIntro();
        }, 15000); // Show at 15s

        // 2. Next Episode (Simulate end if we knew duration, but we don't always know)
        // If duration is passed in episode object:
        if (episode && episode.duration) {
            const durationMs = episode.duration * 60 * 1000;
            const triggerTime = durationMs - 15000; // 15s before end

            this.nextEpTimeout = setTimeout(() => {
                this.showNextEpisodeOverlay(seriesId, parseInt(episode.number) + 1);
            }, triggerTime);
        } else {
            // Fallback: If no duration, maybe just don't show auto-next, or show "Next" button in controls always
        }
    },

    showSkipIntro() {
        if (document.querySelector('.skip-intro-btn')) return;

        const wrapper = document.getElementById('active-player-wrapper');
        if (!wrapper) return;

        const btn = document.createElement('button');
        btn.className = 'skip-intro-btn';
        btn.innerHTML = 'Intro Atla <i class="fa-solid fa-forward"></i>';
        btn.onclick = () => {
            Toast.success('Intro Atlandı');
            btn.style.display = 'none';
            // Try to seek forward +85s
            // This logic depends on the player accepting postMessage, which is flaky for generic iframes
        };

        wrapper.appendChild(btn);

        // Auto hide after 2 mins
        setTimeout(() => { if (btn) btn.remove(); }, 120000);
    },

    showNextEpisodeOverlay(seriesId, nextEpNum) {
        if (document.querySelector('.next-episode-overlay')) return;
        const wrapper = document.getElementById('active-player-wrapper');
        if (!wrapper) return;

        const overlay = document.createElement('div');
        overlay.className = 'next-episode-overlay';
        overlay.innerHTML = `
            <div class="next-ep-header">SONRAKİ BÖLÜM BAŞLIYOR</div>
            <div class="next-ep-title">Bölüm ${nextEpNum}</div>
            <div class="next-ep-timer-bar"><div class="next-ep-timer-progress"></div></div>
            <div class="next-ep-actions">
                <button class="next-ep-btn secondary" onclick="EnhancedPlayer.cancelNextEpisode()">İptal</button>
                <button class="next-ep-btn primary" onclick="window.location.href='#/player/${seriesId}/${this.getAbsIndex(seriesId, nextEpNum)}'; window.location.reload();">Hemen İzle</button>
            </div>
        `;
        wrapper.appendChild(overlay);

        // Animate progress bar
        setTimeout(() => {
            const bar = overlay.querySelector('.next-ep-timer-progress');
            if (bar) bar.style.width = '100%';
        }, 100);

        // Auto Redirect after 5s
        this.autoNextTimeout = setTimeout(() => {
            window.location.href = `#/player/${seriesId}/${this.getAbsIndex(seriesId, nextEpNum)}`;
            window.location.reload();
        }, 5000);
    },

    cancelNextEpisode() {
        const overlay = document.querySelector('.next-episode-overlay');
        if (overlay) overlay.remove();
        if (this.autoNextTimeout) clearTimeout(this.autoNextTimeout);
    },

    getAbsIndex(seriesId, epNum) {
        // Logic to get 0-based index. 
        // We might need to fetch series data or assume linear 0-based index if epNum is reliable.
        // For safety, let's assume epNum - 1, but this assumes sequential numbering.
        return epNum - 1;
    },

    trackWatchTime(seriesId, episodeId) {
        let startTime = Date.now();
        // Remove 'tracked' lock to allow continuous updates

        // Track every 30 seconds
        const trackInterval = setInterval(() => {
            const elapsed = Math.floor((Date.now() - startTime) / 1000);

            // Only save if watched at least 10 seconds
            if (elapsed >= 10) {
                if (window.WatchHistory) {
                    WatchHistory.trackWatch(seriesId, episodeId, elapsed);
                    console.log('✅ Watch time tracked (interval):', elapsed);
                }
            }
        }, 30000); // 30 seconds

        // Cleanup on unload/navigation
        const cleanup = () => {
            clearInterval(trackInterval);
            const finalElapsed = Math.floor((Date.now() - startTime) / 1000);
            if (finalElapsed >= 10 && window.WatchHistory) {
                WatchHistory.trackWatch(seriesId, episodeId, finalElapsed);
                console.log('✅ Watch time tracked (final):', finalElapsed);
            }
        };

        window.addEventListener('beforeunload', cleanup);

        // Also attach to our internal router navigation if possible, 
        // but for now this is good for page unloads.
        // Ideally we'd hook into App.router, but this is a global event listener.
    }
    // --- NEW: Play method REMOVED to avoid conflict with main Player.js ---
    // EnhancedPlayer should only WRAP the existing player, not replace the controller.
};

// Auto-initialize
window.addEventListener('load', () => {
    EnhancedPlayer.init();
});

console.log('✅ Enhanced Player Module Loaded!');
