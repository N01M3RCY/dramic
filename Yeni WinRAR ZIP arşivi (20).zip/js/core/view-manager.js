// ============================================
// VIEW MANAGER - Navigation between views
// ============================================

const ViewManager = {
    currentView: 'home',
    currentBlogCategory: 'all',

    showView(viewName, param1, param2) {
        // Hide all views
        document.querySelectorAll('.view-section').forEach(view => {
            view.style.display = 'none';
        });

        const legacyDetail = document.getElementById('new-detail-view');
        if (legacyDetail) legacyDetail.remove();
        if (viewName !== 'detail') {
            const detailView = document.getElementById('detail-view');
            if (detailView) detailView.innerHTML = '';
        }

        // Update Page Title (Phase 7)
        this.updatePageTitle(viewName, param1);

        // Show selected view
        let targetId = viewName + '-view';
        if (viewName === 'detail') targetId = 'detail-view';

        let targetView = document.getElementById(targetId);

        // Create blog-view dynamically if it doesn't exist
        if (viewName === 'blog' && !targetView) {
            const blogView = document.createElement('div');
            blogView.id = 'blog-view';
            blogView.className = 'view-section';
            blogView.innerHTML = `
                <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 100px 20px 40px;">
                    <div class="blog-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                        <h1 style="font-size: 2rem; background: linear-gradient(135deg, #8b5cf6, #ec4899); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">📰 Blog</h1>
                        <button id="create-blog-btn" class="btn btn-primary" onclick="BlogStudioPage ? BlogStudioPage.switchTab('editor') : Toast.error('Blog Studio yüklenemedi')" style="display: none;">
                            <i class="fa-solid fa-plus"></i> Yeni Yazı
                        </button>
                    </div>
                    <div class="blog-filters" style="display: flex; gap: 10px; margin-bottom: 30px; flex-wrap: wrap;">
                        <button class="btn btn-sm btn-outline active" onclick="ViewManager.filterBlog('all')">Tümü</button>
                        <button class="btn btn-sm btn-outline" onclick="ViewManager.filterBlog('news')">Haberler</button>
                        <button class="btn btn-sm btn-outline" onclick="ViewManager.filterBlog('review')">İncelemeler</button>
                        <button class="btn btn-sm btn-outline" onclick="ViewManager.filterBlog('theory')">Teoriler</button>
                        <button class="btn btn-sm btn-outline" onclick="ViewManager.filterBlog('guide')">Rehberler</button>
                    </div>
                    <div id="blog-posts-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 25px;">
                        <!-- Blog posts rendered here -->
                    </div>
                </div>
            `;
            // Append to body or main content area
            const mainContent = document.getElementById('main-content') || document.body;
            mainContent.appendChild(blogView);
            targetView = blogView;
        }

        // New Blog Detail View
        if (viewName === 'blog-detail') {
            // Ensure the detail view container exists
            let detailView = document.getElementById('blog-detail-view');
            if (!detailView) {
                detailView = document.createElement('div');
                detailView.id = 'blog-detail-view';
                detailView.className = 'view-section';
                detailView.style.paddingTop = '100px';
                document.querySelector('main').appendChild(detailView);
            }
            targetView = detailView;
        }

        // New Actor Detail View
        if (viewName === 'actor-detail') {
            // Ensure the detail view container exists
            let detailView = document.getElementById('actor-detail-view');
            if (!detailView) {
                detailView = document.createElement('div');
                detailView.id = 'actor-detail-view';
                detailView.className = 'view-section';
                detailView.style.paddingTop = '100px';
                document.querySelector('main').appendChild(detailView);
            }
            targetView = detailView;
        }

        if (targetView) {
            targetView.style.display = 'block';
            targetView.classList.add('spa-fade-in');
            setTimeout(() => targetView.classList.remove('spa-fade-in'), 600);
            this.currentView = viewName;

            // Load view-specific content
            if (viewName === 'blog') {
                this.renderBlog();
            }
            if (viewName === 'calendar') {
                if (window.CalendarPage) CalendarPage.init();
                else App.renderCalendar(); // Fallback
            }
            if (viewName === 'profile') App.renderProfile();

            // New Browse Page Integration
            if (viewName === 'diziler' || viewName === 'webtoonlar') {
                if (window.BrowsePage) {
                    BrowsePage.init(viewName);
                } else {
                    console.error('BrowsePage module not loaded!');
                }
            }

            if (viewName === 'blog-detail') {
                if (window.BlogSystem) {
                    BlogSystem.renderPostPage(param1); // param1 is postId
                }
            }

            if (viewName === 'actor-detail') {
                if (window.ActorDetail) {
                    ActorDetail.render(param1); // param1 is actorName
                } else if (window.DetailedView) {
                    DetailedView.renderActorPage(param1);
                }
            }

            // Shorts Page Integration
            if (viewName === 'shorts') {
                if (window.ShortsPage) {
                    ShortsPage.init();
                } else {
                    console.error('ShortsPage module not loaded!');
                }
            }

            // Update navbar active state
            document.querySelectorAll('.nav-links a').forEach(link => {
                link.classList.remove('active');
            });

            // Scroll to top
            window.scrollTo(0, 0);
        }
    },

    renderBlog() {
        if (window.BlogHero && typeof BlogHero.init === 'function') {
            BlogHero.init();
        } else if (window.BlogSystem) {
            const container = document.getElementById('blog-posts-grid');
            if (container) {
                container.innerHTML = BlogSystem.render(this.currentBlogCategory);
            }
        }

        // Access Control for Create Button
        const createBtn = document.getElementById('create-blog-btn');
        if (createBtn) {
            createBtn.style.display = (window.BlogSystem && BlogSystem.canCreatePost()) ? 'inline-block' : 'none';
        }
    },

    filterBlog(category) {
        this.currentBlogCategory = category;
        this.renderBlog();

        // Update active button state
        document.querySelectorAll('.blog-filters .btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.innerText.toLowerCase().includes(category === 'all' ? 'tümü' :
                (category === 'news' ? 'haberler' :
                    (category === 'review' ? 'incelemeler' :
                        (category === 'theory' ? 'teoriler' : 'analizler'))))) {
                btn.classList.add('active');
            }
        });
    },

    loadAnalytics() {
        if (!State.currentUser) {
            Toast.warning("İstatistikleri görmek için giriş yapmalısınız!");
            App.router('home');
            return;
        }

        // Check if user is admin
        const isAdmin = State.currentUser.badges?.includes('Yönetici') || State.currentUser.badges?.includes('Admin');
        if (!isAdmin) {
            Toast.error("İstatistikler sadece yöneticiler için!");
            App.router('home');
            return;
        }

        // Use the new Premium Dashboard instead of the old view
        if (window.AdminAnalytics) {
            AdminAnalytics.showDashboard();
            // Optional: Redirect back to home so the empty view doesn't stay
            App.router('home');
        } else {
            Toast.error("Analitik modülü yüklenemedi!");
        }
    },

    loadStore() {
        if (!State.currentUser) {
            Toast.warning("⚠️ Mağazayı görmek için giriş yapmalısınız!");
            App.router('home');
            return;
        }

        document.getElementById('store-items').innerHTML = RewardStore.render();
    },

    loadBlog() {
        BlogSystem.loadPosts();
        this.filterBlog(this.currentBlogCategory);

        // Show/hide create button based on blogger badge
        const createBtn = document.getElementById('create-blog-btn');
        if (createBtn) {
            createBtn.style.display = BlogSystem.canCreatePost() ? 'block' : 'none';
        }
    },

    filterBlog(category) {
        this.currentBlogCategory = category;
        const container = document.getElementById('blog-posts-grid');
        if (container && window.BlogSystem) {
            container.innerHTML = BlogSystem.render(category);
        }

        // Update active button state safely
        const filters = document.querySelectorAll('.blog-filters .btn');
        if (filters.length) {
            filters.forEach(btn => {
                btn.classList.remove('active');
                if (btn.innerText.toLowerCase().includes(category === 'all' ? 'tümü' :
                    (category === 'news' ? 'haberler' :
                        (category === 'review' ? 'incelemeler' :
                            (category === 'theory' ? 'teoriler' : 'analizler'))))) {
                    btn.classList.add('active');
                }
            });
        }
    },

    openBlogEditor() {
        if (window.BlogEditor) {
            BlogEditor.showEditor();
        } else {
            Toast.error("Blog editörü yüklenemedi!");
        }
    },

    loadAchievements() {
        if (!State.currentUser) {
            Toast.warning("⚠️ Başarımları görmek için giriş yapmalısınız!");
            App.router('home');
            return;
        }

        const userAchievements = State.currentUser.achievements || [];
        const allAchievements = ExpandedAchievements.achievements;

        document.getElementById('achievement-count').innerText = userAchievements.length;

        const html = allAchievements.map(achievement => {
            const unlocked = userAchievements.includes(achievement.id);
            return `
                <div class="achievement-badge ${unlocked ? 'unlocked' : ''}">
                    <div class="achievement-badge-icon">${achievement.icon}</div>
                    <div class="achievement-badge-name">${achievement.name}</div>
                    <div class="achievement-badge-desc">${achievement.desc}</div>
                    <div class="achievement-badge-xp">+${achievement.xp} XP</div>
                    ${unlocked ? '<div style="color: #10b981; margin-top: 5px;">✅ Kazanıldı</div>' : ''}
                </div>
            `;
        }).join('');

        document.getElementById('all-achievements').innerHTML = html;
    },

    loadRecommendations() {
        if (!State.currentUser) {
            Toast.warning("⚠️ Önerileri görmek için giriş yapmalısınız!");
            App.router('home');
            return;
        }

        // Recommendations
        const recommended = AIRecommendations.getRecommendations(12);
        const recommendationsCarousel = document.getElementById('recommendations-carousel');
        if (recommendationsCarousel) {
            recommendationsCarousel.innerHTML = recommended.map(s => {
                const buttonText = s.type === 'webtoon' ? '📖 Oku' : '▶ İzle';
                return `
                    <div class="media-card" onclick="App.router('detail', '${s.id}')">
                        <div class="card-image-wrapper" style="position: relative;">
                            <img src="${s.coverImage || s.poster || 'https://via.placeholder.com/300x450?text=No+Image'}" class="card-image" loading="lazy">
                            ${window.CountryFlags ? CountryFlags.getFlagHTML(s.country || 'Kore') : ''}
                        </div>
                        <div class="card-content">
                            <h3 class="card-title">${s.title}</h3>
                            ${s.genre ? `<div class="card-genres">${window.CountryFlags ? CountryFlags.getGenreHTML(s.genre) : `<span class="genre-tag">${s.genre}</span>`}</div>` : ''}
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Trending
        const trending = AIRecommendations.getTrending(12);
        const trendingCarousel = document.getElementById('trending-carousel');
        if (trendingCarousel) {
            trendingCarousel.innerHTML = trending.map(s => {
                const buttonText = s.type === 'webtoon' ? '📖 Oku' : '▶ İzle';
                return `
                    <div class="media-card" onclick="App.router('detail', '${s.id}')">
                        <div class="card-image-wrapper" style="position: relative;">
                            <img src="${s.coverImage || s.poster || 'https://via.placeholder.com/300x450?text=No+Image'}" class="card-image" loading="lazy">
                            ${window.CountryFlags ? CountryFlags.getFlagHTML(s.country || 'Kore') : ''}
                        </div>
                        <div class="card-content">
                            <h3 class="card-title">${s.title}</h3>
                            ${s.genre ? `<div class="card-genres">${window.CountryFlags ? CountryFlags.getGenreHTML(s.genre) : `<span class="genre-tag">${s.genre}</span>`}</div>` : ''}
                        </div>
                    </div>
                `;
            }).join('');
        }
    },

    updatePageTitle(viewName, param1) {
        let title = 'Dramicbox';
        switch(viewName) {
            case 'blog': title = 'Blog & Haberler - Dramicbox'; break;
            case 'blog-detail':
                if (window.State && State.data.blogPosts) {
                    const post = State.data.blogPosts.find(p => p.id === param1);
                    if (post) title = `${post.title} - Dramicbox Blog`;
                }
                break;
            case 'social': title = 'Sosyal Hub - Dramicbox'; break;
            case 'profile': title = `${param1 || 'Profil'} - Dramicbox`; break;
            case 'browse': title = 'Keşfet - Dramicbox'; break;
            case 'shorts': title = 'Dramic Shorts - Dramicbox'; break;
        }
        document.title = title;
    }
};

// Extensions moved to ui-extensions.js to resolve reference errors


console.log('✅ View Manager Loaded!');
