/**
 * DramicBox Global State
 */
const State = {
    currentUser: null,
    data: {
        series: [],
        webtoons: [],
        announcements: [],
        blogPosts: [],
        users: [],
        socialPosts: [],
        friendRequests: [],
        sourceApprovals: [],
        tickets: [],
        actors: [],
        seriesAssignments: [],
        webtoonAssignments: [],
        settings: {}
    },
    currentSeries: null,
    currentEpisode: null,
    browseType: 'drama',
    actorCards: [], // Global list of all possible cards
    settings: {
        autoNext: true,
        cinemaMode: false
    }
};

window.State = State;
