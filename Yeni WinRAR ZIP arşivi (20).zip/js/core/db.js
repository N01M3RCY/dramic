/**
 * DramicBox Unified Database Service
 * Version: 4.0 (Full MySQL Integration)
 * Integrated with the high-performance PHP/MySQL backend.
 */
if (typeof window.DataService === 'undefined') {
    window.DataService = class DataService {
        constructor() {
            this.STORAGE_KEY = 'dramicbox_db';
        this.API_URL = 'api/db.php';
        this.loadedCollections = new Set();
        this._initialized = false;
        this.isOnline = true;
        this.syncChannel = new BroadcastChannel('dramicbox_sync');
        this.setupBroadcastListener();
        console.log('🔗 DataService: Initializing MySQL Sync Mode...');
    }

    async safeFetch(url, options = {}) {
        options.credentials = 'include';
        try {
            let response = await fetch(url, options);
            if ((response.status === 403 || response.status === 400) && window.Auth && Auth.checkPersistentSession) {
                console.warn(`🔄 Request returned ${response.status}. Attempting to re-sync session...`);
                const reSync = await Auth.checkPersistentSession();
                if (reSync) {
                    console.log("🚀 Session re-sync successful! Retrying request...");
                    response = await fetch(url, options);
                }
            }
            return response;
        } catch (e) {
            console.warn("safeFetch error:", e);
            throw e;
        }
    }

    setupBroadcastListener() {
        this.syncChannel.onmessage = (event) => {
            const { type, collection, data } = event.data;
            if (type === 'collection_update') {
                if (typeof State !== 'undefined' && State.data) {
                    State.data[collection] = data;
                    window.dispatchEvent(new CustomEvent('dramicbox_sync_complete', { detail: { collection } }));
                }
            }
        };
    }

    broadcastUpdate(collection, data) {
        this.syncChannel.postMessage({ type: 'collection_update', collection, data });
    }

    /**
     * Loads data collections from MySQL API with localStorage fallback
     */
    async loadData(collections = []) {
        try {
            console.log('☁️ Syncing with Cloud Database (MySQL)...');
            const colParam = collections.length > 0 ? `&collections=${collections.join(',')}` : '';
            const response = await this.safeFetch(`${this.API_URL}?action=get-data${colParam}`);
            
            if (response.ok) {
                const result = await response.json();
                if (result.success && result.data) {
                    this.isOnline = true;
                    if (typeof State !== 'undefined') {
                        if (!State.data) State.data = {};
                        
                        Object.keys(result.data).forEach(c => {
                            State.data[c] = result.data[c];
                            this.loadedCollections.add(c);
                        });
                    }
                    
                    // Update State.currentUser from fresh 'users' data
                    if (State.currentUser && State.currentUser.id && result.data.users) {
                        const freshUser = result.data.users.find(u => u.id === State.currentUser.id);
                        if (freshUser) {
                            State.currentUser = { ...State.currentUser, ...freshUser };
                            localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
                        }
                    }

                    // Update local backup
                    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(State.data));
                    return State.data;
                }
            }
        } catch (e) {
            console.warn('⚠️ Server unreachable, switching to Local Mode:', e.message);
            this.isOnline = false;
        }

        // Fallback to localStorage
        const raw = localStorage.getItem(this.STORAGE_KEY);
        if (raw) {
            const allData = JSON.parse(raw);
            if (typeof State !== 'undefined') {
                if (!State.data) State.data = {};
                State.data = { ...State.data, ...allData };
            }
        }
        // Ensure requested collections are marked as loaded (even if empty) to prevent infinite load loops
        if (typeof State !== 'undefined' && State.data) {
            collections.forEach(c => {
                this.loadedCollections.add(c);
                if (!State.data[c]) {
                    State.data[c] = [];
                }
            });
        }
        return typeof State !== 'undefined' ? State.data : {};
    }

    async ensureCollection(collection) {
        if (!this.loadedCollections.has(collection)) {
            await this.loadData([collection]);
        }
    }

    /**
     * Save a single item to the MySQL backend
     */
    async saveItem(collection, id, data) {
        if (!State.data[collection]) State.data[collection] = [];
        const idx = State.data[collection].findIndex(i => String(i.id) === String(id));
        
        if (idx > -1) {
            State.data[collection][idx] = data;
        } else {
            State.data[collection].unshift(data);
        }

        // Local save
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(State.data));

        // Cloud sync
        try {
            const response = await this.safeFetch(`${this.API_URL}?action=write`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ [collection]: [data] })
            });
            const result = await response.json();
            return result.success;
        } catch (e) {
            console.warn('☁️ Cloud Save failed, data is local only.');
            return false;
        }
    }

    /**
     * Delete an item from MySQL
     */
    async deleteItem(collection, id) {
        if (!State.data[collection]) return false;
        State.data[collection] = State.data[collection].filter(i => String(i.id) !== String(id));
        
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(State.data));

        try {
            const response = await this.safeFetch(`${this.API_URL}?action=delete-item&id=${id}&collection=${collection}`);
            const result = await response.json();
            return result.success;
        } catch (e) {
            console.warn('☁️ Cloud Delete failed.');
            return false;
        }
    }

    /**
     * Updates a user's details and syncs with the database
     */
    async updateUser(userId, updates) {
        if (!State.currentUser) return false;
        
        // Update local session state
        if (State.currentUser.id === userId) {
            State.currentUser = { ...State.currentUser, ...updates };
            localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        }

        // Also update inside users collection in State.data
        if (State.data && State.data.users) {
            const idx = State.data.users.findIndex(u => String(u.id) === String(userId));
            if (idx > -1) {
                State.data.users[idx] = { ...State.data.users[idx], ...updates };
            }
        }

        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(State.data));

        try {
            const response = await this.safeFetch(`${this.API_URL}?action=user-update`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    targetUserId: userId,
                    updates: updates
                })
            });
            const result = await response.json();
            if (result.success && result.user) {
                if (State.currentUser.id === userId) {
                    State.currentUser = { ...State.currentUser, ...result.user };
                    localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
                }
                return true;
            }
            return result.success;
        } catch (e) {
            console.warn('☁️ User update sync failed, saved locally.', e);
            return false;
        }
    }

    /**
     * Smart Save: Persists data to MySQL.
     * Admins save full state, regular users save allowed collections only.
     */
    async save(collections = null) {
        const isAdmin = State.currentUser?.role === 'admin' || State.currentUser?.badges?.includes('Admin');
        
        // For non-admins, if no collections are specified, fallback to all user-writable collections
        if (!isAdmin && !collections) {
            collections = ['socialPosts', 'comments', 'activities', 'friendRequests', 'users', 'customLists', 'watchParties', 'partyRooms', 'tickets', 'episodeComments'];
        }

        try {
            let payload = {};
            if (collections) {
                const cols = Array.isArray(collections) ? collections : [collections];
                cols.forEach(c => {
                    if (State.data[c]) payload[c] = State.data[c];
                });
            } else {
                payload = State.data;
            }
            
            const response = await this.safeFetch(`${this.API_URL}?action=write`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const result = await response.json();
            if (result.success) {
                localStorage.setItem(this.STORAGE_KEY, JSON.stringify(State.data));
                return true;
            }
        } catch (e) {
            console.warn('☁️ Cloud Sync failed.');
        }
        return false;
    }

    /**
     * Executes a specific action on the server
     */
    async syncAction(type, data = {}) {
        try {
            const response = await this.safeFetch(`${this.API_URL}?action=sync-action&type=${type}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            return result;
        } catch (e) {
            console.warn(`Action ${type} failed.`);
            return { success: false };
        }
    }

    saveDebounced(collection = null) {
        if (this._saveTimeout) clearTimeout(this._saveTimeout);
        this._saveTimeout = setTimeout(() => this.save(collection), 2000);
    }

    getSeries(id) {
        if (!id) return null;
        const all = [...(State.data.series || []), ...(State.data.webtoons || [])];
        return all.find(s => {
            if (String(s.id) === String(id) || s.slug === id) return true;
            const baseSlug = s.title?.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').trim();
            const yearSlug = baseSlug + (s.year ? '-' + s.year : '');
            return baseSlug === id || yearSlug === id;
        });
    },

    /** Tek bir diziyi slug/id ile yükle (detay sayfası için) */
    async ensureSeries(idOrSlug) {
        let series = this.getSeries(idOrSlug);
        if (series) return series;

        await this.loadData(['series', 'webtoons']);
        series = this.getSeries(idOrSlug);
        if (series) return series;

        const slug = String(idOrSlug).trim();
        const paths = [
            `Database/diziler/${slug}.json`,
            `Database/webtoonlar/${slug}.json`
        ];
        for (const path of paths) {
            try {
                const res = await fetch(path);
                if (!res.ok) continue;
                series = await res.json();
                if (!series?.id) continue;
                const collection = path.includes('webtoon') ? 'webtoons' : 'series';
                if (!State.data[collection]) State.data[collection] = [];
                const idx = State.data[collection].findIndex(s => String(s.id) === String(series.id));
                if (idx >= 0) State.data[collection][idx] = series;
                else State.data[collection].push(series);
                return series;
            } catch (e) { /* try next */ }
        }
        return null;
    }

    _seriesCollection(seriesOrId) {
        const series = typeof seriesOrId === 'object' ? seriesOrId : this.getSeries(seriesOrId);
        if (!series) return 'series';
        if (State.data.webtoons?.some(w => String(w.id) === String(series.id))) return 'webtoons';
        return series.type === 'webtoon' ? 'webtoons' : 'series';
    }

    updateSeries(seriesId, updates) {
        const series = this.getSeries(seriesId);
        if (!series) {
            console.warn('updateSeries: series not found', seriesId);
            return false;
        }
        Object.assign(series, updates);
        const collection = this._seriesCollection(series);
        if (!State.data[collection]) State.data[collection] = [];
        const idx = State.data[collection].findIndex(s => String(s.id) === String(series.id));
        if (idx > -1) State.data[collection][idx] = series;
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(State.data));
        this.saveItem(collection, series.id, series).catch(() => {});
        return true;
    }

    async saveSeries(seriesObj) {
        if (!seriesObj?.id) return false;
        const collection = this._seriesCollection(seriesObj);
        if (!State.data[collection]) State.data[collection] = [];
        const idx = State.data[collection].findIndex(s => String(s.id) === String(seriesObj.id));
        if (idx > -1) State.data[collection][idx] = seriesObj;
        else State.data[collection].unshift(seriesObj);
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(State.data));

        try {
            const response = await this.safeFetch(`${this.API_URL}?action=add-series`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(seriesObj)
            });
            const result = await response.json();
            if (result.success) return true;
        } catch (e) {
            console.warn('saveSeries API failed, saved locally.', e);
        }
        return this.saveItem(collection, seriesObj.id, seriesObj);
    }

    addSeries(newSeries) {
        if (!newSeries?.id) return false;
        const collection = this._seriesCollection(newSeries);
        if (!State.data[collection]) State.data[collection] = [];
        State.data[collection].unshift(newSeries);
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(State.data));
        this.saveSeries(newSeries).catch(() => {});
        return true;
    }

    async updateMember(userId, updates) {
        const user = (State.data.users || []).find(u => String(u.id) === String(userId));
        if (!user) return false;
        Object.assign(user, updates);
        if (State.currentUser && String(State.currentUser.id) === String(userId)) {
            State.currentUser = { ...State.currentUser, ...updates };
            localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        }
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(State.data));
        return this.saveItem('users', user.id || user.username, user);
    }

    async syncDatabaseFromJson(seriesId) {
        try {
            await this.loadData(['series', 'webtoons']);
        } catch (e) {
            console.warn('syncDatabaseFromJson:', e);
        }
        return !!this.getSeries(seriesId);
    }

    /**
     * Periodically syncs data from the cloud
     */
    startCloudPulse(interval = 30000) {
        if (this._pulseInterval) clearInterval(this._pulseInterval);
        this._pulseInterval = setInterval(() => this.loadData(), interval);
        console.log(`📡 CloudPulse active (Interval: ${interval}ms)`);
    }

    /**
     * Alias for saveItem for semantic compatibility
     */
    async syncItem(collection, data) {
        if (!data || !data.id) return false;
        return this.saveItem(collection, data.id, data);
    }

    /**
     * Check if an item (series, movie, episode) is visible/accessible to the current user
     */
    checkVisibility(item) {
        if (!item) return true;
        
        const isVip = item.isVip || item.vip || item.is_vip || item.isPrivate || item.private || item.is_private;
        if (!isVip) return true;
        
        if (typeof State !== 'undefined' && State.currentUser) {
            const user = State.currentUser;
            const isAdmin = user.role === 'admin' || (user.badges && user.badges.includes('Admin'));
            if (isAdmin) return true;
            
            const hasVipStatus = user.isVip || user.vip || (user.vipUntil && new Date(user.vipUntil) > new Date());
            if (hasVipStatus) return true;
        }
        
        return false;
    }
};
window.db = window.db || new DataService();
}
