// DramicBox Configuration
const Config = {
    // Use current domain (works both locally and on server by using relative api path or full origin)
    apiUrl: './api', // Default to relative to avoid CORS/Protocol issues
    API_URL: './api' // Backward compat
};

window.Config = Config;
window.config = Config; // Backward compatibility
window.API_BASE = Config.apiUrl;

console.log('✅ Config loaded - API URL:', Config.apiUrl);
