/**
 * Google Drive API Service
 * Handles SRT backup and file storage.
 */

const DriveService = {
    apiKey: 'YOUR_GOOGLE_API_KEY', // Should be set in settings
    clientId: 'YOUR_CLIENT_ID',
    scopes: 'https://www.googleapis.com/auth/drive.file',
    isLoaded: false,

    init() {
        console.log('📂 Google Drive Service Initialized');
        // Check for saved credentials in State
        if (!State.data.driveSettings) {
            State.data.driveSettings = {
                autoBackup: false,
                targetFolderId: null
            };
        }
    },

    async authenticate() {
        return new Promise((resolve, reject) => {
            if (typeof google === 'undefined') {
                Toast.error('Google API yüklenemedi. Lütfen internet bağlantınızı kontrol edin.');
                return reject('Google SDK missing');
            }

            const tokenClient = google.accounts.oauth2.initTokenClient({
                client_id: this.clientId,
                scope: this.scopes,
                callback: (response) => {
                    if (response.error) {
                        Toast.error('Google Drive erişim izni alınamadı.');
                        return reject(response.error);
                    }
                    this.accessToken = response.access_token;
                    this.isLoaded = true;
                    resolve(response);
                },
            });
            tokenClient.requestAccessToken();
        });
    },

    async uploadSRT(filename, content) {
        if (!this.accessToken) {
            await this.authenticate();
        }

        Toast.info('Drive\'a yedekleniyor...');

        try {
            const metadata = {
                name: filename,
                mimeType: 'text/plain',
            };

            const form = new FormData();
            form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
            form.append('file', new Blob([content], { type: 'text/plain' }));

            const response = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + this.accessToken,
                },
                body: form
            });

            const result = await response.json();
            if (result.id) {
                Toast.success('Drive Yedeği Başarılı!');
                return result.id;
            } else {
                throw new Error(result.error?.message || 'Yükleme hatası');
            }
        } catch (e) {
            console.error('Drive Upload Error:', e);
            Toast.error('Drive yüklemesi başarısız: ' + e.message);
            return null;
        }
    }
};

window.DriveService = DriveService;
