/**
 * Vidmoly API Service
 * Handles video uploads, status tracking, and daily limits.
 * API Key: 6091283ndivn7guk85lht5
 */

const VidmolyService = {
    apiKey: '6091283ndivn7guk85lht5',
    dailyLimit: 50,
    uploadQueue: [],
    isUploading: false,
    
    init() {
        console.log('🎬 Vidmoly Service Initialized');
        // Load stats from State
        if (!State.data.vidmolyStats) {
            State.data.vidmolyStats = {
                lastReset: new Date().toDateString(),
                count: 0
            };
        }
        this.checkReset();
        
        // Add exit warning if uploading
        window.onbeforeunload = (e) => {
            if (this.isUploading) {
                e.preventDefault();
                e.returnValue = 'Devam eden bir yükleme işlemi var. Ayrılmak istediğinize emin misiniz?';
            }
        };
    },

    checkReset() {
        const today = new Date().toDateString();
        if (State.data.vidmolyStats.lastReset !== today) {
            State.data.vidmolyStats.lastReset = today;
            State.data.vidmolyStats.count = 0;
            db.save();
        }
    },

    async uploadVideo(file, metadata, onProgress) {
        this.checkReset();
        
        if (State.data.vidmolyStats.count >= this.dailyLimit) {
            Toast.error('Günlük Vidmoly yükleme sınırına ulaşıldı (50/50).');
            return null;
        }

        this.isUploading = true;
        const startTime = Date.now();
        
        try {
            // 1. Get Upload Server
            const serverRes = await fetch(`https://vidmoly.to/api/upload/server?key=${this.apiKey}`);
            const serverData = await serverRes.json();
            if (serverData.status !== 200) throw new Error('Yükleme sunucusu alınamadı');
            
            const uploadUrl = serverData.result;
            
            // 2. Perform Upload
            const formData = new FormData();
            formData.append('file', file);
            formData.append('key', this.apiKey);
            if (metadata.title) formData.append('title', metadata.title);

            const xhr = new XMLHttpRequest();
            const promise = new Promise((resolve, reject) => {
                xhr.upload.addEventListener('progress', (e) => {
                    if (e.lengthComputable) {
                        const percent = (e.loaded / e.total) * 100;
                        const elapsed = (Date.now() - startTime) / 1000;
                        const speed = e.loaded / elapsed; // bytes/sec
                        if (onProgress) onProgress(percent, speed);
                    }
                });

                xhr.onreadystatechange = () => {
                    if (xhr.readyState === 4) {
                        if (xhr.status === 200) {
                            resolve(JSON.parse(xhr.responseText));
                        } else {
                            reject(new Error('Upload failed'));
                        }
                    }
                };
                
                xhr.open('POST', uploadUrl);
                xhr.send(formData);
            });

            const result = await promise;
            
            if (result.status === 200) {
                State.data.vidmolyStats.count++;
                db.save();
                Toast.success(`Vidmoly Yükleme Başarılı! (${State.data.vidmolyStats.count}/50)`);
                return result.result[0]; // video code
            } else {
                throw new Error(result.msg || 'Yükleme hatası');
            }
            
        } catch (e) {
            console.error('Vidmoly Upload Error:', e);
            Toast.error('Vidmoly yüklemesi başarısız oldu: ' + e.message);
            return null;
        } finally {
            this.isUploading = false;
        }
    },

    getStatusText() {
        const count = State.data.vidmolyStats?.count || 0;
        return `${count} / ${this.dailyLimit} (Günlük Sınır)`;
    },

    formatSpeed(bytesPerSec) {
        if (bytesPerSec < 1024) return bytesPerSec.toFixed(1) + ' B/s';
        if (bytesPerSec < 1024 * 1024) return (bytesPerSec / 1024).toFixed(1) + ' KB/s';
        return (bytesPerSec / (1024 * 1024)).toFixed(1) + ' MB/s';
    }
};

window.VidmolyService = VidmolyService;
