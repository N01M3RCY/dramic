/**
 * DramicBox Module Loader
 * Handles dynamic script injection and module state
 */
const Loader = {
    loadedScripts: new Set(),

    init() {
        // Mark scripts already present in index.html as loaded
        document.querySelectorAll('script[src]').forEach(script => {
            this.loadedScripts.add(script.getAttribute('src'));
        });
        console.log('🚀 Loader initialized. Core scripts track started.');
    },

    /**
     * Dynamically loads a JavaScript file
     * @param {string} src - Path to the script
     * @returns {Promise}
     */
    loadScript(src) {
        // Normalize src: remove leading / and handle query strings
        const normalizedSrc = src.replace(/^\/+/, '');

        if (this.loadedScripts.has(normalizedSrc)) {
            return Promise.resolve();
        }

        // Check if script actually exists in DOM already
        const existing = document.querySelector(`script[src*="${normalizedSrc}"]`);
        if (existing) {
            this.loadedScripts.add(normalizedSrc);
            return Promise.resolve();
        }

        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = normalizedSrc;
            script.async = true;

            script.onload = () => {
                this.loadedScripts.add(src);
                console.log(`📦 Loaded: ${src}`);
                resolve();
            };

            script.onerror = () => {
                console.error(`❌ Failed to load script: ${src}`);
                reject(new Error(`Script load error: ${src}`));
            };

            document.body.appendChild(script);
        });
    },

    /**
     * Loads multiple scripts in parallel or sequence
     * @param {string[]} srcs 
     * @param {boolean} parallel 
     */
    async loadMany(srcs, parallel = true) {
        if (parallel) {
            return Promise.all(srcs.map(src => this.loadScript(src)));
        } else {
            for (const src of srcs) {
                await this.loadScript(src);
            }
        }
    },

    /**
     * Dynamically loads a CSS file
     * @param {string} href - Path to the stylesheet
     */
    loadStyle(href) {
        if (document.querySelector(`link[href="${href}"]`)) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        document.head.appendChild(link);
    }
};

// Initialize when DOM is parsed to register all static scripts
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => Loader.init());
} else {
    Loader.init();
}
window.Loader = Loader;
