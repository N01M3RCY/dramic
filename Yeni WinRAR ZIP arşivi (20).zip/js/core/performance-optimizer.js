// Performance Optimization Module
const PerformanceOptimizer = {
    init() {
        console.log('⚡ Performance Optimizer initialized');
        this.optimizeImages(); // Move this FIRST so images are prepped
        this.setupLazyLoading(); // Then observe them
        this.registerServiceWorker();
    },

    // Lazy Loading for Images
    setupLazyLoading() {
        const images = document.querySelectorAll('img[data-src]');

        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.add('loaded');
                    observer.unobserve(img);
                }
            });
        }, {
            rootMargin: '50px'
        });

        images.forEach(img => imageObserver.observe(img));

        console.log('✅ Lazy loading enabled for', images.length, 'images');
    },

    // Convert img tags to lazy loading
    optimizeImages() {
        // Exclude logos and images that are already processed
        // Also exclude images with .no-lazy class
        const images = document.querySelectorAll('img:not([data-src]):not(#site-logo):not(.auth-logo):not(.no-lazy)');

        images.forEach(img => {
            if (img.src && !img.dataset.src) {
                img.dataset.src = img.src;
                img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1"%3E%3C/svg%3E';
                // Add lazy class to handle transitions if needed
                img.classList.add('lazy');
            }
        });
    },

    // Service Worker Registration
    async registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            try {
                const registration = await navigator.serviceWorker.register('/sw.js');
                console.log('✅ Service Worker registered:', registration);
            } catch (error) {
                console.log('❌ Service Worker registration failed:', error);
            }
        }
    },

    // Cache Management
    async clearCache() {
        if ('caches' in window) {
            const cacheNames = await caches.keys();
            await Promise.all(cacheNames.map(name => caches.delete(name)));
            console.log('✅ Cache cleared');
            Toast.success('Önbellek temizlendi!');
        }
    },

    // Performance Metrics
    getPerformanceMetrics() {
        if (window.performance) {
            const perfData = window.performance.timing;
            const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
            const connectTime = perfData.responseEnd - perfData.requestStart;
            const renderTime = perfData.domComplete - perfData.domLoading;

            return {
                pageLoadTime: Math.round(pageLoadTime),
                connectTime: Math.round(connectTime),
                renderTime: Math.round(renderTime),
                domReady: Math.round(perfData.domContentLoadedEventEnd - perfData.navigationStart)
            };
        }
        return null;
    },

    showPerformanceReport() {
        const metrics = this.getPerformanceMetrics();
        if (!metrics) {
            Toast.error('Performance API desteklenmiyor');
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2>⚡ Performans Raporu</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-card-value">${metrics.pageLoadTime}ms</div>
                            <div class="stat-card-label">Sayfa Yükleme</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-value">${metrics.connectTime}ms</div>
                            <div class="stat-card-label">Bağlantı</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-value">${metrics.renderTime}ms</div>
                            <div class="stat-card-label">Render</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-value">${metrics.domReady}ms</div>
                            <div class="stat-card-label">DOM Hazır</div>
                        </div>
                    </div>

                    <div style="margin-top: 30px;">
                        <h3 style="margin-bottom: 15px;">Optimizasyon Önerileri</h3>
                        <div style="background: var(--bg-secondary); padding: 20px; border-radius: 8px;">
                            ${this.getOptimizationTips(metrics)}
                        </div>
                    </div>

                    <div style="margin-top: 20px; display: flex; gap: 10px;">
                        <button onclick="PerformanceOptimizer.clearCache()" class="btn btn-outline">
                            <i class="fa-solid fa-trash"></i> Önbelleği Temizle
                        </button>
                        <button onclick="location.reload()" class="btn btn-primary">
                            <i class="fa-solid fa-rotate"></i> Sayfayı Yenile
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    getOptimizationTips(metrics) {
        const tips = [];

        if (metrics.pageLoadTime > 3000) {
            tips.push('⚠️ Sayfa yükleme süresi yüksek. Önbelleği temizlemeyi deneyin.');
        } else {
            tips.push('✅ Sayfa yükleme süresi iyi!');
        }

        if (metrics.connectTime > 1000) {
            tips.push('⚠️ Bağlantı süresi yüksek. İnternet bağlantınızı kontrol edin.');
        } else {
            tips.push('✅ Bağlantı süresi iyi!');
        }

        if (metrics.renderTime > 2000) {
            tips.push('⚠️ Render süresi yüksek. Tarayıcı eklentilerinizi kontrol edin.');
        } else {
            tips.push('✅ Render süresi iyi!');
        }

        return tips.map(tip => `<div style="margin-bottom: 10px;">${tip}</div>`).join('');
    },

    // Preload critical resources
    preloadResources(urls) {
        urls.forEach(url => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.as = this.getResourceType(url);
            link.href = url;
            document.head.appendChild(link);
        });
    },

    getResourceType(url) {
        if (url.endsWith('.css')) return 'style';
        if (url.endsWith('.js')) return 'script';
        if (url.match(/\.(jpg|jpeg|png|gif|webp)$/)) return 'image';
        if (url.match(/\.(woff|woff2|ttf)$/)) return 'font';
        return 'fetch';
    }
};

// Auto-initialize
window.addEventListener('load', () => {
    PerformanceOptimizer.init();
});

console.log('✅ Performance Optimizer Module Loaded!');
