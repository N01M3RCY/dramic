/**
 * UI Extensions & Monkey-patches
 * This file contains logic that extends various modules after they are loaded.
 */

// Add to Admin badge options
if (typeof Admin !== 'undefined') {
    const originalAddBadge = Admin.addBadge;
    Admin.addBadge = function () {
        if (!State.currentUser || !State.currentUser.badges?.includes('Yönetici')) {
            Toast.error("❌ Sadece yöneticiler rozet verebilir!");
            return;
        }

        const username = prompt("Kullanıcı adı:");
        if (!username) return;

        const user = State.data.users.find(u => u.username === username);
        if (!user) {
            Toast.error("❌ Kullanıcı bulunamadı!");
            return;
        }

        const badgeOptions = ['Yönetici', 'Çevirmen', 'VIP', 'Moderatör', 'Aktif Üye', 'Destekçi', 'Blogger'];
        const badge = prompt(`Rozet seç:\n${badgeOptions.join(', ')}`);

        if (!badge || !badgeOptions.includes(badge)) {
            Toast.error("❌ Geçersiz rozet!");
            return;
        }

        if (!user.badges) user.badges = [];
        if (user.badges.includes(badge)) {
            Toast.warning("⚠️ Kullanıcı zaten bu rozete sahip!");
            return;
        }

        user.badges.push(badge);
        db.updateUser(user.id, { badges: user.badges });
        Toast.success(`✅ ${username} kullanıcısına ${badge} rozeti verildi!`);
    };
}

// Daily Quests Modal extension
if (typeof DailyQuests !== 'undefined') {
    DailyQuests.showModal = function () {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>🎯 Günlük Görevler</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div style="padding: 20px;">
                    ${this.render()}
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    };
}

// Leaderboard Modal extension
if (typeof Leaderboard !== 'undefined') {
    Leaderboard.showModal = function () {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>🏅 Liderlik Tablosu</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div style="padding: 20px;">
                    ${this.render()}
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    };
}


// Avatar & Fame Extensions
const UIExtensions = window.UIExtensions || {};
UIExtensions.getAvatarHTML = function (user, size = 40, extraClass = '') {
    const avatarUrl = user && user.avatar ? user.avatar : 'assets/logo.png';
    const frameId = user && user.activeFrame ? user.activeFrame : null;

    // Find frame config for class name if needed
    let frameClass = '';

    // Check ShopSystem first
    if (frameId && window.ShopSystem && ShopSystem.items && ShopSystem.items.frames) {
        const frameItem = ShopSystem.items.frames.find(f => f.id === frameId);
        if (frameItem) frameClass = frameItem.class;
    }
    // Fallback if ShopSystem not loaded but we know the pattern
    else if (frameId) {
        // Assume frameId matches class name if generic logic failed? 
        // Actually shop system IDs are like 'frame_neon_purple', classes are 'frame-neon-purple'.
        // Let's try to map if simple replace
        frameClass = frameId.replace(/_/g, '-');
    }

    if (frameClass) {
        // Wrapper style for frame
        const wrapperSize = size + 8; // generic padding
        return `
            <div class="${extraClass} ${frameClass}" style="
                width: ${wrapperSize}px; 
                height: ${wrapperSize}px; 
                padding: 4px; 
                border-radius: 50%; 
                display: inline-block; 
                vertical-align: middle; 
                position: relative; 
                box-sizing: border-box;
                flex-shrink: 0;
            ">
                <img src="${avatarUrl}" style="
                    width: 100%; 
                    height: 100%; 
                    object-fit: cover; 
                    border-radius: 50%; 
                    display: block;
                ">
            </div>
        `;
    } else {
        return `<img src="${avatarUrl}" class="${extraClass}" style="
            width: ${size}px; 
            height: ${size}px; 
            object-fit: cover; 
            border-radius: 50%; 
            vertical-align: middle;
            display: inline-block;
            flex-shrink: 0;
        ">`;
    }
};

UIExtensions.getNameHTML = function (user) {
    if (!user) return 'Misafir';
    const username = user.username;
    const glowId = user.activeGlow;
    let glowClass = '';

    if (glowId && window.ShopSystem && ShopSystem.items && ShopSystem.items.glows) {
        const glowItem = ShopSystem.items.glows.find(g => g.id === glowId);
        if (glowItem) glowClass = glowItem.class;
    }

    const nameSpan = glowClass ? `<span class="${glowClass}">${username}</span>` : username;
    const verifiedBadge = (user.isVerified || user.role === 'admin' || user.role === 'moderator') 
        ? '<i class="fa-solid fa-circle-check" style="color: #3b82f6; margin-left: 5px;" title="Doğrulanmış Hesap"></i>' 
        : '';
    return nameSpan + verifiedBadge;
};

// Export to window if not already there (it is assigned earlier in file via if check, but let's ensure)
window.UIExtensions = UIExtensions || {};

console.log('✨ UI Extensions Loaded!');
