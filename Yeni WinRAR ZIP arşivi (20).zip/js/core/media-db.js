/**
 * MediaDB: Persistent Binary Storage using IndexedDB
 * Used for storing user-uploaded media (images, etc.) without hitting localStorage limits.
 */
const MediaDB = {
    DB_NAME: 'DramicboxMedia',
    STORE_NAME: 'media',
    VERSION: 1,
    _db: null,

    async init() {
        if (this._db) return this._db;
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.DB_NAME, this.VERSION);
            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(this.STORE_NAME)) {
                    db.createObjectStore(this.STORE_NAME, { keyPath: 'id' });
                }
            };
            request.onsuccess = (e) => {
                this._db = e.target.result;
                resolve(this._db);
            };
            request.onerror = (e) => reject(e);
        });
    },

    async saveMedia(fileOrBlob) {
        await this.init();
        const id = 'media_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        const data = {
            id,
            blob: fileOrBlob,
            type: fileOrBlob.type,
            name: fileOrBlob.name || 'uploaded_media',
            createdAt: new Date().toISOString()
        };

        return new Promise((resolve, reject) => {
            const transaction = this._db.transaction([this.STORE_NAME], 'readwrite');
            const store = transaction.objectStore(this.STORE_NAME);
            const request = store.add(data);
            request.onsuccess = () => resolve(id);
            request.onerror = (e) => reject(e);
        });
    },

    async getMedia(id) {
        await this.init();
        return new Promise((resolve, reject) => {
            const transaction = this._db.transaction([this.STORE_NAME], 'readonly');
            const store = transaction.objectStore(this.STORE_NAME);
            const request = store.get(id);
            request.onsuccess = () => resolve(request.result);
            request.onerror = (e) => reject(e);
        });
    },

    async deleteMedia(id) {
        await this.init();
        return new Promise((resolve, reject) => {
            const transaction = this._db.transaction([this.STORE_NAME], 'readwrite');
            const store = transaction.objectStore(this.STORE_NAME);
            const request = store.delete(id);
            request.onsuccess = () => resolve(true);
            request.onerror = (e) => reject(e);
        });
    },

    /**
     * Helper to get a temporary URL for an IDB media item
     */
    async getMediaUrl(id) {
        const item = await this.getMedia(id);
        if (!item) return null;
        return URL.createObjectURL(item.blob);
    },

    async getAllIds() {
        await this.init();
        return new Promise((resolve, reject) => {
            const transaction = this._db.transaction([this.STORE_NAME], 'readonly');
            const store = transaction.objectStore(this.STORE_NAME);
            const request = store.getAllKeys();
            request.onsuccess = () => resolve(request.result);
            request.onerror = (e) => reject(e);
        });
    },

    async garbageCollect(activeIds = []) {
        const storedIds = await this.getAllIds();
        const orphans = storedIds.filter(id => !activeIds.includes(id));
        
        if (orphans.length === 0) return;

        console.log(`[MediaDB] GC: Purging ${orphans.length} orphan media blobs...`);
        
        for (const id of orphans) {
            await this.deleteMedia(id);
        }
        
        console.log(`[MediaDB] GC: Cleanup complete.`);
    }
};

window.MediaDB = MediaDB;
