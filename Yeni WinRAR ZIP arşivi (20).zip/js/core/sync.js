/**
 * SyncService.js
 * DEPRECATED - Real-time Firebase Synchronization REMOVED
 * MySQL polling or BroadcastChannel used instead.
 */
const SyncService = {
    db: null,
    isConnected: false,

    init() {
        console.log('ℹ️ SyncService: Legacy Firebase sync is disabled.');
    },

    async push(path, data) {
        // No-op or migrate to MySQL if needed
        console.log('ℹ️ SyncService push requested (ignored):', path);
    },

    on(path, callback) {
        // No-op
    },

    off(path) {
        // No-op
    },

    setupPresence() {
        // No-op
    },

    listenToGlobalEvents() {
        // No-op
    }
};

window.SyncService = SyncService;

