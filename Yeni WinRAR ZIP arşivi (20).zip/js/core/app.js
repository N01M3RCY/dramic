/**
 * DramicBox Application Logic - SPA Edition
 * Fixed and Enhanced Version
 */

// --- STATE MANAGEMENT ---
// Moved to js/core/state.js


// --- DATA SERVICE ---
// Moved to js/core/db.js

if (typeof window.App === 'undefined') {
    window.App = {
        _lastRoute: null,
        showView(viewId) {
        document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
        const view = document.getElementById(viewId);
        if (view) view.style.display = 'block';
    },
    toggleMobileMenu() {
        const overlay = document.getElementById('mobile-nav-overlay');
        if (overlay) {
            overlay.classList.toggle('active');
            document.body.style.overflow = overlay.classList.contains('active') ? 'hidden' : '';
        }
    },
    showWelcomeBetaModal() {
        if (sessionStorage.getItem('dramicbox_welcome_shown')) return;
        
        const modal = document.createElement('div');
        modal.id = 'welcome-beta-modal';
        modal.style.cssText = `
            position: fixed; inset: 0; z-index: 99999;
            background: rgba(4, 4, 6, 0.85);
            backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
            display: flex; align-items: center; justify-content: center;
            opacity: 0; transition: opacity 0.5s ease;
            padding: 20px;
        `;
        
        modal.innerHTML = `
            <div class="welcome-modal-content" style="
                background: linear-gradient(135deg, rgba(20, 20, 30, 0.9), rgba(10, 10, 15, 0.95));
                border: 1px solid rgba(139, 92, 246, 0.25);
                box-shadow: 0 30px 70px rgba(0,0,0,0.8), 0 0 50px rgba(139, 92, 246, 0.15);
                border-radius: 32px; padding: 40px; text-align: center;
                max-width: 500px; width: 100%;
                transform: translateY(30px); transition: transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
                position: relative; overflow: hidden;
            ">
                <div style="position: absolute; top: -50px; left: 50%; transform: translateX(-50%); width: 200px; height: 200px; background: radial-gradient(circle, rgba(139, 92, 246, 0.25) 0%, transparent 70%); filter: blur(30px); pointer-events: none;"></div>
                
                <div class="welcome-modal-icon" style="
                    width: 80px; height: 80px; background: rgba(139, 92, 246, 0.1); border-radius: 24px;
                    display: flex; align-items: center; justify-content: center; margin: 0 auto 25px;
                    border: 1px solid rgba(139, 92, 246, 0.3); box-shadow: 0 0 25px rgba(139, 92, 246, 0.25);
                ">
                    <i class="fa-solid fa-sparkles" style="font-size: 2.2rem; color: #a78bfa; animation: welcomePulse 2s infinite;"></i>
                </div>
                
                <h2 style="
                    font-size: 2rem; font-weight: 900; color: #fff; margin-bottom: 12px;
                    background: linear-gradient(135deg, #fff, #a78bfa); -webkit-background-clip: text; -webkit-text-fill-color: transparent;
                    letter-spacing: -0.5px;
                    font-family: 'Outfit', sans-serif;
                ">DramicBox Beta Sürecinde!</h2>
                
                <p style="
                    color: #94a3b8; font-size: 1rem; line-height: 1.6; margin-bottom: 30px;
                    font-weight: 500; text-align: center;
                    font-family: 'Outfit', sans-serif;
                ">
                    DramicBox yenilenen modern tasarımı, yüksek hızlı oynatıcısı ve yepyeni topluluk özellikleri ile şu anda beta sürecindedir. 
                    Deneyiminizi geliştirmek için sürekli çalışıyoruz. Keyifli vakit geçirmeniz dileğiyle!
                </p>
                
                <button onclick="App.dismissWelcomeBetaModal()" class="welcome-close-btn" style="
                    width: 100%; padding: 15px; border-radius: 16px; border: none;
                    background: linear-gradient(135deg, #7c3aed, #6d28d9);
                    color: #fff; font-weight: 800; font-size: 1rem; cursor: pointer;
                    box-shadow: 0 10px 25px rgba(124, 58, 237, 0.35); transition: all 0.3s ease;
                    font-family: 'Outfit', sans-serif;
                ">
                    Keşfetmeye Başla
                </button>
            </div>
            <style>
                @keyframes welcomePulse {
                    0%, 100% { transform: scale(1); filter: drop-shadow(0 0 5px rgba(167, 139, 250, 0.5)); }
                    50% { transform: scale(1.1); filter: drop-shadow(0 0 15px rgba(167, 139, 250, 0.8)); }
                }
                .welcome-close-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 12px 30px rgba(124, 58, 237, 0.5);
                    filter: brightness(1.1);
                }
            </style>
        `;
        
        document.body.appendChild(modal);
        
        setTimeout(() => {
            modal.style.opacity = '1';
            const content = modal.querySelector('.welcome-modal-content');
            if (content) content.style.transform = 'translateY(0)';
        }, 100);
    },
    dismissWelcomeBetaModal() {
        const modal = document.getElementById('welcome-beta-modal');
        if (modal) {
            modal.style.opacity = '0';
            const content = modal.querySelector('.welcome-modal-content');
            if (content) content.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                modal.remove();
                sessionStorage.setItem('dramicbox_welcome_shown', 'true');
            }, 500);
        }
    },
    async init() {
        if (this._initialized) return;
        this._initialized = true;
        console.log('🚀 DramicBox App Initializing...');

        // 1. Initial Auth UI update (Show guest UI immediately)
        if (window.Auth && Auth.updateAuthUI) {
            Auth.updateAuthUI();
        }

        // 2. Restore user session early
        let persistentUser = null;
        try {
            if (window.Auth && Auth.checkPersistentSession) {
                persistentUser = await Auth.checkPersistentSession();
            }
            if (persistentUser) {
                State.currentUser = persistentUser;
            } else {
                let storedUser = localStorage.getItem('dramicbox_user');
                State.currentUser = storedUser ? JSON.parse(storedUser) : { role: 'guest', username: 'Misafir' };
            }
        } catch (e) {
            console.warn('⚠️ Session restore failed:', e);
            State.currentUser = { role: 'guest' };
        }

        // 3. Update Auth UI again with restored user and render Navbar
        if (window.Auth && Auth.updateAuthUI) {
            Auth.updateAuthUI();
        }
        if (typeof App.renderNavbar === 'function') {
            App.renderNavbar();
        }

        // 4. Load INITIAL CORE data
        await db.loadData(['series', 'announcements', 'blogPosts', 'settings', 'calendar', 'users', 'webtoons', 'socialPosts', 'actors']);

        // Sync AdService config with database
        if (typeof AdService !== 'undefined') AdService.initSync();

        // --- MAINTENANCE MODE CHECK ---
        const user = State.currentUser;
        const isAdmin = user && (user.role === 'admin' || user.badges?.includes('Yönetici') || user.badges?.includes('Admin'));

        // Check site settings safely
        let isMaintenance = false;
        try {
            const settings = State.data.settings;
            let currentSettings = {};
            if (Array.isArray(settings) && settings.length > 0) {
                currentSettings = settings[0];
            } else if (typeof settings === 'object' && settings !== null) {
                currentSettings = settings;
            } else {
                currentSettings = JSON.parse(localStorage.getItem('dramicbox_site_settings') || '{}');
            }
            isMaintenance = currentSettings.maintenanceMode === true;
        } catch (e) {
            console.warn('⚠️ Maintenance check error:', e);
        }

        if (isMaintenance && !isAdmin) {
            document.body.innerHTML = `
                <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; background:#0f0f13; color:white; font-family:'Outfit',sans-serif; text-align:center;">
                    <i class="fa-solid fa-triangle-exclamation" style="font-size: 4rem; color: #ef4444; margin-bottom: 20px;"></i>
                    <h1 style="font-size: 2.5rem; margin-bottom: 10px;">Bakım Modu</h1>
                    <p style="color: #94a3b8; max-width: 500px;">DramicBox şu anda daha iyi hizmet verebilmek için güncelleniyor. Lütfen kısa bir süre sonra tekrar kontrol edin. 🛠️</p>
                    <button onclick="location.reload()" style="margin-top:20px; padding:10px 20px; background:#7c3aed; border:none; color:white; border-radius:8px; cursor:pointer;">Tekrar Dene</button>
                    <a href="#" onclick="Auth.showLogin()" style="margin-top:15px; color:#64748b; font-size:0.8rem; text-decoration:none;">Yönetici Girişi</a>
                </div>
             `;
            return; // STOP APP EXECUTION
        }

        // UI Core Components (Always present)
        this.initRouter();

        if (window.HeroSlider) HeroSlider.init();
        if (window.ThemeSystem) ThemeSystem.init();
        if (window.Search) Search.init();
        if (window.LatestReleases) LatestReleases.init();
        if (window.BlogSystem) BlogSystem.init();

        // Load User Dashboard
        await Loader.loadScript('js/pages/user-dashboard.js');

        // Background loading of non-critical components
        setTimeout(async () => {
            if (window.Gamification) Gamification.init();
            if (window.BadgeSystem) BadgeSystem.checkAll();
            if (window.Social) Social.init();

            // Load and Init Daily Reward (Automatic / Silent claim)
            await Loader.loadScript('js/features/daily-reward.js');
            if (window.DailyReward) {
                DailyReward.init();
                DailyReward.claimSilent();
            }

            // Load and Init Notification System
            await Loader.loadScript('js/features/notifications.js');
            if (window.NotificationSystem) NotificationSystem.init();

            // Start Cloud Sync Pulse (Real-time multi-user sync)
            db.startCloudPulse(10000); // Sync every 10s for better integrity

            // Presence Tracking (NEW)
            setInterval(() => {
                if (State.currentUser && State.currentUser.id) {
                    State.currentUser.lastActive = new Date().toISOString();
                    db.syncItem('users', State.currentUser);
                }
            }, 60000); // Update every 1 minute
        }, 1000);

        this.setupVideoProtection();
        this.updateDefaultAdmin();
        this.populateFilters();
        this.initEasterEgg();

        // Initialize Admin Bar if Admin
        if (isAdmin) {
            await Loader.loadScript('js/features/admin-bar.js');
        }

        // Apply system toggles (hide disabled systems from navbars/sections)
        this.applySystemToggles();
        this.checkLiveStatus();

        // Navbar Scroll Effect
        window.addEventListener('scroll', () => {
            const nav = document.getElementById('main-navbar');
            if (nav) {
                if (window.scrollY > 50) {
                    nav.classList.add('scrolled');
                } else {
                    nav.classList.remove('scrolled');
                }
            }
        });

        // Initialize Global Stats
        this.updateGlobalStats();

        // Hide App Loader after everything is ready
        const appLoader = document.getElementById('app-loader');
        if (appLoader) {
            appLoader.classList.add('hide-bg');
            setTimeout(() => {
                appLoader.remove();
                this.showWelcomeBetaModal();
            }, 500);
        } else {
            this.showWelcomeBetaModal();
        }
    },

    requireAuth(callback) {
        if (!State.currentUser || State.currentUser.role === 'guest' || !State.currentUser.id) {
            Toast.warning('Bu özelliği kullanmak için giriş yapmalısınız!');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return false;
        }
        if (callback) callback();
        return true;
    },

    isGuest() {
        return !State.currentUser || State.currentUser.role === 'guest';
    },

    async updateGlobalStats() {
        try {
            const inc = !sessionStorage.getItem('dramicbox_visit_counted');
            const response = await fetch(`api/db.php?action=global-stats${inc ? '&inc=1' : ''}`);
            const data = await response.json();
            
            if (data.success && data.stats) {
                const totalEl = document.getElementById('stat-total-visitors');
                const dailyEl = document.getElementById('stat-daily-visitors');
                
                if (totalEl) totalEl.innerText = data.stats.totalVisitors.toLocaleString();
                if (dailyEl) dailyEl.innerText = data.stats.dailyVisitors.toLocaleString();
                
                if (inc) sessionStorage.setItem('dramicbox_visit_counted', 'true');
            }
        } catch (e) {
            console.warn('Failed to fetch global stats:', e);
        }
    },

    startHeartbeat() {
        if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);

        // Check every 60 seconds
        this.heartbeatInterval = setInterval(async () => {
            if (State.currentUser && State.currentUser.role !== 'guest') {
                await Auth.checkSession();
                // Optionally update UI elements that depend on user status here
            } else {
                clearInterval(this.heartbeatInterval);
                this.heartbeatInterval = null;
            }
        }, 60000);
    },

    // --- EASTER EGG SYSTEM ---
    _eggClicks: 0,
    initEasterEgg() {
        const logo = document.querySelector('.nav-brand');
        if (logo) {
            logo.style.cursor = 'pointer';
            logo.addEventListener('click', () => {
                this._eggClicks++;
                if (this._eggClicks === 7) {
                    this.triggerEasterEgg();
                    this._eggClicks = 0;
                }
            });
        }
    },

    async triggerEasterEgg() {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            return Toast.info('Giriş yapmalısınız...');
        }

        if (!State.data.easterEgg) {
            State.data.easterEgg = { finders: [], max: 3 };
        }

        if (State.data.easterEgg.finders.includes(State.currentUser.id)) {
            return Toast.success('Zaten bu easter eggi buldunuz! ✨');
        }

        const isFull = State.data.easterEgg.finders.length >= State.data.easterEgg.max;
        const isAdmin = State.currentUser.role === 'admin' || (State.currentUser.badges || []).includes('Yönetici');

        if (isFull && !isAdmin) {
            return Toast.info('Tüm ödüller tükendi, ama sırrı buldun! 😉');
        }

        // Award
        if (!isFull) {
            State.data.easterEgg.finders.push(State.currentUser.id);
            
            if (!State.currentUser.badges) State.currentUser.badges = [];
            State.currentUser.badges.push('Sır Avcısı');
            
            if (!State.currentUser.stats) State.currentUser.stats = { coins: 0, level: 1, xp: 0 };
            State.currentUser.stats.coins += 5000;
            
            await db.save();
            Toast.success('Gizli ödül hesabınıza tanımlandı! 🎉');
        }

        // Show Modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width:500px; text-align:center; padding:40px; border:2px solid gold; background:rgba(15,15,19,0.95);">
                <div style="font-size:4rem; margin-bottom:20px;">💎</div>
                <h1 style="color:gold; font-size:2rem; margin-bottom:15px;">TEBRİKLER!</h1>
                <p style="color:#fff; font-size:1.1rem; line-height:1.6;">
                    Dramicbox'ın en büyük sırlarından birini buldun! <br>
                    ${isFull ? 'Ödüller tükendi ama bu özel anı gördün.' : 'İlk 3 kişiden birisin!'}
                </p>
                ${!isFull ? `
                <div style="margin:20px 0; padding:15px; background:rgba(255,215,0,0.1); border-radius:12px;">
                    <b style="color:gold;">ÖDÜL:</b> <br>
                    🏅 "Sır Avcısı" Rozeti <br>
                    💰 5.000 Bonus Coin
                </div>` : ''}
                <button onclick="this.closest('.modal').remove()" class="btn btn-primary">Muhteşem!</button>
            </div>
        `;
        document.body.appendChild(modal);
    },

    // ==================== SYSTEM TOGGLE (Admin Navbar Management) ====================
    isSystemEnabled(systemKey) {
        // Check State.data first, then localStorage fallback
        let settings = State.data?.settings;
        let disabled = [];
        
        if (settings) {
            // Handle both object and array-wrapped object formats
            if (Array.isArray(settings) && settings.length > 0) {
                disabled = settings[0].disabledSystems || [];
            } else if (typeof settings === 'object') {
                disabled = settings.disabledSystems || [];
            }
        } else {
            const savedSettings = JSON.parse(localStorage.getItem('dramicbox_site_settings') || '{}');
            disabled = savedSettings.disabledSystems || [];
        }
        
        return !disabled.includes(systemKey);
    },

    applySystemToggles() {
        // Get disabled list from State or localStorage fallback
        let settings = State.data?.settings;
        let disabled = [];

        if (settings) {
            if (Array.isArray(settings) && settings.length > 0) {
                disabled = settings[0].disabledSystems || [];
            } else if (typeof settings === 'object') {
                disabled = settings.disabledSystems || [];
            }
        }

        if (disabled.length === 0) {
            const savedSettings = JSON.parse(localStorage.getItem('dramicbox_site_settings') || '{}');
            disabled = savedSettings.disabledSystems || [];
        }

        // Always process all elements (needed to re-enable when list changes)
        document.querySelectorAll('[data-system]').forEach(el => {
            const system = el.getAttribute('data-system');
            if (disabled.includes(system)) {
                el.style.setProperty('display', 'none', 'important');
                el.classList.add('system-disabled');
            } else {
                // Restore original display if it was hidden by this system
                if (el.classList.contains('system-disabled')) {
                    el.style.display = '';
                    el.classList.remove('system-disabled');
                }
            }
        });

        if (disabled.length > 0) {
            console.log(`🔧 System toggles applied. Disabled: [${disabled.join(', ')}]`);
        }
    },

    /**
     * Dynamically loads a module file
     * @param {string} moduleName - Name of the module (matches file name)
     */
    async loadModule(moduleName) {
        // Map module names to file paths
        const moduleMap = {
            'VideoStudioPage': 'js/pages/video-studio-page.js',
            'BlogStudioPage': 'js/pages/blog-studio-page.js',
            'StudioDashboard': 'js/pages/studio-dashboard.js',
            'BrowsePage': 'js/pages/browse-page.js',
            'ShortsPage': 'js/pages/shorts-page.js',
            'MessageService': 'js/services/message-service.js',
            'ShopSystem': 'js/features/shop-system.js',
            'AdminAnalytics': 'js/admin/admin-analytics.js'
        };

        const path = moduleMap[moduleName];
        if (!path) {
            console.error(`Unknown module: ${moduleName}`);
            return Promise.reject(new Error(`Unknown module: ${moduleName}`));
        }

        return Loader.loadScript(path);
    },

    updateDefaultAdmin() {
        if (!State.data || !State.data.users) return;
        const adminUsername = 'Halilaisnc';
        const adminPass = 'Zumran1514!';
        let user = State.data.users.find(u => u.username === adminUsername);

        if (user) {
            // Update if needed
            let changed = false;
            if (user.password !== adminPass) {
                user.password = adminPass;
                changed = true;
            }
            if (!user.badges.includes('Yönetici') && !user.badges.includes('Admin')) {
                if (!user.badges.includes('Yönetici')) user.badges.push('Yönetici');
                if (!user.badges.includes('Admin')) user.badges.push('Admin');
                changed = true;
            }
            if (changed) {
                db.save();
                console.log('✅ Admin credentials updated');
            }
        } else {
            // Create new
            const newAdmin = {
                id: 'admin-' + Date.now(),
                username: adminUsername,
                password: adminPass,
                email: 'halilcan1514@gmail.com',
                badges: ['Yönetici', 'Admin'],
                watchHistory: [],
                watchlist: [],
                settings: {}
            };
            State.data.users.push(newAdmin);
            db.save();
            console.log('✅ Default Admin created');
        }
    },

    toggleMobileMenu() {
        const navLinks = document.querySelector('.nav-links');
        if (navLinks) navLinks.classList.toggle('show');
    },

    setupVideoProtection() {
        const getProtection = () => {
            const settings = State.data.settings;
            let siteSettings = {};
            if (Array.isArray(settings) && settings.length > 0) {
                siteSettings = settings[0];
            } else if (typeof settings === 'object' && settings !== null) {
                siteSettings = settings;
            } else {
                try {
                    siteSettings = JSON.parse(localStorage.getItem('dramicbox_site_settings') || '{}');
                } catch(e) {}
            }
            return siteSettings.screenshotProtectionEnabled !== false;
        };

        // Disable Right Click
        document.addEventListener('contextmenu', event => {
            if (!getProtection()) return;
            event.preventDefault();
        });

        // Disable Long Press on Mobile
        document.addEventListener('touchstart', (e) => {
            if (!getProtection()) return;
            if (e.touches.length > 1) {
                e.preventDefault(); // Disable multi-touch gestures if needed
            }
        }, { passive: false });

        // Disable Screen Capture Keys (PrintScreen, etc.)
        document.addEventListener('keyup', (e) => {
            if (!getProtection()) return;
            if (e.key == 'PrintScreen') {
                const isAdmin = State.currentUser && (State.currentUser.role === 'admin' || State.currentUser.badges?.includes('Yönetici') || State.currentUser.badges?.includes('Admin'));
                if (isAdmin) return;

                navigator.clipboard.writeText('');
                Toast.warning('Ekran görüntüsü almak yasaktır!');
                // Optional: Overlay black screen for a second
                const overlay = document.createElement('div');
                overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:black;z-index:99999;';
                document.body.appendChild(overlay);
                setTimeout(() => overlay.remove(), 1000);
            }
        });

        // Disable Developer Tools Shortcuts
        document.addEventListener('keydown', (e) => {
            if (!getProtection()) return;
            if (e.ctrlKey && (e.key === 'u' || e.key === 'U' || e.key === 's' || e.key === 'S')) {
                e.preventDefault();
            }
            // F12
            if (e.key === 'F12') {
                e.preventDefault();
            }
        });
    },

    showMainApp() {
        console.log('App: Showing main app');
        const navbar = document.querySelector('.navbar');
        if (navbar) navbar.style.display = 'flex';
        if (document.getElementById('main-app')) document.getElementById('main-app').style.display = 'block';
        if (document.getElementById('auth-container')) document.getElementById('auth-container').style.display = 'none';

        if (typeof Auth !== 'undefined' && Auth.updateAuthUI) {
            Auth.updateAuthUI();

            // Apply shop effects to navbar if logged in
            if (State.currentUser) {
                const navAvatar = document.getElementById('nav-user-avatar');
                if (navAvatar) {
                    const activeFrameClass = State.currentUser.activeFrame ?
                        ShopSystem.items.frames.find(f => f.id === State.currentUser.activeFrame)?.class : '';
                    navAvatar.parentElement.className = `nav-user-btn ${activeFrameClass}`;
                    navAvatar.parentElement.style.padding = activeFrameClass ? '2px' : '0';
                }
            }
        } else {
            // Retry if Auth not ready yet
            setTimeout(() => { if (window.Auth) Auth.updateAuthUI(); }, 500);
        }

        // Check for notifications
        if (window.NotificationSystem) {
            NotificationSystem.init();
        }

        // Global Announcement Check
        this.checkGlobalAnnouncements();

        // Setup dropdown listeners
        // this.setupDropdownListeners(); // Removed: not implemented and causing crash

        // Security Watermark for Staff (Anti-Leak)
        if (State.currentUser && ['admin', 'moderator', 'translator'].includes(State.currentUser.role)) {
            if (window.ManagementHub && ManagementHub.setupSecurityWatermark) {
                ManagementHub.setupSecurityWatermark();
            }
        }

    },

    // --- ROUTING & NAVIGATION ---
    // (Router definition moved to lines 1077+)


    renderBrowse(type = 'drama') {
        if (window.BrowsePage) {
            BrowsePage.init(type);
        } else {
            console.error('BrowsePage module not loaded');
        }
    },

    showSeriesDetail(id) {
        const series = db.getSeries(id);
        if (!series) return this.router('home', null, null, true);
        State.currentSeries = series;

        if (window.DetailedView && DetailedView.render) {
            DetailedView.render(series.id);
        } else {
            // Fallback
            const container = document.getElementById('detail-view');
            if (container) container.innerHTML = `<div class="container section" style="padding-top:100px;"><h1>${series.title}</h1><p>Detay modülü yüklenemedi.</p></div>`;
        }
    },

    openSearchModal() {
        const modal = document.getElementById('search-modal');
        if (modal) {
            modal.style.display = 'flex';
            setTimeout(() => document.getElementById('search-input')?.focus(), 100);
        }
    },

    initRouter() {
        // Listen for hash changes (works with file:// protocol)
        window.addEventListener('hashchange', () => {
            if (window.isReloading) return;
            const hash = window.location.hash;
            if (hash.startsWith('#/')) {
                this.handleRoute(hash.slice(1));
            }
        });

        // Also listen for popstate (browser back/forward)
        window.addEventListener('popstate', (e) => {
            if (window.isReloading) return;
            const hash = window.location.hash;
            if (hash.startsWith('#/')) {
                this.handleRoute(hash.slice(1));
            }
        });

        // Handle initial route from hash
        const hash = window.location.hash;
        if (hash.startsWith('#/')) {
            const route = hash.slice(1);
            console.log('🚀 Initial hash route:', route);
            this.handleRoute(route);
        } else {
            // Check for SEO clean URLs (popstate already handles this, but initial load might not have hash)
            const path = window.location.pathname;
            if (path !== '/' && path !== '/index.html') {
                this.handleRoute(path);
            } else {
                this.navigate('home');
            }
        }
    },

    // NEW: Centralized navigation helper
    navigate(viewId, param = null, param2 = null) {
        this.router(viewId, param, param2, false);
    },

    getRoutePath(viewId, param = null, param2 = null, options = {}) {
        let path = `/${viewId}`;
        if (param) path += `/${param}`;
        if (param2) path += `/${param2}`;

        // SEO Aliases (Mirror logic in history.pushState)
        if (viewId === 'home') path = '/ana-sayfa';
        if (viewId === 'browse' && param === 'drama') path = '/diziler';
        if (viewId === 'browse' && param === 'movie') path = '/filmler';
        if (viewId === 'browse' && param === 'anime') path = '/animeler';
        if (viewId === 'calendar') path = '/takvim';

        return path;
    },

    handleRoute(path) {
        // Normalize
        let fullPath = path || '';
        if (fullPath.startsWith('/')) fullPath = fullPath.slice(1);
        fullPath = fullPath.replace(/^#?\/?/, '').replace(/\/$/, '');

        // Close mobile menu on every route change
        const overlay = document.getElementById('mobile-nav-overlay');
        if (overlay) overlay.classList.remove('active');
        document.body.style.overflow = '';

        // Separate path and query string
        const [routePath, queryString] = fullPath.split('?');
        const urlParams = new URLSearchParams(queryString || '');
        const options = Object.fromEntries(urlParams.entries());

        const parts = routePath.split('/');
        const main = parts[0] || 'home';

        // Video Studio - Handled by its own page script or route
        if (main === 'studio-edit-secure-access' || main === 'studio-panel-secure-access') {
            this.router('studio', null, null, true, options);
            return;
        }

        // Map paths to router calls
        if (!main || main === 'anasayfa' || main === 'ana-sayfa') this.router('home', null, null, true, options);
        else if (main === 'player' || main === 'izle' || main === 'watch') this.router('player', parts[1], parts[2], true, options);
        else if (main === 'read' || main === 'oku') this.router('read', parts[1], parts[2], true, options);
        else if (main === 'diziler') this.router('browse', 'drama', null, true, options);
        else if (main === 'filmler' || main === 'movies') this.router('browse', 'movie', null, true, options);
        else if (main === 'animeler') this.router('browse', 'anime', null, true, options);
        else if (main === 'webtoonlar' || main === 'webtoons') this.router('browse', 'webtoon', null, true, options);
        else if (main === 'kisa-dramalar' || main === 'shorts' || main === 'bolumler') this.router('shorts', null, null, true, options);
        else if (main === 'takvim' || main === 'calendar') this.router('calendar', null, null, true, options);
        else if (main === 'oyuncular' || main === 'actors') this.router('actors', null, null, true, options);
        else if (main === 'browse') {
            const sub = parts[1] || 'drama';
            this.router('browse', sub, null, true, options);
        }
        else if (main === 'profil' || main === 'profile') {
            const userId = parts[1] || (State.currentUser ? State.currentUser.id : null);
            if (!userId) {
                Toast.warning('Profil görüntülemek için giriş yapmalısınız.');
                this.router('home', null, null, true, options);
                return;
            }
            this.router('profile', userId, null, true, options);
        }
        else if (main === 'admin-panel') {
            const token = parts[1];
            if (token) {
                Auth.verifyMagicLink(token);
            } else {
                this.router('home', null, null, true, options);
            }
        }
        else if (main === 'blog-studio') {
            if (window.BlogStudioPage) {
                BlogStudioPage.init();
            }
        }
        else if (main === 'blog') {
            if (parts[1]) {
                // Check if it's "blog-studio" first
                if (parts[1] === 'studio') { /* handled above or rename route? */ }
                // Blog Detail Page
                this.router('blog-detail', parts[1], null, true, options);
            } else {
                this.router('blog', null, null, true, options);
            }
        }
        else if (main === 'oyuncu' || main === 'actor' || main === 'actor-detail') {
            if (parts[1]) {
                const actorName = decodeURIComponent(parts[1]);
                this.router('actor-detail', actorName, null, true, options);
            } else {
                this.router('actors', null, null, true, options);
            }
        }
        else if (main === 'blog-studio') {
            if (typeof BlogStudioPage !== 'undefined') {
                BlogStudioPage.render();
            } else {
                Toast.error('Blog Studio yüklenemedi');
            }
            return;
        }
        else if (main === 'playlist') this.router('playlist', parts[1], null, true, options);
        else if (main === 'studio') {
            this.navigate('studio');
            return;
        }
        else if (main === 'live' || main === 'canli') {
            this.router('live', null, null, true, options);
        }

        else if (main === 'admin') {
            window.location.href = 'admin.html';
            return;
        }
        else if (main === 'profil-degistir' || main === 'switch-profile') {
            this.navigate('home');
        }
        else if (main === 'sosyal' || main === 'social') {
            const sub = parts[1] || null;
            const sub2 = parts[2] || null;
            if (sub === 'fan-center' || sub === 'oyuncu-merkezi') {
                this.router('social', 'fan-center', null, true, options);
            } else {
                this.router('social', sub, sub2, true, options);
            }
        }
        else if (main === 'fan-centers' || main === 'oyuncu-merkezi') {
            this.router('social', 'fan-center', null, true, options);
        }
        else if (main === 'edit-series' || main === 'dizi-duzenle') {
            if (parts[1]) {
                this.router('edit-series', decodeURIComponent(parts[1]), null, true, options);
            } else {
                Toast.warning('Düzenlenecek içerik seçilmedi.');
                this.router('home', null, null, true, options);
            }
        }
        else if (main === 'liderlik' || main === 'leaderboard') {
            if (typeof LeaderboardPage !== 'undefined') {
                LeaderboardPage.open();
            } else if (typeof LeaderboardSystem !== 'undefined') {
                LeaderboardSystem.open();
            } else {
                Toast.error('Liderlik tablosu yüklenemedi');
            }
        }
        // Auth routes
        else if (main === 'giris-yap') {
            Auth.showLogin();
        }
        else if (main === 'kayit-ol') {
            Auth.showRegister();
        }

        // Admin Video Studio Route
        /* Legacy Video Studio Route Removed */

        // Cryptology Route (Dynamic URL - starts with 'cryptology-')
        else if (main.startsWith('cryptology-')) {
            if (typeof AdminCryptology !== 'undefined') {
                AdminCryptology.render();
            } else {
                Toast.error('Cryptology modülü yüklenemedi');
                this.router('home', null, null, true, options);
            }
            return;
        }

        else if (main === 'detail' || main === 'dizi' || main === 'webtoon' || main === 'icerik') {
            const slugOrId = parts[1] ? decodeURIComponent(parts[1]) : null;
            const segment1 = parts[2] ? decodeURIComponent(parts[2]) : null;
            const segment2 = parts[3] ? decodeURIComponent(parts[3]) : null;

            if (!slugOrId) {
                this.router('home', null, null, true, options);
                return;
            }

            // --- DATA READINESS CHECK ---
            if (!State.data.series || State.data.series.length === 0) {
                console.log('⏳ State data not ready, waiting...');
                setTimeout(() => this.handleRoute(path), 500);
                return;
            }

            const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])];
            const series = allContent.find(s => {
                const baseSlug = s.title?.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').trim();
                const yearSlug = baseSlug + (s.year ? '-' + s.year : '');
                return s.id === slugOrId || s.slug === slugOrId || baseSlug === slugOrId || yearSlug === slugOrId;
            });

            if (!series) {
                console.warn('❌ Series not found for slug:', slugOrId);
                this.router('home', null, null, true, options);
                return;
            }


            const isNumericIndex = segment1 && !isNaN(parseInt(segment1)) && segment1 === String(parseInt(segment1));
            const isEpisodePattern = (segment1 && segment1.startsWith('sezon-') && segment2 && segment2.startsWith('bolum-')) ||
                                   (segment1 && segment1.startsWith('bolum-'));

            if (isNumericIndex) {
                this.router('player', series.id, parseInt(segment1), true, options);
                return;
            }

            if (isEpisodePattern) {
                let episodeNum = 1, seasonNum = 1;
                if (segment1.startsWith('sezon-')) {
                    seasonNum = parseInt(segment1.replace('sezon-', ''));
                    episodeNum = parseInt(segment2.replace('bolum-', ''));
                } else {
                    episodeNum = parseInt(segment1.replace('bolum-', ''));
                }

                let absoluteIndex = 0, found = false;
                if (series.seasons && seasonNum) {
                    for (let s of series.seasons) {
                        if (s.number < seasonNum) absoluteIndex += s.episodes.length;
                        else if (s.number === seasonNum) {
                            const epIdx = s.episodes.findIndex(e => e.number === episodeNum);
                            if (epIdx !== -1) { absoluteIndex += epIdx; found = true; }
                            break;
                        }
                    }
                } else if (series.episodes) {
                    const epIdx = series.episodes.findIndex(e => e.number === episodeNum);
                    if (epIdx !== -1) { absoluteIndex = epIdx; found = true; }
                }
                this.router('player', series.id, found ? absoluteIndex : 0, true, options);
                return;
            }

            let tab = null;
            if (segment1 && ['hakkinda', 'bolumler', 'karakterler', 'yorumlar', 'incelemeler', 'fanmerkezi', 'fan-merkezi', 'ost', 'about', 'episodes', 'cast', 'comments', 'reviews', 'fancenter'].includes(segment1)) {
                const tabMap = { 
                    'hakkinda': 'about', 'about': 'about',
                    'bolumler': 'episodes', 'episodes': 'episodes',
                    'karakterler': 'cast', 'cast': 'cast',
                    'yorumlar': 'comments', 'comments': 'comments',
                    'incelemeler': 'reviews', 'reviews': 'reviews',
                    'fanmerkezi': 'fancenter', 'fan-merkezi': 'fancenter', 'fancenter': 'fancenter',
                    'ost': 'ost'
                };
                tab = tabMap[segment1];
            }
            this.router('detail', series.id, tab, true, options);
        }
        else if (main === 'search' || main === 'arama') {
            this.router('search', parts[1] || null, null, true, options);
        }
        else if (main === 'vip-uyelik' || main === 'vip' || main === 'market' || main === 'shop' || main === 'magaza') {
            this.router('shop', parts[1] || null, null, true, options);
        }
        else {
            console.warn('❓ Unhandled route:', main, 'Path:', fullPath);
            // Before redirecting to home, check if it might be a slug directly
            const possibleSlug = parts[0];
            const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])];
            if (allContent.find(s => s.id === possibleSlug || s.slug === possibleSlug)) {
                this.router('detail', possibleSlug, null, true, options);
            } else {
                this.router('home', null, null, true, options);
            }
        }
    },

    async router(viewId, param = null, param2 = null, fromHistory = false, options = {}) {
        // --- FLICKER & LOOP PREVENTION ---
        const currentRoute = `${viewId}-${param || ''}-${param2 || ''}`;
        if (this._lastRoute === currentRoute && !options.force) {
            console.log('App.router: Skipping redundant route render for', viewId);
            return;
        }
        this._lastRoute = currentRoute;

        console.log('🚀 Routing to:', viewId, param, param2, options);

        // Track Page View Log
        if (viewId !== 'player') {
            if (typeof window.logActivity === 'function') {
                window.logActivity('Sayfa Görüntüleme', { view: viewId, param: param });
            }
        }

        // Update URL via Hash (Better for local file:// compatibility)
        if (!fromHistory) {
            let hash = `#/${viewId}`;
            if (param) hash += `/${param}`;
            if (param2) hash += `/${param2}`;

            // SEO Aliases (still using hash)
            if (viewId === 'home') hash = '#/ana-sayfa';
            else if (viewId === 'browse' && param === 'drama') hash = '#/diziler';
            else if (viewId === 'browse' && param === 'webtoon') hash = '#/webtoonlar';
            else if (viewId === 'browse' && param === 'movie') hash = '#/filmler';
            else if (viewId === 'browse' && param === 'anime') hash = '#/animeler';
            else if (viewId === 'calendar') hash = '#/takvim';
            else if (viewId === 'shop') hash = '#/market';
            else if (viewId === 'social') hash = '#/sosyal';

            window.location.hash = hash;
        }

        // --- SPA Smooth Transition ---
        let progressBar = document.getElementById('spa-progress');
        if (!progressBar) {
            progressBar = document.createElement('div');
            progressBar.id = 'spa-progress';
            progressBar.className = 'spa-progress-bar';
            document.body.prepend(progressBar);
        }
        progressBar.className = 'spa-progress-bar active';

        const currentVisible = document.querySelector('.view-section[style*="display: block"], .view-section.active');
        if (currentVisible && currentVisible.id !== (viewId + '-view')) {
            currentVisible.classList.add('spa-fade-out');
        }

        const switchDelay = currentVisible ? 120 : 0;
        setTimeout(async () => {
            // Hide previous view
            if (currentVisible) {
                currentVisible.style.display = 'none';
                currentVisible.classList.remove('spa-fade-out', 'active');
            }

            // Prepare all views (ensure hidden except target if needed)
            document.querySelectorAll('.view-section').forEach(el => {
                if (el !== currentVisible) {
                   el.style.display = 'none';
                   el.classList.remove('spa-fade-out', 'spa-fade-in', 'active');
                }
            });
            document.querySelectorAll('.nav-links a').forEach(el => el.classList.remove('active'));

            // Wait for content loading (scripts, initial data)
            await this._routerContent(viewId, param, param2, fromHistory, options);

            const newView = document.querySelector('.view-section[style*="display: block"]');
            if (newView) {
                newView.classList.add('spa-fade-in');
                setTimeout(() => newView.classList.remove('spa-fade-in'), 350);
            }

            progressBar.className = 'spa-progress-bar done';
            setTimeout(() => { progressBar.className = 'spa-progress-bar'; }, 500);
        }, switchDelay);
    },

    async _routerContent(viewId, param = null, param2 = null, fromHistory = false, options = {}) {
        // --- CENTRAL DATABASE READINESS CHECK ---
        if (window.db && typeof db.loadedCollections !== 'undefined' && !db.loadedCollections.has('series')) {
            console.log('⏳ [SPA Router] Database collections not loaded yet, pausing render for:', viewId);
            setTimeout(() => this._routerContent(viewId, param, param2, fromHistory, options), 150);
            return;
        }

        // Map specific virtual views to their DOM sections
        let actualViewId = viewId;
        if (['webtoons', 'webtoonlar', 'drama', 'diziler', 'anime', 'animeler', 'movie', 'movies', 'filmler'].includes(viewId)) {
            actualViewId = 'browse';
        }
        else if (viewId === 'notifications') actualViewId = 'notifications';
        else if (viewId === 'social' || viewId === 'messages') actualViewId = 'social';
        else actualViewId = actualViewId;
        // Lazy-load module scripts based on route
        const PAGE_MODULES = {
            'shorts': 'js/pages/shorts-page.js',
            'blog': 'js/features/blog-system.js',
            'blog-detail': 'js/features/blog-system.js',
            'detail': 'js/pages/detailed-view.js',
            'player': 'js/pages/player.js',
            'profile': 'js/pages/profile-advanced.js',
            'browse': 'js/pages/browse-page.js',
            'movies': 'js/pages/browse-page.js',
            'webtoons': 'js/pages/browse-page.js',
            'actor-detail': 'js/pages/actor-detail.js',
            'admin': 'js/admin/ManagementHub.js',
            'studio': 'js/admin/ManagementHub.js',
            'social': 'js/features/social-feed.js',
            'leaderboard': 'js/pages/leaderboard-page.js',
            'live-player': 'js/pages/live-player.js',
            'broadcaster-studio': 'js/pages/broadcaster-studio.js',
            'calendar': 'js/pages/calendar-page.js',
            'edit-series': 'js/pages/series-edit.js'
        };

        if (PAGE_MODULES[viewId]) {
            await Loader.loadScript(PAGE_MODULES[viewId]);
        }

        // Handle collection loading for specific views
        if (viewId === 'shorts') await db.ensureCollection('shorts');
        if (viewId === 'actor-detail' || viewId === 'actors') await db.ensureCollection('actors');
        if (viewId === 'admin') await db.loadData(['tickets', 'logs', 'reports', 'settings']);
        if (viewId === 'movies' || viewId === 'movie') await db.ensureCollection('series');

        const view = document.getElementById(actualViewId + '-view');
        if (view) {
            document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
            view.style.display = 'block';
        }
        window.scrollTo(0, 0);

        // Update Navbar Active State
        document.querySelectorAll('.nav-links a').forEach(link => {
            const route = link.getAttribute('data-route');
            const linkParam = link.getAttribute('data-param');
            if (route === viewId && (!linkParam || linkParam === param)) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });

        // Trigger Render Logic for specific views
        if (viewId === 'home') { if (window.HeroSlider) HeroSlider.render(); this.renderHome(); }
        else if (viewId === 'detail' && window.DetailedView) {
            let seriesObj = db.getSeries(param);
            if (!seriesObj && db.ensureSeries) seriesObj = await db.ensureSeries(param);
            await DetailedView.render(seriesObj || param, param2);
            const dv = document.getElementById('detail-view');
            if (dv) dv.style.display = 'block';
        }
        else if (viewId === 'player' && window.Player) Player.play(param, param2);
        else if (viewId === 'calendar') {
            if (window.CalendarPage) CalendarPage.init();
        }
        else if (viewId === 'browse') {
            if (window.BrowsePage) BrowsePage.init(param || 'drama');
        }
        else if (viewId === 'webtoons') {
            if (window.BrowsePage) BrowsePage.init('webtoon');
        }
        else if (viewId === 'anime') {
            if (window.BrowsePage) BrowsePage.init('anime');
        }
        else if (viewId === 'movie' || viewId === 'movies') {
            if (window.BrowsePage) BrowsePage.init('movie');
        }
        else if (viewId === 'notifications') {
            document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
            const notifView = document.getElementById('notifications-view');
            if (notifView) {
                notifView.style.display = 'block';
                // Trigger full page notifications if needed or just open drawer
                if (window.NotificationSystem) NotificationSystem.togglePanel();
            }
        }
        else if (viewId === 'shorts' && window.ShortsPage) ShortsPage.render();
        else if (viewId === 'blog' && window.BlogSystem) BlogSystem.init();
        else if (viewId === 'social' && window.SocialFeed) {
            const socialTab = param === 'fan-center' ? 'fan-center' : (param || 'feed');
            const targetUser = param === 'profile' ? param2 : (param && !['fan-center', 'feed', 'live', 'blog', 'reviews', 'friends', 'messages', 'moderation', 'badges'].includes(param) ? param : param2);
            SocialFeed.init({ tab: socialTab, targetUser: param === 'profile' ? param2 : targetUser });
        }
        else if (viewId === 'actor-detail') {
            if (window.ActorDetail) {
                ActorDetail.render(param);
            } else if (window.DetailedView) {
                DetailedView.renderActorPage(param);
            }
        }
        else if (viewId === 'actors') {
            this.renderActorsPage();
        }
        else if (viewId === 'profile') {
            // Load users collection if needed
            await db.ensureCollection('users');
            await db.ensureCollection('socialPosts');
            const profileView = document.getElementById('profile-view');
            if (profileView) {
                document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
                profileView.style.display = 'block';
            }
            if (window.AdvancedProfile) {
                await AdvancedProfile.render(param);
            }
        }
        else if (viewId === 'actors') this.renderActorsPage();
        else if (viewId === 'admin' || viewId === 'studio') ManagementHub.init('dashboard');
        else if (viewId === 'live' || viewId === 'canli') {
            if (param === 'studio') {
                await Loader.loadScript('js/pages/broadcaster-studio.js');
                BroadcasterStudio.init();
            } else if (param) {
                await Loader.loadScript('js/pages/live-player.js');
                LivePlayer.init(param);
            } else {
                this.renderLiveView();
            }
        }
        else if (viewId === 'shop') {
            // Show home view as background, then open shop modal
            const homeView = document.getElementById('home-view');
            if (homeView) {
                document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
                homeView.style.display = 'block';
            }
            if (window.ShopSystem) {
                ShopSystem.open();
                // If coming from vip-uyelik route, switch to premium tab
                if (param === 'premium' || !param) {
                    setTimeout(() => ShopSystem.switchTab('premium'), 300);
                } else {
                    setTimeout(() => ShopSystem.switchTab(param), 300);
                }
            } else {
                await App.loadModule('ShopSystem');
                if (window.ShopSystem) {
                    ShopSystem.open();
                    setTimeout(() => ShopSystem.switchTab(param || 'premium'), 300);
                }
            }
        }
        else if (viewId === 'social') {
            const socialView = document.getElementById('social-view');
            if (socialView) {
                document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
                socialView.style.display = 'block';
            }
            if (window.SocialFeed) {
                SocialFeed.init({ tab: param || 'feed', targetUser: param2 });
            } else {
                await Loader.loadScript('js/features/social-feed.js');
                if (window.SocialFeed) SocialFeed.init({ tab: param || 'feed', targetUser: param2 });
            }
        }
        else if (viewId === 'edit-series' && window.SeriesEdit) {
            SeriesEdit.open(param);
        }
        else if (viewId === 'messages' && window.SocialFeed) {
            SocialFeed.init({ tab: 'messages' });
        }
        else if (viewId === 'fan-centers') {
            this.renderFanCentersPage();
        }
        else if (viewId === 'anime' || viewId === 'animeler') {
            if (window.BrowsePage) BrowsePage.init('anime');
        }

        else if (viewId === 'leaderboard' && window.LeaderboardPage) LeaderboardPage.render();
        else if (viewId === 'leaderboard') this.renderLeaderboard();


        // Push to Browser History - REMOVED DUPLICATE LOGIC
    },

    // --- NEW: Visit Page Helper (Simulate Fresh Tab/Reload) ---
    visitPage(url) {
        if (url.startsWith('#')) {
            window.location.hash = url;
            // No reload needed, hashchange listener handles it
        } else {
            window.location.href = url;
        }
    },

    // ...

    toggleMobileMenu() {
        const overlay = document.getElementById('mobile-nav-overlay');
        if (overlay) {
            overlay.classList.toggle('active');
            document.body.style.overflow = overlay.classList.contains('active') ? 'hidden' : '';
        }
    },


    // Grid builder helper REPLACED with StandardCard Grid
    buildNetflixRow(items, rowId) {
        if (!items || items.length === 0) return '<div class="no-content" style="padding: 0 4%;">İçerik bulunamadı.</div>';

        const cardsHtml = items.map(s => {
            if (window.StandardCard) {
                return `<div style="flex: 0 0 220px;">${StandardCard.render(s)}</div>`;
            }
            return ''; // Should not happen
        }).join('');

        return `
            <div class="netflix-row" id="row-${rowId}">
                <div class="netflix-scroll-container" style="display: flex; gap: 20px; overflow-x: auto; padding: 20px 0;">
                    ${cardsHtml}
                </div>
            </div>
        `;
    },

    // Grid builder for vertical layouts (Browse, Search Results)
    buildGrid(items) {
        if (!items || items.length === 0) return '<div class="no-content" style="padding: 100px; text-align: center; color: var(--text-secondary); grid-column: 1/-1;">Aradığınız kriterlere uygun içerik bulunamadı.</div>';

        if (window.StandardCard) {
            return items.map(s => StandardCard.render(s)).join('');
        }
        return '';
    },


    renderHome() {
        if (State.currentUser && window.UserDashboard) {
            UserDashboard.init();
        }

        console.log('App: Rendering generic home started (Horizontal Mode)');

        if (!State.data || !State.data.series) {
            console.warn('⚠️ No data for home');
            return;
        }

        // --- VIP CHECK ---
        const user = State.currentUser;
        const isLoggedIn = user && user.role !== 'guest';
        const isVipUser = isLoggedIn && (
            user.role === 'admin' ||
            user.role === 'moderator' ||
            user.role === 'vip' ||
            (user.vipUntil && new Date(user.vipUntil) > new Date())
        );

        /* Using simple reload approach for renderHome not necessary */

        // 1. Continue Watching
        const continueContainer = document.getElementById('continue-watching-grid');
        if (continueContainer && window.ContinueWatching) {
            if (ContinueWatching.renderContinueWatching) ContinueWatching.renderContinueWatching();
        }

        // 1.5 DYNAMIC COLLECTIONS (Vitrin)
        const dynColContainer = document.getElementById('dynamic-collections-container');
        if (dynColContainer) {
            if (State.data.collections && State.data.collections.length > 0) {
                let html = '';
                State.data.collections.forEach(col => {
                    if (!col.items || col.items.length === 0) return;
                    
                    const itemsHtml = col.items.map(itemId => {
                        let content = State.data.series.find(s => s.id === itemId);
                        if (!content) content = State.data.webtoons?.find(w => w.id === itemId);
                        if (!content) return '';
                        
                        // VIP Auth check
                        if ((content.isVip || content.isPremium) && !isVipUser) return '';
                        
                        if (typeof StandardCard !== 'undefined') {
                            return StandardCard.render(content);
                        } else {
                            return this.createHorizontalCard(content);
                        }
                    }).join('');

                    if (itemsHtml.trim() !== '') {
                        html += `
                            <section class="container section">
                                <div class="section-header">
                                    <h2 class="section-title"><i class="fa-solid fa-layer-group" style="color:#0ea5e9; margin-right:8px;"></i> ${col.title}</h2>
                                </div>
                                <div class="media-grid">
                                    ${itemsHtml}
                                </div>
                            </section>
                        `;
                    }
                });
                dynColContainer.innerHTML = html;
            } else {
                dynColContainer.innerHTML = ''; // empty if no collections
            }
        }

        // 2. Popular Dramas (Redesigned to match browse page)
        const dramasContainer = document.getElementById('popular-dramas');
        if (dramasContainer) {
            const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])];
            const dramas = allContent
                .filter(s => {
                    const isType = ['dizi', 'drama', 'series'].includes(s.type);
                        const isVisible = !s.isHidden && (isVipUser || (!s.isVip && !s.isPremium));
                    return isType && isVisible;
                })
                .sort((a, b) => ((b.views || 0) + (b.popularity || 0)) - ((a.views || 0) + (a.popularity || 0)))
                .slice(0, 10);

            if (window.StandardCard) {
                dramasContainer.innerHTML = dramas.map(s => StandardCard.render(s)).join('');
                dramasContainer.className = 'standard-grid animate-up';
            }
        }

        // 2.5 Popular Movies
        const moviesContainer = document.getElementById('popular-movies');
        if (moviesContainer) {
            const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])];
            const movies = allContent
                .filter(s => {
                    const isType = s.type === 'movie' || s.type === 'film';
                        const isVisible = !s.isHidden && (isVipUser || (!s.isVip && !s.isPremium));
                    return isType && isVisible;
                })
                .sort((a, b) => ((b.views || 0) + (b.popularity || 0)) - ((a.views || 0) + (a.popularity || 0)))
                .slice(0, 10);

            if (window.StandardCard) {
                moviesContainer.innerHTML = movies.map(s => StandardCard.render(s)).join('');
                moviesContainer.className = 'standard-grid';
            }
        }

        // 3. Popular Webtoons (Redesigned to match browse page)
        const webtoonsContainer = document.getElementById('popular-webtoons');
        if (webtoonsContainer) {
            const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])];
            const webtoons = allContent
                .filter(s => {
                    const isType = s.type === 'webtoon';
                        const isVisible = !s.isHidden && (isVipUser || (!s.isVip && !s.isPremium));
                    return isType && isVisible;
                })
                .sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
                .slice(0, 10);

            if (window.StandardCard) {
                webtoonsContainer.innerHTML = webtoons.map(s => StandardCard.render(s)).join('');
                webtoonsContainer.className = 'standard-grid';
            }
        }

        // 4. Latest Releases
        if (window.LatestReleases && LatestReleases.init) LatestReleases.init();

        // 5. Popular Anime
        const animeContainer = document.getElementById('popular-anime');
        if (animeContainer) {
            const animes = State.data.series
                .filter(s => {
                    const isType = s.type === 'anime';
                        const isVisible = !s.isHidden && (isVipUser || (!s.isVip && !s.isPremium));
                    return isType && isVisible;
                })
                .sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
                .slice(0, 10);

            if (animes.length > 0) {
                if (window.StandardCard) {
                    animeContainer.innerHTML = animes.map(s => StandardCard.render(s)).join('');
                }
                animeContainer.className = 'standard-grid';
                animeContainer.closest('section').style.display = '';
            } else {
                animeContainer.closest('section').style.display = 'none';
            }
        }

        // 6. Show admin mobile nav if admin
        const adminNavMobile = document.getElementById('mobile-admin-nav');
        if (adminNavMobile) {
            const canAccessAdmin = State.currentUser && [
                'admin', 'moderator', 'translator_chief', 'translator', 'editor', 'uploader', 'social_mod', 'support_staff'
            ].includes(State.currentUser.role);
            adminNavMobile.style.display = canAccessAdmin ? '' : 'none';
        }

        // 8. Render Team Section
        this.renderTeamSection();
    },

    renderTeamSection() {
        const container = document.getElementById('home-team-grid');
        const section = document.getElementById('team-section');
        if (!container || !section) return;

        const admins = (State.data.users || []).filter(u => 
            u.role === 'admin' || 
            (u.badges || []).includes('Yönetici') || 
            (u.badges || []).includes('Kurucu') || 
            (u.badges || []).includes('Admin')
        );

        if (admins.length > 0) {
            section.style.display = 'block';
            container.innerHTML = admins.map(admin => {
                const avatar = admin.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(admin.username)}&background=8b5cf6&color=fff&size=200`;
                const badges = (admin.badges || []).filter(b => ['Yönetici', 'Kurucu', 'Admin', 'Moderatör'].includes(b));
                const role = badges[0] || (admin.role === 'admin' ? 'Yönetici' : 'Ekip Üyesi');
                const isOnline = admin.isOnline || false;
                
                return `
                    <div class="premium-staff-card" onclick="App.router('profile', '${admin.id}')">
                        <div class="staff-avatar-wrap">
                            <img src="${avatar}" class="staff-avatar" alt="${admin.username}" onerror="this.src='assets/logo.png'">
                            <div class="staff-status ${isOnline ? 'online' : 'offline'}"></div>
                        </div>
                        <div class="staff-info">
                            <h3 class="staff-name">${admin.username}</h3>
                            <div class="staff-role">${role.toUpperCase()}</div>
                        </div>
                    </div>
                `;
            }).join('');
        } else {
            section.style.display = 'none';
        }
    },

    // Filter Latest Releases by content type
    filterLatestReleases(type, btn) {
        // Update button states
        document.querySelectorAll('.latest-filter-btn').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');

        // Special handling for 'upcoming' — show Yakında series as poster cards
        if (type === 'upcoming') {
            const container = document.getElementById('latest-releases-carousel');
            if (!container) return;

            const upcoming = (State.data.series || []).concat(State.data.webtoons || []).filter(s => s.status === 'Yakında' && !s.isHidden);
            upcoming.sort((a, b) => {
                if (a.releaseDate && b.releaseDate) return a.releaseDate.localeCompare(b.releaseDate);
                if (a.releaseDate) return -1;
                if (b.releaseDate) return 1;
                return 0;
            });

            if (upcoming.length === 0) {
                container.innerHTML = '<p style="color: var(--text-secondary); padding: 40px; text-align: center;">Yakında gelecek içerik bulunmuyor.</p>';
                return;
            }

            container.style.display = 'flex';
            container.style.gap = '20px';
            container.style.overflowX = 'auto';
            container.style.paddingBottom = '20px';

            container.innerHTML = upcoming.map(s => {
                const img = s.poster || s.coverImage || 'assets/logo.png';
                const typeLabel = s.type === 'webtoon' ? 'Webtoon' : s.type === 'anime' ? 'Anime' : s.type === 'short' ? 'Kısa Dizi' : 'Dizi';
                const releaseText = s.releaseDate ? new Date(s.releaseDate).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : 'Tarih Belirsiz';
                return `
                    <div class="premium-coming-soon-card" onclick="App.router('detail', '${s.id}')">
                        <img src="${img}" class="premium-coming-soon-img" loading="lazy">
                        <div class="premium-coming-soon-badge">🕐 Yakında</div>
                        <div class="premium-coming-soon-overlay">
                            <span class="premium-coming-soon-date">${releaseText}</span>
                            <h3 class="premium-coming-soon-title">${s.title}</h3>
                        </div>
                    </div>
                `;
            }).join('');
            return;
        }

        if (window.LatestReleases && LatestReleases.init) {
            LatestReleases.init(type);
        }
    },

    renderPopularActors() {
        const container = document.getElementById('popular-actors');
        if (!container) return;

        let actors = [];
        if (State.data && State.data.actors && State.data.actors.length > 0) {
            actors = State.data.actors;
        } else if (State.data && State.data.series) {
            const actorMap = new Map();
            State.data.series.forEach(series => {
                const cast = series.characters || series.cast || [];
                cast.forEach(c => {
                    const name = c.actor || c.name;
                    if (name && !actorMap.has(name)) {
                        actorMap.set(name, {
                            id: name,
                            name: name,
                            image: c.image || c.avatar || '',
                            avatar: c.avatar || c.image || '',
                            role: c.role
                        });
                    }
                });
            });
            actors = Array.from(actorMap.values());
        }

        if (actors.length === 0) {
            container.innerHTML = '<p style="color:var(--text-secondary)">Oyuncu bulunamadı.</p>';
            return;
        }

        const popularActors = actors.slice(0, 15);
        container.innerHTML = popularActors.map(actor => {
            const img = actor.image || actor.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(actor.name)}&background=8b5cf6&color=fff&size=200`;
            const escapedName = actor.name.replace(/'/g, "\\'");
            const fanCount = actor.fanCount || (actor.fanCenter ? actor.fanCenter.members.length : 0) || 0;
            const fanBadge = fanCount > 0 ? `<div class="fan-badge"><i class="fa-solid fa-heart"></i> ${fanCount}</div>` : '';
            
            return `
                <div class="actor-card-modern" onclick="App.router('actor-detail', '${escapedName}')">
                    <div class="actor-image-wrapper">
                        <img src="${img}" class="actor-image" alt="${actor.name}" onerror="this.src='https://ui-avatars.com/api/?name=${encodeURIComponent(actor.name)}&background=8b5cf6&color=fff&size=200'">
                        ${fanBadge}
                    </div>
                    <div class="actor-info">
                        <div class="actor-name">${actor.name}</div>
                        <div class="actor-role">${actor.role || 'Oyuncu'}</div>
                    </div>
                </div>
            `;
        }).join('');
    },

    showAllActors() {
        this.router('actors');
    },

    renderActorsPage(searchQuery = '') {
        const grid = document.getElementById('actors-grid') || document.getElementById('actors-page-grid');
        const badge = document.getElementById('actors-count-badge');
        if (!grid) return;

        // Show view
        App.showView('actors-view');

        // Gather actors from State data
        let actors = [];
        if (State.data && State.data.actors && State.data.actors.length > 0) {
            actors = State.data.actors;
        } else if (State.data && State.data.series) {
            const actorMap = new Map();
            State.data.series.forEach(series => {
                const cast = series.cast || series.characters || [];
                cast.forEach(c => {
                    const name = c.actor || c.name;
                    if (name && !actorMap.has(name)) {
                        actorMap.set(name, {
                            id: name,
                            name: name,
                            avatar: c.image || 'assets/default-avatar.png',
                            country: series.country || 'Güney Kore'
                        });
                    }
                });
            });
            actors = Array.from(actorMap.values());
        }
        
        if (searchQuery) {
            actors = actors.filter(a => a.name.toLowerCase().includes(searchQuery.toLowerCase()));
        }

        if (badge) {
            badge.textContent = actors.length + ' oyuncu';
        }

        if (actors.length === 0) {
            grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1; text-align:center; padding:100px; color:#64748b; font-weight:700;">Henüz oyuncu verisi bulunmuyor.</div>';
            return;
        }

        // Add premium styling
        const styleId = 'actors-page-premium-styles';
        if (!document.getElementById(styleId)) {
            const style = document.createElement('style');
            style.id = styleId;
            style.textContent = `
                #actors-page-grid {
                    display: grid !important;
                    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)) !important;
                    gap: 30px !important;
                    margin-top: 30px;
                }
                .actor-card-premium {
                    background: rgba(255, 255, 255, 0.02) !important;
                    border: 1px solid rgba(255, 255, 255, 0.06) !important;
                    border-radius: 24px !important;
                    overflow: hidden !important;
                    cursor: pointer !important;
                    transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) !important;
                    position: relative !important;
                    backdrop-filter: blur(10px) !important;
                    -webkit-backdrop-filter: blur(10px) !important;
                    display: flex !important;
                    flex-direction: column !important;
                }
                .actor-card-premium:hover {
                    transform: translateY(-8px) scale(1.02) !important;
                    border-color: rgba(167, 139, 250, 0.4) !important;
                    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6), 0 0 30px rgba(167, 139, 250, 0.15) !important;
                }
                .actor-card-image {
                    width: 100% !important;
                    aspect-ratio: 1/1 !important;
                    position: relative !important;
                    overflow: hidden !important;
                    background: rgba(0,0,0,0.2) !important;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.05) !important;
                }
                .actor-card-image img {
                    width: 100% !important;
                    height: 100% !important;
                    object-fit: cover !important;
                    transition: transform 0.5s ease !important;
                }
                .actor-card-premium:hover .actor-card-image img {
                    transform: scale(1.08) !important;
                }
                .actor-card-overlay {
                    position: absolute !important;
                    inset: 0 !important;
                    background: linear-gradient(to top, rgba(10, 10, 15, 0.9) 0%, rgba(10, 10, 15, 0.2) 60%, transparent 100%) !important;
                    opacity: 0 !important;
                    display: flex !important;
                    align-items: flex-end !important;
                    justify-content: center !important;
                    padding-bottom: 20px !important;
                    transition: opacity 0.3s ease !important;
                }
                .actor-card-premium:hover .actor-card-overlay {
                    opacity: 1 !important;
                }
                .actor-card-overlay .view-btn {
                    background: linear-gradient(135deg, #7c3aed, #db2777) !important;
                    color: #fff !important;
                    padding: 8px 20px !important;
                    border-radius: 50px !important;
                    font-size: 0.8rem !important;
                    font-weight: 800 !important;
                    box-shadow: 0 4px 15px rgba(124, 58, 237, 0.4) !important;
                    letter-spacing: 0.5px;
                }
                .actor-card-info {
                    padding: 20px !important;
                    text-align: center !important;
                    background: rgba(10, 10, 15, 0.3) !important;
                }
                .actor-card-info h3 {
                    margin: 0 0 6px !important;
                    font-size: 1.1rem !important;
                    font-weight: 800 !important;
                    color: #fff !important;
                    white-space: nowrap !important;
                    overflow: hidden !important;
                    text-overflow: ellipsis !important;
                }
                .actor-card-info p {
                    margin: 0 !important;
                    font-size: 0.8rem !important;
                    color: #a78bfa !important;
                    font-weight: 700 !important;
                    text-transform: uppercase !important;
                    letter-spacing: 0.5px;
                }
            `;
            document.head.appendChild(style);
        }

        grid.innerHTML = actors.map(actor => {
            const avatar = actor.avatar || actor.image || 'assets/default-avatar.png';
            return `
                <div class="actor-card-premium" onclick="App.router('actor-detail', '${encodeURIComponent(actor.id || actor.name)}')">
                    <div class="actor-card-image">
                        <img src="${avatar}" alt="${actor.name}" onerror="this.src='assets/default-avatar.png'">
                        <div class="actor-card-overlay">
                            <span class="view-btn">Profili Gör</span>
                        </div>
                    </div>
                    <div class="actor-card-info">
                        <h3>${actor.name}</h3>
                        <p>${actor.country || 'Bilinmiyor'}</p>
                    </div>
                </div>
            `;
        }).join('');
    },

    filterAllActors(query) {
        this.renderActorsPage(query);
    },

    showActorDetail(id) {
        // Placeholder for actor detail logic
        // Could open a modal or route to a page
        console.log("Show actor detail:", id);
    },

    renderFanCentersPage() {
        const grid = document.getElementById('actors-page-grid');
        const badge = document.getElementById('actors-count-badge');
        if (!grid) return;

        // Show view
        App.showView('actors-view');
        
        // Update title for Fan Centers
        const titleNode = document.querySelector('#actors-view h2');
        if (titleNode) titleNode.innerHTML = '💖 Fan Merkezleri';

        // Gather actors with fan clubs
        let actors = [];
        if (State.data && State.data.actors) {
            actors = State.data.actors.filter(a => a.hasFanClub || a.fanCount > 0);
        }

        // Sort by fan count
        actors.sort((a, b) => (b.fanCount || 0) - (a.fanCount || 0));

        // Update count badge
        if (badge) badge.textContent = actors.length + ' aktif topluluk';

        if (actors.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px;">
                    <i class="fa-solid fa-heart-crack" style="font-size: 3rem; color: #475569; margin-bottom: 15px; display: block;"></i>
                    <p style="color: #64748b; font-size: 1.1rem;">Henüz aktif bir fan merkezi bulunmuyor.</p>
                </div>`;
            return;
        }

        grid.innerHTML = actors.map(actor => {
            const img = actor.image || actor.avatar || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(actor.name) + '&background=8b5cf6&color=fff&size=200';
            const escapedName = actor.name.replace(/'/g, "\\'");
            const fanCount = actor.fanCount || 0;
            
            return `
                <div class="actor-card-modern fan-center-card" onclick="App.router('actor-detail', '${escapedName}')">
                    <div class="actor-image-wrapper">
                        <img src="${img}" class="actor-image" alt="${actor.name}" loading="lazy">
                        <div class="fan-badge"><i class="fa-solid fa-heart"></i> ${fanCount}</div>
                    </div>
                    <div class="actor-info">
                        <div class="actor-name">${actor.name}</div>
                        <div class="actor-role">FAN MERKEZİ</div>
                    </div>
                </div>`;
        }).join('');
    },
    
    async renderLiveView() {
        const view = document.getElementById('live-view');
        if (!view) return;

        this.showView('live-view');

        view.innerHTML = `
            <div class="live-center-container container">
                <div class="live-center-layout">
                    <div class="live-main-area">
                        <div class="live-center-hero glass-panel">
                            <div class="live-hero-content">
                                <h1>Canlı Yayın Merkezi</h1>
                                <p>DramicBox topluluğunun canlı çeviri ve sohbet odalarını keşfedin.</p>
                                ${(State.currentUser?.can_stream || State.currentUser?.role === 'admin' || State.currentUser?.role === 'moderator') ? `
                                    <button onclick="App.router('live', 'studio')" class="btn btn-primary" style="background:#ef4444; border:none; padding:15px 30px; border-radius:12px; font-weight:800; font-size:1.1rem; box-shadow:0 10px 20px rgba(239,68,68,0.3);">
                                        <i class="fa-solid fa-tower-broadcast animate-pulse"></i> YAYIN BAŞLAT
                                    </button>
                                ` : ''}
                            </div>
                        </div>

                        <div class="live-streams-grid" id="live-streams-list">
                            <div class="loading-state" style="grid-column: 1/-1; text-align:center; padding:50px;">
                                <i class="fa-solid fa-circle-notch fa-spin" style="font-size:2rem; color:#ef4444;"></i>
                                <p style="margin-top:15px; color:#64748b;">Yayınlar yükleniyor...</p>
                            </div>
                        </div>
                    </div>

                    <div class="live-sidebar-area">
                        <div class="live-leaderboard glass-panel">
                            <h3><i class="fa-solid fa-trophy" style="color:gold;"></i> Top Yayıncılar</h3>
                            <div id="live-leaderboard-list">
                                <div style="text-align:center; padding:20px; color:#64748b;">Yükleniyor...</div>
                            </div>
                        </div>
                        
                        <div class="live-stats-mini glass-panel" style="margin-top:20px;">
                            <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                                <span style="color:#94a3b8;">Aktif Yayın</span>
                                <span id="total-live-count" style="font-weight:800; color:#ef4444;">0</span>
                            </div>
                            <div style="display:flex; justify-content:space-between;">
                                <span style="color:#94a3b8;">Toplam İzleyici</span>
                                <span id="total-viewer-count" style="font-weight:800; color:#fff;">0</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Fetch active streams
        try {
            const res = await fetch('api/db.php?action=live-action&live_action=get-active-streams');
            const data = await res.json();
            
            const listContainer = document.getElementById('live-streams-list');
            const leaderboardContainer = document.getElementById('live-leaderboard-list');
            const totalLiveCount = document.getElementById('total-live-count');
            const totalViewerCount = document.getElementById('total-viewer-count');

            if (data.success && data.streams.length > 0) {
                listContainer.innerHTML = data.streams.map(s => `
                    <div class="live-card-modern glass-panel" onclick="App.router('live', '${s.id}')">
                        <div class="live-card-thumbnail">
                            <div class="live-tag">LIVE</div>
                            <div class="viewer-tag"><i class="fa-solid fa-eye"></i> ${s.viewerCount || 0}</div>
                            <img src="${s.thumbnail || 'assets/logo.png'}">
                            <div class="play-overlay"><i class="fa-solid fa-play"></i></div>
                        </div>
                        <div class="live-card-body">
                            <h3>${s.title}</h3>
                            <div class="broadcaster-meta">
                                <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(s.broadcasterName)}&background=ef4444&color=fff">
                                <span>${s.broadcasterName}</span>
                            </div>
                        </div>
                    </div>
                `).join('');

                // Update Stats
                totalLiveCount.textContent = data.streams.length;
                totalViewerCount.textContent = data.streams.reduce((sum, s) => sum + (s.viewerCount || 0), 0);

                // Populate Leaderboard (Top 5 by viewer count for now, or use a separate API)
                const sorted = [...data.streams].sort((a, b) => (b.viewerCount || 0) - (a.viewerCount || 0));
                leaderboardContainer.innerHTML = sorted.slice(0, 5).map((s, idx) => `
                    <div class="leaderboard-item" onclick="App.router('live', '${s.id}')">
                        <div class="rank">#${idx + 1}</div>
                        <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(s.broadcasterName)}&background=ef4444&color=fff">
                        <div class="name">${s.broadcasterName}</div>
                        <div class="viewers"><i class="fa-solid fa-eye"></i> ${s.viewerCount || 0}</div>
                    </div>
                `).join('');

            } else {
                listContainer.innerHTML = `
                    <div class="empty-state" style="grid-column: 1/-1; padding: 100px 20px; text-align:center;">
                        <div class="empty-icon-wrapper" style="width:100px; height:100px; background:rgba(255,255,255,0.03); border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 30px;">
                            <i class="fa-solid fa-video-slash" style="font-size:3rem; color:#334155;"></i>
                        </div>
                        <h3 style="color:#94a3b8; font-size:1.5rem; font-weight:800;">Şu an aktif yayın yok</h3>
                        <p style="color:#64748b; margin-top:10px;">Daha sonra tekrar kontrol edin veya kendi yayınınızı başlatın!</p>
                    </div>
                `;
                leaderboardContainer.innerHTML = '<div style="text-align:center; padding:20px; color:#475569; font-size:0.8rem;">Aktif yayıncı bulunamadı.</div>';
            }
        } catch (e) {
            console.error("Live streams error:", e);
        }
    },

    // Calendar system moved to CalendarPage.js
    async renderCalendar(filterType = 'all') {
        if (window.CalendarPage) CalendarPage.init(filterType);
    },





    getSeriesForDay(dayName) {
        if (!State.data || !State.data.series) return [];
        return State.data.series.filter(s => {
            // Support both broadcastDays (array) and broadcastDay (string)
            if (Array.isArray(s.broadcastDays)) {
                return s.broadcastDays.includes(dayName);
            }
            return s.broadcastDay === dayName;
        });
    },

    createStandardPosterCard(item) {
        return StandardCard.render(item);
    },

    // [Duplicate renderProfile removed. See line 1832+]
    // [Duplicate renderBrowse removed. See line 1605+ for the active logic]

    showBrowseSuggestions(query) {
        let container = document.getElementById('browse-search-suggestions');
        if (!container) {
            // Create container if not exists
            container = document.createElement('div');
            container.id = 'browse-search-suggestions';
            container.style.cssText = `
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: var(--bg-card);
                border: 1px solid var(--border-color);
                border-radius: 0 0 8px 8px;
                z-index: 100;
                max-height: 300px;
                overflow-y: auto;
                display: none;
                box-shadow: 0 4px 6px rgba(0,0,0,0.3);
            `;
            const wrapper = document.getElementById('browse-search-input').parentNode;
            if (getComputedStyle(wrapper).position === 'static') {
                wrapper.style.position = 'relative';
            }
            wrapper.appendChild(container);
        }

        if (!query || query.length < 2) {
            container.style.display = 'none';
            return;
        }

        const type = State.browseType || 'drama';
        const allItems = db.getAllSeries(type);
        const matches = allItems.filter(s => s.title.toLowerCase().includes(query.toLowerCase())).slice(0, 5);

        if (matches.length === 0) {
            container.style.display = 'none';
            return;
        }

        container.innerHTML = matches.map(s => `
            <div onclick="App.router('detail', '${s.id}');" style="
                display: flex;
                gap: 10px;
                padding: 10px;
                cursor: pointer;
                border-bottom: 1px solid var(--border-color);
                transition: background 0.2s;
            " onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseout="this.style.background='transparent'">
                <img src="${s.poster || s.coverImage}" style="width: 40px; height: 60px; object-fit: cover; border-radius: 4px;">
                <div>
                    <div style="font-weight: 600; font-size: 0.95rem;">${s.title}</div>
                    <div style="font-size: 0.8rem; color: var(--text-secondary);">${s.year} • ${s.type === 'webtoon' ? 'Webtoon' : 'Dizi'}</div>
                </div>
            </div>
        `).join('');
        container.style.display = 'block';
    },

    populateFilters(type = 'drama') {
        // Collect all unique genres and years for the specific TYPE
        const years = new Set();
        const genres = new Set();

        const items = db.getAllSeries(type); // Get only relevant items

        items.forEach(s => {
            if (s.year) years.add(s.year);
            const genreList = s.genres || s.genre;
            if (genreList) {
                // Handle both array and string genres
                if (Array.isArray(genreList)) {
                    genreList.forEach(g => genres.add(g.trim()));
                } else if (typeof genreList === 'string') {
                    // Split comma separated strings if necessary
                    genreList.split(',').forEach(g => genres.add(g.trim()));
                }
            }
        });

        const yearSelect = document.getElementById('filter-year');
        const genreSelect = document.getElementById('filter-genre');
        const statusSelect = document.getElementById('filter-status');

        if (!yearSelect || !genreSelect) return;

        // Preserve current selection if any
        const currentYear = yearSelect.value;
        const currentGenre = genreSelect.value;

        // Populate Years
        let yearHtml = '<option value="">Tümü</option>';
        Array.from(years).sort((a, b) => b - a).forEach(y => {
            yearHtml += `<option value="${y}">${y}</option>`;
        });
        yearSelect.innerHTML = yearHtml;
        yearSelect.value = currentYear;

        // Populate Genres
        let genreHtml = '<option value="">Tümü</option>';
        Array.from(genres).sort().forEach(g => {
            if (g) genreHtml += `<option value="${g}">${g}</option>`;
        });
        genreSelect.innerHTML = genreHtml;
        genreSelect.value = currentGenre;

        if (statusSelect && !statusSelect.querySelector('option[value=""]')) {
            statusSelect.innerHTML = '<option value="">Tümü</option>' + statusSelect.innerHTML;
        }

        // NEW: Populate Country
        const countrySelect = document.getElementById('filter-country');
        if (countrySelect) {
            const countries = new Set();
            items.forEach(s => {
                if (s.country) countries.add(s.country);
            });

            let cHtml = '<option value="">Tümü</option>';
            Array.from(countries).sort().forEach(c => {
                cHtml += `<option value="${c}">${c}</option>`;
            });
            countrySelect.innerHTML = cHtml;
            countrySelect.value = ''; // Reset on repopulate? Or preserve? Let's reset for now to be safe on tab switch
        }
    },

    applyFilters() {
        const type = State.browseType || 'drama';
        const genreFilter = document.getElementById('filter-genre').value;
        const yearFilter = document.getElementById('filter-year').value;
        const statusFilter = document.getElementById('filter-status').value;
        const countryFilter = document.getElementById('filter-country') ? document.getElementById('filter-country').value : '';
        // Search Input Handling
        const searchInput = document.getElementById('browse-search-input');
        const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

        // Use State data directly
        const allItems = State.data.series || [];
        let items = allItems.filter(item => {
            if (type === 'webtoon') return item.type === 'webtoon';
            return item.type !== 'webtoon'; // Default to drama/movie
        });

        if (query) {
            items = items.filter(s => s.title.toLowerCase().includes(query));
        }
        if (genreFilter) {
            items = items.filter(s => s.genre && (Array.isArray(s.genre) ? s.genre.includes(genreFilter) : s.genre.includes(genreFilter)));
        }
        if (yearFilter) {
            items = items.filter(s => s.year == yearFilter);
        }
        if (statusFilter) {
            items = items.filter(s => s.status === statusFilter);
        }
        if (countryFilter) {
            items = items.filter(s => s.country === countryFilter);
        }

        const grid = document.getElementById('browse-grid');
        if (grid) {
            grid.innerHTML = this.buildGrid(items);
        }
    },


    renderProfile(userId = null) {
        // Modern Profile System
        if (window.UserProfile && window.UserProfile.show) {
            UserProfile.show(userId);
            return;
        }

        // Fallback or Error
        console.error("UserProfile module not found!");
        // ... (keep fallback minimal or redirect home)
        if (!State.currentUser || State.currentUser.role === 'guest') {
            if (typeof Toast !== 'undefined') Toast.error("Bu sayfayı görmek için giriş yapmalısınız.");
            this.router('home');
            return;
        }
    },

    showAllAchievements() {
        // Remove existing if any
        const existing = document.querySelector('.achievement-modal');
        if (existing) existing.remove();

        const modal = document.createElement('div');
        modal.className = 'modal achievement-modal';
        modal.style.display = 'flex';

        // Use Real Achievements from Gamification Module
        const allAchievements = Gamification.achievements || [];
        const userAchievements = State.currentUser.achievements || [];
        const userShowcase = State.currentUser.showcase || [];

        // Mark unlocked status & sort (Unlocked first, then by XP)
        const displayList = allAchievements.map(a => ({
            ...a,
            unlocked: userAchievements.find(ua => ua.id === a.id) ? true : false,
            isShowcased: userShowcase.includes(a.id)
        })).sort((a, b) => {
            if (a.unlocked && !b.unlocked) return -1;
            if (!a.unlocked && b.unlocked) return 1;
            return b.xp - a.xp;
        });

        modal.innerHTML = `
                <div class="modal-content" style="max-width: 900px; max-height: 90vh; background: var(--bg-card); border-radius: 16px; overflow: hidden; display: flex; flex-direction: column;">
                    <div class="modal-header" style="background: var(--bg-secondary); padding: 20px; border-bottom: 1px solid var(--border-color);">
                        <h2 style="font-size: 1.5rem;">🏆 Başarımlar ve Ödüller</h2>
                        <button class="modal-close" onclick="this.closest('.modal').remove()" style="font-size: 1.5rem;">×</button>
                    </div>
                    
                    <div class="modal-subheader" style="padding: 15px 20px; background: rgba(124, 58, 237, 0.1); border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 0.9rem; color: var(--text-primary); font-weight: 500;">
                            <i class="fa-solid fa-star" style="color: #fbbf24; margin-right: 5px;"></i>
                            Vitrinde Gösterilen: <span id="showcase-count" style="font-weight: bold; color: var(--accent-color);">${userShowcase.length}</span>/5
                        </span>
                        <div style="font-size: 0.8rem; color: var(--text-secondary);">
                            Kazanılan: <span style="color: var(--success-color); font-weight: bold;">${userAchievements.length}</span> / ${allAchievements.length}
                        </div>
                    </div>

                    <div class="achievement-modal-body custom-scrollbar">
                         <div class="achievements-grid-modern">
                            ${displayList.map(a => `
                                <div id="ach-card-${a.id}" 
                                     class="achievement-card-modern ${a.unlocked ? 'unlocked' : 'locked'} ${a.isShowcased ? 'selected' : ''}" 
                                     onclick="${a.unlocked ? `App.toggleAchievementShowcase('${a.id}')` : ''}"
                                     title="${a.unlocked ? 'Vitrine eklemek için tıkla' : 'Bu başarı henüz kilitli'}">
                                    
                                    <div class="achievement-xp-badge">+${a.xp} XP</div>
                                    
                                    <div class="achievement-icon-modern">
                                        ${App.getIconForAchievement(a.icon)}
                                    </div>
                                    
                                    <div class="achievement-title-modern">${a.title}</div>
                                    <div class="achievement-desc-modern">${a.desc}</div>

                                    ${!a.unlocked ? '<div style="margin-top:5px; font-size:0.75rem; color:var(--text-secondary);"><i class="fa-solid fa-lock"></i> Kilitli</div>' : ''}
                                </div>
                            `).join('')}
                         </div>
                    </div>
                </div>
            `;
        document.body.appendChild(modal);
    },

    getIconForAchievement(faIconClass) {
        // Map FA classes or emoji strings
        if (faIconClass.startsWith('fa-')) return `<i class="fa-solid ${faIconClass}"></i>`;
        return faIconClass; // Return as is if emoji or other
    },

    // ... editProfileModal ...

    // --- Friend System --- (Skipping lines logic)

    // --- Achievement Showcase System ---
    toggleAchievementShowcase(id) {
        const card = document.getElementById(`ach-card-${id}`);
        if (!State.currentUser.showcase) State.currentUser.showcase = [];

        // Check if already selected
        const isSelected = State.currentUser.showcase.includes(id);

        if (isSelected) {
            // Remove
            State.currentUser.showcase = State.currentUser.showcase.filter(sid => sid !== id);
            if (card) card.classList.remove('selected');
        } else {
            // Add (Limit 5)
            if (State.currentUser.showcase.length >= 5) {
                Toast.warning('En fazla 5 başarım seçebilirsiniz!', 2000);
                // Shake animation for feedback if possible, or just return
                if (card) {
                    card.style.transform = 'translateX(5px)';
                    setTimeout(() => card.style.transform = '', 100);
                }
                return;
            }
            State.currentUser.showcase.push(id);
            if (card) card.classList.add('selected');
        }

        // Update Counter in UI
        const countSpan = document.getElementById('showcase-count');
        if (countSpan) countSpan.textContent = State.currentUser.showcase.length;

        // Save
        db.updateUser(State.currentUser.id, { showcase: State.currentUser.showcase });
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));

        // Refresh Profile (to show verified showcase) - Debounced slightly or immediate
        this.renderProfile();
    },

    showSettingsModal() {
        this.showEditProfileModal();
    },

    // Helper: Generate SEO-friendly slug from series title
    generateSlug(series) {
        if (!series || !series.title) return '';
        return series.title
            .toLowerCase()
            .replace(/[^a-z0-9\s-]/g, '') // Remove special chars
            .replace(/\s+/g, '-')          // Replace spaces with hyphens
            .replace(/-+/g, '-')           // Remove duplicate hyphens
            .trim();
    },


    renderDetail(seriesId, initialTab = 'episodes') {
        console.log('📺 App.renderDetail called with:', seriesId, initialTab);

        // --- DYNAMIC SEO META TAGS ---
        if (State.data && State.data.series) {
            const series = State.data.series.find(s => s.id === seriesId);
            if (series) {
                document.title = `${series.title} - DramicBox`;

                // Update Description
                const descMeta = document.querySelector('meta[name="description"]');
                if (descMeta) descMeta.setAttribute('content', `${series.title} izle.${series.description ? series.description.substring(0, 150) + '...' : ''} Türkçe altyazılı.`);

                // Update OG Tags
                const ogTitle = document.querySelector('meta[property="og:title"]');
                if (ogTitle) ogTitle.setAttribute('content', `${series.title} - DramicBox`);

                const ogDesc = document.querySelector('meta[property="og:description"]');
                if (ogDesc) ogDesc.setAttribute('content', `Hemen izle: ${series.title} `);

                const ogImage = document.querySelector('meta[property="og:image"]');
                if (ogImage && (series.poster || series.coverImage)) ogImage.setAttribute('content', series.poster || series.coverImage);
            }
        }

        // Delegate to DetailedView module
        if (typeof DetailedView !== 'undefined' && DetailedView.render) {
            DetailedView.render(seriesId, initialTab);
        } else {
            console.error('DetailedView module not loaded');
            Toast.error('Detay sayfası yüklenemedi');
        }
    },

    async checkGlobalAnnouncements() {
        // Fetch active announcements
        const res = await fetch('api/db.php?action=list-announcements&active=true');
        const anns = (await res.json()).data || [];
        
        const existing = document.getElementById('global-announcement-bar');
        if (existing) existing.remove();

        if (anns.length === 0) return;

        const latest = anns.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
        
        // Don't show if closed in this session
        if (sessionStorage.getItem(`ann_closed_${latest.id}`)) return;

        const bar = document.createElement('div');
        bar.id = 'global-announcement-bar';
        bar.className = `ann-bar ${latest.type || 'info'}`;
        bar.innerHTML = `
            <div class="ann-bar-content">
                <i class="fa-solid fa-bullhorn"></i>
                <span class="ann-text"><b>DUYURU:</b> ${latest.content}</span>
                <button onclick="App.closeAnnouncement('${latest.id}')" class="ann-close">&times;</button>
            </div>
            <style>
                #global-announcement-bar {
                    position: fixed;
                    top: 0; left: 0; width: 100%;
                    z-index: 9999;
                    background: linear-gradient(90deg, #8b5cf6, #ec4899);
                    color: white;
                    padding: 8px 15px;
                    font-size: 0.9rem;
                    text-align: center;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
                }
                .ann-bar-content { display: flex; align-items: center; justify-content: center; gap: 15px; max-width: 1200px; margin: 0 auto; }
                .ann-close { background: none; border: none; color: white; cursor: pointer; font-size: 1.2rem; font-weight: 700; opacity: 0.7; transition: 0.3s; }
                .ann-close:hover { opacity: 1; transform: scale(1.1); }
                .ann-bar.warning { background: linear-gradient(90deg, #f59e0b, #ef4444); }
                body { padding-top: 35px; } /* Push content down when bar is active */
            </style>
        `;
        document.body.appendChild(bar);
    },

    closeAnnouncement(id) {
        sessionStorage.setItem(`ann_closed_${id}`, 'true');
        const bar = document.getElementById('global-announcement-bar');
        if (bar) bar.remove();
        document.body.style.paddingTop = '0';
    },

    checkLiveStatus() {
        const liveLink = document.getElementById('nav-live-stream');
        if (!liveLink) return;
        
        if (State.data.activeLive) {
            liveLink.style.display = 'flex';
        } else {
            liveLink.style.display = 'none';
        }
    },

    async renderLiveView() {
        const view = document.getElementById('live-view');
        if (!view) return;
        
        if (!State.data.activeLive) {
            view.innerHTML = `
                <div class="container section" style="padding: 150px 20px; text-align: center;">
                    <div style="font-size: 5rem; margin-bottom: 20px; opacity: 0.2;">📡</div>
                    <h2 style="font-size: 2rem; color: #fff;">Şu an aktif bir yayın yok.</h2>
                    <p style="color: #64748b; margin-top: 10px;">Yeni yayınlar başladığında burada görünecek. Takipte kalın!</p>
                    <button onclick="App.router('home')" class="btn btn-primary" style="margin-top: 30px;">Anasayfaya Dön</button>
                </div>
            `;
            return;
        }

        const live = State.data.activeLive;
        const series = State.data.series.find(s => s.id === live.seriesId);
        
        view.innerHTML = `
            <div class="live-stream-layout" style="display: grid; grid-template-columns: 1fr 400px; height: calc(100vh - 100px); background: #050508;">
                <!-- Video & Subtitle Area -->
                <div style="display: flex; flex-direction: column; border-right: 1px solid rgba(255,255,255,0.05); position: relative;">
                    <div id="live-player-container" style="flex: 1; background: #000; display: flex; align-items: center; justify-content: center; position: relative;">
                        <div class="live-badge" style="position: absolute; top: 30px; left: 30px; background: #ef4444; color: #fff; padding: 5px 15px; border-radius: 8px; font-weight: 800; display: flex; align-items: center; gap: 8px; z-index: 100;">
                            <span class="live-pulse"></span> CANLI ÇEVİRİ
                        </div>
                        
                        <div style="text-align: center;">
                            <i class="fa-solid fa-play-circle" style="font-size: 5rem; color: rgba(255,255,255,0.1); margin-bottom: 20px;"></i>
                            <h3 style="color: rgba(255,255,255,0.4); font-size: 1.2rem;">${series?.title || 'Dizi'} - Bölüm ${live.epNum}</h3>
                            <p style="color: rgba(255,255,255,0.2);">Yayıncı çeviri stüdyosunda çalışıyor...</p>
                        </div>

                        <!-- Subtitle Overlay -->
                        <div id="live-subtitle-overlay" style="position: absolute; bottom: 15%; left: 0; right: 0; text-align: center; color: #fff; text-shadow: 0 2px 10px #000; font-size: 1.8rem; font-weight: 800; padding: 0 50px; pointer-events: none;">
                            <!-- Real-time subtitles here -->
                        </div>
                    </div>
                    
                    <div style="padding: 20px 40px; background: rgba(255,255,255,0.02); display: flex; align-items: center; gap: 20px;">
                        <img src="${series?.poster || 'assets/logo.png'}" style="width: 50px; height: 75px; border-radius: 8px; object-fit: cover;">
                        <div>
                            <h2 style="margin:0; color:#fff; font-size: 1.1rem;">${series?.title || 'Canlı Yayın'}</h2>
                            <p style="margin:5px 0 0; color:#8b5cf6; font-size:0.8rem; font-weight: 700;">${live.epNum}. Bölüm Canlı Çeviri Etkinliği</p>
                        </div>
                    </div>
                </div>

                <!-- Live Chat -->
                <div style="display: flex; flex-direction: column; background: #0a0a0f;">
                    <div style="padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center;">
                        <h3 style="margin: 0; font-size: 1rem; font-weight: 800; color: #fff;"><i class="fa-solid fa-comments" style="color: #8b5cf6; margin-right: 8px;"></i> YAYIN SOHBETİ</h3>
                        <div style="font-size: 0.75rem; color: #10b981; font-weight: 700;"><i class="fa-solid fa-circle"></i> 1,240 İzleyici</div>
                    </div>
                    
                    <div id="live-chat-box" style="flex: 1; overflow-y: auto; padding: 20px;" class="custom-scroll">
                        <div class="chat-msg" style="margin-bottom: 15px; display: flex; gap: 10px;">
                            <div style="width: 30px; height: 30px; border-radius: 50%; background: #7c3aed; display: flex; align-items: center; justify-content: center; font-size: 0.7rem; font-weight: 800; color: #fff;">S</div>
                            <div>
                                <span style="font-size: 0.75rem; color: #64748b; font-weight: 700;">Sistem:</span>
                                <p style="margin: 3px 0 0; color: #94a3b8; font-size: 0.85rem;">Canlı çeviri yayınına hoş geldiniz! Sohbet kurallarına uymayı unutmayın.</p>
                            </div>
                        </div>
                    </div>

                    <div style="padding: 20px; border-top: 1px solid rgba(255,255,255,0.05);">
                        ${State.currentUser && State.currentUser.role !== 'guest' ? `
                            <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; display: flex; align-items: center; padding: 5px 15px;">
                                <input type="text" id="live-chat-input" placeholder="Sohbete katıl..." style="flex: 1; background: none; border: none; color: #fff; padding: 10px; outline: none; font-size: 0.85rem;" onkeydown="if(event.key==='Enter') App.sendLiveChat()">
                                <button onclick="App.sendLiveChat()" style="background: none; border: none; color: #8b5cf6; cursor: pointer;"><i class="fa-solid fa-paper-plane"></i></button>
                            </div>
                        ` : `
                            <div style="text-align: center; padding: 10px; background: rgba(139, 92, 246, 0.1); border-radius: 10px; font-size: 0.8rem; color: #8b5cf6;">
                                Sohbet etmek için <a href="#" onclick="Auth.showLogin()" style="color: #fff; text-decoration: underline;">giriş yapmalısınız.</a>
                            </div>
                        `}
                    </div>
                </div>
            </div>
        `;

        // Real-time Listeners for Viewers
        const studioPath = `studio/${live.seriesId}/${live.epNum}`;
        const chatPath = `chats/live/${live.seriesId}_${live.epNum}`;

        // Listen for Subtitles
        SyncService.on(studioPath, (data) => {
            const overlay = document.getElementById('live-subtitle-overlay');
            if (overlay && data && data.subtitles) {
                const lastLine = data.subtitles[data.subtitles.length - 1];
                if (lastLine) {
                    overlay.innerText = lastLine.translation || lastLine.sourceText;
                }
            }
        });

        // Listen for Live Chat
        SyncService.on(chatPath, (data) => {
            const box = document.getElementById('live-chat-box');
            if (!box || !data) return;
            box.innerHTML = '';
            Object.values(data).forEach(m => {
                box.insertAdjacentHTML('beforeend', `
                    <div class="chat-msg" style="margin-bottom: 15px; display: flex; gap: 10px; animation: fadeIn 0.3s ease;">
                        <img src="${m.avatar || 'assets/logo.png'}" style="width: 30px; height: 30px; border-radius: 50%; border: 1px solid #8b5cf6;">
                        <div>
                            <span style="font-size: 0.75rem; color: #8b5cf6; font-weight: 800;">${m.username}</span>
                            <p style="margin: 3px 0 0; color: #fff; font-size: 0.85rem;">${m.text}</p>
                        </div>
                    </div>
                `);
            });
            box.scrollTop = box.scrollHeight;
        });
    },

    sendLiveChat() {
        const input = document.getElementById('live-chat-input');
        if (!input || !input.value.trim()) return;
        
        const live = State.data.activeLive;
        if (!live) return;

        const chatPath = `chats/live/${live.seriesId}_${live.epNum}`;
        const msg = {
            username: State.currentUser.username,
            avatar: State.currentUser.avatar,
            text: input.value.trim(),
            at: Date.now()
        };

        SyncService.push(`${chatPath}/${Date.now()}`, msg);
        input.value = '';
    },
};

// --- BLOG SYSTEM MODULE ---
// --- BLOG SYSTEM MODULE ---
// Removed - using js/features/premium-features.js instead
const _BlogSystem_Placeholder = {}; // Prevent any possible breakages from missing refs

const Carousel = {
    currentIndex: 0,
    itemsPerView: 5,

    render() {
        // Get latest and ongoing series (max 6)
        // Ensure visibility check
        const allSeries = db.getAllSeries()
            .filter(s => s.status === 'Devam Ediyor')
            .slice(0, 6);

        const track = document.getElementById('carousel-track');
        if (!track) return;

        track.innerHTML = allSeries.map(item => `
    <div class="media-card" onclick = "App.router('detail', '${item.id}')" >
                <div class="card-image-wrapper">
                    <img src="${item.coverImage}" class="card-image" loading="lazy">
                </div>
                <div class="card-content">
                    <h3 class="card-title">${item.title}</h3>
                    <div class="card-meta">
                        <span>${item.year}</span>
                        <span>${item.country || 'Kore'}</span>
                    </div>
                </div>
            </div>
    `).join('');
    },

    next() {
        const track = document.getElementById('carousel-track');
        if (!track) return;
        const totalItems = track.children.length;

        if (this.currentIndex < totalItems - this.itemsPerView) {
            this.currentIndex++;
            this.updatePosition();
        }
    },

    prev() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
            this.updatePosition();
        }
    },

    updatePosition() {
        const track = document.getElementById('carousel-track');
        if (!track) return;
        const offset = -this.currentIndex * 220;
        track.style.transform = `translateX(${offset}px)`;
    }
};

const WatchHistory = {
    trackWatch(seriesId, episodeId, timeElapsed) {
        if (!State.currentUser) return;

        if (!State.currentUser.watchHistory) State.currentUser.watchHistory = [];

        // Remove existing entry for same episode
        State.currentUser.watchHistory = State.currentUser.watchHistory.filter(h =>
            !(h.seriesId == seriesId && h.episodeId == episodeId)
        );

        // Add new entry
        const entry = {
            seriesId: seriesId,
            episodeId: episodeId, // Note: this might be episode index or ID depending on caller
            timestamp: Date.now(),
            timeElapsed: timeElapsed,
            date: new Date().toISOString()
        };

        State.currentUser.watchHistory.unshift(entry);

        // Keep last 100 entries
        if (State.currentUser.watchHistory.length > 100) {
            State.currentUser.watchHistory = State.currentUser.watchHistory.slice(0, 100);
        }

        // Save to backend properly
        // We use updateUser to persist this specific field
        db.updateUser(State.currentUser.id, { watchHistory: State.currentUser.watchHistory });
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
    },

    getLastWatch(seriesId) {
        if (!State.currentUser || !State.currentUser.watchHistory) return null;
        return State.currentUser.watchHistory.find(h => h.seriesId == seriesId);
    }
};
window.WatchHistory = WatchHistory; // Expose globally

// --- RATING MODULE ---
const Rating = {
    displayRating(series) {
        const ratings = series.ratings || [];
        const avgRating = ratings.length > 0
            ? (ratings.reduce((sum, r) => sum + r.score, 0) / ratings.length).toFixed(1)
            : 0;

        document.getElementById('series-rating').innerText = avgRating;
        document.getElementById('rating-count').innerText = `(${ratings.length} oy)`;

        // Display stars
        const stars = Math.round(avgRating / 2);
        document.getElementById('series-stars').innerText = '⭐'.repeat(stars) + '☆'.repeat(5 - stars);

        // Check if user already rated
        if (State.currentUser) {
            const userRating = ratings.find(r => r.userId === State.currentUser.id);
            if (userRating) {
                document.getElementById('user-rating').value = userRating.score;
            }
        }
    },

    submitRating() {
        if (!State.currentUser) {
            alert("⚠️ Puan vermek için giriş yapmalısınız!");
            document.getElementById('user-rating').value = '';
            return;
        }

        const score = parseInt(document.getElementById('user-rating').value);
        if (!score) return;

        const series = State.currentSeries;
        if (!series.ratings) series.ratings = [];

        // Remove old rating if exists
        series.ratings = series.ratings.filter(r => r.userId !== State.currentUser.id);

        // Add new rating
        series.ratings.push({
            userId: State.currentUser.id,
            username: State.currentUser.username,
            score: score,
            date: new Date().toLocaleDateString('tr-TR')
        });

        db.updateSeries(series.id, { ratings: series.ratings });
        this.displayRating(series);
        alert(`✅ ${score}/10 puanınız kaydedildi!`);
    }
};

// --- COMMENTS MODULE ---
const LegacyComments_Deprecated = {
    displayComments(series, containerId = 'comments-list') {
        const comments = series.comments || [];
        const container = document.getElementById(containerId);

        if (!container) {
            console.warn(`Comments container '${containerId}' not found`);
            return;
        }

        if (comments.length === 0) {
            container.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 20px;">Henüz yorum yapılmamış. İlk yorumu siz yapın!</p>';
            return;
        }

        container.innerHTML = comments.map((comment, index) => `
            <div class="comment-item">
                <div class="comment-header">
                    <div class="comment-author">
                        <img src="${comment.avatar || 'https://via.placeholder.com/40'}" class="comment-avatar" alt="${comment.username}">
                        <div>
                            <div class="comment-username">${comment.username}</div>
                            <div class="comment-date">${comment.date}</div>
                        </div>
                    </div>
                </div>
                <div class="comment-content ${comment.spoiler ? 'spoiler' : ''}" onclick="Comments.revealSpoiler(this)">
                    ${comment.text}
                </div>
                <div class="comment-actions-bar">
                    <button class="comment-action-btn ${comment.likes && comment.likes.includes(State.currentUser?.id) ? 'liked' : ''}" 
                            onclick="Comments.likeComment(${index})">
                        <i class="fa-solid fa-thumbs-up"></i>
                        <span>${comment.likes ? comment.likes.length : 0}</span>
                    </button>
                    <button class="comment-action-btn" onclick="Comments.replyComment(${index})">
                        <i class="fa-solid fa-reply"></i>
                        Yanıtla
                    </button>
                </div>
            </div>
        `).join('');
    },

    addComment(seriesId, text) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Yorum yapmak için giriş yapmalısınız!');
            return;
        }

        if (!text || text.trim() === '') {
            Toast.warning('Lütfen bir yorum yazın!');
            return;
        }

        const series = State.data.series.find(s => s.id === seriesId);
        if (!series) return;

        if (!series.comments) series.comments = [];

        // Check for spoiler checkbox
        const spoilerCheckbox = document.getElementById(`comment-spoiler-${seriesId}`);
        const isSpoiler = spoilerCheckbox ? spoilerCheckbox.checked : false;

        const newComment = {
            id: Date.now(),
            username: State.currentUser.username,
            avatar: State.currentUser.avatar || 'assets/logo.png',
            text: text.trim(),
            date: new Date().toLocaleDateString('tr-TR'),
            upvotes: 0,
            downvotes: 0,
            spoiler: isSpoiler,
            replies: []
        };

        series.comments.unshift(newComment);
        db.updateSeries(series.id, { comments: series.comments });

        Toast.success('Yorumunuz eklendi!');

        // Clear the textarea
        const textarea = document.getElementById(`comment-text-${seriesId}`);
        if (textarea) textarea.value = '';

        // Uncheck spoiler
        if (spoilerCheckbox) spoilerCheckbox.checked = false;

        // Refresh comments display
        this.displayComments(series, 'detail-comments-container');
    },

    revealSpoiler(element) {
        if (element.classList.contains('spoiler')) {
            element.classList.add('revealed');
        }
    },

    likeComment(index) {
        if (!State.currentUser) {
            alert("⚠️ Beğenmek için giriş yapmalısınız!");
            return;
        }

        const series = State.currentSeries;
        const comment = series.comments[index];

        if (!comment.likes) comment.likes = [];

        const likeIndex = comment.likes.indexOf(State.currentUser.id);
        if (likeIndex > -1) {
            comment.likes.splice(likeIndex, 1);
        } else {
            comment.likes.push(State.currentUser.id);
        }

        db.updateSeries(series.id, { comments: series.comments });
        this.displayComments(series);
    },

    replyComment(index) {
        alert("💬 Yanıtlama özelliği yakında eklenecek!");
    }
};

// --- THEME MODULE ---
const Theme = {
    toggleMobileMenu() {
        const overlay = document.getElementById('mobile-nav-overlay');
        if (overlay) {
            overlay.classList.toggle('active');
            document.body.style.overflow = overlay.classList.contains('active') ? 'hidden' : '';
        }
    },

    init() {
        const savedTheme = localStorage.getItem('dramicbox_theme') || 'dark';
        this.setTheme(savedTheme);
    },

    toggle() {
        const current = document.documentElement.getAttribute('data-theme') || 'dark';
        const newTheme = current === 'dark' ? 'light' : 'dark';
        this.setTheme(newTheme);
    },

    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('dramicbox_theme', theme);

        const icon = document.getElementById('theme-icon');
        if (icon) {
            icon.className = theme === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
        }
    }
};


// --- AUTH MODULE ---


// --- AUTH MODULE ---
// Duplicate Auth module removed - using public/auth.js instead
// The Auth object was removed from here.

// --- WATCHLIST MODULE ---
const Watchlist = {
    toggle() {
        if (!State.currentUser) {
            alert("Listeme eklemek için giriş yapmalısınız!");
            return;
        }

        if (!State.currentSeries) return;

        const watchlist = State.currentUser.watchlist || [];
        const seriesId = State.currentSeries.id;
        const index = watchlist.indexOf(seriesId);

        if (index > -1) {
            watchlist.splice(index, 1);
            alert(`${State.currentSeries.title} listenizden çıkarıldı.`);
        } else {
            watchlist.push(seriesId);
            alert(`${State.currentSeries.title} listenize eklendi!`);
        }

        db.updateUser(State.currentUser.id, { watchlist });
        State.currentUser.watchlist = watchlist;
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));

        this.updateButton();
    },

    updateButton() {
        const btn = document.getElementById('watchlist-btn');
        if (!btn) return;

        if (!State.currentUser) {
            btn.innerHTML = '<i class="fa-solid fa-plus"></i> Listeme Ekle';
            btn.classList.remove('in-watchlist');
            return;
        }

        const watchlist = State.currentUser.watchlist || [];
        const inList = watchlist.includes(State.currentSeries.id);

        if (inList) {
            btn.innerHTML = '<i class="fa-solid fa-check"></i> Listemde';
            btn.classList.add('in-watchlist');
        } else {
            btn.innerHTML = '<i class="fa-solid fa-plus"></i> Listeme Ekle';
            btn.classList.remove('in-watchlist');
        }
    }
};

// --- PLAYER MODULE ---
// Replaced by public/player.js


// --- ADMIN MODULE ---
const Admin = {
    render() {
        if (!State.currentUser) return;

        const role = State.currentUser.role;
        const badges = State.currentUser.badges || [];
        const isTranslator = role === 'translator' || badges.includes('Çevirmen');
        const isBlogger = role === 'blogger' || badges.includes('Blogger');
        const isAdmin = role === 'admin' || badges.includes('Yönetici') || badges.includes('Admin');

        if (!isAdmin && !isTranslator && !isBlogger) {
            alert("Yetkisiz Giriş!");
            App.router('home');
            return;
        }

        // Redirect to new Hub if available
        if (window.AdminPanelHub && typeof AdminPanelHub.showMainDashboard === 'function') {
            AdminPanelHub.showMainDashboard();
            return;
        }

        // Legacy rendering logic
        if (isTranslator && !isAdmin) {
            document.querySelector('button[onclick="Admin.switchTab(\'users\')"]').style.display = 'none';
            document.querySelector('button[onclick="Admin.switchTab(\'calendar\')"]').style.display = 'none';
            // Default to episodes tab
            this.switchTab('episodes');
        } else {
            this.renderContent();
            this.renderUsers();
        }
    },

    switchTab(tabName) {
        // Hide all
        document.querySelectorAll('.admin-panel').forEach(p => p.style.display = 'none');
        document.querySelectorAll('.admin-tabs button').forEach(b => b.classList.remove('active'));

        // Show selected
        const panel = document.getElementById(`admin-tab-${tabName}`);
        if (panel) panel.style.display = 'block';

        // Update button
        const btn = document.querySelector(`button[onclick="Admin.switchTab('${tabName}')"]`);
        if (btn) btn.classList.add('active');

        // Load data if needed
        if (tabName === 'content') this.renderContent();
        if (tabName === 'users') this.renderUsers();
        if (tabName === 'calendar') this.renderCalendarList();
        if (tabName === 'chat') this.renderChat();
        if (tabName === 'rules') this.renderRules();
        if (tabName === 'translators') this.renderContent(); // Populate series dropdown
    },

    renderContent() {
        const list = document.getElementById('admin-content-list');
        list.innerHTML = State.data.series.map(s => `
            <li>
                <span><strong>${s.title}</strong> (${s.type === 'drama' ? 'Dizi' : 'Webtoon'})</span>
                <button class="btn btn-sm btn-outline" onclick="Admin.editSeries('${s.id}')">Düzenle</button>
            </li>
        `).join('');

        // Populate series selects
        const episodeSelect = document.getElementById('episode-series-select');
        const characterSelect = document.getElementById('character-series-select');
        const translatorSelect = document.getElementById('translator-series-select');

        const options = '<option value="">Dizi seçin...</option>' +
            State.data.series.map(s => `<option value="${s.id}">${s.title}</option>`).join('');

        if (episodeSelect) episodeSelect.innerHTML = options;
        if (characterSelect) characterSelect.innerHTML = options;
        if (translatorSelect) translatorSelect.innerHTML = options;
    },

    // Temporary storage for sources being added
    tempSources: [],

    addSource() {
        const name = document.getElementById('source-name').value.trim();
        const url = document.getElementById('source-url').value.trim();

        if (!name || !url) {
            alert('❌ Kaynak adı ve URL gerekli!');
            return;
        }

        this.tempSources.push({ name, url });

        // Clear inputs
        document.getElementById('source-name').value = '';
        document.getElementById('source-url').value = '';

        // Update display
        this.renderTempSources();
    },

    renderTempSources() {
        const container = document.getElementById('episode-sources-container');
        if (this.tempSources.length === 0) {
            container.innerHTML = '<p style="color: var(--text-secondary); font-size: 0.9rem;">Henüz kaynak eklenmedi.</p>';
            return;
        }

        container.innerHTML = this.tempSources.map((source, index) => `
            <div style="display: flex; gap: 10px; align-items: center; padding: 8px; background: var(--card-bg); border-radius: 8px; margin-bottom: 8px;">
                <span style="flex: 1; color: var(--text-primary);"><strong>${source.name}</strong></span>
                <span style="flex: 2; color: var(--text-secondary); font-size: 0.85rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${source.url}</span>
                <button class="btn btn-sm btn-outline" onclick="Admin.removeSource(${index})" style="color: #ff4444;">Sil</button>
            </div>
        `).join('');
    },

    removeSource(index) {
        this.tempSources.splice(index, 1);
        this.renderTempSources();
    },

    loadEpisodes() {
        const seriesId = document.getElementById('episode-series-select').value;
        if (!seriesId) {
            document.getElementById('episode-management').style.display = 'none';
            return;
        }

        document.getElementById('episode-management').style.display = 'block';
        const series = db.getSeries(seriesId);
        State.currentSeries = series;

        // Clear temp sources when switching series
        this.tempSources = [];
        this.renderTempSources();

        const list = document.getElementById('episodes-list');
        if (!series.episodes || series.episodes.length === 0) {
            list.innerHTML = '<p style="color: var(--text-secondary);">Henüz bölüm eklenmemiş.</p>';
            return;
        }

        list.innerHTML = series.episodes.map((ep, index) => {
            const sourcesInfo = ep.sources && ep.sources.length > 0
                ? `<div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 5px;">📹 ${ep.sources.length} kaynak</div>`
                : '<div style="font-size: 0.85rem; color: #ff4444; margin-top: 5px;">⚠️ Kaynak yok</div>';

            return `
                <div class="episode-item">
                    <div class="episode-header">
                        <strong>Bölüm ${ep.number}</strong>
                        <button class="btn btn-sm btn-outline" onclick="Admin.deleteEpisode(${index})">Sil</button>
                    </div>
                    ${sourcesInfo}
                    <div class="progress-bar-container">
                        <div class="progress-bar-fill" style="width: ${ep.translationProgress || 0}%"></div>
                    </div>
                    <div class="progress-text">
                        Çeviri: ${ep.translationProgress || 0}% 
                        ${ep.translationProgress === 100 ? '✅' : ep.translationProgress > 0 ? '🔄 Devam Ediyor' : '⏳ Çok Yakında'}
                    </div>
                    <button class="btn btn-sm btn-primary" style="margin-top: 10px;" onclick="Admin.updateProgress(${index})">
                        İlerleme Güncelle
                    </button>
                </div>
            `;
        }).join('');
    },

    addEpisode() {
        const number = document.getElementById('episode-number').value;
        const progress = document.getElementById('episode-translation-progress').value;

        if (!number) {
            alert("❌ Bölüm numarası gerekli!");
            return;
        }

        if (this.tempSources.length === 0) {
            alert("❌ En az bir kaynak eklemelisiniz!");
            return;
        }

        const series = State.currentSeries;
        if (!series.episodes) series.episodes = [];

        series.episodes.push({
            number: parseInt(number),
            sources: [...this.tempSources], // Copy the sources array
            translationProgress: parseInt(progress) || 0
        });

        db.updateSeries(series.id, { episodes: series.episodes });

        // Clear form
        document.getElementById('episode-number').value = '';
        document.getElementById('episode-translation-progress').value = 0;
        document.getElementById('progress-value').innerText = '0%';
        this.tempSources = [];
        this.renderTempSources();

        alert(`✅ Bölüm ${number} eklendi!`);
        this.loadEpisodes();
    },

    updateProgress(index) {
        const newProgress = prompt("Yeni çeviri ilerlemesi (0-100):", "0");
        if (newProgress === null) return;

        const progress = parseInt(newProgress);
        if (isNaN(progress) || progress < 0 || progress > 100) {
            alert("❌ Geçerli bir sayı girin (0-100)!");
            return;
        }

        const series = State.currentSeries;
        series.episodes[index].translationProgress = progress;
        db.updateSeries(series.id, { episodes: series.episodes });

        alert(`✅ İlerleme %${progress} olarak güncellendi!`);
        this.loadEpisodes();
    },

    deleteEpisode(index) {
        if (!confirm("Bu bölümü silmek istediğinizden emin misiniz?")) return;

        const series = State.currentSeries;
        series.episodes.splice(index, 1);
        db.updateSeries(series.id, { episodes: series.episodes });

        alert("✅ Bölüm silindi!");
        this.loadEpisodes();
    },

    loadCharacters() {
        const seriesId = document.getElementById('character-series-select').value;
        if (!seriesId) {
            document.getElementById('character-management').style.display = 'none';
            return;
        }

        document.getElementById('character-management').style.display = 'block';
        const series = db.getSeries(seriesId);
        State.currentSeries = series;

        const grid = document.getElementById('characters-grid');
        if (!series.characters || series.characters.length === 0) {
            grid.innerHTML = '<p style="color: var(--text-secondary);">Henüz karakter eklenmemiş.</p>';
            return;
        }

        grid.innerHTML = series.characters.map((char, index) => `
            <div class="character-card">
                <img src="${char.image}" class="character-image" alt="${char.name}">
                <div class="character-info">
                    <div class="character-name">${char.name}</div>
                    <div class="character-actor">${char.actor}</div>
                    <span class="character-role">${char.role}</span>
                    <button class="btn btn-sm btn-outline" style="margin-top: 10px; width: 100%;" onclick="Admin.deleteCharacter(${index})">Sil</button>
                </div>
            </div>
            </div>
        `).join('');

        // --- INJECT ACTOR SELECTION ---
        this.injectActorSelector();
    },

    injectActorSelector() {
        let selectContainer = document.getElementById('admin-actor-select-container');
        if (!selectContainer) {
            // Find where to insert (before character name input)
            const nameInput = document.getElementById('character-name');
            if (nameInput && nameInput.closest('.form-group')) {
                const targetGroup = nameInput.closest('.form-group');

                selectContainer = document.createElement('div');
                selectContainer.id = 'admin-actor-select-container';
                selectContainer.className = 'form-group';
                selectContainer.style.marginBottom = '15px';
                selectContainer.style.background = 'rgba(255,255,255,0.05)';
                selectContainer.style.padding = '10px';
                selectContainer.style.borderRadius = '8px';

                selectContainer.innerHTML = `
                    <label style="color:#8b5cf6; font-weight:bold;">Mevcut Oyunculardan Seç (Opsiyonel)</label>
                    <select id="admin-actor-select" class="form-select" onchange="Admin.onActorSelect(this.value)">
                        <option value="">-- Yeni Oyuncu Ekle --</option>
                    </select>
                `;

                targetGroup.parentElement.insertBefore(selectContainer, targetGroup);
            }
        }

        // Populate Select
        const select = document.getElementById('admin-actor-select');
        if (select) {
            // Aggregate actors
            const actorMap = new Map();
            // From stored actors
            if (State.data.actors) State.data.actors.forEach(a => actorMap.set(a.name, a.image));
            // From series characters (fallback)
            State.data.series.forEach(s => {
                if (s.characters) s.characters.forEach(c => {
                    if (c.actor && !actorMap.has(c.actor)) actorMap.set(c.actor, c.image);
                });
            });

            const sortedActors = Array.from(actorMap.keys()).sort();

            // Store map for retrieval
            this.actorImageMap = actorMap;

            select.innerHTML = '<option value="">-- Yeni Oyuncu Ekle --</option>' +
                sortedActors.map(name => `<option value="${name}">${name}</option>`).join('');
        }
    },

    onActorSelect(name) {
        if (!name) {
            // Reset
            document.getElementById('character-actor').value = '';
            document.getElementById('character-image').value = '';
            return;
        }

        document.getElementById('character-actor').value = name;
        // Try to autofill image
        if (this.actorImageMap && this.actorImageMap.has(name)) {
            const img = this.actorImageMap.get(name);
            if (img) document.getElementById('character-image').value = img;
        }
    },

    addCharacter() {
        const name = document.getElementById('character-name').value;
        const actor = document.getElementById('character-actor').value;
        const image = document.getElementById('character-image').value;
        const role = document.getElementById('character-role').value;

        if (!name || !actor || !image) {
            alert("❌ Tüm alanları doldurun!");
            return;
        }

        const series = State.currentSeries;
        if (!series.characters) series.characters = [];

        series.characters.push({
            name: name,
            actor: actor,
            image: image,
            role: role
        });

        db.updateSeries(series.id, { characters: series.characters });

        document.getElementById('character-name').value = '';
        document.getElementById('character-actor').value = '';
        document.getElementById('character-image').value = '';

        alert(`✅ ${name} karakteri eklendi!`);
        this.loadCharacters();
    },

    deleteCharacter(index) {
        if (!confirm("Bu karakteri silmek istediğinizden emin misiniz?")) return;

        const series = State.currentSeries;
        series.characters.splice(index, 1);
        db.updateSeries(series.id, { characters: series.characters });

        alert("✅ Karakter silindi!");
        this.loadCharacters();
    },

    addNewSeries() {
        const title = document.getElementById('admin-series-title').value;
        const img = document.getElementById('admin-series-img').value;
        const type = document.getElementById('admin-series-type').value;
        const yearInput = document.getElementById('admin-series-year').value;
        const country = document.getElementById('admin-series-country').value;
        const status = document.getElementById('admin-series-status').value;
        const genre = document.getElementById('admin-series-genre').value;
        const tags = document.getElementById('admin-series-tags').value;
        const backdrop = document.getElementById('admin-series-backdrop').value;
        const desc = document.getElementById('admin-series-desc').value;

        if (!title || !img) {
            alert("❌ Başlık ve kapak resmi zorunludur!");
            return;
        }

        // Parse tags
        const tagArray = tags ? tags.split('#').filter(t => t.trim()).map(t => '#' + t.trim()) : [];

        const newSeries = {
            id: 'series-' + Date.now(),
            title: title,
            type: type,
            year: parseInt(yearInput) || new Date().getFullYear(),
            country: country || 'Güney Kore',
            status: status || 'Devam Ediyor',
            genre: genre || 'Tümü',
            tags: tagArray,
            description: desc || 'Açıklama eklenmedi.',
            coverImage: img,
            backdropImage: backdrop || img,
            episodes: []
        };

        db.addSeries(newSeries);
        alert(`✅ ${title} başarıyla eklendi!`);

        // Clear form
        document.getElementById('admin-series-title').value = '';
        document.getElementById('admin-series-img').value = '';
        document.getElementById('admin-series-backdrop').value = '';
        document.getElementById('admin-series-desc').value = '';
        document.getElementById('admin-series-tags').value = '';

        this.renderContent();
    },

    editSeries(seriesId) {
        const series = db.getSeries(seriesId);
        if (!series) return;

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2>✏️ İçerik Düzenle: ${series.title}</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Öne Çıkarılan (Senin İçin Öneriler)</label>
                        <select id="edit-is-recommended" class="form-select">
                            <option value="false" ${!series.isRecommended ? 'selected' : ''}>Hayır</option>
                            <option value="true" ${series.isRecommended ? 'selected' : ''}>Evet</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Trend Listesinde Göster</label>
                        <select id="edit-is-trending" class="form-select">
                            <option value="false" ${!series.isTrending ? 'selected' : ''}>Hayır</option>
                            <option value="true" ${series.isTrending ? 'selected' : ''}>Evet</option>
                        </select>
                    </div>
                     <div class="form-group">
                        <label>Durum</label>
                        <select id="edit-status" class="form-select">
                            <option value="Devam Ediyor" ${series.status === 'Devam Ediyor' ? 'selected' : ''}>Devam Ediyor</option>
                            <option value="Tamamlandı" ${series.status === 'Tamamlandı' ? 'selected' : ''}>Tamamlandı</option>
                        </select>
                    </div>
                    <button class="btn btn-primary btn-block" onclick="Admin.saveSeriesChanges('${seriesId}')">Kaydet</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    saveSeriesChanges(seriesId) {
        const isRecommended = document.getElementById('edit-is-recommended').value === 'true';
        const isTrending = document.getElementById('edit-is-trending').value === 'true';
        const status = document.getElementById('edit-status').value;

        db.updateSeries(seriesId, {
            isRecommended,
            isTrending,
            status
        });

        alert("✅ Değişiklikler kaydedildi!");
        document.querySelector('.modal').remove();
        this.renderContent(); // Refresh list
    },

    renderUsers() {
        const tbody = document.getElementById('admin-user-list');
        tbody.innerHTML = State.data.users.map(u => `
            <tr>
                <td>${u.username}</td>
                <td>
                    <select onchange="Admin.changeRole('${u.id}', this.value)" class="form-input" style="padding:5px;">
                        <option value="user" ${u.role === 'user' ? 'selected' : ''}>Kullanıcı</option>
                        <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
                    </select>
                </td>
                <td>
                    ${u.badges ? u.badges.join(', ') : ''} 
                    <button class="btn btn-sm btn-primary" onclick="Admin.addBadge('${u.id}')">+ Rozet Ekle</button>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline" onclick="Admin.removeBadges('${u.id}')">Rozetleri Temizle</button>
                </td>
            </tr>
        `).join('');
    },

    changeRole(uid, newRole) {
        db.updateUser(uid, { role: newRole });
        alert('Rol güncellendi.');
        this.renderUsers();
    },

    addBadge(uid) {
        const badgeOptions = ['Yönetici', 'Çevirmen', 'VIP', 'Moderatör', 'Aktif Üye', 'Destekçi'];
        const badgeList = badgeOptions.map((b, i) => `${i + 1}. ${b}`).join('\n');

        const choice = prompt(`Rozet seçin:\n${badgeList}\n\nNumara girin veya özel rozet adı yazın:`);

        if (!choice) return;

        let badge;
        const num = parseInt(choice);
        if (num >= 1 && num <= badgeOptions.length) {
            badge = badgeOptions[num - 1];
        } else {
            badge = choice;
        }

        const user = State.data.users.find(u => u.id === uid);
        const badges = user.badges || [];

        if (badges.includes(badge)) {
            alert("⚠️ Bu rozet zaten ekli!");
            return;
        }

        badges.push(badge);
        db.updateUser(uid, { badges });
        alert(`✅ "${badge}" rozeti eklendi!`);
        this.renderUsers();
    },

    removeBadges(uid) {
        if (confirm("Tüm rozetler silinecek. Emin misiniz?")) {
            db.updateUser(uid, { badges: [] });
            this.renderUsers();
        }
    },

    addCalendaritem() {
        const day = document.getElementById('calendar-day-select').value;
        const note = document.getElementById('calendar-note').value;
        if (note) {
            db.addCalendarEntry(day, note);
            this.renderCalendarList();
            document.getElementById('calendar-note').value = '';
            // Toast notification if available
            if (window.Toast) Toast.success('Takvim notu eklendi.');
        }
    },

    deleteCalendarItem(id) {
        if (confirm("Bu notu silmek istediğinize emin misiniz?")) {
            db.removeCalendarEntry(id).then(() => {
                this.renderCalendarList();
                if (window.Toast) Toast.success('Not silindi.');
            });
        }
    },



    renderCalendarList() {
        const list = document.getElementById('admin-calendar-list');
        if (!State.data.calendar || State.data.calendar.length === 0) {
            list.innerHTML = '<li style="color:var(--text-secondary);">Henüz not eklenmemiş.</li>';
            return;
        }
        list.innerHTML = State.data.calendar.map(c => `
            <li class="calendar-item-admin" style="display:flex; justify-content:space-between; align-items:center; background:var(--bg-secondary); padding:10px; margin-bottom:5px; border-radius:8px;">
                <span><strong style="color:var(--accent-color);">${c.day}</strong>: ${c.title}</span>
                <button class="btn btn-sm btn-outline" style="color:#ff4444; border-color:#ff4444;" onclick="Admin.deleteCalendarItem('${c.id}')"><i class="fa-solid fa-trash"></i> Sil</button>
            </li>
        `).join('');
    },

    // --- ADMIN CHAT ---
    renderChat() {
        const chat = JSON.parse(localStorage.getItem('dramicbox_admin_chat')) || [];
        const container = document.getElementById('admin-chat-messages');
        if (!container) return;

        container.innerHTML = chat.map(msg => `
            <div style="margin-bottom:10px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">
                <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
                    <strong style="color:var(--accent-color);">${msg.user}</strong>
                    <span style="font-size:0.75rem; color:var(--text-secondary);">${new Date(msg.date).toLocaleTimeString()}</span>
                </div>
                <div style="color:var(--text-primary);">${msg.text}</div>
            </div>
        `).join('') || '<p style="color:var(--text-secondary); text-align:center; padding:20px;">Henüz mesaj yok.</p>';

        container.scrollTop = container.scrollHeight;
    },

    sendChat() {
        const input = document.getElementById('admin-chat-input');
        const text = input.value.trim();
        if (!text) return;

        const chat = JSON.parse(localStorage.getItem('dramicbox_admin_chat')) || [];
        chat.push({
            user: State.currentUser.username,
            text: text,
            date: new Date().toISOString()
        });

        // Keep last 50 messages
        if (chat.length > 50) chat.shift();

        localStorage.setItem('dramicbox_admin_chat', JSON.stringify(chat));
        input.value = '';
        this.renderChat();
    },

    // --- RULES ---
    renderRules() {
        const rules = localStorage.getItem('dramicbox_rules') || '<h3>Site Kuralları</h3><p>Henüz kural eklenmedi.</p>';
        const textarea = document.getElementById('admin-rules-text');
        const preview = document.getElementById('admin-rules-preview');

        if (textarea) textarea.value = rules;
        if (preview) preview.innerHTML = rules;
    },

    saveRules() {
        const rules = document.getElementById('admin-rules-text').value;
        localStorage.setItem('dramicbox_rules', rules);
        this.renderRules();
        alert("✅ Kurallar başarıyla kaydedildi!");
    },

    // --- TRANSLATOR ASSIGNMENT ---
    loadTranslators() {
        const seriesId = document.getElementById('translator-series-select').value;
        if (!seriesId) {
            document.getElementById('translator-management').style.display = 'none';
            return;
        }

        document.getElementById('translator-management').style.display = 'block';
        const series = db.getSeries(seriesId);
        State.currentSeries = series;

        // Populate user select with users who have Çevirmen badge
        const translatorUsers = State.data.users.filter(u =>
            u.badges && (u.badges.includes('Çevirmen') || u.badges.includes('Yönetici') || u.badges.includes('Admin'))
        );

        const userSelect = document.getElementById('translator-user-select');
        userSelect.innerHTML = '<option value="">Kullanıcı seçin...</option>' +
            translatorUsers.map(u => `<option value="${u.id}">${u.username}</option>`).join('');

        this.renderTranslators();
    },

    renderTranslators() {
        const series = State.currentSeries;
        const list = document.getElementById('translators-list');

        if (!series.translators || series.translators.length === 0) {
            list.innerHTML = '<p style="color: var(--text-secondary);">Henüz çevirmen atanmamış.</p>';
            return;
        }

        list.innerHTML = series.translators.map((translatorId, index) => {
            const user = State.data.users.find(u => u.id === translatorId);
            if (!user) return '';

            return `
                <div class="episode-item">
                    <div class="episode-header">
                        <strong>${user.username}</strong>
                        <button class="btn btn-sm btn-outline" onclick="Admin.removeTranslator(${index})">Kaldır</button>
                    </div>
                </div>
            `;
        }).join('');
    },

    assignTranslator() {
        const userId = document.getElementById('translator-user-select').value;

        if (!userId) {
            alert("❌ Lütfen bir kullanıcı seçin!");
            return;
        }

        const series = State.currentSeries;
        if (!series.translators) series.translators = [];

        if (series.translators.includes(userId)) {
            alert("⚠️ Bu kullanıcı zaten çevirmen olarak atanmış!");
            return;
        }

        series.translators.push(userId);
        db.updateSeries(series.id, { translators: series.translators });

        const user = State.data.users.find(u => u.id === userId);
        alert(`✅ ${user.username} çevirmen olarak atandı!`);
        this.renderTranslators();
    },

    removeTranslator(index) {
        if (!confirm("Bu çevirmeni kaldırmak istediğinizden emin misiniz?")) return;

        const series = State.currentSeries;
        series.translators.splice(index, 1);
        db.updateSeries(series.id, { translators: series.translators });

        alert("✅ Çevirmen kaldırıldı!");
        this.renderTranslators();
    }
};

// HeroSlider is now defined in js/features/hero-slider-modern.js













document.addEventListener('DOMContentLoaded', () => {
    // Dynamic Filter Population
    const yearSelect = document.getElementById('search-year-filter');
    if (yearSelect) {
        const currentYear = new Date().getFullYear();
        let options = '<option value="">Tüm Yıllar</option>';
        for (let y = currentYear; y >= 2010; y--) {
            options += `<option value="${y}">${y}</option>`;
        }
        yearSelect.innerHTML = options;
    }

    const explicitGenres = [
        "Aksiyon", "Romantik", "Komedi", "Dram", "Fantezi",
        "Bilim Kurgu", "Korku", "Gerilim", "Suç", "Gizem",
        "Doğaüstü", "Tarih", "Müzik", "Spor", "Macera",
        "Okul", "Medikal", "Hukuk", "Politik", "Aile"
    ];

    const genreSelect = document.getElementById('search-genre-filter');
    if (genreSelect) {
        let options = '<option value="">Tüm Türler</option>';
        explicitGenres.forEach(g => {
            options += `<option value="${g}">${g}</option>`;
        });
        genreSelect.innerHTML = options;
    }

    // Auto-initialize app
    App.init();
});



// --- TRENDING CAROUSEL ---
const TrendingCarousel = {
    offset: 0,
    itemWidth: 220,

    prev() {
        this.offset = Math.max(0, this.offset - this.itemWidth * 5);
        this.updatePosition();
    },

    next() {
        const track = document.getElementById('trending-carousel');
        const maxOffset = track.scrollWidth - track.parentElement.clientWidth;
        this.offset = Math.min(maxOffset, this.offset + this.itemWidth * 5);
        this.updatePosition();
    },

    updatePosition() {
        const track = document.getElementById('trending-carousel');
        track.style.transform = `translateX(-${this.offset}px)`;
    }
};

// --- CALENDAR TYPE FILTERING DELEGATE ---
const Calendar = {
    filterType(type) {
        if (App && App.renderCalendar) {
            App.renderCalendar(type);
        }
    }
};

// --- ADMIN USER SEARCH ---
Admin.searchUsers = function () {
    const query = document.getElementById('user-search').value.toLowerCase();
    const filteredUsers = State.data.users.filter(u =>
        u.username.toLowerCase().includes(query)
    );

    const tbody = document.getElementById('admin-user-list');
    tbody.innerHTML = filteredUsers.map(u => `
    <tr>
            <td>${u.username}</td>
            <td>
                <select onchange="Admin.changeRole('${u.id}', this.value)" class="form-input" style="padding:5px;">
                    <option value="user" ${u.role === 'user' ? 'selected' : ''}>Kullanıcı</option>
                    <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
                </select>
            </td>
            <td>
                ${u.badges ? u.badges.join(', ') : ''} 
                <button class="btn btn-sm btn-primary" onclick="Admin.addBadge('${u.id}')">+ Rozet Ekle</button>
            </td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="Admin.removeBadges('${u.id}')">Rozetleri Temizle</button>
            </td>
        </tr>
    `).join('');
};

// Update renderUsers to use searchUsers
const originalRenderUsers = Admin.renderUsers;
Admin.renderUsers = function () {
    // Clear search
    const searchInput = document.getElementById('user-search');
    if (searchInput) searchInput.value = '';

    // Call search with empty query to show all
    this.searchUsers();
};

console.log('✅ Carousel, Calendar Filter, and User Search modules loaded!');

// --- DROPDOWN FIX ---
App.toggleUserDropdown = function (e) {
    if (e) {
        e.stopPropagation();
        e.preventDefault();
    }
    const dropdown = document.getElementById('user-dropdown');
    if (dropdown) {
        const isShown = dropdown.classList.contains('show') || dropdown.style.display === 'block';
        if (isShown) {
            dropdown.classList.remove('show');
            dropdown.style.display = 'none';
        } else {
            dropdown.classList.add('show');
            dropdown.style.display = 'block';
        }
        const notifDropdown = document.getElementById('notif-dropdown');
        if (notifDropdown && notifDropdown.classList.contains('show')) {
            notifDropdown.classList.remove('show');
        }
    }
};

App.initEasterEgg = function() {
    let dCount = 0;
    let lastDPress = 0;

    document.addEventListener('keydown', (e) => {
        // Only trigger if not in an input/textarea
        if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;

        if (e.key.toLowerCase() === 'd') {
            const now = Date.now();
            if (now - lastDPress < 1000) {
                dCount++;
            } else {
                dCount = 1;
            }
            lastDPress = now;

            if (dCount === 5) {
                App.triggerEasterEgg();
                dCount = 0;
            }
        } else {
            dCount = 0;
        }
    });
};

App.triggerEasterEgg = async function() {
    if (!State.currentUser) return;
    if (State.currentUser.easter_egg_found) {
        Toast.info("Zaten bu ödülü aldın! 😉");
        return;
    }

    // Add Dramiccoin
    if (!State.currentUser.coins) State.currentUser.coins = 0;
    State.currentUser.coins += 300;
    State.currentUser.easter_egg_found = true;

    // Save
    if (window.db) {
        await db.save();
    }

    // Show Animation
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.8); z-index:10000; display:flex; flex-direction:column; align-items:center; justify-content:center; animation: fadeIn 0.5s;';
    overlay.innerHTML = `
        <div style="text-align:center; animation: zoomIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);">
            <div style="font-size: 8rem; margin-bottom: 20px;">🥚</div>
            <h1 style="color:#ffd700; font-size:3rem; font-weight:900; text-shadow:0 0 30px rgba(255,215,0,0.5);">EASTER EGG FOUND!</h1>
            <p style="color:#fff; font-size:1.5rem; margin-top:10px;">+300 DramicCoin Hesabına Eklendi! 🎉</p>
            <div style="margin-top:30px; font-size:4rem;">🏆</div>
        </div>
    `;
    document.body.appendChild(overlay);

    // Add Achievement
    if (window.BadgeSystem) {
        BadgeSystem.award(State.currentUser.id, 'easter_egg');
    }

    setTimeout(() => {
        overlay.style.animation = 'fadeOut 0.5s';
        setTimeout(() => overlay.remove(), 500);
    }, 4000);

    Toast.success("Gizli başarı keşfedildi! 🎉");
};

// Global Listener for closing dropdowns
document.addEventListener('click', (e) => {
    const dropdown = document.getElementById('user-dropdown');
    const pill = e.target.closest('.user-pill');
    if (dropdown && (dropdown.classList.contains('show') || dropdown.style.display === 'block')) {
        if (!dropdown.contains(e.target) && !pill) {
            dropdown.classList.remove('show');
            dropdown.style.display = 'none';
        }
    }

    // Close navbar customizer
    const customizer = document.getElementById('navbar-customizer-menu');
    const customizerBtn = e.target.closest('.nav-customizer-btn');
    if (customizer && customizer.classList.contains('show')) {
        if (!customizer.contains(e.target) && !customizerBtn) {
            customizer.classList.remove('show');
            const btn = document.querySelector('.nav-customizer-btn');
            if (btn) btn.classList.remove('active');
        }
    }
});

// Dynamic Navbar & Customization Methods
App.renderNavbar = function() {
    const navLinks = document.querySelector('.nav-links');
    if (!navLinks) return;

    // Get current pinned links from localStorage
    let pinnedKeys = [];
    try {
        const saved = localStorage.getItem('dramicbox_pinned_links');
        if (saved) {
            pinnedKeys = JSON.parse(saved);
        } else {
            // Default pinned links
            pinnedKeys = ['drama', 'webtoon'];
            localStorage.setItem('dramicbox_pinned_links', JSON.stringify(pinnedKeys));
        }
    } catch(e) {
        pinnedKeys = ['drama', 'webtoon'];
    }

    // Definitions for all categories
    const categories = {
        drama: { title: 'Diziler', icon: 'fa-clapperboard', route: 'browse', param: 'drama' },
        webtoon: { title: 'Webtoonlar', icon: 'fa-book-open', route: 'browse', param: 'webtoon' },
        anime: { title: 'Animeler', icon: 'fa-dragon', route: 'browse', param: 'anime' },
        movie: { title: 'Filmler', icon: 'fa-film', route: 'browse', param: 'movie' },
        shorts: { title: 'Kısa Dramalar', icon: 'fa-bolt', route: 'shorts', param: null }
    };

    // 1. Discover (Keşfet) Dropdown
    let html = `
        <div class="nav-dropdown-wrapper">
            <a href="#" class="premium-nav-link" onclick="App.router('home'); return false;" data-route="home">
                <i class="fa-solid fa-compass"></i> Keşfet <i class="fa-solid fa-chevron-down dropdown-arrow"></i>
            </a>
            <div class="nav-dropdown-menu glass-panel">
                <a href="#" onclick="App.router('home'); return false;"><i class="fa-solid fa-house"></i> Ana Sayfa</a>
                <a href="#" onclick="App.router('browse', 'drama'); return false;"><i class="fa-solid fa-clapperboard"></i> Diziler</a>
                <a href="#" onclick="App.router('browse', 'webtoon'); return false;"><i class="fa-solid fa-book-open"></i> Webtoonlar</a>
                <a href="#" onclick="App.router('browse', 'anime'); return false;"><i class="fa-solid fa-dragon"></i> Animeler</a>
                <a href="#" onclick="App.router('browse', 'movie'); return false;"><i class="fa-solid fa-film"></i> Filmler</a>
                <a href="#" onclick="App.router('shorts'); return false;"><i class="fa-solid fa-bolt"></i> Kısa Dramalar</a>
                <a href="#" onclick="App.router('calendar'); return false;"><i class="fa-solid fa-calendar-days"></i> Yayın Takvimi</a>
            </div>
        </div>
    `;

    // 2. Render Pinned Links
    pinnedKeys.forEach(key => {
        const cat = categories[key];
        if (cat) {
            html += `
                <a href="#" class="premium-nav-link" onclick="App.router('${cat.route}'${cat.param ? `, '${cat.param}'` : ''}); return false;" data-route="${cat.route}" ${cat.param ? `data-param="${cat.param}"` : ''}>
                    <i class="fa-solid ${cat.icon}"></i> ${cat.title}
                </a>
            `;
        }
    });

    // 3. Yayın Takvimi
    html += `
        <a href="#" class="premium-nav-link" onclick="App.router('calendar'); return false;" data-route="calendar">
            <i class="fa-solid fa-calendar-days"></i> Yayın Takvimi
        </a>
    `;

    // 5. Sosyal Hub
    html += `
        <a href="#" class="premium-nav-link" onclick="App.router('social'); return false;" data-route="social">
            <i class="fa-solid fa-earth-americas"></i> Sosyal Hub
        </a>
    `;

    // 6. Personalization gear customizer
    html += `
        <div class="nav-customizer-wrapper">
            <button class="nav-customizer-btn" onclick="App.toggleNavbarCustomizer(event)" title="Menüyü Kişiselleştir">
                <i class="fa-solid fa-gear"></i>
            </button>
            <div class="nav-customizer-menu glass-panel" id="navbar-customizer-menu" onclick="event.stopPropagation()">
                <div class="customizer-title">Menüyü Düzenle</div>
                <div class="customizer-options">
                    <label class="customizer-option">
                        <input type="checkbox" value="drama" ${pinnedKeys.includes('drama') ? 'checked' : ''} onchange="App.togglePinnedLink('drama')">
                        <span>Diziler</span>
                    </label>
                    <label class="customizer-option">
                        <input type="checkbox" value="webtoon" ${pinnedKeys.includes('webtoon') ? 'checked' : ''} onchange="App.togglePinnedLink('webtoon')">
                        <span>Webtoonlar</span>
                    </label>
                    <label class="customizer-option">
                        <input type="checkbox" value="anime" ${pinnedKeys.includes('anime') ? 'checked' : ''} onchange="App.togglePinnedLink('anime')">
                        <span>Animeler</span>
                    </label>
                    <label class="customizer-option">
                        <input type="checkbox" value="movie" ${pinnedKeys.includes('movie') ? 'checked' : ''} onchange="App.togglePinnedLink('movie')">
                        <span>Filmler</span>
                    </label>
                    <label class="customizer-option">
                        <input type="checkbox" value="shorts" ${pinnedKeys.includes('shorts') ? 'checked' : ''} onchange="App.togglePinnedLink('shorts')">
                        <span>Kısa Dramalar</span>
                    </label>
                </div>
            </div>
        </div>
    `;

    navLinks.innerHTML = html;

    // Trigger router highlight to color the active item correctly
    const currentHash = window.location.hash || '';
    if (currentHash.startsWith('#/')) {
        const routePath = currentHash.slice(2).split('?')[0];
        const parts = routePath.split('/');
        const viewId = parts[0] || 'home';
        const param = parts[1] || null;

        document.querySelectorAll('.nav-links a').forEach(link => {
            const route = link.getAttribute('data-route');
            const linkParam = link.getAttribute('data-param');
            if (route === viewId && (!linkParam || linkParam === param)) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }
};

App.toggleNavbarCustomizer = function(event) {
    if (event) event.stopPropagation();
    const menu = document.getElementById('navbar-customizer-menu');
    const btn = document.querySelector('.nav-customizer-btn');
    if (menu) {
        menu.classList.toggle('show');
        if (btn) btn.classList.toggle('active', menu.classList.contains('show'));
    }
};

App.togglePinnedLink = function(key) {
    let pinnedKeys = [];
    try {
        const saved = localStorage.getItem('dramicbox_pinned_links');
        if (saved) pinnedKeys = JSON.parse(saved);
    } catch(e) {}

    const index = pinnedKeys.indexOf(key);
    if (index > -1) {
        pinnedKeys.splice(index, 1);
    } else {
        pinnedKeys.push(key);
    }

    localStorage.setItem('dramicbox_pinned_links', JSON.stringify(pinnedKeys));
    App.renderNavbar();
    
    // Keep customizer open after re-rendering
    setTimeout(() => {
        const menu = document.getElementById('navbar-customizer-menu');
        const btn = document.querySelector('.nav-customizer-btn');
        if (menu && btn) {
            menu.classList.add('show');
            btn.classList.add('active');
        }
    }, 50);
};

// Utility Functions
const Utils = {
    copyToClipboard(text) {
        if (!text) return;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(() => {
                Toast.success('Bağlantı kopyalandı!');
            }).catch(err => {
                this.fallbackCopyTextToClipboard(text);
            });
        } else {
            this.fallbackCopyTextToClipboard(text);
        }
    },

    fallbackCopyTextToClipboard(text) {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            Toast.success('Bağlantı kopyalandı!');
        } catch (err) {
            Toast.error('Kopyalama başarısız!');
        }
        document.body.removeChild(textArea);
    }
};
window.App = App;
window.Utils = Utils;

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});
}
