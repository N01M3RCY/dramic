/**
 * Admin Cryptology Page
 * Secure encryption/decryption interface with dynamic URL
 */

const AdminCryptology = {
    token: null,
    dynamicPath: null,

    /**
     * Initialize cryptology page with dynamic URL
     */
    init() {
        // Generate dynamic path component
        this.dynamicPath = 'cryptology-' + Date.now() + '-' + Math.random().toString(36).substring(7);
        console.log('🔐 Cryptology initialized with path:', this.dynamicPath);
    },

    /**
     * Check if user has access
     */
    hasAccess() {
        const user = State.currentUser;
        if (!user) return false;
        return user.role === 'admin' || user.badges?.includes('Yönetici') || user.badges?.includes('Admin');
    },

    /**
     * Get access token from server
     */
    async getToken() {
        try {
            const response = await fetch('./api/db.php?action=crypto-token');
            const result = await response.json();
            if (result.success) {
                this.token = result.token;
                return true;
            }
            Toast.error(result.error || 'Token alınamadı');
            return false;
        } catch (e) {
            Toast.error('Token hatası: ' + e.message);
            return false;
        }
    },

    /**
     * Render the cryptology page
     */
    async render() {
        if (!this.hasAccess()) {
            Toast.error('Bu sayfaya erişim yetkiniz yok!');
            App.router('home');
            return;
        }

        // Get fresh token
        await this.getToken();

        if (!this.token) {
            Toast.error('Güvenlik tokeni alınamadı');
            return;
        }

        // Update URL with dynamic path (prevents URL sharing)
        const newPath = 'cryptology-' + Date.now();
        window.history.replaceState(null, '', '#/' + newPath);

        const container = document.getElementById('main-content');
        if (!container) return;

        // Hide all views
        document.querySelectorAll('.view-section').forEach(v => v.style.display = 'none');

        container.innerHTML = `
            <div class="cryptology-page" style="padding: 100px 20px 40px; max-width: 1200px; margin: 0 auto;">
                <div class="crypto-header" style="margin-bottom: 30px;">
                    <h1 style="font-size: 2rem; background: linear-gradient(135deg, #10b981, #06b6d4); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                        🔐 Cryptology Center
                    </h1>
                    <p style="color: var(--text-muted); margin-top: 10px;">AES-256-GCM şifreleme ve çözme merkezi</p>
                    <div style="margin-top: 15px; padding: 10px 15px; background: rgba(16, 185, 129, 0.1); border-radius: 8px; display: inline-block;">
                        <span style="color: #10b981;">🔑 Token:</span>
                        <code style="color: var(--text-muted); font-size: 0.85rem;">${this.token.substring(0, 20)}...</code>
                        <span style="color: #f59e0b; margin-left: 10px;">⏱️ 5 dk geçerli</span>
                    </div>
                </div>
                
                <div class="crypto-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 25px;">
                    <!-- Decrypt Panel -->
                    <div class="crypto-panel" style="background: var(--card-bg); border-radius: 16px; padding: 25px; border: 1px solid var(--border-color);">
                        <h2 style="color: var(--text-primary); margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                            <span style="font-size: 1.5rem;">🔓</span> Şifre Çöz
                        </h2>
                        <textarea id="crypto-decrypt-input" placeholder="DRMC ile başlayan şifreli metni buraya yapıştırın..." 
                            style="width: 100%; height: 150px; background: var(--input-bg); border: 1px solid var(--border-color); border-radius: 8px; padding: 15px; color: var(--text-primary); resize: vertical; font-family: monospace;"></textarea>
                        <button onclick="AdminCryptology.decrypt()" class="btn btn-primary" style="margin-top: 15px; width: 100%;">
                            <i class="fa-solid fa-unlock"></i> Şifreyi Çöz
                        </button>
                        <div id="crypto-decrypt-result" style="margin-top: 20px;"></div>
                    </div>
                    
                    <!-- Encrypt Panel -->
                    <div class="crypto-panel" style="background: var(--card-bg); border-radius: 16px; padding: 25px; border: 1px solid var(--border-color);">
                        <h2 style="color: var(--text-primary); margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                            <span style="font-size: 1.5rem;">🔒</span> Şifrele
                        </h2>
                        <textarea id="crypto-encrypt-input" placeholder="Şifrelenecek metni buraya yazın..." 
                            style="width: 100%; height: 150px; background: var(--input-bg); border: 1px solid var(--border-color); border-radius: 8px; padding: 15px; color: var(--text-primary); resize: vertical;"></textarea>
                        <button onclick="AdminCryptology.encrypt()" class="btn btn-secondary" style="margin-top: 15px; width: 100%;">
                            <i class="fa-solid fa-lock"></i> Şifrele
                        </button>
                        <div id="crypto-encrypt-result" style="margin-top: 20px;"></div>
                    </div>
                </div>
                
                <!-- Analyze Panel -->
                <div class="crypto-panel" style="background: var(--card-bg); border-radius: 16px; padding: 25px; border: 1px solid var(--border-color); margin-top: 25px;">
                    <h2 style="color: var(--text-primary); margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 1.5rem;">🔍</span> Şifreli Veri Analizi
                    </h2>
                    <button onclick="AdminCryptology.listEncrypted()" class="btn btn-outline" style="margin-bottom: 20px;">
                        <i class="fa-solid fa-database"></i> Veritabanındaki Şifreli Verileri Listele
                    </button>
                    <div id="crypto-list-result"></div>
                </div>
                
                <!-- Info Panel -->
                <div class="crypto-panel" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(6, 182, 212, 0.1)); border-radius: 16px; padding: 25px; margin-top: 25px; border: 1px solid rgba(16, 185, 129, 0.3);">
                    <h3 style="color: #10b981; margin-bottom: 15px;">🛡️ Güvenlik Bilgisi</h3>
                    <ul style="color: var(--text-muted); line-height: 1.8;">
                        <li><strong>Algoritma:</strong> AES-256-GCM (Authenticated Encryption)</li>
                        <li><strong>Anahtar Türetme:</strong> PBKDF2-SHA256 (100,000 iterasyon)</li>
                        <li><strong>IV/Salt:</strong> Her şifreleme için benzersiz</li>
                        <li><strong>Signature:</strong> DRMC prefix ile tanımlama</li>
                        <li><strong>Token Süresi:</strong> 5 dakika</li>
                    </ul>
                </div>
            </div>
        `;
    },

    /**
     * Decrypt text
     */
    async decrypt() {
        const input = document.getElementById('crypto-decrypt-input');
        const result = document.getElementById('crypto-decrypt-result');

        if (!input.value.trim()) {
            Toast.warning('Şifreli metin girin');
            return;
        }

        result.innerHTML = '<div style="color: var(--text-muted);"><i class="fa-solid fa-spinner fa-spin"></i> Çözülüyor...</div>';

        try {
            const response = await fetch('./api/db.php?action=crypto-decrypt', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    token: this.token,
                    encrypted: input.value.trim()
                })
            });

            const data = await response.json();

            if (data.success) {
                let content = '';
                if (data.type === 'json') {
                    content = `
                        <div style="background: rgba(16, 185, 129, 0.1); border-radius: 8px; padding: 15px;">
                            <div style="color: #10b981; margin-bottom: 10px;">✅ Başarıyla çözüldü (JSON)</div>
                            <pre style="background: var(--input-bg); padding: 15px; border-radius: 8px; overflow-x: auto; color: var(--text-primary); font-size: 0.85rem;">${JSON.stringify(data.data, null, 2)}</pre>
                        </div>
                    `;
                } else {
                    content = `
                        <div style="background: rgba(16, 185, 129, 0.1); border-radius: 8px; padding: 15px;">
                            <div style="color: #10b981; margin-bottom: 10px;">✅ Başarıyla çözüldü</div>
                            <div style="background: var(--input-bg); padding: 15px; border-radius: 8px; color: var(--text-primary);">${data.data}</div>
                        </div>
                    `;
                }
                result.innerHTML = content;
            } else {
                result.innerHTML = `<div style="color: #ef4444; background: rgba(239, 68, 68, 0.1); padding: 15px; border-radius: 8px;">❌ ${data.error}</div>`;
            }
        } catch (e) {
            result.innerHTML = `<div style="color: #ef4444;">❌ Hata: ${e.message}</div>`;
        }
    },

    /**
     * Encrypt text
     */
    async encrypt() {
        const input = document.getElementById('crypto-encrypt-input');
        const result = document.getElementById('crypto-encrypt-result');

        if (!input.value.trim()) {
            Toast.warning('Şifrelenecek metin girin');
            return;
        }

        result.innerHTML = '<div style="color: var(--text-muted);"><i class="fa-solid fa-spinner fa-spin"></i> Şifreleniyor...</div>';

        try {
            const response = await fetch('./api/db.php?action=crypto-encrypt', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    token: this.token,
                    plaintext: input.value.trim()
                })
            });

            const data = await response.json();

            if (data.success) {
                result.innerHTML = `
                    <div style="background: rgba(139, 92, 246, 0.1); border-radius: 8px; padding: 15px;">
                        <div style="color: #8b5cf6; margin-bottom: 10px;">🔒 Şifrelendi</div>
                        <textarea readonly style="width: 100%; height: 80px; background: var(--input-bg); border: 1px solid var(--border-color); border-radius: 8px; padding: 10px; color: var(--text-primary); font-family: monospace; font-size: 0.8rem;">${data.encrypted}</textarea>
                        <button onclick="navigator.clipboard.writeText('${data.encrypted}'); Toast.success('Kopyalandı!')" class="btn btn-sm btn-outline" style="margin-top: 10px;">
                            <i class="fa-solid fa-copy"></i> Kopyala
                        </button>
                        <div style="margin-top: 15px; color: var(--text-muted); font-size: 0.85rem;">
                            <strong>Analiz:</strong> ${data.analysis.algorithm} | ${data.analysis.totalLength} karakter
                        </div>
                    </div>
                `;
            } else {
                result.innerHTML = `<div style="color: #ef4444;">❌ ${data.error}</div>`;
            }
        } catch (e) {
            result.innerHTML = `<div style="color: #ef4444;">❌ Hata: ${e.message}</div>`;
        }
    },

    /**
     * List encrypted data in database
     */
    async listEncrypted() {
        const result = document.getElementById('crypto-list-result');
        result.innerHTML = '<div style="color: var(--text-muted);"><i class="fa-solid fa-spinner fa-spin"></i> Taranıyor...</div>';

        try {
            const response = await fetch('./api/db.php?action=crypto-list', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token: this.token })
            });

            const data = await response.json();

            if (data.success) {
                if (data.items.length === 0) {
                    result.innerHTML = '<div style="color: var(--text-muted);">Şifreli veri bulunamadı.</div>';
                    return;
                }

                let html = `<div style="color: #10b981; margin-bottom: 15px;">${data.count} şifreli veri bulundu</div>`;
                html += '<div style="display: grid; gap: 10px;">';

                data.items.forEach(item => {
                    html += `
                        <div style="background: var(--input-bg); padding: 12px 15px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <span style="color: var(--text-primary);">${item.type}: ${item.id}</span>
                                <span style="color: var(--text-muted); margin-left: 10px;">[${item.field}]</span>
                            </div>
                            <code style="color: var(--text-muted); font-size: 0.75rem;">${item.preview}</code>
                        </div>
                    `;
                });

                html += '</div>';
                result.innerHTML = html;
            } else {
                result.innerHTML = `<div style="color: #ef4444;">❌ ${data.error}</div>`;
            }
        } catch (e) {
            result.innerHTML = `<div style="color: #ef4444;">❌ Hata: ${e.message}</div>`;
        }
    }
};

// Initialize
AdminCryptology.init();

// Make globally available
window.AdminCryptology = AdminCryptology;

console.log('✅ Admin Cryptology Module Loaded');
