/**
 * DRAMICBOX - UNIFIED MANAGEMENT HUB (STUDIO)
 * Version: 3.1 (Ultra-Premium Redesign + Full Feature Integration)
 */

const ManagementHub = {
    currentTab: 'dashboard',
    role: 'guest',
    data: {},

    async init(initialTab = 'dashboard') {
        const user = State.currentUser;
        if (!user || !['admin', 'moderator', 'editor', 'translation_leader', 'editor_leader'].includes(user.role)) {
            Toast.error('Yetkisiz erişim.');
            window.location.href = 'index.html';
            return;
        }

        this.role = user.role;
        this.currentTab = initialTab;

        // Apply Customizations early
        this.applyAdminCustomization();

        // Load Data
        await this.refreshData();
        this.render();
    },

    async refreshData() {
        if (window.db && db.loadData) {
            State.data = await db.loadData(['users', 'series', 'webtoons', 'blogPosts', 'reports', 'settings', 'approvals', 'announcements', 'logs', 'journals', 'actors']);
        }
        this.render();
    },

    render() {
        const container = document.getElementById('admin-main-view');
        if (!container) return;

        // Apply Customizations on render
        this.applyAdminCustomization();

        // Update active link in sidebar
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('onclick')?.includes(this.currentTab)) {
                link.classList.add('active');
            }
        });

        // Update Title & Subtitle
        const titleMap = {
            dashboard: { t: 'Dashboard', s: 'Sistemin genel durumuna ve istatistiklerine göz atın.' },
            calendar: { t: 'Yayın Takvimi', s: 'Haftalık yayın akışını ve yeni bölüm zamanlarını yönetin.' },
            series: { t: 'Dizi Yönetimi', s: 'Kütüphanedeki tüm dizileri düzenleyin ve yeni içerik ekleyin.' },
            webtoons: { t: 'Webtoon Yönetimi', s: 'Webtoon serilerini ve bölümlerini yönetin.' },
            actors: { t: 'Karakter & Aktörler', s: 'Aktörlerin biyografilerini, kişisel künyelerini ve fan kulüp ayarlarını yönetin.' },
            chests_cards: { t: 'Oyuncu Kartı & Sandık', s: 'Oyuncu kartlarını, sandık fiyatlarını ve düşme oranlarını yönetin.' },
            dramic_pass: { t: 'Dramic Pass', s: 'Seviye ödüllerini ve Royal Pass katmanlarını yönetin.' },
            blog: { t: 'Blog Yazıları', s: 'Haberler, makaleler ve duyuruları yönetin.' },
            approvals: { t: 'Onay Merkezi', s: 'Sürükle bırak ile içerikleri hızla onaylayın veya reddedin.' },
            teams: { t: 'Ekip Merkezi', s: 'Çeviri ve editör ekiplerini organize edin.' },
            journal: { t: 'E-Dergi Yönetimi', s: 'Aylık e-dergi sayılarını ve taslaklarını düzenleyin.' },
            users: { t: 'Üye Denetimi', s: 'Kullanıcı yetkilerini ve hesap durumlarını yönetin.' },
            verifications: { t: 'Mavi Tik Başvuruları', s: 'Kullanıcıların doğrulanmış hesap başvurularını inceleyin.' },
            ads: { t: 'Reklam Yönetimi', s: 'Sitedeki video/görsel reklamları ve yayın sıklıklarını yönetin.' },
            logs: { t: 'Sistem Logları', s: 'Sistem üzerindeki tüm aktiviteleri takip edin.' },
            settings: { t: 'Genel Ayarlar', s: 'Site yapılandırmasını ve global ayarları düzenleyin.' },
            social_moderation: { t: 'Sosyal Link Moderasyonu', s: 'Sosyal Hub\'da paylaşılmasına izin verilen ve yasaklanan alan adlarını yönetin.' }
        };

        const head = titleMap[this.currentTab] || { t: 'Yönetim', s: 'Kontrol paneli' };
        document.getElementById('page-title').textContent = head.t;
        document.getElementById('page-subtitle').textContent = head.s;

        // Render Tab Content
        switch (this.currentTab) {
            case 'dashboard': this.renderDashboard(container); break;
            case 'calendar': this.renderCalendarManagement(container); break;
            case 'approvals': this.renderApprovals(container); break;
            case 'teams': this.renderTeams(container); break;
            case 'series': this.renderContentList(container, 'series'); break;
            case 'webtoons': this.renderContentList(container, 'webtoons'); break;
            case 'actors': this.renderActors(container); break;
            case 'chests_cards': this.renderChestsCards(container); break;
            case 'dramic_pass': this.renderDramicPass(container); break;
            case 'blog': this.renderContentList(container, 'blogPosts'); break;
            case 'journal': this.renderJournal(container); break;
            case 'users': this.renderUsers(container); break;
            case 'verifications': this.renderVerifications(container); break;
            case 'ads': this.renderAds(container); break;
            case 'logs': this.renderLogs(container); break;
            case 'settings': this.renderSettings(container); break;
            case 'social_moderation': this.renderSocialModeration(container); break;
            default: container.innerHTML = `<div style="padding: 50px; text-align: center; color: var(--admin-text-muted);"><h3>Bu bölüm yapım aşamasındadır.</h3></div>`;
        }
    },

    renderDashboard(container) {
        const stats = [
            { label: 'Toplam Üye', value: (State.data.users || []).length, icon: 'fa-users', color: '#8b5cf6', trend: '+12%' },
            { label: 'Aktif Diziler', value: (State.data.series || []).length, icon: 'fa-play', color: '#10b981', trend: '+5' },
            { label: 'Bekleyen Onay', value: (State.data.approvals || []).length, icon: 'fa-clock', color: '#f59e0b', trend: 'Yeni' },
            { label: 'Sistem Durumu', value: 'Kontrol Et', icon: 'fa-heart-pulse', color: '#ef4444', action: 'checkSystemHealth' }
        ];

        container.innerHTML = `
            <div class="stats-container">
                ${stats.map(s => `
                    <div class="stat-card" ${s.action ? `onclick="ManagementHub.${s.action}()" style="cursor:pointer;"` : ''}>
                        ${s.trend ? `<div class="stat-trend" style="background: ${s.color}20; color: ${s.color};">${s.trend}</div>` : ''}
                        <div class="stat-icon" style="background: ${s.color}20; color: ${s.color};">
                            <i class="fa-solid ${s.icon}"></i>
                        </div>
                        <div class="stat-value">${s.value}</div>
                        <div class="stat-label">${s.label}</div>
                    </div>
                `).join('')}
            </div>

            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
                <div class="data-card" style="padding: 30px;">
                    <h3 style="margin-bottom: 20px;">Ziyaretçi İstatistikleri</h3>
                    <canvas id="visitorChart" height="150"></canvas>
                </div>
                <div class="data-card" style="padding: 30px;">
                    <h3 style="margin-bottom: 20px;">Son Aktiviteler</h3>
                    <div id="recent-activities">
                        ${(State.data.logs || []).slice(0, 5).map(log => `
                            <div style="padding: 12px 0; border-bottom: 1px solid var(--admin-border); display: flex; gap: 10px;">
                                <div style="width: 8px; height: 8px; border-radius: 50%; background: ${log.type === 'error' ? '#ef4444' : '#8b5cf6'}; margin-top: 6px;"></div>
                                <div>
                                    <div style="font-weight: 700; font-size: 0.85rem;">${log.action || 'Sistem Olayı'}</div>
                                    <div style="font-size: 0.75rem; color: var(--admin-text-muted);">${log.message || 'Detay yok.'}</div>
                                </div>
                            </div>
                        `).join('') || '<div style="color:var(--admin-text-muted); font-size:0.8rem;">Henüz aktivite yok.</div>'}
                    </div>
                </div>
            </div>
        `;

        this.initCharts();
    },

    initCharts() {
        const ctx = document.getElementById('visitorChart')?.getContext('2d');
        if (!ctx) return;

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'],
                datasets: [{
                    label: 'Günlük İzlenme',
                    data: [12000, 19000, 15000, 25000, 22000, 30000, 35000],
                    borderColor: '#8b5cf6',
                    backgroundColor: 'rgba(139, 92, 246, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#64748b' } },
                    x: { grid: { display: false }, ticks: { color: '#64748b' } }
                }
            }
        });
    },

    renderApprovals(container) {
        const userRole = State.currentUser?.role;
        let allItems = State.data.pendingApprovals || [];

        // Role-based filtering
        if (userRole === 'translation_leader') {
            // Translation leaders see only items from their translators
            allItems = allItems.filter(i => i.teamType === 'translation' && (!i.status || i.status === 'pending' || i.status === 'pending_leader_approval'));
        } else if (userRole === 'editor_leader') {
            allItems = allItems.filter(i => i.teamType === 'editing' && (!i.status || i.status === 'pending' || i.status === 'pending_leader_approval'));
        }
        // Admin sees everything

        const pending = allItems.filter(i => !i.status || i.status === 'pending' || i.status === 'pending_leader_approval');
        const approved = allItems.filter(i => i.status === 'approved' || i.status === 'approved_by_leader');
        const rejected = allItems.filter(i => i.status === 'rejected');

        container.innerHTML = `
            <div class="kanban-board">
                <div class="kanban-column" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)" ondrop="handleDrop(event, 'pending')">
                    <div class="column-header">
                        <div class="column-title" style="color: var(--admin-warning);">
                            <i class="fa-solid fa-clock"></i> BEKLEYENLER
                        </div>
                        <div class="column-count">${pending.length}</div>
                    </div>
                    <div class="kanban-cards">
                        ${pending.map(item => this.renderKanbanCard(item)).join('')}
                    </div>
                </div>
                <div class="kanban-column" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)" ondrop="handleDrop(event, 'approved')">
                    <div class="column-header">
                        <div class="column-title" style="color: var(--admin-success);">
                            <i class="fa-solid fa-circle-check"></i> ONAYLANANLAR
                        </div>
                        <div class="column-count">${approved.length}</div>
                    </div>
                    <div class="kanban-cards">
                        ${approved.map(item => this.renderKanbanCard(item)).join('')}
                    </div>
                </div>
                <div class="kanban-column" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)" ondrop="handleDrop(event, 'rejected')">
                    <div class="column-header">
                        <div class="column-title" style="color: var(--admin-danger);">
                            <i class="fa-solid fa-circle-xmark"></i> REDDEDİLENLER
                        </div>
                        <div class="column-count">${rejected.length}</div>
                    </div>
                    <div class="kanban-cards">
                        ${rejected.map(item => this.renderKanbanCard(item)).join('')}
                    </div>
                </div>
            </div>
        `;
    },

    renderKanbanCard(item) {
        return `
            <div class="kanban-item" draggable="true" ondragstart="handleDragStart(event, '${item.id}')" ondragend="handleDragEnd(event)">
                <div style="display: flex; gap: 12px;">
                    <img src="${item.poster || 'assets/logo.png'}" style="width: 40px; height: 55px; border-radius: 8px; object-fit: cover;">
                    <div style="flex: 1;">
                        <h4 style="margin:0; font-size:0.85rem;">${item.title}</h4>
                        <p style="font-size:0.7rem;">${item.type?.toUpperCase()} • ${item.submitter || 'Staff'}</p>
                    </div>
                </div>
            </div>
        `;
    },

    async updateItemStatus(id, newStatus) {
        const item = State.data.pendingApprovals.find(i => i.id === id);
        if (item) {
            item.status = newStatus;
            await db.saveItem('pendingApprovals', item.id, item);
            Toast.success(`${item.title} durumu güncellendi.`);
            this.render();
        }
    },

    renderTeams(container) {
        const users = State.data.users || [];
        const translators = users.filter(u => u.role === 'translator');
        const translationLeaders = users.filter(u => u.role === 'translation_leader');
        const editors = users.filter(u => u.role === 'editor');
        const editorLeaders = users.filter(u => u.role === 'editor_leader');

        const teamGroups = [
            {
                name: 'Çeviri Ekibi',
                icon: 'fa-language',
                color: '#8b5cf6',
                leaders: translationLeaders,
                members: translators,
                roleKey: 'translator'
            },
            {
                name: 'Editör Ekibi', 
                icon: 'fa-pen-nib',
                color: '#3b82f6',
                leaders: editorLeaders,
                members: editors,
                roleKey: 'editor'
            }
        ];

        container.innerHTML = `
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(450px, 1fr)); gap: 24px;">
                ${teamGroups.map(team => `
                    <div class="data-card" style="padding: 30px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                            <h3 style="margin:0; display:flex; align-items:center; gap:10px;">
                                <i class="fa-solid ${team.icon}" style="color:${team.color}"></i> ${team.name}
                            </h3>
                            <span class="badge" style="background:${team.color}20; color:${team.color}; padding:5px 12px; border-radius:10px; font-weight:700;">
                                ${team.leaders.length + team.members.length} Kişi
                            </span>
                        </div>

                        ${team.leaders.length > 0 ? `
                            <div style="margin-bottom: 20px;">
                                <div style="font-size:0.8rem; color:var(--admin-text-muted); margin-bottom:10px; text-transform:uppercase; font-weight:700; letter-spacing:1px;">Ekip Liderleri</div>
                                ${team.leaders.map(l => `
                                    <div style="display:flex; align-items:center; gap:12px; padding:12px; background:rgba(255,255,255,0.03); border-radius:12px; border:1px solid rgba(255,255,255,0.05); margin-bottom:8px;">
                                        <img src="${l.avatar || 'assets/logo.png'}" style="width:40px; height:40px; border-radius:50%; border:2px solid ${team.color};" onerror="this.src='assets/logo.png'">
                                        <div style="flex:1;">
                                            <div style="font-weight:700; color:#fff;">${l.username} <i class="fa-solid fa-crown" style="color:#fbbf24; font-size:0.75rem;"></i></div>
                                            <div style="font-size:0.75rem; color:var(--admin-text-muted);">${l.email || 'E-posta yok'}</div>
                                        </div>
                                        <button class="admin-btn admin-btn-outline" style="padding:5px 10px; font-size:0.75rem;" onclick="ManagementHub.changeRole('${l.id}', 'user')">Yetkiyi Al</button>
                                    </div>
                                `).join('')}
                            </div>
                        ` : ''}

                        <div style="font-size:0.8rem; color:var(--admin-text-muted); margin-bottom:10px; text-transform:uppercase; font-weight:700; letter-spacing:1px;">Ekip Üyeleri</div>
                        ${team.members.length > 0 ? team.members.map(m => `
                            <div style="display:flex; align-items:center; gap:12px; padding:10px; background:rgba(0,0,0,0.15); border-radius:10px; margin-bottom:6px;">
                                <img src="${m.avatar || 'assets/logo.png'}" style="width:35px; height:35px; border-radius:50%;" onerror="this.src='assets/logo.png'">
                                <div style="flex:1;">
                                    <div style="font-weight:600; color:#cbd5e1; font-size:0.9rem;">${m.username}</div>
                                </div>
                                <button class="admin-btn admin-btn-outline" style="padding:4px 8px; font-size:0.7rem;" onclick="ManagementHub.changeRole('${m.id}', '${team.roleKey}_leader')">
                                    <i class="fa-solid fa-arrow-up"></i> Lider Yap
                                </button>
                                <button class="admin-btn admin-btn-outline" style="padding:4px 8px; font-size:0.7rem; color:var(--admin-danger);" onclick="ManagementHub.changeRole('${m.id}', 'user')">
                                    <i class="fa-solid fa-user-minus"></i>
                                </button>
                            </div>
                        `).join('') : '<div style="color:var(--admin-text-muted); font-size:0.85rem; padding:15px; text-align:center;">Henüz ekip üyesi yok.</div>'}

                        <div style="margin-top:15px; padding-top:15px; border-top:1px solid rgba(255,255,255,0.05);">
                            <button class="admin-btn admin-btn-primary" style="width:100%; justify-content:center; padding:10px;" onclick="ManagementHub.showAddMemberModal('${team.roleKey}')">
                                <i class="fa-solid fa-user-plus"></i> Üye Ekle
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    },

    renderJournal(container) {
        const journals = State.data.journals || [];
        container.innerHTML = `
            <div class="data-card" style="padding: 30px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <h3>E-Dergi Koleksiyonu</h3>
                    <button class="admin-btn admin-btn-primary" onclick="ManagementHub.openJournalModal()"><i class="fa-solid fa-plus"></i> Yeni Sayı Oluştur</button>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 24px;">
                    ${journals.map(j => `
                        <div class="stat-card" style="padding: 15px; text-align: center;">
                            <img src="${j.coverImage || 'assets/logo.png'}" style="width: 100%; height: 250px; object-fit: cover; border-radius: 15px; margin-bottom: 15px;">
                            <h4 style="margin:0;">${j.title}</h4>
                            <p style="font-size: 0.8rem; color: var(--admin-text-muted);">${j.month} ${j.year}</p>
                        </div>
                    `).join('') || '<div style="color:var(--admin-text-muted);">Sayı bulunamadı.</div>'}
                </div>
            </div>
        `;
    },

    renderContentList(container, type) {
        const items = State.data[type] || [];
        const typeLabel = type === 'series' ? 'dizi' : type === 'webtoons' ? 'webtoon' : 'yazı';
        container.innerHTML = `
            <div class="data-card">
                <div style="padding: 24px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--admin-border); flex-wrap: wrap; gap: 16px;">
                    <h3>${type === 'series' ? 'Diziler' : type === 'webtoons' ? 'Webtoonlar' : 'Blog Yazıları'}</h3>
                    <button class="admin-btn admin-btn-primary" onclick="ManagementHub.openContentModal('${type}')">Yeni Ekle</button>
                </div>
                <div style="padding: 16px 24px; border-bottom: 1px solid var(--admin-border); display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 200px; position: relative;">
                        <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--admin-text-muted); pointer-events: none;"></i>
                        <input type="search" id="admin-content-search" class="admin-form-input" placeholder="${type === 'series' ? 'Dizi adı ile ara...' : type === 'webtoons' ? 'Webtoon adı ile ara...' : 'Yazı başlığı ile ara...'}" 
                            style="width: 100%; padding: 10px 14px 10px 40px; border-radius: 10px;"
                            oninput="ManagementHub.filterContentRows(this.value)">
                    </div>
                    <span style="color: var(--admin-text-muted); font-size: 0.85rem;" id="admin-content-count">${items.length} ${typeLabel}</span>
                </div>
                <div class="table-responsive">
                    <table class="admin-table">
                        <thead>
                            <tr><th>İçerik</th><th>Durum</th><th>İşlem</th></tr>
                        </thead>
                        <tbody id="admin-content-tbody">
                            ${items.map(item => `
                                <tr data-content-search="${(item.title || '').toLowerCase().replace(/"/g, '')}">
                                    <td><b>${item.title}</b></td>
                                    <td><span style="color:var(--admin-success)">Aktif</span></td>
                                    <td style="display:flex; gap:10px;">
                                        <button class="admin-btn admin-btn-outline" style="padding:5px 10px; font-size:0.75rem;" onclick="ManagementHub.openContentModal('${type}', '${item.id}')">Düzenle</button>
                                        <button class="admin-btn admin-btn-outline" style="padding:5px 10px; font-size:0.75rem; color:var(--admin-danger); border-color:rgba(239,68,68,0.2);" onclick="ManagementHub.deleteContent('${type}', '${item.id}', '${item.title.replace(/'/g, "\\'")}')">Sil</button>
                                    </td>
                                </tr>
                            `).join('') || '<tr><td colspan="3" style="text-align:center; padding:20px;">Veri yok.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    },

    filterContentRows(query) {
        const q = (query || '').trim().toLowerCase();
        let visibleCount = 0;
        const rows = document.querySelectorAll('#admin-content-tbody tr[data-content-search]');
        rows.forEach(row => {
            const blob = row.getAttribute('data-content-search') || '';
            const matches = !q || blob.includes(q);
            row.style.display = matches ? '' : 'none';
            if (matches) visibleCount++;
        });
        const countSpan = document.getElementById('admin-content-count');
        if (countSpan) {
            const label = this.currentTab === 'series' ? 'dizi' : this.currentTab === 'webtoons' ? 'webtoon' : 'yazı';
            countSpan.textContent = `${visibleCount} ${label}`;
        }
    },

    renderUsers(container) {
        const users = State.data.users || [];
        container.innerHTML = `
            <div class="data-card">
                <div style="padding: 16px 20px; border-bottom: 1px solid var(--admin-border); display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                    <div style="flex:1; min-width: 200px;">
                        <input type="search" id="admin-member-search" class="admin-form-input" placeholder="Kullanıcı adı veya e-posta ile ara..." 
                            style="width:100%; padding:10px 14px; border-radius:10px;"
                            oninput="ManagementHub.filterMemberRows(this.value)">
                    </div>
                    <span style="color:var(--admin-text-muted); font-size:0.85rem;">${users.length} üye</span>
                </div>
                <div class="table-responsive">
                    <table class="admin-table" id="admin-members-table">
                        <thead><tr><th>Kullanıcı</th><th>E-posta</th><th>Rol</th><th>XP / Para</th><th>Durum</th><th>İşlem</th></tr></thead>
                        <tbody id="admin-members-tbody">
                            ${users.map(u => this.memberRowHtml(u)).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    },

    memberRowHtml(u) {
        const status = u.banned ? 'Yasaklı' : (u.status || 'Aktif');
        const xp = u.stats?.xp ?? 0;
        const coins = u.stats?.coins ?? 0;
        const searchBlob = `${u.username || ''} ${u.email || ''} ${u.role || ''}`.toLowerCase();
        return `
            <tr data-member-search="${searchBlob.replace(/"/g, '')}">
                <td><b>${u.username || '—'}</b></td>
                <td style="font-size:0.85rem; color:var(--admin-text-muted);">${u.email || '—'}</td>
                <td>${(u.role || 'user').toUpperCase()}</td>
                <td style="font-size:0.85rem;"><span style="color:#a78bfa;">${xp}</span> XP · <span style="color:#fbbf24;">${coins}</span> <i class="fa-solid fa-coins" style="font-size:0.7rem;"></i></td>
                <td>${status}</td>
                <td>
                    <button type="button" class="admin-btn admin-btn-outline" style="padding:5px 12px; font-size:0.75rem;" onclick="ManagementHub.openEditMemberModal('${u.id}')">
                        <i class="fa-solid fa-pen"></i> Düzenle
                    </button>
                </td>
            </tr>
        `;
    },

    filterMemberRows(query) {
        const q = (query || '').trim().toLowerCase();
        document.querySelectorAll('#admin-members-tbody tr[data-member-search]').forEach(row => {
            const blob = row.getAttribute('data-member-search') || '';
            row.style.display = !q || blob.includes(q) ? '' : 'none';
        });
    },

    openEditMemberModal(userId) {
        const user = (State.data.users || []).find(u => String(u.id) === String(userId));
        if (!user) return Toast.error('Kullanıcı bulunamadı.');

        const modal = document.getElementById('admin-modal');
        const content = document.getElementById('admin-modal-content');
        if (!modal || !content) return;

        const roles = ['user', 'member', 'admin', 'moderator', 'translator', 'editor', 'uploader', 'social_mod', 'support_staff'];
        const userXp = user.stats?.xp ?? 0;
        const userCoins = user.stats?.coins ?? 0;
        content.innerHTML = `
            <div class="modal-header-premium">
                <h3 style="margin:0; color:#fff;"><i class="fa-solid fa-user-pen"></i> Üye Düzenle: ${user.username}</h3>
                <button type="button" onclick="document.getElementById('admin-modal').style.display='none'" style="background:none;border:none;color:#64748b;font-size:1.5rem;cursor:pointer;">&times;</button>
            </div>
            <div class="modal-body-premium" style="padding:25px;">
                <div class="admin-form-row" style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                    <div class="form-group">
                        <label style="display:block;margin-bottom:6px;color:#cbd5e1;font-weight:600;">XP</label>
                        <input type="number" id="edit-member-xp" class="admin-form-input" value="${userXp}" min="0" style="width:100%;">
                    </div>
                    <div class="form-group">
                        <label style="display:block;margin-bottom:6px;color:#cbd5e1;font-weight:600;">Para (Coin)</label>
                        <input type="number" id="edit-member-coins" class="admin-form-input" value="${userCoins}" min="0" style="width:100%;">
                    </div>
                </div>
                <div class="form-group" style="margin-bottom:15px;">
                    <label style="display:block;margin-bottom:6px;color:#cbd5e1;font-weight:600;">Rol</label>
                    <select id="edit-member-role" class="admin-form-input" style="width:100%;">
                        ${roles.map(r => `<option value="${r}" ${user.role === r ? 'selected' : ''}>${r}</option>`).join('')}
                    </select>
                </div>
                <div class="form-group" style="margin-bottom:15px;">
                    <label style="display:block;margin-bottom:6px;color:#cbd5e1;font-weight:600;">Hesap Durumu</label>
                    <select id="edit-member-status" class="admin-form-input" style="width:100%;">
                        <option value="active" ${!user.banned ? 'selected' : ''}>Aktif</option>
                        <option value="banned" ${user.banned ? 'selected' : ''}>Yasaklı</option>
                    </select>
                </div>
                <button type="button" class="admin-btn admin-btn-primary" style="width:100%; padding:12px;" onclick="ManagementHub.saveMemberEdit('${user.id}')">
                    <i class="fa-solid fa-floppy-disk"></i> Kaydet
                </button>
            </div>
        `;
        modal.style.display = 'flex';
    },

    async saveMemberEdit(userId) {
        const user = (State.data.users || []).find(u => String(u.id) === String(userId));
        if (!user) return Toast.error('Kullanıcı bulunamadı.');

        const role = document.getElementById('edit-member-role')?.value || user.role;
        const status = document.getElementById('edit-member-status')?.value || 'active';
        const xp = parseInt(document.getElementById('edit-member-xp')?.value, 10);
        const coins = parseInt(document.getElementById('edit-member-coins')?.value, 10);
        if (!user.stats) user.stats = {};
        const updates = {
            role,
            banned: status === 'banned',
            status: status === 'banned' ? 'Yasaklı' : 'Aktif',
            stats: {
                ...user.stats,
                xp: Number.isFinite(xp) ? xp : (user.stats.xp || 0),
                coins: Number.isFinite(coins) ? coins : (user.stats.coins || 0)
            }
        };

        Toast.info('Kaydediliyor...');
        const ok = await db.updateMember(userId, updates);
        if (ok) {
            Toast.success(`${user.username} güncellendi.`);
            document.getElementById('admin-modal').style.display = 'none';
            const tbody = document.getElementById('admin-members-tbody');
            if (tbody) {
                const searchVal = document.getElementById('admin-member-search')?.value || '';
                tbody.innerHTML = (State.data.users || []).map(u => this.memberRowHtml(u)).join('');
                if (searchVal) this.filterMemberRows(searchVal);
            } else {
                this.switchTab('users');
            }
        } else {
            Toast.error('Kayıt başarısız.');
        }
    },

    renderLogs(container) {
        const logs = State.data.logs || [];
        container.innerHTML = `
            <div class="data-card" style="padding: 30px;">
                <table class="admin-table">
                    <thead><tr><th>Tarih</th><th>Kullanıcı</th><th>İşlem</th><th>Mesaj</th></tr></thead>
                    <tbody>
                        ${logs.reverse().map(log => `
                            <tr>
                                <td style="font-size:0.8rem; color:var(--admin-text-muted);">${new Date(log.timestamp).toLocaleString()}</td>
                                <td>${log.username || 'System'}</td>
                                <td><b>${log.action}</b></td>
                                <td style="font-size:0.85rem;">${log.message}</td>
                            </tr>
                        `).join('') || '<tr><td colspan="4" style="text-align:center; padding:20px;">Log kaydı yok.</td></tr>'}
                    </tbody>
                </table>
            </div>
        `;
    },

    settingsSubTab: 'site',

    renderSettings(container) {
        const subTab = this.settingsSubTab || 'site';
        
        // Fetch site settings
        const settingsArray = State.data.settings || [];
        const siteSettings = Array.isArray(settingsArray)
            ? (settingsArray.find(s => s.id === 'site_settings') || {})
            : (settingsArray || {});

        // Fetch user customization settings
        const user = State.currentUser;
        const personalSettings = (user && user.adminCustomization) || {
            theme: 'default',
            sidebar: 'left',
            widgets: { stats: true, charts: true, recent: true }
        };

        const themes = [
            { key: 'default', name: 'Klasik Koyu (Default)', color: '#8b5cf6', bg: '#06070c' },
            { key: 'amoled', name: 'AMOLED Gece Siyahı', color: '#7c3aed', bg: '#000000' },
            { key: 'safir', name: 'Sihirli Safir Mavisi', color: '#38bdf8', bg: '#0f172a' },
            { key: 'purple_midnight', name: 'Neon Mor Parıltı', color: '#a78bfa', bg: '#0f0f13' },
            { key: 'gold_premium', name: 'Kraliyet Altın Vurgu', color: '#fbbf24', bg: '#0a0a0a' },
            { key: 'emerald', name: 'Zümrüt Yeşil Ormanı', color: '#34d399', bg: '#064e3b' }
        ];

        let contentHTML = '';

        if (subTab === 'site') {
            contentHTML = `
                <div style="display: grid; gap: 25px;">
                    <div class="form-group">
                        <label style="display:block; margin-bottom:8px; font-weight:700; color:#cbd5e1;">Site Başlığı</label>
                        <input type="text" id="settings-site-name" class="admin-form-input" value="${siteSettings.siteName || 'DramicBox'}" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;">
                    </div>
                    <div class="form-group">
                        <label style="display:block; margin-bottom:8px; font-weight:700; color:#cbd5e1;">Bakım Modu</label>
                        <select id="settings-maintenance-mode" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;">
                            <option value="false" ${!siteSettings.maintenanceMode ? 'selected' : ''}>Kapalı</option>
                            <option value="true" ${siteSettings.maintenanceMode ? 'selected' : ''}>Açık (Sadece Adminler Erişebilir)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="display:block; margin-bottom:8px; font-weight:700; color:#cbd5e1;">Ekran Görüntüsü ve Geliştirici Araçları Engelleme</label>
                        <select id="settings-screenshot-protection" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;">
                            <option value="false" ${!siteSettings.screenshotProtectionEnabled ? 'selected' : ''}>Kapalı</option>
                            <option value="true" ${siteSettings.screenshotProtectionEnabled ? 'selected' : ''}>Açık (Görüntü Alma & DevTools Bloklanır)</option>
                        </select>
                    </div>
                    
                    <div style="border-top: 1px solid var(--admin-border); padding-top: 20px; margin-top: 10px;">
                        <h4 style="color:#fbbf24; margin-bottom:15px; font-weight:800; font-size:1rem;"><i class="fa-solid fa-triangle-exclamation"></i> Oynatıcı Kaynak Uyarı Mesajları</h4>
                        <p style="color:var(--admin-text-muted); font-size:0.8rem; margin-bottom:20px;">VK, OK ve Moly video oynatıcı kaynakları aktif olduğunda oynatıcının altında gösterilecek özel açıklama metinlerini ayarlayın.</p>
                        
                        <div class="form-group" style="margin-bottom:15px;">
                            <label style="display:block; margin-bottom:8px; font-weight:600; color:#cbd5e1;">VK Kaynak Uyarısı</label>
                            <textarea id="settings-warning-vk" class="admin-form-textarea" rows="2" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;" placeholder="Boş bırakılırsa varsayılan mesaj gösterilir...">${siteSettings.warningVK || ''}</textarea>
                        </div>
                        <div class="form-group" style="margin-bottom:15px;">
                            <label style="display:block; margin-bottom:8px; font-weight:600; color:#cbd5e1;">OK.ru Kaynak Uyarısı</label>
                            <textarea id="settings-warning-ok" class="admin-form-textarea" rows="2" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;" placeholder="Boş bırakılırsa varsayılan mesaj gösterilir...">${siteSettings.warningOK || ''}</textarea>
                        </div>
                        <div class="form-group" style="margin-bottom:15px;">
                            <label style="display:block; margin-bottom:8px; font-weight:600; color:#cbd5e1;">Moly Kaynak Uyarısı</label>
                            <textarea id="settings-warning-moly" class="admin-form-textarea" rows="2" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;" placeholder="Boş bırakılırsa varsayılan mesaj gösterilir...">${siteSettings.warningMoly || ''}</textarea>
                        </div>
                    </div>

                    <div style="display: flex; justify-content: flex-end; margin-top: 15px;">
                        <button class="admin-btn admin-btn-primary" onclick="ManagementHub.saveSiteSettings()" style="height:48px; font-weight:800; font-size:0.95rem; padding: 0 35px;">
                            Sistem Ayarlarını Kaydet
                        </button>
                    </div>
                </div>
            `;
        } else {
            contentHTML = `
                <div style="display: grid; gap: 30px;">
                    <!-- Theme Selector -->
                    <div>
                        <label style="display: block; margin-bottom: 12px; font-weight: 700; font-size: 0.9rem; color: #cbd5e1;">Arayüz Teması</label>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px;">
                            ${themes.map(t => {
                                const isSelected = (personalSettings.theme || 'default') === t.key;
                                return `
                                    <div class="theme-option-card ${isSelected ? 'selected' : ''}" 
                                         onclick="ManagementHub.selectAdminTheme('${t.key}')"
                                         style="background:${t.bg}; border:2px solid ${isSelected ? 'var(--admin-accent)' : 'rgba(255,255,255,0.05)'}; padding:15px; border-radius:14px; cursor:pointer; text-align:center; transition:0.3s; position:relative;">
                                        <div style="width:20px; height:20px; border-radius:50%; background:${t.color}; margin:0 auto 10px; box-shadow:0 0 10px ${t.color}80;"></div>
                                        <div style="font-size:0.75rem; font-weight:700; color:#fff;">${t.name}</div>
                                        ${isSelected ? `<i class="fa-solid fa-circle-check" style="position:absolute; top:8px; right:8px; color:var(--admin-accent); font-size:0.9rem;"></i>` : ''}
                                    </div>
                                `;
                            }).join('')}
                        </div>
                        <input type="hidden" id="admin-custom-theme" value="${personalSettings.theme || 'default'}">
                    </div>

                    <!-- Sidebar Position Selector -->
                    <div>
                        <label style="display: block; margin-bottom: 12px; font-weight: 700; font-size: 0.9rem; color: #cbd5e1;">Menü (Sidebar) Pozisyonu</label>
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px;">
                            <div class="sidebar-option-card ${(personalSettings.sidebar || 'left') === 'left' ? 'selected' : ''}"
                                 onclick="ManagementHub.selectAdminSidebar('left')"
                                 style="background:rgba(255,255,255,0.02); border:2px solid ${(personalSettings.sidebar || 'left') === 'left' ? 'var(--admin-accent)' : 'rgba(255,255,255,0.05)'}; padding:15px; border-radius:14px; cursor:pointer; text-align:center; transition:0.3s;">
                                 <i class="fa-solid fa-align-left" style="font-size:1.2rem; margin-bottom:8px; color:var(--admin-text-muted);"></i>
                                 <div style="font-size:0.75rem; font-weight:700; color:#fff;">Sol Kenar (Standart)</div>
                            </div>
                            <div class="sidebar-option-card ${personalSettings.sidebar === 'right' ? 'selected' : ''}"
                                 onclick="ManagementHub.selectAdminSidebar('right')"
                                 style="background:rgba(255,255,255,0.02); border:2px solid ${personalSettings.sidebar === 'right' ? 'var(--admin-accent)' : 'rgba(255,255,255,0.05)'}; padding:15px; border-radius:14px; cursor:pointer; text-align:center; transition:0.3s;">
                                 <i class="fa-solid fa-align-right" style="font-size:1.2rem; margin-bottom:8px; color:var(--admin-text-muted);"></i>
                                 <div style="font-size:0.75rem; font-weight:700; color:#fff;">Sağ Kenar</div>
                            </div>
                            <div class="sidebar-option-card ${personalSettings.sidebar === 'compact' ? 'selected' : ''}"
                                 onclick="ManagementHub.selectAdminSidebar('compact')"
                                 style="background:rgba(255,255,255,0.02); border:2px solid ${personalSettings.sidebar === 'compact' ? 'var(--admin-accent)' : 'rgba(255,255,255,0.05)'}; padding:15px; border-radius:14px; cursor:pointer; text-align:center; transition:0.3s;">
                                 <i class="fa-solid fa-compress" style="font-size:1.2rem; margin-bottom:8px; color:var(--admin-text-muted);"></i>
                                 <div style="font-size:0.75rem; font-weight:700; color:#fff;">Sadece Simgeler (Kompakt)</div>
                            </div>
                        </div>
                        <input type="hidden" id="admin-custom-sidebar" value="${personalSettings.sidebar || 'left'}">
                    </div>

                    <!-- Dashboard Widgets Visibility -->
                    <div>
                        <label style="display: block; margin-bottom: 12px; font-weight: 700; font-size: 0.9rem; color: #cbd5e1;">Dashboard Panelleri Görünürlüğü</label>
                        <div style="display: flex; flex-direction: column; gap: 12px; background:rgba(0,0,0,0.15); padding:20px; border-radius:14px; border:1px solid rgba(255,255,255,0.05);">
                            <label style="display:flex; align-items:center; gap:12px; cursor:pointer; color:#fff; font-size:0.85rem;">
                                <input type="checkbox" id="widget-stats" ${personalSettings.widgets?.stats !== false ? 'checked' : ''} style="width:18px; height:18px; accent-color:var(--admin-accent);">
                                İstatistik Özet Kartları (Üye, Dizi, Onay vb.)
                            </label>
                            <label style="display:flex; align-items:center; gap:12px; cursor:pointer; color:#fff; font-size:0.85rem;">
                                <input type="checkbox" id="widget-charts" ${personalSettings.widgets?.charts !== false ? 'checked' : ''} style="width:18px; height:18px; accent-color:var(--admin-accent);">
                                Ziyaretçi & İzlenme İstatistik Grafiği (Visitor Chart)
                            </label>
                            <label style="display:flex; align-items:center; gap:12px; cursor:pointer; color:#fff; font-size:0.85rem;">
                                <input type="checkbox" id="widget-recent" ${personalSettings.widgets?.recent !== false ? 'checked' : ''} style="width:18px; height:18px; accent-color:var(--admin-accent);">
                                Son Sistem Aktiviteleri Listesi (Recent Activities)
                            </label>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 10px; border-top: 1px solid var(--admin-border); padding-top: 20px;">
                        <button class="admin-btn admin-btn-outline" onclick="ManagementHub.resetAdminCustomization()" style="height:45px; font-weight:700;">
                            <i class="fa-solid fa-rotate-left"></i> Varsayılana Sıfırla
                        </button>
                        <button class="admin-btn admin-btn-primary" onclick="ManagementHub.saveAdminSettings()" style="height:45px; font-weight:800; font-size:0.95rem; padding: 0 30px;">
                            Kişiselleştirmeyi Kaydet
                        </button>
                    </div>
                </div>
            `;
        }

        container.innerHTML = `
            <div class="data-card fade-in" style="padding: 40px; max-width: 800px; margin: 0 auto; background: var(--admin-sidebar); border: 1px solid var(--admin-border); border-radius: 24px;">
                <div class="settings-tabs" style="display:flex; gap:10px; margin-bottom:30px; border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:15px;">
                    <button class="admin-tab-btn ${subTab === 'site' ? 'active' : ''}" onclick="ManagementHub.switchSettingsSubTab('site')" style="background:none; border:none; color:${subTab === 'site' ? '#a78bfa' : '#64748b'}; font-weight:800; font-size:1rem; cursor:pointer; padding:8px 16px; border-radius:8px; transition:0.2s;">
                        <i class="fa-solid fa-gears" style="margin-right:8px;"></i> Sistem Site Ayarları
                    </button>
                    <button class="admin-tab-btn ${subTab === 'personal' ? 'active' : ''}" onclick="ManagementHub.switchSettingsSubTab('personal')" style="background:none; border:none; color:${subTab === 'personal' ? '#a78bfa' : '#64748b'}; font-weight:800; font-size:1rem; cursor:pointer; padding:8px 16px; border-radius:8px; transition:0.2s;">
                        <i class="fa-solid fa-sliders" style="margin-right:8px;"></i> Panel Özelleştirme
                    </button>
                </div>
                
                <div id="settings-tab-content">
                    ${contentHTML}
                </div>
            </div>
            
            <style>
                .admin-tab-btn.active {
                    background: rgba(167, 139, 250, 0.1) !important;
                    color: #a78bfa !important;
                }
                .admin-tab-btn:hover {
                    color: #fff !important;
                }
            </style>
        `;
    },

    switchSettingsSubTab(subTabId) {
        this.settingsSubTab = subTabId;
        this.render();
    },

    async saveSiteSettings() {
        const siteName = document.getElementById('settings-site-name').value.trim();
        const maintenanceMode = document.getElementById('settings-maintenance-mode').value === 'true';
        const screenshotProtectionEnabled = document.getElementById('settings-screenshot-protection').value === 'true';
        const warningVK = document.getElementById('settings-warning-vk').value.trim();
        const warningOK = document.getElementById('settings-warning-ok').value.trim();
        const warningMoly = document.getElementById('settings-warning-moly').value.trim();

        if (!siteName) {
            Toast.warning('Lütfen site adını giriniz.');
            return;
        }

        const siteSettings = {
            id: 'site_settings',
            siteName,
            maintenanceMode,
            screenshotProtectionEnabled,
            warningVK,
            warningOK,
            warningMoly,
            updatedAt: new Date().toISOString()
        };

        Toast.info('Ayarlar kaydediliyor...');
        const success = await db.saveItem('settings', 'site_settings', siteSettings);
        if (success) {
            Toast.success('Sistem ayarları başarıyla kaydedildi.');
            
            // Sync local State
            if (!State.data.settings) State.data.settings = [];
            if (Array.isArray(State.data.settings)) {
                const idx = State.data.settings.findIndex(s => s.id === 'site_settings');
                if (idx > -1) State.data.settings[idx] = siteSettings;
                else State.data.settings.push(siteSettings);
            } else {
                State.data.settings = siteSettings;
            }

            // Sync video protection in real time if function exists
            if (window.setupVideoProtection) {
                window.setupVideoProtection();
            }
            
            await this.refreshData();
        } else {
            Toast.error('Ayarlar kaydedilemedi.');
        }
    },

    async checkSystemHealth() {
        Toast.info('Sistem taranıyor...');
        try {
            const response = await fetch('api/db.php?action=system-health');
            const result = await response.json();
            if (result.success) {
                const h = result.mysql;
                const s = result.server;
                const statusColor = h.status === 'Connected' ? '#10b981' : '#ef4444';
                
                const modal = document.createElement('div');
                modal.className = 'modal';
                modal.style.display = 'flex';
                modal.innerHTML = `
                    <div class="data-card" style="width:90%; max-width:600px; padding:30px; position:relative; background:#0f0f14; border:1px solid var(--admin-border);">
                        <button onclick="this.closest('.modal').remove()" style="position:absolute; top:20px; right:20px; background:none; border:none; color:#fff; font-size:1.5rem; cursor:pointer;">&times;</button>
                        <h2 style="margin-bottom:20px;"><i class="fa-solid fa-microchip"></i> Sistem Sağlık Raporu</h2>
                        
                        <div style="display:grid; gap:15px;">
                            <div style="background:rgba(255,255,255,0.03); padding:15px; border-radius:12px; border-left:4px solid ${statusColor};">
                                <h4 style="margin-bottom:8px; color:${statusColor};">MySQL Bağlantısı: ${h.status}</h4>
                                <div style="font-size:0.85rem; color:var(--admin-text-muted);">
                                    <div>Host: ${h.host}</div>
                                    <div>DB: ${h.database}</div>
                                    <div>Tablo Sayısı: ${h.table_count}</div>
                                    ${h.error ? `<div style="color:#ef4444; margin-top:5px;">Hata: ${h.error}</div>` : ''}
                                </div>
                            </div>
                            
                            <div style="background:rgba(255,255,255,0.03); padding:15px; border-radius:12px;">
                                <h4 style="margin-bottom:8px;">Sunucu Bilgileri</h4>
                                <div style="font-size:0.85rem; color:var(--admin-text-muted);">
                                    <div>PHP Version: ${s.php_version}</div>
                                    <div>OS: ${s.os}</div>
                                    <div>Bellek Kullanımı: ${s.memory_usage}</div>
                                    <div>Yük: ${s.load}</div>
                                </div>
                            </div>
                            
                            <div style="font-size:0.75rem; text-align:center; color:var(--admin-text-muted); margin-top:10px;">
                                Rapor Zamanı: ${new Date(result.timestamp).toLocaleString()}
                            </div>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
            } else {
                Toast.error('Sistem raporu alınamadı: ' + result.message);
            }
        } catch (e) {
            Toast.error('Bağlantı hatası.');
        }
    },

    switchTab(tabId) {
        this.currentTab = tabId;
        this.render();
    },

    renderActors(container) {
        const actors = State.data.actors || [];
        container.innerHTML = `
            <div class="data-card" style="padding:30px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px;">
                    <h3>Aktör & Karakter Listesi</h3>
                    <button class="admin-btn admin-btn-primary" onclick="ManagementHub.openActorModal()"><i class="fa-solid fa-user-plus"></i> Yeni Aktör Eklensin</button>
                </div>
                <div class="actors-grid">
                    ${actors.map(actor => `
                        <div class="actor-admin-card">
                            <div class="actor-admin-avatar-container">
                                <img src="${actor.avatar || actor.image || 'assets/default-avatar.png'}" alt="${actor.name}" onerror="this.src='assets/default-avatar.png'">
                                <div class="actor-admin-glow"></div>
                            </div>
                            <div class="actor-admin-details">
                                <h4>${actor.name}</h4>
                                <p style="font-family: 'Noto Sans KR', sans-serif; color: var(--admin-accent); font-weight: 700;">${actor.koreanName || ''}</p>
                                <div class="actor-admin-meta">
                                    <div><i class="fa-solid fa-flag"></i> ${actor.country || 'Güney Kore'}</div>
                                    <div><i class="fa-solid fa-calendar"></i> ${actor.birthYear || '-'}</div>
                                    <div><i class="fa-solid fa-arrows-up-down"></i> ${actor.height || '-'} cm</div>
                                    <div><i class="fa-solid fa-droplet"></i> Kan: ${actor.bloodType || '-'}</div>
                                </div>
                                <div class="actor-admin-actions">
                                    <button class="admin-btn admin-btn-outline" style="flex:1; padding:8px 12px; font-size:0.8rem;" onclick="ManagementHub.openActorModal('${actor.id || actor.name}')"><i class="fa-solid fa-user-pen"></i> Düzenle</button>
                                    <button class="admin-btn admin-btn-outline" style="padding:8px 12px; font-size:0.8rem; color:var(--admin-warning);" onclick="ManagementHub.startElectionFromAdmin('${actor.id || actor.name}')" title="Başkanlık Seçimi Başlat"><i class="fa-solid fa-crown"></i></button>
                                    <button class="admin-btn admin-btn-outline" style="padding:8px 12px; font-size:0.8rem; color:var(--admin-danger);" onclick="ManagementHub.deleteActor('${actor.id || actor.name}', '${actor.name}')" title="Oyuncuyu Sil"><i class="fa-solid fa-trash-can"></i></button>
                                </div>
                            </div>
                        </div>
                    `).join('') || '<div style="grid-column: 1/-1; text-align:center; padding:50px; color:var(--admin-text-muted);">Veritabanında henüz aktör bulunmuyor.</div>'}
                </div>
            </div>
        `;
    },

    openActorModal(actorId = null) {
        const modal = document.getElementById('admin-modal');
        const content = document.getElementById('admin-modal-content');
        if (!modal || !content) return;

        let actor = null;
        if (actorId) {
            actor = (State.data.actors || []).find(a => a.id === actorId || a.name === actorId);
        }

        const isEdit = !!actor;
        const title = isEdit ? 'Aktör Künyesini Düzenle' : 'Yeni Aktör / Karakter Ekle';

        content.innerHTML = `
            <div class="modal-header-premium">
                <h3 style="margin:0; font-weight:800; color:#fff; display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-masks-theater" style="color:var(--admin-accent);"></i> ${title}</h3>
                <button onclick="ManagementHub.closeActorModal()" style="background:none; border:none; color:#64748b; font-size:1.5rem; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="modal-body-premium">
                <form id="admin-actor-form" onsubmit="event.preventDefault()">
                    <input type="hidden" id="actor-form-id" value="${actor?.id || ''}">
                    
                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Aktör Adı Soyadı</label>
                            <input type="text" id="actor-form-name" class="admin-form-input" value="${actor?.name || ''}" required placeholder="Örn: Lee Jae-wook">
                        </div>
                        <div class="admin-form-group">
                            <label>Korece Adı (Hangul)</label>
                            <input type="text" id="actor-form-korean" class="admin-form-input" value="${actor?.koreanName || ''}" placeholder="Örn: 이재욱">
                        </div>
                    </div>

                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Uyruk / Ülke</label>
                            <input type="text" id="actor-form-country" class="admin-form-input" value="${actor?.country || 'Güney Kore'}" placeholder="Örn: Güney Kore">
                        </div>
                        <div class="admin-form-group">
                            <label>Doğum Yılı</label>
                            <input type="text" id="actor-form-birthyear" class="admin-form-input" value="${actor?.birthYear || ''}" placeholder="Örn: 1998">
                        </div>
                    </div>

                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Doğum Tarihi</label>
                            <input type="date" id="actor-form-birthdate" class="admin-form-input" value="${actor?.birthDate || ''}">
                        </div>
                        <div class="admin-form-group">
                            <label>Burç</label>
                            <input type="text" id="actor-form-zodiac" class="admin-form-input" value="${actor?.zodiac || ''}" placeholder="Örn: Boğa">
                        </div>
                    </div>

                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Boy (cm)</label>
                            <input type="text" id="actor-form-height" class="admin-form-input" value="${actor?.height || ''}" placeholder="Örn: 187">
                        </div>
                        <div class="admin-form-group">
                            <label>Kilo (kg)</label>
                            <input type="text" id="actor-form-weight" class="admin-form-input" value="${actor?.weight || ''}" placeholder="Örn: 75">
                        </div>
                    </div>

                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Kan Grubu</label>
                            <input type="text" id="actor-form-blood" class="admin-form-input" value="${actor?.bloodType || ''}" placeholder="Örn: O">
                        </div>
                        <div class="admin-form-group">
                            <label>Ayak Numarası</label>
                            <input type="text" id="actor-form-foot" class="admin-form-input" value="${actor?.footSize || ''}" placeholder="Örn: 43">
                        </div>
                    </div>

                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Göz Rengi</label>
                            <input type="text" id="actor-form-eye" class="admin-form-input" value="${actor?.eyeColor || ''}" placeholder="Örn: Kahverengi">
                        </div>
                        <div class="admin-form-group">
                            <label>Giyim Bedeni</label>
                            <input type="text" id="actor-form-clothing" class="admin-form-input" value="${actor?.clothingSize || ''}" placeholder="Örn: XL">
                        </div>
                    </div>

                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Avatar Resim URL</label>
                            <input type="text" id="actor-form-avatar" class="admin-form-input" value="${actor?.avatar || actor?.image || ''}" placeholder="Örn: https://...">
                        </div>
                        <div class="admin-form-group">
                            <label>Instagram Kullanıcı Adı</label>
                            <input type="text" id="actor-form-instagram" class="admin-form-input" value="${actor?.social?.instagram || ''}" placeholder="Örn: jxxvvxxk">
                        </div>
                    </div>

                    <div class="admin-form-row">
                        <div class="admin-form-group">
                            <label>Kart Nadirlik Derecesi (Rarity)</label>
                            <select id="actor-form-rarity" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                                <option value="Common" ${actor?.rarity === 'Common' ? 'selected' : ''}>Yaygın (Common)</option>
                                <option value="Rare" ${actor?.rarity === 'Rare' ? 'selected' : ''}>Nadir (Rare)</option>
                                <option value="Epic" ${actor?.rarity === 'Epic' ? 'selected' : ''}>Epik (Epic)</option>
                                <option value="Legendary" ${actor?.rarity === 'Legendary' ? 'selected' : ''}>Efsanevi (Legendary)</option>
                            </select>
                        </div>
                        <div class="admin-form-group">
                            <label>Sandık Çıkma Durumu</label>
                            <select id="actor-form-collectible" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                                <option value="true" ${actor?.isCollectible !== false ? 'selected' : ''}>Koleksiyon Kartı Olarak Çıkabilir</option>
                                <option value="false" ${actor?.isCollectible === false ? 'selected' : ''}>Sandıklardan Çıkamaz (Sadece Aktör)</option>
                            </select>
                        </div>
                    </div>

                    <div class="admin-form-group">
                        <label>Biyografi</label>
                        <textarea id="actor-form-bio" class="admin-form-textarea" rows="4" placeholder="Oyuncunun hayat hikayesi veya karakter biyografisi...">${actor?.bio || ''}</textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer-premium">
                <button class="admin-btn admin-btn-outline" onclick="ManagementHub.closeActorModal()">Vazgeç</button>
                <button class="admin-btn admin-btn-primary" onclick="ManagementHub.saveActor()">${isEdit ? 'Güncelle' : 'Kaydet'}</button>
            </div>
        `;
        modal.style.display = 'flex';
    },

    closeActorModal() {
        const modal = document.getElementById('admin-modal');
        if (modal) modal.style.display = 'none';
    },

    async saveActor() {
        const name = document.getElementById('actor-form-name').value.trim();
        if (!name) {
            Toast.warning('Lütfen aktör ismini girin!');
            return;
        }

        const id = document.getElementById('actor-form-id').value || 'act-' + Date.now();
        const existingActor = (State.data.actors || []).find(a => a.id === id || a.name === name);

        const actorData = {
            id: id,
            name: name,
            koreanName: document.getElementById('actor-form-korean').value.trim(),
            country: document.getElementById('actor-form-country').value.trim(),
            birthYear: document.getElementById('actor-form-birthyear').value.trim(),
            birthDate: document.getElementById('actor-form-birthdate').value,
            zodiac: document.getElementById('actor-form-zodiac').value.trim(),
            height: document.getElementById('actor-form-height').value.trim(),
            weight: document.getElementById('actor-form-weight').value.trim(),
            bloodType: document.getElementById('actor-form-blood').value.trim(),
            footSize: document.getElementById('actor-form-foot').value.trim(),
            eyeColor: document.getElementById('actor-form-eye').value.trim(),
            clothingSize: document.getElementById('actor-form-clothing').value.trim(),
            avatar: document.getElementById('actor-form-avatar').value.trim() || 'assets/default-avatar.png',
            bio: document.getElementById('actor-form-bio').value.trim(),
            social: {
                instagram: document.getElementById('actor-form-instagram').value.trim()
            },
            rarity: document.getElementById('actor-form-rarity').value,
            isCollectible: document.getElementById('actor-form-collectible').value === 'true',
            ratings: existingActor?.ratings || [],
            fanCenter: existingActor?.fanCenter || {
                presidentId: null,
                members: [],
                posts: [],
                polls: [],
                gallery: []
            },
            updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
        };

        Toast.info('Oyuncu veritabanına yazılıyor...');
        const success = await db.saveItem('actors', actorData.name, actorData);
        if (success) {
            Toast.success('Aktör başarıyla kaydedildi.');
            ManagementHub.closeActorModal();
            await ManagementHub.refreshData();
        } else {
            Toast.error('Kaydetme başarısız oldu.');
        }
    },

    async deleteActor(actorId, actorName) {
        if (!confirm(`${actorName} aktörünü ve fan kulübünü tamamen silmek istediğinize emin misiniz?`)) return;
        Toast.info('Aktör siliniyor...');
        
        // Pass actorName because it serves as the filename/primary key in our dual-mode Database.php
        const success = await db.deleteItem('actors', actorName);
        if (success) {
            Toast.success('Aktör başarıyla silindi.');
            await ManagementHub.refreshData();
        } else {
            Toast.error('Silme işlemi başarısız.');
        }
    },

    openContentModal(type, itemId = null) {
        if (type === 'series' && itemId && window.SeriesEdit) {
            SeriesEdit.open(itemId);
            return;
        }

        const modal = document.getElementById('admin-modal');
        const content = document.getElementById('admin-modal-content');
        if (!modal || !content) return;

        const items = State.data[type] || [];
        let item = null;
        if (itemId) {
            item = items.find(i => String(i.id) === String(itemId));
        }

        const isEdit = !!item;
        let title = '';
        if (type === 'series') title = isEdit ? 'Dizi Düzenle' : 'Yeni Dizi Ekle';
        else if (type === 'webtoons') title = isEdit ? 'Webtoon Düzenle' : 'Yeni Webtoon Ekle';
        else title = isEdit ? 'Blog Yazısı Düzenle' : 'Yeni Blog Yazısı Ekle';

        let formContent = '';
        if (type === 'blogPosts') {
            formContent = `
                <div class="admin-form-group" style="margin-bottom:15px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Başlık</label>
                    <input type="text" id="content-form-title" class="admin-form-input" value="${item?.title || ''}" required placeholder="Blog Başlığı" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                </div>
                <div class="admin-form-group" style="margin-bottom:15px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Kategori</label>
                    <select id="content-form-category" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                        <option value="news" ${item?.category === 'news' ? 'selected' : ''}>Haber</option>
                        <option value="review" ${item?.category === 'review' ? 'selected' : ''}>İnceleme</option>
                        <option value="theory" ${item?.category === 'theory' ? 'selected' : ''}>Teori</option>
                        <option value="guide" ${item?.category === 'guide' ? 'selected' : ''}>Rehber</option>
                    </select>
                </div>
                <div class="admin-form-group" style="margin-bottom:15px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Görsel URL</label>
                    <input type="text" id="content-form-image" class="admin-form-input" value="${item?.image || ''}" placeholder="Resim URL" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                </div>
                <div class="admin-form-group" style="margin-bottom:15px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Yazar</label>
                    <input type="text" id="content-form-author" class="admin-form-input" value="${item?.author || State.currentUser?.username || 'Admin'}" placeholder="Yazar Adı" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                </div>
                <div class="admin-form-group" style="margin-bottom:15px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">İçerik</label>
                    <textarea id="content-form-body" class="admin-form-textarea" rows="8" placeholder="Yazı içeriği..." style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px; font-family:inherit;">${item?.content || ''}</textarea>
                </div>
            `;
        } else {
            const genreOptions = ['Dram', 'Romantik', 'Komedi', 'Aksiyon', 'Gerilim', 'Fantastik', 'Tarih', 'Bilim Kurgu', 'Korku', 'Gizem', 'Aile', 'Gençlik', 'Müzikal', 'Spor'];
            const selectedGenres = new Set((Array.isArray(item?.genres) ? item.genres : (item?.genres ? String(item.genres).split(',') : [])).map(g => g.trim()));
            const ageRating = item?.ageRating || 'Genel';
            formContent = `
                <div class="admin-form-row" style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Başlık</label>
                        <input type="text" id="content-form-title" class="admin-form-input" value="${item?.title || ''}" required placeholder="İçerik Başlığı" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Korece İsim</label>
                        <input type="text" id="content-form-korean" class="admin-form-input" value="${item?.koreanTitle || item?.originalTitle || ''}" placeholder="예: 드라마 제목" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                </div>
                <div class="admin-form-row" style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">İçerik Türü</label>
                        <select id="content-form-subtype" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                            <option value="drama" ${item?.type === 'drama' || item?.type === 'dizi' ? 'selected' : ''}>Dizi (KDrama)</option>
                            <option value="webtoon" ${item?.type === 'webtoon' ? 'selected' : ''}>Webtoon</option>
                            <option value="movie" ${item?.type === 'movie' || item?.type === 'film' ? 'selected' : ''}>Film</option>
                            <option value="anime" ${item?.type === 'anime' ? 'selected' : ''}>Anime</option>
                        </select>
                    </div>
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Yaş Kitlesi</label>
                        <select id="content-form-age" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                            ${['Genel', '13+', '16+', '18+', '21+'].map(a => `<option value="${a}" ${ageRating === a ? 'selected' : ''}>${a}</option>`).join('')}
                        </select>
                    </div>
                </div>
                <div class="admin-form-row" style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Yayın Durumu</label>
                        <select id="content-form-status" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                            <option value="Aktif" ${item?.status === 'Aktif' ? 'selected' : ''}>Aktif</option>
                            <option value="Devam Ediyor" ${item?.status === 'Devam Ediyor' ? 'selected' : ''}>Devam Ediyor</option>
                            <option value="Yakında" ${item?.status === 'Yakında' ? 'selected' : ''}>Yakında</option>
                            <option value="Tamamlandı" ${item?.status === 'Tamamlandı' ? 'selected' : ''}>Tamamlandı</option>
                        </select>
                    </div>
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Yıl</label>
                        <input type="number" id="content-form-year" class="admin-form-input" value="${item?.year || new Date().getFullYear()}" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                </div>
                <div class="admin-form-row" style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Ülke</label>
                        <input type="text" id="content-form-country" class="admin-form-input" value="${item?.country || 'Güney Kore'}" placeholder="Güney Kore" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Türler (Seçim)</label>
                        <div id="content-form-genres-grid" style="display:flex; flex-wrap:wrap; gap:8px; padding:10px; background:rgba(255,255,255,0.03); border:1px solid var(--admin-border); border-radius:8px; max-height:120px; overflow-y:auto;">
                            ${genreOptions.map(g => `
                                <label style="display:flex; align-items:center; gap:6px; font-size:0.8rem; color:#e2e8f0; cursor:pointer; background:rgba(255,255,255,0.04); padding:4px 10px; border-radius:20px;">
                                    <input type="checkbox" class="content-genre-cb" value="${g}" ${selectedGenres.has(g) ? 'checked' : ''}>
                                    ${g}
                                </label>
                            `).join('')}
                        </div>
                    </div>
                </div>
                <div class="admin-form-row" style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Afiş Resim URL (Poster)</label>
                        <input type="text" id="content-form-poster" class="admin-form-input" value="${item?.poster || ''}" placeholder="https://..." style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                    <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Kapak Resim URL (Cover)</label>
                        <input type="text" id="content-form-cover" class="admin-form-input" value="${item?.coverImage || ''}" placeholder="https://..." style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                </div>
                <div class="admin-form-group" style="margin-bottom:15px; display:flex; flex-direction:column; gap:6px;">
                    <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Özet / Açıklama</label>
                    <textarea id="content-form-description" class="admin-form-textarea" rows="4" placeholder="Konusu..." style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px; font-family:inherit;">${item?.description || item?.synopsis || ''}</textarea>
                </div>
                <div class="admin-form-row" style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:15px; margin-bottom:15px; background:rgba(255,255,255,0.02); padding:15px; border-radius:10px; border:1px solid rgba(255,255,255,0.05);">
                    <label style="display:flex; align-items:center; gap:8px; color:#fff; font-size:0.85rem; cursor:pointer;">
                        <input type="checkbox" id="content-form-vip" ${item?.isVip ? 'checked' : ''} style="width:16px; height:16px; accent-color:var(--admin-accent);">
                        👑 VIP İçerik
                    </label>
                    <label style="display:flex; align-items:center; gap:8px; color:#fff; font-size:0.85rem; cursor:pointer;">
                        <input type="checkbox" id="content-form-hidden" ${item?.isHidden ? 'checked' : ''} style="width:16px; height:16px; accent-color:var(--admin-accent);">
                        🔒 Gizli (Listede Gizle)
                    </label>
                    <label style="display:flex; align-items:center; gap:8px; color:#fff; font-size:0.85rem; cursor:pointer;">
                        <input type="checkbox" id="content-form-hero" ${item?.isHeroSlider ? 'checked' : ''} style="width:16px; height:16px; accent-color:var(--admin-accent);">
                        ✨ Hero Slider'da Göster
                    </label>
                </div>
            `;
        }

        content.innerHTML = `
            <div class="modal-header-premium" style="padding:20px; border-bottom:1px solid var(--admin-border); display:flex; justify-content:space-between; align-items:center;">
                <h3 style="margin:0; font-weight:800; color:#fff;">${title}</h3>
                <button onclick="document.getElementById('admin-modal').style.display='none'" style="background:none; border:none; color:#64748b; font-size:1.5rem; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="modal-body-premium" style="padding:25px;">
                <form id="admin-content-form" onsubmit="event.preventDefault()">
                    <input type="hidden" id="content-form-id" value="${item?.id || ''}">
                    ${formContent}
                </form>
            </div>
            <div class="modal-footer-premium" style="padding:20px; display:flex; justify-content:flex-end; gap:10px; border-top:1px solid var(--admin-border);">
                <button class="admin-btn admin-btn-outline" onclick="document.getElementById('admin-modal').style.display='none'">Vazgeç</button>
                <button class="admin-btn admin-btn-primary" onclick="ManagementHub.saveContent('${type}')">${isEdit ? 'Güncelle' : 'Kaydet'}</button>
            </div>
        `;
        modal.style.display = 'flex';
    },

    async saveContent(type) {
        const id = document.getElementById('content-form-id').value || 'item-' + Date.now();
        const title = document.getElementById('content-form-title').value.trim();
        if (!title) return Toast.warning('Lütfen başlık girin!');

        let itemData = {};

        if (type === 'blogPosts') {
            itemData = {
                id,
                title,
                category: document.getElementById('content-form-category').value,
                image: document.getElementById('content-form-image').value.trim() || 'assets/logo.png',
                author: document.getElementById('content-form-author').value.trim() || 'Admin',
                content: document.getElementById('content-form-body').value.trim(),
                createdAt: new Date().toISOString()
            };
        } else {
            const existing = (State.data.series || []).find(s => String(s.id) === String(id))
                || (State.data.webtoons || []).find(s => String(s.id) === String(id));
            const genresArray = Array.from(document.querySelectorAll('.content-genre-cb:checked')).map(cb => cb.value);
            const koreanTitle = document.getElementById('content-form-korean')?.value?.trim() || '';
            const subType = document.getElementById('content-form-subtype').value;

            const isVip = document.getElementById('content-form-vip').checked;
            const isHidden = document.getElementById('content-form-hidden').checked;
            const isHeroSlider = document.getElementById('content-form-hero').checked;

            itemData = {
                id,
                title,
                type: subType,
                status: document.getElementById('content-form-status').value,
                year: parseInt(document.getElementById('content-form-year').value) || new Date().getFullYear(),
                country: document.getElementById('content-form-country').value.trim() || 'Güney Kore',
                genres: genresArray,
                genre: genresArray.join(', '),
                koreanTitle,
                originalTitle: koreanTitle || existing?.originalTitle || '',
                ageRating: document.getElementById('content-form-age')?.value || 'Genel',
                poster: document.getElementById('content-form-poster').value.trim() || 'assets/poster-placeholder.jpg',
                coverImage: document.getElementById('content-form-cover').value.trim() || 'assets/poster-placeholder.jpg',
                description: document.getElementById('content-form-description').value.trim(),
                isVip,
                isHidden,
                isHeroSlider,
                episodes: existing?.episodes || [],
                seasons: existing?.seasons || null,
                cast: existing?.cast || []
            };
        }

        Toast.info('İçerik kaydediliyor...');
        const success = await db.saveItem(type, itemData.id, itemData);
        if (success) {
            Toast.success('İçerik başarıyla kaydedildi.');
            document.getElementById('admin-modal').style.display = 'none';
            await this.refreshData();
        } else {
            Toast.error('Kaydetme hatası.');
        }
    },

    async deleteContent(type, id, title) {
        if (!confirm(`"${title}" içeriğini silmek istediğinize emin misiniz?`)) return;
        Toast.info('Siliniyor...');
        const success = await db.deleteItem(type, id);
        if (success) {
            Toast.success('İçerik silindi.');
            await this.refreshData();
        } else {
            Toast.error('Silme hatası.');
        }
    },

    openJournalModal(journalId = null) {
        const modal = document.getElementById('admin-modal');
        const content = document.getElementById('admin-modal-content');
        if (!modal || !content) return;

        const journals = State.data.journals || [];
        let journal = null;
        if (journalId) {
            journal = journals.find(j => String(j.id) === String(journalId));
        }

        const isEdit = !!journal;
        const title = isEdit ? 'Dergiyi Düzenle' : 'Yeni Dergi Sayısı Ekle';

        content.innerHTML = `
            <div class="modal-header-premium" style="padding:20px; border-bottom:1px solid var(--admin-border); display:flex; justify-content:space-between; align-items:center;">
                <h3 style="margin:0; font-weight:800; color:#fff;">${title}</h3>
                <button onclick="document.getElementById('admin-modal').style.display='none'" style="background:none; border:none; color:#64748b; font-size:1.5rem; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="modal-body-premium" style="padding:25px;">
                <form id="admin-journal-form" onsubmit="event.preventDefault()">
                    <input type="hidden" id="journal-form-id" value="${journal?.id || ''}">
                    <div class="admin-form-group" style="margin-bottom:15px; display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Sayı Adı (Başlık)</label>
                        <input type="text" id="journal-form-title" class="admin-form-input" value="${journal?.title || ''}" required placeholder="Sayı 5: Bahar Rüzgarı" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                    <div class="admin-form-row" style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                        <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                            <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Ay</label>
                            <input type="text" id="journal-form-month" class="admin-form-input" value="${journal?.month || ''}" placeholder="Haziran" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                        </div>
                        <div class="admin-form-group" style="display:flex; flex-direction:column; gap:6px;">
                            <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Yıl</label>
                            <input type="number" id="journal-form-year" class="admin-form-input" value="${journal?.year || new Date().getFullYear()}" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                        </div>
                    </div>
                    <div class="admin-form-group" style="margin-bottom:15px; display:flex; flex-direction:column; gap:6px;">
                        <label style="font-weight:700; color:#cbd5e1; font-size:0.85rem;">Kapak Görseli URL</label>
                        <input type="text" id="journal-form-cover" class="admin-form-input" value="${journal?.coverImage || ''}" placeholder="https://..." style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                </form>
            </div>
            <div class="modal-footer-premium" style="padding:20px; display:flex; justify-content:flex-end; gap:10px; border-top:1px solid var(--admin-border);">
                <button class="admin-btn admin-btn-outline" onclick="document.getElementById('admin-modal').style.display='none'">Vazgeç</button>
                <button class="admin-btn admin-btn-primary" onclick="ManagementHub.saveJournal()">${isEdit ? 'Güncelle' : 'Kaydet'}</button>
            </div>
        `;
        modal.style.display = 'flex';
    },

    async saveJournal() {
        const id = document.getElementById('journal-form-id').value || 'jr-' + Date.now();
        const title = document.getElementById('journal-form-title').value.trim();
        if (!title) return Toast.warning('Lütfen başlık girin!');

        const journalData = {
            id,
            title,
            month: document.getElementById('journal-form-month').value.trim() || 'Haziran',
            year: parseInt(document.getElementById('journal-form-year').value) || new Date().getFullYear(),
            coverImage: document.getElementById('journal-form-cover').value.trim() || 'assets/logo.png',
            createdAt: new Date().toISOString()
        };

        Toast.info('Dergi kaydediliyor...');
        const success = await db.saveItem('journals', journalData.id, journalData);
        if (success) {
            Toast.success('Dergi başarıyla kaydedildi.');
            document.getElementById('admin-modal').style.display = 'none';
            await this.refreshData();
        } else {
            Toast.error('Kaydetme hatası.');
        }
    },

    async startElectionFromAdmin(actorId) {
        const actor = (State.data.actors || []).find(a => a.id === actorId || a.name === actorId);
        if (!actor) return;
        if (!actor.fanCenter) {
            actor.fanCenter = { presidentId: null, members: [], posts: [], polls: [], gallery: [] };
        }
        actor.fanCenter.electionActive = true;
        actor.fanCenter.electionEndTime = Date.now() + (3 * 24 * 60 * 60 * 1000); // 3 days

        Toast.info('Seçim başlatılıyor...');
        const success = await db.saveItem('actors', actor.name, actor);
        if (success) {
            Toast.success('Seçim süreci başlatıldı! Hayran merkezinde yayında.');
            await ManagementHub.refreshData();
        } else {
            Toast.error('Seçim başlatılamadı.');
        }
    },

    renderVerifications(container) {
        const users = State.data.users || [];
        const pending = users.filter(u => u.verificationRequested && u.verificationStatus === 'pending');
        
        container.innerHTML = `
            <div class="data-card" style="padding: 30px;">
                <h3 style="margin-bottom: 20px;">Mavi Tik Bekleyen Başvurular</h3>
                <div class="table-responsive">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Kullanıcı Adı</th>
                                <th>E-posta</th>
                                <th>Kayıt Tarihi</th>
                                <th>İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${pending.map(u => `
                                <tr>
                                    <td><b>${u.username}</b></td>
                                    <td>${u.email || '-'}</td>
                                    <td>${u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '-'}</td>
                                    <td style="display:flex; gap:10px;">
                                        <button class="admin-btn admin-btn-primary" style="padding: 5px 12px; font-size: 0.8rem; background:#10b981;" onclick="ManagementHub.approveVerification('${u.id}')">
                                            <i class="fa-solid fa-check"></i> Onayla
                                        </button>
                                        <button class="admin-btn admin-btn-outline" style="padding: 5px 12px; font-size: 0.8rem; color:#ef4444; border-color:#ef4444; background:transparent;" onclick="ManagementHub.rejectVerification('${u.id}')">
                                            <i class="fa-solid fa-xmark"></i> Reddet
                                        </button>
                                    </td>
                                </tr>
                            `).join('') || '<tr><td colspan="4" style="text-align:center; padding:20px; color:var(--admin-text-muted);">Bekleyen başvuru bulunmuyor.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    },

    async approveVerification(userId) {
        if (!confirm('Bu başvuruyu onaylamak ve doğrulama bağlantısı e-postalamak istediğinize emin misiniz?')) return;
        Toast.info('İşlem yapılıyor...');
        try {
            const response = await fetch('api/Router.php?action=approve-verification', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId })
            });
            const data = await response.json();
            if (data.success) {
                Toast.success('Başvuru onaylandı! E-posta gönderildi.');
                await this.refreshData();
            } else {
                Toast.error(data.message || 'Hata oluştu.');
            }
        } catch (e) {
            Toast.error('Sunucu bağlantı hatası.');
        }
    },

    async rejectVerification(userId) {
        if (!confirm('Bu başvuruyu reddetmek istediğinize emin misiniz?')) return;
        Toast.info('İşlem yapılıyor...');
        try {
            const response = await fetch('api/Router.php?action=reject-verification', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId })
            });
            const data = await response.json();
            if (data.success) {
                Toast.success('Başvuru reddedildi.');
                await this.refreshData();
            } else {
                Toast.error(data.message || 'Hata oluştu.');
            }
        } catch (e) {
            Toast.error('Sunucu bağlantı hatası.');
        }
    },

    renderAds(container) {
        const adSetting = (State.data.settings || []).find(s => s.id === 'ads') || {
            id: 'ads',
            preRollDuration: 5,
            socialAdFrequency: 5,
            blogAdFrequency: 3,
            ads: []
        };
        const adsList = adSetting.ads || [];

        container.innerHTML = `
            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px; align-items: start;">
                <div class="data-card" style="padding: 30px;">
                    <h3 style="margin-bottom: 20px;">Sıklık & Süre Ayarları</h3>
                    <div style="display:grid; gap: 20px;">
                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; color:var(--admin-text-muted);">Pre-Roll Reklam Süresi (Saniye)</label>
                            <input type="number" id="ad-settings-preroll" value="${adSetting.preRollDuration || 5}" class="admin-form-input" style="background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px; width:100%;">
                        </div>
                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; color:var(--admin-text-muted);">Sosyal Akış Reklam Sıklığı (Kaç postta bir)</label>
                            <input type="number" id="ad-settings-social" value="${adSetting.socialAdFrequency || 5}" class="admin-form-input" style="background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px; width:100%;">
                        </div>
                        <div class="form-group">
                            <label style="display:block; margin-bottom:8px; color:var(--admin-text-muted);">Blog Reklam Sıklığı (Kaç paragrafta bir)</label>
                            <input type="number" id="ad-settings-blog" value="${adSetting.blogAdFrequency || 3}" class="admin-form-input" style="background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px; width:100%;">
                        </div>
                        <button class="admin-btn admin-btn-primary" onclick="ManagementHub.saveAdSettings()" style="height:45px; justify-content:center; font-weight:800; font-size:0.9rem;">Ayarları Kaydet</button>
                    </div>
                </div>

                <div class="data-card" style="padding: 30px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                        <h3 style="margin:0;">Reklam İçerikleri</h3>
                        <button class="admin-btn admin-btn-primary" onclick="ManagementHub.openAdModal()"><i class="fa-solid fa-plus"></i> Yeni Reklam Ekle</button>
                    </div>
                    <div class="table-responsive">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Reklam Başlığı</th>
                                    <th>Tür</th>
                                    <th>Link / Yönlendirme</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${adsList.map(ad => `
                                    <tr>
                                        <td><b>${ad.title || 'İsimsiz Reklam'}</b></td>
                                        <td><span class="badge" style="background:rgba(139,92,246,0.1); color:#a78bfa; padding:4px 8px; border-radius:8px;">${ad.type === 'video' ? 'Video' : 'Görsel'}</span></td>
                                        <td><a href="${ad.link}" target="_blank" style="color:var(--admin-accent); text-decoration:none; font-size:0.85rem; word-break:break-all;">${ad.link}</a></td>
                                        <td style="display:flex; gap:10px;">
                                            <button class="admin-btn admin-btn-outline" style="padding: 5px 10px; font-size: 0.75rem;" onclick="ManagementHub.openAdModal('${ad.id}')"><i class="fa-solid fa-pen"></i></button>
                                            <button class="admin-btn admin-btn-outline" style="padding: 5px 10px; font-size: 0.75rem; color:#ef4444; border-color:rgba(239,68,68,0.2);" onclick="ManagementHub.deleteAd('${ad.id}')"><i class="fa-solid fa-trash"></i></button>
                                        </td>
                                    </tr>
                                `).join('') || '<tr><td colspan="4" style="text-align:center; padding:20px; color:var(--admin-text-muted);">Henüz reklam içeriği eklenmemiş.</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    },

    async saveAdSettings() {
        const preRoll = parseInt(document.getElementById('ad-settings-preroll').value) || 5;
        const social = parseInt(document.getElementById('ad-settings-social').value) || 5;
        const blog = parseInt(document.getElementById('ad-settings-blog').value) || 3;

        const adSetting = (State.data.settings || []).find(s => s.id === 'ads') || { id: 'ads', ads: [] };
        adSetting.preRollDuration = preRoll;
        adSetting.socialAdFrequency = social;
        adSetting.blogAdFrequency = blog;

        Toast.info('Ayarlar kaydediliyor...');
        const success = await db.saveItem('settings', 'ads', adSetting);
        if (success) {
            Toast.success('Reklam ayarları başarıyla kaydedildi!');
            if (typeof AdService !== 'undefined') AdService.initSync();
            await this.refreshData();
        } else {
            Toast.error('Kaydetme hatası.');
        }
    },

    openAdModal(adId = null) {
        const modal = document.getElementById('admin-modal');
        const content = document.getElementById('admin-modal-content');
        if (!modal || !content) return;

        const adSetting = (State.data.settings || []).find(s => s.id === 'ads') || { id: 'ads', ads: [] };
        const adsList = adSetting.ads || [];
        let ad = null;
        if (adId) {
            ad = adsList.find(a => String(a.id) === String(adId));
        }

        const isEdit = !!ad;
        const title = isEdit ? 'Reklamı Düzenle' : 'Yeni Reklam Ekle';

        content.innerHTML = `
            <div class="modal-header-premium">
                <h3 style="margin:0; font-weight:800; color:#fff; display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-rectangle-ad" style="color:var(--admin-accent);"></i> ${title}</h3>
                <button onclick="ManagementHub.closeAdModal()" style="background:none; border:none; color:#64748b; font-size:1.5rem; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="modal-body-premium" style="padding:25px;">
                <form id="admin-ad-form" onsubmit="event.preventDefault()">
                    <input type="hidden" id="ad-form-id" value="${ad?.id || ''}">
                    
                    <div class="admin-form-group" style="margin-bottom:15px;">
                        <label style="display:block; margin-bottom:5px; color:#cbd5e1;">Reklam Başlığı</label>
                        <input type="text" id="ad-form-title" class="admin-form-input" value="${ad?.title || ''}" required placeholder="Örn: DramicBox Premium" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                    
                    <div class="admin-form-group" style="margin-bottom:15px;">
                        <label style="display:block; margin-bottom:5px; color:#cbd5e1;">Tipi</label>
                        <select id="ad-form-type" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                            <option value="image" ${ad?.type === 'image' ? 'selected' : ''}>Görsel / Banner</option>
                            <option value="video" ${ad?.type === 'video' ? 'selected' : ''}>Video</option>
                        </select>
                    </div>

                    <div class="admin-form-group" style="margin-bottom:15px;">
                        <label style="display:block; margin-bottom:5px; color:#cbd5e1;">Medya Bağlantısı (Resim/Video URL'si)</label>
                        <input type="text" id="ad-form-url" class="admin-form-input" value="${ad?.url || ''}" required placeholder="Örn: https://..." style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>

                    <div class="admin-form-group" style="margin-bottom:15px;">
                        <label style="display:block; margin-bottom:5px; color:#cbd5e1;">Hedef URL (Tıklandığında açılacak link)</label>
                        <input type="text" id="ad-form-link" class="admin-form-input" value="${ad?.link || ''}" required placeholder="Örn: /#/vip-uyelik" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:10px; border-radius:8px;">
                    </div>
                </form>
            </div>
            <div class="modal-footer-premium" style="padding:20px; display:flex; justify-content:flex-end; gap:10px; border-top:1px solid var(--admin-border);">
                <button class="admin-btn admin-btn-outline" onclick="ManagementHub.closeAdModal()">Vazgeç</button>
                <button class="admin-btn admin-btn-primary" onclick="ManagementHub.saveAd()">${isEdit ? 'Güncelle' : 'Ekle'}</button>
            </div>
        `;
        modal.style.display = 'flex';
    },

    closeAdModal() {
        const modal = document.getElementById('admin-modal');
        if (modal) modal.style.display = 'none';
    },

    async saveAd() {
        const id = document.getElementById('ad-form-id').value || 'ad-' + Date.now();
        const title = document.getElementById('ad-form-title').value.trim();
        const type = document.getElementById('ad-form-type').value;
        const url = document.getElementById('ad-form-url').value.trim();
        const link = document.getElementById('ad-form-link').value.trim();

        if (!title || !url || !link) {
            Toast.warning('Lütfen tüm alanları doldurun!');
            return;
        }

        const adSetting = (State.data.settings || []).find(s => s.id === 'ads') || { id: 'ads', ads: [] };
        if (!adSetting.ads) adSetting.ads = [];

        const adData = { id, title, type, url, link };
        
        const idx = adSetting.ads.findIndex(a => String(a.id) === String(id));
        if (idx > -1) {
            adSetting.ads[idx] = adData;
        } else {
            adSetting.ads.push(adData);
        }

        Toast.info('Reklam kaydediliyor...');
        const success = await db.saveItem('settings', 'ads', adSetting);
        if (success) {
            Toast.success('Reklam başarıyla kaydedildi.');
            this.closeAdModal();
            if (typeof AdService !== 'undefined') AdService.initSync();
            await this.refreshData();
        } else {
            Toast.error('Kaydetme hatası.');
        }
    },

    async changeRole(userId, newRole) {
        const user = (State.data.users || []).find(u => u.id === userId);
        if (!user) return Toast.error('Kullanıcı bulunamadı.');
        if (!confirm(`${user.username} kullanıcısının rolünü "${newRole}" olarak değiştirmek istediğinize emin misiniz?`)) return;
        
        user.role = newRole;
        Toast.info('Rol güncelleniyor...');
        const success = await db.saveItem('users', user.id || user.username, user);
        if (success) {
            Toast.success(`${user.username} artık "${newRole}" rolünde.`);
            await this.refreshData();
        } else {
            Toast.error('Rol güncellenemedi.');
        }
    },

    showAddMemberModal(roleKey) {
        const modal = document.getElementById('admin-modal');
        const content = document.getElementById('admin-modal-content');
        if (!modal || !content) return;

        const users = (State.data.users || []).filter(u => u.role === 'user' || u.role === 'member');

        content.innerHTML = `
            <div class="modal-header-premium">
                <h3 style="margin:0; font-weight:800; color:#fff;"><i class="fa-solid fa-user-plus" style="color:var(--admin-accent);"></i> Ekibe Üye Ekle</h3>
                <button onclick="document.getElementById('admin-modal').style.display='none'" style="background:none; border:none; color:#64748b; font-size:1.5rem; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="modal-body-premium" style="padding:25px; max-height:400px; overflow-y:auto;">
                ${users.length > 0 ? users.map(u => `
                    <div style="display:flex; align-items:center; gap:12px; padding:12px; background:rgba(0,0,0,0.15); border-radius:12px; margin-bottom:8px;">
                        <img src="${u.avatar || 'assets/logo.png'}" style="width:40px; height:40px; border-radius:50%;" onerror="this.src='assets/logo.png'">
                        <div style="flex:1;"><b style="color:#fff;">${u.username}</b></div>
                        <button class="admin-btn admin-btn-primary" style="padding:6px 14px; font-size:0.8rem;" onclick="ManagementHub.changeRole('${u.id}', '${roleKey}'); document.getElementById('admin-modal').style.display='none';">
                            <i class="fa-solid fa-plus"></i> Ekle
                        </button>
                    </div>
                `).join('') : '<div style="color:var(--admin-text-muted); text-align:center; padding:30px;">Eklenebilecek kullanıcı bulunamadı.</div>'}
            </div>
        `;
        modal.style.display = 'flex';
    },

    renderSocialModeration(container) {
        const socialSettings = (State.data.settings || []).find(s => s.id === 'social_moderation') || {
            id: 'social_moderation',
            allowedDomains: ['dramicbox.com', 'youtube.com', 'youtu.be', 'twitter.com', 'x.com', 'instagram.com'],
            blockedDomains: []
        };

        const allowed = socialSettings.allowedDomains || [];
        const blocked = socialSettings.blockedDomains || [];

        container.innerHTML = `
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; align-items: start;">
                <div class="link-mod-panel">
                    <h4><i class="fa-solid fa-circle-check"></i> Onaylı Alan Adları (Whitelist)</h4>
                    <p style="color:var(--admin-text-muted); font-size:0.85rem; margin-bottom:20px;">Bu listedeki alan adlarından gelen bağlantılara Sosyal Hub'da izin verilir.</p>
                    <div class="link-mod-list" id="whitelist-items">
                        ${allowed.map((d, i) => `
                            <div class="link-mod-item">
                                <span class="domain-name">${d}</span>
                                <button class="remove-btn" onclick="ManagementHub.removeSocialDomain('allowed', ${i})"><i class="fa-solid fa-xmark"></i></button>
                            </div>
                        `).join('') || '<div style="color:var(--admin-text-muted); font-size:0.85rem; padding:10px;">Henüz alan adı eklenmemiş.</div>'}
                    </div>
                    <div class="link-mod-add-row">
                        <input type="text" id="whitelist-input" placeholder="Örn: twitter.com">
                        <button onclick="ManagementHub.addSocialDomain('allowed')"><i class="fa-solid fa-plus"></i> Ekle</button>
                    </div>
                </div>

                <div class="link-mod-panel">
                    <h4><i class="fa-solid fa-ban"></i> Yasaklı Alan Adları (Blacklist)</h4>
                    <p style="color:var(--admin-text-muted); font-size:0.85rem; margin-bottom:20px;">Bu listedeki alan adlarından gelen bağlantılar Sosyal Hub'da otomatik olarak engellenir.</p>
                    <div class="link-mod-list" id="blacklist-items">
                        ${blocked.map((d, i) => `
                            <div class="link-mod-item">
                                <span class="domain-name">${d}</span>
                                <button class="remove-btn" onclick="ManagementHub.removeSocialDomain('blocked', ${i})"><i class="fa-solid fa-xmark"></i></button>
                            </div>
                        `).join('') || '<div style="color:var(--admin-text-muted); font-size:0.85rem; padding:10px;">Henüz yasaklı alan adı yok.</div>'}
                    </div>
                    <div class="link-mod-add-row">
                        <input type="text" id="blacklist-input" placeholder="Örn: spam-site.com">
                        <button onclick="ManagementHub.addSocialDomain('blocked')" style="background:linear-gradient(135deg, #ef4444, #dc2626);"><i class="fa-solid fa-plus"></i> Ekle</button>
                    </div>
                </div>
            </div>
        `;
    },

    async addSocialDomain(listType) {
        const inputId = listType === 'allowed' ? 'whitelist-input' : 'blacklist-input';
        const input = document.getElementById(inputId);
        const domain = input?.value?.trim().toLowerCase();
        if (!domain) return Toast.warning('Lütfen bir alan adı girin!');

        const socialSettings = (State.data.settings || []).find(s => s.id === 'social_moderation') || {
            id: 'social_moderation',
            allowedDomains: ['dramicbox.com', 'youtube.com', 'youtu.be'],
            blockedDomains: []
        };

        const key = listType === 'allowed' ? 'allowedDomains' : 'blockedDomains';
        if (!socialSettings[key]) socialSettings[key] = [];

        if (socialSettings[key].includes(domain)) {
            return Toast.warning('Bu alan adı zaten listede!');
        }

        socialSettings[key].push(domain);
        Toast.info('Kaydediliyor...');
        const success = await db.saveItem('settings', 'social_moderation', socialSettings);
        if (success) {
            Toast.success(`${domain} ${listType === 'allowed' ? 'beyaz listeye' : 'kara listeye'} eklendi!`);
            // Update live moderation in SocialFeed
            if (window.SocialFeed) {
                if (listType === 'allowed') SocialFeed.moderation.allowedDomains = [...socialSettings.allowedDomains];
            }
            if (!State.data.socialSettings) State.data.socialSettings = {};
            State.data.socialSettings.allowedDomains = socialSettings.allowedDomains;
            State.data.socialSettings.blockedDomains = socialSettings.blockedDomains;
            this.renderSocialModeration(document.getElementById('admin-main-view'));
        } else {
            Toast.error('Kaydetme hatası.');
        }
    },

    async removeSocialDomain(listType, index) {
        const socialSettings = (State.data.settings || []).find(s => s.id === 'social_moderation');
        if (!socialSettings) return;

        const key = listType === 'allowed' ? 'allowedDomains' : 'blockedDomains';
        const removed = socialSettings[key].splice(index, 1)[0];

        Toast.info('Siliniyor...');
        const success = await db.saveItem('settings', 'social_moderation', socialSettings);
        if (success) {
            Toast.success(`${removed} listeden kaldırıldı.`);
            if (!State.data.socialSettings) State.data.socialSettings = {};
            State.data.socialSettings.allowedDomains = socialSettings.allowedDomains;
            State.data.socialSettings.blockedDomains = socialSettings.blockedDomains;
            this.renderSocialModeration(document.getElementById('admin-main-view'));
        } else {
            Toast.error('Silme hatası.');
        }
    },



    selectAdminTheme(themeKey) {
        document.getElementById('admin-custom-theme').value = themeKey;
        document.querySelectorAll('.theme-option-card').forEach(card => {
            card.style.borderColor = 'rgba(255,255,255,0.05)';
            const check = card.querySelector('.fa-circle-check');
            if (check) check.remove();
        });
        const activeCard = event.currentTarget;
        activeCard.style.borderColor = 'var(--admin-accent)';
        activeCard.insertAdjacentHTML('beforeend', `<i class="fa-solid fa-circle-check" style="position:absolute; top:8px; right:8px; color:var(--admin-accent); font-size:0.9rem;"></i>`);
    },

    selectAdminSidebar(sidebarPos) {
        document.getElementById('admin-custom-sidebar').value = sidebarPos;
        document.querySelectorAll('.sidebar-option-card').forEach(card => {
            card.style.borderColor = 'rgba(255,255,255,0.05)';
        });
        event.currentTarget.style.borderColor = 'var(--admin-accent)';
    },

    async saveAdminSettings() {
        const theme = document.getElementById('admin-custom-theme').value;
        const sidebar = document.getElementById('admin-custom-sidebar').value;
        const stats = document.getElementById('widget-stats').checked;
        const charts = document.getElementById('widget-charts').checked;
        const recent = document.getElementById('widget-recent').checked;

        const customConfig = {
            theme,
            sidebar,
            widgets: { stats, charts, recent }
        };

        if (!State.currentUser) State.currentUser = {};
        State.currentUser.adminCustomization = customConfig;
        
        Toast.info('Özelleştirmeler kaydediliyor...');
        const success = await db.saveItem('users', State.currentUser.id || State.currentUser.username, State.currentUser);
        if (success) {
            localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            Toast.success('Tercihleriniz başarıyla kaydedildi ve uygulandı! 🎉');
            this.applyAdminCustomization();
            this.render();
        } else {
            Toast.error('Ayarlar kaydedilemedi.');
        }
    },

    async resetAdminCustomization() {
        if (!confirm('Özelleştirme ayarlarınızı varsayılana sıfırlamak istediğinize emin misiniz?')) return;
        
        if (!State.currentUser) State.currentUser = {};
        State.currentUser.adminCustomization = {
            theme: 'default',
            sidebar: 'left',
            widgets: { stats: true, charts: true, recent: true }
        };

        Toast.info('Sıfırlanıyor...');
        const success = await db.saveItem('users', State.currentUser.id || State.currentUser.username, State.currentUser);
        if (success) {
            localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            Toast.success('Panel varsayılana sıfırlandı.');
            this.applyAdminCustomization();
            this.render();
        } else {
            Toast.error('Ayarlar sıfırlanamadı.');
        }
    },

    applyAdminCustomization() {
        const user = State.currentUser || JSON.parse(localStorage.getItem('dramicbox_user') || sessionStorage.getItem('dramicbox_user') || 'null');
        if (!user) return;
        
        const settings = user.adminCustomization || {
            theme: 'default',
            sidebar: 'left',
            widgets: { stats: true, charts: true, recent: true }
        };

        // 1. Apply Theme
        document.body.classList.remove('theme-amoled', 'theme-safir', 'theme-purple_midnight', 'theme-gold_premium', 'theme-emerald', 'theme-classic');
        if (settings.theme && settings.theme !== 'default') {
            document.body.classList.add('theme-' + settings.theme);
        }

        // 2. Apply Sidebar position
        document.body.classList.remove('navbar-right', 'sidebar-compact');
        if (settings.sidebar === 'right') {
            document.body.classList.add('navbar-right');
        } else if (settings.sidebar === 'compact') {
            document.body.classList.add('sidebar-compact');
        }

        // 3. Apply Widgets (Show/Hide dashboard cards dynamically if we are on dashboard tab)
        const dashboardStats = document.querySelector('.stats-container');
        const dashboardChart = document.querySelector('#visitorChart')?.closest('.data-card');
        const dashboardRecent = document.querySelector('#recent-activities')?.closest('.data-card');

        if (settings.widgets) {
            if (dashboardStats) dashboardStats.style.display = settings.widgets.stats === false ? 'none' : 'grid';
            if (dashboardChart) {
                const parentRow = dashboardChart.parentNode;
                dashboardChart.style.display = settings.widgets.charts === false ? 'none' : 'block';
                if (parentRow) {
                    const isChartVisible = settings.widgets.charts !== false;
                    const isRecentVisible = settings.widgets.recent !== false;
                    if (isChartVisible && isRecentVisible) {
                        parentRow.style.gridTemplateColumns = '2fr 1fr';
                    } else {
                        parentRow.style.gridTemplateColumns = '1fr';
                    }
                }
            }
            if (dashboardRecent) dashboardRecent.style.display = settings.widgets.recent === false ? 'none' : 'block';
        }
    },

    async deleteAd(adId) {
        if (!confirm('Bu reklamı tamamen silmek istediğinize emin misiniz?')) return;
        
        const adSetting = (State.data.settings || []).find(s => s.id === 'ads');
        if (!adSetting || !adSetting.ads) return;

        adSetting.ads = adSetting.ads.filter(a => String(a.id) !== String(adId));

        Toast.info('Reklam siliniyor...');
        const success = await db.saveItem('settings', 'ads', adSetting);
        if (success) {
            Toast.success('Reklam silindi.');
            if (typeof AdService !== 'undefined') AdService.initSync();
            await this.refreshData();
        } else {
            Toast.error('Silme hatası.');
        }
    },

    renderCalendarManagement(container) {
        const days = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];
        const calendarItems = State.data.calendar || [];

        container.innerHTML = `
            <div class="data-card" style="padding: 30px; animation: fadeIn 0.4s ease;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; flex-wrap: wrap; gap: 15px;">
                    <div>
                        <h3 style="margin: 0; font-size: 1.4rem; font-weight: 800; color: #fff;">📅 Yayın Takvimi Yönetimi</h3>
                        <p style="color: var(--admin-text-muted); font-size: 0.85rem; margin-top: 5px;">Haftalık yayın akışını güncelleyin ve yeni bölüm saatlerini belirleyin.</p>
                    </div>
                    <button class="admin-btn admin-btn-primary" onclick="ManagementHub.openCalendarModal()"><i class="fa-solid fa-plus"></i> Yeni Yayın Ekle</button>
                </div>

                <div class="calendar-days-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px;">
                    ${days.map(day => {
                        const items = calendarItems.filter(i => i.day === day);
                        items.sort((a, b) => (a.time || '').localeCompare(b.time || ''));

                        return `
                            <div class="calendar-day-column" style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); border-radius: 20px; padding: 20px; display: flex; flex-direction: column; min-height: 250px;">
                                <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 12px; margin-bottom: 15px;">
                                    <h4 style="margin: 0; font-size: 1.1rem; font-weight: 800; color: #a78bfa;">${day}</h4>
                                    <button class="admin-btn admin-btn-outline" style="padding: 4px 10px; font-size: 0.75rem;" onclick="ManagementHub.openCalendarModal(null, '${day}')">
                                        <i class="fa-solid fa-plus"></i> Ekle
                                    </button>
                                </div>
                                <div style="display: flex; flex-direction: column; gap: 10px; flex: 1;">
                                    ${items.map(item => {
                                        const s = (State.data.series || []).find(x => x.id === item.seriesId) || (State.data.webtoons || []).find(x => x.id === item.seriesId);
                                        const title = s ? s.title : 'Bilinmeyen İçerik';
                                        const poster = s ? (s.poster || s.coverImage || 'assets/logo.png') : 'assets/logo.png';
                                        return `
                                            <div style="display: flex; align-items: center; gap: 12px; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.03); border-radius: 12px; padding: 8px 12px; position: relative;">
                                                <img src="${poster}" style="width: 35px; height: 50px; border-radius: 6px; object-fit: cover;">
                                                <div style="flex: 1; min-width: 0;">
                                                    <div style="font-weight: 700; font-size: 0.85rem; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${title}">${title}</div>
                                                    <div style="font-size: 0.75rem; color: var(--admin-text-muted); margin-top: 2px;">
                                                        <i class="fa-regular fa-clock" style="margin-right: 4px;"></i> ${item.time || '20:00'}
                                                        ${item.episodeNumber ? `• ${item.episodeNumber}. Bölüm` : ''}
                                                    </div>
                                                </div>
                                                <div style="display: flex; gap: 4px;">
                                                    <button class="admin-btn admin-btn-outline" style="padding: 4px 6px; font-size: 0.7rem;" onclick="ManagementHub.openCalendarModal('${item.id}')" title="Düzenle">
                                                        <i class="fa-solid fa-pen"></i>
                                                    </button>
                                                    <button class="admin-btn admin-btn-outline" style="padding: 4px 6px; font-size: 0.7rem; color: var(--admin-danger); border-color: rgba(239, 68, 68, 0.2);" onclick="ManagementHub.deleteCalendarItem('${item.id}', '${title.replace(/'/g, "\\'")}')" title="Sil">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        `;
                                    }).join('') || `<div style="text-align: center; color: var(--admin-text-muted); font-size: 0.8rem; margin: auto 0; padding: 20px 0;">Yayın bulunmuyor.</div>`}
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
    },

    openCalendarModal(itemId = null, defaultDay = 'Pazartesi') {
        const modal = document.getElementById('admin-modal');
        const modalContent = document.getElementById('admin-modal-content');
        if (!modal || !modalContent) return;

        const calendarItems = State.data.calendar || [];
        const item = itemId ? calendarItems.find(i => i.id === itemId) : null;

        const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])];
        allContent.sort((a, b) => (a.title || '').localeCompare(b.title || ''));

        const days = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];
        const selectedDay = item ? item.day : defaultDay;

        modalContent.innerHTML = `
            <div style="padding: 30px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; border-bottom: 1px solid var(--admin-border); padding-bottom: 15px;">
                    <h3 style="margin: 0; color: #fff;"><i class="fa-solid fa-calendar-days" style="color: var(--admin-accent); margin-right: 8px;"></i> ${item ? 'Yayını Düzenle' : 'Yeni Yayın Ekle'}</h3>
                    <button onclick="document.getElementById('admin-modal').style.display='none'" style="background: none; border: none; color: var(--admin-text-muted); font-size: 1.5rem; cursor: pointer;">&times;</button>
                </div>
                
                <form id="calendar-item-form" onsubmit="event.preventDefault();" style="display: flex; flex-direction: column; gap: 20px;">
                    <div class="form-group">
                        <label style="display: block; margin-bottom: 8px; font-weight: 700; color: #cbd5e1;">Dizi / Webtoon Seçin</label>
                        <select id="cal-series-id" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;" required>
                            <option value="">-- İçerik Seçin --</option>
                            ${allContent.map(s => `
                                <option value="${s.id}" ${item && item.seriesId === s.id ? 'selected' : ''}>[${s.type === 'webtoon' ? 'Webtoon' : 'Dizi'}] ${s.title}</option>
                            `).join('')}
                        </select>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div class="form-group">
                            <label style="display: block; margin-bottom: 8px; font-weight: 700; color: #cbd5e1;">Yayın Günü</label>
                            <select id="cal-day" class="admin-form-input" style="width:100%; background:#1e1e24; border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;" required>
                                ${days.map(d => `
                                    <option value="${d}" ${selectedDay === d ? 'selected' : ''}>${d}</option>
                                `).join('')}
                            </select>
                        </div>
                        <div class="form-group">
                            <label style="display: block; margin-bottom: 8px; font-weight: 700; color: #cbd5e1;">Yayın Saati</label>
                            <input type="time" id="cal-time" class="admin-form-input" value="${item ? item.time || '20:00' : '20:00'}" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label style="display: block; margin-bottom: 8px; font-weight: 700; color: #cbd5e1;">Bölüm Numarası (Opsiyonel)</label>
                        <input type="number" id="cal-episode" class="admin-form-input" value="${item && item.episodeNumber ? item.episodeNumber : ''}" placeholder="Örn: 5" style="width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--admin-border); color:#fff; padding:12px; border-radius:10px;">
                    </div>

                    <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 15px; border-top: 1px solid var(--admin-border); padding-top: 20px;">
                        <button type="button" class="admin-btn admin-btn-outline" onclick="document.getElementById('admin-modal').style.display='none'">İptal</button>
                        <button type="button" class="admin-btn admin-btn-primary" onclick="ManagementHub.saveCalendarItem(${item ? `'${item.id}'` : 'null'})">${item ? 'Güncelle' : 'Kaydet'}</button>
                    </div>
                </form>
            </div>
        `;

        modal.style.display = 'flex';
    },

    async saveCalendarItem(itemId = null) {
        const seriesId = document.getElementById('cal-series-id').value;
        const day = document.getElementById('cal-day').value;
        const time = document.getElementById('cal-time').value;
        const episodeNumber = parseInt(document.getElementById('cal-episode').value) || null;

        if (!seriesId || !day || !time) {
            Toast.warning('Lütfen gerekli alanları doldurun.');
            return;
        }

        const id = itemId || 'cal_' + Date.now();
        const data = {
            id,
            seriesId,
            day,
            time,
            episodeNumber
        };

        try {
            if (window.db && db.saveItem) {
                const success = await db.saveItem('calendar', id, data);
                if (success) {
                    Toast.success('Yayın planı kaydedildi!');
                    document.getElementById('admin-modal').style.display = 'none';
                    await this.refreshData();
                } else {
                    Toast.error('Yayın planı kaydedilemedi.');
                }
            }
        } catch (e) {
            console.error('saveCalendarItem error:', e);
            Toast.error('Bir hata oluştu.');
        }
    },

    async deleteCalendarItem(itemId, itemTitle) {
        if (!confirm(`"${itemTitle}" yayın planını silmek istediğinize emin misiniz?`)) return;

        try {
            if (window.db && db.deleteItem) {
                const success = await db.deleteItem('calendar', itemId);
                if (success) {
                    Toast.success('Yayın planı başarıyla silindi.');
                    await this.refreshData();
                } else {
                    Toast.error('Silme işlemi başarısız.');
                }
            }
        } catch (e) {
            console.error('deleteCalendarItem error:', e);
            Toast.error('Bir hata oluştu.');
        }
    },

    renderChestsCards(container) {
        const settingsArray = State.data.settings || [];
        let chestSettings = Array.isArray(settingsArray)
            ? settingsArray.find(s => s.id === 'chest_settings')
            : settingsArray.chest_settings;

        if (!chestSettings) {
            chestSettings = {
                id: 'chest_settings',
                bronze: { price: 150, common: 70, rare: 20, epic: 8, legendary: 2 },
                silver: { price: 350, common: 40, rare: 40, epic: 15, legendary: 5 },
                gold: { price: 800, common: 15, rare: 30, epic: 40, legendary: 15 }
            };
        }

        const actors = State.data.actors || [];

        container.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:30px; animation: fadeIn 0.4s ease;">
                <div class="data-card" style="padding: 30px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                        <div>
                            <h3 style="margin: 0; font-size: 1.4rem; font-weight: 800; color: #fff;">📦 Sandık ve Kart Ayarları</h3>
                            <p style="color: var(--admin-text-muted); font-size: 0.85rem; margin-top: 5px;">Market sandık fiyatlarını ve nadirlik yüzdelerini yapılandırın.</p>
                        </div>
                        <button class="admin-btn admin-btn-primary" onclick="ManagementHub.saveChestSettings()">
                            <i class="fa-solid fa-floppy-disk"></i> Ayarları Kaydet
                        </button>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
                        <div style="background: rgba(205, 127, 50, 0.05); border: 1px solid rgba(205, 127, 50, 0.2); border-radius: 20px; padding: 20px;">
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                                <i class="fa-solid fa-box" style="color: #cd7f32; font-size: 1.5rem;"></i>
                                <h4 style="margin:0; color:#fff; font-weight: 800;">Bronz Sandık</h4>
                            </div>
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <label style="color:#cbd5e1; font-size:0.85rem;">Fiyat (Coins)</label>
                                    <input type="number" id="chest-price-bronze" class="admin-form-input" style="width: 100px; text-align: center;" value="${chestSettings.bronze.price}">
                                </div>
                                <div style="border-top: 1px solid rgba(255,255,255,0.05); padding-top: 10px; display:flex; flex-direction:column; gap:8px;">
                                    <div style="font-size:0.8rem; font-weight:700; color:#8b5cf6;">Çıkma Olasılıkları (%)</div>
                                    <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap: 6px; text-align:center; font-size:0.75rem; color:#cbd5e1;">
                                        <div>Yaygın<input type="number" id="chest-prob-bronze-common" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.bronze.common}"></div>
                                        <div>Nadir<input type="number" id="chest-prob-bronze-rare" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.bronze.rare}"></div>
                                        <div>Epik<input type="number" id="chest-prob-bronze-epic" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.bronze.epic}"></div>
                                        <div>Efsane<input type="number" id="chest-prob-bronze-legendary" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.bronze.legendary}"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div style="background: rgba(192, 192, 192, 0.05); border: 1px solid rgba(192, 192, 192, 0.2); border-radius: 20px; padding: 20px;">
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                                <i class="fa-solid fa-box" style="color: #c0c0c0; font-size: 1.5rem;"></i>
                                <h4 style="margin:0; color:#fff; font-weight: 800;">Gümüş Sandık</h4>
                            </div>
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <label style="color:#cbd5e1; font-size:0.85rem;">Fiyat (Coins)</label>
                                    <input type="number" id="chest-price-silver" class="admin-form-input" style="width: 100px; text-align: center;" value="${chestSettings.silver.price}">
                                </div>
                                <div style="border-top: 1px solid rgba(255,255,255,0.05); padding-top: 10px; display:flex; flex-direction:column; gap:8px;">
                                    <div style="font-size:0.8rem; font-weight:700; color:#8b5cf6;">Çıkma Olasılıkları (%)</div>
                                    <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap: 6px; text-align:center; font-size:0.75rem; color:#cbd5e1;">
                                        <div>Yaygın<input type="number" id="chest-prob-silver-common" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.silver.common}"></div>
                                        <div>Nadir<input type="number" id="chest-prob-silver-rare" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.silver.rare}"></div>
                                        <div>Epik<input type="number" id="chest-prob-silver-epic" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.silver.epic}"></div>
                                        <div>Efsane<input type="number" id="chest-prob-silver-legendary" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.silver.legendary}"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div style="background: rgba(255, 215, 0, 0.05); border: 1px solid rgba(255, 215, 0, 0.2); border-radius: 20px; padding: 20px;">
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                                <i class="fa-solid fa-box" style="color: #ffd700; font-size: 1.5rem;"></i>
                                <h4 style="margin:0; color:#fff; font-weight: 800;">Altın Sandık</h4>
                            </div>
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <label style="color:#cbd5e1; font-size:0.85rem;">Fiyat (Coins)</label>
                                    <input type="number" id="chest-price-gold" class="admin-form-input" style="width: 100px; text-align: center;" value="${chestSettings.gold.price}">
                                </div>
                                <div style="border-top: 1px solid rgba(255,255,255,0.05); padding-top: 10px; display:flex; flex-direction:column; gap:8px;">
                                    <div style="font-size:0.8rem; font-weight:700; color:#8b5cf6;">Çıkma Olasılıkları (%)</div>
                                    <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap: 6px; text-align:center; font-size:0.75rem; color:#cbd5e1;">
                                        <div>Yaygın<input type="number" id="chest-prob-gold-common" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.gold.common}"></div>
                                        <div>Nadir<input type="number" id="chest-prob-gold-rare" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.gold.rare}"></div>
                                        <div>Epik<input type="number" id="chest-prob-gold-epic" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.gold.epic}"></div>
                                        <div>Efsane<input type="number" id="chest-prob-gold-legendary" class="admin-form-input" style="padding:4px; text-align:center; margin-top:4px;" value="${chestSettings.gold.legendary}"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="data-card" style="padding: 30px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                        <div>
                            <h3 style="margin: 0; font-size: 1.4rem; font-weight: 800; color: #fff;">🃏 Oyuncu Kartı Koleksiyonu</h3>
                            <p style="color: var(--admin-text-muted); font-size: 0.85rem; margin-top: 5px;">Aktörleri koleksiyon kartı durumuna ve nadirlik sınıflarına göre filtreleyin ve düzenleyin.</p>
                        </div>
                        <button class="admin-btn admin-btn-outline" onclick="ManagementHub.switchTab('actors')">
                            <i class="fa-solid fa-plus"></i> Yeni Aktör Ekle
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>Görsel</th>
                                    <th>Oyuncu Adı</th>
                                    <th>Korece Adı</th>
                                    <th>Nadirlik Sınıfı</th>
                                    <th>Koleksiyon Kartı mı?</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${actors.map(actor => {
                                    let badgeColor = '#94a3b8';
                                    let badgeBg = 'rgba(148, 163, 184, 0.1)';
                                    const rarity = actor.rarity || 'Common';
                                    if (rarity === 'Rare') { badgeColor = '#3b82f6'; badgeBg = 'rgba(59, 130, 246, 0.1)'; }
                                    else if (rarity === 'Epic') { badgeColor = '#a855f7'; badgeBg = 'rgba(168, 85, 247, 0.1)'; }
                                    else if (rarity === 'Legendary') { badgeColor = '#f59e0b'; badgeBg = 'rgba(245, 158, 11, 0.1)'; }

                                    const isColl = actor.isCollectible !== false;

                                    return `
                                        <tr>
                                            <td>
                                                <img src="${actor.avatar || actor.image || 'assets/default-avatar.png'}" style="width: 45px; height: 45px; border-radius: 50%; object-fit: cover; border: 1.5px solid rgba(255,255,255,0.1);" onerror="this.src='assets/default-avatar.png'">
                                            </td>
                                            <td><b>${actor.name}</b></td>
                                            <td style="font-family: 'Noto Sans KR', sans-serif; color: var(--admin-text-muted);">${actor.koreanName || '-'}</td>
                                            <td>
                                                <span class="badge" style="background:${badgeBg}; color:${badgeColor}; border:1px solid ${badgeColor}20; padding:6px 12px; border-radius:8px; font-weight:700;">
                                                    ${rarity === 'Common' ? 'Yaygın (Common)' : rarity === 'Rare' ? 'Nadir (Rare)' : rarity === 'Epic' ? 'Epik (Epic)' : 'Efsanevi (Legendary)'}
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge" style="background:${isColl ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)'}; color:${isColl ? '#10b981' : '#ef4444'}; padding:6px 12px; border-radius:8px; font-weight:700;">
                                                    ${isColl ? 'Evet' : 'Hayır'}
                                                </span>
                                            </td>
                                            <td style="display:flex; gap:10px;">
                                                <button class="admin-btn admin-btn-outline" style="padding: 6px 12px; font-size: 0.8rem;" onclick="ManagementHub.openActorModal('${actor.id || actor.name}')">
                                                    <i class="fa-solid fa-pen-to-square"></i> Düzenle
                                                </button>
                                            </td>
                                        </tr>
                                    `;
                                }).join('') || '<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--admin-text-muted);">Oyuncu bulunamadı.</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    },

    renderDramicPass(container) {
        const cached = localStorage.getItem('dramicbox_gamification_config');
        if (cached && !State.data.gamificationConfig) {
            try { State.data.gamificationConfig = JSON.parse(cached); } catch (e) { /* ignore */ }
        }
        if (!State.data.gamificationConfig) {
            container.innerHTML = '<div style="padding:40px; text-align:center; color:var(--admin-text-muted);">Dramic Pass yükleniyor...</div>';
            fetch('Database/gamification_config.json')
                .then(r => r.json())
                .then(cfg => { State.data.gamificationConfig = cfg; this.renderDramicPass(container); })
                .catch(() => { State.data.gamificationConfig = { passTiers: {} }; this.renderDramicPass(container); });
            return;
        }
        const config = State.data.gamificationConfig;
        const tiers = config.passTiers || {};
        const tierKeys = Object.keys(tiers).sort((a, b) => parseInt(a) - parseInt(b));

        container.innerHTML = `
            <div class="data-card" style="padding:30px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:25px;">
                    <div>
                        <h3 style="margin:0; font-size:1.4rem; font-weight:800; color:#fff;">👑 Dramic Pass (Royal Pass)</h3>
                        <p style="color:var(--admin-text-muted); font-size:0.85rem; margin-top:5px;">Seviye atlama ödüllerini düzenleyin. Ücretsiz ve VIP kanalları ayrı tanımlanır.</p>
                    </div>
                    <button class="admin-btn admin-btn-primary" onclick="ManagementHub.saveDramicPass()">
                        <i class="fa-solid fa-floppy-disk"></i> Pass Ayarlarını Kaydet
                    </button>
                </div>
                <div id="dramic-pass-tiers-list" style="display:flex; flex-direction:column; gap:16px;">
                    ${tierKeys.map(lvl => {
                        const t = tiers[lvl];
                        return `
                        <div style="background:rgba(255,255,255,0.02); border:1px solid var(--admin-border); border-radius:16px; padding:20px;">
                            <h4 style="margin:0 0 15px; color:#fbbf24;">Seviye ${lvl}</h4>
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                                <div>
                                    <label style="color:#94a3b8; font-size:0.8rem; font-weight:700;">Ücretsiz Ödül Etiketi</label>
                                    <input type="text" class="admin-form-input pass-free-label" data-level="${lvl}" value="${t.free?.label || ''}" style="width:100%; margin-top:6px;">
                                    <label style="color:#94a3b8; font-size:0.75rem; margin-top:8px; display:block;">Tip (coins/chest/frame/vip_days)</label>
                                    <input type="text" class="admin-form-input pass-free-type" data-level="${lvl}" value="${t.free?.type || 'coins'}" style="width:100%; margin-top:4px;">
                                    <input type="text" class="admin-form-input pass-free-value" data-level="${lvl}" value="${t.free?.value || ''}" placeholder="değer" style="width:100%; margin-top:4px;">
                                </div>
                                <div>
                                    <label style="color:#fbbf24; font-size:0.8rem; font-weight:700;">VIP Ödül Etiketi</label>
                                    <input type="text" class="admin-form-input pass-vip-label" data-level="${lvl}" value="${t.vip?.label || ''}" style="width:100%; margin-top:6px;">
                                    <label style="color:#94a3b8; font-size:0.75rem; margin-top:8px; display:block;">Tip</label>
                                    <input type="text" class="admin-form-input pass-vip-type" data-level="${lvl}" value="${t.vip?.type || 'coins'}" style="width:100%; margin-top:4px;">
                                    <input type="text" class="admin-form-input pass-vip-value" data-level="${lvl}" value="${t.vip?.value || ''}" placeholder="değer" style="width:100%; margin-top:4px;">
                                </div>
                            </div>
                        </div>`;
                    }).join('') || '<p style="color:var(--admin-text-muted);">Pass katmanı bulunamadı. gamification_config.json dosyasını kontrol edin.</p>'}
                </div>
                <button class="admin-btn admin-btn-outline" style="margin-top:20px;" onclick="ManagementHub.addPassTier()">
                    <i class="fa-solid fa-plus"></i> Yeni Seviye Katmanı Ekle
                </button>
            </div>
        `;
    },

    addPassTier() {
        if (!State.data.gamificationConfig) State.data.gamificationConfig = { passTiers: {} };
        const keys = Object.keys(State.data.gamificationConfig.passTiers || {}).map(Number);
        const next = (keys.length ? Math.max(...keys) : 1) + 1;
        State.data.gamificationConfig.passTiers[String(next)] = {
            free: { type: 'coins', value: 50, label: '50 Coin' },
            vip: { type: 'coins', value: 150, label: '150 Coin' }
        };
        this.renderDramicPass(document.getElementById('admin-main-view'));
        Toast.success(`Seviye ${next} pass katmanı eklendi.`);
    },

    async saveDramicPass() {
        if (!State.data.gamificationConfig) State.data.gamificationConfig = { passTiers: {} };
        const tiers = {};
        document.querySelectorAll('.pass-free-label').forEach(inp => {
            const lvl = inp.dataset.level;
            if (!tiers[lvl]) tiers[lvl] = {};
            tiers[lvl].free = {
                type: document.querySelector(`.pass-free-type[data-level="${lvl}"]`)?.value || 'coins',
                value: document.querySelector(`.pass-free-value[data-level="${lvl}"]`)?.value || 0,
                label: inp.value || ''
            };
            tiers[lvl].vip = {
                type: document.querySelector(`.pass-vip-type[data-level="${lvl}"]`)?.value || 'coins',
                value: document.querySelector(`.pass-vip-value[data-level="${lvl}"]`)?.value || 0,
                label: document.querySelector(`.pass-vip-label[data-level="${lvl}"]`)?.value || ''
            };
        });
        State.data.gamificationConfig.passTiers = tiers;
        try {
            const res = await fetch('Database/gamification_config.json');
            const full = await res.json();
            full.passTiers = tiers;
            await fetch('api/db.php?action=save-gamification-config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(full)
            }).catch(() => null);
            localStorage.setItem('dramicbox_gamification_config', JSON.stringify(full));
            Toast.success('Dramic Pass ayarları kaydedildi!');
        } catch (e) {
            localStorage.setItem('dramicbox_gamification_config', JSON.stringify(State.data.gamificationConfig));
            Toast.success('Pass ayarları yerel olarak kaydedildi.');
        }
    },

    async saveChestSettings() {
        const settingsArray = State.data.settings || [];
        let chestSettings = Array.isArray(settingsArray)
            ? settingsArray.find(s => s.id === 'chest_settings')
            : settingsArray.chest_settings;

        const newSettings = {
            id: 'chest_settings',
            bronze: {
                price: parseInt(document.getElementById('chest-price-bronze').value) || 150,
                common: parseInt(document.getElementById('chest-prob-bronze-common').value) || 70,
                rare: parseInt(document.getElementById('chest-prob-bronze-rare').value) || 20,
                epic: parseInt(document.getElementById('chest-prob-bronze-epic').value) || 8,
                legendary: parseInt(document.getElementById('chest-prob-bronze-legendary').value) || 2,
            },
            silver: {
                price: parseInt(document.getElementById('chest-price-silver').value) || 350,
                common: parseInt(document.getElementById('chest-prob-silver-common').value) || 40,
                rare: parseInt(document.getElementById('chest-prob-silver-rare').value) || 40,
                epic: parseInt(document.getElementById('chest-prob-silver-epic').value) || 15,
                legendary: parseInt(document.getElementById('chest-prob-silver-legendary').value) || 5,
            },
            gold: {
                price: parseInt(document.getElementById('chest-price-gold').value) || 800,
                common: parseInt(document.getElementById('chest-prob-gold-common').value) || 15,
                rare: parseInt(document.getElementById('chest-prob-gold-rare').value) || 30,
                epic: parseInt(document.getElementById('chest-prob-gold-epic').value) || 40,
                legendary: parseInt(document.getElementById('chest-prob-gold-legendary').value) || 15,
            }
        };

        const checkSum = (chest) => chest.common + chest.rare + chest.epic + chest.legendary;
        if (checkSum(newSettings.bronze) !== 100 || checkSum(newSettings.silver) !== 100 || checkSum(newSettings.gold) !== 100) {
            Toast.warning('Hata: Her sandık için toplam olasılık %100 olmalıdır!');
            return;
        }

        Toast.info('Sandık ayarları kaydediliyor...');
        const success = await db.saveItem('settings', 'chest_settings', newSettings);
        if (success) {
            Toast.success('Sandık ayarları başarıyla güncellendi!');
            await this.refreshData();
        } else {
            Toast.error('Ayarlar kaydedilemedi.');
        }
    }
};
