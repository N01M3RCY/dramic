/**
 * SubtitleStudio.js
 * Collaborative Spreadsheet-style Subtitle Editor
 * Premium Google Sheets + CapCut Aesthetics
 * Includes LIVE Broadcast Mode
 */

const SubtitleStudio = {
    currentVideo: null,
    subtitles: [],
    history: [],
    seriesId: null,
    epNum: null,
    isLive: false,
    
    init(seriesId = null, epNum = null) {
        this.seriesId = seriesId;
        this.epNum = epNum;
        this.subtitles = [];
        this.currentVideo = null;
        this.isLive = false;
        
        if (seriesId && epNum) {
            const series = State.data.series.find(s => s.id === seriesId);
            const ep = series?.episodes.find(e => e.number === epNum);
            if (ep) {
                if (ep.subtitleData) {
                    this.subtitles = ep.subtitleData;
                }
                
                // Auto-load video if sources exist
                if (ep.sources && ep.sources.length > 0) {
                    this.currentVideo = ep.sources[0].url;
                }
            }
        }
        
        // Real-time Sync Start
        if (this.seriesId && this.epNum) {
            const syncPath = `studio/${this.seriesId}/${this.epNum}`;
            SyncService.on(syncPath, (data) => {
                if (data && data._userId !== State.currentUser?.id) {
                    this.subtitles = data.subtitles || [];
                    this.renderSpreadsheet();
                }
            });

            // Chat Listener
            const chatPath = `chats/studio/${this.seriesId}_${this.epNum}`;
            SyncService.on(chatPath, (data) => {
                if (!data) return;
                const box = document.getElementById('studio-chat-messages');
                if (!box) return;
                box.innerHTML = ''; // Reset and re-render or handle increments
                Object.values(data).sort((a,b) => a.at - b.at).forEach(m => {
                    const msgDiv = document.createElement('div');
                    msgDiv.style.marginBottom = '8px';
                    msgDiv.innerHTML = `<span style="color: #8b5cf6; font-weight: 800;">${m.username}:</span> <span style="color: #e2e8f0;">${m.text}</span>`;
                    box.appendChild(msgDiv);
                });
                box.scrollTop = box.scrollHeight;
            });
        }
        
        // Load Drive Service
        if (!window.DriveService) {
            Loader.loadScript('js/core/drive.js').then(() => DriveService.init());
        }
    },

    render() {
        if (!this.seriesId || !this.epNum) {
            return this.renderProjectSelector();
        }

        const series = State.data.series.find(s => s.id === this.seriesId);
        
        // Live Mode Isolation
        if (this.isLive) {
            document.body.classList.add('live-mode-active');
        } else {
            document.body.classList.remove('live-mode-active');
        }

        return `
            <div class="studio-container ${this.isLive ? 'is-live' : ''}" style="display:flex; flex-direction:column; height: ${this.isLive ? '100vh' : 'calc(100vh - 100px)'}; background: #0a0a0f; border-radius: ${this.isLive ? '0' : '30px'}; overflow: hidden; border: ${this.isLive ? 'none' : '1px solid rgba(255,255,255,0.05)'}; position: ${this.isLive ? 'fixed' : 'relative'}; top:0; left:0; width:100%; z-index: ${this.isLive ? '5000' : '1'};">
                
                <!-- Toolbar / Navigation -->
                <div class="studio-toolbar" style="padding: 15px 30px; background: rgba(255,255,255,0.02); border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 20px;">
                        <button onclick="SubtitleStudio.exit()" class="btn-icon" style="background: rgba(255,255,255,0.05); border-radius: 12px; width: 40px; height: 40px; color: #fff;"><i class="fa-solid fa-chevron-left"></i></button>
                        <div>
                            <h2 style="margin:0; font-size: 1.1rem; color: #fff; font-weight: 800;">${series ? series.title : 'Subtitle Studio'}</h2>
                            <div style="display:flex; align-items:center; gap:10px;">
                                <p style="margin: 0; font-size: 0.75rem; color: #64748b;">${this.epNum ? 'Bölüm ' + this.epNum : 'Çalışma Alanı'}</p>
                                <button onclick="SubtitleStudio.seriesId=null; ManagementHub.render()" style="background:none; border:none; color:#8b5cf6; font-size:0.65rem; cursor:pointer; font-weight:800;">[BÖLÜM DEĞİŞTİR]</button>
                            </div>
                        </div>
                    </div>

                    <div style="display: flex; gap: 10px; align-items:center;">
                        <button onclick="SubtitleStudio.inviteStaff()" class="btn btn-sm" style="background:rgba(139, 92, 246, 0.1); color:#a78bfa; border:1px solid rgba(139, 92, 246, 0.2); border-radius:8px; font-size:0.7rem; height:35px;"><i class="fa-solid fa-user-plus"></i> EKİBİ ÇAĞIR</button>
                        <div style="width:1px; height:20px; background:rgba(255,255,255,0.1); margin:0 5px;"></div>
                        <button onclick="SubtitleStudio.toggleLive()" class="btn ${this.isLive ? 'btn-danger' : 'btn-outline'}" style="border-radius: 12px; font-weight: 700; height:40px;">
                            <i class="fa-solid ${this.isLive ? 'fa-broadcast-tower' : 'fa-play-circle'}"></i> ${this.isLive ? 'YAYINI DURDUR' : 'CANLI YAYINA GEÇ'}
                        </button>
                        <button onclick="SubtitleStudio.aiTranslateAll()" class="btn btn-outline" style="border-radius: 12px; font-weight: 700; border-color: #8b5cf6; color: #8b5cf6; height:40px;"><i class="fa-solid fa-wand-magic-sparkles"></i> YAPAY ZEKA (HEPSİ)</button>
                        <button onclick="SubtitleStudio.exportSRT()" class="btn btn-primary" style="border-radius: 12px; font-weight: 700; height:40px;"><i class="fa-solid fa-download"></i> SRT İNDİR</button>
                        <button onclick="SubtitleStudio.backupToDrive()" class="btn btn-outline" style="border-radius: 12px; font-weight: 700; border-color: #10b981; color: #10b981; height:40px;"><i class="fa-brands fa-google-drive"></i> DRIVE'A YEDEKLE</button>
                    </div>
                </div>

                <!-- Main Layout -->
                <div style="display: flex; flex: 1; overflow: hidden;">
                    
                    <!-- Left: Video & Preview (40%) -->
                    <div style="width: 40%; display: flex; flex-direction: column; border-right: 1px solid rgba(255,255,255,0.05); background: #000;">
                        <div id="studio-video-container" style="flex: 1; position: relative; display: flex; align-items: center; justify-content: center;">
                            <video id="studio-video" style="width: 100%; max-height: 100%; object-fit: contain;" crossorigin="anonymous">
                                <source src="${this.currentVideo || ''}" type="video/mp4">
                            </video>
                            
                            <!-- Subtitle Overlay -->
                            <div id="studio-subtitle-overlay" style="position: absolute; bottom: 10%; width: 100%; text-align: center; color: #fff; text-shadow: 0 2px 10px #000; font-size: 1.5rem; font-weight: 700; pointer-events: none; padding: 0 20px;"></div>

                            <!-- Live Indicator -->
                            ${this.isLive ? '<div class="live-pulse" style="position: absolute; top: 20px; right: 20px;"></div>' : ''}
                        </div>

                        <!-- Video Controls Bar -->
                        <div style="padding: 15px 25px; background: #0a0a0f; border-top: 1px solid rgba(255,255,255,0.05);">
                            <div style="display: flex; align-items: center; justify-content: space-between;">
                                <div style="display: flex; gap: 15px; align-items: center;">
                                    <button onclick="SubtitleStudio.playPause()" class="btn-icon" style="color: #fff; font-size: 1.2rem;"><i class="fa-solid fa-play"></i></button>
                                    <span id="studio-time-display" style="font-size: 0.7rem; color: #fff; font-family: monospace;">00:00:00</span>
                                </div>
                            </div>
                            <div style="margin-top: 15px; display: flex; gap: 10px;">
                                <input type="text" id="video-url-input" value="${this.currentVideo || ''}" placeholder="Video URL girin..." style="flex: 1; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 10px 15px; border-radius: 12px; color: #fff; font-size: 0.8rem;" onchange="SubtitleStudio.loadVideo()">
                                ${this.renderSourcePicker()}
                            </div>
                        </div>

                        <!-- Real-time Team Chat (Small Sidebar) -->
                        <div id="studio-chat" style="height: 200px; border-top: 1px solid rgba(255,255,255,0.05); display: flex; flex-direction: column; background: #0c0c14;">
                            <div style="padding: 10px 20px; border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between;">
                                <span style="font-size: 0.7rem; font-weight: 800; color: #8b5cf6;">EKİP SOHBETİ</span>
                                <span style="font-size: 0.65rem; color: #10b981;">● Aktif</span>
                            </div>
                            <div id="studio-chat-messages" style="flex: 1; overflow-y: auto; padding: 10px 20px; font-size: 0.8rem;" class="custom-scroll">
                                <div style="color: #64748b; margin-bottom: 5px;"><i>Sistem: Çeviri odasına katıldınız.</i></div>
                            </div>
                            <div style="padding: 10px 20px; display: flex; gap: 10px;">
                                <input type="text" id="studio-chat-input" placeholder="Mesaj yaz..." style="flex: 1; background: rgba(255,255,255,0.05); border: none; border-radius: 8px; color: #fff; padding: 5px 12px; font-size: 0.75rem;" onkeydown="if(event.key==='Enter') SubtitleStudio.sendMessage()">
                                <button onclick="SubtitleStudio.sendMessage()" style="background: none; border: none; color: #8b5cf6;"><i class="fa-solid fa-paper-plane"></i></button>
                            </div>
                        </div>
                    </div>

                    <!-- Right: Spreadsheet (60%) -->
                    <div style="flex: 1; display: flex; flex-direction: column; background: #0f0f18;">
                        <div style="padding: 10px 30px; background: rgba(255,255,255,0.01); border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center;">
                            <div style="display: flex; gap: 20px; font-size: 0.75rem; color: #64748b; font-weight: 600;">
                                <span style="color: #10b981;"><i class="fa-solid fa-cloud-check"></i> Kaydedildi</span>
                                <span>Satır Sayısı: <b style="color:#fff;">${this.subtitles.length}</b></span>
                            </div>
                            <button onclick="SubtitleStudio.addLine()" class="btn btn-sm btn-primary" style="border-radius: 8px;"><i class="fa-solid fa-plus"></i> Yeni Satır Ekle</button>
                        </div>

                        <!-- Grid Table -->
                        <div style="flex: 1; overflow-y: auto;" class="custom-scroll">
                            <table class="studio-table" style="width: 100%; border-collapse: collapse;">
                                <thead style="position: sticky; top: 0; background: #161625; z-index: 10; border-bottom: 1px solid rgba(255,255,255,0.1);">
                                    <tr>
                                        <th style="width: 50px;">#</th>
                                        <th style="width: 120px;">Başlangıç</th>
                                        <th style="width: 120px;">Bitiş</th>
                                        <th>Orijinal Metin</th>
                                        <th>Çeviri</th>
                                        <th style="width: 80px;">Durum</th>
                                        <th style="width: 50px;">AI</th>
                                    </tr>
                                </thead>
                                <tbody id="studio-spreadsheet-body">
                                    <!-- Rows injected by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

                <style>
                    .studio-table th { padding: 12px; font-size: 0.75rem; text-align: left; color: #94a3b8; font-weight: 800; text-transform: uppercase; }
                    .studio-table td { padding: 0; border: 1px solid rgba(255,255,255,0.03); }
                    .studio-input { width: 100%; height: 100%; background: transparent; border: none; padding: 12px; color: #e2e8f0; font-size: 0.85rem; outline: none; }
                    .studio-input:focus { background: rgba(139, 92, 246, 0.05); }
                    .studio-row:hover { background: rgba(255,255,255,0.02); }
                    .studio-row.active { background: rgba(139, 92, 246, 0.08); }
                    
                    /* Live Mode Special Styles */
                    body.live-mode-active .app-sidebar, 
                    body.live-mode-active .app-header,
                    body.live-mode-active .footer { display: none !important; }
                    body.live-mode-active #admin-view { padding: 0 !important; }
                    
                    .live-pulse {
                        width: 12px; height: 12px; background: #ef4444; border-radius: 50%;
                        box-shadow: 0 0 10px #ef4444; animation: pulse 1.5s infinite;
                    }
                    @keyframes pulse { 0% { transform: scale(0.9); opacity: 1; } 100% { transform: scale(2); opacity: 0; } }
                </style>
            </div>
        `;
    },

    renderProjectSelector() {
        const series = State.data.series || [];
        return `
            <div style="display:flex; align-items:center; justify-content:center; height:100%; background:radial-gradient(circle at center, #161625, #0a0a0f);">
                <div class="glass-panel" style="width:450px; padding:40px; text-align:center; border-radius:30px;">
                    <div style="width:80px; height:80px; background:rgba(139, 92, 246, 0.1); border-radius:24px; display:flex; align-items:center; justify-content:center; margin:0 auto 20px;">
                        <i class="fa-solid fa-clapperboard" style="font-size:2.5rem; color:#8b5cf6;"></i>
                    </div>
                    <h2 style="color:#fff; margin-bottom:10px;">Proje Seçin</h2>
                    <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:30px;">Çeviriye başlamak için bir içerik ve bölüm seçmelisiniz.</p>
                    
                    <div style="text-align:left;">
                        <div class="form-group">
                            <label style="color:#64748b; font-size:0.75rem; font-weight:800; text-transform:uppercase; margin-bottom:8px; display:block;">İÇERİK</label>
                            <select id="studio-series-select" class="form-input" onchange="SubtitleStudio.updateEpisodeSelect(this.value)">
                                <option value="">İçerik Seçin...</option>
                                ${series.map(s => `<option value="${s.id}">${s.title}</option>`).join('')}
                            </select>
                        </div>
                        <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-top:15px;">
                            <div class="form-group">
                                <label style="color:#64748b; font-size:0.75rem; font-weight:800; text-transform:uppercase; margin-bottom:8px; display:block;">BÖLÜM</label>
                                <select id="studio-ep-select" class="form-input">
                                    <option value="">Önce içerik seçin</option>
                                </select>
                            </div>
                            <button onclick="SubtitleStudio.startProject()" class="btn btn-primary" style="margin-top:23px; height:45px; font-weight:800;">BAŞLA</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    updateEpisodeSelect(seriesId) {
        const select = document.getElementById('studio-ep-select');
        if (!select) return;
        
        const series = State.data.series.find(s => s.id === seriesId);
        if (!series || !series.episodes) {
            select.innerHTML = '<option value="">Bölüm bulunamadı</option>';
            return;
        }

        select.innerHTML = series.episodes.map(e => `<option value="${e.number}">Bölüm ${e.number} ${e.title ? '- ' + e.title : ''}</option>`).join('');
    },

    startProject() {
        const seriesId = document.getElementById('studio-series-select').value;
        const epNum = parseInt(document.getElementById('studio-ep-select').value);
        
        if (!seriesId || !epNum) return Toast.warning('Lütfen içerik ve bölüm seçin.');
        
        this.init(seriesId, epNum);
        ManagementHub.render();
    },

    inviteStaff() {
        const modal = document.getElementById('m-hub-modal');
        const staff = (State.data.users || []).filter(u => ['translator', 'editor', 'translator_chief'].includes(u.role));
        
        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width:400px;">
                <div class="modal-header">
                    <h2>Ekibi Çağır</h2>
                    <button onclick="ManagementHub.closeModal()">&times;</button>
                </div>
                <div style="padding:20px;">
                    <p style="color:#94a3b8; font-size:0.85rem; margin-bottom:15px;">Aktif çalışanları bu odaya davet edin.</p>
                    <div style="display:flex; flex-direction:column; gap:10px;">
                        ${staff.map(u => `
                            <div style="display:flex; align-items:center; justify-content:space-between; background:rgba(255,255,255,0.03); padding:10px; border-radius:12px;">
                                <div style="display:flex; align-items:center; gap:10px;">
                                    <img src="${u.avatar || 'assets/logo.png'}" style="width:30px; height:30px; border-radius:50%;">
                                    <span style="color:#fff; font-size:0.9rem;">${u.username}</span>
                                </div>
                                <button onclick="SubtitleStudio.sendInvite('${u.id}')" class="btn-sm btn-outline" style="font-size:0.65rem;">DAVET ET</button>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
        modal.style.display = 'flex';
    },

    sendInvite(userId) {
        if (!userId) return;
        
        const inviteData = {
            id: 'inv-' + Date.now(),
            from: State.currentUser.username,
            fromId: State.currentUser.id,
            seriesId: this.seriesId,
            epNum: this.epNum,
            type: 'studio_invite',
            at: Date.now()
        };

        // Push to user's notification/invite channel
        SyncService.push(`users/${userId}/notifications/${inviteData.id}`, inviteData);
        
        Toast.success('Çevirmen çağrıldı! Bildirim gönderildi.');
        ManagementHub.closeModal();
    },



    renderHub() {
        const adminView = document.getElementById('admin-view');
        if (adminView) {
            ManagementHub.render();
        }
    },

    renderSourcePicker() {
        const series = State.data.series.find(s => s.id === this.seriesId);
        const ep = series?.episodes.find(e => e.number === this.epNum);
        if (!ep || !ep.sources || ep.sources.length === 0) return '';

        return `
            <select onchange="document.getElementById('video-url-input').value = this.value; SubtitleStudio.loadVideo()" style="background: rgba(139, 92, 246, 0.1); border: 1px solid rgba(139, 92, 246, 0.2); color: #a78bfa; padding: 5px 15px; border-radius: 12px; font-size: 0.75rem; font-weight: 800; outline: none; cursor: pointer;">
                <option value="">Kaynak Seç...</option>
                ${ep.sources.map(src => `<option value="${src.url}" ${src.url === this.currentVideo ? 'selected' : ''}>${src.name}</option>`).join('')}
            </select>
        `;
    },

    loadVideo() {
        const url = document.getElementById('video-url-input').value.trim();
        if (!url) return;
        const video = document.getElementById('studio-video');
        video.src = url;
        video.load();
        video.ontimeupdate = () => {
            const timeDisplay = document.getElementById('studio-time-display');
            if (timeDisplay) timeDisplay.innerText = this.formatTime(video.currentTime);
            this.syncSubtitles();
        };
    },

    addLine() {
        const video = document.getElementById('studio-video');
        const start = video ? video.currentTime : 0;
        const newLine = {
            id: 'line_' + Date.now(),
            start: this.formatTime(start),
            end: this.formatTime(start + 2.5),
            sourceText: '',
            translation: '',
            status: 'draft'
        };
        this.subtitles.push(newLine);
        this.renderSpreadsheet();
    },

    renderSpreadsheet() {
        const body = document.getElementById('studio-spreadsheet-body');
        if (!body) return;

        body.innerHTML = this.subtitles.map((line, idx) => `
            <tr class="studio-row" id="row-${line.id}">
                <td style="text-align: center; color: #64748b; font-size: 0.7rem;">${idx + 1}</td>
                <td><input type="text" class="studio-input" value="${line.start}" onchange="SubtitleStudio.updateLine('${line.id}', 'start', this.value)"></td>
                <td><input type="text" class="studio-input" value="${line.end}" onchange="SubtitleStudio.updateLine('${line.id}', 'end', this.value)"></td>
                <td><input type="text" class="studio-input" value="${line.sourceText}" placeholder="Orijinal..." onchange="SubtitleStudio.updateLine('${line.id}', 'sourceText', this.value)"></td>
                <td><input type="text" class="studio-input" value="${line.translation}" placeholder="Çeviri..." onchange="SubtitleStudio.updateLine('${line.id}', 'translation', this.value)"></td>
                <td style="text-align: center;">
                    <span style="font-size: 0.6rem; padding: 3px 8px; border-radius: 5px; background: ${line.status === 'done' ? '#10b981' : '#f59e0b'}; color: #fff;">
                        ${line.status === 'done' ? 'BİTTİ' : 'DRAFT'}
                    </span>
                </td>
                <td style="text-align: center;">
                    <button onclick="SubtitleStudio.aiTranslateLine('${line.id}')" class="btn-icon" style="color: #8b5cf6; font-size: 0.9rem;" title="Gemini AI ile Çevir">
                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    },

    updateLine(id, field, value) {
        const line = this.subtitles.find(l => l.id === id);
        if (line) {
            line[field] = value;
            this.save();
        }
    },

    save() {
        const series = State.data.series.find(s => s.id === this.seriesId);
        const ep = series?.episodes.find(e => e.number === this.epNum);
        if (ep) {
            ep.subtitleData = this.subtitles;
            db.save();

            // Push to Real-time Sync
            SyncService.push(`studio/${this.seriesId}/${this.epNum}`, {
                subtitles: this.subtitles
            });
        }
    },

    playPause() {
        const video = document.getElementById('studio-video');
        if (video.paused) video.play(); else video.pause();
    },

    syncSubtitles() {
        const video = document.getElementById('studio-video');
        const overlay = document.getElementById('studio-subtitle-overlay');
        if (!video || !overlay) return;

        const currentTime = video.currentTime;
        const activeLine = this.subtitles.find(l => {
            const start = this.parseTime(l.start);
            const end = this.parseTime(l.end);
            return currentTime >= start && currentTime <= end;
        });

        overlay.innerText = activeLine ? activeLine.translation || activeLine.sourceText : '';
    },

    async aiTranslateLine(id) {
        const line = this.subtitles.find(l => l.id === id);
        if (!line || !line.sourceText) return Toast.warning('Önce orijinal metni girin.');

        Toast.info('Gemini AI çeviriyor...');
        
        try {
            // Mock Gemini API call (In production, this should hit a backend endpoint)
            // For now, we simulate a smart translation
            const translation = await this.mockGeminiTranslate(line.sourceText);
            line.translation = translation;
            line.status = 'done';
            this.renderSpreadsheet();
            this.save();
            Toast.success('AI Çevirisi Tamamlandı!');
        } catch (e) {
            Toast.error('AI Hatası oluştu.');
        }
    },

    async aiTranslateAll() {
        const lines = this.subtitles.filter(l => l.sourceText && !l.translation);
        if (lines.length === 0) return Toast.info('Çevrilecek boş satır bulunamadı.');

        if (!confirm(`${lines.length} satır Gemini AI tarafından çevrilecek. Onaylıyor musunuz?`)) return;

        Toast.info('Toplu AI çevirisi başladı...');
        
        for (let line of lines) {
            line.translation = await this.mockGeminiTranslate(line.sourceText);
            line.status = 'done';
        }

        this.renderSpreadsheet();
        this.save();
        Toast.success('Tüm boş satırlar çevrildi! ✨');
    },

    // Simulated Gemini API Logic
    async mockGeminiTranslate(text) {
        // This is where you'd fetch('api/gemini/translate.php', { method: 'POST', body: text })
        // For demonstration, let's do a simple mock or use a public free translation proxy
        return new Promise((resolve) => {
            setTimeout(() => {
                // Mock logic: Just capitalize or add " [AI]" for now
                // In a real app, this would be a fetch call.
                resolve(text + " (AI Çevirisi)");
            }, 800);
        });
    },

    formatTime(seconds) {
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = Math.floor(seconds % 60);
        const ms = Math.floor((seconds % 1) * 1000);
        return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')},${ms.toString().padStart(3, '0')}`;
    },

    parseTime(srtTime) {
        const [time, ms] = srtTime.split(',');
        const [h, m, s] = time.split(':').map(parseFloat);
        return h * 3600 + m * 60 + s + (parseFloat(ms) / 1000);
    },

    exportSRT() {
        if (this.subtitles.length === 0) {
            Toast.error('Dışa aktarılacak satır yok!');
            return;
        }

        let srtContent = '';
        this.subtitles.forEach((line, idx) => {
            srtContent += `${idx + 1}\n${line.start} --> ${line.end}\n${line.translation || line.sourceText}\n\n`;
        });

        const blob = new Blob([srtContent], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const series = State.data.series.find(s => s.id === this.seriesId);
        a.download = `${series ? series.title : 'dizi'}_bolum_${this.epNum}.srt`;
        a.click();
        Toast.success('SRT Dosyası İndirildi!');
    },

    toggleLive() {
        this.isLive = !this.isLive;
        const series = State.data.series.find(s => s.id === this.seriesId);

        if (this.isLive) {
            Toast.success('Canlı Yayın Başlatıldı!');
            const streamId = 'live-' + Date.now();
            const stream = {
                id: streamId,
                broadcasterId: State.currentUser.id,
                broadcasterName: State.currentUser.username,
                title: `${series?.title || 'İçerik'} - Bölüm ${this.epNum} Çeviri`,
                status: 'live',
                startTime: Date.now(),
                viewerCount: 1,
                seriesId: this.seriesId,
                epNum: this.epNum
            };
            
            if (!State.data.liveStreams) State.data.liveStreams = [];
            State.data.liveStreams.push(stream);
            
            // Push to Real-time
            SyncService.push('liveStreams/' + streamId, stream);

            // Create a Social Hub Post
            if (!State.data.socialPosts) State.data.socialPosts = [];
            const livePost = {
                id: 'post-live-' + Date.now(),
                userId: State.currentUser.id,
                username: State.currentUser.username,
                avatar: State.currentUser.avatar,
                text: `📺 Şu an **${series?.title}** Bölüm ${this.epNum} için canlı çeviri yapıyorum! Gelip izleyebilirsiniz.`,
                type: 'live_broadcast',
                liveId: streamId,
                at: Date.now(),
                likes: 0,
                comments: 0,
                status: 'active'
            };
            State.data.socialPosts.unshift(livePost);
            
            // Log Activity
            if (window.ActivityService) {
                ActivityService.logStaffAction(`Canlı çeviri yayını başlattı: ${series?.title}`);
            }
        } else {
            Toast.info('Canlı Yayın Kapatıldı.');
            if (State.data.liveStreams) {
                const myStream = State.data.liveStreams.find(s => s.broadcasterId === State.currentUser.id);
                if (myStream) {
                    myStream.status = 'ended';
                    SyncService.push('liveStreams/' + myStream.id, null);
                }
            }
        }
        db.save();
        ManagementHub.render();
    },

    async backupToDrive() {
        if (this.subtitles.length === 0) {
            Toast.error('Yedeklenecek içerik yok!');
            return;
        }

        let srtContent = '';
        this.subtitles.forEach((line, idx) => {
            srtContent += `${idx + 1}\n${line.start} --> ${line.end}\n${line.translation || line.sourceText}\n\n`;
        });

        const series = State.data.series.find(s => s.id === this.seriesId);
        const filename = `${series ? series.title : 'dizi'}_bolum_${this.epNum}_backup.srt`;

        await DriveService.uploadSRT(filename, srtContent);
    },

    sendMessage() {
        const input = document.getElementById('studio-chat-input');
        if (!input.value.trim()) return;
        
        const path = `chats/studio/${this.seriesId}_${this.epNum}`;
        const msg = {
            username: State.currentUser.username,
            text: input.value,
            avatar: State.currentUser.avatar,
            at: Date.now()
        };

        SyncService.push(`${path}/${Date.now()}`, msg);
        input.value = '';
    },

    exit() {
        if (confirm('Studio\'dan çıkmak istediğinize emin misiniz? Kaydedilmemiş değişiklikler kaybolabilir.')) {
            // Stop listeners
            SyncService.off(`studio/${this.seriesId}/${this.epNum}`);
            SyncService.off(`chats/studio/${this.seriesId}_${this.epNum}`);
            
            // Clean up live stream if any
            if (this.isLive) {
                if (State.data.liveStreams) {
                    const myStream = State.data.liveStreams.find(s => s.broadcasterId === State.currentUser.id);
                    if (myStream) {
                        myStream.status = 'ended';
                        SyncService.push('liveStreams/' + myStream.id, null);
                    }
                }
            }

            this.isLive = false;
            document.body.classList.remove('live-mode-active');
            App.router('admin');
        }
    }
};

window.SubtitleStudio = SubtitleStudio;
