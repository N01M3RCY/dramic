/**
 * Dramicbox Production Pipeline System (Kanban)
 * Manages the workflow of content translation and publication.
 */
if (typeof ProductionPipeline === 'undefined') {
    window.ProductionPipeline = {
    render(container) {
        if (!State.data.pipeline) {
            State.data.pipeline = [
                { id: 'p1', seriesId: 'the-impossible-heir', title: 'The Impossible Heir', episode: 5, status: 'translating', assigneeId: null, teamId: 't1', priority: 'high', type: 'drama' },
                { id: 'p2', seriesId: 'doctor-slump', title: 'Doctor Slump', episode: 12, status: 'pending_review', assigneeId: 'u1', teamId: null, priority: 'medium', type: 'drama' },
                { id: 'p3', seriesId: 'flex-x-cop', title: 'Flex X Cop', episode: 8, status: 'pending_translation', assigneeId: null, teamId: null, priority: 'low', type: 'drama' }
            ];
        }

        // Initialize filters if not present
        if (!this.filters) {
            this.filters = {
                type: 'all',
                staff: 'all',
                time: 'all'
            };
        }

        const columns = [
            { id: 'approval', title: 'Yeni İçerik Onayı', icon: 'fa-shield-check', color: '#f43f5e' },
            { id: 'pending_translation', title: 'Çeviri Bekliyor', icon: 'fa-hourglass-start', color: '#64748b' },
            { id: 'translating', title: 'Çeviriliyor', icon: 'fa-pen-nib', color: '#7c3aed' },
            { id: 'pending_review', title: 'Bölüm Denetimi', icon: 'fa-shield-halved', color: '#f59e0b' },
            { id: 'published', title: 'Yayında', icon: 'fa-circle-check', color: '#10b981' }
        ];

        const html = `
            <div class="pipeline-board-container" style="padding: 10px;">
                <div class="pipeline-header-controls glass-panel" style="padding: 20px; border-radius: 20px; margin-bottom: 25px; display: flex; flex-wrap: wrap; gap: 15px; justify-content: space-between; align-items: center;">
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <!-- Type Filter -->
                        <div class="filter-select-group">
                            <label style="display: block; font-size: 0.65rem; color: #64748b; font-weight: 800; margin-bottom: 5px; text-transform: uppercase;">İçerik Türü</label>
                            <select onchange="ProductionPipeline.setFilter('type', this.value)" style="background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 8px 12px; border-radius: 10px; font-weight: 700;">
                                <option value="all" ${this.filters.type === 'all' ? 'selected' : ''}>Tümü</option>
                                <option value="drama" ${this.filters.type === 'drama' ? 'selected' : ''}>Dizi (KDrama)</option>
                                <option value="webtoon" ${this.filters.type === 'webtoon' ? 'selected' : ''}>Webtoon</option>
                                <option value="movie" ${this.filters.type === 'movie' ? 'selected' : ''}>Film</option>
                                <option value="blog" ${this.filters.type === 'blog' ? 'selected' : ''}>Blog / Haber</option>
                            </select>
                        </div>

                        <!-- Staff Filter -->
                        <div class="filter-select-group">
                            <label style="display: block; font-size: 0.65rem; color: #64748b; font-weight: 800; margin-bottom: 5px; text-transform: uppercase;">Ekip Filtresi</label>
                            <select onchange="ProductionPipeline.setFilter('staff', this.value)" style="background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 8px 12px; border-radius: 10px; font-weight: 700;">
                                <option value="all" ${this.filters.staff === 'all' ? 'selected' : ''}>Tüm Ekipler</option>
                                ${State.data.teams?.map(t => `<option value="${t.id}" ${this.filters.staff === t.id ? 'selected' : ''}>${t.name}</option>`).join('') || ''}
                            </select>
                        </div>

                        <!-- Time Filter -->
                        <div class="filter-select-group">
                            <label style="display: block; font-size: 0.65rem; color: #64748b; font-weight: 800; margin-bottom: 5px; text-transform: uppercase;">Zaman Aralığı</label>
                            <select onchange="ProductionPipeline.setFilter('time', this.value)" style="background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 8px 12px; border-radius: 10px; font-weight: 700;">
                                <option value="all" ${this.filters.time === 'all' ? 'selected' : ''}>Tüm Zamanlar</option>
                                <option value="24h" ${this.filters.time === '24h' ? 'selected' : ''}>Son 24 Saat</option>
                                <option value="week" ${this.filters.time === 'week' ? 'selected' : ''}>Son 1 Hafta</option>
                            </select>
                        </div>
                    </div>

                    <div style="display: flex; gap: 15px;">
                        <div class="glass-panel" style="padding: 10px 20px; border-radius: 12px; background: rgba(139, 92, 246, 0.1);">
                            <div style="font-size: 0.6rem; color: #a78bfa; font-weight: 800; text-transform: uppercase;">Aktif Akış</div>
                            <div style="font-size: 1.1rem; font-weight: 900; color: #fff;">${State.data.pipeline.length} Görev</div>
                        </div>
                    </div>
                </div>

                <div class="pipeline-board" style="display: flex; gap: 20px; overflow-x: auto; padding-bottom: 20px; min-height: 650px;">
                    ${columns.map(col => this.renderColumn(col)).join('')}
                </div>
            </div>
            
            <style>
                .pipeline-board { scrollbar-width: thin; scrollbar-color: rgba(255,255,255,0.1) transparent; }
                .pipeline-column {
                    flex: 1;
                    min-width: 320px;
                    max-width: 400px;
                    background: rgba(255,255,255,0.01);
                    border: 1px solid rgba(255,255,255,0.04);
                    border-radius: 24px;
                    display: flex;
                    flex-direction: column;
                    height: fit-content;
                }
                .pipeline-header {
                    padding: 20px;
                    border-bottom: 1px solid rgba(255,255,255,0.05);
                    display: flex;
                    align-items: center;
                    gap: 12px;
                }
                .pipeline-cards {
                    padding: 15px;
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                    min-height: 100px;
                }
                .pipeline-card {
                    background: rgba(255,255,255,0.03);
                    border: 1px solid rgba(255,255,255,0.06);
                    border-radius: 20px;
                    padding: 20px;
                    cursor: grab;
                    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                    position: relative;
                    overflow: hidden;
                }
                .pipeline-card:hover {
                    background: rgba(255,255,255,0.05);
                    border-color: rgba(139, 92, 246, 0.3);
                    transform: translateY(-3px) scale(1.01);
                    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                }
                .pipeline-card:active { cursor: grabbing; }
                .priority-tag {
                    font-size: 0.6rem;
                    padding: 3px 10px;
                    border-radius: 50px;
                    text-transform: uppercase;
                    font-weight: 900;
                    letter-spacing: 0.5px;
                    margin-bottom: 12px;
                    display: inline-block;
                }
                .priority-high { background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.2); }
                .priority-medium { background: rgba(245,158,11,0.15); color: #f59e0b; border: 1px solid rgba(245,158,11,0.2); }
                .priority-low { background: rgba(16,185,129,0.15); color: #10b981; border: 1px solid rgba(16,185,129,0.2); }
                
                .team-badge {
                    background: rgba(139, 92, 246, 0.1);
                    color: #a78bfa;
                    font-size: 0.65rem;
                    padding: 2px 8px;
                    border-radius: 6px;
                    font-weight: 800;
                    display: flex;
                    align-items: center;
                    gap: 4px;
                }
            </style>
        `;

        if (container) {
            container.innerHTML = html;
        }
        return html;
    },

    setFilter(key, val) {
        this.filters[key] = val;
        ManagementHub.render();
    },

    renderColumn(col) {
        let items = [];
        
        if (col.id === 'approval') {
            // Fetch from pendingApprovals
            items = (State.data.pendingApprovals || []).map(p => ({
                id: p.id,
                title: p.title || p.name,
                status: 'approval',
                priority: 'medium',
                type: p.type || 'drama',
                createdAt: p.createdAt,
                isApprovalItem: true,
                submitter: p.submitterUsername
            }));
        } else {
            items = State.data.pipeline.filter(item => item.status === col.id);
        }

        // Apply Filters
        if (this.filters.type !== 'all') {
            items = items.filter(item => (item.type || '').toLowerCase() === this.filters.type);
        }
        
        if (this.filters.staff !== 'all') {
            items = items.filter(item => item.teamId === this.filters.staff || item.assigneeId === this.filters.staff);
        }

        if (this.filters.time !== 'all') {
            const now = Date.now();
            const oneDay = 24 * 60 * 60 * 1000;
            const oneWeek = 7 * oneDay;
            
            items = items.filter(item => {
                const date = new Date(item.createdAt || item.addedAt || 0).getTime();
                if (this.filters.time === '24h') return (now - date) <= oneDay;
                if (this.filters.time === 'week') return (now - date) <= oneWeek;
                return true;
            });
        }
        
        return `
            <div class="pipeline-column" ondragover="event.preventDefault()" ondrop="ProductionPipeline.handleDrop(event, '${col.id}')">
                <div class="pipeline-header">
                    <div style="width: 10px; height: 10px; border-radius: 50%; background: ${col.color}; box-shadow: 0 0 10px ${col.color}44;"></div>
                    <h3 style="margin: 0; font-size: 0.9rem; color: #fff; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px;">${col.title}</h3>
                    <span style="margin-left: auto; background: rgba(255,255,255,0.05); padding: 4px 10px; border-radius: 12px; font-size: 0.75rem; color: #94a3b8; font-weight: 700;">${items.length}</span>
                </div>
                <div class="pipeline-cards">
                    ${items.map(item => this.renderCard(item)).join('')}
                    ${col.id !== 'approval' ? `
                    <button onclick="ProductionPipeline.openAddModal('${col.id}')" style="background: rgba(255,255,255,0.02); border: 1px dashed rgba(255,255,255,0.1); color: #64748b; padding: 15px; border-radius: 16px; cursor: pointer; transition: 0.2s; font-weight: 700; font-size: 0.8rem; display: flex; align-items: center; justify-content: center; gap: 8px;" onmouseenter="this.style.borderColor='rgba(139, 92, 246, 0.3)'; this.style.color='#a78bfa'" onmouseleave="this.style.borderColor='rgba(255,255,255,0.1)'; this.style.color='#64748b'">
                        <i class="fa-solid fa-plus-circle"></i> Görev Ekle
                    </button>
                    ` : ''}
                </div>
            </div>
        `;
    },

    renderCard(item) {
        const team = item.teamId ? State.data.teams?.find(t => t.id === item.teamId) : null;
        const assignee = item.assigneeId ? State.data.users?.find(u => u.id === item.assigneeId) : null;
        const priorityLabels = { high: 'Yüksek', medium: 'Orta', low: 'Düşük' };

        return `
            <div class="pipeline-card" draggable="${!item.isApprovalItem}" ondragstart="event.dataTransfer.setData('text/plain', '${item.id}')">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 12px;">
                    <span class="priority-tag priority-${item.priority || 'medium'}">${priorityLabels[item.priority] || 'Orta'}</span>
                    ${item.isApprovalItem ? `
                        <button onclick="ProductionPipeline.approveNewContent('${item.id}')" class="btn-sm violet-btn" style="padding: 5px 12px; font-size: 0.7rem;"><i class="fa-solid fa-check-double"></i> ONAYLA</button>
                    ` : `
                        <button onclick="ProductionPipeline.openEditModal('${item.id}')" style="background: none; border: none; color: #475569; cursor: pointer; transition: 0.2s;" onmouseenter="this.style.color='#fff'"><i class="fa-solid fa-ellipsis"></i></button>
                    `}
                </div>
                
                <div style="font-weight: 800; color: #fff; font-size: 1rem; margin-bottom: 5px; letter-spacing: -0.3px;">${item.title}</div>
                <div style="font-size: 0.8rem; color: #94a3b8; margin-bottom: 15px; display: flex; align-items: center; gap: 6px;">
                    ${item.isApprovalItem ? `
                        <i class="fa-solid fa-user-plus" style="font-size: 0.7rem; color: #f43f5e;"></i> Ekleyen: ${item.submitter || 'Admin'}
                    ` : `
                        <i class="fa-solid fa-layer-group" style="font-size: 0.7rem; color: #8b5cf6;"></i> Bölüm ${item.episode}
                    `}
                    <span style="margin-left: auto; font-size: 0.65rem; background: rgba(0,0,0,0.2); padding: 2px 6px; border-radius: 4px;">${(item.type || 'Drama').toUpperCase()}</span>
                </div>
                
                <div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 15px;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        ${item.isApprovalItem ? `
                             <span style="font-size: 0.7rem; color: #64748b;"><i class="fa-solid fa-clock"></i> ${new Date(item.createdAt).toLocaleDateString()}</span>
                        ` : (team ? `
                            <div class="team-badge" title="Ekip: ${team.name}">
                                <i class="fa-solid fa-users-viewfinder"></i> ${team.name}
                            </div>
                        ` : `
                            <img src="${assignee?.avatar || 'assets/logo.png'}" style="width: 24px; height: 24px; border-radius: 8px; object-fit: cover; border: 1px solid rgba(255,255,255,0.1);">
                            <span style="font-size: 0.75rem; color: #cbd5e1; font-weight: 600;">${assignee?.username || 'Atanmamış'}</span>
                        `)}
                    </div>
                    <div style="display: flex; gap: 5px;">
                         ${item.status === 'pending_review' ? '<i class="fa-solid fa-shield-check" style="color: #f59e0b;" title="Onay Bekliyor"></i>' : ''}
                         ${item.status === 'published' ? '<i class="fa-solid fa-circle-check" style="color: #10b981;" title="Yayında"></i>' : ''}
                    </div>
                </div>
            </div>
        `;
    },

    async approveNewContent(approvalId) {
        if (!confirm('Bu içeriği onaylayıp kütüphaneye eklemek istediğinize emin misiniz?')) return;
        
        const approvalItem = State.data.pendingApprovals?.find(p => p.id === approvalId);
        if (!approvalItem) return;

        // Add to main series list
        if (!State.data.series) State.data.series = [];
        
        // Remove from approvals
        State.data.pendingApprovals = State.data.pendingApprovals.filter(p => p.id !== approvalId);
        
        // Finalize object
        const seriesObj = { ...approvalItem, status: 'Aktif' };
        delete seriesObj.isApprovalItem;
        
        State.data.series.unshift(seriesObj);
        
        // Sync to filesystem
        await db.syncItem('series', seriesObj, true);
        
        Toast.success(`${seriesObj.title} onaylandı ve yayına hazır!`);
        ManagementHub.render();
    },

    async handleDrop(e, status) {
        e.preventDefault();
        const itemId = e.dataTransfer.getData('text/plain');
        const item = State.data.pipeline.find(i => i.id === itemId);
        
        if (item && item.status !== status) {
            const oldStatus = item.status;
            item.status = status;

            // Integration Hooks
            if (status === 'pending_review') {
                this.triggerApprovalFlow(item);
            }
            
            if (status === 'published') {
                this.triggerPublishFlow(item);
            }

            await db.save();
            ManagementHub.render();
            Toast.success(`${item.title} durumu güncellendi.`);
            
            // Log activity
            if (window.ActivityService) {
                ActivityService.logStaffAction(`Görev durumunu değiştirdi: ${item.title} (Bölüm ${item.episode}) -> ${status}`);
            }
        }
    },

    triggerApprovalFlow(item) {
        // Integrate with ManagementHub's Approval System
        if (!State.data.pendingApprovals) State.data.pendingApprovals = [];
        
        const alreadyPending = State.data.pendingApprovals.some(p => p.pipelineId === item.id);
        if (!alreadyPending) {
            const approvalItem = {
                id: 'appr-' + Date.now(),
                pipelineId: item.id,
                title: `${item.title} - Bölüm ${item.episode}`,
                type: 'translation_review',
                submitterUsername: State.currentUser.username,
                createdAt: new Date().toISOString(),
                data: item
            };
            State.data.pendingApprovals.unshift(approvalItem);
            Toast.info('İçerik onay merkezine gönderildi.');
        }
    },

    async triggerPublishFlow(item) {
        // Find actual series and update episode status if it exists
        const series = State.data.series?.find(s => s.id === item.seriesId || s.title === item.title);
        if (series) {
            if (!series.episodes) series.episodes = [];
            const episode = series.episodes?.find(e => e.number == item.episode);
            if (episode) {
                episode.translationStatus = 100;
                episode.isPublished = true;
                episode.status = 'Aktif';
                
                // If series was "Upcoming", make it "Active"
                if (series.status === 'Yakında') {
                    series.status = 'Aktif';
                }

                Toast.success(`${series.title} Bölüm ${item.episode} başarıyla yayınlandı!`);
            } else {
                // If episode doesn't exist, create a draft episode
                series.episodes.push({
                    number: item.episode,
                    title: `Bölüm ${item.episode}`,
                    translationStatus: 100,
                    isPublished: true,
                    status: 'Aktif',
                    addedAt: new Date().toISOString()
                });
                Toast.info('Bölüm kütüphanede bulunamadı, yeni (taslak) bölüm olarak oluşturuldu.');
            }
            await db.save();
        }
    },

    openAddModal(status) {
        const modal = document.getElementById('m-hub-modal');
        const teams = State.data.teams || [];
        const staff = State.data.users?.filter(u => ['translator', 'editor', 'translator_chief'].includes(u.role)) || [];
        const seriesList = State.data.series || [];

        modal.innerHTML = `
            <div class="modal-content glass-panel" style="max-width: 500px; padding: 30px; border-radius: 30px;">
                <div class="modal-header" style="margin-bottom: 25px;">
                    <h2 style="margin: 0; font-size: 1.4rem;">🎯 Yeni Üretim Görevi</h2>
                    <button onclick="ManagementHub.closeModal()" style="background: none; border: none; color: #fff; font-size: 1.5rem; cursor: pointer;">&times;</button>
                </div>
                <form id="pipeline-add-form" onsubmit="ProductionPipeline.saveNewItem(event, '${status}')">
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label style="display: block; color: #94a3b8; font-size: 0.75rem; font-weight: 800; margin-bottom: 8px; text-transform: uppercase;">İçerik Seçin</label>
                        <select name="seriesId" class="form-input" required onchange="ProductionPipeline.updateTitleFromSelect(this)">
                            <option value="">İçerik Seçin...</option>
                            ${seriesList.map(s => `<option value="${s.id}">${s.title}</option>`).join('')}
                            <option value="other">Diğer (Manuel Gir)</option>
                        </select>
                    </div>
                    <div id="manual-title-group" class="form-group" style="margin-bottom: 20px; display: none;">
                        <label style="display: block; color: #94a3b8; font-size: 0.75rem; font-weight: 800; margin-bottom: 8px; text-transform: uppercase;">Manuel Başlık</label>
                        <input type="text" name="manualTitle" class="form-input" placeholder="Dizi/Film Adı">
                    </div>
                    <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                        <div class="form-group">
                            <label style="display: block; color: #94a3b8; font-size: 0.75rem; font-weight: 800; margin-bottom: 8px; text-transform: uppercase;">Bölüm No</label>
                            <input type="number" name="episode" class="form-input" required value="1">
                        </div>
                        <div class="form-group">
                            <label style="display: block; color: #94a3b8; font-size: 0.75rem; font-weight: 800; margin-bottom: 8px; text-transform: uppercase;">Öncelik</label>
                            <select name="priority" class="form-input">
                                <option value="low">Düşük</option>
                                <option value="medium" selected>Orta</option>
                                <option value="high">Yüksek</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group" style="margin-bottom: 25px;">
                        <label style="display: block; color: #94a3b8; font-size: 0.75rem; font-weight: 800; margin-bottom: 8px; text-transform: uppercase;">Atama (Ekip veya Personel)</label>
                        <select name="assignment" class="form-input">
                            <option value="">Seçilmedi</option>
                            <optgroup label="EKİPLER">
                                ${teams.map(t => `<option value="team:${t.id}">👥 ${t.name}</option>`).join('')}
                            </optgroup>
                            <optgroup label="PERSONEL">
                                ${staff.map(u => `<option value="user:${u.id}">👤 ${u.username}</option>`).join('')}
                            </optgroup>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block" style="padding: 15px; font-weight: 800;">GÖREVİ BAŞLAT</button>
                </form>
            </div>
        `;
        modal.style.display = 'flex';
    },

    updateTitleFromSelect(select) {
        const manualGroup = document.getElementById('manual-title-group');
        manualGroup.style.display = select.value === 'other' ? 'block' : 'none';
    },

    async saveNewItem(e, status) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const seriesId = formData.get('seriesId');
        const manualTitle = formData.get('manualTitle');
        const assignment = formData.get('assignment') || '';
        
        let title = '';
        if (seriesId === 'other') {
            title = manualTitle || 'İsimsiz Görev';
        } else {
            title = State.data.series.find(s => s.id === seriesId)?.title || 'Bilinmeyen';
        }

        const newItem = {
            id: 'p-' + Date.now(),
            seriesId: seriesId === 'other' ? null : seriesId,
            title: title,
            episode: parseInt(formData.get('episode')),
            status: status,
            priority: formData.get('priority'),
            assigneeId: assignment.startsWith('user:') ? assignment.split(':')[1] : null,
            teamId: assignment.startsWith('team:') ? assignment.split(':')[1] : null,
            createdAt: new Date().toISOString()
        };

        State.data.pipeline.push(newItem);
        await db.save();
        ManagementHub.closeModal();
        ManagementHub.render();
        Toast.success('Üretim hattına yeni görev eklendi.');
    },

    openEditModal(id) {
        const item = State.data.pipeline.find(i => i.id === id);
        if (!item) return;
        
        // Simple delete for now as requested for integration
        if (confirm(`${item.title} görevini hattan kaldırmak istiyor musunuz?`)) {
            State.data.pipeline = State.data.pipeline.filter(i => i.id !== id);
            db.save();
            ManagementHub.render();
            Toast.info('Görev kaldırıldı.');
        }
    }
};
}

window.ProductionPipeline = ProductionPipeline;
console.log('📋 Production Pipeline Integrated with Teams & Approvals!');
