/**
 * Webtoon Studio - Image-Based Translation Center
 */

const WebtoonStudio = {
    seriesId: null,
    chapterNum: null,
    pages: [],
    translations: [],
    currentIndex: 0,

    init(seriesId, chapterNum) {
        this.seriesId = seriesId;
        this.chapterNum = chapterNum;
        
        const series = State.data.series.find(s => s.id === seriesId);
        const chapter = series?.chapters?.find(c => c.number === chapterNum);
        
        this.pages = chapter?.pages || [];
        this.translations = chapter?.translations || this.pages.map(() => ({ source: '', translation: '', status: 'pending' }));
        
        console.log('📖 Webtoon Studio Initialized for:', series?.title);
        this.render();
    },

    render() {
        const view = document.getElementById('admin-view');
        if (!view) return;

        view.innerHTML = `
            <div class="webtoon-studio-container" style="display: grid; grid-template-columns: 1fr 450px; height: 100vh; background: #0a0a0f;">
                <!-- Page Viewer -->
                <div class="studio-viewer" style="overflow-y: auto; padding: 40px; display: flex; flex-direction: column; align-items: center; background: #050508;">
                    <div class="viewer-header" style="width: 100%; max-width: 800px; display: flex; justify-content: space-between; margin-bottom: 20px;">
                        <h2 style="color: #fff; margin: 0;">Sayfa #${this.currentIndex + 1}</h2>
                        <div style="display: flex; gap: 10px;">
                            <button onclick="WebtoonStudio.prevPage()" class="btn btn-outline"><i class="fa-solid fa-chevron-left"></i> Geri</button>
                            <button onclick="WebtoonStudio.nextPage()" class="btn btn-outline">İleri <i class="fa-solid fa-chevron-right"></i></button>
                        </div>
                    </div>
                    
                    <div class="page-container" style="position: relative; width: 100%; max-width: 800px; background: #000; border-radius: 12px; overflow: hidden; box-shadow: 0 20px 50px rgba(0,0,0,0.5);">
                        ${this.pages[this.currentIndex] ? `<img src="${this.pages[this.currentIndex]}" style="width: 100%;">` : '<div style="padding: 100px; text-align: center; color: #444;">Görsel Yüklenemedi</div>'}
                    </div>
                </div>

                <!-- Translation Panel (Spreadsheet Style) -->
                <div class="studio-sidebar" style="background: rgba(15, 15, 20, 0.95); border-left: 1px solid rgba(255,255,255,0.05); display: flex; flex-direction: column;">
                    <div style="padding: 25px; border-bottom: 1px solid rgba(255,255,255,0.05);">
                        <h3 style="color: #fff; margin: 0; font-size: 1.1rem;"><i class="fa-solid fa-language" style="color: #8b5cf6; margin-right: 8px;"></i> WEBTOON ÇEVİRİ HUB</h3>
                        <p style="color: #64748b; font-size: 0.75rem; margin: 5px 0 0;">Her sayfa için balon metinlerini girin.</p>
                    </div>

                    <div class="translation-list custom-scroll" style="flex: 1; overflow-y: auto; padding: 20px;">
                        ${this.translations.map((t, idx) => `
                            <div class="trans-item ${this.currentIndex === idx ? 'active' : ''}" onclick="WebtoonStudio.goToPage(${idx})" style="padding: 15px; background: ${this.currentIndex === idx ? 'rgba(139, 92, 246, 0.1)' : 'rgba(255,255,255,0.02)'}; border-radius: 12px; margin-bottom: 10px; border: 1px solid ${this.currentIndex === idx ? '#8b5cf6' : 'transparent'}; cursor: pointer;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                    <span style="font-size: 0.7rem; color: #475569; font-weight: 800;">SAYFA ${idx + 1}</span>
                                    <span class="status-badge ${t.status}">${t.status.toUpperCase()}</span>
                                </div>
                                <textarea placeholder="Orijinal Metin..." oninput="WebtoonStudio.updateTrans(${idx}, 'source', this.value)" style="width: 100%; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.05); color: #94a3b8; font-size: 0.8rem; padding: 8px; border-radius: 6px; margin-bottom: 8px; resize: none;">${t.source}</textarea>
                                <textarea placeholder="Çeviri Metni..." oninput="WebtoonStudio.updateTrans(${idx}, 'translation', this.value)" style="width: 100%; background: rgba(139, 92, 246, 0.05); border: 1px solid rgba(139, 92, 246, 0.2); color: #fff; font-size: 0.85rem; padding: 8px; border-radius: 6px; resize: none;">${t.translation}</textarea>
                            </div>
                        `).join('')}
                    </div>

                    <div style="padding: 25px; border-top: 1px solid rgba(255,255,255,0.05); display: flex; gap: 10px;">
                        <button onclick="WebtoonStudio.save()" class="btn btn-primary" style="flex: 1;"><i class="fa-solid fa-floppy-disk"></i> KAYDET</button>
                        <button onclick="App.router('admin')" class="btn btn-outline"><i class="fa-solid fa-right-from-bracket"></i> ÇIKIŞ</button>
                    </div>
                </div>
            </div>
        `;
    },

    goToPage(index) {
        this.currentIndex = index;
        this.render();
    },

    nextPage() {
        if (this.currentIndex < this.pages.length - 1) {
            this.currentIndex++;
            this.render();
        }
    },

    prevPage() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
            this.render();
        }
    },

    updateTrans(index, field, value) {
        this.translations[index][field] = value;
        this.translations[index].status = this.translations[index].translation ? 'done' : 'pending';
    },

    save() {
        const series = State.data.series.find(s => s.id === this.seriesId);
        const chapter = series?.chapters?.find(c => c.number === this.chapterNum);
        if (chapter) {
            chapter.translations = this.translations;
            db.save();
            Toast.success('Webtoon çevirileri kaydedildi!');
        }
    }
};

window.WebtoonStudio = WebtoonStudio;
