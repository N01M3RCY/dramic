// Country Flags Utility
const CountryFlags = {
    // Country code mapping
    codes: {
        'Kore': 'kr',
        'Çin': 'cn',
        'Tayvan': 'tw',
        'Tayland': 'th',
        'ABD': 'us',
        'Japonya': 'jp',
        'Korea': 'kr',
        'China': 'cn',
        'Taiwan': 'tw',
        'Thailand': 'th',
        'USA': 'us',
        'Japan': 'jp'
    },

    // Emoji flags
    emojis: {
        'Kore': '🇰🇷',
        'Çin': '🇨🇳',
        'Tayvan': '🇹🇼',
        'Tayland': '🇹🇭',
        'ABD': '🇺🇸',
        'Japonya': '🇯🇵',
        'Korea': '🇰🇷',
        'China': '🇨🇳',
        'Taiwan': '🇹🇼',
        'Thailand': '🇹🇭',
        'USA': '🇺🇸',
        'Japan': '🇯🇵'
    },

    getCode(country) {
        return this.codes[country] || 'kr'; // Default to Korea
    },

    getEmoji(country) {
        return this.emojis[country] || '🇰🇷';
    },

    getFlagUrl(country) {
        const code = this.getCode(country);
        return `assets/flags/${code}.png`;
    },

    // Generate flag HTML for series card
    getFlagHTML(country) {
        if (!country) return '';

        const emoji = this.getEmoji(country);
        const url = this.getFlagUrl(country);

        return `
            <div class="country-flag-overlay" title="${country}">
                <img src="${url}" alt="${country}" onerror="this.style.display='none'">
            </div>
        `;
    },

    // Generate genre tag HTML
    getGenreHTML(genre) {
        if (!genre) return '';

        // Handle multiple genres
        const genres = Array.isArray(genre) ? genre : [genre];

        return genres.map(g => `<span class="genre-tag">${g}</span>`).join('');
    }
};

window.CountryFlags = CountryFlags;
console.log('✅ Country Flags Utility Loaded!');
