if (typeof NotificationSystem === 'undefined') {
    const NotificationSystem = {
        pollInterval: null,
        notifications: [],
        isOpen: false,
        activeFilter: 'all',
        apiUrl: 'api/Router.php',

        init() {
            if (!State.currentUser) return;

            console.log('🔔 Notification System: Synchronizing with backend...');

            // Load INITIAL from storage (for immediate display)
            this.loadLocal();

            // Update UI
            this.updateBadge();

            // Initial Fetch from server
            this.fetchFromServer();

            // Start Polling for new notifications
            if (this.pollInterval) clearInterval(this.pollInterval);
            this.pollInterval = setInterval(() => {
                if (document.visibilityState === 'visible') {
                    this.fetchFromServer();
                    this.checkLocalNotifications(); // Fallback for local actions
                }
            }, 10000); // Poll every 10s


            // Check for calendar reminders
            this.checkCalendarReminders();

            // Request Push Permission
            this.initPush();
        },

        async initPush() {
            if (!('Notification' in window) || !('serviceWorker' in navigator)) return;

            if (Notification.permission === 'default') {
                // Show a gentle prompt first or wait for interaction
                console.log('🔔 Web Push: Permission pending...');
            } else if (Notification.permission === 'granted') {
                this.subscribeUserToPush();
            }
        },

        async requestPushPermission() {
            if (!('Notification' in window)) return;
            
            const permission = await Notification.requestPermission();
            if (permission === 'granted') {
                Toast.success('Bildirimler etkinleştirildi!');
                this.subscribeUserToPush();
            }
        },

        async subscribeUserToPush() {
            try {
                const registration = await navigator.serviceWorker.ready;
                const subscription = await registration.pushManager.subscribe({
                    userVisibleOnly: true,
                    applicationServerKey: 'BEl62vp95WKO7EBvt94JslL9adApeN_F9T5iSeeS_p70Qz93zW+ad-9W67ad-9adA' // Placeholder VAPID Key
                });

                console.log('🔔 Web Push: Subscribed!', subscription);
                this.saveSubscriptionToServer(subscription);
            } catch (error) {
                console.warn('❌ Web Push: Subscription failed', error);
            }
        },

        async saveSubscriptionToServer(subscription) {
            if (!State.currentUser) return;
            try {
                await fetch(`${this.apiUrl}?action=notif-save-subscription`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ subscription })
                });
            } catch (e) {
                console.error('Failed to save subscription:', e);
            }
        },

        checkLocalNotifications() {
            // Placeholder for local notification logic if needed
            // Currently syncGlobalAnnouncements handles most logic
            this.syncGlobalAnnouncements();
        },

        checkCalendarReminders() {
            if (!State.currentUser || !State.currentUser.calendarReminders || State.currentUser.calendarReminders.length === 0) return;

            const days = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
            const todayIndex = new Date().getDay();
            const currentDayName = days[todayIndex];

            const todayBroadcasts = State.data.calendar.filter(c => c.day === currentDayName);
            
            State.currentUser.calendarReminders.forEach(seriesId => {
                const broadcast = todayBroadcasts.find(b => b.seriesId === seriesId);
                if (broadcast) {
                    const series = State.data.series.find(s => s.id === seriesId);
                    if (series) {
                        // Check if we already notified today for this series
                        const lastNotifiedKey = `last_notified_${seriesId}_${new Date().toDateString()}`;
                        if (!localStorage.getItem(lastNotifiedKey)) {
                            this.addLocalNotification({
                                title: 'Bölüm Hatırlatıcısı!',
                                message: `${series.title} dizisinin yeni bölümü bugün ${broadcast.time || '20:00'}'da yayınlanıyor!`,
                                type: 'content',
                                link: `detail/${seriesId}`
                            });
                            localStorage.setItem(lastNotifiedKey, 'true');
                        }
                    }
                }
            });
        },

        addLocalNotification(notif) {
            const newNotif = {
                id: 'local_' + Date.now(),
                title: notif.title,
                message: notif.message,
                type: notif.type || 'info',
                time: Date.now(),
                read: false,
                link: notif.link || '',
                image: notif.image || null
            };

            this.notifications.unshift(newNotif);
            this.saveLocal();
            this.updateBadge();
            
            // Instant UI update if open
            if (this.isOpen) {
                this.renderPanel();
            } else {
                // Play subtle sound if possible or show toast
                if (typeof Toast !== 'undefined') {
                    Toast.info(notif.message, 5000);
                }
            }
        },

        loadLocal() {
            const stored = localStorage.getItem(`notifications_${State.currentUser.id}`);
            if (stored) {
                try { this.notifications = JSON.parse(stored); } catch (e) { this.notifications = []; }
            }

            // Sync with global announcements from State.data
            this.syncGlobalAnnouncements();
        },

        syncGlobalAnnouncements() {
            if (!State.data.notifications) return;

            // Merge announcements that are NOT already in the local list
            State.data.notifications.forEach(ann => {
                const exists = this.notifications.some(n => n.id === ann.id);
                if (!exists) {
                    this.notifications.unshift({
                        id: ann.id,
                        title: ann.title,
                        message: ann.message,
                        link: ann.link,
                        image: ann.image || null,
                        type: ann.type || 'system',
                        time: ann.timestamp || Date.now(),
                        read: false
                    });
                }
            });

            // Keep only last 50
            if (this.notifications.length > 50) this.notifications = this.notifications.slice(0, 50);
            this.saveLocal();
        },

        saveLocal() {
            if (!State.currentUser) return;
            localStorage.setItem(`notifications_${State.currentUser.id}`, JSON.stringify(this.notifications));
        },

        async fetchFromServer() {
            if (!State.currentUser) return;
            // Local-first: Only sync with State.data for now
            this.syncGlobalAnnouncements();
            this.updateBadge();
            if (this.isOpen) this.renderPanel();
        },

        togglePanel() {
            const panel = document.getElementById('notification-panel');
            if (!panel) return;

            this.isOpen = !this.isOpen;
            if (this.isOpen) {
                panel.classList.add('active');
                document.body.classList.add('drawer-open');
                this.renderPanel();
            } else {
                panel.classList.remove('active');
                document.body.classList.remove('drawer-open');
            }
        },

        closePanel() {
            this.isOpen = false;
            const panel = document.getElementById('notification-panel');
            if (panel) panel.classList.remove('active');
            document.body.classList.remove('drawer-open');
        },

        switchFilter(filter) {
            this.activeFilter = filter;
            document.querySelectorAll('.notif-tab').forEach(t => t.classList.remove('active'));
            const activeTab = document.querySelector(`.notif-tab[data-filter="${filter}"]`);
            if (activeTab) activeTab.classList.add('active');
            this.renderPanel();
        },

        updateBadge() {
            const badge = document.getElementById('notification-count');
            const unreadCount = this.notifications.filter(n => !n.read).length;

            if (badge) {
                if (unreadCount > 0) {
                    badge.style.display = 'flex';
                    badge.innerText = unreadCount > 99 ? '99+' : unreadCount;
                    badge.classList.add('pulse');
                } else {
                    badge.style.display = 'none';
                    badge.classList.remove('pulse');
                }
            }
        },

        renderPanel() {
            const listContainer = document.getElementById('notification-list-ul');
            if (!listContainer) return;

            let filtered = this.notifications;
            if (this.activeFilter !== 'all') {
                filtered = this.notifications.filter(n => n.type === this.activeFilter);
            }

            if (filtered.length === 0) {
                listContainer.innerHTML = `
                <div class="empty-notif" style="padding:40px 20px; text-align:center; color:#64748b;">
                    <i class="fa-regular fa-bell-slash" style="font-size:2rem; margin-bottom:10px; opacity:0.5;"></i>
                    <p>Henüz bildirim yok.</p>
                </div>
            `;
                return;
            }

            listContainer.innerHTML = filtered.map(n => `
            <li class="notif-item ${n.read ? '' : 'unread'}" onclick="NotificationSystem.handleRef('${n.id}', '${n.link || ''}', event)">
                <div class="notif-icon-box" style="background: ${this.getTypeColor(n.type, true)}; color: ${this.getTypeColor(n.type)}">
                    <i class="${this.getTypeIcon(n.type)}"></i>
                </div>
                <div class="notif-content-box">
                    <div class="notif-title">${n.title || 'Bildirim'}</div>
                    <div class="notif-desc">${n.message}</div>
                    ${n.image ? `<img src="${n.image}" class="notif-image" style="width:100%; height:120px; object-fit:cover; border-radius:8px; margin-top:8px; border:1px solid rgba(255,255,255,0.05);">` : ''}
                    <div class="notif-meta">${this.formatTime(n.time)}</div>
                </div>
                ${!n.read ? '<div class="unread-dot"></div>' : ''}
            </li>
        `).join('');
        },

        async handleRef(id, link, event) {
            if (event) event.stopPropagation();

            const n = this.notifications.find(x => x.id === id);
            if (n && !n.read) {
                n.read = true;
                this.saveLocal();
                this.updateBadge();
                this.renderPanel();
            }

            // Navigate if needed
            if (link) {
                this.closePanel();
                if (link.startsWith('http')) {
                    window.open(link, '_blank');
                } else if (link.startsWith('#')) {
                    window.location.hash = link;
                } else {
                    window.location.hash = '#/' + link;
                }
            }
        },

        async markAllRead() {
            this.notifications.forEach(n => n.read = true);
            this.saveLocal();
            this.updateBadge();
            this.renderPanel();

            try {
                await fetch(`${this.apiUrl}?action=notif-mark-read`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: 'all' })
                });
                Toast.success('Tümü okundu işaretlendi.');
            } catch (e) {
                console.error('Bulk mark read failed:', e);
            }
        },

        getTypeColor(type, bg = false) {
            const map = {
                system: '#64748b',
                success: '#22c55e',
                warning: '#f59e0b',
                error: '#ef4444',
                info: '#3b82f6',
                social: '#8b5cf6',
                comment: '#ec4899',
                content: '#14b8a6'
            };
            const color = map[type] || map['system'];
            return bg ? `${color}15` : color;
        },

        getTypeIcon(type) {
            const map = {
                system: 'fa-solid fa-bell',
                success: 'fa-solid fa-check',
                warning: 'fa-solid fa-triangle-exclamation',
                error: 'fa-solid fa-circle-xmark',
                info: 'fa-solid fa-circle-info',
                social: 'fa-solid fa-user-group',
                comment: 'fa-regular fa-comment-dots',
                content: 'fa-solid fa-film'
            };
            return map[type] || map['system'];
        },

        formatTime(ts) {
            const diff = Date.now() - ts;
            if (diff < 60000) return 'Az önce';
            if (diff < 3600000) return Math.floor(diff / 60000) + 'dk önce';
            if (diff < 86400000) return Math.floor(diff / 3600000) + 'sa önce';
            return new Date(ts).toLocaleDateString('tr-TR');
        },

        showToast(options = {}) {
            if (typeof Toast !== 'undefined') {
                const message = options.message || options.title || 'Yeni bildirim';
                const type = options.type || 'info';
                
                if (type === 'success') Toast.success(message);
                else if (type === 'warning') Toast.warning(message);
                else if (type === 'error') Toast.error(message);
                else Toast.info(message);
            } else {
                console.log('🔔 Notification:', options.message);
            }
        }
    };

    window.NotificationSystem = NotificationSystem;

    // Close drawer on overlay click if we had one, for now clicking outside
    document.addEventListener('click', (e) => {
        const box = document.getElementById('notification-panel');
        const trigger = document.getElementById('nav-bell-trigger');
        if (NotificationSystem.isOpen && box && !box.contains(e.target) && !trigger.contains(e.target)) {
            NotificationSystem.closePanel();
        }
    });
} // End undefined check

