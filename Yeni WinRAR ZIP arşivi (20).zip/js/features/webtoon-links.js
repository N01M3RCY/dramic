// ============================================
// WEBTOON EXTERNAL LINKS HANDLER
// Handles webtoons with external platform links
// ============================================

const WebtoonHandler = {
    // Render webtoon detail with external links
    renderWebtoonDetail(series) {
        if (!series || series.type !== 'webtoon') return;

        // Check if has external links
        if (series.externalLinks && series.externalLinks.length > 0) {
            this.renderExternalLinksView(series);
        } else {
            // Fallback to old episode view
            this.renderEpisodesView(series);
        }
    },

    renderExternalLinksView(series) {
        const episodesContainer = document.getElementById('episodes-list');
        if (!episodesContainer) return;

        episodesContainer.innerHTML = `
            <div class="webtoon-external-container">
                <div class="webtoon-info-box">
                    <i class="fa-solid fa-info-circle" style="font-size: 2rem; color: var(--accent-color); margin-bottom: 15px;"></i>
                    <h3>Bu Webtoon Harici Platformlarda Okunabilir</h3>
                    <p style="color: var(--text-secondary); margin-top: 10px;">
                        ${series.title} webtoonunu aşağıdaki platformlardan okuyabilirsiniz.
                        ${series.chapters ? `Toplam ${series.chapters} bölüm mevcut.` : ''}
                    </p>
                </div>

                <div class="external-links-grid">
                    ${series.externalLinks.map(link => `
                        <a href="${link.url}" target="_blank" class="external-link-card">
                            <div class="external-link-icon">
                                <i class="${link.icon}"></i>
                            </div>
                            <div class="external-link-info">
                                <h4>${link.platform}</h4>
                                <span>Okumak için tıklayın</span>
                            </div>
                            <div class="external-link-arrow">
                                <i class="fa-solid fa-arrow-right"></i>
                            </div>
                        </a>
                    `).join('')}
                </div>

                ${series.note ? `
                    <div class="webtoon-note">
                        <i class="fa-solid fa-lightbulb"></i>
                        <span>${series.note}</span>
                    </div>
                ` : ''}
            </div>
        `;
    },

    renderEpisodesView(series) {
        // Old method for webtoons with stored episodes
        const episodesContainer = document.getElementById('episodes-list');
        if (!episodesContainer || !series.episodes) return;

        episodesContainer.innerHTML = series.episodes.map(ep => `
            <div class="episode-card" onclick="App.playWebtoonEpisode('${series.id}', ${ep.number})">
                <div class="episode-number">Bölüm ${ep.number}</div>
                <div class="episode-title">${ep.title}</div>
            </div>
        `).join('');
    },

    // Add external link to existing webtoon
    addExternalLink(seriesId, platform, url, icon = 'fa-solid fa-link') {
        const series = db.getSeries(seriesId);
        if (!series || series.type !== 'webtoon') {
            Toast.error("Sadece webtoonlara harici link eklenebilir!");
            return;
        }

        if (!series.externalLinks) {
            series.externalLinks = [];
        }

        const link = {
            platform: platform,
            url: url,
            icon: icon
        };

        series.externalLinks.push(link);
        db.updateSeries(seriesId, { externalLinks: series.externalLinks });
        Toast.success(`${platform} linki eklendi!`);
    },

    // Show modal to add external link (for admins)
    showAddLinkModal(seriesId) {
        if (!State.currentUser?.badges?.includes('Yönetici')) {
            Toast.error("Sadece yöneticiler link ekleyebilir!");
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 500px;">
                <div class="modal-header">
                    <h2>Harici Link Ekle</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div style="padding: 25px;">
                    <div class="form-group">
                        <label>Platform Adı</label>
                        <input type="text" id="link-platform" class="form-input" placeholder="Webtoon, Asura Scans, Moly...">
                    </div>

                    <div class="form-group">
                        <label>URL</label>
                        <input type="url" id="link-url" class="form-input" placeholder="https://...">
                    </div>

                    <div class="form-group">
                        <label>İkon (Font Awesome)</label>
                        <input type="text" id="link-icon" class="form-input" placeholder="fa-solid fa-book-open" value="fa-solid fa-link">
                    </div>

                    <button class="btn btn-primary" onclick="WebtoonHandler.submitAddLink('${seriesId}'); this.closest('.modal').remove();" style="width: 100%;">
                        <i class="fa-solid fa-plus"></i> Link Ekle
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    submitAddLink(seriesId) {
        const platform = document.getElementById('link-platform').value;
        const url = document.getElementById('link-url').value;
        const icon = document.getElementById('link-icon').value;

        if (!platform || !url) {
            Toast.warning("Platform adı ve URL gereklidir!");
            return;
        }

        this.addExternalLink(seriesId, platform, url, icon);

        // Refresh detail view
        if (State.currentSeries?.id === seriesId) {
            App.renderDetail(seriesId);
        }
    }
};

console.log('✅ Webtoon External Links Handler Loaded!');
