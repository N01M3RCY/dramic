// =============================================
// DRAMICBOX - SOCIAL FEED (Social Hub)
// Instagram-like social hub with spoiler system,
// polls, hashtags, mentions, verified badges,
// friend/messaging integration, and content sharing
// =============================================
const db = window.db;

const SocialFeed = {
    posts: [],
    shareData: null,     // pre-filled data from series/player pages
    filterTag: null,     // current hashtag filter
    currentTab: 'feed',  // active tab
    postsPerPage: 15,    // Pagination: posts per load
    currentPage: 1,      // Pagination: current page
    searchQuery: '',     // Search query filter

    // ==================== MODERATION CONFIG ====================
    moderation: {
        // Default banned words (can be extended from admin)
        bannedWords: [
            'küfür1', 'küfür2', 'amk', 'aq', 'orospu', 'piç', 'siktir', 'yarrak', 'göt',
            'fuck', 'shit', 'bitch', 'dick', 'asshole', 'bastard'
        ],
        // Blocked URL patterns
        blockedLinkPatterns: [
            /https?:\/\/[^\s]+/gi, // Block ALL external links by default
        ],
        // Allowed domains (whitelist) - loaded dynamically
        allowedDomains: ['dramicbox.com', 'youtube.com', 'youtu.be'],
        // Blocked domains (blacklist) - loaded dynamically
        blockedDomains: [],
        // Maximum post length
        maxPostLength: 2000,
        // Maximum comment length
        maxCommentLength: 500,
    },

    // Load moderation settings from database
    async initModeration() {
        try {
            if (window.db && db.loadData) {
                const settings = State.data?.settings || [];
                const socialMod = Array.isArray(settings) 
                    ? settings.find(s => s.id === 'social_moderation')
                    : settings.social_moderation;
                
                if (socialMod) {
                    if (socialMod.allowedDomains && socialMod.allowedDomains.length > 0) {
                        this.moderation.allowedDomains = socialMod.allowedDomains;
                    }
                    if (socialMod.blockedDomains && socialMod.blockedDomains.length > 0) {
                        this.moderation.blockedDomains = socialMod.blockedDomains;
                    }
                    console.log('🔗 Social moderation settings loaded:', {
                        allowed: this.moderation.allowedDomains.length,
                        blocked: this.moderation.blockedDomains.length
                    });
                }
            }
        } catch(e) {
            console.warn('Could not load social moderation settings:', e);
        }
    },

    // Check if user is a moderator
    isModerator(user) {
        if (!user) return false;
        return user.role === 'admin' ||
            user.role === 'moderator' ||
            user.role === 'translator' ||
            user.badges?.includes('Admin') ||
            user.badges?.includes('Moderatör') ||
            user.badges?.includes('Çevirmen') ||
            user.badges?.includes('Sosyal Moderatör');
    },

    // Auto-moderate content
    moderateContent(text) {
        if (!text) return { clean: true, text };
        let result = { clean: true, text, warnings: [] };

        // Load custom banned words from State if available
        const customBanned = State.data.socialSettings?.bannedWords || [];
        const allBanned = [...this.moderation.bannedWords, ...customBanned];

        // Check banned words
        const lowerText = text.toLowerCase();
        for (const word of allBanned) {
            if (lowerText.includes(word.toLowerCase())) {
                result.clean = false;
                result.warnings.push(`Yasaklı kelime tespit edildi: "${word}"`);
            }
        }

        // Check links
        const urlRegex = /https?:\/\/([^\s\/]+)/gi;
        let match;
        while ((match = urlRegex.exec(text)) !== null) {
            const domain = match[1].toLowerCase();
            const customAllowed = State.data.socialSettings?.allowedDomains || [];
            const allAllowed = [...this.moderation.allowedDomains, ...customAllowed];
            
            // Check blacklist first (takes priority)
            const blockedDomains = this.moderation.blockedDomains || [];
            const customBlocked = State.data.socialSettings?.blockedDomains || [];
            const allBlocked = [...blockedDomains, ...customBlocked];
            const isBlocked = allBlocked.some(d => domain.includes(d));
            
            if (isBlocked) {
                result.clean = false;
                result.warnings.push(`Yasaklı alan adı: ${match[0]}`);
            } else {
                const isAllowed = allAllowed.some(d => domain.includes(d));
                if (!isAllowed) {
                    result.clean = false;
                    result.warnings.push(`İzin verilmeyen link: ${match[0]}`);
                }
            }
        }

        // Check length
        if (text.length > this.moderation.maxPostLength) {
            result.clean = false;
            result.warnings.push(`Metin çok uzun (max ${this.moderation.maxPostLength} karakter)`);
        }

        return result;
    },

    checkSocialBan() {
        const user = State.currentUser;
        if (!user || user.role === 'guest') return false;
        if (user.socialBanUntil && user.socialBanUntil > Date.now()) {
            const hours = Math.ceil((user.socialBanUntil - Date.now()) / (1000 * 60 * 60));
            Toast.error(`Topluluk kurallarını ihlal ettiğiniz için kısıtlandınız. Lütfen ${hours} saat bekleyin.`);
            return true;
        }
        return false;
    },

    handleViolation(warnings) {
        const user = State.currentUser;
        if (!user || user.role === 'guest') return;
        
        user.socialViolations = (user.socialViolations || 0) + 1;
        let banHours = 0;
        
        if (user.socialViolations === 5) banHours = 6;
        else if (user.socialViolations === 6) banHours = 12;
        else if (user.socialViolations === 7) banHours = 24;
        else if (user.socialViolations >= 8) banHours = 48;
        
        if (banHours > 0) {
            user.socialBanUntil = Date.now() + (banHours * 60 * 60 * 1000);
            Toast.error(`Uyarı sınırını aştınız! Paylaşım yetkiniz ${banHours} saat süreyle kısıtlandı.`);
        } else {
            Toast.warning(`İhlal uyarısı (${user.socialViolations}/5): ${warnings[0]}`);
        }
        
        // Save user state
        localStorage.setItem('dramicbox_user', JSON.stringify(user));
        if (window.db && db.updateUser) db.updateUser(user.id, { socialViolations: user.socialViolations, socialBanUntil: user.socialBanUntil });
        else if (window.db) db.save('users');
    },

    injectStyles() {
        if (document.getElementById('social-feed-styles-v2')) return;
        const style = document.createElement('style');
        style.id = 'social-feed-styles-v2';
        style.textContent = `
            /* Spoiler wraps */
            .spoiler-wrapper {
                position: relative;
                cursor: pointer;
                border-radius: 14px;
                overflow: hidden;
                margin-top: 10px;
            }
            .spoiler-wrapper .spoiler-overlay {
                position: absolute;
                inset: 0;
                background: rgba(10, 10, 15, 0.94);
                backdrop-filter: blur(25px);
                -webkit-backdrop-filter: blur(25px);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                gap: 12px;
                color: #fb923c;
                font-weight: 800;
                font-size: 0.9rem;
                z-index: 10;
                transition: opacity 0.3s ease;
                border: 1px dashed rgba(251, 146, 60, 0.3);
                border-radius: 14px;
                padding: 24px;
                text-align: center;
                font-family: 'Outfit', sans-serif;
            }
            .spoiler-wrapper .spoiler-overlay i {
                font-size: 1.8rem;
                filter: drop-shadow(0 0 10px rgba(251, 146, 60, 0.4));
            }
            .spoiler-wrapper .spoiler-content {
                filter: blur(25px);
                pointer-events: none;
                transition: filter 0.3s ease;
            }
            .spoiler-wrapper.revealed .spoiler-overlay {
                opacity: 0;
                pointer-events: none;
            }
            .spoiler-wrapper.revealed .spoiler-content {
                filter: none;
                pointer-events: auto;
            }

            /* Custom aesthetics for feed */
            .post-card-premium {
                background: rgba(255, 255, 255, 0.02) !important;
                backdrop-filter: blur(24px) !important;
                -webkit-backdrop-filter: blur(24px) !important;
                border: 1px solid rgba(167, 139, 250, 0.12) !important;
                border-radius: 24px !important;
                padding: 24px !important;
                margin-bottom: 25px !important;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), 0 0 20px rgba(167, 139, 250, 0.05) !important;
                transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1) !important;
                font-family: 'Inter', sans-serif !important;
            }
            .post-card-premium:hover {
                transform: translateY(-4px) !important;
                border-color: rgba(167, 139, 250, 0.3) !important;
                box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4), 0 0 30px rgba(167, 139, 250, 0.15) !important;
            }
            .post-username {
                font-family: 'Outfit', sans-serif !important;
                font-weight: 800 !important;
                letter-spacing: -0.3px !important;
                color: #fff !important;
            }
            .social-hub-tab {
                font-family: 'Outfit', sans-serif !important;
                font-weight: 700 !important;
                border-radius: 14px !important;
                border: 1px solid transparent !important;
                transition: all 0.3s !important;
            }
            .social-hub-tab.active {
                background: rgba(167, 139, 250, 0.12) !important;
                color: #a78bfa !important;
                border-color: rgba(167, 139, 250, 0.25) !important;
                box-shadow: 0 0 20px rgba(167, 139, 250, 0.08) !important;
            }
            .social-search-box input {
                font-family: 'Outfit', sans-serif !important;
                font-weight: 500 !important;
            }
            
            /* Schedule Widget */
            .schedule-status-badge { text-decoration: none; }
            .schedule-status-badge.status-active { background: rgba(16, 185, 129, 0.12) !important; color: #34d399 !important; border: 1px solid rgba(16, 185, 129, 0.2) !important; }
            .schedule-status-badge.status-preparing { background: rgba(234, 179, 8, 0.12) !important; color: #fbbf24 !important; border: 1px solid rgba(234, 179, 8, 0.2) !important; }
            .schedule-status-badge.status-upcoming { background: rgba(255, 255, 255, 0.05) !important; color: #94a3b8 !important; border: 1px solid rgba(255, 255, 255, 0.08) !important; }
        `;
        document.head.appendChild(style);
    },

    handleSearch(query) {
        this.searchQuery = query.trim().toLowerCase();
        this.currentPage = 1;
        const content = document.getElementById('social-tab-content');
        if (content) {
            if (this.currentTab === 'feed') {
                content.innerHTML = this.renderFeedTab();
            } else if (this.currentTab === 'reviews') {
                content.innerHTML = this.renderReviewsTab();
            } else if (this.currentTab === 'blog') {
                content.innerHTML = this.renderBlogTab();
            }
        }
    },

    // ==================== INIT ====================
    async init(options = {}, target = null) {
        try {
            this.injectStyles();
            await this.initModeration();
            let tab = 'feed';
            let targetUser = null;

            if (typeof options === 'object' && options !== null && !Array.isArray(options)) {
                tab = options.tab || 'feed';
                targetUser = options.targetUser || options.target || null;
            } else {
                tab = options || 'feed';
                targetUser = target;
            }

            console.log('📱 SocialHub initializing...', { tab, targetUser });
            this.currentTab = tab;
            this.targetUser = targetUser;

            // Ensure users and posts are loaded
            if (window.db) {
                await Promise.all([
                    db.ensureCollection('users'),
                    db.ensureCollection('socialPosts'),
                    db.ensureCollection('series')
                ]);
            }

            if (!State.data) State.data = {};
            if (!State.data.socialPosts) State.data.socialPosts = [];
            if (!State.data.users) State.data.users = [];

            // Cleanup: Remove legacy "Misafir" account from State.data.users if it exists as a real entry
            const guestIdx = State.data.users.findIndex(u => u.username === 'Misafir' && (u.id === 'guest' || u.role === 'guest'));
            if (guestIdx > -1) {
                console.log('🧹 Cleanup: Removing legacy guest account entry from user list');
                State.data.users.splice(guestIdx, 1);
                if (window.db) db.save();
            }
            
            this.posts = State.data.socialPosts;

            // Render feed
            this.render();

            // Listen for Cloud Sync events to refresh feed live
            if (!this._syncBound) {
                window.addEventListener('dramicbox_sync_complete', () => {
                    if (this.currentTab === 'feed' || this.currentTab === 'trending') {
                        console.log('🔄 Cloud Pulse detected new social data, refreshing feed...');
                        this.render();
                    }
                });

                window.addEventListener('dramicbox_live_update', () => {
                    console.log('📡 Live stream update received via BroadcastChannel');
                    this.render();
                });
                
                this._syncBound = true;
            }

            // --- GARBAGE COLLECTION ---
            // Run global storage scan occasionally (20% chance on init) to clean orphans
            if (Math.random() < 0.2) {
                this.runGlobalGC();
            }
        } catch (err) {
            console.error('❌ SocialHub initialization failed:', err);
            const container = document.getElementById('social-view');
            if (container) {
                container.innerHTML = `
                    <div style="padding: 100px 20px; text-align: center; color: #94a3b8;">
                        <i class="fa-solid fa-triangle-exclamation" style="font-size: 3rem; color: #ef4444; margin-bottom: 20px;"></i>
                        <h2>Sosyal Hub Yüklenemedi</h2>
                        <p>Bir hata oluştu: ${err.message}</p>
                        <button onclick="SocialFeed.init()" class="btn btn-primary" style="margin-top: 20px;">Tekrar Dene</button>
                    </div>
                `;
            }
        }
    },

    runGlobalGC() {
        console.log('🧹 SocialHub: Running global garbage collection...');
        try {
            if (State.data && Array.isArray(State.data.socialPosts)) {
                const beforeCount = State.data.socialPosts.length;
                State.data.socialPosts = State.data.socialPosts.filter(post => post && post.id && post.userId);
                const afterCount = State.data.socialPosts.length;
                if (beforeCount !== afterCount) {
                    console.log(`🧹 SocialHub GC: Cleaned ${beforeCount - afterCount} orphan posts.`);
                    if (window.db) db.save();
                }
            }
        } catch (e) {
            console.error('🧹 SocialHub GC error:', e);
        }
    },

    // ==================== CLUB GATE ====================
    renderClubJoinGate(user) {
        if (!user) {
            return `
                <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:60vh; text-align:center; padding:20px;">
                    <i class="fa-solid fa-lock" style="font-size:4rem; color:var(--m-accent-violet); margin-bottom:20px;"></i>
                    <h2 style="font-size:2rem; font-weight:900; color:#fff; margin-bottom:10px;">Sosyal Klüp Özel Alanı</h2>
                    <p style="color:var(--text-secondary); max-width:500px; margin-bottom:30px; font-size:1.1rem;">
                        Bu alandaki paylaşımları ve içerikleri görebilmek için Dramicbox Klübüne üye olmanız gerekmektedir. Lütfen önce giriş yapın.
                    </p>
                    <button onclick="App.router('login')" class="btn btn-primary" style="padding:15px 30px; font-size:1.1rem; border-radius:12px;">Giriş Yap</button>
                </div>
            `;
        }

        if (user.clubStatus === 'pending') {
            return `
                <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:60vh; text-align:center; padding:20px;">
                    <i class="fa-solid fa-hourglass-half" style="font-size:4rem; color:#f59e0b; margin-bottom:20px; animation: pulse 2s infinite;"></i>
                    <h2 style="font-size:2rem; font-weight:900; color:#fff; margin-bottom:10px;">Başvurunuz Değerlendiriliyor</h2>
                    <p style="color:var(--text-secondary); max-width:500px; margin-bottom:30px; font-size:1.1rem;">
                        Klübe katılım isteğiniz yöneticilere ulaştı. Onaylandığı zaman Sosyal Hub'a erişebileceksiniz.
                    </p>
                    <button onclick="SocialFeed.render()" class="btn btn-outline" style="padding:12px 24px; border-radius:12px;">Durumu Yenile</button>
                </div>
            `;
        }

        return `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:60vh; text-align:center; padding:20px;">
                <i class="fa-solid fa-users" style="font-size:4rem; color:var(--m-accent-cyan); margin-bottom:20px;"></i>
                <h2 style="font-size:2rem; font-weight:900; color:#fff; margin-bottom:10px;">Dramicbox Klübüne Katıl</h2>
                <p style="color:var(--text-secondary); max-width:500px; margin-bottom:30px; font-size:1.1rem;">
                    Sosyal Hub sadece klüp üyelerine özeldir. Başvuru yaparak topluluğa katılabilir, yorum yapabilir ve gönderileri görebilirsiniz.
                </p>
                <button onclick="SocialFeed.applyToClub()" class="btn btn-primary" style="padding:15px 30px; font-size:1.1rem; border-radius:12px; background:linear-gradient(135deg, var(--m-accent-cyan), var(--m-accent-violet)); border:none;">
                    Klübe Başvur
                </button>
            </div>
        `;
    },

    async applyToClub() {
        const user = State.currentUser;
        if (!user) return;
        user.clubStatus = 'pending';
        // Wait, to safely save this, we use db.updateUser or we just save to users array.
        // Let's use db.updateUser if it exists, else modify State.data.users
        if (window.db && db.updateUser) {
            await db.updateUser(user.id, { clubStatus: 'pending' });
        } else {
            State.currentUser.clubStatus = 'pending';
            localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            if (State.data.users) {
                const idx = State.data.users.findIndex(u => String(u.id) === String(user.id));
                if (idx > -1) State.data.users[idx].clubStatus = 'pending';
            }
            if (window.db) db.save('users');
        }
        Toast.success('Başvurunuz alındı!');
        this.render();
    },

    // ==================== REAL-TIME SYNC ====================
    streamSource: null,
    initStream() {
        console.log("📡 Social Hub running in Local-Only mode.");
        // No server-side stream needed for local-first architecture.
    },

    handleNewPost(post) {
        if (!State.data.socialPosts) State.data.socialPosts = [];
        
        // Prevent duplicates
        if (State.data.socialPosts.find(p => String(p.id) === String(post.id))) return;
        
        State.data.socialPosts.unshift(post);
        this.posts = State.data.socialPosts;
        
        if (this.currentTab === 'feed') {
            const container = document.getElementById('social-posts-container');
            if (container) {
                const temp = document.createElement('div');
                temp.innerHTML = this.renderPostCard(post);
                const postEl = temp.firstElementChild;
                if (postEl) {
                    postEl.style.opacity = '0';
                    postEl.style.transform = 'translateY(-20px)';
                    postEl.style.transition = 'all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)';
                    
                    container.prepend(postEl);
                    setTimeout(() => {
                        postEl.style.opacity = '1';
                        postEl.style.transform = 'translateY(0)';
                    }, 10);
                }
            }
        } else {
            // Update badge for new posts
            let badge = document.querySelector('.social-hub-tab[data-tab="feed"] .tab-badge');
            if (!badge) {
                const tab = document.querySelector('.social-hub-tab[data-tab="feed"]');
                if (tab) {
                    badge = document.createElement('span');
                    badge.className = 'tab-badge';
                    tab.appendChild(badge);
                }
            }
            if (badge) {
                const currentCount = parseInt(badge.textContent || 0);
                badge.textContent = currentCount + 1;
                badge.style.display = 'block';
            }
        }
    },

    handlePostUpdate(updatedPost) {
        if (!State.data.socialPosts) return;
        const idx = State.data.socialPosts.findIndex(p => String(p.id) === String(updatedPost.id));
        if (idx > -1) {
            State.data.socialPosts[idx] = updatedPost;
            this.posts = State.data.socialPosts;
            // Re-render only if currently viewing this post or just refresh feed
        }
    },


    // ==================== MAIN RENDER ====================
    loadMorePosts() {
        this.currentPage++;
        this.render();
        // Scroll a bit down to show new content
        setTimeout(() => {
            const btn = document.querySelector('.post-submit-btn[onclick*="loadMorePosts"]');
            if (btn) btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 100);
    },

    render() {
        const container = document.getElementById('social-view');
        if (!container) return;
        const user = State.currentUser;

        // --- CLUB JOIN GATE BYPASSED ---


        container.innerHTML = `
            <div class="container" style="margin-top: 30px;">
                <div class="social-hub-header" style="margin-bottom: 40px; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h1 style="font-size: 3.5rem; background: linear-gradient(135deg, #fff 0%, #a78bfa 50%, #f472b6 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; letter-spacing: -2px; font-weight: 900; margin-bottom: 10px; margin-top: 0;">
                            <i class="fa-solid fa-earth-americas" style="font-size: 2.8rem; background: linear-gradient(135deg, #a78bfa, #f472b6); -webkit-background-clip: text; -webkit-text-fill-color: initial; color: transparent;"></i> Sosyal Hub
                        </h1>
                        <p style="color: var(--text-secondary); font-size: 1.1rem; font-weight: 500; margin: 0;">Topluluk ile etkileşime geç, en yeni dizi yorumlarını ve blogları keşfet.</p>
                    </div>
                    <button class="social-hub-tab" onclick="SocialFeed.init()" title="Akışı Yenile" style="background: rgba(124, 58, 237, 0.1); border-radius: 50%; width: 56px; height: 56px; padding: 0; display: flex; align-items: center; justify-content: center; border: 1px solid rgba(124, 58, 237, 0.3); color: #a78bfa; transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); cursor: pointer;" onmouseover="this.style.transform='rotate(180deg) scale(1.1)'; this.style.background='rgba(124, 58, 237, 0.2)';" onmouseout="this.style.transform='rotate(0deg) scale(1)'; this.style.background='rgba(124, 58, 237, 0.1)';">
                        <i class="fa-solid fa-arrows-rotate" style="font-size: 1.4rem;"></i>
                    </button>
                </div>

                <div class="social-hub-container" style="display: grid; grid-template-columns: 260px 1fr 320px; gap: 30px; align-items: start;">
                    <!-- Left Sidebar (Menu) -->
                    <div class="social-sidebar-left" style="position: sticky; top: 100px; display: flex; flex-direction: column; gap: 20px;">
                        <div class="glass-card" style="padding: 20px; border-radius: 20px; border: 1px solid var(--border-premium);">
                            <h4 style="margin-bottom: 20px; font-size: 0.8rem; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 1.5px; font-weight: 800;">KEŞFET</h4>
                            
                            <!-- Search Bar -->
                            <div class="social-search-box" style="position: relative; margin-bottom: 20px;">
                                <i class="fa-solid fa-search" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #64748b; font-size: 0.85rem;"></i>
                                <input type="text" id="social-search-input" placeholder="Sosyal medyada ara..." oninput="SocialFeed.handleSearch(this.value)" 
                                    value="${this.searchQuery || ''}"
                                    style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: white; padding: 10px 15px 10px 35px; border-radius: 12px; outline: none; width: 100%; font-size: 0.85rem; font-family: 'Outfit', sans-serif; transition: all 0.3s;"
                                    onfocus="this.style.borderColor='rgba(139,92,246,0.5)'; this.style.boxShadow='0 0 10px rgba(139,92,246,0.2)';"
                                    onblur="this.style.borderColor='rgba(255,255,255,0.1)'; this.style.boxShadow='none';">
                            </div>
                            <div class="social-hub-tabs" style="display: flex; flex-direction: column; gap: 8px;">
                                <button class="social-hub-tab ${this.currentTab === 'feed' ? 'active' : ''}" data-tab="feed" onclick="SocialFeed.switchTab('feed', this)" style="width: 100%; justify-content: flex-start; padding: 12px 18px;">
                                    <i class="fa-solid fa-rss" style="width: 25px; font-size: 1.1rem;"></i> Akış
                                </button>
                                <button class="social-hub-tab ${this.currentTab === 'reviews' ? 'active' : ''}" data-tab="reviews" onclick="SocialFeed.switchTab('reviews', this)" style="width: 100%; justify-content: flex-start; padding: 12px 18px;">
                                    <i class="fa-solid fa-star-half-stroke" style="width: 25px; font-size: 1.1rem;"></i> İncelemeler
                                </button>
                                <button class="social-hub-tab ${this.currentTab === 'blog' ? 'active' : ''}" data-tab="blog" onclick="SocialFeed.switchTab('blog', this)" style="width: 100%; justify-content: flex-start; padding: 12px 18px;">
                                    <i class="fa-solid fa-pen-nib" style="width: 25px; font-size: 1.1rem;"></i> Blog
                                </button>
                                <button class="social-hub-tab ${this.currentTab === 'friends' ? 'active' : ''}" data-tab="friends" onclick="SocialFeed.switchTab('friends', this)" style="width: 100%; justify-content: flex-start; padding: 12px 18px;">
                                    <i class="fa-solid fa-user-group" style="width: 25px; font-size: 1.1rem;"></i> Arkadaşlar
                                </button>
                                <button class="social-hub-tab ${this.currentTab === 'fan-center' ? 'active' : ''}" data-tab="fan-center" onclick="SocialFeed.switchTab('fan-center', this)" style="width: 100%; justify-content: flex-start; padding: 12px 18px;">
                                    <i class="fa-solid fa-masks-theater" style="width: 25px; font-size: 1.1rem; color:#f472b6;"></i> Oyuncu Merkezi
                                </button>
                                <button class="social-hub-tab ${this.currentTab === 'live' ? 'active' : ''}" data-tab="live" onclick="SocialFeed.switchTab('live', this)" style="width: 100%; justify-content: flex-start; padding: 12px 18px;">
                                    <i class="fa-solid fa-tower-broadcast" style="width: 25px; font-size: 1.1rem; color: #ef4444;"></i> Canlı Yayınlar
                                </button>
                                <div style="height: 1px; background: var(--border-premium); margin: 10px 0;"></div>
                                <button class="social-hub-tab ${this.currentTab === 'profile' ? 'active' : ''}" data-tab="profile" onclick="SocialFeed.switchTab('profile', this)" style="width: 100%; justify-content: flex-start; padding: 12px 18px;">
                                    <i class="fa-solid fa-user-ninja" style="width: 25px; font-size: 1.1rem;"></i> Profilim
                                </button>
                            </div>
                        </div>

                        ${this.isModerator(user) ? `
                            <div class="glass-card" style="padding: 20px; border-radius: 20px; border: 1px solid rgba(239, 68, 68, 0.1);">
                                <h4 style="margin-bottom: 15px; font-size: 0.8rem; color: var(--premium-pink); font-weight: 800; text-transform: uppercase;">MODERASYON</h4>
                                <button class="social-hub-tab ${this.currentTab === 'moderation' ? 'active' : ''}" onclick="SocialFeed.switchTab('moderation', this)" style="width: 100%; justify-content: flex-start; color: var(--premium-pink); padding: 12px 18px;">
                                    <i class="fa-solid fa-shield-halved" style="width: 25px; font-size: 1.1rem;"></i> Yönetim
                                </button>
                            </div>
                        ` : ''}

                        <!-- Live Center Mini Button -->
                        <div class="glass-card" style="padding: 20px; border-radius: 20px; background: linear-gradient(135deg, rgba(239, 68, 68, 0.05) 0%, rgba(124, 58, 237, 0.05) 100%); border: 1px solid rgba(239, 68, 68, 0.1);">
                            <h4 style="margin-bottom: 12px; font-size: 0.75rem; color: #ef4444; font-weight: 800; letter-spacing: 1px;">LIVE CENTER</h4>
                            <p style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 15px;">Çevirmenlerin canlı yayınlarını izle veya yayına katıl.</p>
                            ${(user?.role === 'translator' || user?.role === 'admin' || user?.badges?.includes('Çevirmen')) ? `
                                <button onclick="SocialFeed.openStreamSetup()" class="btn btn-sm" style="width: 100%; background: #ef4444; color: #fff; border-radius: 12px; font-weight: 800;">
                                    <i class="fa-solid fa-tower-broadcast"></i> Yayın Başlat
                                </button>
                            ` : `
                                <button onclick="SocialFeed.viewLiveCenter()" class="btn btn-sm btn-outline" style="width: 100%; border-radius: 12px;">
                                    <i class="fa-solid fa-eye"></i> Yayınları Gör
                                </button>
                            `}
                        </div>
                    </div>

                    <!-- Main Feed Column -->
                    <div class="social-feed-main" style="min-height: 800px; display: flex; flex-direction: column; gap: 24px;">
                        <div id="social-tab-content">
                            <!-- Tab content will be rendered here -->
                        </div>
                    </div>

                    <!-- Right Sidebar (Gündem) -->
                    <div class="social-sidebar-right" style="position: sticky; top: 100px; display: flex; flex-direction: column; gap: 20px;">
                        <div class="glass-card" style="padding: 25px; border-radius: 24px; border: 1px solid var(--border-premium);">
                            <div id="live-streams-area" style="margin-bottom: 30px;">
                                ${this.renderLiveStreams()}
                            </div>
                            <h4 style="margin-bottom: 25px; color: #fff; font-weight: 900; font-size: 1.2rem;">Gündemdekiler</h4>
                            <div class="trending-list" style="display: grid; gap: 20px;" id="social-trending-list">
                                ${this.renderTrendingList()}
                            </div>

                            <div style="margin-top: 40px; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 30px;">
                                <h4 style="margin-bottom: 20px; color: #a78bfa; font-weight: 900; font-size: 1.1rem; display: flex; align-items: center; gap: 10px;">
                                    <i class="fa-solid fa-star"></i> Popüler Oyuncular
                                </h4>
                                <div id="social-popular-actors" class="popular-actors-social-grid">
                                    ${this.renderPopularActors()}
                                </div>
                            </div>

                            <div style="margin-top: 40px; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 30px;">
                                <h4 style="margin-bottom: 20px; color: gold; font-weight: 900; font-size: 1.1rem; display: flex; align-items: center; gap: 10px;">
                                    <i class="fa-solid fa-crown"></i> Hall of Fame
                                </h4>
                                <div id="hall-of-fame-list">
                                    ${this.renderHallOfFame()}
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        `;

        // Render initial tab content
        this.switchTab(this.currentTab, null);

        // If shareData from series/player, auto-open create post
        if (this.shareData) {
            setTimeout(() => this.openCreatePostModal(), 300);
        }

        // --- ASYNC MEDIA RESOLUTION ---
        this.resolveMedia();
    },

    /**
     * Finds all elements with data-media-idb and resolves them from IndexedDB
     */
    async resolveMedia(container = document) {
        const elements = container.querySelectorAll('[data-media-idb]');
        if (elements.length === 0) return;

        console.log(`🖼️ Resolving ${elements.length} persistent media items...`);
        
        for (const el of elements) {
            const id = el.getAttribute('data-media-idb');
            if (!id) continue;

            try {
                const url = await MediaDB.getMediaUrl(id);
                if (url) {
                    el.src = url;
                    // Remove attribute to avoid double resolution
                    el.removeAttribute('data-media-idb');
                } else {
                    console.warn(`⚠️ Media not found in IDB: ${id}`);
                    el.style.display = 'none'; // Hide if failed
                }
            } catch (err) {
                console.error(`❌ Failed to resolve media ${id}:`, err);
            }
        }
    },

    // ==================== TABS ====================
    switchTab(tab, btnEl) {
        this.currentTab = tab;
        this.currentPage = 1; // Reset pagination
        // Update active tab
        document.querySelectorAll('.social-hub-tab').forEach(b => b.classList.remove('active'));
        if (btnEl) btnEl.classList.add('active');

        const content = document.getElementById('social-tab-content');
        if (!content) return;

        if (tab === 'feed') {
            content.innerHTML = this.renderFeedTab();
        } else if (tab === 'friends') {
            if (!State.currentUser || State.currentUser.role === 'guest') {
                content.innerHTML = this.renderFriendsTab(); // Friends tab already handles guest UI
            } else {
                content.innerHTML = window.FriendCenter ? FriendCenter.render() : this.renderFriendsTab();
            }
        } else if (tab === 'messages') {
            if (!State.currentUser || State.currentUser.role === 'guest') {
                content.innerHTML = this.renderMessagesTab(); // Messages tab already handles guest UI
            } else {
                content.innerHTML = this.renderMessagesTab();
            }
        } else if (tab === 'reviews') {
            content.innerHTML = this.renderReviewsTab();
        } else if (tab === 'badges') {
            content.innerHTML = this.renderBadgesTab();
        } else if (tab === 'profile') {
            content.innerHTML = this.renderProfileTab();
        } else if (tab === 'blog') {
            content.innerHTML = this.renderBlogTab();
        } else if (tab === 'announcements') {
            content.innerHTML = this.renderAnnouncementsTab();
        } else if (tab === 'live') {
            content.innerHTML = this.renderLiveTab();
        } else if (tab === 'fan-center') {
            content.innerHTML = this.renderFanCenterTab();
        } else if (tab === 'moderation') {
            content.innerHTML = this.renderModerationTab();
        }

    },

    renderSidebar() {
        const container = document.getElementById('social-sidebar-container');
        if (container) {
            container.innerHTML = `
                ${this.renderActiveFriendsSidebar()}
                ${this.renderHallOfFame()}
                ${this.renderTrendingSidebar()}
                ${this.renderQuickActions()}
            `;
        }
    },


    sortMode: 'latest', // 'latest' or 'popular'

    // ==================== FEED TAB ====================
    renderBlogTab() {
        const blogs = this.posts.filter(p => p.isBlog && p.status === 'active').sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        const categories = ['Haberler', 'Teknoloji', 'Spor', 'Eğlence'];

        let html = `
            <div style="margin-bottom: 30px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2 style="color:#fff; font-size:1.8rem; font-weight:900; margin:0;"><i class="fa-solid fa-pen-nib" style="color:#a78bfa; margin-right:12px;"></i> Blog & Haberler</h2>
                    ${State.currentUser?.role === 'blogger' || State.currentUser?.role === 'admin' ? `
                        <button onclick="SocialFeed.openBlogEditor()" class="btn btn-primary" style="background:linear-gradient(135deg,#7c3aed,#6d28d9); border:none; padding:10px 20px; border-radius:12px; font-weight:700;">
                            <i class="fa-solid fa-plus"></i> Yeni Yazı
                        </button>
                    ` : ''}
                </div>
                
                <div style="display:flex; gap:10px; overflow-x:auto; padding-bottom:10px;">
                    <button onclick="SocialFeed.filterBlogByCategory(null)" class="social-hub-tab ${!this._blogCategory ? 'active' : ''}" style="white-space:nowrap; font-size:0.8rem;">Tümü</button>
                    ${categories.map(cat => `
                        <button onclick="SocialFeed.filterBlogByCategory('${cat}')" class="social-hub-tab ${this._blogCategory === cat ? 'active' : ''}" style="white-space:nowrap; font-size:0.8rem;">${cat}</button>
                    `).join('')}
                    ${State.currentUser?.role === 'admin' ? `
                        <button onclick="SocialFeed.filterBlogByCategory('pending')" class="social-hub-tab ${this._blogCategory === 'pending' ? 'active' : ''}" style="white-space:nowrap; font-size:0.8rem; border-color:rgba(245,158,11,0.3); color:#f59e0b;"><i class="fa-solid fa-clock"></i> Onay Bekleyenler</button>
                    ` : ''}
                </div>
            </div>
        `;

        let filtered = this._blogCategory === 'pending' 
             ? this.posts.filter(p => p.isBlog && p.status === 'pending')
             : (this._blogCategory ? blogs.filter(b => b.category === this._blogCategory) : blogs);

        if (this.searchQuery) {
            filtered = filtered.filter(b => {
                const title = (b.title || '').toLowerCase();
                const text = (b.text || '').toLowerCase();
                const user = State.data.users?.find(u => u.id === b.userId);
                const username = (user?.username || '').toLowerCase();
                return title.includes(this.searchQuery) || text.includes(this.searchQuery) || username.includes(this.searchQuery);
            });
        }

        if (filtered.length === 0) {
            html += `<div class="social-empty-state"><i class="fa-solid fa-pen-fancy"></i><h3>Henüz bu kategoride yazı yok</h3><p>Yeni bir blog yazısı paylaşıldığında burada görünecek.</p></div>`;
        } else {
            html += `<div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap:25px;">
                ${filtered.map(b => this.renderBlogCard(b)).join('')}
            </div>`;
        }

        return html;
    },

    renderBlogCard(post) {
        const user = State.data.users?.find(u => u.id === post.userId);
        return `
            <div class="blog-card-modern" style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:20px; overflow:hidden; transition:all 0.3s;" onmouseenter="this.style.transform='translateY(-5px)'; this.style.borderColor='rgba(139,92,246,0.3)'" onmouseleave="this.style.transform=''; this.style.borderColor='rgba(255,255,255,0.06)'">
                ${post.mediaUrl ? `<div style="height:180px; overflow:hidden;"><img src="${post.mediaUrl}" style="width:100%; height:100%; object-fit:cover;"></div>` : ''}
                <div style="padding:20px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                        <span style="background:rgba(139,92,246,0.1); color:#a78bfa; padding:4px 10px; border-radius:8px; font-size:0.7rem; font-weight:700; text-transform:uppercase;">${post.category || 'Genel'}</span>
                        <span style="color:#64748b; font-size:0.75rem;">${this.timeAgo(post.createdAt)}</span>
                    </div>
                    <h3 style="color:#fff; font-size:1.2rem; font-weight:700; margin:0 0 10px; line-height:1.4;">${post.title || 'Başlıksız Yazı'}</h3>
                    <p style="color:#94a3b8; font-size:0.85rem; line-height:1.6; display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; margin-bottom:20px;">
                        ${this.stripHtml(post.text).substring(0, 150)}...
                    </p>
                    <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid rgba(255,255,255,0.05); padding-top:15px;">
                        <div style="display:flex; align-items:center; gap:8px;">
                            <img src="${user?.avatar || 'assets/logo.png'}" style="width:24px; height:24px; border-radius:50%;">
                            <span style="color:#e2e8f0; font-size:0.8rem; font-weight:600;">${user?.username || 'Blogger'}</span>
                        </div>
                        <div style="display:flex; gap:8px;">
                            ${State.currentUser?.role === 'admin' && post.status === 'pending' ? `
                                <button onclick="SocialFeed.approvePost('${post.id}')" style="background:#10b981; border:none; color:#fff; padding:5px 12px; border-radius:8px; font-size:0.75rem; font-weight:700; cursor:pointer;"><i class="fa-solid fa-check"></i> Onayla</button>
                                <button onclick="SocialFeed.rejectPost('${post.id}')" style="background:#ef4444; border:none; color:#fff; padding:5px 12px; border-radius:8px; font-size:0.75rem; font-weight:700; cursor:pointer;"><i class="fa-solid fa-xmark"></i> Reddet</button>
                            ` : `
                                <button onclick="SocialFeed.viewBlogPost('${post.id}')" style="background:none; border:none; color:#a78bfa; font-weight:700; font-size:0.85rem; cursor:pointer;">Devamını Oku <i class="fa-solid fa-arrow-right"></i></button>
                            `}
                        </div>
                    </div>
                </div>
            </div>

            <!-- Achievements & Timeline Section -->
            <div style="margin-top:30px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h3 style="color:#fff; font-size:1.2rem; font-weight:800; margin:0;"><i class="fa-solid fa-trophy" style="color:#f59e0b; margin-right:10px;"></i> Başarımlar & Rozetler</h3>
                    <div style="font-size:0.8rem; color:#94a3b8; font-weight:600; background:rgba(255,255,255,0.05); padding:4px 12px; border-radius:20px;">Tamamlanma: ${this.getAchievementCompletionRate(user)}%</div>
                </div>
                
                <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(80px, 1fr)); gap:15px; margin-bottom:30px;">
                    ${this.renderUserAchievements(user)}
                </div>

                <h3 style="color:#fff; font-size:1.2rem; font-weight:800; margin-bottom:20px;"><i class="fa-solid fa-timeline" style="color:#a78bfa; margin-right:10px;"></i> Başarı Geçmişi</h3>
                <div class="achievement-timeline" style="display:flex; flex-direction:column; gap:15px;">
                    ${this.renderAchievementTimeline(user)}
                </div>
            </div>
        `;
    },

    getAchievementCompletionRate(user) {
        const allBadges = [
            { id: 'first_post' }, { id: 'social_butterfly' }, { id: 'popular' },
            { id: 'critic' }, { id: 'influencer' }, { id: 'commenter' },
            { id: 'networker' }, { id: 'veteran' }, { id: 'nerd' }, { id: 'marathon' }
        ];
        const earnedCount = (user.achievements || []).length;
        return Math.round((earnedCount / allBadges.length) * 100) || 0;
    },

    renderUserAchievements(user) {
        const allBadges = [
            { id: 'first_post', name: 'İlk Paylaşım', icon: 'fa-feather', color: '#10b981' },
            { id: 'social_butterfly', name: 'Sosyal Kelebek', icon: 'fa-butterfly', color: '#8b5cf6' },
            { id: 'popular', name: 'Popüler', icon: 'fa-fire', color: '#ef4444' },
            { id: 'critic', name: 'Eleştirmen', icon: 'fa-star-half-stroke', color: '#f59e0b' },
            { id: 'influencer', name: 'Fenomen', icon: 'fa-bolt', color: '#ec4899' },
            { id: 'commenter', name: 'Geveze', icon: 'fa-comments', color: '#3b82f6' },
            { id: 'networker', name: 'Sosyalleşmiş', icon: 'fa-user-group', color: '#10b981' },
            { id: 'veteran', name: 'Efsane', icon: 'fa-trophy', color: '#8b5cf6' },
            { id: 'nerd', name: 'Dizi Kurdu', icon: 'fa-tv', color: '#14b8a6' },
            { id: 'marathon', name: 'Maratoncu', icon: 'fa-running', color: '#ef4444' },
        ];

        return allBadges.map(b => {
            const isEarned = (user.achievements || []).some(ua => ua.id === b.id);
            return `
                <div style="display:flex; flex-direction:column; align-items:center; gap:8px; opacity:${isEarned ? '1' : '0.2'}; filter:${isEarned ? 'none' : 'grayscale(1)'};" title="${b.name}">
                    <div style="width:60px; height:60px; border-radius:18px; background:${isEarned ? b.color + '20' : 'rgba(255,255,255,0.05)'}; border:2px solid ${isEarned ? b.color : 'rgba(255,255,255,0.1)'}; display:flex; align-items:center; justify-content:center; font-size:1.4rem; box-shadow:${isEarned ? '0 0 15px ' + b.color + '30' : 'none'};">
                        <i class="fa-solid ${b.icon}" style="color:${isEarned ? b.color : '#94a3b8'};"></i>
                    </div>
                    <span style="font-size:0.65rem; font-weight:700; color:${isEarned ? '#fff' : '#64748b'}; text-align:center;">${b.name}</span>
                </div>
            `;
        }).join('');
    },

    renderTrendingList() {
        const hashtags = {};
        this.posts.forEach(p => {
            (p.hashtags || []).forEach(h => {
                hashtags[h] = (hashtags[h] || 0) + 1;
            });
        });

        const sorted = Object.entries(hashtags)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5);

        if (sorted.length === 0) return '<div style="color:#64748b; font-size:0.85rem;">Şu an gündem sakin...</div>';

        return sorted.map(([tag, count], i) => `
            <div class="trending-item" onclick="SocialFeed.filterByTag('${tag}')" style="cursor:pointer; display:flex; justify-content:space-between; align-items:center; transition:0.2s;" onmouseenter="this.style.transform='translateX(5px)'" onmouseleave="this.style.transform=''">
                <div>
                    <div style="font-size:0.75rem; color:#64748b;">${i + 1} · Trending</div>
                    <div style="font-weight:800; color:#fff;">${tag}</div>
                    <div style="font-size:0.7rem; color:#a78bfa;">${count} Paylaşım</div>
                </div>
                <i class="fa-solid fa-chevron-right" style="font-size:0.8rem; color:rgba(255,255,255,0.1);"></i>
            </div>
        `).join('');
    },

    renderPopularActors() {
        let actors = [];
        if (State.data?.actors?.length) {
            actors = State.data.actors;
        } else if (State.data?.series) {
            const actorMap = new Map();
            State.data.series.forEach(series => {
                (series.characters || series.cast || []).forEach(c => {
                    const name = c.actor || c.name;
                    if (name && !actorMap.has(name)) {
                        actorMap.set(name, {
                            id: name,
                            name,
                            image: c.image || c.avatar || '',
                            role: c.role || 'Oyuncu'
                        });
                    }
                });
            });
            actors = Array.from(actorMap.values());
        }

        if (!actors.length) {
            return '<p style="color:#64748b; font-size:0.85rem;">Henüz oyuncu eklenmemiş.</p>';
        }

        return actors.slice(0, 12).map(actor => {
            const img = actor.image || actor.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(actor.name)}&background=8b5cf6&color=fff&size=120`;
            const escaped = (actor.name || '').replace(/'/g, "\\'");
            return `
                <div onclick="App.router('actor-detail', '${escaped}')" style="display:flex; align-items:center; gap:10px; padding:10px; border-radius:14px; cursor:pointer; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); margin-bottom:8px; transition:0.2s;"
                     onmouseenter="this.style.borderColor='rgba(139,92,246,0.4)'; this.style.background='rgba(139,92,246,0.08)';"
                     onmouseleave="this.style.borderColor='rgba(255,255,255,0.05)'; this.style.background='rgba(255,255,255,0.02)';">
                    <img src="${img}" alt="${actor.name}" style="width:42px; height:42px; border-radius:50%; object-fit:cover; border:2px solid rgba(139,92,246,0.3);"
                         onerror="this.src='https://ui-avatars.com/api/?name=${encodeURIComponent(actor.name)}&background=8b5cf6&color=fff&size=120'">
                    <div style="min-width:0;">
                        <div style="font-weight:800; color:#fff; font-size:0.85rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${actor.name}</div>
                        <div style="font-size:0.7rem; color:#94a3b8;">${actor.role || 'Oyuncu'}</div>
                    </div>
                </div>
            `;
        }).join('');
    },

    renderHallOfFame() {
        if (!State.data.easterEgg || !State.data.easterEgg.finders) {
            return '<div style="color:#64748b; font-size:0.85rem; font-style:italic;">Gizem henüz çözülmedi... 🕵️</div>';
        }

        const finders = State.data.easterEgg.finders.map(id => State.data.users?.find(u => u.id === id)).filter(u => u);

        if (finders.length === 0) {
            return '<div style="color:#64748b; font-size:0.85rem; font-style:italic;">Gizem henüz çözülmedi... 🕵️</div>';
        }

        return finders.map((u, i) => `
            <div class="hof-item" style="display:flex; align-items:center; gap:12px; margin-bottom:15px; background:rgba(255,215,0,0.05); padding:10px; border-radius:14px; border:1px solid rgba(255,215,0,0.1); position:relative; overflow:hidden;">
                <div class="hof-rank" style="position:absolute; right:10px; top:10px; font-weight:900; color:gold; font-size:1.5rem; opacity:0.2;">#${i + 1}</div>
                <div style="position:relative;">
                    <img src="${u.avatar || 'assets/logo.png'}" style="width:40px; height:40px; border-radius:10px; border:2px solid gold; box-shadow:0 0 10px rgba(255,215,0,0.3);">
                    <i class="fa-solid fa-sparkles" style="position:absolute; -5px; -5px; color:gold; font-size:0.8rem; animation:pulse 1s infinite;"></i>
                </div>
                <div>
                    <div style="font-weight:800; color:#fff; font-size:0.9rem;">${u.username}</div>
                    <div style="font-size:0.7rem; color:gold; font-weight:700;"><i class="fa-solid fa-medal"></i> Sır Avcısı</div>
                </div>
            </div>
        `).join('');
    },

    openStreamSetup() {
        App.router('live', 'studio');
    },

    viewLiveCenter() {
        const liveBtn = document.querySelector('.social-hub-tab[data-tab="live"]');
        if (liveBtn) liveBtn.click();
        else this.switchTab('live');
    },

    renderLiveTab() {
        const activeStreams = (State.data.liveStreams || []).filter(s => s.status === 'live');
        const user = State.currentUser;
        const isTranslator = user?.role === 'translator' || user?.role === 'admin' || user?.badges?.includes('Çevirmen');

        return `
            <div style="margin-bottom: 30px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <div>
                        <h2 style="color:#fff; font-size:1.8rem; font-weight:900; margin:0;"><i class="fa-solid fa-tower-broadcast" style="color:#ef4444; margin-right:12px;"></i> Canlı Yayın Merkezi</h2>
                        <p style="color:#64748b; font-size:0.9rem; margin-top:4px;">Çevirmenlerin canlı çeviri ve sohbet yayınları</p>
                    </div>
                    ${isTranslator ? `
                        <button onclick="SocialFeed.openStreamSetup()" class="btn btn-primary" style="background:linear-gradient(135deg,#ef4444,#dc2626); border:none; padding:12px 24px; border-radius:14px; font-weight:700; box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);">
                            <i class="fa-solid fa-plus"></i> Yayın Başlat
                        </button>
                    ` : ''}
                </div>

                ${activeStreams.length === 0 ? `
                    <div style="text-align:center; padding:80px 20px; background:rgba(255,255,255,0.02); border:1px dashed rgba(255,255,255,0.1); border-radius:24px;">
                        <div style="width:80px; height:80px; background:rgba(239,68,68,0.1); border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 20px;">
                            <i class="fa-solid fa-satellite-dish" style="font-size:2.5rem; color:rgba(239,68,68,0.5);"></i>
                        </div>
                        <h3 style="color:#94a3b8; margin:0 0 10px;">Şu An Aktif Yayın Yok</h3>
                        <p style="color:#64748b; font-size:0.9rem; max-width:400px; margin:0 auto;">Henüz canlı bir çeviri veya sohbet başlatılmamış. Favori çevirmenlerini takip ederek yayınlardan haberdar olabilirsin.</p>
                        ${isTranslator ? '<button class="btn btn-primary" onclick="SocialFeed.openStreamSetup()" style="margin-top:20px; background:#ef4444; border:none; border-radius:10px;">İlk Yayını Sen Başlat!</button>' : ''}
                    </div>
                ` : `
                    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:20px;">
                        ${activeStreams.map(s => `
                            <div class="glass-card" style="padding:0; border-radius:20px; overflow:hidden; border:1px solid rgba(255,255,255,0.05); transition:all 0.3s; cursor:pointer;" onclick="SocialFeed.watchStream('${s.id}')" onmouseenter="this.style.transform='translateY(-5px)'; this.style.borderColor='rgba(239,68,68,0.3)';" onmouseleave="this.style.transform=''; this.style.borderColor='rgba(255,255,255,0.05)';">
                                <div style="position:relative; aspect-ratio:16/9; background:#000; display:flex; align-items:center; justify-content:center;">
                                    <div style="position:absolute; top:12px; left:12px; background:#ef4444; color:#fff; font-size:0.65rem; font-weight:900; padding:4px 8px; border-radius:6px; display:flex; align-items:center; gap:5px; z-index:2;">
                                        <span style="width:6px; height:6px; background:#fff; border-radius:50%; animation:pulse 1s infinite;"></span> CANLI
                                    </div>
                                    <div style="position:absolute; top:12px; right:12px; background:rgba(0,0,0,0.6); color:#fff; font-size:0.65rem; padding:4px 8px; border-radius:6px; z-index:2;">
                                        <i class="fa-solid fa-eye"></i> ${s.viewerCount || 0} İzleyici
                                    </div>
                                    <i class="fa-solid fa-play" style="font-size:2.5rem; color:rgba(255,255,255,0.3);"></i>
                                    <img src="${s.thumbnail || 'assets/logo.png'}" style="position:absolute; inset:0; width:100%; height:100%; object-fit:cover; opacity:0.6;">
                                </div>
                                <div style="padding:15px;">
                                    <h4 style="margin:0 0 10px; color:#fff; font-size:0.95rem; font-weight:700; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${s.title}</h4>
                                    <div style="display:flex; align-items:center; gap:10px;">
                                        <img src="${this.getUserAvatar(s.broadcasterId)}" style="width:30px; height:30px; border-radius:50%; border:1px solid rgba(255,255,255,0.1);">
                                        <div>
                                            <div style="font-weight:600; color:#e2e8f0; font-size:0.8rem;">${s.broadcasterName}</div>
                                            <div style="font-size:0.7rem; color:#64748b;">${s.category || 'Dizi Çevirisi'}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `}
            </div>
        `;
    },

    // ==================== MODERATION TAB ====================
    renderModerationTab() {
        const pendingUsers = (State.data.users || []).filter(u => u.clubStatus === 'pending');

        return `
            <div style="margin-bottom: 30px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <div>
                        <h2 style="color:#fff; font-size:1.8rem; font-weight:900; margin:0;"><i class="fa-solid fa-shield-halved" style="color:var(--premium-pink); margin-right:12px;"></i> Sosyal Yönetim</h2>
                        <p style="color:#64748b; font-size:0.9rem; margin-top:4px;">Klüp başvuruları ve sosyal hub denetimleri</p>
                    </div>
                </div>

                <div class="glass-card" style="padding: 20px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); margin-bottom: 20px;">
                    <h3 style="color:#fff; font-size:1.2rem; font-weight:800; margin-bottom: 20px;"><i class="fa-solid fa-user-clock" style="color:#f59e0b; margin-right:8px;"></i> Klüp Başvuruları</h3>
                    
                    ${pendingUsers.length === 0 ? `
                        <div style="text-align:center; padding: 40px 20px; color:#64748b;">
                            <i class="fa-solid fa-check-circle" style="font-size:2.5rem; color:#10b981; opacity:0.5; margin-bottom:15px;"></i>
                            <h4>Bekleyen başvuru yok.</h4>
                        </div>
                    ` : `
                        <div style="display:flex; flex-direction:column; gap:15px;">
                            ${pendingUsers.map(u => `
                                <div style="display:flex; align-items:center; justify-content:space-between; background:rgba(255,255,255,0.02); padding:15px; border-radius:14px; border:1px solid rgba(255,255,255,0.05);">
                                    <div style="display:flex; align-items:center; gap:15px;">
                                        <img src="${u.avatar || 'assets/logo.png'}" style="width:50px; height:50px; border-radius:50%; object-fit:cover;">
                                        <div>
                                            <div style="font-weight:700; color:#fff; font-size:1rem;">${u.username}</div>
                                            <div style="font-size:0.8rem; color:#94a3b8;">${u.email || 'Email gizli'}</div>
                                        </div>
                                    </div>
                                    <div style="display:flex; gap:10px;">
                                        <button onclick="SocialFeed.approveClubRequest('${u.id}')" class="btn btn-primary" style="background:#10b981; border:none; padding:8px 16px; border-radius:10px; font-weight:700;"><i class="fa-solid fa-check"></i> Onayla</button>
                                        <button onclick="SocialFeed.rejectClubRequest('${u.id}')" class="btn btn-primary" style="background:#ef4444; border:none; padding:8px 16px; border-radius:10px; font-weight:700;"><i class="fa-solid fa-xmark"></i> Reddet</button>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    `}
                </div>
            </div>
        `;
    },

    async approveClubRequest(userId) {
        if (window.db && db.updateUser) {
            await db.updateUser(userId, { clubStatus: 'approved' });
        } else {
            const idx = State.data.users.findIndex(u => String(u.id) === String(userId));
            if (idx > -1) State.data.users[idx].clubStatus = 'approved';
            if (window.db) db.save('users');
        }
        Toast.success('Kullanıcı klübe kabul edildi!');
        this.render();
    },

    async rejectClubRequest(userId) {
        if (window.db && db.updateUser) {
            await db.updateUser(userId, { clubStatus: 'rejected' });
        } else {
            const idx = State.data.users.findIndex(u => String(u.id) === String(userId));
            if (idx > -1) State.data.users[idx].clubStatus = 'rejected';
            if (window.db) db.save('users');
        }
        Toast.info('Kullanıcı başvurusu reddedildi.');
        this.render();
    },

    renderLiveStreams() {
        const activeStreams = (State.data.liveStreams || []).filter(s => s.status === 'live');
        if (activeStreams.length === 0) return '';

        return `
            <h4 style="margin-bottom: 15px; color: #ef4444; font-weight: 900; font-size: 0.85rem; display: flex; align-items: center; gap: 8px;">
                <span class="live-dot" style="width:8px; height:8px; background:#ef4444; border-radius:50%; animation:pulse 1s infinite;"></span> CANLI ÇEVİRİLER
            </h4>
            <div style="display:flex; flex-direction:column; gap:10px;">
                ${activeStreams.map(s => `
                    <div class="live-stream-card" onclick="SocialFeed.watchStream('${s.id}')" style="background:rgba(239,68,68,0.05); border:1px solid rgba(239,68,68,0.1); border-radius:12px; padding:10px; cursor:pointer; transition:0.2s;" onmouseenter="this.style.background='rgba(239,68,68,0.08)'" onmouseleave="this.style.background='rgba(239,68,68,0.05)'">
                        <div style="font-weight:700; color:#fff; font-size:0.8rem; margin-bottom:4px;">${s.title}</div>
                        <div style="display:flex; align-items:center; gap:6px;">
                            <img src="${this.getUserAvatar(s.broadcasterId)}" style="width:16px; height:16px; border-radius:50%;">
                            <span style="font-size:0.7rem; color:#64748b;">${s.broadcasterName}</span>
                            <span style="margin-left:auto; font-size:0.65rem; color:#ef4444;"><i class="fa-solid fa-eye"></i> ${s.viewerCount || 0}</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    },

    getUserAvatar(userId) {
        const u = State.data.users?.find(x => x.id === userId);
        return u?.avatar || 'assets/logo.png';
    },

    async watchStream(streamId) {
        App.router('live', streamId);
    },

    async sendDonation(toId, amount) {
        if (!State.currentUser) return Toast.error('Lütfen giriş yapın.');
        
        // Use the centralized LiveService for consistent database updates
        if (window.LiveService) {
            // If we are in a live stream, we use the stream donation logic
            if (window.LivePlayer && LivePlayer.currentStream) {
                const res = await LiveService.sendCoin(LivePlayer.currentStream.id, amount);
                if (res.success) {
                    Toast.success(`${amount} DramicCoin gönderildi! 🎉`);
                } else {
                    Toast.error(res.message || 'Hata oluştu.');
                }
                return;
            }
        }

        // Generic donation (Social Hub profile)
        Toast.info('Sosyal profil bağış sistemi güncelleniyor...');
    },

    sendLiveChatMessage(streamId) {
        const input = document.getElementById('live-chat-input');
        const text = input.value.trim();
        if (!text) return;
        
        this.addLiveChatMessage(State.currentUser.username, text);
        input.value = '';
    },

    addLiveChatMessage(user, text) {
        const container = document.getElementById('live-chat-messages');
        if (!container) return;
        
        const msg = document.createElement('div');
        msg.innerHTML = user ? `<b style="color:#a78bfa;">${user}:</b> ${text}` : `<div style="background:rgba(245,158,11,0.1); color:#f59e0b; padding:5px; border-radius:5px; font-size:0.75rem; text-align:center;">${text}</div>`;
        msg.style.fontSize = '0.85rem';
        msg.style.color = '#e2e8f0';
        
        container.appendChild(msg);
        container.scrollTop = container.scrollHeight;
    },

    renderAchievementTimeline(user) {
        const history = user.achievements || [];
        if (history.length === 0) return '<div style="color:#64748b; font-size:0.85rem; font-style:italic;">Henüz bir başarım kazanılmadı.</div>';

        return history.sort((a, b) => new Date(b.date) - new Date(a.date)).map(h => `
            <div style="display:flex; gap:15px; position:relative; padding-left:20px; border-left:2px solid rgba(124, 58, 237, 0.2);">
                <div style="position:absolute; left:-7px; top:0; width:12px; height:12px; border-radius:50%; background:#7c3aed; box-shadow:0 0 10px rgba(124, 58, 237, 0.5);"></div>
                <div style="flex:1; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:12px; padding:12px 16px;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                        <span style="font-weight:700; color:#fff; font-size:0.9rem;">${h.name}</span>
                        <span style="font-size:0.7rem; color:#64748b;">${new Date(h.date).toLocaleDateString('tr-TR')}</span>
                    </div>
                    <div style="color:#94a3b8; font-size:0.8rem;">"${h.id}" başarımı kilidi açıldı! 🎉</div>
                </div>
            </div>
        `).join('');
    },

    stripHtml(html) {
        const tmp = document.createElement('DIV');
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || "";
    },

    filterBlogByCategory(cat) {
        this._blogCategory = cat;
        this.render();
    },

    openBlogEditor() {
        if (window.BlogEditor && typeof BlogEditor.showEditor === 'function') {
            BlogEditor.showEditor();
        } else {
            const modal = document.getElementById('blog-editor-modal');
            if (modal) {
                modal.style.display = 'flex';
                // Trigger any init if needed
                if (window.BlogEditor && typeof BlogEditor.init === 'function') BlogEditor.init();
            } else {
                Toast.error('Blog editörü yüklenemedi!');
            }
        }
    },

    viewBlogPost(postId) {
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;
        // Logic to show blog detail view
        this.currentTab = 'blog-detail';
        this.setupEventListeners();
        this.render();

        // Listen for Cloud Sync events to refresh feed live
        window.addEventListener('dramicbox_sync_complete', () => {
            console.log('🔄 Cloud Pulse detected new social data, refreshing feed...');
            this.render();
        });
    },

    renderFeedTab() {
        const user = (State.currentUser && State.currentUser.role !== 'guest') ? State.currentUser : null;
        const avatar = user?.avatar || 'assets/logo.png';

        // Stories Bar
        const storiesHtml = this.renderStoriesBar();

        if (!this.posts || !Array.isArray(this.posts)) {
            this.posts = State.data.socialPosts || [];
        }

        let postsHtml = '';
        if (this.posts.length === 0) {
            postsHtml = `
                <div class="social-empty-state">
                    <i class="fa-solid fa-satellite-dish"></i>
                    <h3>Henüz paylaşım yok</h3>
                    <p>İlk paylaşımı yaparak topluluğu başlat!</p>
                </div>`;
        } else {
            // Filter blocked users and respect privacy
            const blockedUsers = State.currentUser?.blockedUsers || [];
            const visiblePosts = this.posts.filter(p => {
                if (!p) return false;
                
                const poster = State.data.users?.find(u => u.id === p.userId);
                
                // 1. Profile Privacy Audit
                if (poster && poster.isPrivate && p.userId !== State.currentUser?.id) {
                    const isFriend = (State.currentUser?.friends || []).includes(p.userId);
                    if (!isFriend) return false;
                }

                // 2. Post-level Privacy Audit
                if (p.privacy === 'followers' && p.userId !== State.currentUser?.id) {
                    const isFollowing = (State.currentUser?.following || []).includes(p.userId);
                    const isFriend = (State.currentUser?.friends || []).includes(p.userId);
                    if (!isFollowing && !isFriend) return false;
                }

                // 3. Status Audit
                if (p.status === 'pending') {
                    if (p.userId !== State.currentUser?.id && !this.isModerator(State.currentUser)) return false;
                }

                // 4. Blocking Audit
                const blockedUsers = State.currentUser?.blockedUsers || [];
                if (blockedUsers.includes(p.userId)) return false;
                if (poster?.blockedUsers?.includes(State.currentUser?.id)) return false;

                return true;
            });

            // Sorting logic
            let sorted = [...visiblePosts];
            const following = State.currentUser?.following || [];

            try {
                if (this.sortMode === 'popular') {
                    sorted.sort((a, b) => {
                        const scoreA = (a.likes?.length || 0) + (a.comments?.length || 0) * 2 + (a.tips || 0) * 5;
                        const scoreB = (b.likes?.length || 0) + (b.comments?.length || 0) * 2 + (b.tips || 0) * 5;
                        return scoreB - scoreA;
                    });
                } else {
                    sorted.sort((a, b) => {
                        if (a.isPinned && !b.isPinned) return -1;
                        if (!a.isPinned && b.isPinned) return 1;
                        const aFollowed = following.includes(a.userId) ? 1 : 0;
                        const bFollowed = following.includes(b.userId) ? 1 : 0;
                        if (aFollowed !== bFollowed) return bFollowed - aFollowed;
                        const dateA = a.createdAt ? new Date(a.createdAt) : 0;
                        const dateB = b.createdAt ? new Date(b.createdAt) : 0;
                        return dateB - dateA;
                    });
                }
            } catch (sortErr) {
                console.warn('Post sort error:', sortErr);
            }

            // Ad injection
            if (typeof AdService !== 'undefined' && AdService.shouldShowAds()) {
                sorted = AdService.injectSocialAds(sorted);
            }

            // Privacy Filter: Only show posts from public profiles or friends
            const privacyFiltered = sorted.filter(post => {
                if (!post) return false;
                const author = State.data.users?.find(u => u.id === post.userId);
                if (!author) return true; // Fallback for system posts

                const isSelf = State.currentUser?.id === author.id;
                const isFriend = (State.currentUser?.friends || []).includes(author.id);
                const isPrivate = author.privacy === 'private';

                return !isPrivate || isSelf || isFriend;
            });

            let filtered = this.filterTag
                ? privacyFiltered.filter(p => p && (p.hashtags || []).includes(this.filterTag.toLowerCase()))
                : privacyFiltered;

            if (this.searchQuery) {
                filtered = filtered.filter(p => {
                    if (!p) return false;
                    const text = (p.text || '').toLowerCase();
                    const username = (State.data.users?.find(u => u.id === p.userId)?.username || '').toLowerCase();
                    const hashtags = (p.hashtags || []).join(' ').toLowerCase();
                    return text.includes(this.searchQuery) || username.includes(this.searchQuery) || hashtags.includes(this.searchQuery);
                });
            }

            // Simple Virtualization: Paginate posts
            const totalVisible = filtered.length;
            const limitedPosts = filtered.slice(0, this.currentPage * this.postsPerPage);

            postsHtml = limitedPosts.map(p => {
                try {
                    return this.renderPostCard(p);
                } catch (e) {
                    console.error('Post card render error:', e, p);
                    return '';
                }
            }).join('');

            // Load More Button
            if (totalVisible > limitedPosts.length) {
                postsHtml += `
                    <div style="text-align:center; padding: 30px 0;">
                        <button class="post-submit-btn" style="width: 220px; font-weight: 700; height: 50px; background: linear-gradient(135deg, #8b5cf6, #7c3aed); border-radius: 25px;" 
                                onclick="SocialFeed.loadMorePosts()">
                            <i class="fa-solid fa-chevron-down" style="margin-right: 8px;"></i> Daha Fazla Yükle
                        </button>
                    </div>
                `;
            }

            if ((this.filterTag || this.searchQuery) && filtered.length === 0) {
                postsHtml = `
                    <div class="social-empty-state">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <h3>Arama kriterlerinize uygun sonuç bulunamadı</h3>
                        <button class="post-submit-btn" style="margin-top:15px;" onclick="SocialFeed.filterByTag(null); SocialFeed.handleSearch(''); document.getElementById('social-search-input').value='';">Tüm Akışı Gör</button>
                    </div>`;
            }
        }

        return `
            <!-- Stories Bar -->
            ${storiesHtml}

            <!-- Persistent Spoiler Disclaimer Banner -->
            <div class="spoiler-disclaimer-banner" style="background: rgba(239, 68, 68, 0.06); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 16px; padding: 15px 20px; margin-bottom: 20px; display: flex; align-items: center; gap: 15px; box-shadow: 0 0 15px rgba(239, 68, 68, 0.05);">
                <div style="background: #ef4444; width: 36px; height: 36px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; flex-shrink: 0; box-shadow: 0 0 10px rgba(239, 68, 68, 0.3);">
                    <i class="fa-solid fa-triangle-exclamation" style="font-size: 1.1rem;"></i>
                </div>
                <div style="flex: 1;">
                    <h4 style="margin: 0; color: #fff; font-size: 0.95rem; font-weight: 800; font-family: 'Outfit', sans-serif;">Spoiler Uyarısı!</h4>
                    <p style="margin: 3px 0 0; color: #cbd5e1; font-size: 0.82rem; line-height: 1.4; font-family: 'Inter', sans-serif;">Bu bölümdeki incelemeler, paylaşımlar ve yorumlar diziler hakkında <b>sürprizbozan (spoiler)</b> içerebilir.</p>
                </div>
            </div>

            <!-- Feed Sorting & Filters -->
            <div class="feed-sort-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; background: rgba(255,255,255,0.02); padding: 10px 15px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                <div style="display: flex; gap: 8px;">
                    <button onclick="SocialFeed.setSort('latest')" 
                            style="padding: 6px 14px; border-radius: 8px; border: none; font-size: 0.85rem; font-weight: 700; cursor: pointer; transition: all 0.3s;
                            ${this.sortMode === 'latest' ? 'background: #8b5cf6; color: white;' : 'background: transparent; color: #94a3b8;'}">
                        Son Eklenen
                    </button>
                    <button onclick="SocialFeed.setSort('popular')" 
                            style="padding: 6px 14px; border-radius: 8px; border: none; font-size: 0.85rem; font-weight: 700; cursor: pointer; transition: all 0.3s;
                            ${this.sortMode === 'popular' ? 'background: #f59e0b; color: white;' : 'background: transparent; color: #94a3b8;'}">
                        Popüler
                    </button>
                </div>
                ${this.filterTag ? `<div style="font-size: 0.85rem; color: #a78bfa; font-weight: 600;">#${this.filterTag} filtreleniyor</div>` : ''}
            </div>

            <!-- Create Post Box -->
            ${user ? `
            <div class="create-post-box">
                <div class="create-post-trigger" onclick="SocialFeed.openCreatePostModal()">
                    <img src="${avatar}" alt="avatar">
                    <span class="post-placeholder">Ne düşünüyorsun, ${user.username}?</span>
                </div>
                <div class="create-post-actions">
                    <button class="create-post-action-btn media" onclick="SocialFeed.openCreatePostModal('media'); setTimeout(() => SocialFeed.promptMediaLink(), 300)">
                        <i class="fa-solid fa-image"></i> Medya
                    </button>
                    <button class="create-post-action-btn poll" onclick="SocialFeed.openCreatePostModal('poll')">
                        <i class="fa-solid fa-square-poll-vertical"></i> Anket
                    </button>
                    <button class="create-post-action-btn spoiler" onclick="SocialFeed.openCreatePostModal('spoiler')">
                        <i class="fa-solid fa-eye-slash"></i> Spoiler
                    </button>
                    <button class="create-post-action-btn gift" onclick="SocialFeed.toggleGiftCardEditorInModal()" style="color:#ec4899;">
                        <i class="fa-solid fa-gift"></i> Hediye
                    </button>
                </div>
            </div>` : `
            <div class="create-post-box guest-restriction-box" style="text-align:center; padding:45px 30px; background: rgba(15, 15, 20, 0.4); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1px solid rgba(139, 92, 246, 0.25); border-radius: 24px; box-shadow: 0 15px 35px rgba(0,0,0,0.3), inset 0 0 1px 1px rgba(255,255,255,0.05); margin-bottom: 25px;">
                <div style="font-size: 3.5rem; margin-bottom: 20px; background: linear-gradient(135deg, #a78bfa, #f472b6); -webkit-background-clip: text; -webkit-text-fill-color: transparent; display: inline-block; filter: drop-shadow(0 0 15px rgba(139, 92, 246, 0.4));">
                    <i class="fa-solid fa-lock"></i>
                </div>
                <h3 style="color: #fff; font-weight: 800; font-size: 1.5rem; margin-bottom: 12px; letter-spacing: -0.5px;">Giriş Yapmanız Gerekmektedir</h3>
                <p style="color: #94a3b8; margin-bottom: 25px; max-width: 420px; margin-left: auto; margin-right: auto; font-size: 0.95rem; line-height: 1.6;">Paylaşım yapmak ve topluluğa katılmak için giriş yapmalısınız.</p>
                <div style="display: flex; gap: 15px; justify-content: center; align-items: center;">
                    <button class="btn btn-primary" onclick="Auth.showLogin()" style="padding: 12px 30px; border-radius: 12px; font-weight: 800; font-size: 0.9rem; cursor: pointer; box-shadow: 0 8px 20px rgba(124, 58, 237, 0.3);">Giriş Yap</button>
                    <button class="btn btn-secondary" onclick="Auth.showRegister()" style="padding: 12px 30px; border-radius: 12px; font-weight: 800; font-size: 0.9rem; cursor: pointer; border: 1px solid rgba(255, 255, 255, 0.15); background: rgba(255,255,255,0.03); color: #fff; transition: var(--smooth);" onmouseover="this.style.background='rgba(255,255,255,0.08)';" onmouseout="this.style.background='rgba(255,255,255,0.03)';">Kayıt Ol</button>
                </div>
            </div>
            `}

            <!-- Posts -->
            <div id="social-posts-container">
                ${postsHtml}
            </div>
        `;
    },

    setSort(mode) {
        this.sortMode = mode;
        this.switchTab('feed', document.querySelector('.social-hub-tab[data-tab="feed"]'));
    },

    // ==================== POST CARD (PREMIUM) ====================
    renderPostCard(post) {
        if (post.isAd) {
            return `
                <div class="post-card-premium ad-post" style="border: 1px solid var(--ultra-accent-glow); background: rgba(124, 58, 237, 0.05);">
                    <div class="post-header">
                        <img src="${post.author.avatar}" class="post-avatar">
                        <div class="post-user-info">
                            <div class="post-username">
                                ${post.author.username} 
                                <span class="badge badge-accent">SPONSORLU</span>
                            </div>
                            <div class="post-time">Önerilen İçerik</div>
                        </div>
                    </div>
                    <div class="post-content">
                        <p>${post.content}</p>
                        ${post.image ? `<img src="${post.image}" class="post-media" style="cursor: pointer;" onclick="window.open('${post.link}', '_blank')">` : ''}
                    </div>
                    <div style="margin-top:15px;">
                        <button class="btn-hero-primary" onclick="window.open('${post.link}', '_blank')" style="width: 100%; justify-content: center;">
                            Hemen İncele <i class="fa-solid fa-arrow-up-right-from-square" style="margin-left: 8px;"></i>
                        </button>
                    </div>
                </div>
            `;
        }

        const user = State.data.users?.find(u => u.id === post.userId);
        const username = user?.username || 'Bilinmeyen';
        const avatar = user?.avatar || 'assets/logo.png';
        const isVerified = user?.isVerified === true || user?.role === 'admin' || user?.role === 'moderator' || user?.badges?.includes('Admin') || user?.badges?.includes('Yönetici');
        const timeStr = this.timeAgo(post.createdAt);
        const commentCount = post.comments?.length || 0;

        const content = this.parseContent(post.text || '');
        const isSpoiler = post.isSpoiler;

        let mediaHtml = '';
        if (post.mediaUrl) {
            const isIdb = post.mediaUrl.startsWith('media-idb:');
            const mediaId = isIdb ? post.mediaUrl.replace('media-idb:', '') : null;
            const src = isIdb ? '' : post.mediaUrl; // Empty if IDB, will be resolved later

            if (post.mediaType === 'video') {
                mediaHtml = `<div class="post-media"><video ${isIdb ? `data-media-idb="${mediaId}"` : `src="${src}"`} controls playsinline></video></div>`;
            } else {
                mediaHtml = `<div class="post-media"><img ${isIdb ? `data-media-idb="${mediaId}"` : `src="${src}"`} alt="post media"></div>`;
            }
        }

        // Shared content logic...
        let sharedHtml = '';
        if (post.sharedContent) {
             const sc = post.sharedContent;
             const posterUrl = sc.poster ? (sc.poster.startsWith('/') || sc.poster.startsWith('http') || sc.poster.startsWith('data:') ? sc.poster : '/' + sc.poster) : 'assets/poster-placeholder.jpg';
             sharedHtml = `
                <div class="post-media">
                    <div class="social-nav-card" style="padding:10px; border-radius:18px; display:flex; gap:15px; cursor:pointer; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); transition: all 0.3s;" onmouseenter="this.style.background='rgba(255,255,255,0.05)'" onmouseleave="this.style.background='rgba(255,255,255,0.02)'" onclick="App.router('detail', '${sc.seriesId || sc.id}')">
                        <img src="${posterUrl}" style="width:80px; height:110px; border-radius:12px; object-fit:cover; box-shadow: 0 4px 10px rgba(0,0,0,0.3);">
                        <div style="display:flex; flex-direction:column; justify-content:center;">
                            <span class="badge badge-accent" style="width:fit-content; margin-bottom:8px; font-size: 0.65rem;"><i class="fa-solid fa-share-nodes"></i> PAYLAŞILAN İÇERİK</span>
                            <h4 style="margin:0; color:#fff; font-size:1.1rem; font-weight: 800;">${sc.title}</h4>
                            <p style="margin:6px 0 0; color:#94a3b8; font-size:0.85rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${sc.subtitle || 'DramicBox İçeriği'}</p>
                        </div>
                    </div>
                </div>
             `;
        }

        let pollHtml = '';
        if (post.poll) {
            pollHtml = this.renderPoll(post);
        }

        let giftHtml = '';
        let liveHtml = '';
        
        if (post.type === 'live_broadcast') {
            const stream = State.data.liveStreams?.find(s => s.id === post.liveId);
            const isEnded = stream?.status === 'ended';
            
            liveHtml = `
                <div class="live-broadcast-card" style="margin-top:15px; background:rgba(239,68,68,0.08); border:1px solid rgba(239,68,68,0.2); border-radius:18px; padding:20px; text-align:center; position:relative; overflow:hidden;">
                    <div style="position:absolute; top:10px; right:15px;">
                        ${isEnded ? 
                            '<span style="background:#64748b; color:#fff; font-size:0.65rem; padding:4px 10px; border-radius:20px; font-weight:800;">YAYIN BİTTİ</span>' : 
                            '<span style="background:#ef4444; color:#fff; font-size:0.65rem; padding:4px 10px; border-radius:20px; font-weight:800; animation:pulse 1s infinite;">CANLI</span>'
                        }
                    </div>
                    <div style="width:60px; height:60px; background:rgba(239,68,68,0.15); border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 15px; border:2px solid rgba(239,68,68,0.3);">
                        <i class="fa-solid fa-satellite-dish" style="color:#ef4444; font-size:1.8rem; ${isEnded ? '' : 'animation: pulse 1.5s infinite;'}"></i>
                    </div>
                    <h4 style="color:#fff; margin-bottom:8px; font-size:1.1rem; font-weight:800;">${post.text || post.content || 'Canlı Çeviri Yayını'}</h4>
                    <p style="color:#94a3b8; font-size:0.85rem; margin-bottom:20px;">${isEnded ? 'Bu yayın sona erdi. Diğer aktif yayınlara göz atabilirsiniz.' : 'Hemen katılın ve çeviri sürecini canlı izleyin!'}</p>
                    
                    ${!isEnded ? `
                        <button onclick="SocialFeed.watchStream('${post.liveId}')" class="btn btn-primary" style="width:100%; background:linear-gradient(135deg, #ef4444, #b91c1c); border:none; padding:12px; border-radius:12px; font-weight:800;">
                            <i class="fa-solid fa-play"></i> YAYINI İZLE
                        </button>
                    ` : `
                        <button class="btn btn-secondary" style="width:100%; background:rgba(255,255,255,0.05); color:#64748b; border:1px solid rgba(255,255,255,0.1); padding:12px; border-radius:12px; font-weight:800; cursor:not-allowed;">
                            <i class="fa-solid fa-clock-rotate-left"></i> YAYIN ARŞİVDE
                        </button>
                    `}
                </div>
            `;
        }

        let actorFanHtml = '';
        if (post.type === 'actor-fan') {
            const actorId = post.metadata?.actorId;
            const actorName = post.metadata?.actorName || 'Oyuncu';
            const actorImg = post.metadata?.image;
            
            actorFanHtml = `
                <div class="actor-fan-card" style="margin-top:15px; background:rgba(139, 92, 246, 0.05); border:1px solid rgba(139, 92, 246, 0.2); border-radius:18px; overflow:hidden;">
                    ${actorImg ? `<img src="${actorImg}" style="width:100%; height:200px; object-fit:cover;">` : ''}
                    <div style="padding:15px; display:flex; justify-content:space-between; align-items:center;">
                        <div style="display:flex; align-items:center; gap:12px;">
                            <div style="width:40px; height:40px; background:rgba(139, 92, 246, 0.1); border-radius:50%; display:flex; align-items:center; justify-content:center;">
                                <i class="fa-solid fa-heart" style="color:#a78bfa;"></i>
                            </div>
                            <div>
                                <div style="color:#fff; font-weight:700; font-size:0.9rem;">${actorName} Hayran Paylaşımı</div>
                                <div style="color:#a78bfa; font-size:0.75rem; font-weight:600;">Fan Merkezi Katkısı</div>
                            </div>
                        </div>
                        <button class="btn-sm" onclick="App.router('actor', '${encodeURIComponent(actorName)}')" style="background:rgba(139, 92, 246, 0.1); color:#a78bfa; border:none; border-radius:10px; padding:6px 12px; font-weight:700; cursor:pointer;">Merkeze Git</button>
                    </div>
                </div>
            `;
        }

        let commentsHtml = '';

        return `
            <div class="post-card-premium ${isSpoiler ? 'is-spoiler' : ''} ${post.type === 'live_broadcast' ? 'live-post' : ''}" id="post-${post.id}">
                <div class="post-header">
                    <img class="post-avatar" src="${avatar}" alt="${username}" onclick="App.router('profile', '${post.userId}')">
                    <div class="post-user-info">
                        <div class="post-username" onclick="App.router('profile', '${post.userId}')">
                            ${username}
                            ${isVerified ? '<i class="fa-solid fa-circle-check verified-badge"></i>' : ''}
                        </div>
                        <div class="post-time">
                            ${post.isPinned ? '<i class="fa-solid fa-thumbtack" style="color:var(--ultra-accent); margin-right:4px;"></i>' : ''}
                            ${timeStr}
                        </div>
                    </div>
                    <button class="social-nav-item" style="padding:8px; border-radius:50%;" onclick="SocialFeed.postMenu('${post.id}')">
                        <i class="fa-solid fa-ellipsis"></i>
                    </button>
                </div>
                <div class="post-content">
                    ${isSpoiler ? `
                        <div id="spoiler-${post.id}" class="spoiler-wrapper" onclick="SocialFeed.revealSpoiler('${post.id}')">
                            <div class="spoiler-overlay">
                                <i class="fa-solid fa-eye-slash"></i>
                                <span>Bu paylaşım spoiler içeriyor.<br>Görmek için tıklayın.</span>
                            </div>
                            <div class="spoiler-content">
                                ${post.type !== 'live_broadcast' ? `<div class="post-text">${content}</div>` : ''}
                                ${mediaHtml}
                                ${sharedHtml}
                                ${pollHtml}
                                ${giftHtml}
                                ${liveHtml}
                                ${actorFanHtml}
                            </div>
                        </div>
                    ` : `
                        ${post.type !== 'live_broadcast' ? `<div class="post-text">${content}</div>` : ''}
                        ${mediaHtml}
                        ${sharedHtml}
                        ${pollHtml}
                        ${giftHtml}
                        ${liveHtml}
                        ${actorFanHtml}
                    `}
                </div>
                <div class="post-actions">
                    <div class="emoji-reactions" style="display:flex;gap:2px;">
                        ${['❤️', '🔥', '😂', '😢', '🤯'].map(emoji => {
                            const count = (post.reactions?.[emoji] || []).length;
                            const reacted = (post.reactions?.[emoji] || []).includes(State.currentUser?.id);
                            return `<button class="post-action-btn ${reacted ? 'liked' : ''}" onclick="SocialFeed.toggleReaction('${post.id}','${emoji}')" style="font-size:0.85rem; padding:4px 8px; min-width:auto; ${reacted ? 'background:rgba(124,58,237,0.12);border-radius:8px;' : ''}">${emoji} ${count > 0 ? `<span style='font-size:0.7rem;'>${count}</span>` : ''}</button>`;
                        }).join('')}
                    </div>
                    <div style="display:flex;gap:4px;margin-left:auto;">
                        <button class="post-action-btn" onclick="SocialFeed.toggleComments('${post.id}')">
                            <i class="fa-regular fa-comment"></i> ${commentCount > 0 ? commentCount : ''}
                        </button>
                        <button class="post-action-btn" onclick="SocialFeed.repost('${post.id}')" title="Yeniden Paylaş">
                            <i class="fa-solid fa-retweet"></i>
                        </button>
                    </div>
                </div>
                <div id="comments-section-${post.id}" style="display:none;">
                    ${commentsHtml}
                </div>
            </div>`;
    },

    // ==================== POLL RENDER ====================
    renderPoll(post) {
        const poll = post.poll;
        const totalVotes = poll.options.reduce((sum, o) => sum + (o.votes || 0), 0);
        const hasVoted = poll.voters?.includes(State.currentUser?.id);

        return `
            <div class="poll-container">
                <div class="poll-question">${this.escapeHtml(poll.question)}</div>
                ${poll.options.map((opt, i) => {
            const pct = totalVotes > 0 ? Math.round((opt.votes / totalVotes) * 100) : 0;
            return `
                        <div class="poll-option ${hasVoted ? 'voted' : ''}" 
                             onclick="${hasVoted ? '' : `SocialFeed.votePoll('${post.id}', ${i})`}">
                            ${hasVoted ? `<div class="poll-bar" style="width: ${pct}%"></div>` : ''}
                            <div class="poll-label">
                                <span>${this.escapeHtml(opt.text)}</span>
                                ${hasVoted ? `<span class="poll-percentage">${pct}%</span>` : ''}
                            </div>
                        </div>`;
        }).join('')}
                <div class="poll-meta">
                    <span><i class="fa-solid fa-chart-bar"></i> ${totalVotes} oy</span>
                </div>
            </div>`;
    },

    // ==================== CREATE POST MODAL ====================
    openCreatePostModal(mode = null) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Paylaşım yapmak ve topluluğa katılmak için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }

        if (State.currentUser.clubStatus !== 'approved' && !this.isModerator(State.currentUser)) {
            Toast.warning('Paylaşım yapabilmek için klüp başvurunuzun onaylanması gerekmektedir.');
            return;
        }

        if (this.checkSocialBan()) return;

        const user = State.currentUser;
        const avatar = user.avatar || 'assets/logo.png';

        // Pre-fill shared content if exists
        let sharedPreviewHtml = '';
        if (this.shareData) {
            const sd = this.shareData;
            const posterUrl = sd.poster ? (sd.poster.startsWith('/') || sd.poster.startsWith('http') || sd.poster.startsWith('data:') ? sd.poster : '/' + sd.poster) : 'assets/poster-placeholder.jpg';
            sharedPreviewHtml = `
                <div class="shared-content-card" style="margin-bottom: 15px; background: rgba(255,255,255,0.03); border-radius: 12px; padding: 10px; display: flex; gap: 12px; border: 1px solid rgba(255,255,255,0.06);">
                    <img src="${posterUrl}" alt="${sd.title}" style="width: 50px; height: 70px; border-radius: 8px; object-fit: cover;">
                    <div class="shared-info" style="display: flex; flex-direction: column; justify-content: center;">
                        <h4 style="margin: 0; color: #fff; font-size: 0.95rem;">${this.escapeHtml(sd.title)}</h4>
                        <p style="margin: 4px 0 0; color: #64748b; font-size: 0.8rem;">${this.escapeHtml(sd.subtitle || 'DramicBox İçeriği')}</p>
                    </div>
                </div>`;
        }

        const overlay = document.createElement('div');
        overlay.className = 'create-post-modal-overlay';
        overlay.id = 'create-post-overlay';
        overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

        let pollEditorHtml = '';
        if (mode === 'poll') {
            pollEditorHtml = `
                <div id="poll-editor" style="margin-top:14px; padding:14px; background:rgba(255,255,255,0.02); border-radius:14px; border:1px solid rgba(255,255,255,0.06);">
                    <input type="text" id="poll-question" placeholder="Anket sorusu..." 
                           style="width:100%; background:transparent; border:none; color:#fff; font-size:1rem; font-weight:700; margin-bottom:12px; outline:none; font-family:'Inter',sans-serif;">
                    <div id="poll-options-list">
                        <input type="text" class="poll-option-input" placeholder="Seçenek 1" style="width:100%; padding:10px 14px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#e2e8f0; margin-bottom:8px; outline:none; font-family:'Inter',sans-serif;">
                        <input type="text" class="poll-option-input" placeholder="Seçenek 2" style="width:100%; padding:10px 14px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#e2e8f0; margin-bottom:8px; outline:none; font-family:'Inter',sans-serif;">
                    </div>
                    <button onclick="SocialFeed.addPollOption()" style="background:none; border:1px dashed rgba(255,255,255,0.1); color:#64748b; width:100%; padding:10px; border-radius:10px; cursor:pointer; font-family:'Inter',sans-serif; margin-top:4px;">
                        <i class="fa-solid fa-plus"></i> Seçenek Ekle
                    </button>
                </div>`;
        }

        overlay.innerHTML = `
            <div class="create-post-modal">
                <div class="create-post-modal-header">
                    <h2>Paylaşım Oluştur</h2>
                    <button class="close-btn" onclick="document.getElementById('create-post-overlay').remove()">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
                
                <div style="display:flex; align-items:center; gap:12px; margin-bottom:16px;">
                    <img src="${avatar}" style="width:42px; height:42px; border-radius:50%; object-fit:cover; border:2px solid rgba(124,58,237,0.3);">
                    <div>
                        <div style="font-weight:700; color:#fff;">${user.username}</div>
                        <div style="font-size:0.8rem; color:#64748b;"><i class="fa-solid fa-earth-americas"></i> Herkese Açık</div>
                    </div>
                </div>

                <textarea class="create-post-textarea" id="create-post-text" placeholder="Ne düşünüyorsun? #hashtagler ve @etiketler kullanabilirsin...">${this.shareData ? '' : ''}</textarea>

                ${sharedPreviewHtml}

                <div id="media-preview-area"></div>

                ${pollEditorHtml}

                <div class="create-post-options">
                    <div class="post-option-btns">
                        <button class="post-option-btn" onclick="SocialFeed.promptMediaLink()" title="Medya Linki Ekle">
                            <i class="fa-solid fa-link" style="color:#10b981;"></i>
                        </button>
                        <button class="post-option-btn" onclick="SocialFeed.openSeriesSelector()" title="Dizi/Film Etiketle">
                            <i class="fa-solid fa-clapperboard" style="color:#3b82f6;"></i>
                        </button>
                        <button class="post-option-btn" onclick="SocialFeed.togglePollEditor()" title="Anket">
                            <i class="fa-solid fa-square-poll-vertical" style="color:#f59e0b;"></i>
                        </button>
                        <button class="post-option-btn" onclick="SocialFeed.toggleGiftCardEditor()" title="Hediye Kartı (Coin Dağıt)">
                            <i class="fa-solid fa-gift" style="color:#ec4899;"></i>
                        </button>
                        <button class="post-option-btn ${mode === 'spoiler' ? 'active' : ''}" id="spoiler-toggle-btn" onclick="SocialFeed.toggleSpoilerOption()" title="Spoiler İşaretle">
                            <i class="fa-solid fa-eye-slash"></i>
                        </button>
                    </div>
                    <button class="post-submit-btn" onclick="SocialFeed.submitPost()">
                        <i class="fa-solid fa-paper-plane"></i> Paylaş
                    </button>
                </div>

            </div>
        `;

        document.body.appendChild(overlay);

        // Focus textarea
        setTimeout(() => {
            const textarea = document.getElementById('create-post-text');
            if (textarea) {
                textarea.focus();
                SocialFeed.attachAutocomplete(textarea);
            }
        }, 200);

        // Set spoiler active by default if mode is spoiler
        this._selectedMedia = null;
    },

    openSeriesSelector() {
        const existing = document.getElementById('series-selector-container');
        if (existing) { existing.remove(); return; }

        const area = document.getElementById('media-preview-area');
        if (!area) return;

        area.insertAdjacentHTML('afterend', `
            <div id="series-selector-container" style="margin-top:14px; padding:14px; background:rgba(124,58,237,0.05); border-radius:14px; border:1px solid rgba(124,58,237,0.2); animation: slideDown 0.3s ease;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                    <span style="color:#a78bfa; font-weight:700; font-size:0.85rem;"><i class="fa-solid fa-magnifying-glass"></i> Dizi/Film Seç</span>
                    <button onclick="document.getElementById('series-selector-container').remove()" style="background:none; border:none; color:#64748b; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
                </div>
                <input type="text" id="series-search-input" placeholder="Dizi adı yazın..." 
                       onkeyup="SocialFeed.searchSeriesForTag(this.value)"
                       style="width:100%; padding:10px 14px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff; outline:none; font-family:'Inter',sans-serif; margin-bottom:10px;">
                <div id="series-search-results" style="max-height:200px; overflow-y:auto; display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <!-- Results -->
                </div>
            </div>
        `);

        document.getElementById('series-search-input').focus();
    },

    searchSeriesForTag(query) {
        const resultsArea = document.getElementById('series-search-results');
        if (!query || query.length < 2) {
            resultsArea.innerHTML = '';
            return;
        }

        const matches = State.data.series.filter(s => 
            s.title.toLowerCase().includes(query.toLowerCase())
        ).slice(0, 6);

        resultsArea.innerHTML = matches.map(s => `
            <div onclick="SocialFeed.selectSeriesForTag('${s.id}', '${s.title.replace(/'/g, "\\'")}', '${s.poster || s.coverImage}')" 
                 style="display:flex; align-items:center; gap:10px; padding:8px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); border-radius:10px; cursor:pointer; transition:all 0.2s;"
                 onmouseover="this.style.background='rgba(255,255,255,0.08)'" onmouseout="this.style.background='rgba(255,255,255,0.03)'">
                <img src="${(s.poster || s.coverImage || '').startsWith('/') ? (s.poster || s.coverImage) : '/' + (s.poster || s.coverImage)}" style="width:30px; height:43px; border-radius:4px; object-fit:cover; border:1px solid rgba(255,255,255,0.1);" onerror="this.src='/assets/logo.png'">
                <div style="font-size:0.75rem; color:#fff; font-weight:600; line-height:1.2; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">${s.title}</div>
            </div>
        `).join('');
    },

    selectSeriesForTag(id, title, poster) {
        this.shareData = {
            id: id,
            title: title,
            poster: poster,
            type: 'review'
        };
        
        // Remove selector
        document.getElementById('series-selector-container')?.remove();
        
        // Update Modal Preview
        this.updateCreatePostPreview();
    },

    updateCreatePostPreview() {
        const overlay = document.getElementById('create-post-overlay');
        if (!overlay) return;

        // Find or create preview container
        let previewArea = overlay.querySelector('.shared-content-preview-container');
        if (!previewArea) {
            const textarea = document.getElementById('create-post-text');
            previewArea = document.createElement('div');
            previewArea.className = 'shared-content-preview-container';
            textarea.insertAdjacentElement('afterend', previewArea);
        }

        if (this.shareData) {
            const sd = this.shareData;
            const posterUrl = sd.poster ? (sd.poster.startsWith('/') || sd.poster.startsWith('http') || sd.poster.startsWith('data:') ? sd.poster : '/' + sd.poster) : 'assets/poster-placeholder.jpg';
            previewArea.innerHTML = `
                <div class="shared-content-card" style="position:relative; margin-top: 15px; background: rgba(255,255,255,0.03); border-radius: 14px; padding: 12px; display: flex; gap: 15px; border: 1px solid rgba(255,255,255,0.08);">
                    <button onclick="SocialFeed.removeSharedContent()" style="position:absolute; top:-8px; right:-8px; width:24px; height:24px; border-radius:50%; background:#ef4444; border:none; color:#fff; cursor:pointer; box-shadow: 0 2px 8px rgba(239,68,68,0.4);"><i class="fa-solid fa-xmark" style="font-size:12px;"></i></button>
                    <img src="${posterUrl}" alt="${sd.title}" style="width: 60px; height: 85px; border-radius: 10px; object-fit: cover;">
                    <div class="shared-info" style="display: flex; flex-direction: column; justify-content: center;">
                        <span class="badge badge-accent" style="width:fit-content; margin-bottom:6px; font-size: 0.6rem;">PAYLAŞILAN İÇERİK</span>
                        <h4 style="margin:0; font-size:1rem; color:#fff; font-weight: 700;">${this.escapeHtml(sd.title)}</h4>
                        <p style="margin:4px 0 0; font-size:0.8rem; color:#94a3b8;">${sd.type === 'review' ? 'İnceleme paylaşılıyor...' : 'İçerik paylaşılıyor...'}</p>
                    </div>
                </div>`;
        } else {
            previewArea.innerHTML = '';
        }
    },

    removeSharedContent() {
        this.shareData = null;
        this.updateCreatePostPreview();
    },

    toggleSpoilerOption() {
        this._spoilerActive = !this._spoilerActive;
        const btn = document.getElementById('spoiler-toggle-btn');
        if (btn) btn.classList.toggle('active', this._spoilerActive);
    },

    toggleGiftCardEditor() {
        const existing = document.getElementById('gift-editor');
        if (existing) { existing.remove(); return; }
        const area = document.getElementById('media-preview-area');
        if (!area) return;
        area.insertAdjacentHTML('afterend', `
            <div id="gift-editor" style="margin-top:14px; padding:16px; background:linear-gradient(135deg,rgba(236,72,153,0.1),rgba(124,58,237,0.1)); border-radius:14px; border:1px solid rgba(236,72,153,0.3);">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:12px;">
                    <div style="background:#ec4899; width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center; box-shadow:0 0 15px rgba(236,72,153,0.5);">
                        <i class="fa-solid fa-gift" style="color:white; font-size:1.1rem;"></i>
                    </div>
                    <div>
                        <div style="color:white; font-weight:700; font-size:1rem;">Hediye Zarfları Dağıt</div>
                        <div style="color:#a78bfa; font-size:0.8rem;">Takipçilerinize DramiCoin hediye edin. İlk tıklayanlar kapar!</div>
                    </div>
                </div>
                <div style="display:flex; gap:10px;">
                    <div style="flex:1;">
                        <label style="color:#e2e8f0; font-size:0.85rem; font-weight:600; display:block; margin-bottom:6px;">Toplam Dağıtılacak Coin</label>
                        <input type="number" id="gift-total-coins" placeholder="Örn: 100" min="1" max="10000" style="width:100%; padding:10px 14px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff; font-weight:700; outline:none; font-family:'Inter',sans-serif;">
                    </div>
                    <div style="flex:1;">
                        <label style="color:#e2e8f0; font-size:0.85rem; font-weight:600; display:block; margin-bottom:6px;">Kişi (Zarf) Sayısı</label>
                        <input type="number" id="gift-claims" placeholder="Örn: 5" min="1" max="100" style="width:100%; padding:10px 14px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:10px; color:#fff; font-weight:700; outline:none; font-family:'Inter',sans-serif;">
                    </div>
                </div>
            </div>
        `);
    },

    toggleGiftCardEditorInModal() {
        this.openCreatePostModal();
        setTimeout(() => {
            this.toggleGiftCardEditor();
        }, 400);
    },

    togglePollEditor() {
        const existing = document.getElementById('poll-editor');
        if (existing) {
            existing.remove();
            return;
        }
        const area = document.getElementById('media-preview-area');
        if (!area) return;
        area.insertAdjacentHTML('afterend', `
            <div id="poll-editor" style="margin-top:14px; padding:14px; background:rgba(255,255,255,0.02); border-radius:14px; border:1px solid rgba(255,255,255,0.06);">
                <input type="text" id="poll-question" placeholder="Anket sorusu..." 
                       style="width:100%; background:transparent; border:none; color:#fff; font-size:1rem; font-weight:700; margin-bottom:12px; outline:none; font-family:'Inter',sans-serif;">
                <div id="poll-options-list">
                    <input type="text" class="poll-option-input" placeholder="Seçenek 1" style="width:100%; padding:10px 14px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#e2e8f0; margin-bottom:8px; outline:none; font-family:'Inter',sans-serif;">
                    <input type="text" class="poll-option-input" placeholder="Seçenek 2" style="width:100%; padding:10px 14px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#e2e8f0; margin-bottom:8px; outline:none; font-family:'Inter',sans-serif;">
                </div>
                <button onclick="SocialFeed.addPollOption()" style="background:none; border:1px dashed rgba(255,255,255,0.1); color:#64748b; width:100%; padding:10px; border-radius:10px; cursor:pointer; font-family:'Inter',sans-serif; margin-top:4px;">
                    <i class="fa-solid fa-plus"></i> Seçenek Ekle
                </button>
            </div>
        `);
    },

    addPollOption() {
        const list = document.getElementById('poll-options-list');
        if (!list) return;
        const count = list.querySelectorAll('.poll-option-input').length;
        if (count >= 6) { Toast.warning('Maksimum 6 seçenek eklenebilir.'); return; }
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'poll-option-input';
        input.placeholder = `Seçenek ${count + 1}`;
        input.style.cssText = 'width:100%; padding:10px 14px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#e2e8f0; margin-bottom:8px; outline:none; font-family:\'Inter\',sans-serif;';
        list.appendChild(input);
    },

    async handleMediaUpload(input) {
        const file = input.files[0];
        if (!file) return;

        // Create overlay if not exists
        let progressOverlay = document.getElementById('upload-progress-overlay');
        if (!progressOverlay) {
            progressOverlay = document.createElement('div');
            progressOverlay.id = 'upload-progress-overlay';
            progressOverlay.style.cssText = `
                position:fixed; inset:0; background:rgba(0,0,0,0.85); backdrop-filter:blur(10px); 
                z-index:100000; display:flex; align-items:center; justify-content:center;
                animation:fadeIn 0.3s ease;
            `;
            progressOverlay.innerHTML = `
                <div style="width:90%; max-width:400px; text-align:center; background:#111116; padding:40px; border-radius:32px; border:1px solid rgba(255,255,255,0.1); box-shadow:0 40px 100px rgba(0,0,0,0.8);">
                    <div id="upload-icon-box" style="width:80px; height:80px; background:rgba(59,130,246,0.1); border-radius:24px; display:flex; align-items:center; justify-content:center; margin:0 auto 24px;">
                        <i class="fa-solid fa-cloud-arrow-up" style="font-size:2rem; color:#3b82f6;"></i>
                    </div>
                    <h3 style="color:#fff; font-size:1.4rem; font-weight:800; margin-bottom:8px;">İşleniyor...</h3>
                    <p id="upload-status-text" style="color:#94a3b8; font-size:0.9rem; margin-bottom:32px;">Medya yerel olarak hazırlanıyor</p>
                    
                    <div style="position:relative; width:100%; height:12px; background:rgba(255,255,255,0.05); border-radius:100px; overflow:hidden; margin-bottom:16px;">
                        <div id="upload-progress-bar" style="position:absolute; inset:0; width:0%; background:linear-gradient(90deg, #3b82f6, #8b5cf6); transition:width 0.3s ease; border-radius:100px;"></div>
                    </div>
                    
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span id="upload-percentage" style="color:#fff; font-weight:800; font-size:1.1rem; font-family:'Outfit', sans-serif;">0%</span>
                        <span id="upload-size" style="color:#64748b; font-size:0.8rem; font-weight:600;">0 / 0 MB</span>
                    </div>
                </div>
            `;
            document.body.appendChild(progressOverlay);
        }

        const bar = document.getElementById('upload-progress-bar');
        const percentText = document.getElementById('upload-percentage');
        const sizeText = document.getElementById('upload-size');
        const totalSize = (file.size / (1024 * 1024)).toFixed(1);

        // Simulate local processing and SAVE to MediaDB
        let progress = 0;
        const interval = setInterval(async () => {
            progress += 5 + Math.random() * 15;
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                
                try {
                    const isVideo = file.type.startsWith('video');
                    // PERSISTENT SAVE to IndexedDB
                    const id = await MediaDB.saveMedia(file);
                    const persistentUrl = 'media-idb:' + id;
                    
                    // Also get a temporary preview URL
                    const previewUrl = URL.createObjectURL(file);
                    
                    this._selectedMedia = { url: persistentUrl, type: isVideo ? 'video' : 'image' };
                    
                    if (progressOverlay) progressOverlay.remove();
                    
                    const area = document.getElementById('media-preview-area');
                    if (area) {
                        if (isVideo) {
                            area.innerHTML = `<div style="position:relative; margin-top:12px;"><video src="${previewUrl}" controls style="width:100%; border-radius:20px; max-height:350px; background:#000; box-shadow:0 10px 30px rgba(0,0,0,0.3);"></video><button onclick="SocialFeed.removeMedia()" style="position:absolute; top:12px; right:12px; background:rgba(0,0,0,0.6); backdrop-filter:blur(4px); border:1px solid rgba(255,255,255,0.1); color:white; border-radius:50%; width:32px; height:32px; cursor:pointer; transition:all 0.2s; display:flex; align-items:center; justify-content:center;" onmouseenter="this.style.background='#ef4444'"><i class="fa-solid fa-xmark"></i></button></div>`;
                        } else {
                            area.innerHTML = `<div style="position:relative; margin-top:12px;"><img src="${previewUrl}" style="width:100%; border-radius:20px; max-height:450px; object-fit:cover; box-shadow:0 10px 30px rgba(0,0,0,0.3);"><button onclick="SocialFeed.removeMedia()" style="position:absolute; top:12px; right:12px; background:rgba(0,0,0,0.6); backdrop-filter:blur(4px); border:1px solid rgba(255,255,255,0.1); color:white; border-radius:50%; width:32px; height:32px; cursor:pointer; transition:all 0.2s; display:flex; align-items:center; justify-content:center;" onmouseenter="this.style.background='#ef4444'"><i class="fa-solid fa-xmark"></i></button></div>`;
                        }
                    }
                    Toast.success('Medya başarıyla kaydedildi! ✨');
                } catch (err) {
                    console.error('Media save error:', err);
                    Toast.error('Medya kaydedilemedi.');
                    if (progressOverlay) progressOverlay.remove();
                }
            }
            
            if (bar) bar.style.width = progress + '%';
            if (percentText) percentText.innerText = Math.round(progress) + '%';
            if (sizeText) {
                const loadedSize = ((progress / 100) * totalSize).toFixed(1);
                sizeText.innerText = `${loadedSize} / ${totalSize} MB`;
            }
        }, 100);
    },

    removeMedia() {
        this._selectedMedia = null;
        const area = document.getElementById('media-preview-area');
        if (area) area.innerHTML = '';
        // Also clear file input
        const input = document.getElementById('media-file-input');
        if (input) input.value = '';
    },

    async submitPost() {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Paylaşım yapmak için giriş yapmalısınız.');
            if (window.Auth) Auth.showLogin();
            return;
        }

        const text = document.getElementById('create-post-text')?.value?.trim();
        const hasPoll = !!document.getElementById('poll-editor');
        const hasGift = !!document.getElementById('gift-editor');
        const hasMedia = !!this._selectedMedia;
        const hasShared = !!this.shareData;

        if (!text && !hasPoll && !hasGift && !hasMedia && !hasShared) {
            Toast.warning('Lütfen bir şeyler yazın veya ekleyin.');
            return;
        }

        if (this.checkSocialBan()) return;

        // AUTO-MODERATION CHECK
        if (text) {
            const modCheck = this.moderateContent(text);
            if (!modCheck.clean) {
                this.handleViolation(modCheck.warnings);
                return;
            }
        }

        const isBlog = this.currentTab === 'blog';
        const post = {
            text: text || '',
            isSpoiler: this._spoilerActive || false,
            isBlog: isBlog
        };

        if (isBlog) {
            post.title = document.getElementById('blog-title-input')?.value || 'Başlıksız Blog';
            post.category = this._blogCategory !== 'pending' ? this._blogCategory : 'Genel';
        }

        // Media
        if (this._selectedMedia) {
            post.mediaUrl = this._selectedMedia.url;
            post.mediaType = this._selectedMedia.type;
        }

        // Shared content
        if (this.shareData) {
            post.sharedContent = this.shareData;
            // Link to review if type is review
            if (this.shareData.type === 'review') {
                post.isReview = true;
            }
            this.shareData = null; // clear
        }

        // Poll
        if (hasPoll) {
            const question = document.getElementById('poll-question')?.value?.trim();
            const optInputs = document.querySelectorAll('.poll-option-input');
            const options = [];
            optInputs.forEach(inp => {
                const val = inp.value.trim();
                if (val) options.push({ text: val, votes: 0 });
            });
            if (question && options.length >= 2) {
                post.poll = { question, options, voters: [] };
            }
        }

        // Gift Card
        if (hasGift) {
            const totalCoins = parseInt(document.getElementById('gift-total-coins')?.value || 0);
            const claimsCount = parseInt(document.getElementById('gift-claims')?.value || 0);

            if (totalCoins > 0 && claimsCount > 0) {
                const userCoins = State.currentUser.stats?.coins || 0;
                if (userCoins < totalCoins) {
                    Toast.error(`Yetersiz bakiye! Mevcut DramiCoin: ${userCoins}`);
                    return;
                }
                
                State.currentUser.stats.coins = userCoins - totalCoins;
                sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
                if (window.db?.updateUser) db.updateUser(State.currentUser.id, State.currentUser);
                db.save('users');
                
                post.giftCard = {
                    totalAmount: totalCoins,
                    maxClaims: claimsCount,
                    claimedBy: []
                };
            } else {
                Toast.error('Lütfen geçerli bir coin miktarı ve kişi sayısı girin.');
                return;
            }
        }

        // Extract hashtags & mentions
        const hashtags = (text || '').match(/#[a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+/g) || [];
        post.hashtags = hashtags.map(h => h.toLowerCase());
        const mentions = (text || '').match(/@[a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+/g) || [];
        post.mentions = mentions.map(m => m.slice(1));

        Toast.info('Paylaşılıyor...');
        
        // Direct localStorage save (no backend API)
        const newPost = {
            ...post,
            id: 'post_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
            userId: State.currentUser.id,
            username: State.currentUser.username,
            createdAt: new Date().toISOString(),
            likes: [],
            comments: [],
            reactions: {}
        };
        
        if (!State.data.socialPosts) State.data.socialPosts = [];
        
        // Use syncItem for cloud persistence
        const syncResult = await db.syncItem('socialPosts', newPost);
        
        if (syncResult && syncResult.success === false && syncResult.message) {
            Toast.error(syncResult.message);
            // Revert local changes
            State.data.socialPosts = State.data.socialPosts.filter(p => p.id !== newPost.id);
            localStorage.setItem(db.STORAGE_KEY, JSON.stringify(State.data));
            return;
        }

        if (syncResult && syncResult.success && !syncResult.localOnly) {
            Toast.success('Paylaşımın yayında! ☁️');
        } else {
            Toast.success('Paylaşımın yayınlandı! 🎉');
        }

        // Broadcast to other tabs
        if (window.db && db.broadcastUpdate) {
            db.broadcastUpdate('collection_update', 'socialPosts', State.data.socialPosts);
        }

        document.getElementById('create-post-overlay')?.remove();
        this.render();
        
        // Gamification
        if (typeof Gamification !== 'undefined') Gamification.addXP(10, 'Sosyal Paylaşım');
        if (typeof DailyQuests !== 'undefined') DailyQuests.updateProgress('post_1');

    },

    // ==================== INTERACTIONS ====================
    async toggleLike(postId) {
        if (!State.currentUser || State.currentUser.role === 'guest') { 
            Toast.warning('Beğenmek için üye olmalısınız.'); 
            if (window.Auth) Auth.showLogin();
            return; 
        }
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;
        if (!post.likes) post.likes = [];

        const idx = post.likes.indexOf(State.currentUser.id);
        const isLiked = idx === -1;

        if (isLiked) post.likes.push(State.currentUser.id);
        else post.likes.splice(idx, 1);

        this.updateLikeUI(postId, isLiked, post.likes.length);
        
        // Sync to cloud
        db.syncAction('social-toggle-like', { postId: postId });

        // Broadcast to other tabs
        if (window.db && db.broadcastUpdate) {
            db.broadcastUpdate('collection_update', 'socialPosts', State.data.socialPosts);
        }
    },

    updateLikeUI(postId, isLiked, count) {
        const btns = document.querySelectorAll(`button[onclick*="toggleLike('${postId}')"]`);
        btns.forEach(btn => {
            btn.classList.toggle('liked', isLiked);
            const icon = btn.querySelector('i');
            if (icon) {
                icon.className = isLiked ? 'fa-solid fa-heart' : 'fa-regular fa-heart';
            }
            btn.innerHTML = `<i class="${isLiked ? 'fa-solid fa-heart' : 'fa-regular fa-heart'}"></i> ${count || ''}`;
        });
    },

    toggleComments(postId) {
        const section = document.getElementById(`comments-section-${postId}`);
        if (section) {
            const isHidden = section.style.display === 'none';
            section.style.display = isHidden ? 'block' : 'none';

            // Render comments if showing
            if (isHidden) {
                const post = this.posts.find(p => p.id === postId);
                if (post) {
                    section.innerHTML = this.renderCommentsSection(post);
                }
            }
        }
    },

    renderCommentsSection(post) {
        if (!post.comments) post.comments = [];
        
        // Group by parentId
        const roots = post.comments.filter(c => !c.parentId);
        const replies = post.comments.filter(c => c.parentId);

        let html = `<div class="post-comments-section">`;
        
        const renderComment = (c, depth = 0) => {
            const cu = State.data.users?.find(u => u.id === c.userId);
            const childReplies = replies.filter(r => r.parentId === c.id);
            
            let cHtml = `
                <div class="post-comment" style="margin-left: ${depth * 30}px; border-left: ${depth > 0 ? '2px solid rgba(255,255,255,0.05)' : 'none'}; padding-left: ${depth > 0 ? '15px' : '0'};">
                    <img src="${cu?.avatar || 'assets/logo.png'}" alt="" style="width: ${depth > 0 ? '28px' : '34px'}; height: ${depth > 0 ? '28px' : '34px'};">
                    <div class="comment-body">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span class="comment-user">${cu?.username || 'Kullanıcı'}</span>
                            <span style="font-size:0.7rem; color:#64748b;">${this.timeAgo(c.createdAt)}</span>
                        </div>
                        <span class="comment-text">${this.escapeHtml(c.text)}</span>
                        <div class="comment-actions" style="margin-top:5px; display:flex; gap:15px;">
                            <button onclick="SocialFeed.showReplyInput('${post.id}', '${c.id}', '${cu?.username}')" style="background:none; border:none; color:#a78bfa; font-size:0.75rem; font-weight:700; cursor:pointer; padding:0;">Yanıtla</button>
                        </div>
                        <div id="reply-input-container-${c.id}"></div>
                    </div>
                </div>`;

            childReplies.forEach(cr => {
                cHtml += renderComment(cr, depth + 1);
            });

            return cHtml;
        };

        roots.forEach(r => {
            html += renderComment(r);
        });

        if (State.currentUser && State.currentUser.role !== 'guest') {
            html += `
                <div class="post-comment-input-wrapper" id="main-comment-input-${post.id}">
                    <input type="text" id="comment-input-${post.id}" placeholder="Yorum yaz..."
                           onkeypress="if(event.key==='Enter') SocialFeed.addComment('${post.id}', this.value)">
                    <button onclick="SocialFeed.addComment('${post.id}', document.getElementById('comment-input-${post.id}').value)">
                        <i class="fa-solid fa-paper-plane"></i>
                    </button>
                </div>`;
        }
        html += '</div>';
        return html;
    },

    showReplyInput(postId, parentId, username) {
        const container = document.getElementById(`reply-input-container-${parentId}`);
        if (!container) return;

        if (container.innerHTML) {
            container.innerHTML = '';
            return;
        }

        container.innerHTML = `
            <div class="post-comment-input-wrapper reply-input" style="margin-top:10px; background:rgba(255,255,255,0.03);">
                <input type="text" id="reply-input-${parentId}" placeholder="${username} kullanıcısına yanıt ver..."
                       onkeypress="if(event.key==='Enter') SocialFeed.addComment('${postId}', this.value, '${parentId}')">
                <button onclick="SocialFeed.addComment('${postId}', document.getElementById('reply-input-${parentId}').value, '${parentId}')">
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>`;
        
        const input = document.getElementById(`reply-input-${parentId}`);
        if (input) input.focus();
    },

    async addComment(postId, text, parentId = null) {
        if (!text?.trim()) return;
        if (!State.currentUser || State.currentUser.role === 'guest') { 
            Toast.warning('Yorum yapmak için üye olmalısınız.'); 
            if (window.Auth) Auth.showLogin();
            return; 
        }
        
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;

        if (this.checkSocialBan()) return;

        // AUTO-MODERATION for comments
        const modCheck = this.moderateContent(text.trim());
        if (!modCheck.clean) {
            this.handleViolation(modCheck.warnings);
            return;
        }

        try {
            const comment = {
                id: 'com_' + Date.now(),
                userId: State.currentUser.id,
                username: State.currentUser.username,
                text: text.trim(),
                parentId: parentId,
                createdAt: new Date().toISOString(),
                likes: []
            };

            if (!post.comments) post.comments = [];
            post.comments.push(comment);
            
            // Sync to cloud
            await db.syncAction('social-add-comment', { postId, text: text.trim(), parentId });

            // Broadcast to other tabs
            if (window.db && db.broadcastUpdate) {
                db.broadcastUpdate('collection_update', 'socialPosts', State.data.socialPosts);
            }
            
            Toast.success('Yorum eklendi! 💬');
            
            // Re-render comments section
            const section = document.getElementById(`comments-section-${postId}`);
            if (section) section.innerHTML = this.renderCommentsSection(post);
            
            // Clear inputs
            const mainInput = document.getElementById(`comment-input-${postId}`);
            if (mainInput) mainInput.value = '';
        } catch (e) {
            console.error('Comment save error:', e);
            Toast.error('Yorum kaydedilirken hata oluştu.');
        }
    },

    votePoll(postId, optionIndex) {
        if (!State.currentUser || State.currentUser.role === 'guest') { 
            Toast.warning('Oy kullanmak için üye olmalısınız.'); 
            if (window.Auth) Auth.showLogin();
            return; 
        }
        const post = this.posts.find(p => p.id === postId);
        if (!post?.poll) return;
        if (post.poll.voters?.includes(State.currentUser.id)) {
            Toast.info('Zaten oy kullandınız.');
            return;
        }
        post.poll.options[optionIndex].votes = (post.poll.options[optionIndex].votes || 0) + 1;
        if (!post.poll.voters) post.poll.voters = [];
        post.poll.voters.push(State.currentUser.id);
        db.saveDebounced();
    },

    renderGiftCard(post) {
        if (!post.giftCard) return '';
        const gc = post.giftCard;
        const total = gc.totalAmount || 0;
        const max = gc.maxClaims || 1;
        const claims = gc.claimedBy || [];
        const isClaimed = State.currentUser && claims.some(c => c.userId === State.currentUser.id);
        const isDepleted = claims.length >= max;
        
        let statusHtml = '';
        if (isClaimed) {
            const myClaim = claims.find(c => c.userId === State.currentUser.id);
            statusHtml = `<div style="margin-top:10px; padding:10px; background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.3); border-radius:10px; color:#10b981; font-weight:700; text-align:center;"><i class="fa-solid fa-check-circle"></i> ${myClaim.amount} Coin Kazandın!</div>`;
        } else if (isDepleted) {
            statusHtml = `<div style="margin-top:10px; padding:10px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.3); border-radius:10px; color:#ef4444; font-weight:700; text-align:center;"><i class="fa-solid fa-face-frown"></i> Zarflar Tükendi</div>`;
        } else {
            statusHtml = `<button onclick="SocialFeed.claimGiftCard('${post.id}')" style="margin-top:10px; width:100%; padding:12px; background:linear-gradient(135deg,#ec4899,#8b5cf6); border:none; border-radius:10px; color:white; font-weight:800; font-size:1.1rem; cursor:pointer; box-shadow:0 4px 15px rgba(236,72,153,0.3); transition:transform 0.2s;" onmouseover="this.style.transform='scale(1.02)'" onmouseout="this.style.transform='scale(1)'"><i class="fa-solid fa-hand-sparkles"></i> Hediyeyi Kap!</button>`;
        }
        
        let claimsListHtml = '';
        if (claims.length > 0) {
            claimsListHtml = `<div style="margin-top:12px; border-top:1px solid rgba(255,255,255,0.1); padding-top:10px;">
                <div style="font-size:0.8rem; color:#a78bfa; margin-bottom:8px; font-weight:600;">Kapanlar (${claims.length}/${max})</div>
                <div style="display:flex; flex-wrap:wrap; gap:6px;">
                    ${claims.map(c => {
                        const u = State.data.users?.find(x => x.id === c.userId);
                        return `<img src="${u?.avatar || 'assets/logo.png'}" title="${u?.username || 'Biri'} (+${c.amount})" style="width:24px; height:24px; border-radius:50%; border:1px solid #ec4899; object-fit:cover;">`;
                    }).join('')}
                </div>
            </div>`;
        }

        return `
            <div class="gift-card-container" style="margin-top:14px; padding:18px; background:linear-gradient(135deg,rgba(236,72,153,0.05),rgba(124,58,237,0.05)); border-radius:16px; border:1px solid rgba(236,72,153,0.2); position:relative; overflow:hidden;">
                <div style="position:absolute; top:-20px; right:-20px; font-size:100px; opacity:0.05; transform:rotate(15deg);"><i class="fa-solid fa-gift"></i></div>
                <div style="display:flex; align-items:center; gap:14px; position:relative; z-index:1;">
                    <div style="width:50px; height:50px; background:linear-gradient(135deg,#ec4899,#8b5cf6); border-radius:14px; display:flex; align-items:center; justify-content:center; box-shadow:0 8px 20px rgba(236,72,153,0.4);">
                        <i class="fa-solid fa-envelope-open-text" style="color:white; font-size:1.5rem;"></i>
                    </div>
                    <div>
                        <div style="color:white; font-weight:800; font-size:1.2rem;">Hediye Zarfı</div>
                        <div style="color:#e2e8f0; font-size:0.9rem;">Toplam ${total} Coin · ${max} Kişiye</div>
                    </div>
                </div>
                <div style="position:relative; z-index:1;">
                    ${statusHtml}
                    ${claimsListHtml}
                </div>
            </div>`;
    },

    claimGiftCard(postId) {
        if (!State.currentUser || State.currentUser.role === 'guest') { 
            Toast.warning('Hediye kapmak için üye olmalısınız.'); 
            if (window.Auth) Auth.showLogin();
            return; 
        }
        const post = this.posts.find(p => p.id === postId);
        if (!post?.giftCard) return;
        
        const gc = post.giftCard;
        if (!gc.claimedBy) gc.claimedBy = [];
        
        if (gc.claimedBy.length >= gc.maxClaims) {
            Toast.error('Maalesef zarflar tükendi.');
            this.render(); return;
        }
        
        if (gc.claimedBy.some(c => c.userId === State.currentUser.id)) {
            Toast.info('Zaten bir zarf kaptınız!');
            return;
        }
        
        const amount = Math.floor(gc.totalAmount / gc.maxClaims);
        
        gc.claimedBy.push({
            userId: State.currentUser.id,
            amount: amount,
            timestamp: new Date().toISOString()
        });
        
        if (!State.currentUser.stats) State.currentUser.stats = { coins: 0 };
        State.currentUser.stats.coins = (State.currentUser.stats.coins || 0) + amount;
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        if (window.db?.updateUser) db.updateUser(State.currentUser.id, State.currentUser);
        
        db.save('socialPosts');
        
        Toast.success(`Tebrikler! ${amount} DramiCoin kaptınız! 🎁`);
        
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        db.save(['socialPosts', 'users']);
        this.render();
    },

    revealSpoiler(postId) {
        const el = document.getElementById(`spoiler-${postId}`);
        if (el) el.classList.add('revealed');
    },

    sharePost(postId) {
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;
        const url = window.location.origin + '/#/social?post=' + postId;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(url);
            Toast.success('Bağlantı kopyalandı!');
        } else {
            Toast.info(url);
        }
    },

    postMenu(postId) {
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;
        const isOwner = post.userId === State.currentUser?.id;
        const isAdmin = State.currentUser?.role === 'admin' || State.currentUser?.badges?.includes('Admin');
        const isMod = this.isModerator(State.currentUser);

        // Remove existing menu if any
        const existing = document.getElementById('social-post-menu');
        if (existing) existing.remove();

        const menuOverlay = document.createElement('div');
        menuOverlay.id = 'social-post-menu';
        menuOverlay.className = 'social-menu-overlay';
        menuOverlay.style.cssText = `
            position: fixed; inset: 0; background: rgba(0,0,0,0.4); 
            backdrop-filter: blur(4px); z-index: 10000; 
            display: flex; align-items: center; justify-content: center;
            animation: fadeIn 0.2s ease;
        `;
        menuOverlay.onclick = (e) => { if (e.target === menuOverlay) menuOverlay.remove(); };

        let menuHtml = `
            <div class="glass-card" style="width: 280px; padding: 10px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 20px 40px rgba(0,0,0,0.4); animation: scaleUp 0.2s ease;">
                <div style="padding: 10px 15px; border-bottom: 1px solid rgba(255,255,255,0.05); margin-bottom: 5px;">
                    <span style="font-size: 0.8rem; color: #64748b; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">İşlemler</span>
                </div>
        `;

        if (isOwner) {
            menuHtml += `
                <div class="social-menu-item" onclick="SocialFeed.togglePin('${postId}'); document.getElementById('social-post-menu').remove();">
                    <i class="fa-solid fa-thumbtack"></i> ${post.isPinned ? 'Sabitlemeyi Kaldır' : 'Paylaşımı Sabitle'}
                </div>
                <div class="social-menu-item danger" onclick="SocialFeed.deletePost('${postId}'); document.getElementById('social-post-menu').remove();">
                    <i class="fa-solid fa-trash-can"></i> Paylaşımı Sil
                </div>
            `;
        } else if (isAdmin || isMod) {
            menuHtml += `
                <div class="social-menu-item danger" onclick="SocialFeed.deletePost('${postId}'); document.getElementById('social-post-menu').remove();">
                    <i class="fa-solid fa-trash-can"></i> Paylaşımı Sil (Mod)
                </div>
                <div class="social-menu-item" onclick="JournalService.addToDraft('${post.mediaUrl ? 'fanArt' : 'review'}', '${post.id}'); document.getElementById('social-post-menu').remove();" style="color: gold;">
                    <i class="fa-solid fa-book-open" style="color: gold;"></i> Dergiye Ekle
                </div>
                <div class="social-menu-item" onclick="SocialFeed.sendSocialNotification('${post.userId}', '⚠️ Moderatör Uyarısı', 'Paylaşımınız topluluk kurallarına aykırı bulundu.', 'warning'); document.getElementById('social-post-menu').remove();">
                    <i class="fa-solid fa-triangle-exclamation"></i> Kullanıcıyı Uyar
                </div>
                <div class="social-menu-item danger" onclick="SocialFeed.blockUser('${post.userId}'); document.getElementById('social-post-menu').remove();">
                    <i class="fa-solid fa-user-slash"></i> Kullanıcıyı Engelle
                </div>
            `;
        } else {
            menuHtml += `
                <div class="social-menu-item danger" onclick="SocialFeed.blockUser('${post.userId}'); document.getElementById('social-post-menu').remove();">
                    <i class="fa-solid fa-user-slash"></i> Kullanıcıyı Engelle
                </div>
                <div class="social-menu-item" onclick="Toast.info('Raporunuz alındı.'); document.getElementById('social-post-menu').remove();">
                    <i class="fa-solid fa-flag"></i> Paylaşımı Raporla
                </div>
            `;
        }

        menuHtml += `
                <div class="social-menu-item" onclick="document.getElementById('social-post-menu').remove();" style="border-top: 1px solid rgba(255,255,255,0.05); margin-top: 5px; color: #64748b;">
                    <i class="fa-solid fa-xmark"></i> Vazgeç
                </div>
            </div>
            <style>
                .social-menu-item {
                    display: flex; align-items: center; gap: 12px; padding: 12px 15px;
                    border-radius: 12px; cursor: pointer; color: #e2e8f0;
                    font-size: 0.9rem; font-weight: 600; transition: all 0.2s;
                }
                .social-menu-item i { width: 20px; text-align: center; font-size: 1rem; color: #8b5cf6; }
                .social-menu-item:hover { background: rgba(255,255,255,0.05); }
                .social-menu-item.danger { color: #f87171 }
                .social-menu-item.danger i { color: #f87171; }
                .social-menu-item.danger:hover { background: rgba(248,113,113,0.1); }
                
                @keyframes scaleUp {
                    from { transform: scale(0.95); opacity: 0; }
                    to { transform: scale(1); opacity: 1; }
                }
            </style>
        `;

        menuOverlay.innerHTML = menuHtml;
        document.body.appendChild(menuOverlay);
    },

    watchStream(liveId) {
        const stream = State.data.liveStreams?.find(s => s.id === liveId);
        if (!stream || stream.status !== 'live') {
            Toast.error('Bu yayın sona ermiş.');
            return;
        }
        App.router('studio', `${stream.seriesId}/${stream.epNum}`);
    },

    async deletePost(postId) {
        if (!confirm('Bu paylaşımı silmek istediğinize emin misiniz?')) return;
        
        Toast.info('Siliniyor...');
        
        const idx = this.posts.findIndex(p => p.id === postId);
        if (idx === -1) {
            Toast.error('Paylaşım bulunamadı.');
            return;
        }

        const post = this.posts[idx];

        try {
            const res = await fetch(`api/db.php?action=social-post-delete&postId=${encodeURIComponent(postId)}`, {
                method: 'POST',
                credentials: 'include'
            });
            const data = await res.json().catch(() => ({}));
            if (!data.success && data.message) {
                console.warn('API delete:', data.message);
            }
        } catch (e) {
            console.warn('API delete failed, continuing local delete:', e);
        }

        if (post.mediaUrl && post.mediaUrl.startsWith('media-idb:')) {
            const mediaId = post.mediaUrl.replace('media-idb:', '');
            try { await MediaDB.deleteMedia(mediaId); } catch (err) { /* ignore */ }
        }

        this.posts.splice(idx, 1);
        State.data.socialPosts = this.posts;
        await db.save('socialPosts');
        if (window.db?.syncItem) {
            await db.syncItem('socialPosts', { id: postId, _deleted: true }, 'delete');
        }
        Toast.success('Paylaşım kalıcı olarak silindi.');
        this.render();
    },

    promptMediaLink() {
        const url = prompt('Medya linki girin (görsel veya video URL):');
        if (!url || !url.trim()) return;
        const trimmed = url.trim();
        if (!/^https?:\/\//i.test(trimmed)) {
            Toast.error('Geçerli bir http/https linki girin.');
            return;
        }
        const isVideo = /\.(mp4|webm|mov)(\?|$)/i.test(trimmed) || trimmed.includes('youtube.com') || trimmed.includes('youtu.be');
        this._selectedMedia = { url: trimmed, type: isVideo ? 'video' : 'image' };
        const area = document.getElementById('media-preview-area');
        if (area) {
            if (isVideo) {
                area.innerHTML = `<div style="position:relative; margin-top:12px;"><video src="${trimmed}" controls style="width:100%; border-radius:20px; max-height:350px; background:#000;"></video><button onclick="SocialFeed.removeMedia()" style="position:absolute; top:12px; right:12px; background:rgba(0,0,0,0.6); color:white; border:none; border-radius:50%; width:32px; height:32px; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button></div>`;
            } else {
                area.innerHTML = `<div style="position:relative; margin-top:12px;"><img src="${trimmed}" style="width:100%; border-radius:20px; max-height:450px; object-fit:cover;" onerror="this.style.display='none'"><button onclick="SocialFeed.removeMedia()" style="position:absolute; top:12px; right:12px; background:rgba(0,0,0,0.6); color:white; border:none; border-radius:50%; width:32px; height:32px; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button></div>`;
            }
        }
        Toast.success('Medya linki eklendi.');
    },

    /**
     * Global Garbage Collection for Persistent Media
     * Scans all state data for media references and deletes orphans from IndexedDB
     */
    async runGlobalGC() {
        if (!window.MediaDB) return;
        console.log('🧹 [SocialFeed] Starting Global Storage Scan...');

        const activeIds = new Set();
        
        // 1. Social Posts
        (State.data.socialPosts || []).forEach(post => {
            if (post.mediaUrl && post.mediaUrl.startsWith('media-idb:')) {
                activeIds.add(post.mediaUrl.replace('media-idb:', ''));
            }
        });

        // 2. Stories
        (State.data.stories || []).forEach(story => {
            if (story.mediaUrl && story.mediaUrl.startsWith('media-idb:')) {
                activeIds.add(story.mediaUrl.replace('media-idb:', ''));
            }
        });

        // 3. User Profiles
        (State.data.users || []).forEach(user => {
            if (user.avatar && user.avatar.startsWith('media-idb:')) {
                activeIds.add(user.avatar.replace('media-idb:', ''));
            }
        });

        // 4. Activity Logs (some activities might have screenshots)
        (State.data.activities || []).forEach(act => {
            if (act.data && act.data.mediaUrl && act.data.mediaUrl.startsWith('media-idb:')) {
                activeIds.add(act.data.mediaUrl.replace('media-idb:', ''));
            }
        });

        await MediaDB.garbageCollect(Array.from(activeIds));
    },

    // ==================== FRIENDS TAB ====================
    renderFriendsTab() {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            return `
                <div class="social-empty-state" style="padding: 80px 20px;">
                    <div style="font-size: 3.5rem; margin-bottom: 25px; opacity: 0.8; filter: grayscale(1);">👥</div>
                    <h3 style="color: #fff; font-weight: 800; margin-bottom: 12px;">Arkadaşlar & Sosyal Çevre</h3>
                    <p style="color: #94a3b8; margin-bottom: 30px; max-width: 450px; margin-left: auto; margin-right: auto; line-height: 1.6;">Arkadaş edinmek, diğer üyeleri takip etmek ve topluluğun bir parçası olmak için giriş yapmalısın.</p>
                    <div style="display: flex; gap: 12px; justify-content: center;">
                        <button class="btn btn-primary" onclick="Auth.showLogin()" style="padding: 12px 32px; border-radius: 14px; font-weight: 800; box-shadow: 0 10px 20px rgba(124, 58, 237, 0.2);">Giriş Yap</button>
                    </div>
                </div>`;
        }

        const friends = State.currentUser.friends || [];
        const pending = State.currentUser.friendRequests || [];
        const followRequests = State.currentUser.followRequests || [];

        // Group friends by status
        const friendsData = friends
            .map(fid => State.data.users?.find(u => u.id === fid))
            .filter(u => u)
            .map(u => ({ ...u, presence: Social.getUserPresence(u) }));

        const onlineFriends = friendsData.filter(f => f.presence.status === 'online');
        const awayFriends = friendsData.filter(f => f.presence.status === 'idle' || f.presence.status === 'dnd');
        const offlineFriends = friendsData.filter(f => f.presence.status === 'offline' || f.presence.status === 'invisible');

        let html = `
            <div style="margin-bottom: 25px;">
                <div style="position: relative; margin-bottom: 25px;">
                    <i class="fa-solid fa-user-plus" style="position: absolute; left: 14px; top: 12px; color: #a78bfa;"></i>
                    <input type="text" id="friend-search-input" placeholder="Yeni arkadaş ara veya ekle..." 
                        style="width:100%; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.06); border-radius:14px; padding:12px 16px 12px 42px; color:#e2e8f0; font-size:0.95rem; outline:none; font-family:'Inter',sans-serif; transition:all 0.3s;"
                        oninput="SocialFeed.handleFriendSearch(this.value)"
                        onfocus="this.style.borderColor='rgba(124,58,237,0.3)'; this.style.background='rgba(255,255,255,0.05)'"
                        onblur="this.style.borderColor='rgba(255,255,255,0.06)'; this.style.background='rgba(255,255,255,0.03)'">
                </div>
                <div id="friend-search-results"></div>
            </div>
        `;

        // Action Tabs within Friends
        html += `
            <div style="display:flex; gap:10px; margin-bottom:20px;">
                <button class="social-hub-tab active" style="font-size:0.8rem; padding:8px 12px;">Tümü</button>
                ${pending.length > 0 ? `<button class="social-hub-tab" style="font-size:0.8rem; padding:8px 12px; border-color:#f59e0b20; color:#f59e0b;">İstekler (${pending.length})</button>` : ''}
            </div>
        `;

        // Follow requests
        if (followRequests.length > 0) {
            html += `<h3 class="friends-group-title"><i class="fa-solid fa-user-plus" style="color:#3b82f6;"></i> Takip İstekleri (${followRequests.length})</h3>`;
            followRequests.forEach((req, i) => {
                const fromId = typeof req === 'object' ? req.fromId : req;
                const requester = State.data.users?.find(u => u.id === fromId);
                if (requester) {
                    const ts = typeof req === 'object' && req.timestamp ? this.timeAgo(req.timestamp) : '';
                    html += `
                        <div class="friend-request-card">
                            <img src="${requester.avatar || 'assets/logo.png'}" class="friend-avatar" onclick="SocialFeed.goToProfile('${requester.username}')">
                            <div style="flex:1;">
                                <div class="friend-name">${requester.username}</div>
                                <div class="friend-status-text">Sizi takip etmek istiyor ${ts ? '· ' + ts : ''}</div>
                            </div>
                            <div class="request-actions">
                                <button onclick="SocialFeed.acceptFollowRequest(${i})" class="btn-accept">Kabul Et</button>
                                <button onclick="SocialFeed.rejectFollowRequest(${i})" class="btn-reject">Reddet</button>
                            </div>
                        </div>`;
                }
            });
        }

        // Pending friend requests
        if (pending.length > 0) {
            html += `<h3 class="friends-group-title"><i class="fa-solid fa-clock" style="color:#f59e0b;"></i> Arkadaşlık İstekleri (${pending.length})</h3>`;
            pending.forEach((req, i) => {
                const requester = State.data.users?.find(u => u.id === req.fromId);
                if (requester) {
                    html += `
                        <div class="friend-request-card">
                            <img src="${requester.avatar || 'assets/logo.png'}" class="friend-avatar" onclick="SocialFeed.goToProfile('${requester.username}')">
                            <div style="flex:1;">
                                <div class="friend-name">${requester.username}</div>
                                <div class="friend-status-text">${this.timeAgo(req.timestamp)} gönderildi</div>
                            </div>
                            <div class="request-actions">
                                <button onclick="SocialFeed.acceptFriendRequest(${i})" class="btn-accept-alt">Kabul Et</button>
                                <button onclick="SocialFeed.rejectFriendRequest(${i})" class="btn-reject">Reddet</button>
                            </div>
                        </div>`;
                }
            });
        }

        // Helper to render friend item
        const renderFriend = (f) => {
            const statusColor = f.presence.status === 'online' ? '#10b981' : f.presence.status === 'dnd' ? '#ef4444' : f.presence.status === 'idle' ? '#f59e0b' : '#64748b';
            return `
                <div class="social-friend-item" onclick="SocialFeed.goToProfile('${f.username}')">
                    <div style="position:relative;">
                        <img src="${f.avatar || 'assets/logo.png'}" class="friend-avatar">
                        <span class="status-dot ${f.presence.dotClass}" style="position:absolute; bottom:2px; right:2px;"></span>
                    </div>
                    <div style="flex:1;">
                        <div class="friend-name">${f.username}</div>
                        <div class="friend-status-text" style="color:${statusColor};">${f.presence.label}${f.presence.lastSeen ? ' · ' + f.presence.lastSeen : ''}</div>
                    </div>
                    <div class="friend-actions">
                        <button onclick="event.stopPropagation(); SocialFeed.startChat('${f.id}')" title="Mesaj Gönder"><i class="fa-solid fa-message"></i></button>
                        <button onclick="event.stopPropagation(); SocialFeed.friendMenu('${f.id}')" title="Diğer Seçenekler"><i class="fa-solid fa-ellipsis-vertical"></i></button>
                    </div>
                </div>`;
        };

        // Friends list sections
        if (onlineFriends.length > 0) {
            html += `<h3 class="friends-group-title"><i class="fa-solid fa-circle" style="color:#10b981; font-size:0.6rem; animation:pulse 2s infinite;"></i> Çevrimiçi (${onlineFriends.length})</h3>`;
            onlineFriends.forEach(f => html += renderFriend(f));
        }

        if (awayFriends.length > 0) {
            html += `<h3 class="friends-group-title"><i class="fa-solid fa-moon" style="color:#f59e0b;"></i> Boşta / Rahatsız Etmeyin (${awayFriends.length})</h3>`;
            awayFriends.forEach(f => html += renderFriend(f));
        }

        if (offlineFriends.length > 0) {
            html += `<h3 class="friends-group-title"><i class="fa-solid fa-circle-dot" style="color:#64748b;"></i> Çevrimdışı (${offlineFriends.length})</h3>`;
            offlineFriends.forEach(f => html += renderFriend(f));
        }

        if (friendsData.length === 0) {
            html += '<div class="social-empty-state"><p>Henüz arkadaşınız yok. Kullanıcı arayarak arkadaş ekleyin.</p></div>';
        }

        return html;
    },

    handleFriendSearch(query) {
        const container = document.getElementById('friend-search-results');
        if (!container) return;
        if (!query.trim()) { container.innerHTML = ''; return; }

        const results = (State.data.users || []).filter(u =>
            u.id !== State.currentUser.id &&
            (u.username || '').toLowerCase().includes(query.toLowerCase())
        ).slice(0, 8);

        if (results.length === 0) {
            container.innerHTML = '<div style="text-align:center; padding:15px; color:#64748b;">Sonuç bulunamadı.</div>';
            return;
        }

        container.innerHTML = results.map(u => {
            const isFriend = (State.currentUser.friends || []).includes(u.id);
            return `
                <div style="display:flex; align-items:center; gap:12px; padding:12px; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:12px; margin-bottom:6px;">
                    <img src="${u.avatar || 'assets/logo.png'}" style="width:38px; height:38px; border-radius:50%; object-fit:cover;">
                    <div style="flex:1;">
                        <div style="font-weight:600; color:#fff; font-size:0.9rem;">${u.username}</div>
                    </div>
                    ${isFriend ?
                    `<span style="color:#10b981; font-size:0.8rem; font-weight:600;"><i class="fa-solid fa-check"></i> Arkadaş</span>` :
                    `<button onclick="SocialFeed.sendFriendRequest('${u.id}')" style="background:linear-gradient(135deg,#7c3aed,#6d28d9); border:none; color:white; padding:6px 14px; border-radius:8px; cursor:pointer; font-weight:600; font-size:0.8rem;">Arkadaş Ekle</button>`
                }
                </div>`;
        }).join('') || '<div style="text-align:center; padding:20px; color:#64748b; font-size:0.9rem;">Kullanıcı bulunamadı.</div>';
    },

    sendFriendRequest(userId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Arkadaş eklemek için üye olmalısınız.');
            if (window.Auth) Auth.showLogin();
            return;
        }
        const target = State.data.users?.find(u => u.id === userId);
        if (!target) return;
        if (!target.friendRequests) target.friendRequests = [];

        // Check duplicate
        if (target.friendRequests.some(r => r.fromId === State.currentUser.id)) {
            Toast.info('Zaten istek gönderildi.');
            return;
        }

        target.friendRequests.push({
            fromId: State.currentUser.id,
            timestamp: new Date().toISOString()
        });

        // Notification
        if (!target.notifications) target.notifications = [];
        target.notifications.push({
            id: 'notif_' + Date.now(),
            title: 'Arkadaşlık İsteği',
            message: `${State.currentUser.username} sana arkadaşlık isteği gönderdi.`,
            timestamp: new Date().toISOString(),
            read: false,
            type: 'friend-request'
        });

        db.save();
        Toast.success('Arkadaşlık isteği gönderildi!');
    },

    acceptFriendRequest(index) {
        const pending = State.currentUser.friendRequests || [];
        if (index >= pending.length) return;
        const req = pending[index];

        // Add friend both ways
        if (!State.currentUser.friends) State.currentUser.friends = [];
        State.currentUser.friends.push(req.fromId);

        const otherUser = State.data.users?.find(u => u.id === req.fromId);
        if (otherUser) {
            if (!otherUser.friends) otherUser.friends = [];
            otherUser.friends.push(State.currentUser.id);
        }

        // Remove request
        pending.splice(index, 1);
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        db.save();
        Toast.success('Arkadaşlık kabul edildi! 🎉');
        this.switchTab('friends', document.querySelector('.social-hub-tab[data-tab="friends"]'));
    },

    rejectFriendRequest(index) {
        const pending = State.currentUser.friendRequests || [];
        if (index >= pending.length) return;
        pending.splice(index, 1);
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        db.save();
        Toast.info('İstek reddedildi.');
        this.switchTab('friends', document.querySelector('.social-hub-tab[data-tab="friends"]'));
    },

    acceptFollowRequest(index) {
        const requests = State.currentUser.followRequests || [];
        if (index >= requests.length) return;
        const req = requests[index];
        const fromId = typeof req === 'object' ? req.fromId : req;

        // Add to followers
        if (!State.currentUser.followers) State.currentUser.followers = [];
        if (!State.currentUser.followers.includes(fromId)) {
            State.currentUser.followers.push(fromId);
        }

        // Add to the other user's following
        const otherUser = State.data.users?.find(u => u.id === fromId);
        if (otherUser) {
            if (!otherUser.following) otherUser.following = [];
            if (!otherUser.following.includes(State.currentUser.id)) {
                otherUser.following.push(State.currentUser.id);
            }
        }

        // Remove request
        requests.splice(index, 1);
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        db.save();
        Toast.success('Takip isteği kabul edildi! 🎉');
        this.switchTab('friends', document.querySelector('.social-hub-tab[data-tab="friends"]'));
    },

    rejectFollowRequest(index) {
        const requests = State.currentUser.followRequests || [];
        if (index >= requests.length) return;
        requests.splice(index, 1);
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        db.save();
        Toast.info('Takip isteği reddedildi.');
        this.switchTab('friends', document.querySelector('.social-hub-tab[data-tab="friends"]'));
    },

    getPendingRequestCount() {
        return (State.currentUser?.friendRequests || []).length + (State.currentUser?.followRequests || []).length;
    },

    // ==================== MESSAGES TAB ====================
    renderMessagesTab() {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            return `
                <div class="social-empty-state" style="padding: 80px 20px;">
                    <div style="font-size: 3.5rem; margin-bottom: 25px; opacity: 0.8; filter: grayscale(1);">💬</div>
                    <h3 style="color: #fff; font-weight: 800; margin-bottom: 12px;">Özel Mesajlar</h3>
                    <p style="color: #94a3b8; margin-bottom: 30px; max-width: 450px; margin-left: auto; margin-right: auto; line-height: 1.6;">Diğer üyelerle sohbet etmek ve mesajlaşmak için bir hesabın olmalı.</p>
                    <div style="display: flex; gap: 12px; justify-content: center;">
                        <button class="btn btn-primary" onclick="Auth.showLogin()" style="padding: 12px 32px; border-radius: 14px; font-weight: 800; box-shadow: 0 10px 20px rgba(124, 58, 237, 0.2);">Giriş Yap</button>
                    </div>
                </div>`;
        }

        const conversations = MessageService.getConversations(State.currentUser.id);

        if (conversations.length === 0) {
            return `
                <div class="social-empty-state">
                    <i class="fa-solid fa-comments" style="font-size:3rem; color:rgba(124,58,237,0.3);"></i>
                    <h3>Henüz Mesaj Yok</h3>
                    <p style="color:#64748b;">Mesajlaşmak için önce arkadaş ekleyin veya birine mesaj atın.</p>
                </div>`;
        }

        let html = `<div id="msg-container" style="display:flex; gap:0; height:500px; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:20px; overflow:hidden;">
            <div id="msg-friend-list" style="width:280px; border-right:1px solid rgba(255,255,255,0.06); overflow-y:auto; flex-shrink:0;">
                <div style="padding:16px; border-bottom:1px solid rgba(255,255,255,0.06);">
                    <div style="font-weight:700; color:#fff; font-size:1rem;"><i class="fa-solid fa-comments" style="color:#8b5cf6;"></i> Mesajlar</div>
                </div>`;

        conversations.forEach(c => {
            const lastMsg = c.lastMessage;
            const lastMsgText = lastMsg ? (lastMsg.text?.substring(0, 30) + (lastMsg.text?.length > 30 ? '...' : '')) : 'Henüz mesaj yok';
            const lastMsgTime = lastMsg ? this.timeAgo(lastMsg.timestamp) : '';
            const unread = c.unreadCount || 0;

            html += `
                <div onclick="SocialFeed.openInlineChat('${c.userId}')" style="display:flex; align-items:center; gap:12px; padding:14px 16px; cursor:pointer; transition:all 0.2s; border-bottom:1px solid rgba(255,255,255,0.03);" onmouseenter="this.style.background='rgba(124,58,237,0.05)'" onmouseleave="this.style.background=''">
                    <img src="${c.avatar || 'assets/logo.png'}" style="width:40px; height:40px; border-radius:50%; object-fit:cover;">
                    <div style="flex:1; min-width:0;">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span style="color:#fff; font-weight:600; font-size:0.85rem;">${c.username}</span>
                            <span style="color:#475569; font-size:0.65rem;">${lastMsgTime}</span>
                        </div>
                        <div style="color:#64748b; font-size:0.78rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${lastMsgText}</div>
                    </div>
                    ${unread > 0 ? `<span style="background:#8b5cf6; color:#fff; font-size:0.65rem; padding:2px 7px; border-radius:10px; font-weight:700;">${unread}</span>` : ''}
                </div>`;
        });

        html += `</div>
            <div id="msg-chat-area" style="flex:1; display:flex; flex-direction:column;">
                <div style="flex:1; display:flex; align-items:center; justify-content:center; color:#475569;">
                    <div style="text-align:center;">
                        <i class="fa-solid fa-message" style="font-size:2.5rem; opacity:0.2; margin-bottom:10px;"></i>
                        <p>Bir sohbet seçin</p>
                    </div>
                </div>
            </div>
        </div>`;

        return html;
    },

    async openInlineChat(userId) {
        const chatArea = document.getElementById('msg-chat-area');
        if (!chatArea) return;

        await db.ensureCollection('messages');
        await MessageService.fetchMessages(State.currentUser.id);

        const friend = State.data.users?.find(u => u.id === userId);
        if (!friend) return;

        const conversations = MessageService.getConversations(State.currentUser.id);
        const convo = conversations.find(c => c.userId === userId);
        const messages = convo ? convo.messages : [];

        // Mark as read
        messages.forEach(m => {
            if (m.to === State.currentUser.id && !m.read) {
                MessageService.markAsRead(m.id);
            }
        });

        chatArea.innerHTML = `
            <div style="padding:14px 16px; border-bottom:1px solid rgba(255,255,255,0.06); display:flex; align-items:center; gap:10px;">
                <img src="${friend.avatar || 'assets/logo.png'}" style="width:32px; height:32px; border-radius:50%; object-fit:cover;">
                <span style="color:#fff; font-weight:700; font-size:0.9rem;">${friend.username}</span>
            </div>
            <div id="msg-chat-messages" style="flex:1; overflow-y:auto; padding:16px; display:flex; flex-direction:column; gap:8px;">
                ${messages.length === 0 ? '<div style="text-align:center; color:#475569; margin-top:50px;"><p>Henüz mesaj yok. Bir mesaj gönderin!</p></div>' :
                messages.map(m => {
                    const isMine = m.from === State.currentUser.id;
                    return `<div style="display:flex; ${isMine ? 'justify-content:flex-end' : 'justify-content:flex-start'};">
                        <div style="max-width:70%; padding:10px 14px; border-radius:${isMine ? '14px 14px 4px 14px' : '14px 14px 14px 4px'}; background:${isMine ? 'linear-gradient(135deg,#7c3aed,#6d28d9)' : 'rgba(255,255,255,0.05)'}; color:#fff; font-size:0.85rem;">
                            ${m.text}
                            <div style="font-size:0.6rem; color:${isMine ? 'rgba(255,255,255,0.5)' : '#475569'}; margin-top:4px; text-align:right;">${this.timeAgo(m.timestamp)}</div>
                        </div>
                    </div>`;
                }).join('')}
            </div>
            <div style="padding:12px 16px; border-top:1px solid rgba(255,255,255,0.06); display:flex; gap:10px;">
                <input id="msg-chat-input" type="text" placeholder="Mesaj yazın..." style="flex:1; padding:10px 16px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:14px; color:#fff; font-size:0.9rem; outline:none;" onkeydown="if(event.key==='Enter') SocialFeed.sendInlineMessage('${userId}')">
                <button onclick="SocialFeed.sendInlineMessage('${userId}')" style="background:linear-gradient(135deg,#7c3aed,#6d28d9); border:none; color:#fff; padding:10px 16px; border-radius:14px; cursor:pointer;"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        `;

        // Scroll to bottom
        setTimeout(() => {
            const msgEl = document.getElementById('msg-chat-messages');
            if (msgEl) msgEl.scrollTop = msgEl.scrollHeight;
        }, 100);
    },

    async sendInlineMessage(userId) {
        const input = document.getElementById('msg-chat-input');
        if (!input || !input.value.trim()) return;

        const text = input.value.trim();
        input.value = ''; // Clear immediately for better feel

        const result = await MessageService.sendMessage(userId, text);

        if (result && result.success) {
            // Re-fetch to see the message immediately
            await MessageService.fetchMessages(State.currentUser.id);
            // Re-render chat
            this.openInlineChat(userId);
        } else {
            Toast.error("Mesaj gönderilemedi.");
        }
    },

    startChat(userId) {
        this.currentTab = 'messages';
        const content = document.getElementById('social-tab-content');
        if (content) content.innerHTML = this.renderMessagesTab();
        // Switch tab button
        document.querySelectorAll('.social-hub-tab').forEach(b => b.classList.remove('active'));
        const msgTab = document.querySelector('.social-hub-tab[data-tab="messages"]');
        if (msgTab) msgTab.classList.add('active');
        setTimeout(() => this.openInlineChat(userId), 200);
    },

    // ==================== TRENDING SIDEBAR ====================
    renderTrendingSidebar() {
        return `
            <div class="trending-card">
                <h3><i class="fa-solid fa-fire"></i> Gündemdekiler</h3>
                <div id="social-trending-list">
                    ${this.renderTrendingList()}
                </div>
            </div>`;
    },


    // ==================== ACTIVE FRIENDS SIDEBAR ====================
    renderActiveFriendsSidebar() {
        if (!State.currentUser || State.currentUser.role === 'guest') return '';

        const friends = State.currentUser.friends || [];
        if (friends.length === 0) return '';

        const activeFriends = friends
            .map(fid => State.data.users?.find(u => u.id === fid))
            .filter(u => u && Social.getUserPresence(u).status === 'online')
            .slice(0, 5);

        if (activeFriends.length === 0) {
            return `
                <div class="trending-card active-friends-sidebar">
                    <h3><i class="fa-solid fa-circle" style="color:#64748b; font-size:0.7rem;"></i> Aktif Arkadaşlar</h3>
                    <p style="color:#64748b; font-size:0.8rem; padding: 5px 0;">Şu an aktif arkadaşın yok.</p>
                </div>`;
        }

        return `
            <div class="trending-card active-friends-sidebar">
                <h3><i class="fa-solid fa-circle" style="color:#10b981; font-size:0.7rem; animation: pulse 2s infinite;"></i> Aktif Arkadaşlar</h3>
                <div class="active-friends-list" style="display:flex; flex-direction:column; gap:12px; margin-top:10px;">
                    ${activeFriends.map(friend => `
                        <div class="active-friend-item" onclick="SocialFeed.startChat('${friend.id}')" style="display:flex; align-items:center; gap:12px; cursor:pointer; transition:all 0.2s; padding:4px; border-radius:10px;" onmouseenter="this.style.background='rgba(255,255,255,0.03)'" onmouseleave="this.style.background=''">
                            <div style="position:relative;">
                                <img src="${friend.avatar || 'assets/logo.png'}" style="width:36px; height:36px; border-radius:50%; object-fit:cover; border: 2px solid #10b981;">
                                <span class="status-dot online" data-user-id="${friend.id}" style="position:absolute; bottom:0; right:0; width:10px; height:10px; border-radius:50%; background:#10b981; border:2px solid #0f0f13;"></span>
                            </div>
                            <div style="flex:1;">
                                <div style="font-weight:700; color:#fff; font-size:0.85rem;">${friend.username}</div>
                                <div style="font-size:0.7rem; color:#10b981; font-weight:600;">Şu an aktif</div>
                            </div>
                            <i class="fa-solid fa-paper-plane" style="color:#64748b; font-size:0.8rem;"></i>
                        </div>
                    `).join('')}
                </div>
            </div>`;
    },
    // ==================== HALL OF FAME ====================

    filterByTag(tag) {
        this.filterTag = tag;
        if (tag) {
            const cleanTag = tag.replace('#', '');
            App.router('social', 'feed', 'tag-' + cleanTag);
        } else {
            App.router('social', 'feed');
        }
    },

    renderQuickActions() {
        return `
            <div class="quick-actions-card" style="width: 100%; box-sizing: border-box;">
                <h3>Hızlı İşlemler</h3>
                <div class="quick-action-item" onclick="SocialFeed.openCreatePostModal()">
                    <i class="fa-solid fa-pen-to-square" style="color:#7c3aed;"></i> Yeni Paylaşım
                </div>
                <div class="quick-action-item" onclick="SocialFeed.openCreatePostModal('poll')">
                    <i class="fa-solid fa-square-poll-vertical" style="color:#f59e0b;"></i> Anket Oluştur
                </div>
                <div class="quick-action-item" onclick="SocialFeed.switchTab('messages')">
                    <i class="fa-solid fa-message" style="color:#10b981;"></i> Mesajlar
                </div>
                <div class="quick-action-item" onclick="App.router('leaderboard')">
                    <i class="fa-solid fa-trophy" style="color:#ef4444;"></i> Liderlik Tablosu
                </div>
                <div class="quick-action-item" onclick="SocialFeed.showMoodPicker()">
                    <i class="fa-solid fa-moon" style="color:#a78bfa;"></i> Ruh Halini Belirle
                </div>
                <div class="quick-action-item" onclick="SocialFeed.showWatchlistModal()">
                    <i class="fa-solid fa-clipboard-list" style="color:#3b82f6;"></i> İzleme Listesi Paylaş
                </div>
                <div class="quick-action-item" onclick="SocialFeed.showPrivacySettings()">
                    <i class="fa-solid fa-lock" style="color:#f59e0b;"></i> Gizlilik Ayarları
                </div>
                ${!State.currentUser || State.currentUser.role === 'guest' ? `
                <div style="margin-top: 15px; padding: 15px; background: rgba(124, 58, 237, 0.08); border: 1px dashed rgba(124, 58, 237, 0.3); border-radius: 12px; text-align: center;">
                    <p style="font-size: 0.75rem; color: #a78bfa; font-weight: 600; margin-bottom: 10px;">Daha fazla özellik için</p>
                    <button class="btn btn-primary btn-sm" onclick="Auth.showLogin()" style="width: 100%; border-radius: 8px; font-size: 0.8rem;">Giriş Yap</button>
                </div>
                ` : ''}
                ${this.isModerator(State.currentUser) ? `
                <div class="quick-action-item" onclick="SocialFeed.showModerationPanel()" style="border-top:1px solid rgba(255,255,255,0.06); padding-top:14px; margin-top:6px;">
                    <i class="fa-solid fa-shield-halved" style="color:#f59e0b;"></i> Moderasyon Paneli
                </div>` : ''}
                ${State.currentUser?.role === 'admin' ? `
                <div class="quick-action-item" onclick="SocialFeed.showAdminBanPanel()">
                    <i class="fa-solid fa-gavel" style="color:#ef4444;"></i> Ban & Raporlar
                </div>` : ''}
            </div>
            
            <div class="quick-actions-card" style="width: 100%; box-sizing: border-box; margin-top: 20px;">
                <h3 style="display:flex; align-items:center; gap:8px;"><i class="fa-solid fa-circle" style="color:#10b981; font-size:0.6rem;"></i> Çevrimiçi Kullanıcılar</h3>
                <div id="online-users-list" style="max-height:200px; overflow-y:auto; padding:5px;">
                    ${this.renderOnlineUsersList()}
                </div>
            </div>`;
    },

    // ==================== CONTENT SHARING (from Series/Player) ====================
    shareToSocial(data) {
        // Called from DetailedView, Player, or Browse
        // data = { type: 'series'|'episode'|'movie'|'anime', title, subtitle, poster, seriesId }
        this.shareData = data;
        App.router('social');
    },

    // ==================== HELPERS ====================
    parseContent(text) {
        if (!text) return '';
        let html = this.escapeHtml(text);

        // Parse hashtags
        html = html.replace(/#([a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+)/g, '<span class="hashtag" onclick="SocialFeed.filterByTag(\'#$1\')">#$1</span>');

        // Parse mentions
        html = html.replace(/@([a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+)/g, '<span class="mention" onclick="SocialFeed.goToProfile(\'$1\')">@$1</span>');

        // Newlines
        html = html.replace(/\n/g, '<br>');

        return html;
    },

    goToProfile(username) {
        App.navigate('social/profile/@' + username);
    },

    escapeHtml(text) {
        if (!text) return '';
        return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    },

    timeAgo(timestamp) {
        if (!timestamp) return '';
        const diff = (Date.now() - new Date(timestamp).getTime()) / 1000;
        if (diff < 60) return 'Az önce';
        if (diff < 3600) return Math.floor(diff / 60) + 'dk';
        if (diff < 86400) return Math.floor(diff / 3600) + 'sa';
        if (diff < 604800) return Math.floor(diff / 86400) + 'g';
        return new Date(timestamp).toLocaleDateString('tr-TR');
    },

    // ==================== ADMIN: MODERATION PANEL ====================
    showModerationPanel() {
        if (!this.isModerator(State.currentUser)) {
            Toast.error('Bu panele erişim yetkiniz yok.');
            return;
        }

        // Init social settings if not exists
        if (!State.data.socialSettings) {
            State.data.socialSettings = { bannedWords: [], allowedDomains: [], moderators: [] };
        }

        const settings = State.data.socialSettings;
        const bannedStr = (settings.bannedWords || []).join(', ');
        const domainsStr = (settings.allowedDomains || []).join(', ');

        const modal = document.createElement('div');
        modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.7); backdrop-filter:blur(8px); z-index:9999; display:flex; align-items:center; justify-content:center;';
        modal.id = 'moderation-panel-modal';
        modal.onclick = (e) => { if (e.target === modal) modal.remove(); };

        modal.innerHTML = `
            <div style="background:#0f0f13; border:1px solid rgba(255,255,255,0.08); border-radius:24px; width:90%; max-width:700px; max-height:85vh; overflow-y:auto; padding:28px; box-shadow:0 30px 60px rgba(0,0,0,0.5);">
                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px;">
                    <h2 style="color:#fff; font-size:1.4rem; font-weight:800; display:flex; align-items:center; gap:10px;">
                        <i class="fa-solid fa-shield-halved" style="color:#f59e0b;"></i> Sosyal Moderasyon Paneli
                    </h2>
                    <button onclick="document.getElementById('moderation-panel-modal').remove()" style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:#94a3b8; width:36px; height:36px; border-radius:50%; cursor:pointer; font-size:1.1rem;">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>

                <!-- Banned Words -->
                <div style="margin-bottom:24px;">
                    <h3 style="color:#e2e8f0; font-size:1rem; margin-bottom:10px;"><i class="fa-solid fa-ban" style="color:#ef4444;"></i> Yasaklı Kelimeler</h3>
                    <p style="color:#64748b; font-size:0.8rem; margin-bottom:10px;">Virgülle ayırarak ekleyin. Varsayılan liste her zaman aktiftir.</p>
                    <textarea id="mod-banned-words" style="width:100%; min-height:80px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:12px; color:#e2e8f0; padding:12px; font-size:0.9rem; outline:none; resize:vertical; font-family:'Inter',sans-serif;">${bannedStr}</textarea>
                </div>

                <!-- Allowed Domains -->
                <div style="margin-bottom:24px;">
                    <h3 style="color:#e2e8f0; font-size:1rem; margin-bottom:10px;"><i class="fa-solid fa-link" style="color:#10b981;"></i> İzin Verilen Domainler</h3>
                    <p style="color:#64748b; font-size:0.8rem; margin-bottom:10px;">Varsayılan: dramicbox.com, youtube.com, youtu.be. Ek domainler ekleyin.</p>
                    <textarea id="mod-allowed-domains" style="width:100%; min-height:60px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:12px; color:#e2e8f0; padding:12px; font-size:0.9rem; outline:none; resize:vertical; font-family:'Inter',sans-serif;">${domainsStr}</textarea>
                </div>

                <!-- Save Settings -->
                <button onclick="SocialFeed.saveModerationSettings()" style="width:100%; padding:14px; background:linear-gradient(135deg,#7c3aed,#6d28d9); border:none; color:white; border-radius:14px; font-weight:700; cursor:pointer; font-size:0.95rem; margin-bottom:24px; font-family:'Inter',sans-serif;">
                    <i class="fa-solid fa-floppy-disk"></i> Ayarları Kaydet
                </button>

                <!-- Moderator Management -->
                ${State.currentUser?.role === 'admin' ? `
                <div style="border-top:1px solid rgba(255,255,255,0.06); padding-top:24px;">
                    <h3 style="color:#e2e8f0; font-size:1rem; margin-bottom:16px;"><i class="fa-solid fa-users-gear" style="color:#a78bfa;"></i> Moderatör Yönetimi</h3>
                    
                    <div style="display:flex; gap:10px; margin-bottom:16px;">
                        <input type="text" id="mod-user-search" placeholder="Kullanıcı adı ara..." 
                               style="flex:1; padding:10px 14px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#e2e8f0; outline:none; font-family:'Inter',sans-serif;"
                               oninput="SocialFeed.searchModUsers(this.value)">
                    </div>
                    <div id="mod-user-results"></div>

                    <h4 style="color:#94a3b8; font-size:0.9rem; margin:20px 0 12px;">Mevcut Moderatörler</h4>
                    <div id="mod-current-list">
                        ${this.renderCurrentModerators()}
                    </div>
                </div>` : ''}



                <!-- Pending Posts for Approval -->
                <div style="border-top:1px solid rgba(255,255,255,0.06); padding-top:24px; margin-top:24px;">
                    <h3 style="color:#e2e8f0; font-size:1rem; margin-bottom:16px;">
                        <i class="fa-solid fa-clock-rotate-left" style="color:#f59e0b;"></i> Onay Bekleyen Paylaşımlar
                    </h3>
                    <div id="pending-posts-list">
                        ${this.renderPendingPostsList()}
                    </div>
                </div>

                <!-- Social Stats -->
                <div style="border-top:1px solid rgba(255,255,255,0.06); padding-top:24px; margin-top:24px;">
                    <h3 style="color:#e2e8f0; font-size:1rem; margin-bottom:16px;"><i class="fa-solid fa-chart-pie" style="color:#ec4899;"></i> Sosyal İstatistikler</h3>
                    <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:12px;">
                        <div style="background:rgba(124,58,237,0.1); border:1px solid rgba(124,58,237,0.2); border-radius:14px; padding:16px; text-align:center;">
                            <div style="font-size:1.8rem; font-weight:800; color:#a78bfa;">${(State.data.socialPosts || []).length}</div>
                            <div style="font-size:0.8rem; color:#94a3b8;">Toplam Paylaşım</div>
                        </div>
                        <div style="background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.2); border-radius:14px; padding:16px; text-align:center;">
                            <div style="font-size:1.8rem; font-weight:800; color:#10b981;">${(State.data.users || []).length}</div>
                            <div style="font-size:0.8rem; color:#94a3b8;">Toplam Kullanıcı</div>
                        </div>
                        <div style="background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); border-radius:14px; padding:16px; text-align:center;">
                            <div style="font-size:1.8rem; font-weight:800; color:#ef4444;">${(State.data.users || []).filter(u => u.badges?.includes('Sosyal Moderatör') || u.role === 'moderator').length}</div>
                            <div style="font-size:0.8rem; color:#94a3b8;">Moderatör</div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
    },

    saveModerationSettings() {
        if (!State.data.socialSettings) State.data.socialSettings = {};

        const bannedInput = document.getElementById('mod-banned-words')?.value || '';
        const domainsInput = document.getElementById('mod-allowed-domains')?.value || '';

        State.data.socialSettings.bannedWords = bannedInput.split(',').map(w => w.trim()).filter(w => w);
        State.data.socialSettings.allowedDomains = domainsInput.split(',').map(d => d.trim()).filter(d => d);

        db.save();
        Toast.success('Moderasyon ayarları kaydedildi! ✅');
    },

    searchModUsers(query) {
        const container = document.getElementById('mod-user-results');
        if (!container) return;
        if (!query.trim()) { container.innerHTML = ''; return; }

        const results = (State.data.users || []).filter(u =>
            u.username.toLowerCase().includes(query.toLowerCase())
        ).slice(0, 6);

        container.innerHTML = results.map(u => {
            const isMod = this.isModerator(u);
            return `
                <div style="display:flex; align-items:center; gap:12px; padding:10px; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:10px; margin-bottom:6px;">
                    <img src="${u.avatar || 'assets/logo.png'}" style="width:36px; height:36px; border-radius:50%; object-fit:cover;">
                    <div style="flex:1;">
                        <div style="font-weight:600; color:#fff; font-size:0.9rem;">${u.username}</div>
                        <div style="font-size:0.75rem; color:#64748b;">${u.role || 'user'} | ${(u.badges || []).join(', ')}</div>
                    </div>
                    ${isMod ?
                    `<button onclick="SocialFeed.removeModeratorRole('${u.id}')" style="background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.3); color:#ef4444; padding:6px 12px; border-radius:8px; cursor:pointer; font-weight:600; font-size:0.8rem;">Moderatörlüğü Kaldır</button>` :
                    `<button onclick="SocialFeed.assignModeratorRole('${u.id}')" style="background:linear-gradient(135deg,#7c3aed,#6d28d9); border:none; color:white; padding:6px 12px; border-radius:8px; cursor:pointer; font-weight:600; font-size:0.8rem;">Moderatör Yap</button>`
                }
                </div>`;
        }).join('');
    },

    assignModeratorRole(userId) {
        const user = State.data.users?.find(u => u.id === userId);
        if (!user) return;

        // Add role and badge
        user.role = 'moderator';
        if (!user.badges) user.badges = [];
        if (!user.badges.includes('Sosyal Moderatör')) {
            user.badges.push('Sosyal Moderatör');
        }

        // Notify user
        if (!user.notifications) user.notifications = [];
        user.notifications.push({
            id: 'notif_' + Date.now(),
            title: '🛡️ Moderatör Rolü Verildi!',
            message: 'Tebrikler! Artık bir Sosyal Moderatörsünüz. Topluluk kurallarını uygulama yetkiniz var.',
            timestamp: new Date().toISOString(),
            read: false,
            type: 'role'
        });

        db.save();
        Toast.success(`${user.username} artık bir Sosyal Moderatör! 🛡️`);

        // Refresh lists
        this.searchModUsers(document.getElementById('mod-user-search')?.value || '');
        document.getElementById('mod-current-list').innerHTML = this.renderCurrentModerators();
    },

    removeModeratorRole(userId) {
        const user = State.data.users?.find(u => u.id === userId);
        if (!user) return;

        if (user.role === 'moderator') user.role = 'user';
        user.badges = (user.badges || []).filter(b => b !== 'Sosyal Moderatör' && b !== 'Moderatör');

        db.save();
        Toast.info(`${user.username} moderatörlükten çıkarıldı.`);

        // Refresh lists
        this.searchModUsers(document.getElementById('mod-user-search')?.value || '');
        document.getElementById('mod-current-list').innerHTML = this.renderCurrentModerators();
    },

    renderCurrentModerators() {
        const mods = (State.data.users || []).filter(u =>
            u.role === 'moderator' || u.badges?.includes('Sosyal Moderatör')
        );

        if (mods.length === 0) {
            return '<div style="text-align:center; padding:20px; color:#64748b;">Henüz moderatör atanmadı.</div>';
        }

        return mods.map(u => `
            <div style="display:flex; align-items:center; gap:12px; padding:10px; background:rgba(245,158,11,0.05); border:1px solid rgba(245,158,11,0.1); border-radius:10px; margin-bottom:6px;">
                <img src="${u.avatar || 'assets/logo.png'}" style="width:36px; height:36px; border-radius:50%; object-fit:cover;">
                <div style="flex:1;">
                    <div style="font-weight:600; color:#fff; font-size:0.9rem;">
                        ${u.username} <i class="fa-solid fa-shield-halved" style="color:#f59e0b; font-size:0.8rem;"></i>
                    </div>
                </div>
                <button onclick="SocialFeed.removeModeratorRole('${u.id}')" style="background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.2); color:#ef4444; padding:5px 10px; border-radius:8px; cursor:pointer; font-size:0.75rem; font-weight:600;">Kaldır</button>
            </div>
        `).join('');
    },

    renderPendingPostsList() {
        const pending = this.posts.filter(p => p.status === 'pending');
        if (pending.length === 0) return '<div style="color:#64748b; font-size:0.85rem; padding:10px; background:rgba(255,255,255,0.02); border-radius:10px; text-align:center;">Bekleyen paylaşım yok.</div>';

        return pending.map(p => {
            const user = State.data.users?.find(u => u.id === p.userId);
            return `
                <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:12px; padding:15px; margin-bottom:12px;">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                        <img src="${user?.avatar || 'assets/logo.png'}" style="width:32px; height:32px; border-radius:50%;">
                        <div>
                            <div style="color:#fff; font-weight:700; font-size:0.85rem;">${user?.username || 'Blogger'}</div>
                            <div style="color:#64748b; font-size:0.7rem;">${this.timeAgo(p.createdAt)}</div>
                        </div>
                    </div>
                    <div style="color:#e2e8f0; font-size:0.85rem; margin-bottom:12px; line-height:1.4;">${this.escapeHtml(p.text || '').substring(0, 150)}${p.text?.length > 150 ? '...' : ''}</div>
                    <div style="display:flex; gap:10px;">
                        <button onclick="SocialFeed.moderatePost('${p.id}', 'approve')" style="flex:1; padding:8px; background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.3); color:#10b981; border-radius:8px; cursor:pointer; font-weight:700; font-size:0.8rem;"><i class="fa-solid fa-check"></i> Onayla</button>
                        <button onclick="SocialFeed.moderatePost('${p.id}', 'reject')" style="flex:1; padding:8px; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.3); color:#ef4444; border-radius:8px; cursor:pointer; font-weight:700; font-size:0.8rem;"><i class="fa-solid fa-xmark"></i> Reddet</button>
                    </div>
                </div>
            `;
        }).join('');
    },

    moderatePost(postId, action) {
        if (!confirm(`Bu paylaşımı ${action === 'approve' ? 'onaylamak' : 'reddetmek'} istediğinize emin misiniz?`)) return;

        const post = this.posts.find(p => p.id === postId);
        if (post) {
            if (action === 'approve') {
                post.status = 'active';
                Toast.success('Paylaşım onaylandı! 🎉');
            } else {
                const idx = this.posts.indexOf(post);
                if (idx > -1) this.posts.splice(idx, 1);
                
                // Also remove from State.data.socialPosts
                const globalIdx = State.data.socialPosts.findIndex(p => p.id === postId);
                if (globalIdx > -1) State.data.socialPosts.splice(globalIdx, 1);
                
                Toast.info('Paylaşım reddedildi.');
            }
            
            db.save();
            const pendingList = document.getElementById('pending-posts-list');
            if (pendingList) pendingList.innerHTML = this.renderPendingPostsList();
            this.render();
        } else {
            Toast.error('Paylaşım bulunamadı.');
        }
    },

    // ==================== FOLLOW SYSTEM ====================
    renderFollowBtn(userId) {
        if (!State.currentUser || userId === State.currentUser.id) return '';
        const isFollowing = (State.currentUser.following || []).includes(userId);
        if (isFollowing) {
            return `<button onclick="event.stopPropagation(); SocialFeed.toggleFollow('${userId}')" style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:#94a3b8; padding:4px 10px; border-radius:8px; cursor:pointer; font-size:0.7rem; font-weight:600; white-space:nowrap;">Takip Ediliyor</button>`;
        }
        return `<button onclick="event.stopPropagation(); SocialFeed.toggleFollow('${userId}')" style="background:linear-gradient(135deg,#7c3aed,#6d28d9); border:none; color:white; padding:4px 10px; border-radius:8px; cursor:pointer; font-size:0.7rem; font-weight:600; white-space:nowrap;">Takip Et</button>`;
    },

    toggleFollow(userId) {
        if (!State.currentUser || State.currentUser.role === 'guest') { 
            Toast.warning('Takip etmek için üye olmalısınız.'); 
            if (window.Auth) Auth.showLogin();
            return; 
        }
        if (!State.currentUser.following) State.currentUser.following = [];

        const target = State.data.users?.find(u => u.id === userId);
        if (!target) return;
        if (!target.followers) target.followers = [];

        const idx = State.currentUser.following.indexOf(userId);
        if (idx > -1) {
            // Unfollow
            State.currentUser.following.splice(idx, 1);
            const fIdx = target.followers.indexOf(State.currentUser.id);
            if (fIdx > -1) target.followers.splice(fIdx, 1);
            Toast.info('Takipten çıkıldı.');
        } else {
            // Follow
            State.currentUser.following.push(userId);
            target.followers.push(State.currentUser.id);

            // Notify target
            if (!target.notifications) target.notifications = [];
            target.notifications.push({
                id: 'notif_' + Date.now(),
                title: '👤 Yeni Takipçi!',
                message: `${State.currentUser.username} seni takip etmeye başladı.`,
                timestamp: new Date().toISOString(),
                read: false,
                type: 'follow'
            });

            // XP reward
            this.awardSocialXP(2, 'follow');
            Toast.success('Takip edildi! ✅');
        }

        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        db.save();
        this.switchTab(this.currentTab, document.querySelector(`.social-hub-tab[data-tab="${this.currentTab}"]`));
    },

    // ==================== PINNED POSTS ====================
    togglePin(postId) {
        if (!State.currentUser) return;
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;
        if (post.userId !== State.currentUser.id) {
            Toast.error('Sadece kendi paylaşımlarınızı sabitleyebilirsiniz.');
            return;
        }

        // Only allow 3 pinned posts max
        const pinnedCount = this.posts.filter(p => p.userId === State.currentUser.id && p.isPinned).length;
        if (!post.isPinned && pinnedCount >= 3) {
            Toast.warning('En fazla 3 paylaşım sabitlenebilir.');
            return;
        }

        post.isPinned = !post.isPinned;
        db.save();
        Toast.success(post.isPinned ? '📌 Paylaşım sabitlendi!' : 'Paylaşım sabitleme kaldırıldı.');
        this.switchTab('feed', document.querySelector('.social-hub-tab[data-tab="feed"]'));
    },

    // ==================== REVIEWS TAB ====================
    renderReviewsTab() {
        const reviews = this.posts.filter(p => p.isReview).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        let html = `
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; background:linear-gradient(135deg,rgba(245,158,11,0.05),transparent); padding:20px; border-radius:20px; border:1px solid rgba(245,158,11,0.1);">
                <div>
                    <h2 style="color:#fff; font-size:1.5rem; font-weight:800; margin:0;"><i class="fa-solid fa-star-half-stroke" style="color:#f59e0b; margin-right:10px;"></i> Dizi İncelemeleri</h2>
                    <p style="color:#64748b; font-size:0.9rem; margin-top:5px;">Topluluk tarafından paylaşılan derinlemesine analizler.</p>
                </div>
                ${State.currentUser ? `<button onclick="SocialFeed.openReviewModal()" class="post-submit-btn" style="background:linear-gradient(135deg,#f59e0b,#d97706); border:none; color:white; padding:12px 24px; border-radius:14px; font-weight:700;"><i class="fa-solid fa-pen"></i> İnceleme Yaz</button>` : ''}
            </div>
        `;

        let filtered = reviews;
        if (this.searchQuery) {
            filtered = reviews.filter(p => {
                const text = (p.text || '').toLowerCase();
                const username = (State.data.users?.find(u => u.id === p.userId)?.username || '').toLowerCase();
                const seriesTitle = (p.reviewData?.seriesTitle || '').toLowerCase();
                return text.includes(this.searchQuery) || username.includes(this.searchQuery) || seriesTitle.includes(this.searchQuery);
            });
        }

        if (filtered.length === 0) {
            html += `<div class="social-empty-state"><i class="fa-solid fa-film"></i><h3>Henüz inceleme yok</h3><p>Yeni bir arama yapmayı veya ilk incelemeyi yazmayı deneyin!</p></div>`;
        } else {
            filtered.forEach(post => {
                const user = State.data.users?.find(u => u.id === post.userId);
                const r = post.reviewData;
                html += `
                    <div class="review-card-premium">
                        <!-- Review Header -->
                        <div class="review-header">
                            <img src="${user?.avatar || 'assets/logo.png'}" class="reviewer-avatar" onclick="SocialFeed.goToProfile('${user?.username}')">
                            <div class="reviewer-info">
                                <div class="reviewer-name">${user?.username || 'Kullanıcı'}</div>
                                <div class="review-meta">${this.timeAgo(post.createdAt)} · <span class="review-tag">${r?.contentType || 'Dizi'}</span></div>
                            </div>
                            <div class="review-score-badge">${r?.overallScore || 0}<span>/10</span></div>
                        </div>

                        <!-- Review Title -->
                        ${r?.seriesTitle ? `<div class="review-series-title">${r.seriesTitle}</div>` : ''}

                        <!-- Review Text -->
                        ${post.text ? `
                            ${post.isSpoiler ? `
                                <div id="spoiler-${post.id}" class="spoiler-wrapper" onclick="SocialFeed.revealSpoiler('${post.id}')" style="margin-bottom:15px;">
                                    <div class="spoiler-overlay">
                                        <i class="fa-solid fa-eye-slash"></i>
                                        <span>Bu inceleme spoiler içeriyor. Görmek için tıklayın.</span>
                                    </div>
                                    <div class="spoiler-content">
                                        <div class="review-text-content">${this.parseContent(post.text)}</div>
                                    </div>
                                </div>
                            ` : `
                                <div class="review-text-content" style="margin-bottom:15px;">${this.parseContent(post.text)}</div>
                            `}
                        ` : ''}

                        <!-- Category Scores -->
                        ${r?.categories ? `
                        <div class="review-categories-grid">
                            ${Object.entries(r.categories).map(([cat, score]) => `
                                <div class="category-score-item">
                                    <span class="cat-label">${cat}</span>
                                    <div class="cat-bar-bg">
                                        <div class="cat-bar-fill" style="width:${score * 10}%;"></div>
                                    </div>
                                    <span class="cat-score">${score}</span>
                                </div>
                            `).join('')}
                        </div>` : ''}

                        <!-- Footer Actions -->
                        <div class="post-footer">
                            <div class="post-stats">
                                <button class="post-action-btn ${post.likes?.includes(State.currentUser?.id) ? 'liked' : ''}" onclick="SocialFeed.toggleLike('${post.id}')">
                                    <i class="fa-${post.likes?.includes(State.currentUser?.id) ? 'solid' : 'regular'} fa-heart"></i> ${post.likes?.length || 0}
                                </button>
                                <button class="post-action-btn" onclick="SocialFeed.toggleComments('${post.id}')">
                                    <i class="fa-regular fa-comment"></i> ${post.comments?.length || 0}
                                </button>
                            </div>
                            <button class="post-action-btn" onclick="SocialFeed.sharePost('${post.id}')" title="Paylaş"><i class="fa-solid fa-share-nodes"></i></button>
                        </div>
                        <div id="comments-section-${post.id}" style="display:none;"></div>
                    </div>
                `;
            });
        }

        return html;
    },

    openReviewModal(options = {}) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('İnceleme yazmak için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }

        const overlay = document.createElement('div');
        overlay.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.7); backdrop-filter:blur(8px); z-index:9999; display:flex; align-items:center; justify-content:center;';
        overlay.id = 'review-modal-overlay';
        overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

        const allContent = [...(State.data.series || []), ...(State.data.webtoons || [])].sort((a,b) => a.title.localeCompare(b.title));
        const selectedId = options.seriesId || '';

        overlay.innerHTML = `
            <div style="background:#0f0f13; border:1px solid rgba(255,255,255,0.08); border-radius:24px; width:90%; max-width:600px; max-height:85vh; overflow-y:auto; padding:28px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <h2 style="color:#fff; font-size:1.3rem; font-weight:800;"><i class="fa-solid fa-star" style="color:#f59e0b;"></i> ${options.title ? `${options.title} - İnceleme` : 'İçerik İncelemesi'}</h2>
                    <button onclick="document.getElementById('review-modal-overlay').remove()" style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); color:#94a3b8; width:34px; height:34px; border-radius:50%; cursor:pointer;">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>

                <div style="margin-bottom:16px;">
                    <label style="color:#94a3b8; font-size:0.8rem; font-weight:600; display:block; margin-bottom:6px;">Dizi / İçerik Seçin</label>
                    <select id="review-series-id" style="width:100%; padding:10px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#e2e8f0; outline:none; font-family:'Inter',sans-serif;">
                        <option value="">-- İçerik Seçin --</option>
                        ${allContent.map(s => `<option value="${s.id}" ${s.id === selectedId ? 'selected' : ''}>${s.title} ${s.type === 'movie' ? '🎬' : s.type === 'webtoon' ? '📖' : '📺'}</option>`).join('')}
                    </select>
                </div>

                <div style="margin-bottom:16px;">
                    <label style="color:#94a3b8; font-size:0.8rem; font-weight:600; display:block; margin-bottom:10px;">Kategori Puanları (1-10)</label>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span style="color:#e2e8f0; font-size:0.85rem; min-width:70px;">Hikaye</span>
                            <input type="range" id="review-story" min="1" max="10" value="7" oninput="document.getElementById('review-story-val').textContent=this.value" style="flex:1;">
                            <span id="review-story-val" style="color:#f59e0b; font-weight:700; min-width:20px;">7</span>
                        </div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span style="color:#e2e8f0; font-size:0.85rem; min-width:70px;">Oyunculuk</span>
                            <input type="range" id="review-acting" min="1" max="10" value="7" oninput="document.getElementById('review-acting-val').textContent=this.value" style="flex:1;">
                            <span id="review-acting-val" style="color:#f59e0b; font-weight:700; min-width:20px;">7</span>
                        </div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span style="color:#e2e8f0; font-size:0.85rem; min-width:70px;">Görsel</span>
                            <input type="range" id="review-visual" min="1" max="10" value="7" oninput="document.getElementById('review-visual-val').textContent=this.value" style="flex:1;">
                            <span id="review-visual-val" style="color:#f59e0b; font-weight:700; min-width:20px;">7</span>
                        </div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span style="color:#e2e8f0; font-size:0.85rem; min-width:70px;">Müzik</span>
                            <input type="range" id="review-music" min="1" max="10" value="7" oninput="document.getElementById('review-music-val').textContent=this.value" style="flex:1;">
                            <span id="review-music-val" style="color:#f59e0b; font-weight:700; min-width:20px;">7</span>
                        </div>
                    </div>
                </div>

                <div style="margin-bottom:16px;">
                    <label style="color:#94a3b8; font-size:0.8rem; font-weight:600; display:block; margin-bottom:6px;">Genel Puan (1-10)</label>
                    <input type="range" id="review-overall" min="1" max="10" value="7" oninput="document.getElementById('review-overall-val').textContent=this.value" style="width:100%;">
                    <div style="text-align:center; font-size:2rem; font-weight:900; color:#f59e0b;" id="review-overall-val">7</div>
                </div>

                <div style="margin-bottom:16px;">
                    <label style="color:#94a3b8; font-size:0.8rem; font-weight:600; display:block; margin-bottom:6px;">İnceleme Yazısı</label>
                    <textarea id="review-text" placeholder="Bu dizi hakkında ne düşünüyorsun? Spoiler varsa belirt..." style="width:100%; min-height:100px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:12px; color:#e2e8f0; padding:12px; outline:none; resize:vertical; font-family:'Inter',sans-serif;"></textarea>
                </div>

                <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px;">
                    <input type="checkbox" id="review-spoiler-check">
                    <label for="review-spoiler-check" style="color:#f59e0b; font-size:0.85rem; font-weight:600;"><i class="fa-solid fa-eye-slash"></i> Spoiler içeriyor</label>
                </div>

                <button onclick="SocialFeed.submitReview()" style="width:100%; padding:14px; background:linear-gradient(135deg,#f59e0b,#d97706); border:none; color:white; border-radius:14px; font-weight:700; cursor:pointer; font-size:1rem; font-family:'Inter',sans-serif;">
                    <i class="fa-solid fa-star"></i> İncelemeyi Yayınla
                </button>
            </div>
        `;

        document.body.appendChild(overlay);
    },

    submitReview() {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('İnceleme yazmak için giriş yapmalısınız.');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        const contentType = document.getElementById('review-content-type')?.value;
        const seriesId = document.getElementById('review-series-id')?.value;
        const series = (State.data.series || []).find(s => s.id === seriesId);
        
        if (!series) { Toast.warning('Lütfen bir dizi/içerik seçin.'); return; }
        
        const seriesTitle = series.title;
        const text = document.getElementById('review-text')?.value?.trim();
        const overallScore = parseInt(document.getElementById('review-overall')?.value || '7');
        const isSpoiler = document.getElementById('review-spoiler-check')?.checked;

        if (!text) { Toast.warning('İnceleme yazısı boş bırakılamaz.'); return; }

        // Moderation check
        const modCheck = this.moderateContent(text);
        if (!modCheck.clean) { Toast.error('⚠️ ' + modCheck.warnings[0]); return; }

        const categories = {
            'Hikaye': parseInt(document.getElementById('review-story')?.value || '7'),
            'Oyunculuk': parseInt(document.getElementById('review-acting')?.value || '7'),
            'Görsel': parseInt(document.getElementById('review-visual')?.value || '7'),
            'Müzik': parseInt(document.getElementById('review-music')?.value || '7'),
        };

        const post = {
            id: 'review_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            userId: State.currentUser.id,
            text: text,
            isReview: true,
            isSpoiler: isSpoiler || false,
            reviewData: { contentType, seriesId, seriesTitle, overallScore, categories },
            likes: [],
            comments: [],
            createdAt: new Date().toISOString()
        };

        // Extract hashtags & mentions
        post.hashtags = (text.match(/#[a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+/g) || []).map(h => h.toLowerCase());
        post.mentions = (text.match(/@[a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+/g) || []).map(m => m.slice(1));

        this.posts.push(post);
        this.awardSocialXP(15, 'review');
        db.save();

        Toast.success('İnceleme yayınlandı! ⭐');
        document.getElementById('review-modal-overlay')?.remove();
        this.switchTab('reviews', document.querySelector('.social-hub-tab[data-tab="reviews"]'));
    },

    // ==================== BADGES & XP QUESTS TAB ====================
    renderBadgesTab() {
        const user = State.currentUser;
        if (!user) return '<div class="social-empty-state"><p>Giriş yapmalısınız.</p></div>';

        const allBadges = [
            { id: 'first_post', name: 'İlk Paylaşım', icon: 'fa-feather', desc: 'İlk paylaşımını yap', color: '#10b981' },
            { id: 'social_butterfly', name: 'Sosyal Kelebek', icon: 'fa-butterfly', desc: '10 paylaşım yap', color: '#8b5cf6' },
            { id: 'popular', name: 'Popüler', icon: 'fa-fire', desc: '50 beğeni al', color: '#ef4444' },
            { id: 'critic', name: 'Eleştirmen', icon: 'fa-star-half-stroke', desc: '5 İnceleme Yaz', color: '#f59e0b' },
            { id: 'influencer', name: 'Fenomen', icon: 'fa-bolt', desc: '20 Takipçiye Ulaş', color: '#ec4899' },
            { id: 'commenter', name: 'Geveze', icon: 'fa-comments', desc: '25 Yorum Yap', color: '#3b82f6' },
            { id: 'networker', name: 'Sosyalleşmiş', icon: 'fa-user-group', desc: '10 Arkadaş Edin', color: '#10b981' },
            { id: 'veteran', name: 'Efsane', icon: 'fa-trophy', desc: '100 Karma Puanı', color: '#8b5cf6' },
            { id: 'nerd', name: 'Dizi Kurdu', icon: 'fa-tv', desc: '10 Dizi Bitir', color: '#14b8a6' },
            { id: 'marathon', name: 'Maratoncu', icon: 'fa-running', desc: '25 Dizi Bitir', color: '#ef4444' },
        ];

        // Check earned  
        const userPosts = this.posts.filter(p => p.userId === user.id);
        const totalLikes = userPosts.reduce((s, p) => s + (p.likes?.length || 0), 0);
        const totalReviews = userPosts.filter(p => p.isReview).length;
        const totalComments = this.posts.reduce((s, p) => s + (p.comments || []).filter(c => c.userId === user.id).length, 0);

        const earned = {
            first_post: userPosts.length >= 1,
            social_butterfly: userPosts.length >= 10,
            popular: totalLikes >= 50,
            critic: totalReviews >= 5,
            influencer: (user.followers?.length || 0) >= 20,
            commenter: totalComments >= 25,
            networker: (user.friends?.length || 0) >= 10,
            veteran: (user.socialKarma || 0) >= 100,
        };

        // Also show system badges
        const systemBadges = (user.badges || []).filter(b => !['Sosyal Moderatör', 'Moderatör'].includes(b));

        let html = `
            <div style="margin-bottom:20px;">
                <h2 style="color:#fff; font-size:1.3rem; font-weight:800; margin-bottom:16px;"><i class="fa-solid fa-trophy" style="color:#f59e0b;"></i> Rozetler & Başarımlar</h2>
                
                ${systemBadges.length > 0 ? `
                <div style="margin-bottom:20px;">
                    <h3 style="color:#94a3b8; font-size:0.9rem; margin-bottom:12px;">Sistem Rozetleri</h3>
                    <div style="display:flex; flex-wrap:wrap; gap:10px;">
                        ${systemBadges.map(b => `
                            <div style="display:flex; align-items:center; gap:8px; padding:8px 14px; background:rgba(124,58,237,0.1); border:1px solid rgba(124,58,237,0.2); border-radius:12px;">
                                <i class="fa-solid fa-award" style="color:#a78bfa;"></i>
                                <span style="color:#e2e8f0; font-weight:600; font-size:0.85rem;">${b}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>` : ''}

                <h3 style="color:#94a3b8; font-size:0.9rem; margin-bottom:12px;">Sosyal Rozetler</h3>
                <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(160px, 1fr)); gap:12px;">
                    ${allBadges.map(b => {
            const isEarned = earned[b.id];
            return `
                        <div style="background:${isEarned ? `rgba(${b.color === '#10b981' ? '16,185,129' : b.color === '#8b5cf6' ? '139,92,246' : b.color === '#ef4444' ? '239,68,68' : b.color === '#f59e0b' ? '245,158,11' : b.color === '#ec4899' ? '236,72,153' : b.color === '#3b82f6' ? '59,130,246' : b.color === '#14b8a6' ? '20,184,166' : '217,119,6'},0.1)` : 'rgba(255,255,255,0.02)'}; border:1px solid ${isEarned ? b.color + '40' : 'rgba(255,255,255,0.05)'}; border-radius:16px; padding:20px; text-align:center; ${!isEarned ? 'opacity:0.5;' : ''}">
                            <div style="width:50px; height:50px; border-radius:50%; background:${isEarned ? b.color + '20' : 'rgba(255,255,255,0.03)'}; display:flex; align-items:center; justify-content:center; margin:0 auto 10px; font-size:1.3rem;">
                                <i class="fa-solid ${b.icon}" style="color:${isEarned ? b.color : '#475569'};"></i>
                            </div>
                            <div style="font-weight:700; color:${isEarned ? '#fff' : '#64748b'}; font-size:0.85rem;">${b.name}</div>
                            <div style="font-size:0.7rem; color:#64748b; margin-top:4px;">${b.desc}</div>
                            ${isEarned ? '<div style="margin-top:6px; font-size:0.7rem; color:#10b981; font-weight:600;"><i class="fa-solid fa-check-circle"></i> Kazanıldı</div>' : ''}
                        </div>`;
        }).join('')}
                </div>
            </div>

            <!-- XP QUESTS -->
            <div style="margin-top:24px;">
                <h2 style="color:#fff; font-size:1.3rem; font-weight:800; margin-bottom:16px;"><i class="fa-solid fa-scroll" style="color:#a78bfa;"></i> XP Görevleri</h2>
                <div style="display:flex; flex-direction:column; gap:10px;">
                    ${this.renderXPQuests()}
                </div>
            </div>

            <!-- Social Karma Card -->
            <div style="margin-top:24px; background:linear-gradient(135deg,rgba(124,58,237,0.1),rgba(236,72,153,0.1)); border:1px solid rgba(124,58,237,0.15); border-radius:20px; padding:24px; text-align:center;">
                <div style="font-size:2.5rem; font-weight:900; color:#a78bfa;">${user.socialKarma || 0}</div>
                <div style="color:#94a3b8; font-weight:600;">Sosyal Karma</div>
                <div style="color:#64748b; font-size:0.8rem; margin-top:6px;">Paylaşım, beğeni, yorum ve takip ile karma kazan!</div>
            </div>
        `;

        return html;
    },

    renderXPQuests() {
        const user = State.currentUser;
        if (!user) return '';
        const userPosts = this.posts.filter(p => p.userId === user.id);
        const totalComments = this.posts.reduce((s, p) => s + (p.comments || []).filter(c => c.userId === user.id).length, 0);

        const quests = [
            { name: 'İlk Paylaşımını Yap', xp: 10, icon: 'fa-feather', done: userPosts.length >= 1, progress: Math.min(userPosts.length, 1), total: 1 },
            { name: '5 Paylaşım Yap', xp: 25, icon: 'fa-pen', done: userPosts.length >= 5, progress: Math.min(userPosts.length, 5), total: 5 },
            { name: '10 Yorum Yap', xp: 20, icon: 'fa-comments', done: totalComments >= 10, progress: Math.min(totalComments, 10), total: 10 },
            { name: '3 Kişiyi Takip Et', xp: 15, icon: 'fa-user-plus', done: (user.following?.length || 0) >= 3, progress: Math.min(user.following?.length || 0, 3), total: 3 },
            { name: 'Bir İnceleme Yaz', xp: 20, icon: 'fa-star', done: userPosts.filter(p => p.isReview).length >= 1, progress: Math.min(userPosts.filter(p => p.isReview).length, 1), total: 1 },
            { name: '5 Arkadaş Edin', xp: 30, icon: 'fa-handshake', done: (user.friends?.length || 0) >= 5, progress: Math.min(user.friends?.length || 0, 5), total: 5 },
            { name: '20 Beğeni Al', xp: 25, icon: 'fa-heart', done: userPosts.reduce((s, p) => s + (p.likes?.length || 0), 0) >= 20, progress: Math.min(userPosts.reduce((s, p) => s + (p.likes?.length || 0), 0), 20), total: 20 },
            { name: 'Bir Paylaşımı Sabitle', xp: 10, icon: 'fa-thumbtack', done: userPosts.some(p => p.isPinned), progress: userPosts.some(p => p.isPinned) ? 1 : 0, total: 1 },
        ];

        return quests.map(q => {
            const pct = Math.round((q.progress / q.total) * 100);
            return `
                <div style="display:flex; align-items:center; gap:14px; padding:14px; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:14px; ${q.done ? 'border-color:rgba(16,185,129,0.2);' : ''}">
                    <div style="width:42px; height:42px; border-radius:12px; background:${q.done ? 'rgba(16,185,129,0.1)' : 'rgba(255,255,255,0.03)'}; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                        <i class="fa-solid ${q.icon}" style="color:${q.done ? '#10b981' : '#64748b'}; font-size:1rem;"></i>
                    </div>
                    <div style="flex:1; min-width:0;">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                            <span style="font-weight:600; color:${q.done ? '#10b981' : '#e2e8f0'}; font-size:0.85rem; ${q.done ? 'text-decoration:line-through;' : ''}">${q.name}</span>
                            <span style="font-size:0.75rem; color:#f59e0b; font-weight:700;">+${q.xp} XP</span>
                        </div>
                        <div style="height:6px; background:rgba(255,255,255,0.06); border-radius:3px; overflow:hidden;">
                            <div style="height:100%; width:${pct}%; background:${q.done ? '#10b981' : 'linear-gradient(90deg,#7c3aed,#a78bfa)'}; border-radius:3px; transition:width 0.5s;"></div>
                        </div>
                        <div style="font-size:0.65rem; color:#64748b; margin-top:3px;">${q.progress}/${q.total} ${q.done ? '✅' : ''}</div>
                    </div>
                </div>`;
        }).join('');
    },

    renderProfileTab() {
        let user = State.currentUser;
        let isOwnProfile = true;

        if (this.targetUser) {
            let targetUserObj = null;
            if (this.targetUser.startsWith('@')) {
                const username = this.targetUser.substring(1).toLowerCase();
                targetUserObj = (State.data.users || []).find(u => u.username && u.username.toLowerCase() === username);
            } else {
                targetUserObj = (State.data.users || []).find(u => u.id === this.targetUser);
            }

            if (targetUserObj) {
                user = targetUserObj;
                isOwnProfile = (State.currentUser && State.currentUser.id === user.id);
            } else {
                return '<div class="social-empty-state"><i class="fa-solid fa-user-xmark"></i><p>Kullanıcı bulunamadı.</p><button class="post-submit-btn" onclick="SocialFeed.switchTab(\'feed\')">Akışa Dön</button></div>';
            }
        } else if (!user || user.role === 'guest') {
            return this.renderGuestProfileView();
        }

        const userPosts = this.posts.filter(p => p.userId === user.id);
        const stats = user.stats || { level: 1, xp: 0 };
        const level = window.Gamification ? Gamification.getLevel(stats.xp) : stats.level;
        const xpToNext = window.Gamification ? Gamification.getXpToNextLevel(stats.xp) : 100;
        const xpPct = window.Gamification ? Gamification.getLevelProgress(stats.xp) : Math.round((stats.xp / xpToNext) * 100);

        let actionButtonsHtml = '';
        if (!isOwnProfile && State.currentUser) {
            const isFriend = (State.currentUser.friends || []).includes(user.id);
            const isFollowing = (State.currentUser.following || []).includes(user.id);

            actionButtonsHtml = `
                <div style="display:flex; gap:10px; margin-top:15px; flex-wrap:wrap;">
                    <button class="post-submit-btn" style="background:transparent; border:1px solid rgba(255,255,255,0.1);" onclick="SocialFeed.toggleFollow('${user.id}')">
                        <i class="fa-solid ${isFollowing ? 'fa-user-minus' : 'fa-user-plus'}"></i> ${isFollowing ? 'Takipten Çık' : 'Takip Et'}
                    </button>
                    ${isFriend ? `
                        <button class="post-submit-btn" style="background:linear-gradient(135deg,#10b981,#059669);" onclick="App.router('social','messages','${user.id}')"><i class="fa-solid fa-message"></i> Mesaj Gönder</button>
                    ` : `
                        <button class="post-submit-btn" style="background:transparent; border:1px solid rgba(255,255,255,0.1);" onclick="SocialFeed.sendFriendRequest('${user.id}')"><i class="fa-solid fa-user-group"></i> Arkadaş Ekle</button>
                    `}
                </div>
            `;
        } else if (isOwnProfile) {
            actionButtonsHtml = `
                <div style="display:flex; gap:10px; margin-top:15px; flex-wrap:wrap;">
                    <button class="post-submit-btn" style="background:transparent; border:1px solid rgba(255,255,255,0.1);" onclick="SocialFeed.openEditProfileModal()"><i class="fa-solid fa-sliders"></i> Profili Düzenle</button>
                    ${window.ShopSystem ? `<button class="post-submit-btn" style="background:linear-gradient(135deg,rgba(16,185,129,0.1),rgba(5,150,105,0.2)); border:1px solid rgba(16,185,129,0.3); color:#10b981;" onclick="ShopSystem.open()"><i class="fa-solid fa-store"></i> Market</button>` : ''}
                </div>
            `;
        }

        const isPrivate = (user.isPrivate && !isOwnProfile && !(State.currentUser?.friends || []).includes(user.id));

        return `
            <style>
                @media (max-width: 768px) {
                    .social-profile-header-inner { flex-direction: column; text-align: center; }
                    .social-profile-header-actions { justify-content: center; }
                    .social-profile-header-stats { justify-content: center; }
                }
            </style>
            <div class="social-profile-header" style="background:linear-gradient(135deg,rgba(124,58,237,0.1),rgba(236,72,153,0.1)); border:1px solid rgba(124,58,237,0.15); border-radius:30px; padding:30px; margin-bottom:24px;">
                <div class="social-profile-header-inner" style="display:flex; align-items:center; gap:25px; flex-wrap:wrap;">
                    <div style="position:relative; width:120px; height:120px; flex-shrink:0;">
                        <img src="${user.avatar || 'assets/logo.png'}" style="width:120px; height:120px; border-radius:32px; border:4px solid var(--premium-violet); box-shadow:0 0 30px var(--premium-violet-glow); object-fit:cover;">
                        ${isOwnProfile ? `
                        <div onclick="SocialFeed.openAvatarUpload()" title="Profil Fotoğrafını Değiştir" style="position:absolute; inset:0; background:rgba(0,0,0,0.6); border-radius:32px; display:flex; align-items:center; justify-content:center; opacity:0; transition:opacity 0.2s; cursor:pointer;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0'">
                            <i class="fa-solid fa-camera" style="color:white; font-size:1.5rem;"></i>
                        </div>` : ''}
                        <div style="position:absolute; bottom:0; right:0; background:#7c3aed; width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:800; font-size:0.8rem; border:2px solid #0f0f13; z-index:2;">${level}</div>
                    </div>
                    <div style="flex:1; min-width:200px;">
                        <h2 style="color:#fff; font-size:2.2rem; font-weight:900; margin-bottom:5px; display:flex; align-items:center; gap:12px;">
                            ${user.username} 
                            ${user.isPremium || user.badges?.includes('Premium') || user.badges?.includes('VIP') ? 
                                `<i class="fa-solid fa-crown" style="color:#ffd700; font-size:1.5rem; filter:drop-shadow(0 0 10px rgba(255,215,0,0.5));" title="Premium Üye"></i>` : ''}
                            <span style="color:var(--text-secondary); font-size:1.1rem; font-weight:500;">#${user.id}</span>
                        </h2>
                        ${user.mood ? `<div style="color:#a78bfa; font-size:0.85rem; margin-bottom:8px;"><i class="fa-solid fa-face-smile"></i> ${user.mood}</div>` : ''}
                        <div style="display:flex; gap:15px; color:#94a3b8; font-size:0.9rem; margin-bottom:15px;">
                            <span><i class="fa-solid fa-heart" style="color:#ef4444;"></i> ${user.socialKarma || 0} Karma</span>
                            <span><i class="fa-solid fa-users" style="color:#3b82f6;"></i> ${(user.followers || []).length} Takipçi</span>
                            <span><i class="fa-solid fa-user-plus" style="color:#10b981;"></i> ${(user.following || []).length} Takip</span>
                        </div>
                        <div style="background:rgba(255,255,255,0.05); height:10px; border-radius:50px; position:relative; overflow:hidden; margin-bottom:5px;">
                            <div style="position:absolute; inset:0; background:linear-gradient(90deg,#7c3aed,#ec4899); width:${xpPct}%; border-radius:50px; transition:width 0.5s;"></div>
                        </div>
                        <div style="display:flex; justify-content:space-between; font-size:0.75rem; color:#64748b;">
                            <span>${stats.xp} / ${xpToNext} XP</span>
                            <span>Seviye ${level}</span>
                        </div>
                        <div style="display:flex; gap:10px; margin-top:15px; flex-wrap:wrap;">
                            ${!isOwnProfile && State.currentUser ? `
                                <button class="post-submit-btn" style="background:transparent; border:1px solid rgba(255,255,255,0.1); padding:10px 20px;" onclick="SocialFeed.toggleFollow('${user.id}')">
                                    <i class="fa-solid ${(State.currentUser.following || []).includes(user.id) ? 'fa-user-minus' : 'fa-user-plus'}"></i> ${(State.currentUser.following || []).includes(user.id) ? 'Takipten Çık' : 'Takip Et'}
                                </button>
                                <button class="post-submit-btn" style="background:linear-gradient(135deg,#7c3aed,#6d28d9); padding:10px 24px;" onclick="SocialFeed.startChat('${user.id}')">
                                    <i class="fa-solid fa-message"></i> Mesaj Gönder
                                </button>
                                ${!(State.currentUser.friends || []).includes(user.id) ? `
                                    <button class="post-submit-btn" style="background:transparent; border:1px solid rgba(255,255,255,0.1); padding:10px 20px;" onclick="SocialFeed.sendFriendRequest('${user.id}')">
                                        <i class="fa-solid fa-user-group"></i> Arkadaş Ekle
                                    </button>
                                ` : ''}
                            ` : isOwnProfile ? `
                                <button class="post-submit-btn" style="background:transparent; border:1px solid rgba(255,255,255,0.1); padding:10px 20px;" onclick="SocialFeed.openEditProfileModal()"><i class="fa-solid fa-sliders"></i> Profili Düzenle</button>
                                ${window.ShopSystem ? `<button class="post-submit-btn" style="background:linear-gradient(135deg,rgba(16,185,129,0.1),rgba(5,150,105,0.2)); border:1px solid rgba(16,185,129,0.3); color:#10b981; padding:10px 20px;" onclick="ShopSystem.open()"><i class="fa-solid fa-store"></i> Market</button>` : ''}
                            ` : ''}
                        </div>
                    </div>
                </div>
            </div>


            ${isPrivate ? `
                <div class="social-empty-state">
                    <i class="fa-solid fa-lock" style="font-size: 3rem; color: #a78bfa; margin-bottom: 15px;"></i>
                    <h3 style="color: #fff; font-size: 1.2rem; margin-bottom: 8px;">Bu Hesap Gizli</h3>
                    <p style="color: #64748b; font-size: 0.9rem;">Gönderilerini ve detaylı bilgilerini görmek için arkadaş olarak ekle.</p>
                </div>
            ` : `
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:24px;">
                <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:20px; padding:20px;">
                    <h3 style="color:#fff; font-size:1.1rem; font-weight:700; margin-bottom:15px;"><i class="fa-solid fa-award" style="color:#f59e0b;"></i> Son Başarımlar</h3>
                    <div style="display:flex; flex-wrap:wrap; gap:8px;">
                        ${(user.badges || []).slice(0, 5).map(b => `
                            <div style="padding:6px 12px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#e2e8f0; font-size:0.75rem;"><i class="fa-solid fa-medal" style="color:#a78bfa;"></i> ${b}</div>
                        `).join('') || '<p style="color:#64748b; font-size:0.8rem;">Henüz rozet yok.</p>'}
                    </div>
                    <button class="post-submit-btn" style="width:100%; margin-top:15px; padding:8px;" onclick="SocialFeed.switchTab('badges')">Tümünü Gör</button>
                </div>
                ${isOwnProfile ? `
                <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:20px; padding:20px;">
                    <h3 style="color:#fff; font-size:1.1rem; font-weight:700; margin-bottom:15px;"><i class="fa-solid fa-bullseye" style="color:#3b82f6;"></i> Sosyal Görevler</h3>
                    <div>
                        ${this.renderXPQuests()}
                    </div>
                </div>
                ` : ''}
            </div>

            ${isOwnProfile ? this.renderProfileInventorySection(user) : ''}

            ${isOwnProfile ? this.renderProfileDramicPassSection(user) : ''}

            <!-- Actor Cards Collection -->
            <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:24px; padding:25px; margin-bottom:24px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:10px;">
                    <h3 style="color:#fff; font-size:1.2rem; font-weight:800; margin:0;"><i class="fa-solid fa-id-card" style="color:#ffd700; margin-right:10px;"></i> Kartlarım</h3>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <div style="font-size:0.8rem; color:#ffd700; font-weight:700; background:rgba(251,191,36,0.1); padding:4px 12px; border-radius:20px; border:1px solid rgba(251,191,36,0.2);">
                            ${this.getUserCardList(user).length} Kart
                        </div>
                        <button class="post-submit-btn" style="padding:6px 14px; font-size:0.8rem;" onclick="SocialFeed.openAllCardsModal('${user.id}')"><i class="fa-solid fa-layer-group"></i> Tümü</button>
                    </div>
                </div>
                <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap:15px;" id="social-profile-actor-cards">
                    ${this.renderActorCards(user, 8)}
                </div>
            </div>

            <h3 style="color:#fff; font-size:1.3rem; font-weight:800; margin-bottom:16px;"><i class="fa-solid fa-stream" style="color:#a78bfa;"></i> Paylaşımlar (${userPosts.length})</h3>
            <div>
                ${userPosts.length > 0 ? userPosts.map(p => this.renderPostCard(p)).join('') : `
                    <div class="social-empty-state">
                        <i class="fa-solid fa-pen-nib"></i>
                        <p>Henüz bir şey paylaşılmamış.</p>
                        ${isOwnProfile ? `<button class="post-submit-btn" onclick="SocialFeed.openCreatePostModal()">Şimdi Paylaş</button>` : ''}
                    </div>
                `}
            </div>
            `}
        `;
    },

    openAvatarUpload() {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Profil fotoğrafı değiştirmek için üye olmalısınız.');
            if (window.Auth) Auth.showLogin();
            return;
        }
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Check size (2MB)
            if (file.size > 2 * 1024 * 1024) {
                Toast.error('Dosya çok büyük. Maksimum 2MB.');
                return;
            }

            // Check type
            if (!file.type.startsWith('image/')) {
                Toast.error('Lütfen geçerli bir resim dosyası seçin.');
                return;
            }

            const reader = new FileReader();
            reader.onload = (event) => {
                const newAvatar = event.target.result;
                if (State.currentUser) {
                    State.currentUser.avatar = newAvatar;
                    // Also update in State.data.users to reflect globally
                    const globalUser = State.data.users?.find(u => u.id === State.currentUser.id);
                    if (globalUser) {
                        globalUser.avatar = newAvatar;
                        db.save(); // Persist changes
                    }

                    // Re-render
                    Toast.success("Profil fotoğrafı başarıyla güncellendi.");
                    localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser)); // Also update local user object physically
                    this.switchTab('profile', document.querySelector('.social-hub-tab[data-tab="profile"]'));
                }
            };
            reader.readAsDataURL(file);
        };
        input.click();
    },

    renderGuestProfileView() {
        return `
            <div class="social-guest-profile-modern" style="padding: 60px 20px; text-align: center; background: linear-gradient(135deg, rgba(124, 58, 237, 0.05), rgba(236, 72, 153, 0.05)); border-radius: 40px; border: 1px solid rgba(124, 58, 237, 0.1); margin: 20px;">
                <div style="width: 140px; height: 140px; background: rgba(255,255,255,0.02); border: 2px dashed rgba(124, 58, 237, 0.3); border-radius: 40px; display: flex; align-items: center; justify-content: center; margin: 0 auto 30px; position: relative;">
                    <i class="fa-solid fa-user-astronaut" style="font-size: 4rem; color: #a78bfa; filter: drop-shadow(0 0 15px rgba(167, 139, 250, 0.4));"></i>
                    <div style="position: absolute; bottom: -10px; right: -10px; background: #7c3aed; color: white; width: 45px; height: 45px; border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; box-shadow: 0 10px 20px rgba(124, 58, 237, 0.3);">
                        <i class="fa-solid fa-plus"></i>
                    </div>
                </div>
                
                <h1 style="color: #fff; font-size: 2.5rem; font-weight: 900; margin-bottom: 15px; letter-spacing: -1px;">Merhaba <span style="color: #a78bfa;">Misafir!</span></h1>
                <p style="color: #94a3b8; font-size: 1.1rem; max-width: 500px; margin: 0 auto 40px; line-height: 1.6;">
                    Kendi profilini oluşturmak, dizi koleksiyonlarını yönetmek ve topluluğun bir parçası olmak için sadece birkaç adım uzaktasın.
                </p>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; max-width: 800px; margin: 0 auto 40px;">
                    <div style="background: rgba(255,255,255,0.03); padding: 25px; border-radius: 24px; border: 1px solid rgba(255,255,255,0.05); transition: 0.3s;" onmouseenter="this.style.background='rgba(255,255,255,0.05)'" onmouseleave="this.style.background='rgba(255,255,255,0.03)'">
                        <i class="fa-solid fa-medal" style="font-size: 2rem; color: #f59e0b; margin-bottom: 15px;"></i>
                        <h3 style="color: #fff; font-size: 1rem; margin-bottom: 10px;">Rozetler Kazan</h3>
                        <p style="color: #64748b; font-size: 0.85rem;">Etkileşim kurarak seviye atla ve efsanevi rozetlerin sahibi ol.</p>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 25px; border-radius: 24px; border: 1px solid rgba(255,255,255,0.05); transition: 0.3s;" onmouseenter="this.style.background='rgba(255,255,255,0.05)'" onmouseleave="this.style.background='rgba(255,255,255,0.03)'">
                        <i class="fa-solid fa-comments" style="font-size: 2rem; color: #3b82f6; margin-bottom: 15px;"></i>
                        <h3 style="color: #fff; font-size: 1rem; margin-bottom: 10px;">Topluluğa Katıl</h3>
                        <p style="color: #64748b; font-size: 0.85rem;">Diziler hakkında yorum yap, incelemeler yaz ve arkadaşlarınla tartış.</p>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 25px; border-radius: 24px; border: 1px solid rgba(255,255,255,0.05); transition: 0.3s;" onmouseenter="this.style.background='rgba(255,255,255,0.05)'" onmouseleave="this.style.background='rgba(255,255,255,0.03)'">
                        <i class="fa-solid fa-bolt" style="font-size: 2rem; color: #ec4899; margin-bottom: 15px;"></i>
                        <h3 style="color: #fff; font-size: 1rem; margin-bottom: 10px;">Özel İçerikler</h3>
                        <p style="color: #64748b; font-size: 0.85rem;">Sadece üyelere özel koleksiyonları ve gelişmiş istatistikleri keşfet.</p>
                    </div>
                </div>

                <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                    <button class="btn btn-primary" onclick="Auth.showLogin()" style="padding: 16px 45px; border-radius: 18px; font-weight: 800; font-size: 1.1rem; box-shadow: 0 15px 30px rgba(124, 58, 237, 0.3); transform: translateY(0); transition: 0.3s;" onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
                        <i class="fa-solid fa-right-to-bracket"></i> Hemen Giriş Yap
                    </button>
                    <button class="btn btn-outline" onclick="Auth.showRegister()" style="padding: 16px 45px; border-radius: 18px; font-weight: 800; font-size: 1.1rem; border: 2px solid rgba(255,255,255,0.1); background: rgba(255,255,255,0.02);">
                        <i class="fa-solid fa-user-plus"></i> Hesap Oluştur
                    </button>
                </div>
            </div>
        `;
    },

    getUserCardList(user) {
        const resolved = [];
        const seen = new Set();

        (user.actorCards || []).forEach(c => {
            const key = c.id || c.name || c.actorName;
            if (!key || seen.has(key)) return;
            seen.add(key);
            resolved.push({
                id: c.id || key,
                name: c.name || c.actorName || 'Oyuncu',
                avatar: c.avatar || c.image || `https://ui-avatars.com/api/?name=${encodeURIComponent(c.name || c.actorName || 'A')}&background=8b5cf6&color=fff`,
                rarity: (c.rarity || 'common').toLowerCase(),
                kdrama: c.kdrama || ''
            });
        });

        const cardIds = user.gamification?.cards || [];
        const configCards = window.Gamification?.config?.cards || [];
        cardIds.forEach(cid => {
            if (seen.has(cid)) return;
            const def = configCards.find(c => c.id === cid);
            if (def) {
                seen.add(cid);
                resolved.push({ id: def.id, name: def.name, avatar: def.avatar, rarity: def.rarity, kdrama: def.kdrama || '' });
            }
        });

        return resolved;
    },

    renderActorCards(user, limit = null) {
        const cards = this.getUserCardList(user);
        const display = limit ? cards.slice(0, limit) : cards;

        if (display.length === 0) {
            return `<div style="grid-column:1/-1; text-align:center; padding:30px; background:rgba(255,255,255,0.02); border:1px dashed rgba(255,255,255,0.1); border-radius:15px;">
                <i class="fa-solid fa-address-card" style="font-size:2rem; color:rgba(255,255,255,0.1); margin-bottom:10px;"></i>
                <p style="color:#64748b; font-size:0.85rem; margin:0;">Henüz oyuncu kartı kazanılmamış. Sandık açarak kart toplayabilirsin!</p>
                ${user.id === State.currentUser?.id ? `<button class="post-submit-btn" style="margin-top:12px;" onclick="Gamification.openHub()">Sandık & Kart Merkezi</button>` : ''}
            </div>`;
        }

        const rarityColors = { common: '#94a3b8', rare: '#3b82f6', epic: '#a78bfa', legendary: '#fbbf24' };

        return display.map(card => {
            const border = rarityColors[card.rarity] || '#ffd700';
            return `
            <div class="social-actor-card" style="aspect-ratio:2/3; border-radius:12px; overflow:hidden; position:relative; border:2px solid ${border}; background:#000; box-shadow:0 5px 15px rgba(0,0,0,0.3);">
                <img src="${card.avatar}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src='https://ui-avatars.com/api/?name=${encodeURIComponent(card.name)}&background=8b5cf6&color=fff'">
                <div style="position:absolute; bottom:0; left:0; right:0; background:linear-gradient(transparent, rgba(0,0,0,0.9)); padding:10px 5px; text-align:center;">
                    <div style="color:#fff; font-weight:bold; font-size:0.75rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${card.name}</div>
                    <div style="color:${border}; font-size:0.55rem; text-transform:uppercase; font-weight:800; margin-top:2px;">${card.rarity}</div>
                </div>
            </div>`;
        }).join('');
    },

    openAllCardsModal(userId) {
        const user = (State.data.users || []).find(u => u.id === userId) || State.currentUser;
        if (!user) return;
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.cssText = 'display:flex; z-index:100001;';
        modal.innerHTML = `
            <div class="modal-content" style="max-width:900px; width:95%; max-height:85vh; background:#0f0f13; border:1px solid rgba(139,92,246,0.3); border-radius:24px; overflow:hidden; display:flex; flex-direction:column;">
                <div style="padding:20px 25px; border-bottom:1px solid rgba(255,255,255,0.08); display:flex; justify-content:space-between; align-items:center;">
                    <h2 style="margin:0; color:#fff;"><i class="fa-solid fa-id-card" style="color:#fbbf24;"></i> ${user.username} — Tüm Kartlar</h2>
                    <button onclick="this.closest('.modal').remove()" style="background:none; border:none; color:#94a3b8; font-size:1.5rem; cursor:pointer;">×</button>
                </div>
                <div style="padding:25px; overflow-y:auto; flex:1;">
                    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(140px, 1fr)); gap:15px;">
                        ${this.renderActorCards(user)}
                    </div>
                </div>
            </div>`;
        document.body.appendChild(modal);
    },

    renderProfileInventorySection(user) {
        if (window.Gamification) Gamification.initUserGamification();
        const gamif = user.gamification || { chests: { bronz: 0, gumus: 0, altin: 0, efsanevi: 0 }, lastFreeChestTime: 0 };
        const cooldown = 12 * 60 * 60 * 1000;
        const diff = Date.now() - (gamif.lastFreeChestTime || 0);
        const dailyReady = diff >= cooldown;
        const hasVip = user.badges?.includes('VIP') || user.role === 'admin' || user.isVip;
        const chestDefs = window.Gamification?.config?.chests || {};

        return `
            <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(139,92,246,0.15); border-radius:24px; padding:25px; margin-bottom:24px;">
                <h3 style="color:#fff; font-size:1.2rem; font-weight:800; margin:0 0 20px;"><i class="fa-solid fa-box-open" style="color:#a78bfa;"></i> Envanter — Sandıklar</h3>
                <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(200px, 1fr)); gap:14px; margin-bottom:16px;">
                    ${dailyReady ? `
                        <div style="grid-column:1/-1; background:linear-gradient(135deg,rgba(124,58,237,0.12),rgba(236,72,153,0.08)); border:1px solid rgba(139,92,246,0.25); border-radius:16px; padding:16px; display:flex; justify-content:space-between; align-items:center;">
                            <div>
                                <div style="font-weight:800; color:#fff;">🎁 Günlük Sandık Hazır</div>
                                <div style="font-size:0.8rem; color:#a78bfa;">Envanterine düştü — hemen aç!</div>
                            </div>
                            <button class="post-submit-btn" onclick="Gamification.openChest('${hasVip ? 'gumus' : 'bronz'}', true); setTimeout(() => SocialFeed.switchTab('profile', document.querySelector('.social-hub-tab[data-tab=profile]')), 1500)">Aç</button>
                        </div>
                    ` : `<p style="grid-column:1/-1; color:#64748b; font-size:0.85rem;"><i class="fa-solid fa-clock"></i> Günlük sandık: ${window.Gamification ? Gamification.formatRemainingTime(cooldown - diff) : 'bekleniyor'} sonra</p>`}
                    ${Object.keys(chestDefs).map(key => {
                        const count = gamif.chests[key] || 0;
                        const def = chestDefs[key];
                        return `
                        <div style="background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:14px; padding:14px;">
                            <div style="font-weight:800; color:#fff; font-size:0.9rem;">${def.name}</div>
                            <div style="font-size:0.75rem; color:#94a3b8; margin:4px 0 10px;">Adet: <strong style="color:#a78bfa;">${count}</strong></div>
                            <button class="post-submit-btn" style="width:100%; padding:8px; font-size:0.8rem;" ${count <= 0 ? 'disabled' : ''} onclick="Gamification.openChest('${key}', false); setTimeout(() => SocialFeed.switchTab('profile', document.querySelector('.social-hub-tab[data-tab=profile]')), 2000)">Sandığı Aç</button>
                        </div>`;
                    }).join('')}
                </div>
                <button class="post-submit-btn" style="background:transparent; border:1px solid rgba(139,92,246,0.3); color:#a78bfa;" onclick="Gamification.openHub()"><i class="fa-solid fa-gamepad"></i> Tam Envanter Merkezi</button>
            </div>`;
    },

    renderProfileDramicPassSection(user) {
        if (!window.Gamification) return '';
        Gamification.initUserGamification();
        const stats = user.stats || { level: 1, xp: 0 };
        const level = Gamification.getLevel(stats.xp);
        const passTiers = Gamification.config?.passTiers || {};
        const claimedTiers = user.gamification?.claimedTiers || { free: [], vip: [] };
        const hasVip = user.badges?.includes('VIP') || user.role === 'admin' || user.isVip;

        const tierRows = Object.keys(passTiers).sort((a, b) => parseInt(a) - parseInt(b)).slice(0, 6).map(lvl => {
            const tier = passTiers[lvl];
            const lvlNum = parseInt(lvl);
            const canClaim = lvlNum <= level;
            const freeClaimed = (claimedTiers.free || []).includes(lvlNum);
            const vipClaimed = (claimedTiers.vip || []).includes(lvlNum);
            return `
                <div style="padding:12px; background:rgba(255,255,255,0.02); border-radius:12px; border:1px solid rgba(255,255,255,0.05); margin-bottom:8px;">
                    <div style="font-weight:800; color:#fbbf24; margin-bottom:8px;">Seviye ${lvl}</div>
                    <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; margin-bottom:6px;">
                        <span style="color:#94a3b8; font-size:0.85rem;">Ücretsiz: ${tier.free?.label || '-'}</span>
                        ${freeClaimed ? `<span style="color:#10b981; font-size:0.75rem;"><i class="fa-solid fa-check"></i></span>` :
                            canClaim ? `<button class="post-submit-btn" style="padding:4px 12px; font-size:0.7rem;" onclick="Gamification.claimPassTier(${lvlNum}, 'free'); setTimeout(() => SocialFeed.switchTab('profile', document.querySelector('.social-hub-tab[data-tab=profile]')), 800)">Al</button>` :
                            `<span style="color:#64748b; font-size:0.7rem;">Kilitli</span>`}
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
                        <span style="color:#fbbf24; font-size:0.85rem;">VIP: ${tier.vip?.label || '-'}</span>
                        ${vipClaimed ? `<span style="color:#10b981; font-size:0.75rem;"><i class="fa-solid fa-check"></i></span>` :
                            canClaim && hasVip ? `<button class="post-submit-btn" style="padding:4px 12px; font-size:0.7rem; background:#fbbf24; color:#000;" onclick="Gamification.claimPassTier(${lvlNum}, 'vip'); setTimeout(() => SocialFeed.switchTab('profile', document.querySelector('.social-hub-tab[data-tab=profile]')), 800)">Al</button>` :
                            canClaim ? `<span style="color:#64748b; font-size:0.7rem;"><i class="fa-solid fa-crown"></i> VIP gerekli</span>` :
                            `<span style="color:#64748b; font-size:0.7rem;">Kilitli</span>`}
                    </div>
                </div>`;
        }).join('');

        return `
            <div style="background:linear-gradient(135deg,rgba(251,191,36,0.06),rgba(124,58,237,0.06)); border:1px solid rgba(251,191,36,0.2); border-radius:24px; padding:25px; margin-bottom:24px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
                    <h3 style="color:#fff; font-size:1.2rem; font-weight:800; margin:0;"><i class="fa-solid fa-crown" style="color:#fbbf24;"></i> Dramic Pass (Royal Pass)</h3>
                    <span style="font-size:0.8rem; color:#fbbf24; font-weight:700;">Seviye ${level}</span>
                </div>
                <p style="color:#94a3b8; font-size:0.85rem; margin:0 0 16px;">Seviye atladıkça ödüllerin burada birikir. VIP üyeler premium kanaldan ekstra ödül alır.</p>
                ${tierRows || '<p style="color:#64748b;">Pass ödülleri yükleniyor...</p>'}
                <button class="post-submit-btn" style="width:100%; margin-top:12px; background:transparent; border:1px solid rgba(251,191,36,0.3); color:#fbbf24;" onclick="Gamification.switchTab('pass'); Gamification.openHub()"><i class="fa-solid fa-ticket"></i> Tüm Pass Ödüllerini Gör</button>
            </div>`;
    },

    renderFanCenterTab() {
        let actors = State.data?.actors || [];
        if (!actors.length && State.data?.series) {
            const map = new Map();
            State.data.series.forEach(s => {
                (s.cast || s.characters || []).forEach(c => {
                    const name = c.actor || c.name;
                    if (name && !map.has(name)) {
                        map.set(name, { id: name, name, image: c.image || c.avatar || '', fanCount: 0, hasFanClub: true });
                    }
                });
            });
            actors = Array.from(map.values());
        }

        return `
            <div style="margin-bottom:24px;">
                <h2 style="color:#fff; font-size:1.8rem; font-weight:900; margin:0 0 8px;"><i class="fa-solid fa-masks-theater" style="color:#f472b6;"></i> Oyuncu Merkezi</h2>
                <p style="color:#94a3b8; font-size:0.9rem; margin:0;">Tüm oyuncuları keşfet, ara ve fan merkezine gir.</p>
            </div>
            <div style="position:relative; margin-bottom:24px;">
                <i class="fa-solid fa-search" style="position:absolute; left:16px; top:50%; transform:translateY(-50%); color:#64748b;"></i>
                <input type="text" id="fan-center-search" placeholder="Oyuncu adı ara..." oninput="SocialFeed.filterFanCenterActors(this.value)"
                    style="width:100%; padding:14px 16px 14px 44px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.1); border-radius:16px; color:#fff; font-size:1rem; outline:none;">
            </div>
            <div id="fan-center-actors-grid" style="display:grid; grid-template-columns:repeat(auto-fill, minmax(160px, 1fr)); gap:16px;">
                ${this.renderFanCenterActorCards(actors)}
            </div>`;
    },

    renderFanCenterActorCards(actors) {
        if (!actors.length) {
            return `<div style="grid-column:1/-1; text-align:center; padding:60px; color:#64748b;"><i class="fa-solid fa-user-slash" style="font-size:2.5rem; margin-bottom:12px; display:block;"></i>Henüz oyuncu eklenmemiş.</div>`;
        }
        return actors.map(actor => {
            const img = actor.image || actor.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(actor.name)}&background=8b5cf6&color=fff&size=200`;
            const escaped = (actor.name || '').replace(/'/g, "\\'");
            const fans = actor.fanCount || actor.fanCenter?.members?.length || 0;
            return `
                <div class="fan-center-actor-card" data-name="${(actor.name || '').toLowerCase()}" onclick="App.router('actor-detail', '${escaped}')"
                     style="cursor:pointer; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.06); border-radius:20px; overflow:hidden; transition:0.25s;"
                     onmouseenter="this.style.borderColor='rgba(244,114,182,0.4)'; this.style.transform='translateY(-4px)';"
                     onmouseleave="this.style.borderColor='rgba(255,255,255,0.06)'; this.style.transform='';">
                    <div style="aspect-ratio:1; overflow:hidden;">
                        <img src="${img}" alt="${actor.name}" style="width:100%; height:100%; object-fit:cover;" loading="lazy"
                             onerror="this.src='https://ui-avatars.com/api/?name=${encodeURIComponent(actor.name)}&background=8b5cf6&color=fff'">
                    </div>
                    <div style="padding:14px;">
                        <div style="font-weight:800; color:#fff; font-size:0.95rem;">${actor.name}</div>
                        <div style="font-size:0.75rem; color:#f472b6; margin-top:4px;"><i class="fa-solid fa-heart"></i> ${fans} hayran</div>
                        <div style="font-size:0.7rem; color:#64748b; margin-top:6px;">Fan merkezine git →</div>
                    </div>
                </div>`;
        }).join('');
    },

    filterFanCenterActors(query) {
        const q = (query || '').toLowerCase().trim();
        document.querySelectorAll('.fan-center-actor-card').forEach(el => {
            const name = el.getAttribute('data-name') || '';
            el.style.display = !q || name.includes(q) ? '' : 'none';
        });
    },

    openEditProfileModal() {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Profil düzenlemek için üye olmalısınız.');
            if (window.Auth) Auth.showLogin();
            return;
        }
        const user = State.currentUser;

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width:500px; background:#0f0f13; border:1px solid rgba(124,58,237,0.3);">
                <div class="modal-header">
                    <h2><i class="fa-solid fa-user-gear"></i> Profili Düzenle</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Kullanıcı Adı</label>
                        <input type="text" id="edit-profile-username" class="form-input" value="${user.username || ''}">
                    </div>
                    <div class="form-group">
                        <label>Ruh Hali / Durum</label>
                        <input type="text" id="edit-profile-mood" class="form-input" value="${user.mood || ''}" placeholder="Nasıl hissediyorsun?">
                    </div>
                    <div class="form-group">
                        <label>Hakkında</label>
                        <textarea id="edit-profile-bio" class="form-input" rows="3" placeholder="Kendinden bahset...">${user.bio || ''}</textarea>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px; margin-top:10px; padding:10px; background:rgba(255,255,255,0.02); border-radius:10px;">
                        <input type="checkbox" id="edit-profile-private" ${user.isPrivate ? 'checked' : ''}>
                        <label for="edit-profile-private" style="margin:0; cursor:pointer;">Gizli Profil (Sadece arkadaşlar görebilir)</label>
                    </div>
                    <button onclick="SocialFeed.saveProfileChanges(this)" class="btn btn-primary btn-block" style="margin-top:20px; background:linear-gradient(135deg,#7c3aed,#ec4899); border:none;">Kaydet</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    saveProfileChanges(btn) {
        const username = document.getElementById('edit-profile-username').value.trim();
        const mood = document.getElementById('edit-profile-mood').value.trim();
        const bio = document.getElementById('edit-profile-bio').value.trim();
        const isPrivate = document.getElementById('edit-profile-private').checked;

        if (!username) {
            Toast.error('Kullanıcı adı boş olamaz!');
            return;
        }

        // Update State
        State.currentUser.username = username;
        State.currentUser.mood = mood;
        State.currentUser.bio = bio;
        State.currentUser.isPrivate = isPrivate;

        // Update global user list
        const globalUser = State.data.users?.find(u => u.id === State.currentUser.id);
        if (globalUser) {
            globalUser.username = username;
            globalUser.mood = mood;
            globalUser.bio = bio;
            globalUser.isPrivate = isPrivate;
        }

        db.save();
        localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        
        Toast.success('Profil güncellendi!');
        btn.closest('.modal').remove();
        this.render(); // Re-render feed and profile
    },

    awardSocialXP(amount, action) {
        if (!State.currentUser) return;
        if (!State.currentUser.socialKarma) State.currentUser.socialKarma = 0;
        State.currentUser.socialKarma += amount;

        // Award to main XP via Gamification module
        if (window.Gamification && Gamification.addXP) {
            Gamification.addXP(amount, `Sosyal Etkinlik: ${action} `);
        } else if (State.currentUser.stats) {
            if (!State.currentUser.stats.xp) State.currentUser.stats.xp = 0;
            State.currentUser.stats.xp += amount;
        }

        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
    },


    // ==================== SOCIAL NOTIFICATIONS ====================
    sendSocialNotification(targetUserId, title, message, type = 'social', link = '') {
        const target = State.data.users?.find(u => u.id === targetUserId);
        if (!target || targetUserId === State.currentUser?.id) return;
        
        // Update local state
        if (!target.notifications) target.notifications = [];
        const notifId = 'notif_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
        target.notifications.push({
            id: notifId,
            title,
            message,
            timestamp: new Date().toISOString(),
            read: false,
            type,
            link: link || `detail/social/post/${notifId}`
        });

        db.saveDebounced ? db.saveDebounced() : db.save();
        console.log(`🔔 Notification locally sent to ${target.username}: ${title}`);
    },

    // ==================== EMOJI REACTIONS ====================
    toggleReaction(postId, emoji) {
        if (!State.currentUser || State.currentUser.role === 'guest') { 
            Toast.warning('Tepki vermek için üye olmalısınız.'); 
            if (window.Auth) Auth.showLogin();
            return; 
        }
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;
        if (!post.reactions) post.reactions = {};
        if (!post.reactions[emoji]) post.reactions[emoji] = [];

        const idx = post.reactions[emoji].indexOf(State.currentUser.id);
        if (idx > -1) {
            post.reactions[emoji].splice(idx, 1);
        } else {
            // Remove from other reactions first (one reaction per user per post)
            ['❤️', '🔥', '😂', '😢', '🤯'].forEach(e => {
                if (post.reactions[e]) {
                    const i = post.reactions[e].indexOf(State.currentUser.id);
                    if (i > -1) post.reactions[e].splice(i, 1);
                }
            });
            post.reactions[emoji].push(State.currentUser.id);

            // Notify post owner
            if (post.userId !== State.currentUser.id) {
                this.sendSocialNotification(post.userId, `${emoji} Tepki!`, `${State.currentUser.username} paylaşımına ${emoji} tepki verdi.`, 'reaction', `detail/social/post/${postId}`);
            }
            // Karma for owner
            const owner = State.data.users?.find(u => u.id === post.userId);
            if (owner && owner.id !== State.currentUser.id) {
                if (!owner.socialKarma) owner.socialKarma = 0;
                owner.socialKarma += 1;
            }
            this.awardSocialXP(1, 'reaction');
        }
        // OPTIMISTIC DOM UPDATE
        const btns = document.querySelectorAll(`button[onclick*="toggleReaction('${postId}'"]`);
        if (btns.length > 0) {
            const container = btns[0].parentElement;
            if (container && container.classList.contains('emoji-reactions')) {
                container.innerHTML = ['❤️', '🔥', '😂', '😢', '🤯'].map(e => {
                    const count = (post.reactions?.[e] || []).length;
                    const reacted = (post.reactions?.[e] || []).includes(State.currentUser?.id);
                    return `<button class="post-action-btn ${reacted ? 'liked' : ''}" onclick="SocialFeed.toggleReaction('${post.id}','${e}')" style="font-size:0.85rem; padding:4px 8px; min-width:auto; ${reacted ? 'background:rgba(124,58,237,0.12);border-radius:8px;' : ''}">${e} ${count > 0 ? `<span style='font-size:0.7rem;'>${count}</span>` : ''}</button>`;
                }).join('');
            }
        }

        // BACKEND SYNC
        this.syncReaction(postId, emoji);
    },

    syncReaction(postId, emoji) {
        // In local mode, reactions are already updated in toggleReaction and saved via db.save()
        db.saveDebounced ? db.saveDebounced() : db.save();
    },

    // ==================== REPOST ====================
    repost(postId) {
        if (!State.currentUser || State.currentUser.role === 'guest') { 
            Toast.warning('Yeniden paylaşmak için üye olmalısınız.'); 
            if (window.Auth) Auth.showLogin();
            return; 
        }
        const original = this.posts.find(p => p.id === postId);
        if (!original) return;
        if (original.userId === State.currentUser.id) { Toast.info('Kendi paylaşımınızı yeniden paylaşamazsınız.'); return; }

        // Check if already reposted
        const alreadyReposted = this.posts.some(p => p.originalPostId === postId && p.repostedBy === State.currentUser.id);
        if (alreadyReposted) { Toast.info('Bu paylaşımı zaten yeniden paylaştınız.'); return; }

        const repost = {
            ...JSON.parse(JSON.stringify(original)),
            id: 'repost_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            repostedBy: State.currentUser.id,
            originalPostId: postId,
            createdAt: new Date().toISOString(),
            likes: [],
            reactions: {},
            comments: []
        };

        this.posts.push(repost);
        this.sendSocialNotification(original.userId, '🔁 Yeniden Paylaşım!', `${State.currentUser.username} paylaşımını yeniden paylaştı.`, 'repost');
        this.awardSocialXP(3, 'repost');
        db.save();
        Toast.success('Yeniden paylaşıldı! 🔁');
        this.switchTab('feed', document.querySelector('.social-hub-tab[data-tab="feed"]'));
    },

    // ==================== REPORT POST ====================
    reportPost(postId) {
        if (!State.currentUser) { Toast.warning('Giriş yapmalısınız.'); return; }
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;

        const reason = prompt('Bildirim sebebi seçin:\n1. Uygunsuz İçerik\n2. Spam\n3. Nefret Söylemi\n4. Spoiler (İşaretlenmemiş)\n5. Diğer');
        if (!reason) return;

        const reasons = { '1': 'Uygunsuz İçerik', '2': 'Spam', '3': 'Nefret Söylemi', '4': 'İşaretlenmemiş Spoiler', '5': 'Diğer' };
        if (!State.data.postReports) State.data.postReports = [];

        State.data.postReports.push({
            id: 'report_' + Date.now(),
            postId: postId,
            reportedBy: State.currentUser.id,
            reportedUser: post.userId,
            reason: reasons[reason] || 'Diğer',
            timestamp: new Date().toISOString(),
            status: 'pending'
        });

        // Notify admins
        const admins = (State.data.users || []).filter(u => u.role === 'admin');
        const adminsList = admins;
        adminsList.forEach(admin => {
            this.sendSocialNotification(admin.id, '🚩 Yeni Rapor!', `${State.currentUser.username} bir paylaşımı raporladı: ${reasons[reason] || 'Diğer'} `, 'report');
        });

        db.save();
        Toast.success('Rapor gönderildi. Yöneticiler inceleyecek.');
    },

    // ==================== BLOCK / UNBLOCK ====================
    blockUser(userId) {
        if (!State.currentUser) return;
        if (userId === State.currentUser.id) { Toast.info('Kendinizi engelleyemezsiniz.'); return; }
        if (!State.currentUser.blockedUsers) State.currentUser.blockedUsers = [];

        if (!State.currentUser.blockedUsers.includes(userId)) {
            State.currentUser.blockedUsers.push(userId);
            // Also unfollow
            const fIdx = (State.currentUser.following || []).indexOf(userId);
            if (fIdx > -1) State.currentUser.following.splice(fIdx, 1);
            // Remove from friends
            const frIdx = (State.currentUser.friends || []).indexOf(userId);
            if (frIdx > -1) State.currentUser.friends.splice(frIdx, 1);

            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            db.save();
            Toast.success('Kullanıcı engellendi. 🚫');
            this.switchTab(this.currentTab, document.querySelector(`.social - hub - tab[data - tab="${this.currentTab}"]`));
        }
    },

    unblockUser(userId) {
        if (!State.currentUser?.blockedUsers) return;
        const idx = State.currentUser.blockedUsers.indexOf(userId);
        if (idx > -1) {
            State.currentUser.blockedUsers.splice(idx, 1);
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            db.save();
            Toast.success('Engel kaldırıldı.');
        }
    },

    // ==================== MOOD STATUS ====================
    setMood(mood) {
        if (!State.currentUser || State.currentUser.role === 'guest') return;
        State.currentUser.mood = mood;
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        
        // Update in global users list
        const globalUser = State.data.users?.find(u => u.id === State.currentUser.id);
        if (globalUser) {
            globalUser.mood = mood;
        }
        db.save();
        
        Toast.success(mood ? `Ruh halin güncellendi: ${mood}` : `Ruh hali kaldırıldı`);
        
        // Refresh UI
        setTimeout(() => {
            const activeTabBtn = document.querySelector('.social-hub-tab.active');
            if (activeTabBtn) {
                this.switchTab(this.currentTab, activeTabBtn);
            } else {
                this.render();
            }
        }, 100);
    },

    showMoodPicker() {
        if (!State.currentUser || State.currentUser.role === 'guest') { 
            Toast.warning('Ruh halini belirlemek için üye olmalısınız.'); 
            return; 
        }
        const moods = [
            '🎬 İzliyor', '✍️ İnceleme Yazıyor', '📖 Webtoon Okuyor',
            '🎮 Müsait', '😴 Uzakta', '🎵 Müzik Dinliyor',
            '🍿 Film/Dizi Arıyor', '💬 Sohbet Etmek İstiyor', '📚 Manga Okuyor'
        ];

        const overlay = document.createElement('div');
        overlay.id = 'mood-picker-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);backdrop-filter:blur(6px);z-index:9999;display:flex;align-items:center;justify-content:center;';
        overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

        overlay.innerHTML = `
            <div style="background:#0f0f13;border:1px solid rgba(255,255,255,0.08);border-radius:24px;padding:28px;width:95%;max-width:400px;box-shadow:0 20px 50px rgba(0,0,0,0.5);animation:modalFadeIn 0.3s ease-out;">
                <h3 style="color:#fff;font-weight:800;margin-bottom:20px;display:flex;align-items:center;gap:12px;">
                    <i class="fa-solid fa-moon" style="color:#a78bfa;"></i> Ruh Halini Belirle
                </h3>
                <div style="display:grid;grid-template-columns:1fr;gap:10px;max-height:60vh;overflow-y:auto;padding-right:5px;" class="custom-scrollbar">
                    ${moods.map(m => `
                        <button onclick="SocialFeed.setMood('${m}'); document.getElementById('mood-picker-overlay').remove();"
                            style="padding:14px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:15px;color:#e2e8f0;cursor:pointer;text-align:left;font-size:0.95rem;font-weight:600;font-family:'Inter',sans-serif; transition:all 0.2s;display:flex;align-items:center;gap:10px;"
                            onmouseenter="this.style.background='rgba(124,58,237,0.1)';this.style.borderColor='rgba(124,58,237,0.3)';this.style.transform='translateX(5px)'"
                            onmouseleave="this.style.background='rgba(255,255,255,0.03)';this.style.borderColor='rgba(255,255,255,0.06)';this.style.transform='none'">${m}</button>
                    `).join('')}
                </div>
                <button onclick="SocialFeed.setMood(''); document.getElementById('mood-picker-overlay').remove();"
                    style="width:100%;margin-top:20px;padding:14px;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.15);border-radius:15px;color:#ef4444;cursor:pointer;font-weight:700;font-family:'Inter',sans-serif;transition:all 0.2s;"
                    onmouseenter="this.style.background='rgba(239,68,68,0.15)'"
                    onmouseleave="this.style.background='rgba(239,68,68,0.08)'">
                    <i class="fa-solid fa-xmark"></i> Durumu Kaldır
                </button>
            </div>
        `;
        document.body.appendChild(overlay);
    },

    // ==================== PRIVACY SETTINGS ====================
    showPrivacySettings() {
        if (!State.currentUser) { Toast.warning('Giriş yapmalısınız.'); return; }
        const u = State.currentUser;

        const overlay = document.createElement('div');
        overlay.id = 'privacy-settings-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);backdrop-filter:blur(6px);z-index:9999;display:flex;align-items:center;justify-content:center;';
        overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

        overlay.innerHTML = `
            <div style="background:#0f0f13;border:1px solid rgba(255,255,255,0.08);border-radius:28px;padding:32px;width:95%;max-width:450px;box-shadow:0 25px 60px rgba(0,0,0,0.6);animation:modalFadeIn 0.3s ease-out;">
                <h3 style="color:#fff;font-weight:800;margin-bottom:24px;display:flex;align-items:center;gap:12px;">
                    <i class="fa-solid fa-lock" style="color:#f59e0b;"></i> Gizlilik Ayarları
                </h3>

                <div style="margin-bottom:20px;">
                    <label style="color:#94a3b8;font-size:0.85rem;font-weight:600;display:block;margin-bottom:10px;">Profil Görünürlüğü</label>
                    <select id="privacy-profile" style="width:100%;padding:14px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:14px;color:#e2e8f0;outline:none;font-family:'Inter',sans-serif;cursor:pointer;transition:border-color 0.2s;">
                        <option value="public" ${(u.privacy?.profile || 'public') === 'public' ? 'selected' : ''}>🌍 Herkese Açık</option>
                        <option value="friends" ${u.privacy?.profile === 'friends' ? 'selected' : ''}>👥 Sadece Arkadaşlar</option>
                        <option value="followers" ${u.privacy?.profile === 'followers' ? 'selected' : ''}>🔒 Sadece Takipçiler</option>
                    </select>
                </div>

                <div style="margin-bottom:20px;">
                    <label style="color:#94a3b8;font-size:0.85rem;font-weight:600;display:block;margin-bottom:10px;">Varsayılan Paylaşım Gizliliği</label>
                    <select id="privacy-posts" style="width:100%;padding:14px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:14px;color:#e2e8f0;outline:none;font-family:'Inter',sans-serif;cursor:pointer;">
                        <option value="public" ${(u.privacy?.posts || 'public') === 'public' ? 'selected' : ''}>🌍 Herkese Açık</option>
                        <option value="followers" ${u.privacy?.posts === 'followers' ? 'selected' : ''}>🔒 Sadece Takipçiler</option>
                    </select>
                </div>

                <div style="margin-bottom:24px;">
                    <label style="color:#94a3b8;font-size:0.85rem;font-weight:600;display:block;margin-bottom:10px;">Mesaj Alabilme</label>
                    <select id="privacy-messages" style="width:100%;padding:14px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:14px;color:#e2e8f0;outline:none;font-family:'Inter',sans-serif;cursor:pointer;">
                        <option value="everyone" ${(u.privacy?.messages || 'everyone') === 'everyone' ? 'selected' : ''}>🌍 Herkes Mesaj Atabilir</option>
                        <option value="friends" ${u.privacy?.messages === 'friends' ? 'selected' : ''}>👥 Sadece Arkadaşlar</option>
                    </select>
                </div>

                ${(u.blockedUsers || []).length > 0 ? `
                <div style="margin-bottom:24px;">
                    <label style="color:#94a3b8;font-size:0.85rem;font-weight:600;display:block;margin-bottom:12px;">Engellenen Kullanıcılar (${u.blockedUsers.length})</label>
                    <div style="max-height:150px;overflow-y:auto;padding-right:5px;" class="custom-scrollbar">
                        ${u.blockedUsers.map(bid => {
            const bu = State.data.users?.find(x => x.id === bid);
            return `<div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:rgba(255,255,255,0.03);border-radius:14px;margin-bottom:8px;border:1px solid rgba(255,255,255,0.05);">
                                <span style="color:#e2e8f0;font-size:0.9rem;">${bu?.username || bid}</span>
                                <button onclick="SocialFeed.unblockUser('${bid}');document.getElementById('privacy-settings-overlay').remove();SocialFeed.showPrivacySettings();" style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);color:#10b981;padding:6px 14px;border-radius:10px;cursor:pointer;font-size:0.8rem;font-weight:700;transition:all 0.2s;" onmouseenter="this.style.background='rgba(16,185,129,0.2)'" onmouseleave="this.style.background='rgba(16,185,129,0.1)'">Engeli Kaldır</button>
                            </div>`;
        }).join('')}
                    </div>
                </div>
                ` : ''
            }

<button onclick="SocialFeed.savePrivacySettings()" style="width:100%;padding:12px;background:linear-gradient(135deg,#7c3aed,#6d28d9);border:none;color:white;border-radius:12px;font-weight:700;cursor:pointer;font-family:'Inter',sans-serif;">
    <i class="fa-solid fa-check"></i> Kaydet
</button>
            </div >
    `;
        document.body.appendChild(overlay);
    },

    savePrivacySettings() {
        if (!State.currentUser) return;
        if (!State.currentUser.privacy) State.currentUser.privacy = {};
        State.currentUser.privacy.profile = document.getElementById('privacy-profile')?.value || 'public';
        State.currentUser.privacy.posts = document.getElementById('privacy-posts')?.value || 'public';
        State.currentUser.privacy.messages = document.getElementById('privacy-messages')?.value || 'everyone';
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        
        // Update globally
        const globalUser = State.data.users?.find(u => u.id === State.currentUser.id);
        if (globalUser) {
            globalUser.privacy = State.currentUser.privacy;
        }
        db.save();
        
        document.getElementById('privacy-settings-overlay')?.remove();
        Toast.success('Gizlilik ayarları kaydedildi! 🔒');
    },

    // ==================== WATCHLIST SHARING ====================
    showWatchlistModal() {
        if (!State.currentUser) { Toast.warning('Giriş yapmalısınız.'); Auth.showLogin(); return; }

        const overlay = document.createElement('div');
        overlay.id = 'watchlist-modal-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);backdrop-filter:blur(8px);z-index:9999;display:flex;align-items:center;justify-content:center;';
        overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

        overlay.innerHTML = `
            <div style="background:#0f0f13;border:1px solid rgba(255,255,255,0.08);border-radius:28px;width:95%;max-width:550px;max-height:85vh;overflow-y:auto;padding:32px;box-shadow:0 30px 70px rgba(0,0,0,0.6);animation:modalFadeIn 0.3s ease-out;" class="custom-scrollbar">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
                    <h2 style="color:#fff;font-size:1.4rem;font-weight:800;display:flex;align-items:center;gap:12px;"><i class="fa-solid fa-clipboard-list" style="color:#3b82f6;"></i> İzleme Listesi Paylaş</h2>
                    <button onclick="document.getElementById('watchlist-modal-overlay').remove()" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#94a3b8;width:38px;height:38px;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 0.2s;" onmouseenter="this.style.background='rgba(239,68,68,0.1)';this.style.color='#ef4444'">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>

                <div style="margin-bottom:20px;">
                    <label style="color:#94a3b8;font-size:0.85rem;font-weight:600;display:block;margin-bottom:10px;">Liste Başlığı</label>
                    <input type="text" id="watchlist-title" placeholder="Örn: En İyi 10 K-Drama" style="width:100%;padding:14px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:14px;color:#e2e8f0;outline:none;font-family:'Inter',sans-serif;transition:border-color 0.2s;" onfocus="this.style.borderColor='rgba(59,130,246,0.5)'" onblur="this.style.borderColor='rgba(255,255,255,0.08)'">
                </div>

                <div style="margin-bottom:24px;">
                    <label style="color:#94a3b8;font-size:0.85rem;font-weight:600;display:block;margin-bottom:10px;">Kategori</label>
                    <select id="watchlist-category" style="width:100%;padding:14px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:14px;color:#e2e8f0;outline:none;font-family:'Inter',sans-serif;cursor:pointer;">
                        <option value="K-Drama">K-Drama</option>
                        <option value="Anime">Anime</option>
                        <option value="Webtoon">Webtoon</option>
                        <option value="Kısa Drama">Kısa Drama</option>
                        <option value="Karışık">Karışık</option>
                    </select>
                </div>
                <div style="margin-bottom:20px;">
                    <label style="color:#94a3b8;font-size:0.85rem;font-weight:600;display:block;margin-bottom:10px;">Liste Öğeleri (her satıra bir tane)</label>
                    <textarea id="watchlist-items" placeholder="1. Squid Game\n2. All of Us Are Dead\n3. Sweet Home..." rows="8" style="width:100%;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:14px;color:#e2e8f0;padding:14px;outline:none;resize:vertical;font-family:'Inter',sans-serif;transition:border-color 0.2s;" onfocus="this.style.borderColor='rgba(59,130,246,0.5)'" onblur="this.style.borderColor='rgba(255,255,255,0.08)'"></textarea>
                </div>

                <div style="margin-bottom:24px;">
                    <label style="color:#94a3b8;font-size:0.85rem;font-weight:600;display:block;margin-bottom:10px;">Açıklama (opsiyonel)</label>
                    <textarea id="watchlist-desc" placeholder="Bu liste neden özel..." rows="3" style="width:100%;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:14px;color:#e2e8f0;padding:14px;outline:none;resize:vertical;font-family:'Inter',sans-serif;transition:border-color 0.2s;" onfocus="this.style.borderColor='rgba(59,130,246,0.5)'" onblur="this.style.borderColor='rgba(255,255,255,0.08)'"></textarea>
                </div>

                <button onclick="SocialFeed.submitWatchlist()" style="width:100%;padding:18px;background:linear-gradient(135deg,#3b82f6,#2563eb);border:none;color:white;border-radius:16px;font-weight:800;cursor:pointer;font-size:1.05rem;font-family:'Inter',sans-serif;box-shadow:0 10px 20px rgba(59,130,246,0.3);transition:all 0.2s;" onmouseenter="this.style.transform='translateY(-2px)'" onmouseleave="this.style.transform='none'">
                    <i class="fa-solid fa-clipboard-list"></i> Listeyi Paylaş
                </button>
            </div>
        `;
        document.body.appendChild(overlay);
    },

    submitWatchlist() {
        const title = document.getElementById('watchlist-title')?.value?.trim();
        const category = document.getElementById('watchlist-category')?.value;
        const itemsText = document.getElementById('watchlist-items')?.value?.trim();
        const desc = document.getElementById('watchlist-desc')?.value?.trim();

        if (!title) { Toast.warning('Liste başlığı gerekli.'); return; }
        if (!itemsText) { Toast.warning('En az bir öğe ekleyin.'); return; }

        const items = itemsText.split('\n').filter(l => l.trim()).map(l => l.trim());

        const post = {
            id: 'wl_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            userId: State.currentUser.id,
            text: desc || `📋 ${title}`,
            isWatchlist: true,
            watchlistData: { title, category, items },
            likes: [],
            reactions: {},
            comments: [],
            createdAt: new Date().toISOString(),
            privacy: State.currentUser.privacy?.posts || 'public'
        };

        if (!State.data.socialPosts) State.data.socialPosts = [];
        State.data.socialPosts.unshift(post);
        this.posts = State.data.socialPosts;
        
        this.awardSocialXP(10, 'watchlist');
        db.saveDebounced();

        Toast.success('Liste paylaşıldı! 📋');
        document.getElementById('watchlist-modal-overlay')?.remove();
        
        const activeTabBtn = document.querySelector('.social-hub-tab[data-tab="feed"]');
        if (activeTabBtn) {
            this.switchTab('feed', activeTabBtn);
        } else {
            this.render();
        }
    },

    // ==================== ADMIN BAN SYSTEM ====================
    showAdminBanPanel() {
        if (State.currentUser?.role !== 'admin') { Toast.error('Yetkiniz yok.'); return; }

        const reports = State.data.postReports || [];
        const bannedUsers = State.data.bannedUsers || [];

        const overlay = document.createElement('div');
        overlay.id = 'admin-ban-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);backdrop-filter:blur(8px);z-index:9999;display:flex;align-items:center;justify-content:center;';
        overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

        overlay.innerHTML = `
            <div style="background:#0f0f13;border:1px solid rgba(255,255,255,0.08);border-radius:24px;width:92%;max-width:700px;max-height:85vh;overflow-y:auto;padding:28px;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                    <h2 style="color:#fff;font-size:1.3rem;font-weight:800;"><i class="fa-solid fa-gavel" style="color:#ef4444;"></i> Admin Ban & Raporlar</h2>
                    <button onclick="document.getElementById('admin-ban-overlay').remove()" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#94a3b8;width:34px;height:34px;border-radius:50%;cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
                </div>

                <!-- Quick Ban -->
                <div style="margin-bottom:20px;padding:16px;background:rgba(239,68,68,0.05);border:1px solid rgba(239,68,68,0.1);border-radius:16px;">
                    <h3 style="color:#ef4444;font-weight:700;margin-bottom:10px;"><i class="fa-solid fa-ban"></i> Hızlı Ban</h3>
                    <div style="display:flex;gap:8px;">
                        <input type="text" id="ban-username-input" placeholder="Kullanıcı adı..." style="flex:1;padding:10px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:10px;color:#e2e8f0;outline:none;">
                        <input type="text" id="ban-reason-input" placeholder="Sebep..." style="flex:1;padding:10px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:10px;color:#e2e8f0;outline:none;">
                        <button onclick="SocialFeed.banUserByName()" style="background:#ef4444;border:none;color:white;padding:10px 16px;border-radius:10px;font-weight:700;cursor:pointer;white-space:nowrap;"><i class="fa-solid fa-ban"></i> Banla</button>
                    </div>
                </div>

        <!-- Pending Reports -->
        <div style="margin-bottom:20px;">
            <h3 style="color:#f59e0b;font-weight:700;margin-bottom:10px;"><i class="fa-solid fa-flag"></i> Bekleyen Raporlar (${reports.filter(r => r.status === 'pending').length})</h3>
            <div style="max-height:250px;overflow-y:auto;">
                ${reports.filter(r => r.status === 'pending').map(r => {
            const reporter = State.data.users?.find(u => u.id === r.reportedBy);
            const reported = State.data.users?.find(u => u.id === r.reportedUser);
            return `
                            <div style="padding:12px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);border-radius:12px;margin-bottom:8px;">
                                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                                    <span style="color:#fff;font-weight:600;">${reported?.username || 'Bilinmeyen'}</span>
                                    <span style="color:#f59e0b;font-size:0.75rem;">${r.reason}</span>
                                </div>
                                <div style="color:#64748b;font-size:0.75rem;margin-bottom:8px;">Raporlayan: ${reporter?.username || '?'} · ${new Date(r.timestamp).toLocaleString('tr-TR')}</div>
                                <div style="display:flex;gap:6px;">
                                    <button onclick="SocialFeed.banUser('${r.reportedUser}','${r.reason}');SocialFeed.resolveReport('${r.id}')" style="background:#ef4444;border:none;color:white;padding:6px 12px;border-radius:8px;font-size:0.75rem;font-weight:600;cursor:pointer;">IP Banla</button>
                                    <button onclick="SocialFeed.resolveReport('${r.id}')" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#94a3b8;padding:6px 12px;border-radius:8px;font-size:0.75rem;font-weight:600;cursor:pointer;">Reddet</button>
                                </div>
                            </div>`;
        }).join('') || '<div style="text-align:center;padding:20px;color:#64748b;">Bekleyen rapor yok.</div>'}
            </div>
        </div>

        <!-- Banned Users -->
        <div>
            <h3 style="color:#ef4444;font-weight:700;margin-bottom:10px;"><i class="fa-solid fa-user-slash"></i> Banlı Kullanıcılar (${bannedUsers.length})</h3>
            <div style="max-height:200px;overflow-y:auto;">
                ${bannedUsers.map(b => `
                            <div style="display:flex;align-items:center;justify-content:space-between;padding:10px;background:rgba(239,68,68,0.03);border:1px solid rgba(239,68,68,0.08);border-radius:10px;margin-bottom:6px;">
                                <div>
                                    <div style="font-weight:600;color:#fff;font-size:0.9rem;">${b.username}</div>
                                    <div style="font-size:0.7rem;color:#64748b;">IP: ${b.ip || 'Bilinmiyor'} · ${b.reason || 'Sebep belirtilmedi'}</div>
                                </div>
                                <button onclick="SocialFeed.unbanUser('${b.userId}')" style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);color:#10b981;padding:5px 10px;border-radius:8px;cursor:pointer;font-size:0.75rem;font-weight:600;">Banı Kaldır</button>
                            </div>
                        `).join('') || '<div style="text-align:center;padding:20px;color:#64748b;">Banlı kullanıcı yok.</div>'}
            </div>
        </div>
    </div>
`;
        document.body.appendChild(overlay);
    },

    banUserByName() {
        const username = document.getElementById('ban-username-input')?.value?.trim();
        const reason = document.getElementById('ban-reason-input')?.value?.trim() || 'Kural ihlali';
        if (!username) { Toast.warning('Kullanıcı adı girin.'); return; }

        const user = State.data.users?.find(u => u.username?.toLowerCase() === username.toLowerCase());
        if (!user) { Toast.error('Kullanıcı bulunamadı.'); return; }
        if (user.role === 'admin') { Toast.error('Admin kullanıcılar banlanamaz.'); return; }

        this.banUser(user.id, reason);
    },

    banUser(userId, reason = 'Kural ihlali') {
        if (State.currentUser?.role !== 'admin') return;
        const user = State.data.users?.find(u => u.id === userId);
        if (!user) return;
        if (user.role === 'admin') { Toast.error('Admin kullanıcılar banlanamaz.'); return; }

        if (!State.data.bannedUsers) State.data.bannedUsers = [];
        if (!State.data.bannedIPs) State.data.bannedIPs = [];

        // Get user's IP (simulated - in real app would come from server)
        const userIP = user.lastIP || user.ip || 'unknown_' + userId.slice(0, 8);

        // Check if already banned
        if (State.data.bannedUsers.some(b => b.userId === userId)) {
            Toast.info('Kullanıcı zaten banlı.');
            return;
        }

        State.data.bannedUsers.push({
            userId,
            username: user.username,
            ip: userIP,
            reason,
            bannedAt: new Date().toISOString(),
            bannedBy: State.currentUser.id
        });

        // IP Ban
        if (userIP && !State.data.bannedIPs.includes(userIP)) {
            State.data.bannedIPs.push(userIP);
        }

        // Disable account
        user.isBanned = true;
        user.banReason = reason;

        // Remove all their posts
        this.posts = this.posts.filter(p => p.userId !== userId);

        // Notify 
        this.sendSocialNotification(userId, '🚫 Hesap Yasaklandı', `Hesabınız yasaklandı.Sebep: ${reason} `, 'ban');

        db.save();
        Toast.success(`${user.username} IP banı yedi! 🔨`);

        // Refresh panel
        document.getElementById('admin-ban-overlay')?.remove();
        this.showAdminBanPanel();
    },

    unbanUser(userId) {
        if (State.currentUser?.role !== 'admin') return;
        if (!State.data.bannedUsers) return;

        const banIdx = State.data.bannedUsers.findIndex(b => b.userId === userId);
        if (banIdx > -1) {
            const ban = State.data.bannedUsers[banIdx];
            // Remove IP ban
            if (ban.ip && State.data.bannedIPs) {
                const ipIdx = State.data.bannedIPs.indexOf(ban.ip);
                if (ipIdx > -1) State.data.bannedIPs.splice(ipIdx, 1);
            }
            State.data.bannedUsers.splice(banIdx, 1);

            // Re-enable account
            const user = State.data.users?.find(u => u.id === userId);
            if (user) {
                user.isBanned = false;
                user.banReason = null;
            }

            db.save();
            Toast.success('Ban kaldırıldı.');
            document.getElementById('admin-ban-overlay')?.remove();
            this.showAdminBanPanel();
        }
    },

    resolveReport(reportId) {
        if (!State.data.postReports) return;
        const report = State.data.postReports.find(r => r.id === reportId);
        if (report) {
            report.status = 'resolved';
            db.save();
            document.getElementById('admin-ban-overlay')?.remove();
            this.showAdminBanPanel();
        }
    },

    // ==================== AUTOCOMPLETE SYSTEM ====================
    _autocompleteActive: false,
    _autocompleteType: null,
    _autocompleteQuery: '',
    _autocompleteTarget: null,
    _autocompleteStartPos: -1,

    attachAutocomplete(textarea) {
        if (!textarea || textarea._autocompleteAttached) return;
        textarea._autocompleteAttached = true;

        textarea.addEventListener('input', (e) => this.handleAutocompleteInput(e));
        textarea.addEventListener('keydown', (e) => this.handleAutocompleteKeydown(e));
        textarea.addEventListener('blur', () => {
            setTimeout(() => this.hideAutocompleteDropdown(), 200);
        });
    },

    handleAutocompleteInput(e) {
        const textarea = e.target;
        const cursorPos = textarea.selectionStart;
        const text = textarea.value.substring(0, cursorPos);

        // Find the last # or @ before cursor
        const hashMatch = text.match(/#([a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]*)$/);
        const mentionMatch = text.match(/@([a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]*)$/);

        if (hashMatch) {
            this._autocompleteType = 'hashtag';
            this._autocompleteQuery = hashMatch[1].toLowerCase();
            this._autocompleteStartPos = cursorPos - hashMatch[0].length;
            this._autocompleteTarget = textarea;
            this.showAutocompleteDropdown(textarea);
        } else if (mentionMatch) {
            this._autocompleteType = 'mention';
            this._autocompleteQuery = mentionMatch[1].toLowerCase();
            this._autocompleteStartPos = cursorPos - mentionMatch[0].length;
            this._autocompleteTarget = textarea;
            this.showAutocompleteDropdown(textarea);
        } else {
            this.hideAutocompleteDropdown();
        }
    },

    handleAutocompleteKeydown(e) {
        const dropdown = document.getElementById('social-autocomplete-dropdown');
        if (!dropdown || dropdown.style.display === 'none') return;

        if (e.key === 'Escape') {
            this.hideAutocompleteDropdown();
            e.preventDefault();
        } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            const items = dropdown.querySelectorAll('.autocomplete-item');
            if (items.length === 0) return;
            const active = dropdown.querySelector('.autocomplete-item.active');
            let idx = active ? Array.from(items).indexOf(active) : -1;
            if (active) active.classList.remove('active');
            idx = e.key === 'ArrowDown' ? Math.min(idx + 1, items.length - 1) : Math.max(idx - 1, 0);
            items[idx].classList.add('active');
            items[idx].scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'Enter' || e.key === 'Tab') {
            const active = dropdown.querySelector('.autocomplete-item.active');
            if (active) {
                e.preventDefault();
                active.click();
            }
        }
    },

    showAutocompleteDropdown(textarea) {
        let dropdown = document.getElementById('social-autocomplete-dropdown');
        if (!dropdown) {
            dropdown = document.createElement('div');
            dropdown.id = 'social-autocomplete-dropdown';
            dropdown.style.cssText = `
                position: absolute;
                z-index: 10000;
                background: rgba(15, 15, 20, 0.85);
                backdrop-filter: blur(20px) saturate(180%);
                -webkit-backdrop-filter: blur(20px) saturate(180%);
                border: 1px solid rgba(139, 92, 246, 0.3);
                border-radius: 16px;
                max-height: 280px;
                overflow-y: auto;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.05);
                min-width: 240px;
                padding: 6px;
                transition: opacity 0.2s, transform 0.2s;
            `;
            document.body.appendChild(dropdown);
        }

        let suggestions = [];
        if (this._autocompleteType === 'hashtag') {
            suggestions = this.getHashtagSuggestions(this._autocompleteQuery);
        } else {
            suggestions = this.getMentionSuggestions(this._autocompleteQuery);
        }

        if (suggestions.length === 0) {
            this.hideAutocompleteDropdown();
            return;
        }

        dropdown.innerHTML = suggestions.map((s, i) => `
            <div class="autocomplete-item ${i === 0 ? 'active' : ''}" onclick="SocialFeed.selectAutocomplete('${this.escapeHtml(s.value)}')"
                 style="padding: 10px 14px; cursor: pointer; display: flex; align-items: center; gap: 12px; border-radius: 10px; margin-bottom: 2px; transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); color: #e2e8f0; font-size: 0.9rem; ${i === 0 ? 'background: rgba(139, 92, 246, 0.15); border: 1px solid rgba(139, 92, 246, 0.2);' : 'border: 1px solid transparent;'}"
                 onmouseover="this.style.background='rgba(139, 92, 246, 0.15)'; this.style.borderColor='rgba(139, 92, 246, 0.2)'; document.querySelectorAll('.autocomplete-item').forEach(x=>x.classList.remove('active')); this.classList.add('active');"
                 onmouseout="if(!this.classList.contains('active')){ this.style.background='transparent'; this.style.borderColor='transparent'; }">
                <div style="width: 32px; height: 32px; border-radius: 50%; background: ${s.icon && s.icon.includes('.') ? 'none' : 'rgba(255,255,255,0.05)'}; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; overflow: hidden; border: 1px solid rgba(255,255,255,0.05);">
                    ${s.icon && s.icon.includes('.') ? `<img src="${s.icon}" style="width: 100%; height: 100%; object-fit: cover;">` : (s.icon || (this._autocompleteType === 'hashtag' ? '#' : '👤'))}
                </div>
                <div style="flex: 1; min-width: 0;">
                    <div style="font-weight: 700; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${s.label}</div>
                    ${s.sub ? `<div style="font-size: 0.7rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${s.sub}</div>` : ''}
                </div>
                ${i === 0 ? `<i class="fa-solid fa-arrow-turn-down" style="font-size: 0.7rem; color: rgba(139, 92, 246, 0.5); transform: rotate(90deg);"></i>` : ''}
            </div>
        `).join('');

        // Position near textarea
        const rect = textarea.getBoundingClientRect();
        dropdown.style.display = 'block';
        dropdown.style.left = rect.left + 'px';
        dropdown.style.top = (rect.bottom + 4) + 'px';
        dropdown.style.width = Math.min(rect.width, 320) + 'px';
    },

    hideAutocompleteDropdown() {
        const dropdown = document.getElementById('social-autocomplete-dropdown');
        if (dropdown) dropdown.style.display = 'none';
        this._autocompleteActive = false;
    },

    selectAutocomplete(value) {
        const textarea = this._autocompleteTarget;
        if (!textarea) return;

        const before = textarea.value.substring(0, this._autocompleteStartPos);
        const after = textarea.value.substring(textarea.selectionStart);
        const prefix = this._autocompleteType === 'hashtag' ? '#' : '@';
        textarea.value = before + prefix + value + ' ' + after;

        const newPos = this._autocompleteStartPos + prefix.length + value.length + 1;
        textarea.selectionStart = textarea.selectionEnd = newPos;
        textarea.focus();
        this.hideAutocompleteDropdown();
    },

    getHashtagSuggestions(query) {
        // Collect all unique hashtags from existing posts
        const tagCounts = {};
        (State.data.socialPosts || []).forEach(p => {
            (p.hashtags || []).forEach(h => {
                const tag = h.replace(/^#/, '').toLowerCase();
                tagCounts[tag] = (tagCounts[tag] || 0) + 1;
            });
        });

        return Object.entries(tagCounts)
            .filter(([tag]) => !query || tag.includes(query))
            .sort((a, b) => b[1] - a[1])
            .slice(0, 8)
            .map(([tag, count]) => ({
                value: tag,
                label: '#' + tag,
                sub: count + ' paylaşım',
                icon: '🏷️'
            }));
    },

    getMentionSuggestions(query) {
        const users = State.data.users || [];
        return users
            .filter(u => !query || u.username.toLowerCase().includes(query))
            .slice(0, 8)
            .map(u => ({
                value: u.username,
                label: '@' + u.username,
                sub: u.badges?.includes('Admin') ? 'Yönetici' : (u.badges?.includes('Çevirmen') ? 'Çevirmen' : (u.role === 'moderator' ? 'Moderatör' : 'Üye')),
                icon: u.avatar || '👤'
            }));
    },

    // ==================== STORY SYSTEM ====================
    renderStoriesBar() {
        if (!State.currentUser) return '';
        const isGuest = State.currentUser.role === 'guest';

        // Filter expired stories
        const now = Date.now();
        const activeStories = (State.data.stories || []).filter(s => new Date(s.expiresAt).getTime() > now);

        // Group by user
        const storiesByUser = {};
        activeStories.forEach(s => {
            if (!storiesByUser[s.userId]) storiesByUser[s.userId] = [];
            storiesByUser[s.userId].push(s);
        });

        // Current user story (if any)
        const myStories = storiesByUser[State.currentUser.id] || [];

        return `
            <div class="stories-container custom-scrollbar">
                <!-- Add My Story -->
                <div class="story-item" style="${isGuest ? 'opacity: 0.5; filter: grayscale(1);' : ''}">
                    <div class="story-circle ${myStories.length > 0 ? '' : 'add-story'}" onclick="${isGuest ? 'SocialFeed.openStoryUpload()' : (myStories.length > 0 ? `SocialFeed.viewStories('${State.currentUser.id}')` : 'SocialFeed.openStoryUpload()')}">
                        <img src="${State.currentUser.avatar || 'assets/logo.png'}">
                        ${myStories.length > 0 ? '' : '<div class="add-story-btn"><i class="fa-solid fa-plus"></i></div>'}
                    </div>
                    <div style="display:flex; align-items:center; gap:5px; margin-top:5px;">
                        <span class="story-name">${isGuest ? 'Misafir' : 'Sen'}</span>
                        ${!isGuest && myStories.length > 0 ? `<div onclick="SocialFeed.openStoryUpload()" style="width:18px;height:18px;background:#7c3aed;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:0.6rem;cursor:pointer;"><i class="fa-solid fa-plus"></i></div>` : ''}
                    </div>
                </div>

                <!-- Others Stories -->
                ${Object.entries(storiesByUser).map(([userId, userStories]) => {
            if (userId === State.currentUser.id) return '';
            const user = State.data.users?.find(u => u.id === userId);
            if (!user) return '';
            const allSeen = userStories.every(s => (s.seenBy || []).includes(State.currentUser.id));

            return `
                        <div class="story-item" onclick="SocialFeed.viewStories('${userId}')">
                            <div class="story-circle ${allSeen ? 'seen' : ''}">
                                <img src="${user.avatar || 'assets/logo.png'}">
                            </div>
                            <div class="story-name">${user.username}</div>
                        </div>`;
        }).join('')}
            </div>
        `;
    },

    openStoryUpload() {
        if (!State.currentUser || State.currentUser.role === 'guest') { 
            Toast.warning('Hikaye paylaşmak için üye olmalısınız.'); 
            if (window.Auth) Auth.showLogin();
            return; 
        }

        const url = prompt('Hikaye medya linki girin (görsel veya kısa video URL):');
        if (!url || !url.trim()) return;
        const trimmed = url.trim();
        if (!/^https?:\/\//i.test(trimmed)) {
            Toast.error('Geçerli bir http/https linki girin.');
            return;
        }
        const isVideo = /\.(mp4|webm|mov)(\?|$)/i.test(trimmed);
        this.submitStory(trimmed, isVideo ? 'video' : 'image');
    },

    submitStory(url, type) {
        if (!State.data.stories) State.data.stories = [];

        const now = new Date();
        const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24 hours later

        const story = {
            id: 'story_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            userId: State.currentUser.id,
            mediaUrl: url,
            mediaType: type,
            createdAt: now.toISOString(),
            expiresAt: expiresAt.toISOString(),
            seenBy: []
        };

        State.data.stories.push(story);
        this.awardSocialXP(10, 'story');
        db.save();

        Toast.success('Hikayen paylaşıldı! ✨');
        this.render(); // Refresh UI
    },

    viewStories(userId) {
        const userStories = (State.data.stories || [])
            .filter(s => s.userId === userId && new Date(s.expiresAt).getTime() > Date.now())
            .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));

        if (userStories.length === 0) return;

        const user = State.data.users?.find(u => u.id === userId);
        let currentIndex = 0;

        const showStory = (index) => {
            const story = userStories[index];
            if (!story) {
                overlay.remove();
                return;
            }

            // Mark as seen
            if (!story.seenBy) story.seenBy = [];
            if (State.currentUser && !story.seenBy.includes(State.currentUser.id)) {
                story.seenBy.push(State.currentUser.id);
                db.save();
            }

            const isVideo = story.mediaType === 'video';
            const mediaHtml = isVideo
                ? `<video src="${story.mediaUrl}" class="story-media" autoplay playsinline></video>`
                : `<img src="${story.mediaUrl}" class="story-media">`;

            viewer.innerHTML = `
                <div class="story-progress-container">
                    ${userStories.map((_, i) => `<div class="story-progress-bar"><div class="story-progress-fill" style="width: ${i < index ? '100%' : (i === index ? '0%' : '0%')}"></div></div>`).join('')}
                </div>
                <div class="story-overlay-header">
                    <img src="${user?.avatar || 'assets/logo.png'}" style="width: 32px; height: 32px; border-radius: 50%; border: 1px solid #fff;">
                    <div style="color: #fff; font-weight: 700; font-size: 0.9rem;">${user?.username || 'Gezgin'}</div>
                    <div style="color: rgba(255,255,255,0.7); font-size: 0.75rem;">${this.timeAgo(story.createdAt)}</div>
                </div>
                ${mediaHtml}
            `;

            const fill = viewer.querySelectorAll('.story-progress-fill')[index];
            const duration = isVideo ? 15000 : 5000; // 15s for video, 5s for image

            if (fill) {
                setTimeout(() => {
                    fill.style.transitionDuration = duration + 'ms';
                    fill.style.width = '100%';
                }, 50);
            }

            this._storyTimer = setTimeout(() => {
                currentIndex++;
                if (currentIndex < userStories.length) {
                    showStory(currentIndex);
                } else {
                    overlay.remove();
                }
            }, duration);
        };

        const overlay = document.createElement('div');
        overlay.className = 'story-viewer-overlay';
        overlay.onclick = (e) => {
            if (e.target === overlay || e.target.classList.contains('story-viewer-overlay')) {
                clearTimeout(this._storyTimer);
                overlay.remove();
            }
        };

        const viewer = document.createElement('div');
        viewer.className = 'story-viewer-content';
        overlay.appendChild(viewer);

        const closeBtn = document.createElement('button');
        closeBtn.className = 'story-close-btn';
        closeBtn.innerHTML = '<i class="fa-solid fa-xmark"></i>';
        closeBtn.onclick = () => {
            clearTimeout(this._storyTimer);
            overlay.remove();
        };
        overlay.appendChild(closeBtn);

        document.body.appendChild(overlay);
        showStory(0);
    },

    sharePost(postId) {
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;

        const shareUrl = window.location.origin + window.location.pathname + '?post=' + postId;

        if (navigator.share) {
            navigator.share({
                title: 'Dramicbox Paylaşımı',
                text: post.text?.substring(0, 100) + '...',
                url: shareUrl
            }).catch(e => console.log('Share failed', e));
        } else {
            const temp = document.createElement('input');
            document.body.appendChild(temp);
            temp.value = shareUrl;
            temp.select();
            document.execCommand('copy');
            document.body.removeChild(temp);
            Toast.success('Bağlantı kopyalandı! 🔗');
        }
    },

    parseContent(text) {
        if (!text) return '';
        let html = this.escapeHtml(text);

        // Parse hashtags
        html = html.replace(/#[a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+/g, (tag) => {
            return `<span class="hashtag" onclick="event.stopPropagation(); SocialFeed.filterByTag('${tag}')" style="color:#a78bfa; cursor:pointer; font-weight:600;">${tag}</span>`;
        });

        // Parse mentions
        html = html.replace(/@[a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+/g, (mention) => {
            const username = mention.slice(1);
            return `<span class="mention" onclick="event.stopPropagation(); App.navigate('social/profile/@${username}')" style="color:#60a5fa; cursor:pointer; font-weight:600;">${mention}</span>`;
        });

        // Parse URLs
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        html = html.replace(urlRegex, (url) => {
            return `<a href="${url}" target="_blank" onclick="event.stopPropagation()" style="color:#10b981; text-decoration:underline;">${url}</a>`;
        });

        return html;
    },

    // ==================== ONLINE USERS LIST ====================
    renderOnlineUsersList() {
        const allUsers = State.data.users || [];
        const onlineUsers = allUsers.filter(u => {
            if (u.id === State.currentUser?.id) return false;
            const presence = window.Social ? Social.getUserPresence(u) : { status: 'offline' };
            return presence.status === 'online';
        }).slice(0, 15);

        if (onlineUsers.length === 0) {
            return '<div style="text-align:center; padding:12px; color:#64748b; font-size:0.8rem;">Şu an çevrimiçi kullanıcı yok.</div>';
        }

        return onlineUsers.map(u => `
            <div style="display:flex; align-items:center; gap:10px; padding:6px 4px; cursor:pointer; border-radius:8px; transition:all 0.2s;" onclick="App.navigate('social/profile/@${u.username}')" onmouseenter="this.style.background='rgba(255,255,255,0.04)'" onmouseleave="this.style.background=''">
                <div style="position:relative;">
                    <img src="${u.avatar || 'assets/logo.png'}" style="width:28px; height:28px; border-radius:50%; object-fit:cover;">
                    <span style="position:absolute; bottom:-1px; right:-1px; width:8px; height:8px; border-radius:50%; background:#10b981; border:2px solid #0f0f13;"></span>
                </div>
                <span style="font-size:0.8rem; color:#e2e8f0; font-weight:500;">${u.username}</span>
            </div>
        `).join('');
    },

    // ==================== ANNOUNCEMENTS TAB ====================
    renderAnnouncementsTab() {
        const announcements = (State.data.announcements || []).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        const isAdmin = State.currentUser?.role === 'admin' || State.currentUser?.badges?.includes('Yönetici') || State.currentUser?.badges?.includes('Admin');

        if (announcements.length === 0) {
            return `
                <div style="text-align:center; padding:60px 20px;">
                    <i class="fa-solid fa-bullhorn" style="font-size:3rem; color:#334155; margin-bottom:15px;"></i>
                    <h3 style="color:#94a3b8; margin:0 0 8px;">Henüz Duyuru Yok</h3>
                    <p style="color:#64748b; font-size:0.9rem;">Yöneticiler tarafından paylaşılan duyurular burada görünecek.</p>
                    ${isAdmin ? '<button class="btn btn-primary" onclick="if(window.AdminAnnouncements) AdminAnnouncements.showAddForm()" style="margin-top:15px;"><i class="fa-solid fa-plus"></i> Yeni Duyuru Ekle</button>' : ''}
                </div>`;
        }

        const getCatColor = (cat) => {
            const colors = { 'Genel': '#3b82f6', 'Çevirmen Aranıyor': '#10b981', 'Form': '#f59e0b', 'Güncelleme': '#a855f7', 'Duyuru': '#ec4899' };
            return colors[cat] || '#6b7280';
        };

        const getTimeAgo = (ts) => {
            const diff = Date.now() - ts;
            const mins = Math.floor(diff / 60000);
            const hrs = Math.floor(diff / 3600000);
            const days = Math.floor(diff / 86400000);
            if (mins < 60) return mins + ' dk önce';
            if (hrs < 24) return hrs + ' saat önce';
            if (days < 7) return days + ' gün önce';
            return new Date(ts).toLocaleDateString('tr-TR');
        };

        return `
            <div style="margin-bottom:20px; display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <h2 style="margin:0; color:#fff; font-size:1.3rem; font-weight:800;">📢 Duyurular</h2>
                    <p style="color:#64748b; font-size:0.8rem; margin:4px 0 0;">Topluluk duyuruları ve güncellemeler</p>
                </div>
                ${isAdmin ? '<button class="btn btn-primary" onclick="if(window.AdminAnnouncements) AdminAnnouncements.showAddForm()" style="font-size:0.85rem;"><i class="fa-solid fa-plus"></i> Yeni Duyuru</button>' : ''}
            </div>
            <div style="display:flex; flex-direction:column; gap:16px;">
                ${announcements.map(a => {
                    const catColor = getCatColor(a.category);
                    const isHigh = a.priority === 'high';
                    return `
                    <div style="background: linear-gradient(135deg, rgba(${isHigh ? '239,68,68' : '139,92,246'},0.06), rgba(255,255,255,0.02)); border: 1px solid rgba(${isHigh ? '239,68,68' : '139,92,246'},0.15); border-radius:16px; padding:20px; transition:all 0.3s;" onmouseenter="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 8px 25px rgba(0,0,0,0.2)'" onmouseleave="this.style.transform=''; this.style.boxShadow=''">
                        <div style="display:flex; align-items:center; gap:8px; margin-bottom:12px; flex-wrap:wrap;">
                            <span style="background:${catColor}; color:#fff; padding:4px 12px; border-radius:50px; font-size:0.7rem; font-weight:700; text-transform:uppercase;">${a.category || 'Genel'}</span>
                            ${isHigh ? '<span style="background:#ef4444; color:#fff; padding:4px 10px; border-radius:50px; font-size:0.65rem; font-weight:700;">ÖNEMLİ</span>' : ''}
                            <span style="margin-left:auto; color:#64748b; font-size:0.75rem;"><i class="fa-regular fa-clock"></i> ${getTimeAgo(a.createdAt)}</span>
                        </div>
                        <h3 style="margin:0 0 10px; color:#fff; font-size:1.1rem; font-weight:700;">${a.title}</h3>
                        <p style="margin:0; color:#cbd5e1; font-size:0.9rem; line-height:1.7; white-space:pre-line;">${a.content}</p>
                        ${a.link ? `
                            <a href="${a.link}" target="_blank" style="display:inline-flex; align-items:center; gap:6px; margin-top:14px; padding:8px 18px; background:linear-gradient(135deg, #7c3aed, #6366f1); border-radius:10px; color:#fff; font-size:0.85rem; font-weight:600; text-decoration:none; transition:all 0.2s;" onmouseenter="this.style.transform='translateY(-1px)'" onmouseleave="this.style.transform=''">
                                ${a.linkText || 'Detaylar'} <i class="fa-solid fa-arrow-right" style="font-size:0.7rem;"></i>
                            </a>` : ''}
                        <div style="margin-top:12px; padding-top:10px; border-top:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">
                            <span style="color:#475569; font-size:0.75rem;">${a.createdBy || 'Admin'}</span>
                            <button onclick="SocialFeed.shareAnnouncementToFeed('${a.id}')" style="background:none; border:1px solid rgba(139,92,246,0.2); color:#a78bfa; padding:5px 12px; border-radius:8px; cursor:pointer; font-size:0.75rem; font-weight:600; transition:all 0.2s;" onmouseenter="this.style.background='rgba(139,92,246,0.1)'" onmouseleave="this.style.background=''">
                                <i class="fa-solid fa-share"></i> Paylaş
                            </button>
                        </div>
                    </div>`;
                }).join('')}
            </div>`;
    },

    shareAnnouncementToFeed(announcementId) {
        const a = (State.data.announcements || []).find(ann => ann.id === announcementId);
        if (!a) { Toast.error('Duyuru bulunamadı!'); return; }
        if (!State.currentUser) { Toast.error('Giriş yapmalısınız!'); return; }

        const post = {
            id: 'post_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            userId: State.currentUser.id,
            text: `📢 **${a.title}**\n\n${a.content}${a.link ? '\n\n🔗 ' + (a.linkText || 'Detaylar') + ': ' + a.link : ''}`,
            isSpoiler: false,
            likes: [],
            comments: [],
            createdAt: new Date().toISOString(),
            hashtags: ['duyuru'],
            isAnnouncement: true
        };

        if (!State.data.socialPosts) State.data.socialPosts = [];
        State.data.socialPosts.unshift(post);
        this.posts = State.data.socialPosts;
        if (window.db) db.saveDebounced ? db.saveDebounced() : db.save();
        Toast.success('Duyuru akışta paylaşıldı! 📢');
    },

    approvePost(postId) {
        if (!State.currentUser || State.currentUser.role !== 'admin') return;
        
        const post = this.posts.find(p => p.id === postId);
        if (post) {
            post.status = 'approved';
            db.save();
            Toast.success('Paylaşım onaylandı ve yayınlandı!');
            this.render();
        } else {
            Toast.error('Paylaşım bulunamadı.');
        }
    },

    rejectPost(postId) {
        if (!State.currentUser || State.currentUser.role !== 'admin') return;
        const feedback = prompt('Reddetme nedeni (isteğe bağlı):') || '';
        
        const post = this.posts.find(p => p.id === postId);
        if (post) {
            post.status = 'rejected';
            post.rejectionFeedback = feedback;
            db.save();
            Toast.success('Paylaşım reddedildi.');
            this.render();
        } else {
            Toast.error('Paylaşım bulunamadı.');
        }
    },

    openBlogEditor() {
        this.openCreatePostModal('blog');
        setTimeout(() => {
            const header = document.querySelector('.create-post-modal-header h2');
            if (header) header.innerText = 'Blog Yazısı Paylaş';
            
            const area = document.getElementById('media-preview-area');
            if (area) {
                area.insertAdjacentHTML('beforebegin', `
                    <div id="blog-extra-fields" style="margin-top:14px; display:flex; flex-direction:column; gap:10px;">
                        <input type="text" id="blog-title-input" placeholder="Yazı Başlığı..." style="width:100%; padding:12px 14px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:12px; color:#fff; font-weight:700; outline:none; font-family:'Inter',sans-serif;">
                        <select id="blog-category-select" style="width:100%; padding:12px 14px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:12px; color:#fff; outline:none; font-family:'Inter',sans-serif; cursor:pointer;">
                            <option value="Haberler" style="background:#111;">Haberler</option>
                            <option value="Teknoloji" style="background:#111;">Teknoloji</option>
                            <option value="Spor" style="background:#111;">Spor</option>
                            <option value="Eğlence" style="background:#111;">Eğlence</option>
                        </select>
                    </div>
                `);
            }
        }, 100);    },

    searchModUsers(query) {
        const container = document.getElementById('mod-user-results');
        if (!container || !query.trim()) { if(container) container.innerHTML = ''; return; }
        const results = (State.data.users || []).filter(u => u.username.toLowerCase().includes(query.toLowerCase())).slice(0, 5);
        container.innerHTML = results.map(u => `
            <div style="display:flex; align-items:center; justify-content:space-between; padding:12px; background:rgba(255,255,255,0.03); border-radius:12px; margin-bottom:8px;">
                <div style="display:flex; align-items:center; gap:10px;">
                    <img src="${u.avatar || 'assets/logo.png'}" style="width:32px; height:32px; border-radius:50%;">
                    <span style="color:#fff; font-size:0.9rem;">${u.username}</span>
                </div>
                <button onclick="SocialFeed.assignModeratorRole('${u.id}')" style="background:#7c3aed; color:#fff; border:none; padding:6px 12px; border-radius:8px; cursor:pointer; font-size:0.8rem;">Moderatör Yap</button>
            </div>
        `).join('') || '<div style="color:#64748b; font-size:0.8rem; text-align:center;">Sonuç bulunamadı.</div>';
    },

    renderCurrentModerators() {
        const mods = (State.data.users || []).filter(u => u.role === 'moderator' || u.badges?.includes('Sosyal Moderatör'));
        if (mods.length === 0) return '<div style="color:#64748b; font-size:0.8rem; text-align:center;">Henüz moderatör atanmamış.</div>';
        return mods.map(u => `
            <div style="display:flex; align-items:center; justify-content:space-between; padding:10px; background:rgba(255,255,255,0.03); border-radius:10px; margin-bottom:8px;">
                <div style="display:flex; align-items:center; gap:10px;">
                    <img src="${u.avatar || 'assets/logo.png'}" style="width:28px; height:28px; border-radius:50%;">
                    <span style="color:#e2e8f0; font-size:0.85rem;">${u.username}</span>
                </div>
                <button onclick="SocialFeed.removeModeratorRole('${u.id}')" style="background:rgba(239,68,68,0.1); color:#ef4444; border:none; padding:4px 10px; border-radius:6px; cursor:pointer; font-size:0.75rem;">Kaldır</button>
            </div>
        `).join('');
    },

    removeModeratorRole(userId) {
        const user = State.data.users?.find(u => u.id === userId);
        if (user) {
            user.role = 'user';
            user.badges = (user.badges || []).filter(b => b !== 'Sosyal Moderatör');
            db.save();
            Toast.success('Moderatör yetkisi kaldırıldı.');
            this.showModerationPanel();
        }
    },

    renderPendingPostsList() {
        const pending = (State.data.socialPosts || []).filter(p => p.status === 'pending');
        if (pending.length === 0) return '<div style="color:#64748b; font-size:0.8rem; text-align:center;">Onay bekleyen paylaşım yok. ✅</div>';
        return pending.map(p => `
            <div style="padding:15px; background:rgba(255,255,255,0.03); border-radius:14px; margin-bottom:12px; border:1px solid rgba(245,158,11,0.2);">
                <div style="font-weight:700; color:#fff; font-size:0.9rem; margin-bottom:8px;">${p.content?.substring(0, 50)}...</div>
                <div style="display:flex; gap:10px;">
                    <button onclick="SocialFeed.approvePost('${p.id}')" style="flex:1; background:#10b981; color:#fff; border:none; padding:8px; border-radius:8px; cursor:pointer;">Onayla</button>
                    <button onclick="SocialFeed.rejectPost('${p.id}')" style="flex:1; background:#ef4444; color:#fff; border:none; padding:8px; border-radius:8px; cursor:pointer;">Reddet</button>
                </div>
            </div>
        `).join('');
    },

    sendSocialNotification(targetUserId, title, message, type = 'info') {
        if (!targetUserId) return;
        const targetUser = State.data.users?.find(u => u.id === targetUserId);
        if (!targetUser) return;

        if (!targetUser.notifications) targetUser.notifications = [];
        targetUser.notifications.unshift({
            id: 'notif_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            title,
            message,
            timestamp: new Date().toISOString(),
            read: false,
            type
        });

        if (window.db) db.saveDebounced ? db.saveDebounced() : db.save();
        console.log(`🔔 Notification sent to ${targetUser.username}: ${title}`);
    },

    renderTodayScheduleWidget() {
        const isHidden = localStorage.getItem('dramicbox_hide_today_schedule') === 'true';
        if (isHidden) return '';

        const daysTurkish = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
        const todayDayName = daysTurkish[new Date().getDay()];

        const scheduled = [];
        const seenSeriesIds = new Set();

        if (State.data.calendar) {
            State.data.calendar.forEach(entry => {
                if (entry.day === todayDayName && entry.seriesId) {
                    const series = (State.data.series || []).find(s => s.id === entry.seriesId);
                    if (series && !seenSeriesIds.has(series.id)) {
                        scheduled.push({
                            series,
                            time: entry.time || series.broadcastTime || '20:00',
                            episodeNumber: entry.episodeNumber
                        });
                        seenSeriesIds.add(series.id);
                    }
                }
            });
        }

        if (State.data.series) {
            State.data.series.forEach(series => {
                if (series.status === 'Devam Ediyor' && series.broadcastDays && series.broadcastDays.includes(todayDayName)) {
                    if (!seenSeriesIds.has(series.id)) {
                        scheduled.push({
                            series,
                            time: series.broadcastTime || '20:00',
                            episodeNumber: null
                        });
                        seenSeriesIds.add(series.id);
                    }
                }
            });
        }

        if (scheduled.length === 0) return '';

        const itemsHTML = scheduled.map(item => {
            const series = item.series;
            const episodes = series.episodes || [];
            let epNum = item.episodeNumber;
            if (!epNum) {
                epNum = episodes.length + 1;
            }
            
            let targetEpIndex = episodes.findIndex(e => e.number === epNum);
            if (targetEpIndex === -1 && episodes.length > 0) {
                targetEpIndex = episodes.length - 1; // Fallback to last episode
            }

            // Resolve status
            let statusLabel = 'Yayınlanacak';
            let statusClass = 'status-upcoming';
            let statusIcon = 'fa-regular fa-clock';
            let watchLink = `#/detail/${series.id}`;

            const ep = episodes.find(e => e.number === epNum);
            if (ep) {
                const hasSource = (ep.sources && ep.sources.length > 0) || ep.videoUrl;
                if (hasSource) {
                    statusLabel = 'Yayında';
                    statusClass = 'status-active';
                    statusIcon = 'fa-solid fa-circle-play';
                    watchLink = `#/player/${series.id}/${episodes.indexOf(ep)}`;
                } else {
                    statusLabel = 'Hazırlanıyor';
                    statusClass = 'status-preparing';
                    statusIcon = 'fa-solid fa-hourglass-half';
                }
            }

            const coverImg = series.poster || series.coverImage || 'assets/logo.png';

            return `
                <div class="today-schedule-item" style="display: flex; gap: 12px; align-items: center; padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.03);">
                    <img src="${coverImg}" style="width: 45px; height: 60px; object-fit: cover; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);" onerror="this.src='assets/logo.png'">
                    <div style="flex: 1; min-width: 0;">
                        <div style="font-weight: 700; font-size: 0.85rem; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${series.title}</div>
                        <div style="font-size: 0.72rem; color: #94a3b8; margin-top: 2px; display: flex; align-items: center; gap: 6px;">
                            <span>${epNum}. Bölüm</span>
                            <span style="color: rgba(255,255,255,0.15);">|</span>
                            <span><i class="fa-regular fa-clock" style="color: #a78bfa;"></i> ${item.time}</span>
                        </div>
                        <div style="margin-top: 4px;">
                            <a href="${watchLink}" class="schedule-status-badge ${statusClass}" style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.65rem; font-weight: 800; text-transform: uppercase; padding: 2px 8px; border-radius: 20px; text-decoration: none;">
                                <i class="${statusIcon}"></i> ${statusLabel}
                            </a>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        return `
            <div class="glass-card today-schedule-widget" style="padding: 20px; border-radius: 20px; margin-bottom: 20px; border: 1px solid rgba(167, 139, 250, 0.15); background: rgba(255, 255, 255, 0.01); position: relative; overflow: hidden;">
                <div style="position: absolute; top: -50px; right: -50px; width: 120px; height: 120px; background: radial-gradient(circle, rgba(167, 139, 250, 0.1) 0%, transparent 70%); border-radius: 50%; pointer-events: none;"></div>
                
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h4 style="margin: 0; font-size: 0.8rem; color: #a78bfa; text-transform: uppercase; letter-spacing: 1.5px; font-weight: 900; display: flex; align-items: center; gap: 8px;">
                        <i class="fa-regular fa-calendar-check" style="font-size: 0.95rem;"></i> Bugünün Yayınları
                    </h4>
                    <button onclick="SocialFeed.hideTodaySchedule(event)" style="background: none; border: none; color: #64748b; font-size: 1rem; cursor: pointer; display: flex; align-items: center; justify-content: center; width: 24px; height: 24px; border-radius: 50%; transition: all 0.2s;" onmouseover="this.style.color='#ef4444'; this.style.background='rgba(239,68,68,0.1)';" onmouseout="this.style.color='#64748b'; this.style.background='none';">
                        &times;
                    </button>
                </div>
                <div style="display: flex; flex-direction: column; gap: 10px;">
                    ${itemsHTML}
                </div>
            </div>
        `;
    },

    hideTodaySchedule(event) {
        if (event) event.stopPropagation();
        localStorage.setItem('dramicbox_hide_today_schedule', 'true');
        this.render();
        Toast.info('Gözetleme widget\'ı kaldırıldı. Keşfet panelinden geri getirebilirsiniz.');
    }
};

window.SocialFeed = SocialFeed;



// --- ACTIVITY FEED SYSTEM ---
if (typeof window.ActivityFeed === 'undefined') {
    window.ActivityFeed = {
        // Log a new activity
        async log(type, data) {
            if (!State.currentUser) return;

            const activity = {
                id: 'act-' + Date.now() + Math.random().toString(36).substr(2, 5),
                userId: State.currentUser.id,
                username: State.currentUser.username,
                avatar: State.currentUser.avatar,
                type: type, // 'watch', 'comment', 'rate', 'follow', 'level_up'
                data: data,
                timestamp: Date.now()
            };

            // Add to global state
            if (!State.data.activities) State.data.activities = [];
            State.data.activities.unshift(activity);

            // Keep logs manageable (last 500 global activities)
            if (State.data.activities.length > 500) {
                State.data.activities = State.data.activities.slice(0, 500);
            }

            // Save DB
            if (window.db && window.db.save) await db.save('activities');
        },

        // Get activities for a specific user (Personal Feed)
        getUserActivity(userId) {
            if (!State.data.activities) return [];
            return State.data.activities.filter(a => a.userId === userId);
        },

        // Get feed from people I follow (Social Feed)
        getSocialFeed() {
            if (!State.currentUser || !State.currentUser.following) return [];
            if (!State.data.activities) return [];

            const followingIds = State.currentUser.following;
            return State.data.activities
                .filter(a => followingIds.includes(a.userId))
                .sort((a, b) => b.timestamp - a.timestamp)
                .slice(0, 50);
        },

        // Generate HTML for a list of activities
        renderList(activities) {
            if (!activities || activities.length === 0) {
                return '<div style="padding: 20px; text-align: center; color: var(--text-secondary);">Henüz aktivite yok.</div>';
            }

            return activities.map(a => {
                let icon, text, content = '';

                switch (a.type) {
                    case 'watch':
                        icon = '<i class="fa-solid fa-play" style="color: #a78bfa;"></i>';
                        text = `<strong>${a.data.title}</strong> (${a.data.episode}. Bölüm) izledi`;
                        content = `<div style="font-size:0.85rem; color:#64748b; margin-top:4px;">${a.data.seriesTitle}</div>`;
                        break;
                    case 'comment':
                        icon = '<i class="fa-solid fa-comment" style="color: #60a5fa;"></i>';
                        text = `<strong>${a.data.seriesTitle}</strong> dizisine yorum yaptı`;
                        content = `<div style="font-size:0.9rem; color:#e2e8f0; margin-top:6px; background:rgba(255,255,255,0.05); padding:8px 12px; border-radius:8px;">"${a.data.comment}"</div>`;
                        break;
                    case 'rate':
                        icon = '<i class="fa-solid fa-star" style="color: #fbbf24;"></i>';
                        text = `<strong>${a.data.seriesTitle}</strong> dizisine ${a.data.rating} puan verdi`;
                        break;
                    case 'follow':
                        icon = '<i class="fa-solid fa-user-plus" style="color: #34d399;"></i>';
                        text = `<strong>${a.data.targetName}</strong> kullanıcısını takip etti`;
                        break;
                    case 'level_up':
                        icon = '<i class="fa-solid fa-trophy" style="color: #f472b6;"></i>';
                        text = `<strong>Seviye ${a.data.level}</strong> oldu!`;
                        break;
                    default:
                        icon = '<i class="fa-solid fa-circle-dot"></i>';
                        text = 'Bir işlem yaptı';
                }

                return `
                    <div class="activity-item" style="display: flex; gap: 15px; padding: 15px; border-bottom: 1px solid rgba(255,255,255,0.05);">
                        <div style="flex-shrink: 0;">
                            <img src="${a.avatar || 'assets/logo.png'}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">
                        </div>
                        <div style="flex: 1;">
                            <div style="font-size: 0.95rem; color: #fff; margin-bottom: 2px;">
                                <span style="font-weight: 700;">${a.username}</span> 
                                <span style="color: #94a3b8; font-weight: 400; font-size: 0.9rem;"> • ${this.timeAgo(a.timestamp)}</span>
                            </div>
                            <div style="color: #cbd5e1; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">
                                ${icon} <span>${text}</span>
                            </div>
                            ${content}
                        </div>
                    </div>
                `;
            }).join('');
        },

        timeAgo(timestamp) {
            const seconds = Math.floor((Date.now() - timestamp) / 1000);
            if (seconds < 60) return 'Az önce';
            if (seconds < 3600) return Math.floor(seconds / 60) + 'dk';
            if (seconds < 86400) return Math.floor(seconds / 3600) + 's';
            return Math.floor(seconds / 86400) + 'g';
        }
    };
} else {
    // If it is already declared in social-expansion.js, make sure the async save feature is attached
    const originalLog = window.ActivityFeed.log;
    window.ActivityFeed.log = async function(type, data) {
        if (!State.currentUser) return;
        const activity = {
            id: 'act-' + Date.now() + Math.random().toString(36).substr(2, 5),
            userId: State.currentUser.id,
            username: State.currentUser.username,
            avatar: State.currentUser.avatar,
            type: type,
            data: data,
            timestamp: Date.now()
        };
        if (!State.data.activities) State.data.activities = [];
        State.data.activities.unshift(activity);
        if (State.data.activities.length > 500) {
            State.data.activities = State.data.activities.slice(0, 500);
        }
        if (window.db && window.db.save) await db.save('activities');
    };
}
