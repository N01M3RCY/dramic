// ============================================
// WATCH TIME TRACKING & MONTHLY SUMMARY
// ============================================

const WatchTimeTracker = {
    init() {
        this.updateAllWatchTimes();
    },

    // Mark episode as watched and track time
    markAsWatched(seriesId, episodeNumber) {
        if (!State.currentUser) return;

        const series = db.getSeries(seriesId);
        if (!series || !series.episodes) return;

        const episode = series.episodes.find(e => e.number === episodeNumber);

        // Duration Logic: Parse "40 dk" or use number. Fallback to 24 mins if missing.
        let duration = 0;
        if (episode && episode.duration) {
            if (typeof episode.duration === 'number') {
                duration = episode.duration;
            } else if (typeof episode.duration === 'string') {
                duration = parseInt(episode.duration.replace(/\D/g, '')) || 0;
            }
        }

        // If duration is still 0/null, try to guess based on series type or default
        if (duration === 0) {
            // Default to 24 mins (anime standard) or 45 mins (drama standard)
            // Just use a safe average of 24 mins to avoid inflation, or check series type
            duration = (series.type === 'movie') ? 120 : 24;
        }

        // 1. Update Watch History (Timestamped for "Continue Watching")
        if (!State.currentUser.watchHistory) {
            State.currentUser.watchHistory = [];
        }

        // Remove existing entries for this series to keep history clean/latest
        State.currentUser.watchHistory = State.currentUser.watchHistory.filter(h => h.seriesId !== seriesId);

        State.currentUser.watchHistory.push({
            seriesId: seriesId,
            episodeNumber: episodeNumber,
            duration: duration,
            watchedAt: Date.now()
        });

        // 2. Update Persistant "Watched Episodes" List (Checkbox)
        this.addToWatchedEpisodes(seriesId, episodeNumber);

        // --- NEW: Award XP (Once Only) ---
        this.awardEpisodeXP(seriesId, episodeNumber);

        // 3. Save
        db.updateUser(State.currentUser.id, {
            watchHistory: State.currentUser.watchHistory,
            watchedEpisodes: State.currentUser.watchedEpisodes,
            xpAwardedEpisodes: State.currentUser.xpAwardedEpisodes || []
        });
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        this.updateWatchTimeDisplay();

        // --- NEW: Check Series Completion for Actor Cards ---
        if (typeof ActorCards !== 'undefined') {
            ActorCards.checkSeriesCompletion(seriesId);
        }

        // 4. Trigger UI Update if DetailedView is active
        if (typeof DetailedView !== 'undefined' && State.currentSeries && State.currentSeries.id === seriesId) {
            DetailedView.updateEpisodeUI(episodeNumber, true);
        }
    },

    // NEW: Manual Toggle Logic
    toggleEpisodeWatched(seriesId, episodeNumber, event) {
        if (event) event.stopPropagation();

        if (!State.currentUser) {
            if (window.Toast) Toast.warning("Bu özelliği kullanmak için giriş yapmalısınız.");
            return;
        }

        if (!State.currentUser.watchedEpisodes) State.currentUser.watchedEpisodes = {};
        if (!State.currentUser.watchedEpisodes[seriesId]) State.currentUser.watchedEpisodes[seriesId] = [];

        const epNum = parseInt(episodeNumber);
        const watchedList = State.currentUser.watchedEpisodes[seriesId];
        const index = watchedList.findIndex(n => parseInt(n) === epNum);

        let isWatched = false;

        if (index > -1) {
            // UNMARK
            watchedList.splice(index, 1);
            if (window.Toast) Toast.info(`${epNum}. Bölüm izlenmedi.`);
            isWatched = false;
        } else {
            // MARK
            watchedList.push(epNum);
            // Also add to history if marking as watched
            this.markAsWatched(seriesId, epNum);
            // markAsWatched handles saving and XP
            if (window.Toast) Toast.success(`${epNum}. Bölüm izlendi!`);
            isWatched = true;
            return; // markAsWatched handled the save
        }

        // Persist (Only for UNMARK case, since MARK calls markAsWatched)
        State.currentUser.watchedEpisodes[seriesId] = watchedList;
        db.updateUser(State.currentUser.id, { watchedEpisodes: State.currentUser.watchedEpisodes });
        if (db.save) db.save();
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));

        // --- NEW: Check Series Completion for Actor Cards (Only if marked as watched) ---
        if (isWatched && typeof ActorCards !== 'undefined') {
            ActorCards.checkSeriesCompletion(seriesId);
        }

        // UI Update
        if (typeof DetailedView !== 'undefined' && State.currentSeries && State.currentSeries.id === seriesId) {
            DetailedView.updateEpisodeUI(epNum, isWatched);
        }

        // Continue Watching Update
        if (typeof ContinueWatching !== 'undefined') {
            ContinueWatching.renderContinueWatching();
        }
    },

    awardEpisodeXP(seriesId, episodeNumber) {
        if (!State.currentUser) return;

        // Clean Initialize
        if (!State.currentUser.xpAwardedEpisodes) State.currentUser.xpAwardedEpisodes = [];
        if (!State.currentUser.lastXpAwardTime) State.currentUser.lastXpAwardTime = 0;

        // Determine correct ID type (string or number consistency)
        // Store as "seriesId_episodeNum" string
        const key = `${seriesId}_${episodeNumber}`;

        // Check if already awarded XP for this specific episode
        if (State.currentUser.xpAwardedEpisodes.includes(key)) {
            console.log(`XP already awarded for ${key}`);
            return;
        }

        // 10-minute cooldown check (anti-spam)
        const now = Date.now();
        const cooldownMs = 10 * 60 * 1000; // 10 minutes in ms
        const timeSinceLastXP = now - State.currentUser.lastXpAwardTime;

        if (timeSinceLastXP < cooldownMs) {
            const remainingMinutes = Math.ceil((cooldownMs - timeSinceLastXP) / 60000);
            if (window.Toast) Toast.warning(`XP almak için ${remainingMinutes} dakika beklemelisiniz.`);
            console.log(`XP cooldown active, ${remainingMinutes} min remaining`);
            return;
        }

        // Mark this episode as XP awarded
        State.currentUser.xpAwardedEpisodes.push(key);
        State.currentUser.lastXpAwardTime = now;

        // Award XP
        if (window.Gamification) {
            Gamification.addXP(50, `${episodeNumber}. Bölüm İzleme`);
        }

        // Save immediately to prevent race conditions or spam
        db.updateUser(State.currentUser.id, {
            xpAwardedEpisodes: State.currentUser.xpAwardedEpisodes,
            lastXpAwardTime: State.currentUser.lastXpAwardTime
        });

        // Sync session storage
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
    },



    addToWatchedEpisodes(seriesId, episodeNumber) {
        if (!State.currentUser.watchedEpisodes) State.currentUser.watchedEpisodes = {};
        if (!State.currentUser.watchedEpisodes[seriesId]) State.currentUser.watchedEpisodes[seriesId] = [];

        if (!State.currentUser.watchedEpisodes[seriesId].includes(episodeNumber)) {
            State.currentUser.watchedEpisodes[seriesId].push(episodeNumber);
        }
    },

    // Calculate total watch time
    getTotalWatchTime() {
        if (!State.currentUser || !State.currentUser.watchHistory) {
            return { minutes: 0, formatted: '0 dakika' };
        }

        const totalMinutes = State.currentUser.watchHistory.reduce((sum, h) => sum + (h.duration || 0), 0);
        return {
            minutes: totalMinutes,
            formatted: this.formatWatchTime(totalMinutes)
        };
    },

    // Format watch time (minutes to hours/days/months)
    formatWatchTime(minutes) {
        if (minutes < 60) {
            return `${minutes} dakika`;
        }

        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;

        if (hours < 24) {
            return remainingMinutes > 0
                ? `${hours} saat ${remainingMinutes} dakika`
                : `${hours} saat`;
        }

        const days = Math.floor(hours / 24);
        const remainingHours = hours % 24;

        if (days < 7) {
            return remainingHours > 0
                ? `${days} gün ${remainingHours} saat`
                : `${days} gün`;
        }

        const weeks = Math.floor(days / 7);
        const remainingDays = days % 7;

        if (weeks < 4) {
            return remainingDays > 0
                ? `${weeks} hafta ${remainingDays} gün`
                : `${weeks} hafta`;
        }

        const months = Math.floor(days / 30);
        const remainingDaysAfterMonths = days % 30;

        return remainingDaysAfterMonths > 0
            ? `${months} ay ${remainingDaysAfterMonths} gün`
            : `${months} ay`;
    },

    // Update watch time display
    updateAllWatchTimes() {
        if (!State.currentUser) return;

        // Recalculate based on history
        const stats = this.getTotalWatchTime();

        // Update User object in memory (this is usually display only, but good to have)
        if (!State.currentUser.stats) State.currentUser.stats = {};
        State.currentUser.stats.totalWatchTimeFormatted = stats.formatted;

        this.updateWatchTimeDisplay();
    },

    updateWatchTimeDisplay() {
        const stats = this.getTotalWatchTime();

        // 1. Sidebar/Navbar
        const el = document.getElementById('user-watch-time');
        if (el) el.textContent = stats.formatted;

        // 2. Profile Page (if open)
        const profileEl = document.getElementById('profile-total-watch-time');
        if (profileEl) profileEl.textContent = stats.minutes;

        const profileFormatted = document.getElementById('profile-watch-time-formatted');
        if (profileFormatted) profileFormatted.textContent = stats.formatted;

        // Also update Watched Episodes Count & Series Count
        if (State.currentUserWrapper && State.currentUser.watchHistory) {
            const uniqueSeries = new Set(State.currentUser.watchHistory.map(h => h.seriesId)).size;
            const totalEpisodes = State.currentUser.watchHistory.length;

            const epCountEl = document.getElementById('profile-watched-episodes-count');
            if (epCountEl) epCountEl.textContent = totalEpisodes;

            const seriesCountEl = document.getElementById('profile-watched-series-count');
            if (seriesCountEl) seriesCountEl.textContent = uniqueSeries;
        }
    },

    // Get watch time for specific period
    getWatchTimeForPeriod(startDate, endDate) {
        if (!State.currentUser || !State.currentUser.watchHistory) {
            return { minutes: 0, formatted: '0 dakika' };
        }

        const filtered = State.currentUser.watchHistory.filter(h => {
            return h.watchedAt >= startDate && h.watchedAt <= endDate;
        });

        const totalMinutes = filtered.reduce((sum, h) => sum + (h.duration || 0), 0);
        return {
            minutes: totalMinutes,
            formatted: this.formatWatchTime(totalMinutes),
            count: filtered.length
        };
    },

    // Monthly summary
    generateMonthlySummary(year, month) {
        if (!State.currentUser) return null;

        const startDate = new Date(year, month - 1, 1).getTime();
        const endDate = new Date(year, month, 0, 23, 59, 59).getTime();

        const watchTime = this.getWatchTimeForPeriod(startDate, endDate);
        const history = State.currentUser.watchHistory?.filter(h =>
            h.watchedAt >= startDate && h.watchedAt <= endDate
        ) || [];

        // Most watched series
        const seriesCounts = {};
        history.forEach(h => {
            seriesCounts[h.seriesId] = (seriesCounts[h.seriesId] || 0) + 1;
        });

        const topSeriesId = Object.keys(seriesCounts).reduce((a, b) =>
            seriesCounts[a] > seriesCounts[b] ? a : b, null
        );
        const topSeries = topSeriesId ? db.getSeries(topSeriesId) : null;

        // Most active day
        const dayCounts = {};
        history.forEach(h => {
            const day = new Date(h.watchedAt).toLocaleDateString('tr-TR');
            dayCounts[day] = (dayCounts[day] || 0) + 1;
        });

        const mostActiveDay = Object.keys(dayCounts).reduce((a, b) =>
            dayCounts[a] > dayCounts[b] ? a : b, null
        );

        return {
            year: year,
            month: month,
            monthName: new Date(year, month - 1).toLocaleDateString('tr-TR', { month: 'long' }),
            totalWatchTime: watchTime,
            episodesWatched: history.length,
            topSeries: topSeries,
            topSeriesCount: topSeriesId ? seriesCounts[topSeriesId] : 0,
            mostActiveDay: mostActiveDay,
            mostActiveDayCount: mostActiveDay ? dayCounts[mostActiveDay] : 0,
            daysActive: Object.keys(dayCounts).length
        };
    },

    // Show monthly summary modal
    showMonthlySummary() {
        const now = new Date();
        const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1);
        const summary = this.generateMonthlySummary(lastMonth.getFullYear(), lastMonth.getMonth() + 1);

        if (!summary) {
            Toast.warning("Özet oluşturulamadı!");
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content monthly-summary-modal">
                <div class="modal-header">
                    <h2>📊 ${summary.monthName} ${summary.year} Özeti</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div style="padding: 30px;">
                    <div class="summary-stats-grid">
                        <div class="summary-stat-card">
                            <div class="summary-stat-icon" style="background: linear-gradient(135deg, #7c3aed, #a78bfa);">
                                <i class="fa-solid fa-clock"></i>
                            </div>
                            <div class="summary-stat-info">
                                <div class="summary-stat-value">${summary.totalWatchTime.formatted}</div>
                                <div class="summary-stat-label">Toplam İzleme Süresi</div>
                            </div>
                        </div>

                        <div class="summary-stat-card">
                            <div class="summary-stat-icon" style="background: linear-gradient(135deg, #10b981, #34d399);">
                                <i class="fa-solid fa-play-circle"></i>
                            </div>
                            <div class="summary-stat-info">
                                <div class="summary-stat-value">${summary.episodesWatched}</div>
                                <div class="summary-stat-label">İzlenen Bölüm</div>
                            </div>
                        </div>

                        <div class="summary-stat-card">
                            <div class="summary-stat-icon" style="background: linear-gradient(135deg, #f59e0b, #fbbf24);">
                                <i class="fa-solid fa-calendar-check"></i>
                            </div>
                            <div class="summary-stat-info">
                                <div class="summary-stat-value">${summary.daysActive}</div>
                                <div class="summary-stat-label">Aktif Gün</div>
                            </div>
                        </div>
                    </div>

                    ${summary.topSeries ? `
                        <div class="summary-highlight">
                            <h3>En Çok İzlediğiniz Dizi</h3>
                            <div style="display: flex; align-items: center; gap: 15px; margin-top: 15px;">
                                <img src="${summary.topSeries.coverImage}" style="width: 80px; height: 120px; object-fit: cover; border-radius: 8px;">
                                <div>
                                    <h4>${summary.topSeries.title}</h4>
                                    <p style="color: var(--text-secondary);">${summary.topSeriesCount} bölüm izlediniz</p>
                                </div>
                            </div>
                        </div>
                    ` : ''}

                    ${summary.mostActiveDay ? `
                        <div class="summary-highlight">
                            <h3>En Aktif Gününüz</h3>
                            <p style="font-size: 1.2rem; color: var(--accent-color); margin-top: 10px;">
                                ${summary.mostActiveDay}
                            </p>
                            <p style="color: var(--text-secondary);">${summary.mostActiveDayCount} bölüm izlediniz</p>
                        </div>
                    ` : ''}

                    <button class="btn btn-primary" onclick="this.closest('.modal').remove()" style="width: 100%; margin-top: 20px;">
                        Harika! 🎉
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    // Auto-generate monthly summary at month end
    checkAndGenerateMonthlySummary() {
        const now = new Date();
        const lastCheck = localStorage.getItem('last_monthly_summary_check');

        if (lastCheck) {
            const lastCheckDate = new Date(parseInt(lastCheck));
            if (lastCheckDate.getMonth() === now.getMonth()) {
                return; // Already checked this month
            }
        }

        // First day of new month - show last month's summary
        if (now.getDate() === 1) {
            setTimeout(() => {
                this.showMonthlySummary();
                localStorage.setItem('last_monthly_summary_check', now.getTime().toString());
            }, 3000);
        }
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        WatchTimeTracker.init();
        WatchTimeTracker.checkAndGenerateMonthlySummary();
    }, 2500);
});

console.log('✅ Watch Time Tracker Loaded!');
