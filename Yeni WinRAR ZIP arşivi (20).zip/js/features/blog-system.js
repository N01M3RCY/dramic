// BlogSystem - Extended Blog Management
// Using window assignment to avoid duplicate declaration conflicts
window.BlogSystem = window.BlogSystem || {
    init() {
        console.log('📝 Blog System initialized');
        // If container isn't ready (e.g. during fresh load), wait a bit
        if (!document.getElementById('blog-view')) {
            setTimeout(() => {
                if (document.getElementById('blog-posts-grid')) this.loadPosts();
            }, 1000);
        } else {
            if (document.getElementById('blog-posts-grid')) this.loadPosts();
        }
    },

    handleSearch(query) {
        this.searchQuery = query.toLowerCase().trim();
        if (window.BlogHero && BlogHero.renderPosts) {
            BlogHero.renderPosts();
        }
    },

    calculateReadTime(content) {
        if (!content) return 1;
        const wordsPerMinute = 200;
        const noOfWords = content.split(/\s+/g).length;
        const minutes = Math.ceil(noOfWords / wordsPerMinute);
        return minutes || 1;
    },

    searchQuery: '',

    renderSkeletons() {
        let skeletons = '';
        for (let i = 0; i < 6; i++) {
            skeletons += `
                <div class="blog-card-cinema skeleton">
                    <div class="card-img-box skeleton-box"></div>
                    <div class="card-details">
                        <div class="card-meta">
                            <div class="skeleton-box" style="width: 60px; height: 12px;"></div>
                            <div class="skeleton-box" style="width: 40px; height: 12px;"></div>
                        </div>
                        <div class="card-title skeleton-box"></div>
                        <div class="card-excerpt skeleton-box"></div>
                        <div class="card-author-info">
                            <div class="author-box skeleton-box" style="width: 100px; height: 30px;"></div>
                        </div>
                    </div>
                </div>
            `;
        }
        return skeletons;
    },

    toggleBookmark(postId, event) {
        if (event) event.stopPropagation();
        const bookmarks = JSON.parse(localStorage.getItem('blog_bookmarks') || '[]');
        const index = bookmarks.indexOf(postId);
        
        if (index === -1) {
            bookmarks.push(postId);
            Toast.success('Yazı yer işaretlerine eklendi!');
        } else {
            bookmarks.splice(index, 1);
            Toast.info('Yazı yer işaretlerinden kaldırıldı.');
        }
        
        localStorage.setItem('blog_bookmarks', JSON.stringify(bookmarks));
        
        // Refresh UI if we are in the blog view
        if (window.BlogHero && BlogHero.renderPosts) {
            BlogHero.renderPosts();
        }
    },

    isBookmarked(postId) {
        const bookmarks = JSON.parse(localStorage.getItem('blog_bookmarks') || '[]');
        return bookmarks.includes(postId);
    },

    sharePost(platform, postTitle, postId) {
        const url = window.location.origin + window.location.pathname + `#/blog/${postId}`;
        const text = encodeURIComponent(`Göz atın: ${postTitle}`);
        const encodedUrl = encodeURIComponent(url);
        
        let shareUrl = '';
        switch(platform) {
            case 'whatsapp':
                shareUrl = `https://api.whatsapp.com/send?text=${text}%20${encodedUrl}`;
                break;
            case 'x':
                shareUrl = `https://twitter.com/intent/tweet?text=${text}&url=${encodedUrl}`;
                break;
            case 'facebook':
                shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
                break;
            case 'copy':
                navigator.clipboard.writeText(url).then(() => {
                    Toast.success('Bağlantı kopyalandı!');
                });
                return;
        }
        
        if (shareUrl) window.open(shareUrl, '_blank');
    },

    renderRelatedPosts(post) {
        const posts = (State.data && State.data.blogPosts) ? State.data.blogPosts : [];
        const related = posts
            .filter(p => p.category === post.category && p.id !== post.id)
            .sort((a, b) => (b.views || 0) - (a.views || 0))
            .slice(0, 3);
            
        if (related.length === 0) return '';
        
        return `
            <div class="related-posts-section">
                <h3 class="related-title">Bunlar da İlginizi Çekebilir</h3>
                <div class="content-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px;">
                    ${related.map(p => this.createPostCard(p)).join('')}
                </div>
            </div>
        `;
    },

    handleSearch(query) {
        const container = document.getElementById('blog-view');
        if (!container) return; // Should exist from index.html

        // Only render structure if it's not correctly set up
        if (!document.getElementById('blog-hero-slider')) {
            container.innerHTML = `
                <div class="blog-view-container">
                    <div class="container section">
                        <div class="blog-header-section">
                            <h1 class="blog-main-title">Blog & Haberler</h1>
                            <p style="color: var(--blog-text-muted);">Dizi dünyasından son haberler, teoriler ve incelemeler</p>
                        </div>

                        <!-- Search Bar -->
                        <div class="blog-search-wrapper">
                            <i class="fas fa-search blog-search-icon"></i>
                            <input type="text" class="blog-search-input" id="blog-search-input" placeholder="Yazılarda ara..." oninput="BlogSystem.handleSearch(this.value)">
                        </div>
        
                        <!-- Hero Section -->
                        <div style="margin-bottom: 40px;">
                            <div class="blog-tabs" style="display: flex; gap: 15px; margin-bottom: 20px;">
                                <button class="blog-tab-btn active" onclick="BlogHero.switchSlider('new', this)">Yeni Eklenenler</button>
                                <button class="blog-tab-btn" onclick="BlogHero.switchSlider('popular', this)">🔥 En Popüler</button>
                            </div>
                            
                            <div id="blog-hero-slider" class="blog-hero-slider-modern">
                                <div class="loading-spinner"></div>
                            </div>
                        </div>
        
                        <!-- Content Grid -->
                        <div style="margin-top: 50px;">
                            <div class="blog-filters-container">
                                <button class="blog-filter-btn active" onclick="BlogHero.filterPosts('all', this)">Tümü</button>
                                <button class="blog-filter-btn" onclick="BlogHero.filterPosts('news', this)">Haberler</button>
                                <button class="blog-filter-btn" onclick="BlogHero.filterPosts('review', this)">İncelemeler</button>
                                <button class="blog-filter-btn" onclick="BlogHero.filterPosts('theory', this)">Teoriler</button>
                                <button class="blog-filter-btn" onclick="BlogHero.filterPosts('guide', this)">Rehberler</button>
                            </div>
        
                            <div id="blog-posts-grid" class="content-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px;">
                                ${this.renderSkeletons()}
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            // Simulated delay for premium feel
            setTimeout(() => {
                if (window.BlogHero && BlogHero.renderPosts) {
                    BlogHero.renderPosts();
                }
            }, 600);
        }

        // Initialize Hero logic
        if (window.BlogHero && BlogHero.init) {
            BlogHero.init();
        } else {
            console.warn('BlogHero module missing, rendering simple list.');
            this.loadPosts(); // Fallback
        }
    },

    render(category = 'all') {
        // Fetch posts from db
        const posts = (State.data && State.data.blogPosts) ? State.data.blogPosts : [];

        // Filter logic
        let filteredPosts = posts;
        if (category !== 'all') {
            filteredPosts = posts.filter(post => post.category === category);
        }

        // Sort by date (newest first)
        filteredPosts.sort((a, b) => new Date(b.date) - new Date(a.date));

        if (filteredPosts.length === 0) {
            return `
                <div style="grid-column: 1/-1; text-align: center; padding: 50px; color: #888;">
                    <i class="fas fa-newspaper" style="font-size: 48px; margin-bottom: 20px;"></i>
                    <p>Bu kategoride henüz yazı bulunmuyor.</p>
                </div>
            `;
        }

        return filteredPosts.map(post => this.createPostCard(post)).join('');
    },

    createPostCard(post) {
        return `
            <div class="blog-card-cinema" onclick="BlogSystem.readPost('${post.id}')">
                <div class="card-img-box">
                    <img src="${post.image || 'assets/blog-placeholder.jpg'}" alt="${post.title}" loading="lazy">
                    <div class="card-overlay"></div>
                    <div class="category-tag">${this.getCategoryName(post.category)}</div>
                </div>
                <div class="card-details">
                    <div class="card-meta">
                        <span><i class="far fa-calendar"></i> ${this.formatDate(post.date)}</span>
                        <span><i class="far fa-eye"></i> ${post.views || 0}</span>
                        <div class="read-time-badge">
                            <i class="far fa-clock"></i> ${this.calculateReadTime(post.content)} dk
                        </div>
                    </div>
                    <h3 class="card-title">${post.title}</h3>
                    <p class="card-excerpt">${post.excerpt || (post.content ? post.content.substring(0, 100) + '...' : '')}</p>
                    
                    <div class="card-author-info">
                        <div class="author-box" onclick="event.stopPropagation(); ViewManager.showView('profile', {username: '${post.author}'})">
                            <img src="${post.authorAvatar || 'assets/logo.png'}" alt="${post.author}" class="author-avatar">
                            <span class="author-name">${post.author}</span>
                        </div>
                        <div style="display: flex; gap: 8px; align-items: center;">
                            <button onclick="BlogSystem.toggleBookmark('${post.id}', event)" class="bookmark-btn ${this.isBookmarked(post.id) ? 'active' : ''}" style="background: none; border: none; color: ${this.isBookmarked(post.id) ? 'var(--blog-accent)' : 'var(--blog-text-muted)'}; cursor: pointer; font-size: 1.1rem; transition: all 0.3s; padding: 5px;">
                                <i class="${this.isBookmarked(post.id) ? 'fas' : 'far'} fa-bookmark"></i>
                            </button>
                            <span style="color: var(--blog-accent-light); font-size: 0.85rem; font-weight: 600; display: flex; align-items: center; gap: 5px;">
                                Oku <i class="fas fa-arrow-right" style="font-size: 12px;"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    readPost(postId) {
        const posts = (State.data && State.data.blogPosts) ? State.data.blogPosts : [];
        const post = posts.find(p => p.id === postId);
        if (!post) return;

        // Populate modal or view
        // For now, let's use a simple modal approach similar to announcements
        this.showPostModal(post);
    },

    showPostModal(post) {
        const modalId = 'blog-post-modal';
        let modal = document.getElementById(modalId);

        if (!modal) {
            modal = document.createElement('div');
            modal.id = modalId;
            modal.className = 'modal';
            document.body.appendChild(modal);
        }

        modal.innerHTML = `
            <div class="modal-content" style="max-width: 850px; width: 95%; background: rgba(15, 15, 20, 0.95); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border: 1px solid var(--blog-glass-border); border-radius: 24px; overflow: hidden; box-shadow: 0 30px 60px rgba(0,0,0,0.6);">
                <div class="modal-header" style="border-bottom: 1px solid rgba(255,255,255,0.05); padding: 20px 30px;">
                    <h2 style="font-size: 1.5rem; font-weight: 700; color: #fff; margin: 0; line-height: 1.3; text-shadow: 0 2px 4px rgba(0,0,0,0.5);">${post.title}</h2>
                    <button class="modal-close" onclick="document.getElementById('${modalId}').remove()" style="color: #aaa; background: rgba(255,255,255,0.1); width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s;">&times;</button>
                </div>
                <div class="modal-body" style="padding: 0; max-height: 80vh; overflow-y: auto;">
                    <div style="position: relative; height: 350px;">
                        <img src="${post.image || 'assets/blog-placeholder.jpg'}" style="width: 100%; height: 100%; object-fit: cover; filter: brightness(0.8);">
                        <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(15, 15, 20, 1) 0%, transparent 100%);"></div>
                    </div>
                    <div style="padding: 40px; margin-top: -80px; position: relative; z-index: 2;">
                        <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(20, 20, 30, 0.8); backdrop-filter: blur(10px); padding: 15px 25px; border-radius: 16px; border: 1px solid rgba(255,255,255,0.05); color: var(--blog-text-muted); margin-bottom: 30px; font-size: 0.95rem; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
                            <div style="display: flex; align-items: center; gap: 10px;"><img src="${post.authorAvatar || 'assets/logo.png'}" style="width: 24px; height: 24px; border-radius: 50%;"><span style="color: #e2e8f0; font-weight: 600;">${post.author}</span></div>
                            <span><i class="far fa-calendar"></i> ${this.formatDate(post.date)}</span>
                            <span style="background: var(--blog-accent); color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 700; text-transform: uppercase;">${this.getCategoryName(post.category)}</span>
                        </div>
                        <div class="blog-content" style="line-height: 1.8; font-size: 1.15rem; color: #e2e8f0; font-family: 'Inter', sans-serif;">
                            ${(() => {
                let content = post.content.replace(/\n/g, '<br>');
                if (typeof AdService !== 'undefined' && AdService.shouldShowAds()) {
                    return AdService.injectBlogAds(content.split('<br>').map(p => `<p style="margin-bottom: 1.5em; text-shadow: 0 1px 2px rgba(0,0,0,0.3);">${p}</p>`).join('')).replace(/<\/?p>/g, '<br>');
                }
                return content.split('<br>').map(p => p.trim() ? `<p style="margin-bottom: 1.5em; text-shadow: 0 1px 2px rgba(0,0,0,0.3);">${p}</p>` : '').join('');
            })()}
                        </div>
                        
                        <!-- Coffee Donation Button -->
                        <div style="margin-top: 40px; padding-top: 30px; border-top: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: center;">
                            <button onclick="BlogSystem.donateToAuthor('${post.authorId}', '${post.author}')" 
                                    style="background: linear-gradient(135deg, #f59e0b, #ea580c); border: none; color: white; padding: 16px 36px; border-radius: 40px; font-size: 1.1rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.3s; box-shadow: 0 8px 25px rgba(245, 158, 11, 0.4);">
                                <i class="fa-solid fa-mug-hot"></i> Yazarına Kahve Ismarla
                            </button>
                        </div>
                        
                        <!-- Interaction Stats -->
                        <div style="margin-top: 30px; display: flex; justify-content: center; gap: 30px; color: var(--blog-text-muted); font-size: 1rem; font-weight: 500;">
                            <span style="display: flex; align-items: center; gap: 8px;"><i class="fa-solid fa-eye" style="color: var(--blog-accent-light);"></i> ${post.views || 0} görüntüleme</span>
                            <span style="display: flex; align-items: center; gap: 8px;"><i class="fa-solid fa-heart" style="color: #ef4444;"></i> ${post.likes || 0} beğeni</span>
                        </div>
                    </div>
                </div>
            </div>
        `;

        modal.style.display = 'flex';

        // Increment view count (mock)
        if (!post.views) post.views = 0;
        post.views++;
        // State.data is managed by App/DataService, strictly we should call save there but for view count it might be overkill or require api
        // db.save(); // Removed as invalid
    },

    renderPostPage(postId) {
        const posts = (State.data && State.data.blogPosts) ? State.data.blogPosts : [];
        const post = posts.find(p => p.id === postId);
        const container = document.getElementById('blog-detail-view');

        if (!container) return;

        if (!post) {
            container.innerHTML = '<div style="padding:100px; text-align:center;">Yazı bulunamadı.</div>';
            return;
        }

        container.innerHTML = `
            <div class="blog-view-container">
                <div class="container" style="max-width: 900px; margin: 0 auto;">
                    <div style="position: relative; height: 500px; border-radius: 24px; overflow: hidden; margin-bottom: 40px; box-shadow: 0 30px 60px rgba(0,0,0,0.5);">
                        <img src="${post.image || 'assets/blog-placeholder.jpg'}" style="width: 100%; height: 100%; object-fit: cover; filter: brightness(0.8);">
                        <div style="position: absolute; inset: 0; background: linear-gradient(to top, #050505 0%, rgba(5,5,5,0.4) 50%, transparent 100%);"></div>
                        <div style="position: absolute; bottom: 40px; left: 40px; right: 40px;">
                            <span style="background: var(--blog-accent); color: white; padding: 8px 20px; border-radius: 30px; font-size: 0.85rem; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; box-shadow: 0 4px 15px rgba(124, 58, 237, 0.4);">${this.getCategoryName(post.category)}</span>
                            <h1 style="font-size: 3.5rem; font-weight: 800; margin: 25px 0 15px; line-height: 1.1; color: #fff; text-shadow: 0 4px 15px rgba(0,0,0,0.6); letter-spacing: -1px;">${post.title}</h1>
                            <div style="display: flex; gap: 25px; color: rgba(255,255,255,0.8); font-size: 1.05rem; font-weight: 500;">
                                 <span style="display: flex; align-items: center; gap: 8px;"><img src="${post.authorAvatar || 'assets/logo.png'}" style="width: 28px; height: 28px; border-radius: 50%; border: 2px solid var(--blog-accent-light);"> <span style="color: #fff;">${post.author}</span></span>
                                 <span style="display: flex; align-items: center; gap: 8px;"><i class="far fa-calendar"></i> ${this.formatDate(post.date)}</span>
                                 <span style="display: flex; align-items: center; gap: 8px;"><i class="far fa-eye"></i> ${post.views || 0}</span>
                            </div>
                        </div>
                    </div>

                    <div class="blog-content" style="font-size: 1.25rem; line-height: 1.9; color: #e2e8f0; font-family: 'Inter', sans-serif; background: var(--blog-glass-bg); backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px); padding: 50px 60px; border-radius: 24px; border: 1px solid var(--blog-glass-border); box-shadow: 0 20px 50px rgba(0,0,0,0.3);">
                        ${(() => {
                let content = post.content.replace(/\n/g, '<br>');
                if (typeof AdService !== 'undefined' && AdService.shouldShowAds()) {
                    return AdService.injectBlogAds(content.split('<br>').map(p => `<p style="margin-bottom: 1.6em; text-shadow: 0 1px 2px rgba(0,0,0,0.2);">${p}</p>`).join('')).replace(/<\/?p>/g, '<br>');
                }
                return content.split('<br>').map(p => p.trim() ? `<p style="margin-bottom: 1.6em; text-shadow: 0 1px 2px rgba(0,0,0,0.2);">${p}</p>` : '').join('');
            })()}
                    </div>

                    <!-- Social Share Buttons -->
                    <div style="margin-top: 30px; display: flex; flex-direction: column; align-items: center; gap: 15px;">
                        <span style="color: var(--blog-text-muted); font-size: 0.9rem; font-weight: 600;">BU YAZIYI PAYLAŞ</span>
                        <div class="share-buttons-container">
                            <button class="share-btn whatsapp" onclick="BlogSystem.sharePost('whatsapp', '${post.title}', '${post.id}')"><i class="fab fa-whatsapp"></i></button>
                            <button class="share-btn x" onclick="BlogSystem.sharePost('x', '${post.title}', '${post.id}')"><i class="fab fa-x-twitter"></i></button>
                            <button class="share-btn facebook" onclick="BlogSystem.sharePost('facebook', '${post.title}', '${post.id}')"><i class="fab fa-facebook-f"></i></button>
                            <button class="share-btn link" onclick="BlogSystem.sharePost('copy', '${post.title}', '${post.id}')"><i class="fas fa-link"></i></button>
                        </div>
                    </div>

                    <!-- Coffee Donation Button -->
                    <div style="margin-top: 50px; display: flex; justify-content: center;">
                        <button onclick="BlogSystem.donateToAuthor('${post.authorId}', '${post.author}')" 
                                style="background: linear-gradient(135deg, #f59e0b, #ea580c); border: none; color: white; padding: 18px 45px; border-radius: 40px; font-size: 1.15rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1); box-shadow: 0 10px 30px rgba(245, 158, 11, 0.4); border: 1px solid rgba(255,255,255,0.2);">
                            <i class="fa-solid fa-mug-hot"></i> Yazarına Kahve Ismarla
                        </button>
                    </div>

                    <!-- Related Posts -->
                    ${this.renderRelatedPosts(post)}

                    <!-- Comments Section -->
                    <div id="blog-comments-container" style="margin-top: 60px; padding-top: 40px; border-top: 1px solid rgba(255, 255, 255, 0.05);">
                        <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 25px; color: #fff;">Sohbete Katıl</h3>
                        <div id="blog-comments-list"></div>
                    </div>
                </div>
            </div>
        `;
        
        // Initialize Enhanced Comments for this post
        setTimeout(() => {
            if (window.EnhancedComments) {
                EnhancedComments.renderInline('blog-comments-list', post.id);
            }
        }, 100);

        // Increment view count
        post.views = (post.views || 0) + 1;
    },

    donateToAuthor(authorId, authorName) {
        if (!State.currentUser) {
            Toast.warning('Bağış yapmak için giriş yapmalısınız!');
            return;
        }

        if (window.DonationSystem && DonationSystem.openModal) {
            DonationSystem.openModal(authorId || 'blogger', authorName || 'Yazar');
        } else {
            Toast.error('Bağış sistemi yüklenemedi.');
        }
    },

    getCategoryName(catKey) {
        const cats = {
            'news': 'Haber',
            'review': 'İnceleme',
            'theory': 'Teori',
            'analysis': 'Analiz',
            'general': 'Genel'
        };
        return cats[catKey] || 'Genel';
    },

    formatDate(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        return d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
    },

    canCreatePost() {
        return State.currentUser && (State.currentUser.role === 'admin' || State.currentUser.role === 'blogger' || (State.currentUser.badges && State.currentUser.badges.includes('Yazar')));
    },

    createPost(title, content, category, coverImage, tags) {
        if (!State.currentUser) {
            Toast.error('Giriş yapmalısınız!');
            return;
        }

        const isAdmin = State.currentUser.role === 'admin' || (State.currentUser.badges && State.currentUser.badges.includes('Yönetici'));

        const post = {
            title: title,
            content: content,
            category: category,
            image: coverImage || '',
            tags: tags || '',
            author: State.currentUser.username,
            authorId: State.currentUser.id,
            authorAvatar: State.currentUser.avatar || 'assets/logo.png',
            date: new Date().toISOString(),
            approvalStatus: isAdmin ? 'published' : 'pending'
        };

        // Use consistent API endpoint for both admins and users
        fetch('api/db.php?action=blog-save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(post)
        })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    if (isAdmin) {
                        Toast.success('Yazı yayınlandı!');
                        // Optionally update local state if needed for instant feedback
                        if (!State.data.blogPosts) State.data.blogPosts = [];
                        post.id = res.id;
                        State.data.blogPosts.unshift(post);
                        this.loadPosts();
                    } else {
                        Toast.success('Yazı onay için yöneticiye gönderildi.');
                    }
                } else {
                    Toast.error(res.message || 'Bir hata oluştu.');
                }
            })
            .catch(err => {
                console.error('Blog save error:', err);
                Toast.error('Sunucu hatası oluştu.');
            });

        return post;
    },

    loadPosts() {
        // Already loaded via db.blogPosts in main App init usually
        // But we can trigger a re-render if needed
        const container = document.getElementById('blog-posts-grid');
        if (container) {
            container.innerHTML = this.render(ViewManager.currentBlogCategory);
        }
    }
};

window.BlogSystem = BlogSystem;
