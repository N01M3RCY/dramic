/**
 * DRAMICBOX - STATISTICS SYSTEM
 * Handles calculation and display of user statistics
 */

const Statistics = {
    // Calculate stats for a specific user
    getStats(userId) {
        const targetId = userId || (State.currentUser ? State.currentUser.id : null);

        // Default stats
        const stats = {
            totalSeries: 0,
            totalEpisodes: 0,
            totalTime: 0,
            completionRate: 0,
            favoriteGenre: 'Belirsiz',
            level: 1,
            xp: 0
        };

        if (!State.data || !State.data.users) return stats;
        const user = State.data.users.find(u => u.id === targetId);
        if (!user) return stats;

        // XP
        if (user.stats && typeof user.stats.xp !== 'undefined') {
            stats.xp = user.stats.xp;
        }

        // Calculate from Watch History
        if (user.watchHistory) {
            stats.totalSeries = user.watchHistory.length;

            // Calculate episodes and time
            user.watchHistory.forEach(historyItem => {
                const series = State.data.series.find(s => s.id === historyItem.seriesId);
                if (series) {
                    // If episode tracking exists
                    if (historyItem.watchedEpisodes) {
                        stats.totalEpisodes += historyItem.watchedEpisodes.length;
                        // Estimate 45 mins per episode
                        stats.totalTime += (historyItem.watchedEpisodes.length * 45);
                    } else {
                        // Fallback: Assume completed if in history but no details
                        // Estimate based on series type
                        const epCount = series.episodes ? series.episodes.length : (series.seasons ? series.seasons.reduce((acc, s) => acc + (s.episodes ? s.episodes.length : 0), 0) : 12);
                        stats.totalEpisodes += epCount;
                        stats.totalTime += (epCount * 45);
                    }
                }
            });
        }

        // Determine Favorite Genre
        if (user.watchHistory && user.watchHistory.length > 0) {
            const genres = {};
            user.watchHistory.forEach(item => {
                const series = State.data.series.find(s => s.id === item.seriesId);
                if (series && series.genres) {
                    series.genres.forEach(g => {
                        genres[g] = (genres[g] || 0) + 1;
                    });
                }
            });

            const sortedGenres = Object.entries(genres).sort((a, b) => b[1] - a[1]);
            if (sortedGenres.length > 0) {
                stats.favoriteGenre = sortedGenres[0][0];
            }
        }

        // Level
        if (user.stats && user.stats.level) {
            stats.level = user.stats.level;
        } else if (window.Gamification) {
            stats.level = Gamification.getLevel(user.stats ? user.stats.xp : 0);
        }

        return stats;
    },

    // Render stats to a container
    renderStats(containerId, userId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const stats = this.getStats(userId);

        // Format time (Minutes to H/D)
        let timeString = "";
        if (stats.totalTime < 60) timeString = `${stats.totalTime} dk`;
        else if (stats.totalTime < 1440) timeString = `${Math.floor(stats.totalTime / 60)} sa ${stats.totalTime % 60} dk`;
        else timeString = `${Math.floor(stats.totalTime / 1440)} gün`;

        container.innerHTML = `
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(var(--primary-rgb), 0.1); color: var(--primary-color);">
                    <i class="fa-solid fa-play"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-value">${stats.totalWatched}</div>
                    <div class="stat-label">Dizi/Film</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(59, 130, 246, 0.1); color: #3b82f6;">
                    <i class="fa-solid fa-layer-group"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-value">${stats.totalEpisodes}</div>
                    <div class="stat-label">Bölüm</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1); color: #10b981;">
                    <i class="fa-solid fa-clock"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-value">${timeString}</div>
                    <div class="stat-label">İzleme Süresi</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1); color: #f59e0b;">
                    <i class="fa-solid fa-heart"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-value" style="font-size: 1rem;">${stats.favoriteGenre}</div>
                    <div class="stat-label">Favori Tür</div>
                </div>
            </div>
        `;
    }
};

window.Statistics = Statistics;
