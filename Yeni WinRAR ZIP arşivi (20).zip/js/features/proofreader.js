/**
 * Community Proofreading System
 * Allows users to report errors in episodes and earn rewards.
 */

window.Proofreader = {
    showReportModal(seriesId, episodeNum) {
        if (!State.currentUser) {
            Toast.error('Hata bildirmek için giriş yapmalısınız.');
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'report-error-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 450px; width: 90%; background: #0f172a; border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 20px; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.5);">
                <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2 style="margin: 0; color: #fff;">Hata Bildir (Bölüm ${episodeNum})</h2>
                    <button class="modal-close" onclick="document.getElementById('report-error-modal').remove()" style="background: none; border: none; color: #64748b; font-size: 24px; cursor: pointer;">&times;</button>
                </div>
                <div class="modal-body">
                    <form onsubmit="event.preventDefault(); Proofreader.submitReport('${seriesId}', ${episodeNum})">
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label style="display: block; color: #94a3b8; margin-bottom: 8px; font-size: 14px;">Hata Türü</label>
                            <select id="report-type" class="form-input" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 12px; color: #fff;">
                                <option value="typo">Yazım Hatası</option>
                                <option value="timing">Zamanlama Kayması</option>
                                <option value="logic">Mantık Hatası / Yanlış Çeviri</option>
                                <option value="other">Diğer</option>
                            </select>
                        </div>
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label style="display: block; color: #94a3b8; margin-bottom: 8px; font-size: 14px;">Hata Detayı</label>
                            <textarea id="report-description" class="form-input" style="width: 100%; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 12px; color: #fff; height: 100px; resize: none;" placeholder="Lütfen hatayı detaylandırın (Dakika/Saniye belirtebilirsiniz)..." required></textarea>
                        </div>
                        <div style="background: rgba(139, 92, 246, 0.1); border: 1px dashed rgba(139, 92, 246, 0.3); padding: 15px; border-radius: 12px; margin-bottom: 25px;">
                            <p style="font-size: 12px; color: #c084fc; margin: 0; line-height: 1.5;">
                                <i class="fa-solid fa-gift"></i> Hatalı kısımları düzeltmemize yardımcı olduğunuz için teşekkürler! Onaylanan her rapor için <strong>20 Coin</strong> kazanırsınız.
                            </p>
                        </div>
                        <div class="form-actions" style="display: flex; justify-content: flex-end; gap: 10px;">
                            <button type="button" class="btn btn-outline" onclick="document.getElementById('report-error-modal').remove()" style="padding: 10px 20px; border-radius: 10px;">İptal</button>
                            <button type="submit" class="btn btn-primary" style="padding: 10px 25px; border-radius: 10px; background: linear-gradient(135deg, #8b5cf6, #d946ef); border: none; color: #fff; font-weight: 600; cursor: pointer;">Raporu Gönder</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async submitReport(seriesId, episodeNum) {
        const type = document.getElementById('report-type').value;
        const description = document.getElementById('report-description').value;

        try {
            const response = await fetch('api/db.php?action=rep-submit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ seriesId, episodeNum, type, description })
            });

            const result = await response.json();
            if (result.success) {
                Toast.success('Raporunuz iletildi! İncelendikten sonra bilgilendirileceksiniz.');
                document.getElementById('report-error-modal').remove();
            } else {
                Toast.error(result.message);
            }
        } catch (e) {
            console.error('Report submission error:', e);
            Toast.error('Sunucu hatası');
        }
    }
};
