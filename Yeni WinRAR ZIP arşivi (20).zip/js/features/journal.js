/**
 * JournalService - Dramicbox E-Magazine (E-Dergi) System
 * Version 1.0 (Premium)
 */

const JournalService = {
    init() {
        console.log('📖 Journal Service Initialized');
        if (!State.data.journals) {
            State.data.journals = {
                draft: {
                    title: 'Dramicbox Sayı #1',
                    month: 'Mayıs',
                    year: '2024',
                    coverImage: 'assets/blog-placeholder.jpg',
                    sections: {
                        editorNote: 'Bu sayımızda...',
                        fanArts: [],
                        topReviews: [],
                        interviews: []
                    }
                },
                allIssues: []
            };
        }
    },

    updateDraft(data) {
        State.data.journals.draft = { ...State.data.journals.draft, ...data };
        db.save();
        Toast.success('Taslak güncellendi.');
    },

    addToJournal(type, content) {
        if (!State.data.journals) this.init();
        const draft = State.data.journals.draft;

        if (type === 'fanArt') {
            draft.sections.fanArts.push(content);
        } else if (type === 'review') {
            draft.sections.topReviews.push(content);
        }
        
        db.save();
        Toast.success('İçerik dergi havuzuna eklendi.');
    },

    publishIssue() {
        const draft = State.data.journals.draft;
        if (!draft.title) {
            Toast.error('Lütfen bir başlık girin.');
            return;
        }

        const issue = {
            ...JSON.parse(JSON.stringify(draft)),
            id: 'journal_' + Date.now(),
            publishedAt: new Date().toISOString()
        };

        State.data.journals.allIssues.unshift(issue);
        
        // Reset Draft for next month
        State.data.journals.draft = {
            title: '',
            month: this.getNextMonth(),
            year: new Date().getFullYear().toString(),
            coverImage: '',
            sections: { editorNote: '', fanArts: [], topReviews: [], interviews: [] }
        };

        db.save();
        Toast.success('Yeni dergi sayısı başarıyla yayınlandı!');
        if (window.ManagementHub) ManagementHub.render();
    },

    getNextMonth() {
        const months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
        const now = new Date();
        return months[(now.getMonth() + 1) % 12];
    }
};

window.JournalService = JournalService;
