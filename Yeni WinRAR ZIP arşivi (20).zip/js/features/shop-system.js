const CustomConfirm = {
    show(message, onConfirm) {
        const existing = document.getElementById('custom-confirm-modal');
        if (existing) existing.remove();

        const modal = document.createElement('div');
        modal.id = 'custom-confirm-modal';
        modal.style.cssText = `
            position: fixed; inset: 0; z-index: 100020;
            background: rgba(5, 5, 8, 0.85);
            backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px);
            display: flex; align-items: center; justify-content: center;
            animation: shopFadeIn 0.3s ease;
            padding: 20px;
        `;

        modal.innerHTML = `
            <div class="glass-panel" style="
                background: linear-gradient(135deg, rgba(20, 20, 30, 0.9), rgba(10, 10, 15, 0.95));
                border: 1px solid rgba(139, 92, 246, 0.25);
                box-shadow: 0 30px 70px rgba(0,0,0,0.8), 0 0 50px rgba(139, 92, 246, 0.15);
                border-radius: 24px; padding: 30px; text-align: center;
                max-width: 450px; width: 100%;
                transform: translateY(20px); transition: transform 0.3s ease;
                color: white;
                font-family: 'Outfit', sans-serif;
            ">
                <div style="font-size: 3rem; margin-bottom: 20px; color: #fbbf24;"><i class="fa-solid fa-circle-question"></i></div>
                <h3 style="margin: 0 0 15px; font-weight: 800; font-size: 1.25rem;">Onay Gerekiyor</h3>
                <p style="color: #94a3b8; font-size: 0.95rem; line-height: 1.6; margin-bottom: 25px;">${message}</p>
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <button id="confirm-cancel-btn" style="flex: 1; padding: 12px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08); background: rgba(255,255,255,0.02); color: #94a3b8; font-weight: 700; cursor: pointer; transition: all 0.2s;">İptal</button>
                    <button id="confirm-ok-btn" style="flex: 1; padding: 12px; border-radius: 12px; border: none; background: linear-gradient(135deg, #7c3aed, #6d28d9); color: white; font-weight: 800; cursor: pointer; box-shadow: 0 5px 15px rgba(124,58,237,0.3); transition: all 0.2s;">Onayla</button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        setTimeout(() => {
            const panel = modal.querySelector('.glass-panel');
            if (panel) panel.style.transform = 'translateY(0)';
        }, 50);

        const closeModal = () => {
            const panel = modal.querySelector('.glass-panel');
            if (panel) panel.style.transform = 'translateY(20px)';
            modal.style.opacity = '0';
            setTimeout(() => modal.remove(), 300);
        };

        modal.querySelector('#confirm-cancel-btn').onclick = () => {
            closeModal();
        };

        modal.querySelector('#confirm-ok-btn').onclick = () => {
            closeModal();
            if (onConfirm) onConfirm();
        };
    }
};
window.CustomConfirm = CustomConfirm;

const ShopSystem = {
    items: {
        premium: [
            { id: 'vip_1_month', name: 'VIP Üyelik (1 Ay)', price: 200, duration: 30, type: 'premium', icon: '👑', desc: '1 Ay boyunca tüm VIP ayrıcalıkları' },
            { id: 'vip_3_month', name: 'VIP Üyelik (3 Ay)', price: 520, duration: 90, type: 'premium', icon: '🌟', desc: '3 Ay boyunca indirimli VIP keyfi' },
            { id: 'vip_1_year', name: 'VIP Üyelik (1 Yıl)', price: 1500, duration: 365, type: 'premium', icon: '👑', desc: '1 Yıl boyunca tüm VIP ayrıcalıkları' }
        ],
        chests: [
            { id: 'chest_bronze', name: 'Bronz Sandık', price: 150, type: 'chest', icon: '📦', color: '#cd7f32', desc: 'Bronz kart sandığı. Ortak ve Nadir kartlar içerir.' },
            { id: 'chest_silver', name: 'Gümüş Sandık', price: 350, type: 'chest', icon: '📦', color: '#c0c0c0', desc: 'Gümüş kart sandığı. Nadir ve Epik kart çıkma şansı yüksektir.' },
            { id: 'chest_gold', name: 'Altın Sandık', price: 800, type: 'chest', icon: '📦', color: '#ffd700', desc: 'Altın kart sandığı. Epik ve Efsanevi kartlar için en iyisi!' }
        ]
    },

    currentTab: 'premium',

    init() {
        console.log('🛍️ Shop System Loaded');
        this.injectStyles();
    },

    injectStyles() {
        if (document.getElementById('shop-styles-v2')) return;
        const style = document.createElement('style');
        style.id = 'shop-styles-v2';
        style.textContent = `
            /* ═══════════════ DRAMIC MARKET V2 - Premium Design ═══════════════ */
            .shop-overlay-v2 {
                position: fixed; inset: 0; z-index: 100005;
                background: rgba(5, 5, 8, 0.85);
                backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
                display: flex; justify-content: center; align-items: flex-start;
                overflow-y: auto; padding: 60px 20px;
                animation: shopFadeIn 0.4s ease;
            }
            @keyframes shopFadeIn { from { opacity: 0; } to { opacity: 1; } }
            .shop-wrapper-v2 {
                width: 100%; max-width: 950px;
                background: rgba(13, 13, 20, 0.85);
                border: 1px solid rgba(139, 92, 246, 0.25);
                border-radius: 32px;
                padding: 40px;
                margin: 0 auto;
                box-shadow: 0 30px 80px rgba(0,0,0,0.8), 0 0 50px rgba(139,92,246,0.1);
                backdrop-filter: blur(30px); -webkit-backdrop-filter: blur(30px);
                position: relative;
                max-height: none;
                overflow: visible;
                animation: shopSlideUp 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
            }
            @keyframes shopSlideUp { from { transform: translateY(40px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

            .shop-hero-v2 {
                background: transparent;
                border: none;
                border-bottom: 1px solid rgba(255,255,255,0.06);
                border-radius: 0; padding: 0 0 25px 0;
                display: flex; justify-content: space-between; align-items: center;
                margin-bottom: 30px; position: relative; overflow: hidden;
            }
            .shop-hero-title { font-size: 2.2rem; font-weight: 900; color: #fff; letter-spacing: -1px; display: flex; align-items: center; gap: 15px; position: relative; z-index: 1; }
            .shop-hero-title i { background: linear-gradient(135deg, #a78bfa, #f472b6); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-size: 2rem; filter: drop-shadow(0 0 15px rgba(167,139,250,0.5)); }
            .shop-hero-subtitle { color: #94a3b8; font-size: 0.95rem; margin-top: 6px; font-weight: 500; }
            .shop-balance-v2 {
                background: rgba(251,191,36,0.08); border: 1px solid rgba(251,191,36,0.25);
                padding: 16px 28px; border-radius: 20px; display: flex; align-items: center; gap: 12px;
                font-weight: 900; color: #fbbf24; font-size: 1.3rem;
                box-shadow: 0 0 30px rgba(251,191,36,0.08); position: relative; z-index: 1;
                font-family: 'Outfit', sans-serif;
            }
            .shop-balance-v2 i { font-size: 1.2rem; }
            .shop-close-v2 {
                position: absolute; top: 20px; right: 25px; z-index: 10;
                background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);
                width: 44px; height: 44px; border-radius: 14px; color: #94a3b8;
                display: flex; align-items: center; justify-content: center;
                cursor: pointer; transition: all 0.3s; font-size: 1.2rem;
            }
            .shop-close-v2:hover { background: rgba(239,68,68,0.15); color: #ef4444; border-color: rgba(239,68,68,0.3); }

            .shop-tabs-v2 {
                display: flex; gap: 8px; margin-bottom: 30px;
                background: rgba(255,255,255,0.02); padding: 8px;
                border-radius: 20px; border: 1px solid rgba(255,255,255,0.05);
                overflow-x: auto; scrollbar-width: none;
            }
            .shop-tabs-v2::-webkit-scrollbar { display: none; }
            .shop-tab-v2 {
                padding: 12px 24px; border-radius: 14px; border: none;
                background: transparent; color: #64748b; font-weight: 700;
                cursor: pointer; transition: all 0.3s; white-space: nowrap;
                font-size: 0.9rem; display: flex; align-items: center; gap: 8px;
                font-family: 'Inter', sans-serif;
            }
            .shop-tab-v2:hover { color: #e2e8f0; background: rgba(255,255,255,0.04); }
            .shop-tab-v2.active {
                background: linear-gradient(135deg, #7c3aed, #6d28d9);
                color: #fff; box-shadow: 0 8px 25px rgba(124,58,237,0.35);
            }
            .shop-tab-v2.vip-tab { color: #fbbf24; }
            .shop-tab-v2.vip-tab.active { background: linear-gradient(135deg, #f59e0b, #d97706); color: #fff; box-shadow: 0 8px 25px rgba(245,158,11,0.35); }

            .shop-grid-v2 {
                display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
                gap: 20px;
            }

            .shop-card-v2 {
                background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06);
                border-radius: 24px; padding: 28px; text-align: center;
                transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
                position: relative; overflow: hidden;
            }
            .shop-card-v2:hover {
                transform: translateY(-8px) scale(1.02);
                border-color: rgba(124,58,237,0.3);
                box-shadow: 0 20px 50px rgba(0,0,0,0.4), 0 0 30px rgba(124,58,237,0.08);
                background: rgba(255,255,255,0.04);
            }
            .shop-card-v2.owned { border-color: rgba(16,185,129,0.3); }
            .shop-card-v2.owned::after {
                content: '✓'; position: absolute; top: 12px; right: 14px;
                background: #10b981; color: #fff; width: 24px; height: 24px;
                border-radius: 50%; display: flex; align-items: center; justify-content: center;
                font-size: 0.7rem; font-weight: 900;
            }

            .shop-preview-v2 {
                width: 100px; height: 100px; margin: 0 auto 20px;
                border-radius: 50%; display: flex; align-items: center; justify-content: center;
                position: relative;
            }
            .shop-preview-v2.frame-preview {
                border: 3px solid var(--frame-color, #a78bfa);
                box-shadow: 0 0 20px var(--frame-color, rgba(167,139,250,0.3)),
                            0 0 40px var(--frame-color, rgba(167,139,250,0.1));
                padding: 4px;
            }
            .shop-preview-v2.frame-preview img {
                width: 100%; height: 100%; border-radius: 50%; object-fit: cover;
            }
            .shop-preview-v2.glow-preview {
                font-size: 1.1rem; font-weight: 900; padding: 15px;
                text-shadow: 0 0 15px var(--glow-color, #a78bfa), 0 0 30px var(--glow-color, rgba(167,139,250,0.5));
                color: var(--glow-color, #a78bfa);
                background: rgba(0,0,0,0.3); border-radius: 16px;
                width: auto; height: auto;
            }
            .shop-preview-v2.badge-preview {
                font-size: 3.5rem; filter: drop-shadow(0 0 15px rgba(255,255,255,0.2));
                background: rgba(0,0,0,0.2); border-radius: 24px;
                width: 100px; height: 100px;
            }
            .shop-preview-v2.premium-preview {
                font-size: 4rem;
                filter: drop-shadow(0 0 25px rgba(251,191,36,0.5));
                animation: premiumFloat 3s ease-in-out infinite;
                background: rgba(251,191,36,0.05); border-radius: 50%;
                border: 2px solid rgba(251,191,36,0.15);
            }
            @keyframes premiumFloat {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-8px); }
            }
            .shop-preview-v2.theme-preview {
                font-size: 3rem; color: #a78bfa;
                background: rgba(124,58,237,0.08); border-radius: 24px;
                border: 1px solid rgba(124,58,237,0.15);
            }

            .shop-card-name { font-weight: 800; color: #fff; font-size: 1.05rem; margin-bottom: 6px; letter-spacing: -0.3px; }
            .shop-card-desc { font-size: 0.78rem; color: #64748b; margin-bottom: 18px; line-height: 1.5; }
            .shop-card-price { font-size: 0.8rem; color: #fbbf24; font-weight: 800; margin-bottom: 14px; display: flex; align-items: center; justify-content: center; gap: 6px; }

            .shop-btn-v2 {
                width: 100%; padding: 14px; border-radius: 14px; border: none;
                font-weight: 800; cursor: pointer; font-size: 0.9rem;
                transition: all 0.3s; display: flex; align-items: center;
                justify-content: center; gap: 8px; font-family: 'Inter', sans-serif;
            }
            .shop-btn-v2.buy-btn {
                background: linear-gradient(135deg, #7c3aed, #6d28d9);
                color: #fff; box-shadow: 0 6px 20px rgba(124,58,237,0.3);
            }
            .shop-btn-v2.buy-btn:hover { transform: scale(1.03); box-shadow: 0 8px 25px rgba(124,58,237,0.5); }
            .shop-btn-v2.equip-btn {
                background: rgba(16,185,129,0.1); color: #34d399;
                border: 1px solid rgba(16,185,129,0.2);
            }
            .shop-btn-v2.equip-btn:hover { background: rgba(16,185,129,0.15); }
            .shop-btn-v2.equipped-btn {
                background: rgba(255,255,255,0.03); color: #475569;
                cursor: default; border: 1px solid rgba(255,255,255,0.05);
            }
            .shop-btn-v2.owned-btn {
                background: rgba(255,255,255,0.03); color: #475569;
                cursor: default; border: 1px solid rgba(255,255,255,0.05);
            }

            /* VIP Banner */
            .vip-banner-v2 {
                grid-column: 1 / -1; border-radius: 24px; padding: 30px;
                background: linear-gradient(135deg, rgba(16,185,129,0.12) 0%, rgba(5,150,105,0.08) 100%);
                border: 1px solid rgba(16,185,129,0.2);
                display: flex; justify-content: space-between; align-items: center;
                margin-bottom: 10px;
            }
            .vip-banner-v2.lifetime {
                background: linear-gradient(135deg, rgba(139,92,246,0.12) 0%, rgba(109,40,217,0.08) 100%);
                border-color: rgba(139,92,246,0.3);
            }
            .vip-banner-v2 h3 { margin: 0; font-size: 1.2rem; color: #fff; display: flex; align-items: center; gap: 10px; }
            .vip-banner-v2 p { margin: 6px 0 0; color: rgba(255,255,255,0.7); font-size: 0.9rem; }

            /* VIP Benefits */
            .vip-benefits-v2 {
                grid-column: 1 / -1; border-radius: 24px; padding: 30px;
                background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06);
                margin-bottom: 10px;
            }
            .vip-benefits-v2 h4 { color: #fbbf24; font-size: 1rem; font-weight: 800; margin: 0 0 20px; display: flex; align-items: center; gap: 10px; }
            .vip-benefits-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; }
            .vip-benefit-item {
                display: flex; align-items: center; gap: 12px; padding: 12px 16px;
                background: rgba(251,191,36,0.04); border-radius: 14px;
                border: 1px solid rgba(251,191,36,0.08);
            }
            .vip-benefit-item i { color: #fbbf24; font-size: 1rem; width: 20px; text-align: center; }
            .vip-benefit-item span { color: #e2e8f0; font-size: 0.85rem; font-weight: 600; }

            .shop-premium-card {
                border-color: rgba(251,191,36,0.2) !important;
                background: linear-gradient(180deg, rgba(251,191,36,0.04) 0%, rgba(255,255,255,0.01) 100%) !important;
            }
            .shop-premium-card:hover { border-color: rgba(251,191,36,0.4) !important; box-shadow: 0 20px 50px rgba(0,0,0,0.4), 0 0 30px rgba(251,191,36,0.1) !important; }

            .shop-footer-v2 {
                margin-top: 30px; padding: 20px 25px;
                background: rgba(255,255,255,0.02); border-radius: 20px;
                border: 1px solid rgba(255,255,255,0.04);
                font-size: 0.78rem; color: #475569; display: flex; align-items: center; gap: 10px;
            }

            @media (max-width: 768px) {
                .shop-hero-v2 { flex-direction: column; gap: 20px; text-align: center; padding: 30px 20px; }
                .shop-hero-title { font-size: 1.6rem; justify-content: center; }
                .shop-grid-v2 { grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 12px; }
                .shop-card-v2 { padding: 20px; }
                .shop-preview-v2 { width: 80px; height: 80px; }
                .shop-preview-v2.badge-preview { width: 80px; height: 80px; font-size: 2.5rem; }
                .vip-banner-v2 { flex-direction: column; text-align: center; gap: 15px; }
                .vip-benefits-grid { grid-template-columns: 1fr; }
            }

            /* ═══════════════ CARD REVEAL 3D ANIMATION ═══════════════ */
            .reveal-modal {
                position: fixed; inset: 0; z-index: 100010;
                background: rgba(4, 4, 6, 0.95);
                display: flex; flex-direction: column; align-items: center; justify-content: center;
                perspective: 1000px;
                animation: shopFadeIn 0.3s ease;
                overflow-y: auto;
                padding: 40px 20px;
            }
            .reveal-grid {
                display: flex;
                gap: 20px;
                justify-content: center;
                align-items: center;
                flex-wrap: wrap;
                max-width: 1400px;
                padding: 20px;
                margin-bottom: 30px;
            }
            .reveal-card-container {
                width: 200px; height: 300px;
                position: relative;
                transform-style: preserve-3d;
                transition: transform 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                cursor: pointer;
            }
            .reveal-card-container.flipped {
                transform: rotateY(180deg);
            }
            .reveal-card-face {
                position: absolute; inset: 0;
                backface-visibility: hidden;
                -webkit-backface-visibility: hidden;
                border-radius: 18px;
                display: flex; flex-direction: column;
                align-items: center; justify-content: center;
                box-shadow: 0 15px 30px rgba(0,0,0,0.6);
            }
            .reveal-card-front {
                background: linear-gradient(135deg, #241442 0%, #0d061a 100%);
                border: 2px solid rgba(139, 92, 246, 0.4);
                box-shadow: 0 0 25px rgba(139, 92, 246, 0.2);
            }
            .reveal-card-front i {
                font-size: 3rem;
                background: linear-gradient(135deg, #a78bfa, #f472b6);
                -webkit-background-clip: text; -webkit-text-fill-color: transparent;
                margin-bottom: 15px;
                animation: floatIcon 3s infinite ease-in-out;
            }
            @keyframes floatIcon {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-12px); }
            }
            .reveal-card-back {
                transform: rotateY(180deg);
                background: linear-gradient(135deg, #13141f 0%, #08080c 100%);
                border: 3px solid var(--rarity-color, #94a3b8);
                box-shadow: 0 0 30px var(--rarity-color, rgba(148, 163, 184, 0.2));
                padding: 15px;
                text-align: center;
                justify-content: space-between !important;
            }
            .reveal-card-rarity-badge {
                padding: 4px 10px; border-radius: 12px; font-weight: 800; font-size: 0.65rem; text-transform: uppercase;
                background: var(--rarity-bg, rgba(255,255,255,0.05));
                color: var(--rarity-color, #fff);
                border: 1px solid var(--rarity-color, #fff);
                box-shadow: 0 0 8px var(--rarity-color, rgba(255,255,255,0.1));
                margin-bottom: 8px;
                width: fit-content;
                align-self: center;
            }
            .reveal-card-img {
                width: 100px; height: 100px; border-radius: 50%;
                border: 3px solid var(--rarity-color, #94a3b8);
                padding: 5px; object-fit: cover;
                box-shadow: 0 0 35px var(--rarity-color, rgba(148, 163, 184, 0.3));
                margin-bottom: 15px;
            }
            .reveal-card-name {
                font-size: 1.6rem; font-weight: 900; color: #fff; margin-bottom: 5px;
                text-shadow: 0 2px 10px rgba(0,0,0,0.5);
            }
            .reveal-card-subname {
                font-size: 1rem; font-weight: 600; color: var(--rarity-color, #94a3b8); margin-bottom: 15px;
            }
            .reveal-bonus-info {
                background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05);
                padding: 10px 20px; border-radius: 14px; color: #fbbf24; font-weight: 700; font-size: 0.9rem;
                display: flex; align-items: center; gap: 8px;
            }
        `;
        document.head.appendChild(style);
    },

    open(initialTab) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Mağazayı kullanmak için giriş yapmalısınız!');
            if (window.Auth && Auth.openLoginModal) Auth.openLoginModal();
            else if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }

        // Ensure styles are always injected
        this.injectStyles();

        // Remove existing
        const existing = document.getElementById('shop-overlay-v2');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.className = 'shop-overlay-v2';
        overlay.id = 'shop-overlay-v2';
        overlay.onclick = (e) => { if (e.target === overlay) this.close(); };

        const tabsConfig = [
            { key: 'premium', label: 'VIP Üyelik', icon: 'fa-crown', isVip: true },
            { key: 'chests', label: 'Kart Sandıkları', icon: 'fa-box-open', isVip: false }
        ];

        overlay.innerHTML = `
            <div class="shop-wrapper-v2">
                <div class="shop-hero-v2">
                    <div>
                        <div class="shop-hero-title">
                            <i class="fa-solid fa-gem"></i> DRAMIC MARKET
                        </div>
                        <div class="shop-hero-subtitle">DramicBox VIP Üyesi ol veya Oyuncu Kartı Sandıkları açarak koleksiyonunu tamamla! 👑</div>
                    </div>
                    <div class="shop-balance-v2">
                        <i class="fa-solid fa-coins"></i>
                        <span id="shop-balance-val">${State.currentUser.stats?.coins || 0}</span>
                    </div>
                    <button class="shop-close-v2" onclick="ShopSystem.close()">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>

                <div class="shop-tabs-v2" style="display: flex;">
                    ${tabsConfig.map(t => `
                        <button class="shop-tab-v2 ${t.isVip ? 'vip-tab' : ''} ${this.currentTab === t.key ? 'active' : ''}" 
                                onclick="ShopSystem.switchTab('${t.key}')">
                            <i class="fa-solid ${t.icon}"></i> ${t.label}
                        </button>
                    `).join('')}
                </div>

                <div class="shop-grid-v2" id="shop-items-grid"></div>

                <div class="shop-footer-v2">
                    <i class="fa-solid fa-circle-info"></i>
                    VIP üyelik anında hesabınıza tanımlanır. Dijital üyeliklerde iade yapılmaz.
                </div>
            </div>
        `;

        document.body.appendChild(overlay);
        this.currentTab = 'premium';
        this.renderItems(this.currentTab);
    },

    close() {
        const overlay = document.getElementById('shop-overlay-v2');
        if (overlay) {
            overlay.style.animation = 'shopFadeIn 0.3s ease reverse';
            setTimeout(() => overlay.remove(), 250);
        }
    },

    switchTab(tabId) {
        this.currentTab = tabId;
        document.querySelectorAll('.shop-tab-v2').forEach(t => {
            t.classList.remove('active');
            if (t.getAttribute('onclick')?.includes(`'${tabId}'`)) {
                t.classList.add('active');
            }
        });
        this.renderItems(this.currentTab);
    },

    renderItems(category) {
        const grid = document.getElementById('shop-items-grid');
        if (!grid) return;

        let items = [...(this.items[category] || [])];

        // Merge server items
        if (State.data && State.data.shopItems) {
            const serverItems = State.data.shopItems.filter(i => i.type === category || (category === 'frames' && i.type === 'frame') || (category === 'glows' && i.type === 'glow') || (category === 'badges' && i.type === 'badge'));
            serverItems.forEach(sItem => {
                const idx = items.findIndex(i => i.id === sItem.id);
                if (idx > -1) items[idx] = { ...items[idx], ...sItem };
                else items.push(sItem);
            });
        }

        const owned = State.currentUser.inventory || [];
        const activeItems = State.currentUser.activeItems || {};
        const badges = State.currentUser.badges || [];
        const isVip = State.currentUser.role === 'vip' || State.currentUser.role === 'admin';

        let headerHTML = '';

        // VIP Status Banner
        if (category === 'premium') {
            const expires = State.currentUser.vipStatus?.expiresAt;
            const now = Date.now();
            if (State.currentUser.vipStatus?.active && expires && expires > now) {
                const daysLeft = Math.ceil((expires - now) / (1000 * 60 * 60 * 24));
                const expiryDate = new Date(expires).toLocaleDateString('tr-TR');
                headerHTML = `
                    <div class="vip-banner-v2">
                        <div>
                            <h3><i class="fa-solid fa-crown" style="color:#10b981;"></i> VIP Üyeliğiniz Aktif</h3>
                            <p>Bitiş: <strong>${expiryDate}</strong> · Kalan: <strong style="color:#10b981;">${daysLeft} gün</strong></p>
                        </div>
                        <div style="font-size:3rem; opacity:0.15;"><i class="fa-solid fa-hourglass-half"></i></div>
                    </div>`;
            }

            // VIP Benefits Section
            headerHTML += `
                <div class="vip-benefits-v2">
                    <h4><i class="fa-solid fa-sparkles"></i> VIP Ayrıcalıkları</h4>
                    <div class="vip-benefits-grid">
                        <div class="vip-benefit-item"><i class="fa-solid fa-ban"></i><span>Reklamsız Deneyim</span></div>
                        <div class="vip-benefit-item"><i class="fa-solid fa-circle-user"></i><span>Özel VIP Çerçevesi</span></div>
                        <div class="vip-benefit-item"><i class="fa-solid fa-rainbow"></i><span>Gökkuşağı İsim Efekti</span></div>
                        <div class="vip-benefit-item"><i class="fa-solid fa-palette"></i><span>Özel Tema Seçenekleri</span></div>
                        <div class="vip-benefit-item"><i class="fa-solid fa-crown"></i><span>VIP Rozeti</span></div>
                        <div class="vip-benefit-item"><i class="fa-solid fa-bolt"></i><span>Öncelikli Destek</span></div>
                        <div class="vip-benefit-item"><i class="fa-solid fa-star"></i><span>Erken Erişim İçerikler</span></div>
                        <div class="vip-benefit-item"><i class="fa-solid fa-gift"></i><span>Aylık Bonus Coinler</span></div>
                    </div>
                </div>`;
        }

        const itemsHTML = items.map(item => {
            let isOwned = owned.includes(item.id);
            const isActive = (item.type === 'frame' && activeItems.frame === item.id) ||
                (item.type === 'glow' && activeItems.color === item.id) ||
                (item.type === 'theme' && activeItems.theme === item.id);

            if (item.type === 'premium') {
                if (item.id === 'vip_lifetime' && badges.includes('VIP+')) isOwned = true;
            }

            let previewHtml = this.getPreviewHTML(item);
            let actionBtn = '';

            if (isOwned && item.type !== 'premium') {
                if (isActive) {
                    actionBtn = `<button class="shop-btn-v2 equipped-btn" disabled><i class="fa-solid fa-check-circle"></i> Kuşanıldı</button>`;
                } else if (item.type === 'badge') {
                    actionBtn = `<button class="shop-btn-v2 owned-btn" disabled><i class="fa-solid fa-check"></i> Sahipsin</button>`;
                } else {
                    actionBtn = `<button class="shop-btn-v2 equip-btn" onclick="ShopSystem.equip('${item.id}', '${item.type}')"><i class="fa-solid fa-shirt"></i> Kuşan</button>`;
                }
            } else {
                if (item.type === 'premium' && item.id === 'vip_lifetime' && badges.includes('VIP+')) {
                    actionBtn = `<button class="shop-btn-v2 owned-btn" disabled><i class="fa-solid fa-check"></i> Satın Alındı</button>`;
                } else if (item.vipOnly && !isVip) {
                    actionBtn = `<button class="shop-btn-v2 buy-btn" style="background:linear-gradient(135deg,#f59e0b,#d97706);" onclick="Toast.info('Bu öğe sadece VIP üyelere özeldir.')"><i class="fa-solid fa-lock"></i> VIP Gerekli</button>`;
                } else {
                    actionBtn = `<button class="shop-btn-v2 buy-btn" onclick="ShopSystem.buy('${item.id}', '${category}')"><i class="fa-solid fa-coins"></i> ${item.price} Coin</button>`;
                }
            }

            return `
                <div class="shop-card-v2 ${isOwned ? 'owned' : ''} ${item.type === 'premium' ? 'shop-premium-card' : ''}">
                    ${previewHtml}
                    <div class="shop-card-name">${item.name}</div>
                    ${item.desc ? `<div class="shop-card-desc">${item.desc}</div>` : ''}
                    ${!isOwned && item.type !== 'premium' ? `<div class="shop-card-price"><i class="fa-solid fa-coins"></i> ${item.price} Coin</div>` : ''}
                    ${actionBtn}
                </div>
            `;
        }).join('');

        grid.innerHTML = headerHTML + itemsHTML;
    },

    getPreviewHTML(item) {
        const avatar = State.currentUser.avatar || 'assets/logo.png';
        if (item.type === 'frame') {
            return `<div class="shop-preview-v2 frame-preview" style="--frame-color: ${item.color || '#a78bfa'}"><img src="${avatar}"></div>`;
        } else if (item.type === 'glow') {
            const colorVal = item.color || '#a78bfa';
            return `<div class="shop-preview-v2 glow-preview" style="--glow-color: ${colorVal}; ${colorVal.includes('gradient') ? `background: ${colorVal}; -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-shadow: none;` : ''}">${State.currentUser.username}</div>`;
        } else if (item.type === 'badge') {
            return `<div class="shop-preview-v2 badge-preview">${item.icon}</div>`;
        } else if (item.type === 'premium') {
            return `<div class="shop-preview-v2 premium-preview">${item.icon}</div>`;
        } else if (item.type === 'theme') {
            return `<div class="shop-preview-v2 theme-preview"><i class="fa-solid fa-palette"></i></div>`;
        } else if (item.type === 'chest') {
            return `<div class="shop-preview-v2 chest-preview" style="font-size: 3.5rem; filter: drop-shadow(0 0 15px ${item.color || '#a78bfa'}); display:flex; align-items:center; justify-content:center;">${item.icon}</div>`;
        }
        return '';
    },

    buy(itemId, category) {
        const item = this.items[category].find(i => i.id === itemId);
        if (!item) return;

        const balance = State.currentUser.stats?.coins || 0;
        if (balance < item.price) {
            Toast.error('Yetersiz bakiye! Daha fazla Coin kazanmalısın.');
            return;
        }

        CustomConfirm.show(`${item.name} ürününü ${item.price} Coin karşılığında satın almak istediğinize emin misiniz?`, () => {
            // Deduct coins
            State.currentUser.stats.coins -= item.price;

            if (item.type === 'chest') {
                if (!State.currentUser.gamification) State.currentUser.gamification = {};
                if (!State.currentUser.gamification.chests) State.currentUser.gamification.chests = { bronze: 0, silver: 0, gold: 0 };
                
                let typeKey = 'bronze';
                if (item.id === 'chest_silver') typeKey = 'silver';
                if (item.id === 'chest_gold') typeKey = 'gold';

                State.currentUser.gamification.chests[typeKey] = (State.currentUser.gamification.chests[typeKey] || 0) + 1;

                const balanceVal = document.getElementById('shop-balance-val');
                if (balanceVal) balanceVal.innerText = State.currentUser.stats.coins;
                
                this.save();
                if (window.App && App.saveState) App.saveState();
                
                Toast.success(`${item.name} başarıyla satın alındı ve envanterine eklendi! Profilim sayfasından açabilirsin. 🎉`);
                this.renderItems(category);
                return;
            }

            // 1. Handle PREMIUM items
            if (item.type === 'premium') {
                this.handlePremiumPurchase(item);
            } else {
                // 2. Handle Normal items
                if (!State.currentUser.inventory) State.currentUser.inventory = [];
                State.currentUser.inventory.push(item.id);

                // Auto-equip frames and glows
                if (item.type !== 'badge') this.equip(item.id, item.type);
                else {
                    if (!State.currentUser.badges) State.currentUser.badges = [];
                    if (!State.currentUser.badges.includes(item.icon)) {
                        State.currentUser.badges.push(item.icon);
                    }
                }
                Toast.success(`${item.name} başarıyla satın alındı!`);
            }

            // Update UI
            const balanceVal = document.getElementById('shop-balance-val');
            if (balanceVal) balanceVal.innerText = State.currentUser.stats.coins;

            this.save();
            if (window.App && App.saveState) App.saveState();
            this.renderItems(category);
        });
    },

    handlePremiumPurchase(item) {
        if (!State.currentUser.vipStatus) {
            State.currentUser.vipStatus = { active: false, expiresAt: null, purchasedAt: null, isLifetime: false };
        }
        if (!State.currentUser.inventory) State.currentUser.inventory = [];
        if (!State.currentUser.badges) State.currentUser.badges = [];

        const now = Date.now();
        let baseExpiry = State.currentUser.vipStatus.expiresAt || now;
        if (baseExpiry < now) baseExpiry = now;

        const durationMs = (item.duration || 365) * 24 * 60 * 60 * 1000;
        const newExpiry = baseExpiry + durationMs;

        State.currentUser.vipStatus.purchasedAt = now;
        State.currentUser.vipStatus.lastPurchase = item.id;
        State.currentUser.vipStatus.expiresAt = newExpiry;
        State.currentUser.vipStatus.active = true;
        State.currentUser.vipStatus.isLifetime = false;
        State.currentUser.vipUntil = newExpiry;
        State.currentUser.isVip = true;

        if (!State.currentUser.badges.includes('VIP')) State.currentUser.badges.push('VIP');

        const expiryDate = new Date(newExpiry).toLocaleDateString('tr-TR');
        Toast.success(`👑 VIP üyeliğiniz aktif! Bitiş: ${expiryDate}`);

        if (!State.currentUser.inventory.includes('frame_vip_exclusive')) {
            State.currentUser.inventory.push('frame_vip_exclusive');
        }
        if (!State.currentUser.inventory.includes('glow_rainbow')) {
            State.currentUser.inventory.push('glow_rainbow');
        }

        if (State.currentUser.role !== 'admin' && State.currentUser.role !== 'moderator') {
            State.currentUser.role = 'vip';
        }

        this.save();
        if (window.App && App.saveState) App.saveState();

        if (window.db && db.logActivity) {
            db.logActivity(`${State.currentUser.username} ${item.name} satın aldı`, '💎');
        }
    },

    equip(itemId, type) {
        if (!State.currentUser.activeItems) State.currentUser.activeItems = {};

        if (type === 'frame') State.currentUser.activeItems.frame = itemId;
        if (type === 'glow') State.currentUser.activeItems.color = itemId;
        if (type === 'theme') State.currentUser.activeItems.theme = itemId;

        Toast.info('Öğe kuşanıldı.');
        this.save();
        this.renderItems(this.currentTab);

        if (window.Auth && Auth.updateAuthUI) Auth.updateAuthUI();
        if (window.App && App.showMainApp) App.showMainApp();
    },

    save() {
        if (window.db && db.updateUser) {
            db.updateUser(State.currentUser.id, State.currentUser);
        }
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
    },

    openChest(chestId) {
        const settingsArray = State.data?.settings || [];
        let chestSettings = Array.isArray(settingsArray)
            ? settingsArray.find(s => s.id === 'chest_settings')
            : settingsArray.chest_settings;

        if (!chestSettings) {
            chestSettings = {
                id: 'chest_settings',
                bronze: { price: 150, common: 70, rare: 20, epic: 8, legendary: 2 },
                silver: { price: 350, common: 40, rare: 40, epic: 15, legendary: 5 },
                gold: { price: 800, common: 15, rare: 30, epic: 40, legendary: 15 }
            };
        }

        let typeKey = 'bronze';
        let cardCount = 1;
        if (chestId === 'chest_silver' || chestId === 'silver') { typeKey = 'silver'; cardCount = 3; }
        if (chestId === 'chest_gold' || chestId === 'gold') { typeKey = 'gold'; cardCount = 5; }

        const probs = chestSettings[typeKey] || chestSettings['bronze'];
        const drawnCards = [];
        const chosenActorIds = new Set(); 

        if (!State.currentUser.actorCards) State.currentUser.actorCards = [];

        for (let i = 0; i < cardCount; i++) {
            const rand = Math.floor(Math.random() * 100);
            let rarity = 'Common';

            if (rand < probs.legendary) {
                rarity = 'Legendary';
            } else if (rand < probs.legendary + probs.epic) {
                rarity = 'Epic';
            } else if (rand < probs.legendary + probs.epic + probs.rare) {
                rarity = 'Rare';
            } else {
                rarity = 'Common';
            }

            let candidates = (State.data.actors || []).filter(a => 
                (a.rarity || 'Common') === rarity && 
                a.isCollectible !== false &&
                !chosenActorIds.has(a.id)
            );

            if (candidates.length === 0) {
                candidates = (State.data.actors || []).filter(a => 
                    a.isCollectible !== false && 
                    !chosenActorIds.has(a.id)
                );
            }

            let card = null;
            if (candidates.length > 0) {
                card = candidates[Math.floor(Math.random() * candidates.length)];
            } else {
                const allCollectibles = (State.data.actors || []).filter(a => a.isCollectible !== false);
                if (allCollectibles.length > 0) {
                    card = allCollectibles[Math.floor(Math.random() * allCollectibles.length)];
                }
            }

            if (!card) {
                continue;
            }

            chosenActorIds.add(card.id);

            const cardExists = State.currentUser.actorCards.some(c => c.id === card.id || c.name === card.name);
            let bonusCoins = 0;
            let isDuplicate = false;

            if (cardExists) {
                isDuplicate = true;
                const duplicateAwards = { Common: 50, Rare: 150, Epic: 300, Legendary: 600 };
                bonusCoins = duplicateAwards[card.rarity || 'Common'] || 50;
                State.currentUser.stats.coins += bonusCoins;
            } else {
                State.currentUser.actorCards.push({
                    id: card.id,
                    name: card.name,
                    avatar: card.avatar || card.image || 'assets/default-avatar.png',
                    rarity: card.rarity || 'Common',
                    awardedAt: new Date().toISOString()
                });
            }

            const baseBonus = Math.floor(Math.random() * 21) + 10;
            State.currentUser.stats.coins += baseBonus;

            drawnCards.push({
                card,
                isDuplicate,
                bonusCoins,
                baseBonus
            });
        }

        if (drawnCards.length === 0) {
            Toast.error('Veritabanında uygun koleksiyon oyuncusu bulunamadı!');
            return;
        }

        this.save();
        if (window.App && App.saveState) App.saveState();

        const oldReveal = document.getElementById('chest-reveal-modal');
        if (oldReveal) oldReveal.remove();

        const modal = document.createElement('div');
        modal.id = 'chest-reveal-modal';
        modal.className = 'reveal-modal';

        const cardsHTML = drawnCards.map((dc, index) => {
            let rarityColor = '#94a3b8';
            let rarityBg = 'rgba(148, 163, 184, 0.05)';
            let rarityLabel = 'Yaygın (Common)';
            
            if (dc.card.rarity === 'Rare') { rarityColor = '#3b82f6'; rarityBg = 'rgba(59, 130, 246, 0.08)'; rarityLabel = 'Nadir (Rare)'; }
            else if (dc.card.rarity === 'Epic') { rarityColor = '#a855f7'; rarityBg = 'rgba(168, 85, 247, 0.08)'; rarityLabel = 'Epik (Epic)'; }
            else if (dc.card.rarity === 'Legendary') { rarityColor = '#f59e0b'; rarityBg = 'rgba(245, 158, 11, 0.08)'; rarityLabel = 'Efsanevi (Legendary)'; }

            const avatar = dc.card.avatar || dc.card.image || 'assets/default-avatar.png';

            return `
                <div class="reveal-card-container" onclick="ShopSystem.revealFlipCard(this, ${index})">
                    <div class="reveal-card-face reveal-card-front">
                        <i class="fa-solid fa-sparkles"></i>
                        <h3 style="color:#fff; font-weight:900; margin:0; font-size:1.15rem; font-family:'Outfit';">KARTI AÇ</h3>
                        <p style="color:rgba(255,255,255,0.4); font-size:0.75rem; margin-top:5px;">Çevirmek için tıkla</p>
                    </div>
                    
                    <div class="reveal-card-face reveal-card-back" style="--rarity-color: ${rarityColor}; --rarity-bg: ${rarityBg};">
                        <div class="reveal-card-rarity-badge">${rarityLabel}</div>
                        <img src="${avatar}" class="reveal-card-img" onerror="this.src='assets/default-avatar.png'">
                        <div>
                            <div class="reveal-card-name">${dc.card.name}</div>
                            <div class="reveal-card-subname">${dc.card.koreanName || ''}</div>
                        </div>
                        <div style="display:flex; flex-direction:column; gap:5px; width:100%;">
                            ${dc.isDuplicate ? `
                                <div class="reveal-bonus-info" style="color: #ef4444; background: rgba(239, 68, 68, 0.05); border-color: rgba(239, 68, 68, 0.15);">
                                    <i class="fa-solid fa-clone"></i> +${dc.bonusCoins} Coin (Kopya)
                                </div>
                            ` : `
                                <div class="reveal-bonus-info" style="color: #10b981; background: rgba(16, 185, 129, 0.05); border-color: rgba(16, 185, 129, 0.15);">
                                    <i class="fa-solid fa-circle-check"></i> Koleksiyona eklendi
                                </div>
                            `}
                            <div class="reveal-bonus-info">
                                <i class="fa-solid fa-coins"></i> +${dc.baseBonus} Coin
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        modal.innerHTML = `
            <h1 style="color:#fff; font-family:'Outfit'; font-weight:900; margin-bottom:10px; text-shadow: 0 0 15px rgba(124,58,237,0.3); font-size: 2.2rem;">✨ KARTLARIN AÇILIYOR ✨</h1>
            <p style="color:rgba(255,255,255,0.6); font-size:1rem; margin-bottom:40px; font-family:'Outfit';" id="reveal-status-msg">Tüm kartları döndürmek için üstlerine tıklayın!</p>
            
            <div class="reveal-grid">
                ${cardsHTML}
            </div>
            
            <button class="admin-btn admin-btn-primary" style="display:none; padding:12px 35px; border-radius:12px; font-weight:800; font-size:1rem; margin-top: 20px; box-shadow: 0 10px 20px rgba(124,58,237,0.3);" id="reveal-close-btn" onclick="ShopSystem.closeRevealModal()">
                Tamam
            </button>
        `;

        document.body.appendChild(modal);
    },

    revealFlipCard(container, index) {
        if (container.classList.contains('flipped')) return;
        container.classList.add('flipped');

        if (typeof confetti === 'function') {
            confetti({
                particleCount: 40,
                spread: 50,
                origin: { y: 0.8 }
            });
        }

        const allCards = document.querySelectorAll('.reveal-card-container');
        const flippedCards = document.querySelectorAll('.reveal-card-container.flipped');
        
        if (allCards.length === flippedCards.length) {
            const btn = document.getElementById('reveal-close-btn');
            if (btn) btn.style.display = 'block';
            const status = document.getElementById('reveal-status-msg');
            if (status) status.innerText = 'Tüm kartlar başarıyla açıldı! 🎉';
        }
    },

    closeRevealModal() {
        const modal = document.getElementById('chest-reveal-modal');
        if (modal) {
            modal.remove();
        }
        const balanceVal = document.getElementById('shop-balance-val');
        if (balanceVal) balanceVal.innerText = State.currentUser.stats.coins;
        
        if (window.SocialFeed && SocialFeed.currentTab === 'profile') {
            SocialFeed.renderProfileTab();
        }
        
        this.renderItems(this.currentTab);
    },

    async buyCoffee(targetId, type = 'translator') {
        const coffeePrice = 50;
        const balance = State.currentUser.stats?.coins || 0;
        if (balance < coffeePrice) {
            Toast.error('Yetersiz DC Coin! Marketten coin almalısın.');
            return;
        }

        CustomConfirm.show(`${coffeePrice} DC Coin karşılığında kahve ısmarlamak istiyor musun?`, async () => {
            try {
                const res = await fetch('api/db.php?action=buy-coffee', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ targetId, type, price: coffeePrice })
                }).then(r => r.json());

                if (res.success) {
                    State.currentUser.stats.coins -= coffeePrice;
                    Toast.success('Kahve başarıyla ısmarlandı! ☕');
                    const balanceVal = document.getElementById('shop-balance-val');
                    if (balanceVal) balanceVal.innerText = State.currentUser.stats.coins;
                    this.save();
                } else {
                    Toast.error(res.message);
                }
            } catch (e) { Toast.error('İşlem başarısız.'); }
        });
    },

    async convertCoffeeToCoins() {
        const coffeeCount = State.currentUser.receivedCoffees || 0;
        if (coffeeCount === 0) return Toast.info('Henüz kahven yok.');

        const rate = 40;
        const totalCoins = coffeeCount * rate;

        CustomConfirm.show(`${coffeeCount} kahveni ${totalCoins} DC Coin'e çevirmek istiyor musun?`, async () => {
            try {
                const res = await fetch('api/db.php?action=convert-coffee', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ count: coffeeCount, rate })
                }).then(r => r.json());

                if (res.success) {
                    State.currentUser.receivedCoffees = 0;
                    if (!State.currentUser.stats) State.currentUser.stats = { coins: 0 };
                    State.currentUser.stats.coins += totalCoins;
                    Toast.success(`${totalCoins} DC Coin hesabına eklendi! 🪙`);
                    const balanceVal = document.getElementById('shop-balance-val');
                    if (balanceVal) balanceVal.innerText = State.currentUser.stats.coins;
                    this.save();
                }
            } catch (e) { Toast.error('Hata oluştu.'); }
        });
    }
};

window.ShopSystem = ShopSystem;
