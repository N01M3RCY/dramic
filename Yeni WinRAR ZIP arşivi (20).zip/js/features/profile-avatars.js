const ProfileAvatars = {
    defaults: [
        { id: 'drami_boy', url: 'assets/mascot/drami-boy.png', label: 'Drami (Robot)' },
        { id: 'drami_girl', url: 'assets/mascot/drami-girl.png', label: 'Drami (Tilki)' },
        { id: 'default_1', url: 'https://cdn-icons-png.flaticon.com/512/3233/3233483.png', label: 'Classic Purple' },
        { id: 'default_2', url: 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png', label: 'Classic Red' },
        { id: 'default_3', url: 'https://cdn-icons-png.flaticon.com/512/4140/4140048.png', label: 'Classic Blue' },
        { id: 'default_4', url: 'https://cdn-icons-png.flaticon.com/512/4140/4140047.png', label: 'Classic Green' },
        { id: 'default_5', url: 'https://cdn-icons-png.flaticon.com/512/1154/1154444.png', label: 'Kids Default', isKids: true }
    ],

    themed: {
        'Anime & Stylized': [
            { id: 'anime_1', url: 'https://i.ibb.co/6yX1pWk/diana.png', label: 'Diana' },
            { id: 'anime_2', url: 'https://i.ibb.co/yYv3Pv9/lucia.png', label: 'Lucia' },
            { id: 'anime_3', url: 'https://cdn-icons-png.flaticon.com/512/1154/1154457.png', label: 'Abstract 1' },
            { id: 'anime_4', url: 'https://cdn-icons-png.flaticon.com/512/1154/1154462.png', label: 'Abstract 2' }
        ]
    },

    getAll() {
        let all = [...this.defaults];
        Object.values(this.themed).forEach(category => {
            all = [...all, ...category];
        });
        return all;
    },

    /**
     * Get all character cards from the system
     */
    getCharacterCards() {
        if (!State.data || !State.data.series) return [];
        let cards = [];
        const processedActors = new Set();

        State.data.series.forEach(s => {
            if (s.characters) {
                s.characters.forEach(c => {
                    const actorName = c.actor || c.name;
                    if (actorName && !processedActors.has(actorName)) {
                        processedActors.add(actorName);
                        cards.push({
                            id: 'card-' + actorName.replace(/\s+/g, '-').toLowerCase(),
                            url: c.image || 'assets/logo.png',
                            label: actorName,
                            isCharacterCard: true,
                            actorName: actorName
                        });
                    }
                });
            }
        });
        return cards;
    },

    getById(id) {
        return [...this.getAll(), ...this.getCharacterCards()].find(a => a.id === id);
    }
};

window.ProfileAvatars = ProfileAvatars;
