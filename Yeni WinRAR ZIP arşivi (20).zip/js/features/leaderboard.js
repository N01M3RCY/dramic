if (typeof Leaderboard === 'undefined') {
    window.Leaderboard = {
        init() {
            console.log('🏆 Leaderboard initialized');
        },

        show() {
            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.style.display = 'flex';
            modal.innerHTML = `
            <div class="modal-content" style="max-width: 800px; max-height: 90vh; overflow-y: auto;">
                <div class="modal-header">
                    <h2>🏆 Liderlik Tablosu</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="tabs" style="display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid var(--border-color); padding-bottom: 10px;">
                        <button class="tab-btn active" onclick="Leaderboard.switchTab(this, 'coins')">💰 En Zenginler</button>
                        <button class="tab-btn" onclick="Leaderboard.switchTab(this, 'level')">⚡ En Yüksek Seviye</button>
                        <button class="tab-btn" onclick="Leaderboard.switchTab(this, 'active')">🔥 En Aktifler</button>
                    </div>

                    <div id="leaderboard-content">
                        ${this.renderList('coins')}
                    </div>
                </div>
            </div>
        `;
            document.body.appendChild(modal);
        },

        switchTab(btn, type) {
            // Update active tab UI
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Render content
            const container = document.getElementById('leaderboard-content');
            container.innerHTML = '<div style="text-align:center; padding:20px;"><i class="fa-solid fa-spinner fa-spin fa-2x"></i></div>';

            // Simulate networking delay for effect or just render
            setTimeout(() => {
                container.innerHTML = this.renderList(type);
            }, 300);
        },

        renderList(type) {
            const users = State.data.users || [];
            let sortedUsers = [];
            let valueLabel = '';
            let valueKey = '';
            let icon = '';

            switch (type) {
                case 'coins':
                    sortedUsers = [...users].sort((a, b) => (b.stats?.coins || 0) - (a.stats?.coins || 0));
                    valueLabel = 'DrCoBox Coin';
                    valueKey = 'coins';
                    icon = '💰';
                    break;
                case 'level':
                    sortedUsers = [...users].sort((a, b) => (b.stats?.level || 0) - (a.stats?.level || 0));
                    valueLabel = 'Seviye';
                    valueKey = 'level';
                    icon = '⚡';
                    break;
                case 'active':
                    sortedUsers = [...users].sort((a, b) => (b.watchHistory?.length || 0) - (a.watchHistory?.length || 0));
                    valueLabel = 'İzlenen Bölüm';
                    valueKey = 'watchCount';
                    icon = '📺';
                    break;
            }

            return `
            <div class="leaderboard-list">
                ${sortedUsers.slice(0, 50).map((user, index) => {
                const rank = index + 1;
                const isTop3 = rank <= 3;
                const rankClass = isTop3 ? `rank-${rank}` : '';
                let displayValue = 0;

                if (type === 'active') {
                    displayValue = user.watchHistory?.length || 0;
                } else {
                    displayValue = user.stats?.[valueKey] || 0;
                }

                return `
                        <div class="leaderboard-item ${rankClass}" style="
                            display: flex; 
                            align-items: center; 
                            padding: 15px; 
                            margin-bottom: 10px; 
                            background: ${isTop3 ? 'var(--bg-secondary)' : 'rgba(255,255,255,0.02)'}; 
                            border: 1px solid ${isTop3 ? 'var(--accent-color)' : 'var(--border-color)'}; 
                            border-radius: 12px;
                        ">
                            <div class="rank" style="
                                width: 40px; 
                                height: 40px; 
                                display: flex; 
                                align-items: center; 
                                justify-content: center; 
                                font-weight: bold; 
                                font-size: 1.2rem; 
                                margin-right: 15px;
                                color: ${rank === 1 ? '#ffd700' : rank === 2 ? '#c0c0c0' : rank === 3 ? '#cd7f32' : 'var(--text-secondary)'};
                            ">
                                ${rank <= 3 ? `<i class="fa-solid fa-trophy"></i>` : rank}
                            </div>
                            
                            <img src="${user.avatar || 'assets/logo.png'}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; margin-right: 15px;">
                            
                            <div style="flex: 1;">
                                <div style="font-weight: 600; color: var(--text-primary);">
                                    ${user.username} 
                                    ${user.badges?.includes('VIP') ? '<span class="badge badge-vip">VIP</span>' : ''}
                                </div>
                                <div style="font-size: 0.8rem; color: var(--text-secondary);">${user.badges?.length || 0} Rozet</div>
                            </div>
                            
                            <div style="text-align: right;">
                                <div style="font-weight: bold; color: var(--accent-color); font-size: 1.1rem;">
                                    ${displayValue}
                                </div>
                                <div style="font-size: 0.8rem; color: var(--text-secondary);">${valueLabel}</div>
                            </div>
                        </div>
                    `;
            }).join('')}
            </div>
        `;
        }
    };
}


