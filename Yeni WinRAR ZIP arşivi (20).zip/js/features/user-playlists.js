
const PlaylistManager = {
    init() {
        console.log('🎵 PlaylistManager starting...');
        // Ensure user playlists structure exists
        if (State.currentUser && !State.currentUser.playlists) {
            State.currentUser.playlists = [];
        }
    },

    // --- CRUD Operations ---

    createPlaylist(name, visibility = 'private') {
        if (!State.currentUser) return Toast.error('Giriş yapmalısınız!');
        if (!name) return Toast.warning('Liste adı gerekli!');

        if (!State.currentUser.playlists) State.currentUser.playlists = [];

        const newPlaylist = {
            id: 'list-' + Date.now(),
            name: name,
            visibility: visibility, // 'public' or 'private'
            items: [],
            createdAt: Date.now()
        };

        State.currentUser.playlists.push(newPlaylist);
        this.save();
        Toast.success('Liste oluşturuldu!');
        return newPlaylist;
    },

    deletePlaylist(playlistId) {
        if (!State.currentUser) return;

        const idx = State.currentUser.playlists.findIndex(p => p.id === playlistId);
        if (idx === -1) return;

        if (confirm('Bu listeyi silmek istediğinize emin misiniz?')) {
            State.currentUser.playlists.splice(idx, 1);
            this.save();
            Toast.info('Liste silindi.');
            if (window.location.hash.includes('profile')) App.router('profile');
        }
    },

    addItem(playlistId, seriesId, episodeIndex = -1) {
        if (!State.currentUser) return;

        const playlist = State.currentUser.playlists.find(p => p.id === playlistId);
        if (!playlist) return Toast.error('Liste bulunamadı.');

        // Check duplicate
        const exists = playlist.items.some(i => i.seriesId === seriesId && i.episodeIndex === episodeIndex);
        if (exists) return Toast.warning('Bu içerik zaten listede var.');

        playlist.items.push({
            seriesId: seriesId,
            episodeIndex: episodeIndex,
            addedAt: Date.now()
        });

        this.save();
        Toast.success('Listeye eklendi!');
    },

    removeItem(playlistId, seriesId, episodeIndex) {
        if (!State.currentUser) return;

        const playlist = State.currentUser.playlists.find(p => p.id === playlistId);
        if (!playlist) return;

        const idx = playlist.items.findIndex(i => i.seriesId === seriesId && i.episodeIndex === episodeIndex);
        if (idx > -1) {
            playlist.items.splice(idx, 1);
            this.save();
            Toast.info('Listeden çıkarıldı.');
            // Refresh view if needed
            if (document.getElementById('playlist-view-container')) {
                this.renderPlaylistView(playlistId);
            }
        }
    },

    toggleVisibility(playlistId) {
        const playlist = State.currentUser.playlists.find(p => p.id === playlistId);
        if (playlist) {
            playlist.visibility = playlist.visibility === 'public' ? 'private' : 'public';
            this.save();
            Toast.success(`Liste artık ${playlist.visibility === 'public' ? 'Herkese Açık' : 'Gizli'}`);
            if (document.getElementById('playlist-view-container')) {
                this.renderPlaylistView(playlistId);
            }
        }
    },

    save() {
        // Save current user data
        db.updateUser(State.currentUser.id, { playlists: State.currentUser.playlists });
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
    },

    // --- UI Methods ---

    // Open Modal to Add Series/Episode to Playlist
    openAddToPlaylistModal(seriesId, episodeIndex = -1) {
        if (!State.currentUser) return Toast.error('Giriş yapmalısınız!');

        const playlists = State.currentUser.playlists || [];

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 400px;">
                <div class="modal-header">
                    <h2><i class="fa-solid fa-list-ul"></i> Listeye Ekle</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div id="playlist-select-list" style="margin-bottom: 20px;">
                        ${playlists.length > 0 ? playlists.map(p => `
                            <button class="btn btn-outline btn-block" style="margin-bottom: 10px; justify-content: space-between;" 
                                onclick="PlaylistManager.addItem('${p.id}', '${seriesId}', ${episodeIndex}); this.closest('.modal').remove();">
                                <span>${p.name} <small>(${p.items.length})</small></span>
                                <i class="fa-solid fa-plus"></i>
                            </button>
                        `).join('') : '<p style="text-align:center; color:#888;">Henüz listeniz yok.</p>'}
                    </div>

                    <div style="border-top: 1px solid var(--border-color); padding-top: 15px;">
                        <h4>Yeni Liste Oluştur</h4>
                        <div style="display:flex; gap: 10px; margin-top: 10px;">
                            <input type="text" id="new-playlist-name" class="form-input" placeholder="Liste adı...">
                            <select id="new-playlist-vis" class="form-input" style="width: 100px;">
                                <option value="private">Gizli</option>
                                <option value="public">Açık</option>
                            </select>
                        </div>
                        <button class="btn btn-primary btn-block" style="margin-top: 10px;" onclick="PlaylistManager.handleCreateInModal('${seriesId}', ${episodeIndex})">
                            Oluştur ve Ekle
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    handleCreateInModal(seriesId, episodeIndex) {
        const nameInput = document.getElementById('new-playlist-name');
        const visInput = document.getElementById('new-playlist-vis');
        if (!nameInput.value) return Toast.warning('İsim gerekli');

        const playlist = this.createPlaylist(nameInput.value, visInput.value);
        this.addItem(playlist.id, seriesId, episodeIndex);
        // Force refresh modal is tricky here as we just removed it logic-wise... 
        // actually we modify the DOM.
        // Simplest: Close and notify.
        document.querySelector('.modal').remove();
    },

    // --- Views ---

    // Render Full Playlist View (My Playlist or Public Playlist)
    renderPlaylistView(playlistId) {
        let playlist = null;
        let owner = null;
        let isOwner = false;

        // 1. Check if it's mine
        if (State.currentUser && State.currentUser.playlists) {
            playlist = State.currentUser.playlists.find(p => p.id === playlistId);
            if (playlist) {
                owner = State.currentUser;
                isOwner = true;
            }
        }

        // 2. If not found, check all users (Public mode)
        if (!playlist && State.data.users) {
            for (const u of State.data.users) {
                if (u.playlists) {
                    const found = u.playlists.find(p => p.id === playlistId);
                    if (found) {
                        playlist = found;
                        owner = u;
                        isOwner = (State.currentUser && State.currentUser.id === u.id);
                        break;
                    }
                }
            }
        }

        const container = document.getElementById('playlist-content-container');
        if (!container) {
            console.error("Playlist container not found!");
            return;
        }

        container.innerHTML = `
            <div class="section-header">
                <div>
                    <h2><i class="fa-solid fa-list"></i> ${playlist ? playlist.name : 'Liste Bulunamadı'}</h2>
                    <p style="color:var(--text-secondary);">${owner ? 'Oluşturan: ' + owner.username : ''} • ${playlist ? playlist.items.length + ' içerik' : ''}</p>
                </div>
                ${(isOwner && playlist) ? `
                    <div style="display:flex; gap:10px;">
                        <button class="btn btn-outline" onclick="PlaylistManager.toggleVisibility('${playlist.id}')">
                            ${playlist.visibility === 'public' ? '<i class="fa-solid fa-earth-americas"></i> Herkese Açık' : '<i class="fa-solid fa-lock"></i> Gizli'}
                        </button>
                        <button class="btn btn-danger" onclick="PlaylistManager.deletePlaylist('${playlist.id}')">
                            <i class="fa-solid fa-trash"></i> Sil
                        </button>
                    </div>
                ` : ''}
            </div>
            ${!playlist ? '<p>Bu liste mevcut değil veya gizli.</p>' : this.buildPlaylistGrid(playlist)}
        `;

        // No need to set display:block here, App.router handles the view switching

        if (!playlist || (!isOwner && playlist.visibility === 'private')) {
            container.innerHTML = `<div style="padding:50px; text-align:center;"><h2>🔒 Bu liste gizli veya mevcut değil.</h2></div>`;
            return;
        }
    },

    buildPlaylistGrid(playlist) {
        if (!playlist.items || playlist.items.length === 0) {
            return '<p style="text-align:center; padding:50px; color:var(--text-secondary);">Liste boş.</p>';
        }

        let html = '<div class="grid-container">';
        playlist.items.forEach(item => {
            const series = db.getSeries(item.seriesId);
            if (!series) return;

            let label = series.title;
            let link = `javascript:App.router('detail', '${series.id}')`;
            let subLabel = series.year;

            // Handle Episode
            if (item.episodeIndex > -1) {
                // Determine episode
                let ep = null;
                // Simplified lookup logic (reused from App.js logic roughly)
                // For now just assume flat episode access for visual simplicity or complex lookup
                // We'll just say "X. Bölüm"
                // But we need safe access.
                if (series.episodes && series.episodes[item.episodeIndex]) {
                    ep = series.episodes[item.episodeIndex];
                    label += ` - Bölüm ${ep.number}`;
                    link = `javascript:App.router('player', '${series.id}', ${item.episodeIndex})`;
                    subLabel = 'Bölüm';
                } else if (series.seasons) {
                    // Complex season handling... skipped for brevity, link to main series
                }
            }

            html += `
                <div class="card" onclick="${link}" style="position:relative;">
                    <div class="card-poster">
                        <img src="${series.poster || series.coverImage}" loading="lazy">
                        <div class="card-overlay">
                            <i class="fa-solid fa-play"></i>
                        </div>
                    </div>
                    <div class="card-info">
                        <h3>${label}</h3>
                        <div class="card-meta">
                            <span>${subLabel}</span>
                            <span class="rating"><i class="fa-solid fa-star"></i> ${series.rating || 'N/A'}</span>
                        </div>
                    </div>
                    ${State.currentUser && State.currentUser.playlists.some(p => p.id === playlist.id) ? `
                        <button onclick="event.stopPropagation(); PlaylistManager.removeItem('${playlist.id}', '${item.seriesId}', ${item.episodeIndex})" 
                                style="position:absolute; top:5px; right:5px; background:rgba(0,0,0,0.7); border:none; color:white; width:24px; height:24px; border-radius:50%; cursor:pointer;">
                            <i class="fa-solid fa-times"></i>
                        </button>
                    ` : ''}
                </div>
            `;
        });
        html += '</div>';
        return html;
    }
};

window.PlaylistManager = PlaylistManager;
