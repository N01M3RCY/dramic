// ============================================
// RECOMMENDATIONS & TRENDING SYSTEM
// ============================================

const RecommendationsSystem = {
    init() {
        this.renderRecommendations();
        this.renderTrending();
    },

    // Get personalized recommendations based on user's watchlist
    getRecommendations() {
        // 1. Prioritize manually recommended series
        const manualRecs = State.data.series.filter(s => s.isRecommended);

        let recommendations = [...manualRecs];

        // If we have enough manual recommendations, return them (up to 6)
        if (recommendations.length >= 6) {
            return recommendations.slice(0, 6);
        }

        // 2. Fill with algorithmic recommendations if user is logged in
        if (State.currentUser && State.currentUser.watchlist && State.currentUser.watchlist.length > 0) {
            const watchlist = State.currentUser.watchlist;
            const watchedGenres = {};
            watchlist.forEach(seriesId => {
                const series = db.getSeries(seriesId);
                if (series && series.genre) {
                    watchedGenres[series.genre] = (watchedGenres[series.genre] || 0) + 1;
                }
            });

            const algoRecs = State.data.series
                .filter(s => !watchlist.includes(s.id) && !recommendations.some(r => r.id === s.id))
                .filter(s => s.genre && watchedGenres[s.genre])
                .sort((a, b) => {
                    const scoreA = watchedGenres[a.genre] || 0;
                    const scoreB = watchedGenres[b.genre] || 0;
                    return scoreB - scoreA;
                })
                .slice(0, 6 - recommendations.length);

            recommendations.push(...algoRecs);
        }

        // 3. Fill remaining with random if still under 6
        if (recommendations.length < 6) {
            const remaining = this.getRandomSeries(6 - recommendations.length)
                .filter(s => !recommendations.find(r => r.id === s.id));
            recommendations.push(...remaining);
        }

        return recommendations;
    },

    // Get trending series (most viewed/rated)
    getTrending() {
        // 1. Prioritize manually trending series
        const manualTrending = State.data.series.filter(s => s.isTrending);

        // 2. If not enough, fill with random/shuffled
        if (manualTrending.length >= 6) {
            return manualTrending.slice(0, 6);
        }

        const remainingCount = 6 - manualTrending.length;
        const others = State.data.series
            .filter(s => !manualTrending.find(m => m.id === s.id))
            .sort(() => Math.random() - 0.5)
            .slice(0, remainingCount);

        return [...manualTrending, ...others];
    },

    getRandomSeries(count) {
        const shuffled = [...State.data.series].sort(() => Math.random() - 0.5);
        return shuffled.slice(0, count);
    },

    renderRecommendations() {
        const container = document.getElementById('recommendations-grid');
        if (!container) return;

        const recommendations = this.getRecommendations();

        if (recommendations.length === 0) {
            container.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 40px;">Henüz öneri yok.</p>';
            return;
        }

        container.innerHTML = recommendations.map(series => {
            if (window.StandardCard) return `<div>${StandardCard.render(series)}</div>`;
            return `
                <div class="recommendation-card" onclick="App.router('detail', '${series.id}')">
                    <img src="${series.coverImage}" alt="${series.title}" class="recommendation-card-image">
                    <div class="recommendation-card-content">
                        <h3 class="recommendation-card-title">${series.title}</h3>
                    </div>
                </div>
            `;
        }).join('');
    },

    renderTrending() {
        const container = document.getElementById('trending-grid');
        if (!container) return;

        const trending = this.getTrending();

        if (trending.length === 0) {
            container.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 40px;">Henüz trend yok.</p>';
            return;
        }

        container.innerHTML = trending.map((series, index) => {
            if (window.StandardCard) return `<div style="position:relative;">${StandardCard.render(series)}<div class="trending-badge" style="position:absolute; top:10px; left:10px; background:var(--ultra-accent); color:white; padding:4px 10px; border-radius:10px; font-weight:800; z-index:5;">#${index+1}</div></div>`;
            return `
                <div class="trending-card" onclick="App.router('detail', '${series.id}')">
                    <img src="${series.coverImage}" alt="${series.title}" class="trending-card-image">
                    <div class="trending-card-content">
                        <h3 class="trending-card-title">${series.title}</h3>
                    </div>
                </div>
            `;
        }).join('');
    }
};

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        RecommendationsSystem.init();
    }, 2000);
});

console.log('✅ Recommendations & Trending System Loaded!');
