// Event and Poll System
const EventSystem = {
    polls: [],
    discussions: [],

    init() {
        console.log('🎫 Event System initialized');
        this.loadPolls();
        this.loadDiscussions();
    },

    loadPolls() {
        const saved = localStorage.getItem('dramicbox_polls');
        if (saved) {
            this.polls = JSON.parse(saved);
        }
    },

    savePolls() {
        localStorage.setItem('dramicbox_polls', JSON.stringify(this.polls));
    },

    loadDiscussions() {
        const saved = localStorage.getItem('dramicbox_discussions');
        if (saved) {
            this.discussions = JSON.parse(saved);
        }
    },

    saveDiscussions() {
        localStorage.setItem('dramicbox_discussions', JSON.stringify(this.discussions));
    },

    // POLLS/SURVEYS
    showPollsPage() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 900px; max-height: 90vh; overflow-y: auto;">
                <div class="modal-header">
                    <h2>📊 Anketler ve Turnuvalar</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    ${State.currentUser && State.currentUser.role === 'admin' ? `
                        <button class="btn btn-primary" onclick="EventSystem.createPoll()" style="margin-bottom: 20px;">
                            <i class="fa-solid fa-plus"></i> Yeni Anket Oluştur
                        </button>
                    ` : ''}

                    <div id="polls-container">
                        ${this.renderPolls()}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    renderPolls() {
        if (this.polls.length === 0) {
            return '<p style="text-align: center; color: var(--text-secondary); padding: 40px;">Henüz anket yok</p>';
        }

        return this.polls.map(poll => {
            const totalVotes = poll.options.reduce((sum, opt) => sum + opt.votes, 0);
            const hasVoted = poll.voters?.includes(State.currentUser?.id);

            return `
                <div class="poll-card" style="background: var(--bg-secondary); padding: 20px; border-radius: 12px; margin-bottom: 20px;">
                    <h3>${poll.title}</h3>
                    <p style="color: var(--text-secondary); margin: 10px 0;">${poll.description}</p>
                    
                    <div style="margin: 20px 0;">
                        ${poll.options.map((option, index) => {
                const percentage = totalVotes > 0 ? (option.votes / totalVotes * 100).toFixed(1) : 0;
                return `
                                <div class="poll-option" style="margin-bottom: 15px;">
                                    ${!hasVoted ? `
                                        <button class="btn btn-outline" onclick="EventSystem.vote('${poll.id}', ${index})" style="width: 100%; text-align: left;">
                                            ${option.text}
                                        </button>
                                    ` : `
                                        <div style="margin-bottom: 5px; display: flex; justify-content: space-between;">
                                            <span>${option.text}</span>
                                            <span style="color: var(--accent-color); font-weight: 600;">${percentage}%</span>
                                        </div>
                                        <div style="width: 100%; height: 12px; background: var(--bg-card); border-radius: 6px; overflow: hidden;">
                                            <div style="width: ${percentage}%; height: 100%; background: var(--accent-gradient); transition: width 0.3s ease;"></div>
                                        </div>
                                    `}
                                </div>
                            `;
            }).join('')}
                    </div>

                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border-color);">
                        <span style="color: var(--text-secondary); font-size: 0.9rem;">
                            <i class="fa-solid fa-users"></i> ${totalVotes} oy
                        </span>
                        <span style="color: var(--text-secondary); font-size: 0.9rem;">
                            ${new Date(poll.createdAt).toLocaleDateString('tr-TR')}
                        </span>
                    </div>
                </div>
            `;
        }).join('');
    },

    createPoll() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2>Yeni Anket Oluştur</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <form onsubmit="EventSystem.savePoll(event)">
                        <div class="form-group">
                            <label>Başlık *</label>
                            <input type="text" id="poll-title" class="form-input" required placeholder="En iyi karakter?">
                        </div>

                        <div class="form-group">
                            <label>Açıklama</label>
                            <textarea id="poll-description" class="form-input" rows="3" placeholder="Açıklama (opsiyonel)"></textarea>
                        </div>

                        <div class="form-group">
                            <label>Seçenekler *</label>
                            <div id="poll-options-container">
                                <input type="text" class="form-input poll-option-input" placeholder="Seçenek 1" style="margin-bottom: 10px;">
                                <input type="text" class="form-input poll-option-input" placeholder="Seçenek 2" style="margin-bottom: 10px;">
                            </div>
                            <button type="button" class="btn btn-outline" onclick="EventSystem.addPollOption()">
                                <i class="fa-solid fa-plus"></i> Seçenek Ekle
                            </button>
                        </div>

                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            <i class="fa-solid fa-check"></i> Anketi Oluştur
                        </button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    addPollOption() {
        const container = document.getElementById('poll-options-container');
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'form-input poll-option-input';
        input.placeholder = `Seçenek ${container.children.length + 1}`;
        input.style.marginBottom = '10px';
        container.appendChild(input);
    },

    savePoll(event) {
        event.preventDefault();

        const title = document.getElementById('poll-title').value;
        const description = document.getElementById('poll-description').value;
        const optionInputs = document.querySelectorAll('.poll-option-input');
        const options = Array.from(optionInputs)
            .map(input => input.value.trim())
            .filter(text => text.length > 0)
            .map(text => ({ text, votes: 0 }));

        if (options.length < 2) {
            Toast.warning('En az 2 seçenek gerekli!');
            return;
        }

        const poll = {
            id: 'poll-' + Date.now(),
            title,
            description,
            options,
            voters: [],
            createdAt: Date.now(),
            createdBy: State.currentUser?.username || 'Admin'
        };

        this.polls.push(poll);
        this.savePolls();

        Toast.success('Anket oluşturuldu!');
        document.querySelector('.modal').remove();
        this.showPollsPage();
    },

    vote(pollId, optionIndex) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Oy vermek için giriş yapmalısınız!');
            return;
        }

        const poll = this.polls.find(p => p.id === pollId);
        if (!poll) return;

        if (poll.voters.includes(State.currentUser.id)) {
            Toast.warning('Bu ankete zaten oy verdiniz!');
            return;
        }

        poll.options[optionIndex].votes++;
        poll.voters.push(State.currentUser.id);
        this.savePolls();

        Toast.success('Oyunuz kaydedildi!');
        this.showPollsPage();
    },

    // DISCUSSION ROOMS
    showDiscussions() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 1000px; max-height: 90vh; overflow-y: auto;">
                <div class="modal-header">
                    <h2>💬 Tartışma Odaları</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px;">
                        ${this.renderDiscussionRooms()}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    renderDiscussionRooms() {
        const series = State.data?.series || [];

        return series.slice(0, 12).map(s => `
            <div class="discussion-room-card" onclick="EventSystem.openDiscussionRoom('${s.id}')" style="
                background: var(--bg-secondary);
                padding: 20px;
                border-radius: 12px;
                cursor: pointer;
                transition: all 0.3s ease;
                text-align: center;
            " onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
                <img src="${s.poster}" style="width: 100%; height: 150px; object-fit: cover; border-radius: 8px; margin-bottom: 10px;">
                <h4 style="margin: 0;">${s.title}</h4>
                <p style="color: var(--text-secondary); font-size: 0.85rem; margin-top: 5px;">
                    <i class="fa-solid fa-comments"></i> Tartışmaya Katıl
                </p>
            </div>
        `).join('');
    },

    openDiscussionRoom(seriesId) {
        const series = State.data.series.find(s => s.id === seriesId);
        if (!series) return;

        Toast.info(`${series.title} tartışma odası yakında eklenecek!`);
        // TODO: Implement real-time chat with WebSocket
    }
};

console.log('✅ Event System Module Loaded!');
