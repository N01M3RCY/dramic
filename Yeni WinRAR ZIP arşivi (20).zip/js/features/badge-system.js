// Badge and Achievement System
const BadgeSystem = {
    badges: {
        // İzleme rozetleri

        'binge-watcher': { name: 'Maraton Ustası', description: '10 bölümü arka arkaya izledin', icon: '🍿', rarity: 'rare', category: 'watching' },
        'night-owl': { name: 'Gece Kuşu', description: 'Gece 2\'den sonra izledin', icon: '🦉', rarity: 'rare', category: 'watching' },
        'early-bird': { name: 'Erken Kuş', description: 'Sabah 6\'dan önce izledin', icon: '🐦', rarity: 'rare', category: 'watching' },
        'century-club': { name: 'Yüzler Kulübü', description: '100 bölüm izledin', icon: '💯', rarity: 'epic', category: 'watching' },
        'thousand-club': { name: 'Binler Kulübü', description: '1000 bölüm izledin', icon: '🏆', rarity: 'legendary', category: 'watching' },
        'dizi-kurdu': { name: 'Dizi Kurdu', description: '10 farklı dizi izledin', icon: '🦊', rarity: 'rare', category: 'watching' },
        'usta-diplomat': { name: 'Usta Diplomat', description: 'Parlamento oturumlarına katıldın', icon: '📜', rarity: 'epic', category: 'social' },

        // Sosyal rozetler
        'social-butterfly': { name: 'Sosyal Kelebek', description: '10 arkadaş ekledin', icon: '🦋', rarity: 'uncommon', category: 'social' },
        'commentator': { name: 'Yorumcu', description: '50 yorum yaptın', icon: '💬', rarity: 'rare', category: 'social' },
        'critic': { name: 'Eleştirmen', description: '100 puan verdin', icon: '⭐', rarity: 'epic', category: 'social' },

        // Koleksiyon rozetleri
        'genre-master-action': { name: 'Aksiyon Ustası', description: '20 aksiyon dizisi izledin', icon: '💥', rarity: 'rare', category: 'collection' },
        'genre-master-romance': { name: 'Romantik Ruh', description: '20 romantik dizi izledin', icon: '💕', rarity: 'rare', category: 'collection' },
        'completionist': { name: 'Tamamlayıcı', description: '5 diziyi bitirdin', icon: '✅', rarity: 'epic', category: 'collection' },

        // Özel rozetler
        'early-adopter': { name: 'Öncü', description: 'İlk 100 kullanıcıdan birisin', icon: '🌟', rarity: 'legendary', category: 'special' },
        'beta-tester': { name: 'Beta Tester', description: 'Beta döneminde katıldın', icon: '🧪', rarity: 'legendary', category: 'special' }
    },

    rarityColors: {
        common: '#9ca3af',
        uncommon: '#10b981',
        rare: '#3b82f6',
        epic: '#a855f7',
        legendary: '#f59e0b'
    },

    init() {
        console.log('🏆 Badge System initialized');
        this.checkBadges();
    },

    async checkBadges() {
        if (!State.currentUser || State.currentUser.role === 'guest') return;

        const earnedBadges = State.currentUser.badges || [];
        const newBadges = [];

        // İzleme rozetlerini kontrol et
        const watchHistory = State.currentUser.watchHistory || [];

        if (watchHistory.length >= 1) {
            if (typeof Gamification !== 'undefined' && !State.currentUser.achievements?.some(a => a.id === 'watch_1')) {
                Gamification.checkAchievements();
            }
        }
        if (watchHistory.length >= 100 && !earnedBadges.includes('century-club')) {
            newBadges.push('century-club');
        }
        if (watchHistory.length >= 1000 && !earnedBadges.includes('thousand-club')) {
            newBadges.push('thousand-club');
        }

        // Gece kuşu kontrolü
        const nightWatches = watchHistory.filter(h => {
            const hour = new Date(h.watchedAt).getHours();
            return hour >= 2 && hour < 6;
        });
        if (nightWatches.length >= 5 && !earnedBadges.includes('night-owl')) {
            newBadges.push('night-owl');
        }

        // Dizi Kurdu kontrolü
        const uniqueSeries = new Set(watchHistory.map(h => h.seriesId)).size;
        if (uniqueSeries >= 10 && !earnedBadges.includes('dizi-kurdu')) {
            newBadges.push('dizi-kurdu');
        }

        // Usta Diplomat kontrolü (Simülasyon aktivite kaydı varsa)
        const parliamentActivity = State.currentUser.stats?.parliamentParticipation || 0;
        if (parliamentActivity >= 5 && !earnedBadges.includes('usta-diplomat')) {
            newBadges.push('usta-diplomat');
        }

        // Yeni rozet kazanıldıysa
        if (newBadges.length > 0) {
            await this.awardBadges(newBadges);
        }
    },

    async awardBadges(badgeIds) {
        const currentBadges = State.currentUser.badges || [];
        const updatedBadges = [...currentBadges, ...badgeIds];

        try {
            // Update local state
            State.currentUser.badges = updatedBadges;

            // Update in users array
            if (State.data && State.data.users) {
                const index = State.data.users.findIndex(u => u.id === State.currentUser.id);
                if (index !== -1) {
                    State.data.users[index] = State.currentUser;
                }
            }

            // Save to database
            if (window.db && window.db.save) {
                window.db.save();
            }

            // Update session storage
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));

            // Bildirim göster
            badgeIds.forEach(id => {
                const badge = this.badges[id];
                if (badge) {
                    this.showBadgeNotification(badge);
                }
            });

        } catch (error) {
            console.error('Award badges error:', error);
        }
    },

    showBadgeNotification(badge) {
        const notification = document.createElement('div');
        notification.className = 'badge-notification';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, ${this.rarityColors[badge.rarity]}, ${this.adjustBrightness(this.rarityColors[badge.rarity], -20)});
            color: white;
            padding: 20px 30px;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            z-index: 10000;
            animation: slideInRight 0.5s ease, pulse 0.5s ease 0.5s;
            max-width: 350px;
        `;
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 15px;">
                <div style="font-size: 3rem;">${badge.icon}</div>
                <div>
                    <div style="font-weight: 700; font-size: 1.2rem; margin-bottom: 5px;">Yeni Rozet!</div>
                    <div style="font-weight: 600; margin-bottom: 3px;">${badge.name}</div>
                    <div style="font-size: 0.9rem; opacity: 0.9;">${badge.description}</div>
                </div>
            </div>
        `;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.5s ease';
            setTimeout(() => notification.remove(), 500);
        }, 4000);
    },

    showBadgeShowcase() {
        const userBadges = State.currentUser?.badges || [];

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 900px; max-height: 90vh; overflow-y: auto;">
                <div class="modal-header">
                    <h2>🏆 Rozet Koleksiyonum</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <!-- Stats -->
                    <div class="stats-grid" style="margin-bottom: 30px;">
                        <div class="stat-card">
                            <div class="stat-card-value">${userBadges.length}</div>
                            <div class="stat-card-label">Kazanılan Rozet</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-value">${Object.keys(this.badges).length}</div>
                            <div class="stat-card-label">Toplam Rozet</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-card-value">${Math.floor((userBadges.length / Object.keys(this.badges).length) * 100)}%</div>
                            <div class="stat-card-label">Tamamlanma</div>
                        </div>
                    </div>

                    <!-- Badge Categories -->
                    ${this.renderBadgeCategories(userBadges)}
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    renderBadgeCategories(userBadges) {
        const categories = {
            watching: 'İzleme Rozetleri',
            social: 'Sosyal Rozetler',
            collection: 'Koleksiyon Rozetleri',
            special: 'Özel Rozetler'
        };

        return Object.entries(categories).map(([cat, title]) => {
            const catBadges = Object.entries(this.badges).filter(([_, b]) => b.category === cat);

            return `
                <div style="margin-bottom: 30px;">
                    <h3 style="margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid var(--border-color);">
                        ${title}
                    </h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;">
                        ${catBadges.map(([id, badge]) => this.renderBadgeCard(id, badge, userBadges.includes(id))).join('')}
                    </div>
                </div>
            `;
        }).join('');
    },

    renderBadgeCard(id, badge, earned) {
        const rarityColor = this.rarityColors[badge.rarity];

        return `
            <div class="badge-card" style="
                background: var(--bg-secondary);
                padding: 20px;
                border-radius: 12px;
                text-align: center;
                border: 2px solid ${earned ? rarityColor : 'var(--border-color)'};
                opacity: ${earned ? '1' : '0.5'};
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
            ">
                ${earned ? `<div style="position: absolute; top: 10px; right: 10px; background: ${rarityColor}; color: white; padding: 2px 8px; border-radius: 12px; font-size: 0.7rem; font-weight: 600; text-transform: uppercase;">${badge.rarity}</div>` : ''}
                <div style="font-size: 4rem; margin-bottom: 10px; filter: ${earned ? 'none' : 'grayscale(100%)'}">${badge.icon}</div>
                <div style="font-weight: 700; margin-bottom: 5px; color: ${earned ? rarityColor : 'var(--text-secondary)'};">${badge.name}</div>
                <div style="font-size: 0.85rem; color: var(--text-secondary);">${badge.description}</div>
            </div>
        `;
    },

    adjustBrightness(hex, percent) {
        const num = parseInt(hex.replace('#', ''), 16);
        const amt = Math.round(2.55 * percent);
        const R = (num >> 16) + amt;
        const G = (num >> 8 & 0x00FF) + amt;
        const B = (num & 0x0000FF) + amt;
        return '#' + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
            (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
            (B < 255 ? B < 1 ? 0 : B : 255))
            .toString(16).slice(1);
    }
};

// Auto-check badges periodically
setInterval(() => {
    if (State.currentUser && State.currentUser.role !== 'guest') {
        BadgeSystem.checkBadges();
    }
}, 60000); // Check every minute

console.log('✅ Badge System Module Loaded!');
