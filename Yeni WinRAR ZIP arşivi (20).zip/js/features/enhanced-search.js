// Standard Search System (Reverted)
const Search = {
    init() {
        console.log('🔍 Standard Search initialized');
        // Setup event listeners
        const input = document.getElementById('search-input');
        if (input) {
            // Live Search on input
            input.addEventListener('input', (e) => this.performSearch());

            // Enter key to force search (optional)
            input.addEventListener('keyup', (e) => {
                if (e.key === 'Enter') this.performSearch();
            });
        }
    },

    openModal() {
        // Use the existing static modal in index.html
        const modal = document.getElementById('search-modal');
        if (modal) {
            modal.style.display = 'flex';
            const input = document.getElementById('search-input');
            if (input) {
                input.value = '';
                input.focus();
            }
            document.getElementById('search-results').innerHTML = ''; // Clear previous results
        }
    },

    closeModal() {
        const modal = document.getElementById('search-modal');
        if (modal) modal.style.display = 'none';
    },

    performSearch() {
        const query = document.getElementById('search-input').value.toLowerCase().trim();
        const resultsContainer = document.getElementById('search-results');

        if (!query) {
            resultsContainer.innerHTML = '';
            return;
        }

        // Safety check for data
        if (!State.data) {
            resultsContainer.innerHTML = '<p style="color:red; padding:20px; text-align:center;">Veri yüklenemedi. Lütfen sayfayı yenileyin.</p>';
            return;
        }

        const seriesData = State.data.series || [];
        const usersData = State.data.users || [];
        const totalItems = seriesData.length + usersData.length;

        resultsContainer.innerHTML = `<div style="text-align:center; padding:10px; color:var(--text-secondary); font-size:0.8rem;"><i class="fa-solid fa-spinner fa-spin"></i> ${totalItems} içerik aranıyor...</div>`;

        // 1. Filter Users
        const userResults = usersData.filter(u => {
            if (!u || !u.username) return false;
            return u.username.toLowerCase().includes(query);
        }).slice(0, 5); // Limit to top 5 users

        // 2. Filter Series
        const seriesResults = seriesData.filter(s => {
            if (!s) return false;
            const title = (s.title || '').toLowerCase();
            const desc = (s.description || '').toLowerCase();
            return title.includes(query) || desc.includes(query);
        });

        if (userResults.length === 0 && seriesResults.length === 0) {
            resultsContainer.innerHTML = `
                <div style="text-align: center; padding: 20px; color: var(--text-secondary);">
                    <p>Sonuç bulunamadı.</p>
                </div>
            `;
            return;
        }

        // Build HTML
        let html = '';

        // Render Users
        if (userResults.length > 0) {
            html += `
                <div style="padding: 10px 15px; color: #8b5cf6; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px;">Kullanıcılar</div>
                <div style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 20px; padding: 0 10px;">
                    ${userResults.map(u => `
                        <div onclick="App.router('profile', '${u.id}'); Search.closeModal();" 
                             style="display: flex; align-items: center; gap: 12px; padding: 10px; background: rgba(255,255,255,0.03); border-radius: 10px; cursor: pointer; transition: background 0.2s;"
                             onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.03)'">
                            ${window.UIExtensions ? UIExtensions.getAvatarHTML(u, 40) : `<img src="${u.avatar || 'assets/logo.png'}" style="width:40px; height:40px; border-radius:50%; object-fit:cover;">`}
                            <div>
                                <div style="font-weight: 600; color: white;">${u.username} ${u.isVip ? '<i class="fa-solid fa-circle-check" style="color:#f59e0b; margin-left:4px;"></i>' : ''}</div>
                                <div style="font-size: 0.75rem; color: #94a3b8;">Level ${u.level || 1} • ${u.role === 'admin' ? 'Yönetici' : 'Üye'}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        // Render Series
        if (seriesResults.length > 0) {
            html += `
                <div style="padding: 10px 15px; color: #white; font-weight: 700; font-size: 0.9rem; border-top: 1px solid rgba(255,255,255,0.1); margin-top: 10px;">İçerikler (${seriesResults.length})</div>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 15px; padding: 10px 10px 20px 10px;">
                    ${seriesResults.map(s => `
                        <div class="search-item" onclick="App.router('detail', '${s.id}'); Search.closeModal();" style="cursor:pointer; transition:transform 0.2s;">
                            <div style="position:relative; aspect-ratio:2/3; margin-bottom:8px; border-radius:8px; overflow:hidden;">
                                <img src="${s.poster || s.coverImage || 'img/no-poster.jpg'}" 
                                     onerror="this.src='https://via.placeholder.com/200x300?text=No+Image'"
                                     style="width:100%; height:100%; object-fit:cover;">
                                ${s.imdb ? `<div style="position:absolute; top:5px; right:5px; background:rgba(245, 197, 24, 0.9); color:black; font-weight:bold; font-size:0.7rem; padding:2px 4px; border-radius:4px;">${s.imdb}</div>` : ''}
                            </div>
                            <div style="font-weight:600; font-size:0.9rem; line-height:1.3; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color: white;">${s.title}</div>
                            <div style="font-size:0.75rem; color:var(--text-secondary); margin-top:2px;">${s.year || ''} • ${s.type === 'webtoon' ? 'Webtoon' : 'Dizi'}</div>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        resultsContainer.innerHTML = html;
    },

    // Alias for compatibility
    showAdvancedSearch() {
        this.openModal();
    }
};

// Expose
window.Search = Search;
window.EnhancedSearch = Search; // Alias to keep navbar button working without HTML change
