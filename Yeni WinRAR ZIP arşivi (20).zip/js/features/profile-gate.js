// Profile Gate System - Disabled
const ProfileGate = {
    selectedProfile: null,
    init() {
        console.log('👤 Profile Gate is in single-profile mode');
    },
    show() {
        // Disabled
    },
    open() {
        // Disabled
    },
    selectProfile(profileId) {
        // Disabled
    }
};

window.ProfileGate = ProfileGate;
ProfileGate.init();
