/**
 * DRAMICBOX - DRAMA SHORTS (TikTok Style)
 * Full-screen vertical video feed with navigation and interactions.
 */

const DramaShorts = {
    isEnabled: true, // Default true, controlled by Admin
    container: null,

    init() {
        console.log('📱 Drama Shorts Initialized');
        // Load setting from storage if exists
        const saved = localStorage.getItem('dramicbox_shorts_enabled');
        if (saved !== null) this.isEnabled = saved === 'true';
    },

    load() {
        if (!this.isEnabled) {
            Toast.warning('Shorts özelliği devre dışı bırakılmıştır.');
            App.router('home');
            return;
        }

        // 1. Consolidate Shorts Data
        // Prioritize State.data.shorts, but also check State.data.series for type='short'
        let shortsData = [];
        if (typeof State !== 'undefined' && State.data) {
            if (State.data.shorts && Array.isArray(State.data.shorts)) {
                shortsData = [...State.data.shorts];
            }
            if (State.data.series && Array.isArray(State.data.series)) {
                const shortsFromSeries = State.data.series.filter(s => s.type === 'short' || s.type === 'shorts');
                shortsData = [...shortsData, ...shortsFromSeries];
            }
        }

        // Deduplicate by ID
        shortsData = Array.from(new Map(shortsData.map(item => [item.id, item])).values());

        // 2. Fallback / Empty State Handling
        if (shortsData.length === 0) {
            // Fallback: Show a friendly "No Content" screen instead of a toast
            this.renderEmptyState();
            return;
        }

        const main = document.getElementById('app-container');
        if (!main) return;

        // Hide all view sections
        document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');

        // Check if our container exists, if not create it
        let container = document.getElementById('drama-shorts-feed-view');
        if (!container) {
            container = document.createElement('div');
            container.id = 'drama-shorts-feed-view';
            container.className = 'view-section';
            main.appendChild(container);
        }

        container.style.display = 'block';
        window.scrollTo(0, 0);

        // 3. Render Feed
        let hasValidVideo = false;
        const feedHtml = shortsData.map((s, i) => {
            // Robust Video Check
            let videoSrc = '';

            // Case A: Direct videoUrl
            if (s.videoUrl) videoSrc = s.videoUrl;
            // Case B: In episodes array
            else if (s.episodes && s.episodes.length > 0) {
                // Try to find one with videoUrl
                const ep = s.episodes.find(e => e.videoUrl) || s.episodes[0];
                videoSrc = ep ? ep.videoUrl : '';
            }
            // Case C: direct source property
            else if (s.source) videoSrc = s.source;

            if (!videoSrc) return '';

            hasValidVideo = true;

            const poster = s.poster || s.coverImage || '';
            const desc = s.description || s.plot || '';

            return `
                <div class="short-video-container" id="short-${i}">
                    <video class="short-video" src="${videoSrc}" loop preload="metadata" playsinline poster="${poster}" onclick="DramaShorts.togglePlay(this)"></video>
                    
                    <div class="short-overlay">
                        <!-- Right Side Actions -->
                        <div class="short-actions">
                            <div class="short-avatar">
                                <img src="${poster || 'assets/logo.png'}" style="width: 45px; height: 45px; border-radius: 50%; border: 2px solid #fff;">
                                <div class="action-btn-plus"><i class="fa-solid fa-plus"></i></div>
                            </div>

                            <div class="short-action" onclick="DramaShorts.like('${s.id}')">
                                <i class="fa-solid fa-heart"></i>
                                <span>${this.formatNumber(s.likes || s.views || 0)}</span>
                            </div>
                            
                            <div class="short-action" onclick="DramaShorts.openComments('${s.id}')">
                                <i class="fa-solid fa-comment-dots"></i>
                                <span>${s.comments ? s.comments.length : 0}</span>
                            </div>

                            <div class="short-action" onclick="DramaShorts.share('${s.id}')">
                                <i class="fa-solid fa-share"></i>
                                <span>Paylaş</span>
                            </div>

                             <div class="short-action" onclick="App.router('detail', '${s.id}')">
                                <i class="fa-solid fa-circle-info"></i>
                                <span>Detay</span>
                            </div>
                        </div>

                        <!-- Bottom Info -->
                        <div class="short-info">
                            <h3 class="short-series-title">${s.title}</h3>
                            <p class="short-desc">${desc.substring(0, 100)}${desc.length > 100 ? '...' : ''}</p>
                            
                            ${s.episodes && s.episodes.length > 1 ? `
                                <div class="short-playlist-tag">
                                    <i class="fa-solid fa-layer-group"></i> Playlist • ${s.episodes.length} Bölüm
                                </div>
                            ` : ''}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        if (!hasValidVideo) {
            this.renderEmptyState(container);
            return;
        }

        container.innerHTML = `
            <div class="shorts-page-vertical">
                <div class="shorts-back-btn" onclick="App.router('home')">
                    <i class="fa-solid fa-chevron-left"></i>
                </div>

                <div class="shorts-feed" id="shorts-feed">
                    ${feedHtml}
                </div>
                
                <div class="shorts-scroll-indicator" id="scroll-indicator">
                    <i class="fa-solid fa-chevron-up"></i>
                    <span>Kaydır</span>
                </div>
            </div>
            <style>
                .shorts-back-btn {
                    position: absolute; top: 20px; left: 20px; z-index: 1000;
                    width: 40px; height: 40px; background: rgba(0,0,0,0.5);
                    border-radius: 50%; display: flex; align-items: center; justify-content: center;
                    color: white; cursor: pointer; backdrop-filter: blur(5px);
                }
                .short-playlist-tag {
                    display: inline-block; padding: 4px 10px; background: rgba(255,255,255,0.2);
                    border-radius: 4px; font-size: 0.8rem; margin-top: 8px; backdrop-filter: blur(5px);
                }
                .action-btn-plus {
                    position: absolute; bottom: -5px; left: 50%; transform: translateX(-50%);
                    width: 18px; height: 18px; background: #ef4444; border-radius: 50%;
                    display: flex; align-items: center; justify-content: center; font-size: 0.6rem; color: white;
                }
                .short-avatar {
                    position: relative; margin-bottom: 10px; cursor: pointer;
                }
            </style>
        `;

        this.setupObservers();

        // Auto-play first video safely
        const vids = document.querySelectorAll('.short-video');
        if (vids.length > 0) {
            vids[0].play().catch(() => {
                // Mute and try again if blocked
                vids[0].muted = true;
                vids[0].play();
                Toast.info('Ses açmak için videoya tıklayın');
            });
        }
    },

    togglePlay(video) {
        if (video.paused) {
            video.play();
            video.muted = false;
        } else {
            video.pause();
        }
    },

    openComments(id) {
        Toast.info('Yorumlar yakında!');
    },

    formatNumber(num) {
        return num >= 1000 ? (num / 1000).toFixed(1) + 'k' : num;
    },

    renderEmptyState(container) {
        const main = container || document.getElementById('drama-shorts-feed-view');
        if (!main) return;

        main.innerHTML = `
            <div style="height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #000; color: white; text-align: center;">
                <i class="fa-solid fa-film" style="font-size: 4rem; margin-bottom: 20px; opacity: 0.5;"></i>
                <h2>Henüz İçerik Yok</h2>
                <p style="color: #888; margin-bottom: 30px;">Şu anda gösterilecek kısa drama bulunmuyor.</p>
                <button onclick="App.router('home')" style="padding: 12px 30px; background: #8b5cf6; border: none; border-radius: 30px; color: white; font-weight: bold; cursor: pointer;">
                    Ana Sayfaya Dön
                </button>
            </div>
        `;
        main.style.display = 'block';
    },

    setupObservers() {
        const options = { threshold: 0.6 };
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                const video = entry.target.querySelector('video');
                if (!video) return;

                if (entry.isIntersecting) {
                    video.play().catch(e => console.log('Playback error:', e));
                    // Fade out scroll indicator
                    const ind = document.getElementById('scroll-indicator');
                    if (ind) ind.style.opacity = '0';
                } else {
                    video.pause();
                    video.currentTime = 0; // Reset for better loop feel
                }
            });
        }, options);

        document.querySelectorAll('.short-video-container').forEach(sw => observer.observe(sw));
    },

    like(id) {
        Toast.success('Dizi kaydedildi!');
        // Update view count/like locally if needed
        if (window.logActivity) window.logActivity('Short Beğeni', { shortId: id });
    },

    share(id) {
        const url = window.location.origin + window.location.pathname + '#/detail/' + id;
        navigator.clipboard.writeText(url);
        Toast.info('Dizi linki kopyalandı!');
    },

    toggleFromAdmin(enabled) {
        this.isEnabled = enabled;
        localStorage.setItem('dramicbox_shorts_enabled', enabled);
        Toast.info(`Shorts Özelliği: ${enabled ? 'Açık' : 'Kapalı'}`);
    }
};

window.DramaShorts = DramaShorts;
