
// --- THEME SYSTEM ---
const ThemeSystem = {
    init() {
        console.log('🎨 Theme System initialized');
    },

    applyTheme(theme) {
        // Custom logic for Premium Themes
        const themeConfigs = {
            amoled: { primary: '#000000', secondary: '#111111', card: '#1a1a1a', accent: '#7c3aed' },
            safir: { primary: '#0f172a', secondary: '#1e293b', card: '#1e293b', accent: '#38bdf8' },
            purple_midnight: { primary: '#0f0f13', secondary: '#1e1e26', card: '#252530', accent: '#a78bfa' },
            gold_premium: { primary: '#0a0a0a', secondary: '#111111', card: '#1a1a1a', accent: '#fbbf24' },
            emerald: { primary: '#064e3b', secondary: '#065f46', card: '#065f46', accent: '#34d399' }
        };

        if (themeConfigs[theme]) {
            const conf = themeConfigs[theme];
            document.documentElement.style.setProperty('--bg-primary', conf.primary);
            document.documentElement.style.setProperty('--bg-secondary', conf.secondary);
            document.documentElement.style.setProperty('--bg-card', conf.card);
            document.documentElement.style.setProperty('--primary-color', conf.accent);
            document.documentElement.style.setProperty('--accent-color', conf.accent);
        } else if (theme === 'light') {
            document.documentElement.style.setProperty('--bg-primary', '#f3f4f6');
            document.documentElement.style.setProperty('--bg-secondary', '#ffffff');
            document.documentElement.style.setProperty('--bg-card', '#ffffff');
            document.documentElement.style.setProperty('--text-primary', '#111827');
            document.documentElement.style.setProperty('--text-secondary', '#4b5563');
        } else {
            // Dark (Default)
            document.documentElement.removeAttribute('style');
        }
    },

    setAccentColor(colorName) {
        const colors = {
            purple: '#7c3aed',
            blue: '#3b82f6',
            green: '#10b981',
            red: '#ef4444',
            pink: '#ec4899',
            orange: '#f59e0b'
        };
        const color = colors[colorName] || colorName;
        document.documentElement.style.setProperty('--primary-color', color);
        document.documentElement.style.setProperty('--accent-color', color);
        localStorage.setItem('dramicbox_accent', colorName);
    },

    setCustomAccentColor(hex) {
        document.documentElement.style.setProperty('--primary-color', hex);
        document.documentElement.style.setProperty('--accent-color', hex);
        localStorage.setItem('dramicbox_accent', hex);
    }
};

// --- USER CUSTOMIZATION ---
const UserCustomization = {
    settings: {
        profileBanner: null,
        showContinueWatching: true,
        viewMode: 'grid', // grid or list
        fontSize: 'medium', // small, medium, large, xlarge
        animationSpeed: 'normal', // fast, normal, slow, off
        compactMode: false
    },

    init() {
        console.log('🎨 User Customization initialized');
        this.loadSettings();
        this.applySettings();
    },

    loadSettings() {
        if (State.currentUser && State.currentUser.customization) {
            this.settings = { ...this.settings, ...State.currentUser.customization };
        } else {
            // Fallback to localStorage if not logged in or missing DB record
            const saved = localStorage.getItem('dramicbox_customization');
            if (saved) {
                this.settings = { ...this.settings, ...JSON.parse(saved) };
            }
        }
    },

    saveSettings() {
        if (State.currentUser) {
            State.currentUser.customization = this.settings;
            if (window.db && window.db.saveUser) {
                db.saveUser(State.currentUser);
            } else if (window.db && window.db.save) {
                db.save();
            }
        }
        localStorage.setItem('dramicbox_customization', JSON.stringify(this.settings));
    },

    open() {
        this.showCustomizationPanel();
    },

    showCustomizationPanel() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 800px; max-height: 90vh; overflow-y: auto;">
                <div class="modal-header">
                    <h2>🎨 Özelleştirme</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <!-- Profile Banner -->
                    <div class="form-group">
                        <label>Profil Banner</label>
                        <input type="url" id="profile-banner-url" class="form-input" 
                               placeholder="Banner URL (https://...)" 
                               value="${this.settings.profileBanner || ''}">
                        <button class="btn btn-outline" onclick="UserCustomization.uploadBanner()" style="margin-top: 10px;">
                            <i class="fa-solid fa-upload"></i> Banner Yükle
                        </button>
                    </div>

                    <!-- Market Inventory Section (New) -->
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 10px; margin-bottom: 20px; border: 1px solid var(--border-color);">
                        <h3 style="margin-top:0; margin-bottom:15px; font-size: 1.1rem;"><i class="fa-solid fa-briefcase"></i> Market Envanterim</h3>
                        ${this.renderInventorySection()}
                    </div>

                    <!-- Premium Theme Section -->
                    <div class="form-group">
                        <label>Premium Temalar</label>
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-top: 10px;">
                            <button class="btn btn-outline" onclick="ThemeSystem.applyTheme('safir'); Toast.success('Karanlık Safir uygulandı');" 
                                    style="padding: 15px; background: #0f172a; color: #38bdf8; border: 2px solid #38bdf8;">
                                <i class="fa-solid fa-gem"></i> Safir
                            </button>
                            <button class="btn btn-outline" onclick="ThemeSystem.applyTheme('purple_midnight'); Toast.success('Gece Yarısı Moru uygulandı');" 
                                    style="padding: 15px; background: #0f0f13; color: #a78bfa; border: 2px solid #a78bfa;">
                                <i class="fa-solid fa-moon"></i> Mor Gece
                            </button>
                            <button class="btn btn-outline" onclick="ThemeSystem.applyTheme('gold_premium'); Toast.success('Altın Vurgu uygulandı');" 
                                    style="padding: 15px; background: #0a0a0a; color: #fbbf24; border: 2px solid #fbbf24;">
                                <i class="fa-solid fa-crown"></i> Altın
                            </button>
                            <button class="btn btn-outline" onclick="ThemeSystem.applyTheme('emerald'); Toast.success('Zümrüt Yeşil uygulandı');" 
                                    style="padding: 15px; background: #064e3b; color: #34d399; border: 2px solid #34d399;">
                                <i class="fa-solid fa-leaf"></i> Zümrüt
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Temel Tema</label>
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 10px;">
                            <button class="btn btn-outline" onclick="ThemeSystem.applyTheme('dark');" style="background: #1a1a2e; color: white;">Dark</button>
                            <button class="btn btn-outline" onclick="ThemeSystem.applyTheme('light');" style="background: #ffffff; color: #1a1a2e;">Light</button>
                            <button class="btn btn-outline" onclick="ThemeSystem.applyTheme('amoled');" style="background: #000000; color: white;">AMOLED</button>
                        </div>
                    </div>

                    <!-- Accent Color -->
                    <div class="form-group">
                        <label>Vurgu Rengi</label>
                        <div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; margin-top: 10px;">
                            <button onclick="ThemeSystem.setAccentColor('purple'); Toast.success('Mor renk uygulandı');" style="padding: 20px; border-radius: 8px; border: 2px solid transparent; background: #7c3aed; cursor: pointer;" title="Mor"></button>
                            <button onclick="ThemeSystem.setAccentColor('blue'); Toast.success('Mavi renk uygulandı');" style="padding: 20px; border-radius: 8px; border: 2px solid transparent; background: #3b82f6; cursor: pointer;" title="Mavi"></button>
                            <button onclick="ThemeSystem.setAccentColor('green'); Toast.success('Yeşil renk uygulandı');" style="padding: 20px; border-radius: 8px; border: 2px solid transparent; background: #10b981; cursor: pointer;" title="Yeşil"></button>
                            <button onclick="ThemeSystem.setAccentColor('red'); Toast.success('Kırmızı renk uygulandı');" style="padding: 20px; border-radius: 8px; border: 2px solid transparent; background: #ef4444; cursor: pointer;" title="Kırmızı"></button>
                            <button onclick="ThemeSystem.setAccentColor('pink'); Toast.success('Pembe renk uygulandı');" style="padding: 20px; border-radius: 8px; border: 2px solid transparent; background: #ec4899; cursor: pointer;" title="Pembe"></button>
                            <button onclick="ThemeSystem.setAccentColor('orange'); Toast.success('Turuncu renk uygulandı');" style="padding: 20px; border-radius: 8px; border: 2px solid transparent; background: #f59e0b; cursor: pointer;" title="Turuncu"></button>
                        </div>
                        <div style="display: flex; gap: 10px; align-items: center; margin-top: 15px;">
                            <input type="color" id="custom-accent-color" style="width: 50px; height: 40px; padding: 0; border: none; cursor: pointer;">
                            <button class="btn btn-outline" onclick="ThemeSystem.setCustomAccentColor(document.getElementById('custom-accent-color').value); Toast.success('Özel renk uygulandı');">Özel Renk Uygula</button>
                        </div>
                    </div>

                    <!-- View Mode -->
                    <div class="form-group">
                        <label>Görünüm Modu</label>
                        <div style="display: flex; gap: 10px;">
                            <button class="btn ${this.settings.viewMode === 'grid' ? 'btn-primary' : 'btn-outline'}" 
                                    onclick="UserCustomization.setViewMode('grid')">
                                <i class="fa-solid fa-grip"></i> Grid
                            </button>
                            <button class="btn ${this.settings.viewMode === 'list' ? 'btn-primary' : 'btn-outline'}" 
                                    onclick="UserCustomization.setViewMode('list')">
                                <i class="fa-solid fa-list"></i> List
                            </button>
                        </div>
                    </div>

                    <!-- Font Size -->
                    <div class="form-group">
                        <label>Font Boyutu</label>
                        <select id="font-size-select" class="form-select" onchange="UserCustomization.setFontSize(this.value)">
                            <option value="small" ${this.settings.fontSize === 'small' ? 'selected' : ''}>Küçük</option>
                            <option value="medium" ${this.settings.fontSize === 'medium' ? 'selected' : ''}>Orta</option>
                            <option value="large" ${this.settings.fontSize === 'large' ? 'selected' : ''}>Büyük</option>
                            <option value="xlarge" ${this.settings.fontSize === 'xlarge' ? 'selected' : ''}>Çok Büyük</option>
                        </select>
                    </div>

                    <!-- Animation Speed -->
                    <div class="form-group">
                        <label>Animasyon Hızı</label>
                        <select id="animation-speed-select" class="form-select" onchange="UserCustomization.setAnimationSpeed(this.value)">
                            <option value="fast" ${this.settings.animationSpeed === 'fast' ? 'selected' : ''}>Hızlı</option>
                            <option value="normal" ${this.settings.animationSpeed === 'normal' ? 'selected' : ''}>Normal</option>
                            <option value="slow" ${this.settings.animationSpeed === 'slow' ? 'selected' : ''}>Yavaş</option>
                            <option value="off" ${this.settings.animationSpeed === 'off' ? 'selected' : ''}>Kapalı</option>
                        </select>
                    </div>

                    <!-- Compact Mode -->
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="compact-mode" ${this.settings.compactMode ? 'checked' : ''} 
                                   onchange="UserCustomization.toggleCompactMode(this.checked)">
                            Kompakt Mod (Daha az boşluk)
                        </label>
                    </div>

                    <!-- Continue Watching Toggle -->
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="show-continue-watching" ${this.settings.showContinueWatching !== false ? 'checked' : ''} 
                                   onchange="UserCustomization.toggleContinueWatching(this.checked)">
                            Devam Et Bölümünü Göster
                        </label>
                    </div>



                    <!-- Reset -->
                    <button class="btn btn-outline" onclick="UserCustomization.resetSettings()" style="width: 100%; margin-top: 20px;">
                        <i class="fa-solid fa-rotate-left"></i> Varsayılana Dön
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    uploadBanner() {
        const url = document.getElementById('profile-banner-url').value;
        if (!url) {
            Toast.warning('Lütfen bir URL girin');
            return;
        }

        this.settings.profileBanner = url;

        // Sync with user profile if logged in
        if (State.currentUser) {
            State.currentUser.coverPhoto = url;
        }

        this.saveSettings();
        this.applyBanner();
        Toast.success('Banner güncellendi!');

        // Refresh profile if open
        if (window.App && window.App.renderProfile) {
            App.renderProfile();
        }
    },

    applyBanner() {
        const bannerUrl = (State.currentUser && State.currentUser.coverPhoto) || this.settings.profileBanner;
        // FIX: Only apply to the specific cover element, not the whole header container
        const coverElement = document.querySelector('.profile-cover');

        if (coverElement && bannerUrl) {
            coverElement.style.backgroundImage = `url(${bannerUrl})`;
            // backgroundSize and position are already in CSS/Inline style of profile-cover
        }
    },

    setViewMode(mode) {
        this.settings.viewMode = mode;
        this.saveSettings();
        this.applyViewMode();
        Toast.success(`Görünüm: ${mode === 'grid' ? 'Grid' : 'List'}`);
        this.showCustomizationPanel();
    },

    applyViewMode() {
        const containers = document.querySelectorAll('.series-grid, .carousel-track');
        containers.forEach(container => {
            if (this.settings.viewMode === 'list') {
                container.style.display = 'flex';
                container.style.flexDirection = 'column';
                container.style.gap = '15px';
            } else {
                container.style.display = 'grid';
                container.style.gridTemplateColumns = 'repeat(auto-fill, minmax(200px, 1fr))';
                container.style.gap = '20px';
            }
        });
    },

    setFontSize(size) {
        this.settings.fontSize = size;
        this.saveSettings();
        this.applyFontSize();
        Toast.success(`Font boyutu: ${size}`);
    },

    applyFontSize() {
        const sizes = {
            small: '14px',
            medium: '16px',
            large: '18px',
            xlarge: '20px'
        };
        document.documentElement.style.fontSize = sizes[this.settings.fontSize];
    },

    setAnimationSpeed(speed) {
        this.settings.animationSpeed = speed;
        this.saveSettings();
        this.applyAnimationSpeed();
        Toast.success(`Animasyon: ${speed}`);
    },

    applyAnimationSpeed() {
        const speeds = {
            fast: '0.15s',
            normal: '0.3s',
            slow: '0.6s',
            off: '0s'
        };
        document.documentElement.style.setProperty('--transition-speed', speeds[this.settings.animationSpeed]);
    },

    toggleCompactMode(enabled) {
        this.settings.compactMode = enabled;
        this.saveSettings();
        this.applyCompactMode();
        Toast.success(enabled ? 'Kompakt mod açık' : 'Kompakt mod kapalı');
    },

    applyCompactMode() {
        if (this.settings.compactMode) {
            document.body.classList.add('compact-mode');
        } else {
            document.body.classList.remove('compact-mode');
        }
    },

    applyCustomCSS() {
        const css = document.getElementById('custom-css').value;
        this.settings.customCSS = css;
        this.saveSettings();

        // Remove old custom CSS
        const oldStyle = document.getElementById('user-custom-css');
        if (oldStyle) oldStyle.remove();

        // Add new custom CSS
        const style = document.createElement('style');
        style.id = 'user-custom-css';
        style.textContent = css;
        document.head.appendChild(style);

        Toast.success('Özel CSS uygulandı!');
    },

    resetSettings() {
        if (!confirm('Tüm özelleştirmeleri sıfırlamak istediğinizden emin misiniz?')) return;

        this.settings = {
            profileBanner: null,
            customCSS: '',
            viewMode: 'grid',
            fontSize: 'medium',
            animationSpeed: 'normal',
            compactMode: false
        };

        this.saveSettings();
        this.applySettings();

        // Remove custom CSS
        const oldStyle = document.getElementById('user-custom-css');
        if (oldStyle) oldStyle.remove();

        Toast.success('Ayarlar sıfırlandı!');
        location.reload();
    },

    renderInventorySection() {
        if (!State.currentUser || !State.currentUser.inventory || State.currentUser.inventory.length === 0) {
            return `<p style="color:var(--text-secondary); font-size:0.9rem; text-align:center; padding:10px;">Envanteriniz boş. <a href="#" onclick="ShopSystem.openShop(); return false;" style="color:var(--accent-color);">Markete git</a></p>`;
        }

        const inventory = State.currentUser.inventory;
        const activeItems = State.currentUser.activeItems || {};

        // Filter items that are in inventory
        const ownedItems = ShopSystem.items.filter(item => inventory.includes(item.id));

        if (ownedItems.length === 0) return `<p style="color:var(--text-secondary); font-size:0.9rem; text-align:center;">Henüz bir eşya almadınız.</p>`;

        return `
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 10px;">
                ${ownedItems.map(item => {
            const isActive = activeItems[item.type] === item.id;
            let previewStr = '';
            if (item.type === 'frame') previewStr = `<div style="width:30px; height:30px; border-radius:50%; margin:0 auto; ${item.value}"></div>`;
            else if (item.type === 'color') previewStr = `<span style="${item.value.includes('gradient') ? item.value + ';-webkit-background-clip:text;color:transparent;' : 'color:' + item.value}">Aa</span>`;
            else if (item.type === 'title') previewStr = `<span class="tag" style="font-size:0.7rem;">${item.value}</span>`;

            return `
                        <div style="background: var(--bg-card); padding: 10px; border-radius: 8px; border: 1px solid ${isActive ? 'var(--accent-color)' : 'var(--border-color)'}; text-align: center; cursor: pointer;"
                             onclick="UserCustomization.equipFromInventory('${item.id}')">
                            <div style="margin-bottom:5px;">${previewStr}</div>
                            <div style="font-size:0.75rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${item.name}</div>
                            <div style="font-size:0.65rem; color:var(--text-secondary);">${isActive ? '<span style="color:var(--success-color)">Aktif</span>' : 'Seç'}</div>
                        </div>
                    `;
        }).join('')}
            </div>
            <div style="margin-top: 15px; text-align: right;">
                <button class="btn btn-outline btn-sm" onclick="ShopSystem.openShop()">
                    <i class="fa-solid fa-cart-shopping"></i> Daha Fazla Al
                </button>
            </div>
        `;
    },

    equipFromInventory(itemId) {
        if (typeof ShopSystem !== 'undefined' && ShopSystem.equipItem) {
            ShopSystem.equipItem(itemId);
            // ShopSystem handles Toast and save.
            // We need to re-open our panel to show changes
            setTimeout(() => {
                const oldModal = document.querySelector('.modal');
                if (oldModal) oldModal.remove();
                this.open();

                // Also refresh profile if visible
                if (window.App && window.App.renderProfile) App.renderProfile();
            }, 100);
        }
    },

    toggleContinueWatching(enabled) {
        this.settings.showContinueWatching = enabled;
        if (enabled) {
            localStorage.removeItem('dramicbox_cw_dismissed');
        } else {
            localStorage.setItem('dramicbox_cw_dismissed', 'true');
        }
        this.saveSettings();
        this.applyContinueWatching();
        Toast.success(enabled ? 'Devam et bölümü aktif' : 'Devam et bölümü gizlendi');
    },

    applyContinueWatching() {
        const section = document.getElementById('continue-watching-section');
        if (section) {
            const isDismissed = localStorage.getItem('dramicbox_cw_dismissed') === 'true';
            const isEnabled = this.settings.showContinueWatching !== false && !isDismissed;
            section.style.display = isEnabled ? 'block' : 'none';
        }
    },

    applySettings() {
        this.applyBanner();
        this.applyViewMode();
        this.applyFontSize();
        this.applyAnimationSpeed();
        this.applyCompactMode();
        this.applyContinueWatching();

        if (this.settings.customCSS) {
            const style = document.createElement('style');
            style.id = 'user-custom-css';
            style.textContent = this.settings.customCSS;
            document.head.appendChild(style);
        }
    }
};

// CSS for compact mode
const compactModeCSS = `
.compact-mode .series-card {
    padding: 10px !important;
}

.compact-mode .modal-body {
    padding: 15px !important;
}

.compact-mode .section-header {
    margin-bottom: 15px !important;
}

.compact-mode .form-group {
    margin-bottom: 10px !important;
}
`;

const _userCustomizationStyle = document.createElement('style');
_userCustomizationStyle.textContent = compactModeCSS;
document.head.appendChild(_userCustomizationStyle);


// Auto-initialize
window.addEventListener('load', () => {
    setTimeout(() => {
        UserCustomization.init();
    }, 1500);
});
window.UserCustomization = UserCustomization;
window.ThemeSystem = ThemeSystem;
