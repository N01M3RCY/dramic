// ============================================
// DRAMICBOX - SOCIAL & COMMENTS EXPANSION
// Advanced social features and comment system
// ============================================

// --- REAL-TIME SOCIAL SYSTEM (SSE) ---
// --- LOCAL-FIRST SOCIAL SYSTEM ---
const RealTimeSocial = {
    init() {
        if (!State.currentUser || State.currentUser.role === 'guest') return;
        console.log('📱 Local Social Hub initialized');
        // No more SSE/polling, everything is handled via shared State.data
    },

    handleUpdate(act) {
        // Local simulation of updates
        if (act.userId !== State.currentUser?.id) {
            this.showLiveActivityToast(act);
        }
    },

    // --- TYPING INDICATOR ---
    typingTimeout: null,
    isTyping: false,

    notifyTyping(postId) {
        if (this.isTyping) return;
        this.isTyping = true;
        
        // Simulate typing event to server (could be SSE event in real app)
        console.log('⌨️ User is typing...');
        
        if (this.typingTimeout) clearTimeout(this.typingTimeout);
        this.typingTimeout = setTimeout(() => {
            this.isTyping = false;
        }, 3000);
    },

    renderOnlineUsers() {
        const users = State.data.users || [];
        const now = Date.now();
        const onlineUsers = users.filter(u => {
            if (!u.lastActive) return false;
            // Active in last 5 minutes
            return (now - u.lastActive) < (5 * 60 * 1000);
        });

        const container = document.getElementById('online-users-list');
        if (!container) return;

        if (onlineUsers.length === 0) {
            container.innerHTML = '<p style="color:#64748b; font-size:0.8rem; text-align:center;">Şu an kimse yok.</p>';
            return;
        }

        container.innerHTML = onlineUsers.map(u => `
            <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;" title="${u.username} çevrimiçi">
                <div style="position:relative;">
                    <img src="${u.avatar || 'assets/logo.png'}" style="width:32px; height:32px; border-radius:50%; object-fit:cover;">
                    <span style="position:absolute; bottom:0; right:0; width:10px; height:10px; background:#10b981; border:2px solid #0f0f13; border-radius:50%;"></span>
                </div>
                <span style="color:#e2e8f0; font-size:0.85rem; font-weight:600;">${u.username}</span>
            </div>
        `).join('');
    }
};

// Global Activity Logger
// Global Activity Logger - Local Only
window.logActivity = function(type, data) {
    if (!State.currentUser) return;
    console.log(`📝 Activity Logged: ${type}`, data);
    
    // Add to local activities list for feed
    if (window.ActivityFeed) {
        ActivityFeed.log(type, data);
    }
};

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => RealTimeSocial.init(), 2000);
});

// --- ADVANCED COMMENTS SYSTEM ---
const AdvancedComments = {
    // Reply to comments (Threading)
    replyToComment(commentIndex, seriesId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning("⚠️ Yanıt vermek için giriş yapmalısınız!");
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }

        const replyText = prompt("Yanıtınızı yazın:");
        if (!replyText) return;

        const series = db.getSeries(seriesId);
        const comment = series.comments[commentIndex];

        if (!comment.replies) comment.replies = [];

        comment.replies.push({
            userId: State.currentUser.id,
            username: State.currentUser.username,
            avatar: State.currentUser.avatar,
            text: replyText,
            date: new Date().toLocaleDateString('tr-TR')
        });

        db.saveDebounced();
        Toast.success("✅ Yanıt eklendi!");
        Comments.displayComments(series);

        // Update quest
        DailyQuests.updateProgress('comment_5');
    },

    // Emoji Reactions
    addReaction(commentIndex, emoji) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning("⚠️ Reaksiyon vermek için giriş yapmalısınız!");
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }

        const series = State.currentSeries;
        const comment = series.comments[commentIndex];

        if (!comment.reactions) comment.reactions = {};
        if (!comment.reactions[emoji]) comment.reactions[emoji] = [];

        const userIndex = comment.reactions[emoji].indexOf(State.currentUser.id);
        if (userIndex > -1) {
            comment.reactions[emoji].splice(userIndex, 1);
        } else {
            comment.reactions[emoji].push(State.currentUser.id);
        }

        db.saveDebounced();
        Comments.displayComments(series); 
    },

    // Sort comments
    sortComments(series, sortBy = 'newest') {
        if (!series.comments) return [];

        const sorted = [...series.comments];

        switch (sortBy) {
            case 'newest':
                return sorted.reverse();
            case 'oldest':
                return sorted;
            case 'popular':
                return sorted.sort((a, b) => (b.likes?.length || 0) - (a.likes?.length || 0));
            default:
                return sorted;
        }
    },

    // Mention system
    parseMentions(text) {
        return text.replace(/@(\w+)/g, '<span class="mention">@$1</span>');
    },

    // GIF Support (Tenor API would be integrated here)
    insertGIF(commentIndex) {
        Toast.info("🎬 GIF özelliği yakında eklenecek!");
    }
};

// --- USER PROFILES ---
const UserProfiles = {
    viewProfile(userId) {
        App.router('profile', userId); // Use the Full Page Profile instead of Modal
    },

    // Follow/Unfollow system
    toggleFollow(userId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning("⚠️ Takip etmek için giriş yapmalısınız!");
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }

        if (userId === State.currentUser.id) return;

        if (!State.currentUser.following) State.currentUser.following = [];

        const index = State.currentUser.following.indexOf(userId);
        let isFollowing = false;

        if (index > -1) {
            State.currentUser.following.splice(index, 1);
            Toast.info("👋 Takibi bıraktınız");
            isFollowing = false;
        } else {
            State.currentUser.following.push(userId);
            Toast.success("✅ Takip ediyorsunuz!");
            Gamification.addXP(10, "Kullanıcı Takibi");

            // Notification to target
            Social.addNotification(userId, 'Yeni Takipçi', `${State.currentUser.username} seni takip etmeye başladı.`);

            isFollowing = true;
        }

        // Persist
        if (window.db && window.db.updateUser) {
            db.updateUser(State.currentUser.id, { following: State.currentUser.following });
        } else {
            // Fallback
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        }

        // Refresh UI if on profile page
        if (window.UserProfile && UserProfile.currentUserId === userId) {
            UserProfile.show(userId);
        }

        return isFollowing;
    },

    getFollowersCount(userId) {
        if (!State.data.users) return 0;
        return State.data.users.filter(u => u.following && u.following.includes(userId)).length;
    },

    getFollowingCount(userId) {
        const user = State.data.users.find(u => u.id === userId);
        return user && user.following ? user.following.length : 0;
    }
};

// --- ACTIVITY FEED ---
const ActivityFeed = {
    // Log a new activity
    log(type, data) {
        if (!State.currentUser) return;

        const activity = {
            id: 'act-' + Date.now() + Math.random().toString(36).substr(2, 5),
            userId: State.currentUser.id,
            username: State.currentUser.username,
            avatar: State.currentUser.avatar,
            type: type, // 'watch', 'comment', 'rate', 'follow', 'level_up'
            data: data,
            timestamp: Date.now()
        };

        // Add to global state
        if (!State.data.activities) State.data.activities = [];
        State.data.activities.unshift(activity);

        // Keep logs manageable (last 500 global activities)
        if (State.data.activities.length > 500) {
            State.data.activities = State.data.activities.slice(0, 500);
        }

        // Save DB
        if (window.db && window.db.save) window.db.save();
    },

    // Get activities for a specific user (Personal Feed)
    getUserActivity(userId) {
        if (!State.data.activities) return [];
        return State.data.activities.filter(a => a.userId === userId);
    },

    // Get feed from people I follow (Social Feed)
    getSocialFeed() {
        if (!State.currentUser || !State.currentUser.following) return [];
        if (!State.data.activities) return [];

        const followingIds = State.currentUser.following;
        return State.data.activities
            .filter(a => followingIds.includes(a.userId))
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, 50);
    },

    // Generate HTML for a list of activities
    renderList(activities) {
        if (!activities || activities.length === 0) {
            return '<div style="padding: 20px; text-align: center; color: var(--text-secondary);">Henüz aktivite yok.</div>';
        }

        return activities.map(a => {
            let icon, text, content = '';

            switch (a.type) {
                case 'watch':
                    icon = '<i class="fa-solid fa-play" style="color: #a78bfa;"></i>';
                    text = `<strong>${a.data.title}</strong> (${a.data.episode}. Bölüm) izledi`;
                    content = `<div style="font-size:0.85rem; color:#64748b; margin-top:4px;">${a.data.seriesTitle}</div>`;
                    break;
                case 'comment':
                    icon = '<i class="fa-solid fa-comment" style="color: #60a5fa;"></i>';
                    text = `<strong>${a.data.seriesTitle}</strong> dizisine yorum yaptı`;
                    content = `<div style="font-size:0.9rem; color:#e2e8f0; margin-top:6px; background:rgba(255,255,255,0.05); padding:8px 12px; border-radius:8px;">"${a.data.comment}"</div>`;
                    break;
                case 'rate':
                    icon = '<i class="fa-solid fa-star" style="color: #fbbf24;"></i>';
                    text = `<strong>${a.data.seriesTitle}</strong> dizisine ${a.data.rating} puan verdi`;
                    break;
                case 'follow':
                    icon = '<i class="fa-solid fa-user-plus" style="color: #34d399;"></i>';
                    text = `<strong>${a.data.targetName}</strong> kullanıcısını takip etti`;
                    break;
                case 'level_up':
                    icon = '<i class="fa-solid fa-trophy" style="color: #f472b6;"></i>';
                    text = `<strong>Seviye ${a.data.level}</strong> oldu!`;
                    break;
                default:
                    icon = '<i class="fa-solid fa-circle-dot"></i>';
                    text = 'Bir işlem yaptı';
            }

            return `
                <div class="activity-item" style="display: flex; gap: 15px; padding: 15px; border-bottom: 1px solid rgba(255,255,255,0.05);">
                    <div style="flex-shrink: 0;">
                        <img src="${a.avatar || 'assets/logo.png'}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">
                    </div>
                    <div style="flex: 1;">
                        <div style="font-size: 0.95rem; color: #fff; margin-bottom: 2px;">
                            <span style="font-weight: 700;">${a.username}</span> 
                            <span style="color: #94a3b8; font-weight: 400; font-size: 0.9rem;"> • ${this.timeAgo(a.timestamp)}</span>
                        </div>
                        <div style="color: #cbd5e1; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">
                            ${icon} <span>${text}</span>
                        </div>
                        ${content}
                    </div>
                </div>
            `;
        }).join('');
    },

    timeAgo(timestamp) {
        const seconds = Math.floor((Date.now() - timestamp) / 1000);
        if (seconds < 60) return 'Az önce';
        if (seconds < 3600) return Math.floor(seconds / 60) + 'dk';
        if (seconds < 86400) return Math.floor(seconds / 3600) + 's';
        return Math.floor(seconds / 86400) + 'g';
    }
};

// --- GROUPS SYSTEM ---
const Groups = {
    // Create a new group
    async createGroup(name, description) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning("⚠️ Grup oluşturmak için giriş yapmalısınız!");
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }

        if (!name) {
            Toast.warning("Grup adı boş olamaz!");
            return;
        }

        if (!State.data.groups) State.data.groups = [];

        const group = {
            id: 'group-' + Date.now(),
            name: name,
            description: description || '',
            creatorId: State.currentUser.id,
            members: [State.currentUser.id],
            createdAt: Date.now()
        };

        State.data.groups.push(group);
        await db.save();

        Toast.success(`🎉 "${name}" grubu başarıyla oluşturuldu!`);
        
        if (window.ActivityFeed) {
            ActivityFeed.log('create_group', { groupId: group.id, groupName: group.name });
        }

        return group;
    },

    // Join a group
    async joinGroup(groupId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning("⚠️ Gruba katılmak için giriş yapmalısınız!");
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }

        if (!State.data.groups) State.data.groups = [];
        
        const group = State.data.groups.find(g => g.id === groupId);
        if (!group) {
            Toast.error("Grup bulunamadı.");
            return;
        }

        if (!group.members) group.members = [];

        const memberIndex = group.members.indexOf(State.currentUser.id);
        if (memberIndex > -1) {
            group.members.splice(memberIndex, 1);
            Toast.info(`👋 "${group.name}" grubundan ayrıldınız.`);
        } else {
            group.members.push(State.currentUser.id);
            Toast.success(`🤝 "${group.name}" grubuna katıldınız!`);
            
            if (window.ActivityFeed) {
                ActivityFeed.log('join_group', { groupId: group.id, groupName: group.name });
            }
        }

        await db.save();
    }
};
window.Groups = Groups;

// --- MOBILE HELPER ---
const MobileHelper = {
    setupSwipeGestures() {
        this.touchStartX = 0;
        this.touchEndX = 0;

        document.addEventListener('touchstart', e => {
            this.touchStartX = e.changedTouches[0].screenX;
        });

        document.addEventListener('touchend', e => {
            this.touchEndX = e.changedTouches[0].screenX;
            this.handleSwipe();
        });
    },

    handleSwipe() {
        const diff = this.touchStartX - this.touchEndX;

        if (Math.abs(diff) > 50) { // Minimum swipe distance
            if (diff > 0) {
                // Swipe left - Next episode
                const nextBtn = document.getElementById('next-ep-btn');
                if (nextBtn && !nextBtn.disabled) {
                    nextBtn.click();
                    Toast.info("⏭️ Sonraki bölüm");
                }
            } else {
                // Swipe right - Previous episode
                const prevBtn = document.getElementById('prev-ep-btn');
                if (prevBtn && !prevBtn.disabled) {
                    prevBtn.click();
                    Toast.info("⏮️ Önceki bölüm");
                }
            }
        }
    },

    setupPullToRefresh() {
        let startY = 0;
        let isPulling = false;

        document.addEventListener('touchstart', e => {
            if (window.scrollY === 0) {
                startY = e.touches[0].pageY;
                isPulling = true;
            }
        });

        document.addEventListener('touchmove', e => {
            if (!isPulling) return;

            const currentY = e.touches[0].pageY;
            const diff = currentY - startY;

            if (diff > 100) {
                this.refresh();
                isPulling = false;
            }
        });

        document.addEventListener('touchend', () => {
            isPulling = false;
        });
    },

    refresh() {
        Toast.info("🔄 Yenileniyor...");
        setTimeout(() => {
            location.reload();
        }, 500);
    },

    detectSystemTheme() {
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            // System is in dark mode
            const savedTheme = localStorage.getItem('dramicbox_theme');
            if (!savedTheme) {
                Theme.setTheme('dark');
            }
        }

        // Listen for system theme changes
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
            const autoTheme = localStorage.getItem('auto_theme');
            if (autoTheme === 'true') {
                Theme.setTheme(e.matches ? 'dark' : 'light');
            }
        });
    }
};

// --- NOTIFICATION PREFERENCES ---
const NotificationPreferences = {
    preferences: {
        newEpisode: true,
        translationComplete: true,
        commentReply: true,
        friendActivity: true,
        dailyQuest: true
    },

    load() {
        const saved = localStorage.getItem('notification_preferences');
        if (saved) {
            this.preferences = JSON.parse(saved);
        }
    },

    save() {
        localStorage.setItem('notification_preferences', JSON.stringify(this.preferences));
        Toast.success("✅ Bildirim tercihleri kaydedildi!");
    },

    toggle(type) {
        this.preferences[type] = !this.preferences[type];
        this.save();
    },

    shouldNotify(type) {
        return this.preferences[type] !== false;
    }
};

const Social = {
    friends: [],
    messages: [],
    pendingRequests: [],
    pollInterval: null,

    init() {
        if (!State.currentUser) return;
        this.getFriends();
        this.updateNavbarUI();
        this.updatePresence();
        this.startPolling();
    },

    startPolling() {
        if (this.pollInterval) clearInterval(this.pollInterval);
        this.pollInterval = setInterval(() => {
            if (State.currentUser && document.visibilityState === 'visible') {
                this.updatePresence();
                if (window.MessageService) {
                    MessageService.fetchMessages(State.currentUser.id).then(() => {
                        this.updateNavbarUI();
                    });
                }
            }
        }, 10000);
    },

    updatePresence() {
        if (!State.currentUser) return;
        const user = State.data.users?.find(u => u.id === State.currentUser.id);
        if (user) {
            user.lastActivity = Date.now();
            if (!user.onlineStatus) user.onlineStatus = 'online';
        }
    },

    getUserPresence(u) {
        if (!u) return { status: 'offline', dotClass: 'offline', label: 'Çevrimdışı', lastSeen: '' };
        const mode = u.onlineStatus || 'offline';
        const lastSeenTime = u.lastActivity;
        const isRecent = lastSeenTime && (Date.now() - lastSeenTime < 300000);

        if (mode === 'invisible') return { status: 'invisible', dotClass: 'offline', label: 'Çevrimdışı', lastSeen: '' };
        if (mode === 'dnd' && isRecent) return { status: 'dnd', dotClass: 'dnd', label: 'R.E.', lastSeen: '' };
        if (mode === 'idle' && isRecent) return { status: 'idle', dotClass: 'idle', label: 'Boşta', lastSeen: '' };
        if (isRecent && (mode === 'online' || !mode)) return { status: 'online', dotClass: 'online', label: 'Çevrimiçi', lastSeen: '' };
        
        return { 
            status: 'offline', 
            dotClass: 'offline', 
            label: 'Çevrimdışı', 
            lastSeen: lastSeenTime ? new Date(lastSeenTime).toLocaleTimeString('tr-TR', {hour:'2-digit', minute:'2-digit'}) : '' 
        };
    },

    async setUserStatus(status) {
        if (!State.currentUser) return;
        State.currentUser.onlineStatus = status;
        const user = State.data.users?.find(u => u.id === State.currentUser.id);
        if (user) user.onlineStatus = status;
        await db.save();
        Toast.success(`Durum: ${status} ✅`);
        const picker = document.getElementById('status-picker-area');
        if (picker) this.renderStatusPicker(picker);
    },

    renderStatusPicker(container) {
        const current = State.currentUser?.onlineStatus || 'online';
        const statuses = [
            { key: 'online', icon: 'fa-circle', color: '#10b981', label: 'Çevrimiçi' },
            { key: 'idle', icon: 'fa-moon', color: '#f59e0b', label: 'Boşta' },
            { key: 'dnd', icon: 'fa-minus-circle', color: '#ef4444', label: 'R.E.' },
            { key: 'invisible', icon: 'fa-eye-slash', color: '#475569', label: 'Görünmez' },
        ];
        container.innerHTML = statuses.map(s => `
            <div onclick="Social.setUserStatus('${s.key}')" style="display:flex; align-items:center; gap:10px; padding:8px 14px; cursor:pointer; border-radius:10px; background:${current === s.key ? 'rgba(139,92,246,0.1)' : 'transparent'};">
                <i class="fa-solid ${s.icon}" style="color:${s.color}; font-size:0.7rem;"></i>
                <span style="color:${current === s.key ? '#a78bfa' : '#94a3b8'}; font-size:0.8rem;">${s.label}</span>
            </div>
        `).join('');
    },

    getFriends() {
        if (State.currentUser && State.currentUser.friends) {
            this.friends = State.currentUser.friends;
        } else {
            this.friends = [];
        }
    },

    async getMessages(userId) {
        if (window.MessageService) {
            this.messages = await MessageService.fetchMessages(userId);
        } else {
            // Fallback for isolated testing
            if (!State.data.messages) State.data.messages = [];
            this.messages = State.data.messages.filter(m => m.from === userId || m.to === userId);
        }
    },

    getPendingCount() {
        if (!State.currentUser || !State.data.friendRequests) return 0;
        return State.data.friendRequests.filter(r => r.to === State.currentUser.id && r.status === 'pending').length;
    },

    async sendFriendRequest(userId) {
        if (!State.currentUser) return Toast.warning("⚠️ Giriş yapmalısınız!");
        if (State.currentUser.id === userId) return;
        
        const isAlreadyFriend = (State.currentUser.friends || []).includes(userId);
        if (isAlreadyFriend) return Toast.info("Zaten arkadaşsınız.");

        try {
            // Check global requests
            if (!State.data.friendRequests) State.data.friendRequests = [];
            
            const existing = State.data.friendRequests.find(r => 
                (r.from === State.currentUser.id && r.to === userId) ||
                (r.from === userId && r.to === State.currentUser.id)
            );

            if (existing) {
                if (existing.status === 'pending') {
                    if (existing.from === State.currentUser.id) return Toast.info("İstek zaten gönderildi.");
                    return this.acceptFriendRequest(userId); // Auto-accept if they sent one too
                }
                return;
            }

            const newReq = {
                id: 'req-' + Date.now(),
                from: State.currentUser.id,
                to: userId,
                status: 'pending',
                timestamp: Date.now()
            };

            State.data.friendRequests.push(newReq);
            
            // Sync current user's locally sent list for UI
            if (!State.currentUser.friendRequestsSent) State.currentUser.friendRequestsSent = [];
            State.currentUser.friendRequestsSent.push(userId);

            await db.save();
            this.addNotification(userId, 'Yeni Arkadaşlık İsteği', `${State.currentUser.username} sana arkadaşlık isteği gönderdi.`);
            Toast.success("Arkadaşlık isteği gönderildi!");
            
            // Trigger UI updates
            if (window.UserProfile && UserProfile.currentUserId === userId) UserProfile.show(userId);
        } catch (error) {
            console.error('SR error:', error);
        }
    },

    async sendMessage(userId, text) {
        if (!State.currentUser) return;

        try {
            if (window.MessageService) {
                const success = await MessageService.sendMessage(userId, text);
                if (success) {
                    await this.getMessages(State.currentUser.id);
                }
                return success;
            } else {
                // Fallback
                if (!State.data.messages) State.data.messages = [];
                const message = {
                    id: 'msg-' + Date.now(),
                    from: State.currentUser.id,
                    to: userId,
                    text: text,
                    timestamp: Date.now(),
                    read: false
                };
                State.data.messages.push(message);
                this.messages.push(message);
                if (window.db && window.db.save) window.db.save();
                return true;
            }
        } catch (error) {
            console.error('Send message error:', error);
            Toast.error("Mesaj gönderilemedi.");
            return false;
        }
    },

    // --- USER SEARCH ---
    searchUsers(query) {
        if (!query) return [];
        query = query.toLowerCase();
        // Filter users: exclude self, match username
        return State.data.users.filter(u =>
            u.id !== State.currentUser.id &&
            u.username.toLowerCase().includes(query)
        );
    },

    renderUserSearchResults(users) {
        const container = document.getElementById('social-search-results');
        if (!container) return;

        if (users.length === 0) {
            container.innerHTML = '<p style="text-align:center; color:var(--text-secondary); margin-top:20px;">Kullanıcı bulunamadı.</p>';
            return;
        }

        container.innerHTML = users.map(user => {
            const isFriend = this.friends.includes(user.id);
            const isPending = (State.data.friendRequests || []).some(r => r.from === State.currentUser.id && r.to === user.id);

            let actionBtn = '';
            if (isFriend) {
                actionBtn = '<span class="tag tag-success"><i class="fa-solid fa-check"></i> Arkadaş</span>';
            } else if (isPending) {
                actionBtn = '<span class="tag tag-warning"><i class="fa-solid fa-clock"></i> İstek Gönderildi</span>';
            } else {
                actionBtn = `<button class="btn btn-sm btn-primary" onclick="Social.sendFriendRequest('${user.id}')"><i class="fa-solid fa-user-plus"></i> Ekle</button>`;
            }

            return `
                <div style="display:flex; align-items:center; justify-content:space-between; padding:10px; background:var(--bg-secondary); border-radius:8px; margin-bottom:10px;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <img src="${user.avatar || 'https://via.placeholder.com/40'}" style="width:40px; height:40px; border-radius:50%; object-fit:cover;">
                        <div>
                            <div style="font-weight:600;">${user.username}</div>
                            <div style="font-size:0.8rem; color:var(--text-secondary);">${user.badges ? user.badges[0] || 'Kullanıcı' : 'Kullanıcı'}</div>
                        </div>
                    </div>
                    ${actionBtn}
                </div>
            `;
        }).join('');
    },

    showSocialModal() {
        if (!State.currentUser) {
            Toast.warning("Önce giriş yapmalısınız.");
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal social-modal-premium';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <style>
                .social-modal-premium .modal-content {
                    max-width: 1000px; height: 85vh; width: 95%; background: rgba(10, 10, 14, 0.95);
                    backdrop-filter: blur(40px); border: 1px solid rgba(255,255,255,0.08); 
                    border-radius: 30px; display: flex; flex-direction: column; overflow: hidden;
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); font-family: 'Inter', sans-serif;
                }
                .social-modal-body { display: flex; flex: 1; overflow: hidden; }
                .social-sidebar { 
                    width: 320px; background: rgba(255, 255, 255, 0.02); 
                    border-right: 1px solid rgba(255,255,255,0.05); display: flex; flex-direction: column; 
                }
                .social-content { flex: 1; display: flex; flex-direction: column; background: rgba(0,0,0,0.2); }
                .social-tab-btn { 
                    padding: 12px; font-weight: 600; border-radius: 12px; flex: 1;
                    background: transparent; border: 1px solid transparent; color: #94a3b8;
                    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); cursor: pointer;
                }
                .social-tab-btn:hover { background: rgba(255,255,255,0.05); color: #fff; }
                .social-tab-btn.active { 
                    background: rgba(139, 92, 246, 0.1); color: #a78bfa; border-color: rgba(139, 92, 246, 0.2); 
                }
                .friend-item {
                    padding: 14px 20px; cursor: pointer; display: flex; align-items: center; gap: 14px;
                    transition: all 0.3s; margin: 0 10px 4px; border-radius: 16px;
                }
                .friend-item:hover { background: rgba(255,255,255,0.04); transform: translateX(5px); }
                .friend-item.active { background: rgba(139, 92, 246, 0.1); }
                
                /* Chat Bubbles */
                .bubble { 
                    max-width: 75%; padding: 12px 18px; border-radius: 20px; font-size: 0.95rem; line-height: 1.5;
                    position: relative; animation: slideIn 0.3s ease-out;
                }
                @keyframes slideIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
                .bubble.me { 
                    background: linear-gradient(135deg, #7c3aed, #6366f1); color: #fff; align-self: flex-end;
                    border-bottom-right-radius: 4px; box-shadow: 0 4px 15px rgba(124, 58, 237, 0.2);
                }
                .bubble.them { 
                    background: rgba(255,255,255,0.05); color: #e2e8f0; align-self: flex-start;
                    border-bottom-left-radius: 4px; border: 1px solid rgba(255,255,255,0.05);
                }
                
                @media (max-width: 768px) {
                    .social-modal-body { flex-direction: column; }
                    .social-sidebar { width: 100%; height: auto; border-right: none; border-bottom: 1px solid rgba(255,255,255,0.05); }
                    .social-sidebar.hide-mobile { display: none; }
                    .social-content { display: none; height: 100%; }
                    .social-content.show-mobile { display: flex; }
                    .bubble { max-width: 85%; padding: 10px 14px; font-size: 0.9rem; }
                }
                
                .typing-indicator { font-size: 0.8rem; color: #a78bfa; font-style: italic; margin-left: 10px; opacity: 0; transition: opacity 0.3s; }
                .typing-indicator.show { opacity: 1; }

                /* Status Dots */
                .status-dot { width: 12px; height: 12px; border-radius: 50%; border: 2px solid #0a0a0e; display: inline-block; }
                .status-dot.online { background: #10b981; box-shadow: 0 0 10px rgba(16, 185, 129, 0.4); }
                .status-dot.idle { background: #f59e0b; }
                .status-dot.dnd { background: #ef4444; }
                .status-dot.offline { background: #475569; }

                /* Read Receipts */
                .msg-read-receipt { font-size: 0.65rem; color: #64748b; margin-left: 5px; }
                .msg-read-receipt.seen { color: #38bdf8; font-weight: 600; }
            </style>
            <div class="modal-content">
                <div class="social-modal-body">
                    <!-- Sidebar -->
                    <div class="social-sidebar">
                        <div style="padding: 24px;">
                            <h2 style="font-size: 1.4rem; font-weight: 800; color: #fff; margin-bottom: 20px;">Sohbetler</h2>
                            <div style="display: flex; gap: 8px; margin-bottom: 20px; background: rgba(0,0,0,0.2); padding: 5px; border-radius: 14px;">
                                <button class="social-tab-btn active" id="tab-btn-friends" onclick="Social.switchTab('friends')">
                                    <i class="fa-solid fa-message"></i>
                                </button>
                                <button class="social-tab-btn" id="tab-btn-requests" onclick="Social.switchTab('requests')">
                                    <i class="fa-solid fa-user-plus"></i>
                                    ${this.getPendingCount() > 0 ? `<span style="position:absolute; top:5px; right:5px; width:8px; height:8px; background:#ef4444; border-radius:50%;"></span>` : ''}
                                </button>
                                <button class="social-tab-btn" id="tab-btn-notifications" onclick="Social.switchTab('notifications')">
                                    <i class="fa-solid fa-bell"></i>
                                </button>
                                <button class="social-tab-btn" id="tab-btn-search" onclick="Social.switchTab('search')">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>

                        <div style="overflow-y:auto; flex:1; padding-bottom: 20px;" class="custom-scrollbar"> 
                             <!-- Friends List -->
                            <div id="social-tab-friends">
                                ${this.friends.length > 0 ? this.friends.map(fid => {
            const user = State.data.users.find(u => u.id === fid);
            const presence = this.getUserPresence(user);
            return `
                                        <div class="friend-item" onclick="Social.openChat('${fid}')">
                                            <div style="position:relative;">
                                                <img src="${user?.avatar || 'assets/logo.png'}" style="width:48px; height:48px; border-radius:50%; object-fit:cover; background: #222;">
                                                <span class="status-dot ${presence.dotClass}" style="position:absolute; bottom:2px; right:2px;"></span>
                                            </div>
                                            <div style="flex:1; overflow:hidden;">
                                                <div style="font-weight: 600; color: #fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${user ? user.username : 'Kullanıcı'}</div>
                                                <div style="font-size: 0.75rem; color: ${presence.status === 'online' ? '#10b981' : presence.status === 'dnd' ? '#ef4444' : presence.status === 'idle' ? '#f59e0b' : '#64748b'};">${presence.label}${presence.lastSeen ? ' · ' + presence.lastSeen : ''}</div>
                                            </div>
                                        </div>`;
        }).join('') : '<div style="padding:40px; text-align:center; color:#475569;"><p>Henüz arkadaş yok</p></div>'}
                            </div>

                            <div id="social-tab-notifications" style="display:none; padding: 0 10px;">
                                <div id="social-notifications-list"></div>
                            </div>

                            <div id="social-tab-requests" style="display:none; padding: 0 10px;">
                                <div id="social-requests-list"></div>
                            </div>

                            <div id="social-tab-search" style="display:none; padding: 0 24px;">
                                <div style="position: relative; margin-bottom: 20px;">
                                    <i class="fa-solid fa-search" style="position: absolute; left: 14px; top: 12px; color: #475569;"></i>
                                    <input type="text" id="social-user-search-input" placeholder="Kullanıcı ara..." 
                                       class="form-input" 
                                       style="background:rgba(0,0,0,0.3); padding-left: 42px; border-radius: 12px;"
                                       oninput="Social.renderUserSearchResults(Social.searchUsers(this.value))">
                                </div>
                                <div id="social-search-results"></div>
                            </div>
                        </div>
                        
                        <!-- Status Picker -->
                        <div style="padding: 12px 20px; border-top: 1px solid rgba(255,255,255,0.05);">
                            <div style="font-size: 0.7rem; color: #64748b; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px;">Durumun</div>
                            <div id="status-picker-area"></div>
                        </div>

                        <div style="padding: 12px 20px; border-top: 1px solid rgba(255,255,255,0.05);">
                            <button class="btn btn-sm btn-block" onclick="this.closest('.modal').remove()" style="background: rgba(255,255,255,0.05); color: #94a3b8;">Kapat</button>
                        </div>
                    </div>

                    <!-- Chat Area -->
                    <div id="social-chat-area" class="social-content">
                        <div style="flex: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; color: #475569; text-align: center;">
                            <div style="width: 100px; height: 100px; background: rgba(139, 92, 246, 0.05); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 24px; color: rgba(139, 92, 246, 0.2);">
                                <i class="fa-solid fa-comments" style="font-size: 3rem;"></i>
                            </div>
                            <h3 style="color: #fff; font-size: 1.2rem; font-weight: 700;">Bir sohbet seçin</h3>
                            <p style="font-size: 0.9rem; max-width: 250px; margin-top: 8px;">Arkadaşlarınızla mesajlaşmaya başlamak için listeden birini seçin.</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Render status picker
        const statusArea = document.getElementById('status-picker-area');
        if (statusArea) this.renderStatusPicker(statusArea);
    },

    promptNewMessage() {
        this.switchTab('search');
        // Optional: Pre-fill or focus search if needed
        setTimeout(() => {
            const input = document.getElementById('social-user-search-input');
            if (input) input.focus();
        }, 100);
    },

    switchTab(tab) {
        const friendsTab = document.getElementById('social-tab-friends');
        const searchTab = document.getElementById('social-tab-search');
        const requestsTab = document.getElementById('social-tab-requests');
        const notificationsTab = document.getElementById('social-tab-notifications');

        if (friendsTab) friendsTab.style.display = tab === 'friends' ? 'block' : 'none';
        if (searchTab) searchTab.style.display = tab === 'search' ? 'block' : 'none';
        if (requestsTab) requestsTab.style.display = tab === 'requests' ? 'block' : 'none';
        if (notificationsTab) notificationsTab.style.display = tab === 'notifications' ? 'block' : 'none';

        const friendsBtn = document.getElementById('tab-btn-friends');
        const searchBtn = document.getElementById('tab-btn-search');
        const requestsBtn = document.getElementById('tab-btn-requests');
        const notificationsBtn = document.getElementById('tab-btn-notifications');

        if (friendsBtn) friendsBtn.classList.toggle('active', tab === 'friends');
        if (searchBtn) searchBtn.classList.toggle('active', tab === 'search');
        if (requestsBtn) requestsBtn.classList.toggle('active', tab === 'requests');
        if (notificationsBtn) notificationsBtn.classList.toggle('active', tab === 'notifications');

        if (tab === 'search') {
            const input = document.getElementById('social-user-search-input');
            if (input) input.focus();
        }

        if (tab === 'requests') {
            this.renderFriendRequests();
        }

        if (tab === 'notifications') {
            this.renderNotifications();
        }
    },

    getNotificationCount() {
        if (!State.currentUser || !State.currentUser.notifications) return 0;
        return State.currentUser.notifications.filter(n => !n.read).length;
    },

    renderNotifications() {
        // Render for Modal
        const container = document.getElementById('social-notifications-list');
        const notifications = State.currentUser.notifications || [];

        if (container) {
            if (notifications.length === 0) {
                container.innerHTML = '<div style="text-align:center; padding:20px; color:#666;"><i class="fa-solid fa-bell-slash" style="font-size:2rem; margin-bottom:10px;"></i><p>Bildiriminiz yok.</p></div>';
            } else {
                container.innerHTML = notifications.slice().reverse().map((notif, index) => {
                    return `
                        <div style="padding:15px; border-bottom:1px solid #333; background: ${notif.read ? 'transparent' : 'rgba(255, 215, 0, 0.1)'}; display:flex; align-items:start; gap:10px;">
                            <div style="flex:1;">
                                <div style="font-weight:600; margin-bottom:5px;">${notif.title || 'Bildirim'}</div>
                                <div style="font-size:0.9rem; color:#ccc;">${notif.message}</div>
                                <div style="font-size:0.8rem; color:#666; margin-top:5px;">${notif.timestamp ? new Date(notif.timestamp).toLocaleString('tr-TR') : ''}</div>
                            </div>
                            ${!notif.read ? `<button class="btn btn-sm" onclick="Social.markNotificationAsRead(${index})" title="Okundu işaretle"><i class="fa-solid fa-check"></i></button>` : ''}
                        </div>
                    `;
                }).join('');
            }
        }

        // Render for Navbar
        this.updateNavbarUI();
    },

    updateNavbarUI() {
        if (!State.currentUser) return;

        const notifications = State.currentUser.notifications || [];
        const unreadCount = notifications.filter(n => !n.read).length;

        // Badge
        const badge = document.getElementById('notification-count');
        if (badge) {
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? 'flex' : 'none';
        }

        // Dropdown List
        const list = document.getElementById('notif-list');
        if (list) {
            if (notifications.length === 0) {
                list.innerHTML = '<li style="padding: 15px; text-align: center; color: var(--text-secondary);">Henüz bildirim yok</li>';
            } else {
                // Show last 5 notifications in dropdown
                const recent = notifications.slice().reverse().slice(0, 5);
                list.innerHTML = recent.map((notif, index) => {
                    // Calculate real index for click handler (since we reversed, logic needs care or we pass ID)
                    // Simplest: just pass the ID if available, or just use the reverse index logic if consistent
                    // For now, let's use a specialized clicking that opens the full modal or marks as read
                    return `
                        <li style="padding: 12px; border-bottom: 1px solid rgba(255,255,255,0.05); background: ${notif.read ? 'transparent' : 'rgba(255, 215, 0, 0.05)'}; cursor: pointer;" onclick="Social.handleNotificationClick('${notif.id || ''}')">
                            <div style="font-size: 0.9rem; font-weight: 600; margin-bottom: 4px; color: ${notif.read ? '#ccc' : '#fff'};">
                                ${notif.read ? '' : '<i class="fa-solid fa-circle" style="font-size: 6px; color: #ffd700; vertical-align: middle; margin-right: 5px;"></i>'}
                                ${notif.title || 'Bildirim'}
                            </div>
                            <div style="font-size: 0.8rem; color: #94a3b8; line-height: 1.4;">${notif.message}</div>
                            <div style="font-size: 0.7rem; color: #64748b; margin-top: 4px; text-align: right;">${this.timeAgo(notif.timestamp)}</div>
                        </li>
                    `;
                }).join('');

                list.innerHTML += '<li style="text-align: center; padding: 10px; background: rgba(0,0,0,0.2);"><a href="#" onclick="Social.showSocialModal(); Social.switchTab(\'notifications\'); return false;" style="font-size: 0.8rem; color: var(--accent-color);">Tümünü Gör</a></li>';
            }
        }
    },

    handleNotificationClick(notifId) {
        // Find notification
        const notifications = State.currentUser.notifications || [];
        const notif = notifications.find(n => n.id === notifId);
        if (notif && !notif.read) {
            notif.read = true;
            this.saveUserData();
            this.updateNavbarUI();
        }
        // If it has a link or action, trigger it here
        // For now, just open the full modal to see details if generic
        Social.showSocialModal();
        Social.switchTab('notifications');
    },

    saveUserData() {
        if (window.db && window.db.updateUser) {
            window.db.updateUser(State.currentUser.id, State.currentUser); // Helper if exists
        } else if (window.db && window.db.saveUser) {
            window.db.saveUser(State.currentUser);
        } else {
            db.save();
        }
    },

    markNotificationAsRead(index) {
        // Since we reversed the array validation for display, we need to find the actual index
        const notifications = State.currentUser.notifications;
        if (!notifications) return;

        // The index passed is from reversed array. 
        // Real Index = Length - 1 - DisplayIndex
        const realIndex = notifications.length - 1 - index;

        if (notifications[realIndex]) {
            notifications[realIndex].read = true;
            this.saveUserData();

            this.renderNotifications();
            // Update badge in modal tab
            const badge = document.querySelector('#tab-btn-notifications .badge');
            if (badge) {
                const count = this.getNotificationCount();
                badge.textContent = count;
                if (count === 0) badge.remove();
            }
        }
    },

    addNotification(userId, title, message) {
        // Ensure data is loaded
        if (!State.data.users) return;

        const user = State.data.users.find(u => u.id === userId);
        if (!user) return;

        if (!user.notifications) user.notifications = [];

        user.notifications.push({
            id: 'notif-' + Date.now() + Math.random().toString(36).substr(2, 5),
            title: title,
            message: message,
            timestamp: Date.now(),
            read: false
        });

        if (window.db && window.db.saveUser) window.db.saveUser(user);
        else if (window.db && window.db.save) window.db.save();

        // If it's for current user, update UI immediately
        if (State.currentUser && userId === State.currentUser.id) {
            this.updateNavbarUI();
            Toast.info(`🔔 Yeni Bildirim: ${title}`);
        }
    },

    renderFriendRequests() {
        const container = document.getElementById('social-requests-list');
        if (!container) return;

        const requests = State.data.friendRequests || [];
        const myRequests = requests.filter(r => r.to === State.currentUser.id && r.status === 'pending');

        if (myRequests.length === 0) {
            container.innerHTML = '<p style="text-align:center; color:var(--text-secondary); margin-top:20px;">Gelen istek yok.</p>';
            return;
        }

        container.innerHTML = myRequests.map(req => {
            const sender = State.data.users.find(u => u.id === req.from);
            if (!sender) return '';

            return `
                <div style="display:flex; align-items:center; justify-content:space-between; padding:10px; background:var(--bg-secondary); border-radius:8px; margin-bottom:10px;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <img src="${sender.avatar || 'https://via.placeholder.com/40'}" style="width:40px; height:40px; border-radius:50%; object-fit:cover;">
                        <div>
                            <div style="font-weight:600;">${sender.username}</div>
                            <div style="font-size:0.8rem; color:var(--text-secondary);">${this.timeAgo(req.timestamp)}</div>
                        </div>
                    </div>
                    <div style="display:flex; gap:5px;">
                        <button class="btn btn-sm btn-success" onclick="Social.acceptFriendRequest('${req.from}')"><i class="fa-solid fa-check"></i></button>
                        <button class="btn btn-sm btn-danger" onclick="Social.rejectFriendRequest('${req.from}')"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                </div>
            `;
        }).join('');
    },

    async acceptFriendRequest(senderId) {
        try {
            const user = State.currentUser;
            const sender = State.data.users.find(u => u.id === senderId);
            if (!sender) return;

            if (!user.friends) user.friends = [];
            if (!sender.friends) sender.friends = [];

            if (!user.friends.includes(senderId)) user.friends.push(senderId);
            if (!sender.friends.includes(user.id)) sender.friends.push(user.id);

            // Remove all related requests
            State.data.friendRequests = (State.data.friendRequests || []).filter(r =>
                !((r.from === senderId && r.to === user.id) || (r.from === user.id && r.to === senderId))
            );
            
            // Clean local sync arrays
            user.friendRequestsSent = (user.friendRequestsSent || []).filter(id => id !== senderId);
            sender.friendRequestsSent = (sender.friendRequestsSent || []).filter(id => id !== user.id);

            await db.save();
            Toast.success(`${sender.username} ile artık arkadaşsınız! ✨`);
            
            this.addNotification(senderId, 'İstek Kabul Edildi', `${user.username} arkadaşlık isteğini kabul etti.`);
            this.getFriends();
            
            if (window.UserProfile) UserProfile.show(UserProfile.currentUserId);
            if (document.querySelector('.social-modal-premium')) {
                this.getFriends();
                this.switchTab('friends'); 
            }
        } catch (error) {
            console.error('Accept error:', error);
            Toast.error("Beklenmedik bir hata oluştu.");
        }
    },

    async removeFriend(friendId) {
        if (!confirm('Arkadaşlıktan çıkarmak istediğinize emin misiniz?')) return;
        
        try {
            const user = State.currentUser;
            const friend = State.data.users.find(u => u.id === friendId);
            
            user.friends = (user.friends || []).filter(id => id !== friendId);
            if (friend) {
                friend.friends = (friend.friends || []).filter(id => id !== user.id);
            }

            await db.save();
            Toast.info("Arkadaşlıktan çıkarıldı.");
            this.getFriends();
            
            if (window.UserProfile) UserProfile.show(UserProfile.currentUserId);
            if (document.querySelector('.social-modal-premium')) {
                this.getFriends();
                this.switchTab('friends');
            }
        } catch (e) {
            console.error('Remove friend error:', e);
        }
    },

    async rejectFriendRequest(senderId) {
        try {
            // Remove request
            State.data.friendRequests = (State.data.friendRequests || []).filter(r =>
                !(r.from === senderId && r.to === State.currentUser.id)
            );

            if (window.db && window.db.save) window.db.save();

            Toast.info("İstek reddedildi.");
            this.renderFriendRequests(); // Refresh list

        } catch (error) {
            console.error('Reject request error:', error);
        }
    },

    timeAgo(timestamp) {
        const seconds = Math.floor((Date.now() - timestamp) / 1000);
        if (seconds < 60) return 'Az önce';
        if (seconds < 3600) return Math.floor(seconds / 60) + ' dk önce';
        if (seconds < 86400) return Math.floor(seconds / 3600) + ' saat önce';
        return Math.floor(seconds / 86400) + ' gün önce';
    },

    openChat(userId) {
        const user = State.data.users.find(u => u.id === userId);
        document.querySelector('.social-content').classList.remove('show-mobile');
    }
};


// Track activities - safely wrap existing functions
if (typeof Comments !== 'undefined' && Comments.addComment) {
    const originalAddComment = Comments.addComment;
    Comments.addComment = function () {
        originalAddComment.call(this);
        ActivityFeed.log('comment', { seriesId: State.currentSeries?.id });
    };
}

if (typeof Rating !== 'undefined' && Rating.submitRating) {
    const originalSubmitRating = Rating.submitRating;
    Rating.submitRating = function () {
        originalSubmitRating.call(this);
        ActivityFeed.log('rate', { seriesId: State.currentSeries?.id });
    };
}

console.log('✅ Social & Comments Expansion Loaded!');

window.Social = Social;
window.RealTimeSocial = RealTimeSocial;
window.ActivityFeed = ActivityFeed;
window.AdvancedComments = AdvancedComments;
window.UserProfiles = UserProfiles;
