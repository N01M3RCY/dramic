/**
 * Donation System - "Kahve Ismarla"
 * Allows users to gift coins to creators (Translators/Bloggers)
 */

window.DonationSystem = {
    // Translator pool - shared coin pool for all translators
    TRANSLATOR_POOL_ID: 'translator-pool',

    openModal(creatorId, creatorName) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.error('Bağış yapmak için giriş yapmalısınız.');
            return;
        }

        // If donating to a translator, redirect to translator pool
        const targetId = creatorId === 'translator' ? this.TRANSLATOR_POOL_ID : creatorId;
        const displayName = creatorId === 'translator' ? 'Çevirmen Havuzu' : creatorName;

        const modalHtml = `
            <div class="donation-modal-overlay" id="donation-modal">
                <div class="donation-modal-content premium-glow">
                    <button class="close-don-modal" onclick="DonationSystem.closeModal()">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                    
                    <div class="don-header">
                        <div class="don-icon-animated">
                            <i class="fa-solid fa-mug-hot"></i>
                        </div>
                        <h2>${displayName}'a Kahve Ismarla</h2>
                        <p>Desteğin üreticimizi motive eder!</p>
                    </div>

                    <div class="don-amounts">
                        <div class="don-option" onclick="DonationSystem.selectAmount(10, this)">
                            <span class="don-mug">☕</span>
                            <span class="don-val">10 Coin</span>
                            <span class="don-label">1 Kahve</span>
                        </div>
                        <div class="don-option" onclick="DonationSystem.selectAmount(50, this)">
                            <span class="don-mug">☕☕☕</span>
                            <span class="don-val">50 Coin</span>
                            <span class="don-label">5 Kahve</span>
                        </div>
                        <div class="don-option active" onclick="DonationSystem.selectAmount(100, this)">
                            <span class="don-mug">☕☕☕☕☕</span>
                            <span class="don-val">100 Coin</span>
                            <span class="don-label">10 Kahve</span>
                        </div>
                    </div>

                    <div class="don-message-area">
                        <textarea id="don-personal-note" placeholder="Bir teşekkür mesajı bırakmak ister misin? (Opsiyonel)"></textarea>
                    </div>

                    <div class="don-footer">
                        <button class="btn-donate-confirm" onclick="DonationSystem.process('${targetId}')">
                            Bağışı Gönder
                        </button>
                        <p class="don-balance-info">Mevcut Bakiyen: <strong>${State.currentUser.stats?.coins || 0} Coin</strong></p>
                    </div>
                </div>
            </div>

            <style>
                .donation-modal-overlay {
                    position: fixed;
                    inset: 0;
                    background: rgba(0, 0, 0, 0.85);
                    backdrop-filter: blur(8px);
                    z-index: 10000;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    animation: fadeIn 0.3s ease;
                }
                .donation-modal-content {
                    background: #0f172a;
                    width: 100%;
                    max-width: 450px;
                    border-radius: 24px;
                    padding: 40px;
                    position: relative;
                    border: 1px solid rgba(139, 92, 246, 0.3);
                    text-align: center;
                    box-shadow: 0 0 40px rgba(139, 92, 246, 0.2);
                }
                .don-header h2 { margin-top: 20px; color: #fff; }
                .don-header p { color: #94a3b8; font-size: 14px; margin-bottom: 30px; }
                
                .don-icon-animated {
                    font-size: 3rem;
                    color: #ffd700;
                    animation: floatCoffee 3s ease-in-out infinite;
                }
                @keyframes floatCoffee {
                    0%, 100% { transform: translateY(0) rotate(0); }
                    50% { transform: translateY(-10px) rotate(5deg); }
                }

                .don-amounts {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 12px;
                    margin-bottom: 24px;
                }
                .don-option {
                    background: rgba(255, 255, 255, 0.05);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                    border-radius: 16px;
                    padding: 15px;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    display: flex;
                    flex-direction: column;
                    gap: 5px;
                }
                .don-option:hover { background: rgba(139, 92, 246, 0.1); transform: translateY(-3px); }
                .don-option.active {
                    background: rgba(139, 92, 246, 0.2);
                    border-color: #8b5cf6;
                    box-shadow: 0 0 15px rgba(139, 92, 246, 0.3);
                }
                .don-mug { font-size: 1.2rem; }
                .don-val { font-weight: 800; color: #fff; font-size: 14px; }
                .don-label { font-size: 11px; color: #94a3b8; }

                #don-personal-note {
                    width: 100%;
                    background: rgba(0, 0, 0, 0.3);
                    border: 1px solid rgba(255, 255, 255, 0.1);
                    border-radius: 12px;
                    padding: 12px;
                    color: #fff;
                    font-size: 14px;
                    height: 80px;
                    resize: none;
                    margin-bottom: 24px;
                }
                .btn-donate-confirm {
                    width: 100%;
                    background: linear-gradient(135deg, #8b5cf6, #d946ef);
                    color: #fff;
                    border: none;
                    border-radius: 12px;
                    padding: 16px;
                    font-weight: 700;
                    font-size: 16px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                .btn-donate-confirm:hover { transform: scale(1.02); filter: brightness(1.1); }
                .don-balance-info { margin-top: 15px; font-size: 13px; color: #94a3b8; }
                .close-don-modal {
                    position: absolute;
                    right: 20px;
                    top: 20px;
                    background: none;
                    border: none;
                    color: #64748b;
                    font-size: 20px;
                    cursor: pointer;
                    transition: color 0.2s;
                }
                .close-don-modal:hover { color: #fff; }
            </style>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHtml);
        this.selectedAmount = 100;
    },

    selectAmount(amt, el) {
        this.selectedAmount = amt;
        document.querySelectorAll('.don-option').forEach(opt => opt.classList.remove('active'));
        el.classList.add('active');
    },

    closeModal() {
        const modal = document.getElementById('donation-modal');
        if (modal) modal.remove();
        this.currentPostId = null;
    },

    openPostTipModal(postId, creatorName) {
        this.currentPostId = postId;
        const post = (State.data.socialPosts || []).find(p => p.id === postId);
        if (!post) return;
        this.openModal(post.userId, creatorName);
    },

    async process(creatorId) {
        const note = document.getElementById('don-personal-note').value;
        const btn = document.querySelector('.btn-donate-confirm');

        btn.disabled = true;
        btn.innerText = 'İşleniyor...';

        const postId = this.currentPostId;

        // Check if user has enough coins
        const userCoins = State.currentUser?.stats?.coins || 0;
        if (userCoins < this.selectedAmount) {
            Toast.error(`Yetersiz bakiye! ${this.selectedAmount} coin gerekiyor, ${userCoins} coin var.`);
            btn.disabled = false;
            btn.innerText = 'Bağışı Gönder';
            return;
        }

        try {
            const response = await fetch(`${Config.apiUrl}?action=donate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    creatorId: creatorId,
                    amount: this.selectedAmount,
                    note: note,
                    postId: postId
                })
            });

            const result = await response.json();
            if (result.success) {
                Toast.success('Harikasın! Bağışın iletildi ☕');

                // Track donation locally
                this.trackDonation(creatorId, this.selectedAmount, note);

                // Update user balance
                if (State.currentUser && State.currentUser.stats) {
                    State.currentUser.stats.coins = result.newBalance;
                }

                const coinDisplay = document.querySelector('.user-coins span');
                if (coinDisplay) coinDisplay.innerText = result.newBalance;

                this.closeModal();

                // Celebration effect
                if (window.confetti) {
                    confetti({
                        particleCount: 100,
                        spread: 70,
                        origin: { y: 0.6 }
                    });
                }
            } else {
                Toast.error(result.message || 'Bağış başarısız oldu.');
                btn.disabled = false;
                btn.innerText = 'Bağışı Gönder';
            }
        } catch (error) {
            console.warn('API donation failed, processing locally:', error);

            // Local fallback - process donation without backend
            if (State.currentUser && State.currentUser.stats) {
                State.currentUser.stats.coins -= this.selectedAmount;
                const newBalance = State.currentUser.stats.coins;

                // Update in State.data.users
                const userIdx = State.data.users.findIndex(u => u.id === State.currentUser.id);
                if (userIdx > -1) {
                    State.data.users[userIdx].stats = State.data.users[userIdx].stats || {};
                    State.data.users[userIdx].stats.coins = newBalance;
                }

                // Track donation
                this.trackDonation(creatorId, this.selectedAmount, note, postId);

                // Save to database
                if (window.db && db.save) db.save();

                // Update session storage
                sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));

                // Update UI
                const coinDisplay = document.querySelector('.user-coins span');
                if (coinDisplay) coinDisplay.innerText = newBalance;

                Toast.success('Harikasın! Bağışın iletildi ☕');
                this.closeModal();

                // Celebration effect
                if (window.confetti) {
                    confetti({
                        particleCount: 100,
                        spread: 70,
                        origin: { y: 0.6 }
                    });
                }
            } else {
                Toast.error('Bir hata oluştu. Lütfen giriş yapın.');
                btn.disabled = false;
                btn.innerText = 'Bağışı Gönder';
            }
        }
    },

    // Track donation with series/translator info
    trackDonation(creatorId, amount, note, postId = null) {
        if (!State.data) return;
        if (!State.data.donations) State.data.donations = [];
        if (!State.data.translatorPool) State.data.translatorPool = { balance: 0, history: [] };

        const donation = {
            id: 'don-' + Date.now(),
            fromUserId: State.currentUser?.id,
            fromUsername: State.currentUser?.username,
            toCreatorId: creatorId,
            amount: amount,
            note: note,
            seriesId: this.currentSeriesId || null,
            seriesTitle: this.currentSeriesTitle || null,
            postId: postId,
            timestamp: Date.now()
        };

        State.data.donations.push(donation);

        // If it's a post tip, credit the post
        if (postId) {
            const post = (State.data.socialPosts || []).find(p => p.id === postId);
            if (post) {
                post.tips = (post.tips || 0) + amount;

                // Also give social XP to the sender
                if (typeof SocialFeed !== 'undefined' && SocialFeed.awardSocialXP) {
                    SocialFeed.awardSocialXP(Math.floor(amount / 5), 'tip');
                }
            }
        }

        // If going to translator pool, add 50% to pool
        if (creatorId === this.TRANSLATOR_POOL_ID) {
            const poolShare = Math.floor(amount * 0.5);
            State.data.translatorPool.balance += poolShare;
            State.data.translatorPool.history.push({
                type: 'deposit',
                amount: poolShare,
                fromDonation: donation.id,
                timestamp: Date.now()
            });
        }

        // Create log entry for admin panel
        if (!State.data.logs) State.data.logs = [];
        State.data.logs.unshift({
            type: 'bağış',
            user: State.currentUser.username,
            action: `${amount} Coin bağışladı → ${creatorId}`,
            target: donation.seriesTitle || creatorId,
            timestamp: new Date().toISOString()
        });

        // Save to backend
        if (window.db && db.save) db.save();
        else if (window.db && db.saveData) db.saveData(State.data);
    },

    // Open modal with series context
    openForSeries(seriesId, translatorName = 'Çevirmen') {
        const series = State.data?.series?.find(s => s.id === seriesId);
        this.currentSeriesId = seriesId;
        this.currentSeriesTitle = series?.title || 'Bilinmeyen Dizi';
        this.openModal('translator', translatorName);
    },

    // Admin: Get donation statistics
    getStats() {
        const donations = State.data?.donations || [];
        const pool = State.data?.translatorPool || { balance: 0 };

        const totalDonations = donations.reduce((sum, d) => sum + d.amount, 0);
        const uniqueDonors = [...new Set(donations.map(d => d.fromUserId))].length;
        const byCreator = {};

        donations.forEach(d => {
            if (!byCreator[d.toCreatorId]) byCreator[d.toCreatorId] = 0;
            byCreator[d.toCreatorId] += d.amount;
        });

        return {
            totalDonations,
            uniqueDonors,
            donationCount: donations.length,
            poolBalance: pool.balance,
            byCreator
        };
    },

    // Admin: Render donation management panel
    renderAdminPanel(container) {
        const stats = this.getStats();
        // Separate donations
        const allDonations = (State.data?.donations || []).slice().reverse();
        const translatorDonations = allDonations.filter(d => d.toCreatorId === this.TRANSLATOR_POOL_ID || d.toCreatorId === 'translator');
        const blogDonations = allDonations.filter(d => d.toCreatorId !== this.TRANSLATOR_POOL_ID && d.toCreatorId !== 'translator');

        container.innerHTML = `
            <div style="padding: 20px;">
                <h2 style="margin-bottom: 25px;">Bağış Yönetimi</h2>
                
                <!-- Donation Tabs -->
                <div class="admin-tabs" style="display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 1px solid var(--border-color);">
                    <button class="tab-btn active" onclick="DonationSystem.switchTab('translator', this)">Çevirmen Bağışları</button>
                    <button class="tab-btn" onclick="DonationSystem.switchTab('blog', this)">Blog/Yazar Bağışları</button>
                </div>

                <!-- Translator Content -->
                <div id="don-tab-translator" class="don-tab-content">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 30px;">
                        <div style="background: linear-gradient(135deg, #10b981, #059669); padding: 20px; border-radius: 12px;">
                            <div style="font-size: 0.85rem; opacity: 0.8;">Havuz Bakiyesi</div>
                            <div style="font-size: 1.8rem; font-weight: 700; margin-top: 5px;">${stats.poolBalance}</div>
                        </div>
                        <div style="background: linear-gradient(135deg, #3b82f6, #2563eb); padding: 20px; border-radius: 12px;">
                            <div style="font-size: 0.85rem; opacity: 0.8;">Toplam Bağış</div>
                            <div style="font-size: 1.8rem; font-weight: 700; margin-top: 5px;">${translatorDonations.reduce((sum, d) => sum + d.amount, 0)}</div>
                        </div>
                    </div>
                    ${this.renderDonationList(translatorDonations, 'Çevirmen Havuzu için henüz bağış yok.')}
                </div>

                <!-- Blog Content -->
                <div id="don-tab-blog" class="don-tab-content" style="display: none;">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 30px;">
                        <div style="background: linear-gradient(135deg, #f59e0b, #d97706); padding: 20px; border-radius: 12px;">
                            <div style="font-size: 0.85rem; opacity: 0.8;">Yazarlara Destek</div>
                            <div style="font-size: 1.8rem; font-weight: 700; margin-top: 5px;">${blogDonations.reduce((sum, d) => sum + d.amount, 0)}</div>
                        </div>
                         <div style="background: linear-gradient(135deg, #ec4899, #be185d); padding: 20px; border-radius: 12px;">
                            <div style="font-size: 0.85rem; opacity: 0.8;">Bağış Alan Yazar</div>
                            <div style="font-size: 1.8rem; font-weight: 700; margin-top: 5px;">${new Set(blogDonations.map(d => d.toCreatorId)).size}</div>
                        </div>
                    </div>
                    ${this.renderDonationList(blogDonations, 'Yazarlar için henüz bağış yok.')}
                </div>
            </div>
        `;
    },

    renderDonationList(list, emptyMsg) {
        return `
            <div style="background: rgba(0,0,0,0.3); border-radius: 12px; overflow: hidden; max-height: 500px; overflow-y: auto;">
                ${list.length > 0 ? list.map(d => `
                    <div style="padding: 15px 20px; border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <div style="font-weight: 600;">${d.fromUsername || 'Anonim'} → <span style="color: #a78bfa;">${d.toCreatorId === this.TRANSLATOR_POOL_ID ? 'Çevirmen Havuzu' : d.toCreatorId}</span></div>
                            <div style="font-size: 0.8rem; color: #888; margin-top: 3px;">
                                ${d.seriesTitle ? `<i class="fa-solid fa-film"></i> ${d.seriesTitle} • ` : ''}
                                ${new Date(d.timestamp).toLocaleDateString('tr-TR')}
                            </div>
                            ${d.note ? `<div style="font-size: 0.85rem; color: #ccc; margin-top: 5px; font-style: italic;">"${d.note}"</div>` : ''}
                        </div>
                        <div style="background: rgba(124, 58, 237, 0.2); padding: 5px 12px; border-radius: 20px; font-weight: 600; color: #a78bfa;">
                            ${d.amount} <i class="fa-solid fa-coins"></i>
                        </div>
                    </div>
                `).join('') : `<div style="padding: 40px; text-align: center; color: #666;">${emptyMsg}</div>`}
            </div>
        `;
    },

    switchTab(tabName, btn) {
        document.querySelectorAll('.don-tab-content').forEach(el => el.style.display = 'none');
        document.getElementById(`don-tab-${tabName}`).style.display = 'block';

        if (btn) {
            btn.parentElement.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        }
    }
};
