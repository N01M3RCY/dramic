// ============================================
// DRAMICBOX - PREMIUM FEATURES MEGA MODULE
// Analytics, AI, Video, Achievements, Rewards, Blog
// ============================================

// --- ANALYTICS WITH CHART.JS ---
const Analytics = {
    charts: {},

    // Watch time line chart
    renderWatchTimeChart(canvasId) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        const history = State.currentUser?.watchHistory || [];
        const last7Days = this.getLast7Days();
        const data = last7Days.map(date => {
            return history.filter(h => {
                const hDate = new Date(h.date).toDateString();
                return hDate === date.toDateString();
            }).length;
        });

        this.charts.watchTime = new Chart(ctx, {
            type: 'line',
            data: {
                labels: last7Days.map(d => d.toLocaleDateString('tr-TR', { weekday: 'short' })),
                datasets: [{
                    label: 'İzlenen Bölümler',
                    data: data,
                    borderColor: '#5e72e4',
                    backgroundColor: 'rgba(94, 114, 228, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    },

    // Genre distribution pie chart
    renderGenreChart(canvasId) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        const watchlist = State.currentUser?.watchlist || [];
        const genres = {};

        watchlist.forEach(sid => {
            const series = db.getSeries(sid);
            if (series && series.genre) {
                genres[series.genre] = (genres[series.genre] || 0) + 1;
            }
        });

        this.charts.genre = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(genres),
                datasets: [{
                    data: Object.values(genres),
                    backgroundColor: [
                        '#5e72e4', '#825ee4', '#10b981', '#f59e0b',
                        '#ef4444', '#ec4899', '#8b5cf6', '#06b6d4'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    },

    // Weekly activity bar chart
    renderWeeklyActivityChart(canvasId) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        const history = State.currentUser?.watchHistory || [];
        const weekDays = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
        const data = weekDays.map((_, index) => {
            return history.filter(h => new Date(h.date).getDay() === index).length;
        });

        this.charts.weekly = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: weekDays,
                datasets: [{
                    label: 'İzleme Sayısı',
                    data: data,
                    backgroundColor: 'rgba(94, 114, 228, 0.8)'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                }
            }
        });
    },

    // GitHub-style heatmap (simplified)
    renderYearlyHeatmap(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const history = State.currentUser?.watchHistory || [];
        const last365Days = this.getLast365Days();

        let html = '<div class="heatmap-grid">';
        last365Days.forEach(date => {
            const count = history.filter(h => {
                const hDate = new Date(h.date).toDateString();
                return hDate === date.toDateString();
            }).length;

            const level = count === 0 ? 0 : count <= 2 ? 1 : count <= 5 ? 2 : count <= 8 ? 3 : 4;
            html += `<div class="heatmap-cell level-${level}" title="${date.toLocaleDateString('tr-TR')}: ${count} bölüm"></div>`;
        });
        html += '</div>';

        container.innerHTML = html;
    },

    getLast7Days() {
        const days = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            days.push(date);
        }
        return days;
    },

    getLast365Days() {
        const days = [];
        for (let i = 364; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            days.push(date);
        }
        return days;
    },

    // User statistics
    getUserStats() {
        const history = State.currentUser?.watchHistory || [];

        // Most watched hours
        const hours = {};
        history.forEach(h => {
            const hour = new Date(h.date).getHours();
            hours[hour] = (hours[hour] || 0) + 1;
        });
        const mostWatchedHour = Object.keys(hours).reduce((a, b) => hours[a] > hours[b] ? a : b, 0);

        // Favorite days
        const days = {};
        history.forEach(h => {
            const day = new Date(h.date).getDay();
            days[day] = (days[day] || 0) + 1;
        });
        const favDay = Object.keys(days).reduce((a, b) => days[a] > days[b] ? a : b, 0);
        const dayNames = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];

        // Watch speed (episodes per day)
        const totalDays = Math.max(1, Math.floor((Date.now() - new Date(history[0]?.date || Date.now()).getTime()) / (1000 * 60 * 60 * 24)));
        const watchSpeed = (history.length / totalDays).toFixed(2);

        return {
            mostWatchedHour: `${mostWatchedHour}:00`,
            favoriteDay: dayNames[favDay],
            watchSpeed: watchSpeed
        };
    }
};

// --- AI RECOMMENDATION SYSTEM ---
const AIRecommendations = {
    // Content-based filtering
    getRecommendations(limit = 6) {
        if (!State.currentUser) return [];

        const watchlist = State.currentUser.watchlist || [];
        const watchHistory = State.currentUser.watchHistory || [];

        // Get user's favorite genres
        const genreScores = {};
        watchlist.forEach(sid => {
            const series = db.getSeries(sid);
            if (series && series.genre) {
                genreScores[series.genre] = (genreScores[series.genre] || 0) + 1;
            }
        });

        // Get unwatched series
        const unwatched = State.data.series.filter(s => !watchlist.includes(s.id));

        // Score based on genre match
        const scored = unwatched.map(series => {
            let score = genreScores[series.genre] || 0;

            // Boost if friends watched it
            const friends = Social.getFriends();
            friends.forEach(friend => {
                if (friend.watchlist?.includes(series.id)) {
                    score += 2;
                }
            });

            // Boost if highly rated
            if (series.ratings && series.ratings.length > 0) {
                const avgRating = series.ratings.reduce((sum, r) => sum + r.rating, 0) / series.ratings.length;
                score += avgRating / 2;
            }

            return { series, score };
        });

        // Sort by score and return top results
        return scored
            .sort((a, b) => b.score - a.score)
            .slice(0, limit)
            .map(item => item.series);
    },

    // Collaborative filtering (simplified)
    getSimilarUserRecommendations(limit = 6) {
        if (!State.currentUser) return [];

        const myWatchlist = State.currentUser.watchlist || [];
        const similarUsers = State.data.users
            .filter(u => u.id !== State.currentUser.id)
            .map(user => {
                const theirWatchlist = user.watchlist || [];
                const commonCount = myWatchlist.filter(id => theirWatchlist.includes(id)).length;
                return { user, similarity: commonCount };
            })
            .filter(item => item.similarity > 0)
            .sort((a, b) => b.similarity - a.similarity)
            .slice(0, 5);

        const recommendations = new Set();
        similarUsers.forEach(({ user }) => {
            const theirWatchlist = user.watchlist || [];
            theirWatchlist.forEach(sid => {
                if (!myWatchlist.includes(sid)) {
                    recommendations.add(sid);
                }
            });
        });

        return Array.from(recommendations)
            .slice(0, limit)
            .map(id => db.getSeries(id))
            .filter(s => s);
    },

    // Trending analysis
    getTrending(limit = 10) {
        const last7Days = new Date();
        last7Days.setDate(last7Days.getDate() - 7);

        // Count recent views
        const viewCounts = {};
        State.data.users.forEach(user => {
            const recentHistory = (user.watchHistory || []).filter(h => new Date(h.date) > last7Days);
            recentHistory.forEach(h => {
                viewCounts[h.seriesId] = (viewCounts[h.seriesId] || 0) + 1;
            });
        });

        return Object.entries(viewCounts)
            .sort((a, b) => b[1] - a[1])
            .slice(0, limit)
            .map(([sid]) => db.getSeries(sid))
            .filter(s => s);
    }
};

// --- ADVANCED VIDEO CONTROLS ---
const AdvancedVideoControls = {
    playbackRate: 1,
    quality: '1080p',
    isPiP: false,

    // Playback speed control
    setPlaybackSpeed(speed) {
        this.playbackRate = speed;
        const iframe = document.querySelector('#player-frame iframe');
        // VK player API would handle this
        Toast.info(`⚡ Hız: ${speed}x`);
        localStorage.setItem('playback_speed', speed);
    },

    // Quality selection
    setQuality(quality) {
        this.quality = quality;
        Toast.info(`🎬 Kalite: ${quality}`);
        localStorage.setItem('video_quality', quality);
    },

    // Picture-in-Picture
    togglePiP() {
        const video = document.querySelector('#player-frame iframe');
        if (!video) return;

        if (!this.isPiP && document.pictureInPictureEnabled) {
            video.requestPictureInPicture();
            this.isPiP = true;
            Toast.success("📺 PiP Modu Aktif");
        } else if (document.pictureInPictureElement) {
            document.exitPictureInPicture();
            this.isPiP = false;
            Toast.info("📺 PiP Modu Kapatıldı");
        }
    },

    // Intro/Outro skip
    skipIntro() {
        Toast.info("⏭️ İntro atlandı");
        // Skip 90 seconds
        EnhancedPlayer.skip(90);
    },

    skipOutro() {
        Toast.info("⏭️ Outro atlandı");
        // Play next episode
        EnhancedPlayer.playNext();
    }
};

// --- EXPANDED ACHIEVEMENTS (50+) ---
const ExpandedAchievements = {
    achievements: [
        // Watching achievements
        { id: 'first_watch', name: 'İlk İzleme', desc: 'İlk diziyi izle', icon: '🎬', xp: 10 },
        { id: 'binge_10', name: 'Maraton Başlangıcı', desc: '10 bölüm arka arkaya', icon: '📺', xp: 50 },
        { id: 'binge_50', name: 'Maraton Kralı', desc: '50 bölüm arka arkaya', icon: '👑', xp: 200 },
        { id: 'night_owl', name: 'Gece Kuşu', desc: 'Gece 2\'den sonra izle', icon: '🦉', xp: 30 },
        { id: 'early_bird', name: 'Erken Kuş', desc: 'Sabah 6\'dan önce izle', icon: '🌅', xp: 30 },
        { id: 'weekend_warrior', name: 'Hafta Sonu Savaşçısı', desc: 'Hafta sonu 20 bölüm izle', icon: '⚔️', xp: 100 },

        // Social achievements
        { id: 'social_10', name: 'Sosyal Başlangıç', desc: '10 arkadaş ekle', icon: '👥', xp: 50 },
        { id: 'social_50', name: 'Sosyal Kelebek', desc: '50 arkadaş ekle', icon: '🦋', xp: 200 },
        { id: 'popular', name: 'Popüler', desc: '100 takipçi', icon: '⭐', xp: 300 },

        // Comment achievements
        { id: 'comment_10', name: 'Yorumcu', desc: '10 yorum yap', icon: '💬', xp: 30 },
        { id: 'comment_100', name: 'Eleştirmen', desc: '100 yorum yap', icon: '✍️', xp: 200 },
        { id: 'comment_1000', name: 'Yorum Efsanesi', desc: '1000 yorum yap', icon: '🏆', xp: 1000 },

        // Collection achievements
        { id: 'collector_20', name: 'Koleksiyoncu', desc: '20 dizi listede', icon: '📚', xp: 50 },
        { id: 'collector_100', name: 'Mega Koleksiyoncu', desc: '100 dizi listede', icon: '📚', xp: 300 },
        { id: 'completionist', name: 'Tamamlayıcı', desc: '50 diziyi bitir', icon: '✅', xp: 500 },

        // Rating achievements
        { id: 'rater_10', name: 'Puanlayıcı', desc: '10 dizi puanla', icon: '⭐', xp: 20 },
        { id: 'rater_100', name: 'Kritik', desc: '100 dizi puanla', icon: '🌟', xp: 150 },

        // Special achievements
        { id: 'first_day', name: 'İlk Gün', desc: 'İlk gün kaydol', icon: '🎉', xp: 10 },
        { id: 'streak_7', name: '7 Gün Streak', desc: '7 gün üst üste giriş', icon: '🔥', xp: 70 },
        { id: 'streak_30', name: '30 Gün Streak', desc: '30 gün üst üste giriş', icon: '🔥', xp: 300 },
        { id: 'level_10', name: 'Seviye 10', desc: 'Seviye 10\'a ulaş', icon: '🎮', xp: 100 },
        { id: 'level_50', name: 'Seviye 50', desc: 'Seviye 50\'ye ulaş', icon: '🎮', xp: 500 },

        // Genre achievements
        { id: 'romance_fan', name: 'Romantik Hayranı', desc: '20 romantik dizi izle', icon: '💕', xp: 100 },
        { id: 'action_fan', name: 'Aksiyon Tutkunu', desc: '20 aksiyon dizisi izle', icon: '💥', xp: 100 },
        { id: 'comedy_fan', name: 'Komedi Sever', desc: '20 komedi izle', icon: '😂', xp: 100 },

        // Time-based
        { id: 'speed_demon', name: 'Hız Canavarı', desc: 'Günde 10 bölüm izle', icon: '⚡', xp: 100 },
        { id: 'patient', name: 'Sabırlı', desc: 'Bir diziyi 30 günde bitir', icon: '🐢', xp: 50 },

        // Rare achievements
        { id: 'first_comment', name: 'İlk Yorum', desc: 'Bir diziye ilk yorum yapan ol', icon: '🥇', xp: 50 },
        { id: 'trendsetter', name: 'Trend Belirleyici', desc: 'Kimsenin izlemediği bir diziyi keşfet', icon: '🔮', xp: 100 },
        { id: 'loyal_fan', name: 'Sadık Hayran', desc: 'Bir diziyi 3 kez izle', icon: '❤️', xp: 150 }
    ],

    checkAchievement(id) {
        const achievement = this.achievements.find(a => a.id === id);
        if (!achievement) return false;

        if (!State.currentUser.achievements) State.currentUser.achievements = [];

        if (!State.currentUser.achievements.includes(id)) {
            State.currentUser.achievements.push(id);
            db.updateUser(State.currentUser.id, { achievements: State.currentUser.achievements });
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));

            Toast.success(`🏆 Başarım Kazanıldı: ${achievement.name}!`);
            Gamification.addXP(achievement.xp, achievement.name);
            return true;
        }
        return false;
    },

    checkAllAchievements() {
        const stats = Statistics.getStats();
        const history = State.currentUser?.watchHistory || [];
        const watchlist = State.currentUser?.watchlist || [];

        // Check various conditions
        if (stats.totalEpisodes >= 1) this.checkAchievement('first_watch');
        if (stats.totalEpisodes >= 10) this.checkAchievement('binge_10');
        if (stats.totalEpisodes >= 50) this.checkAchievement('binge_50');
        if (watchlist.length >= 20) this.checkAchievement('collector_20');
        if (watchlist.length >= 100) this.checkAchievement('collector_100');

        // Check time-based
        const now = new Date();
        const lateNightWatch = history.some(h => new Date(h.date).getHours() >= 2 && new Date(h.date).getHours() <= 6);
        if (lateNightWatch) this.checkAchievement('night_owl');
    }
};

// --- REWARD STORE (DramicShop) ---
const RewardStore = {
    items: [
        { id: 'premium_7d', name: '7 Gün Premium', price: 500, type: 'status', icon: '💎', desc: 'Reklamsız deneyim ve özel rozet.' },
        { id: 'premium_30d', name: '30 Gün Premium', price: 1500, type: 'status', icon: '👑', desc: 'Tüm özellikler açık ve altın profil.' },
        { id: 'badge_legend', name: 'Efsane Rozeti', price: 1000, type: 'badge', icon: '🌟', desc: 'Profilinde parlayan efsane rozeti.' },
        { id: 'theme_cyber', name: 'Cyberpunk Tema', price: 300, type: 'theme', icon: '🌆', desc: 'Neon ışıklı özel site teması.' },
        { id: 'xp_boost_2x', name: '2x XP (24 Saat)', price: 250, type: 'boost', icon: '⚡', desc: 'Seviye atlamanı hızlandırır.' },
        { id: 'card_pack_rare', name: 'Nadir Kart Paketi', price: 400, type: 'card', icon: '🃏', desc: '3 adet nadir koleksiyon kartı.' }
    ],

    purchase(itemId) {
        if (!State.currentUser) return Toast.warning("Satın almak için giriş yapın!");

        const item = this.items.find(i => i.id === itemId);
        if (!item) return;

        const userCoins = State.currentUser.stats?.coins || 0;
        if (userCoins < item.price) {
            return Toast.error(`Yetersiz DramiCoin! Gereken: ${item.price}, Mevcut: ${userCoins}`);
        }

        if (!confirm(`${item.name} satın almak istediğinize emin misiniz? (${item.price} Coin)`)) return;

        // Deduct Coins
        State.currentUser.stats.coins -= item.price;

        // Add to inventory
        if (!State.currentUser.inventory) State.currentUser.inventory = [];
        State.currentUser.inventory.push({ id: itemId, at: Date.now() });

        // Update state and DB
        db.updateUser(State.currentUser.id, {
            stats: State.currentUser.stats,
            inventory: State.currentUser.inventory
        });

        Toast.success(`✅ ${item.name} başarıyla alındı! Keyfini çıkar.`);
        if (window.Gamification) Gamification.updateDisplay();
        this.renderInView(); // Refresh UI if open
    },

    render() {
        return `
            <div class="premium-store-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; padding: 20px;">
                ${this.items.map(item => `
                    <div class="store-item-card glass-panel" style="padding: 25px; border-radius: 24px; text-align: center; transition: 0.3s; border: 1px solid rgba(255,255,255,0.05); position: relative; overflow: hidden;">
                        <div class="item-glow" style="position: absolute; inset: 0; background: radial-gradient(circle at center, rgba(139, 92, 246, 0.1), transparent); opacity: 0; transition: 0.3s;"></div>
                        <div style="font-size: 3.5rem; margin-bottom: 15px; filter: drop-shadow(0 0 10px rgba(255,255,255,0.2));">${item.icon}</div>
                        <div style="font-weight: 800; font-size: 1.2rem; color: #fff; margin-bottom: 8px;">${item.name}</div>
                        <div style="font-size: 0.85rem; color: #94a3b8; margin-bottom: 20px; min-height: 40px;">${item.desc}</div>
                        <div style="display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 20px;">
                            <div style="color: #ffd700; font-weight: 900; font-size: 1.3rem;">${item.price}</div>
                            <div style="font-size: 0.7rem; color: #ffd700; font-weight: 700; background: rgba(255,215,0,0.1); padding: 2px 8px; border-radius: 10px;">COIN</div>
                        </div>
                        <button class="btn-premium-glow" style="width: 100%; padding: 12px; font-size: 0.9rem;" onclick="RewardStore.purchase('${item.id}')">
                            Hemen Al
                        </button>
                    </div>
                `).join('')}
            </div>
            <style>
                .store-item-card:hover { transform: translateY(-10px); border-color: var(--premium-violet); }
                .store-item-card:hover .item-glow { opacity: 1; }
            </style>
        `;
    },

    // For injecting into a specific container
    renderInView(containerId = 'store-content-area') {
        const el = document.getElementById(containerId);
        if (el) el.innerHTML = this.render();
    }
};

// --- CHARACTER FEATURES ---
const CharacterFeatures = {
    favoriteCharacter(characterId, seriesId) {
        if (!State.currentUser) {
            Toast.warning("⚠️ Favori eklemek için giriş yapmalısınız!");
            return;
        }

        if (!State.currentUser.favoriteCharacters) State.currentUser.favoriteCharacters = [];

        const index = State.currentUser.favoriteCharacters.findIndex(fc => fc.characterId === characterId);
        if (index > -1) {
            State.currentUser.favoriteCharacters.splice(index, 1);
            Toast.info("💔 Favorilerden çıkarıldı");
        } else {
            State.currentUser.favoriteCharacters.push({ characterId, seriesId });
            Toast.success("❤️ Favorilere eklendi!");
            Gamification.addXP(5, "Favori Karakter");
        }

        db.updateUser(State.currentUser.id, { favoriteCharacters: State.currentUser.favoriteCharacters });
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
    },

    voteCharacter(characterId, seriesId) {
        if (!State.currentUser) {
            Toast.warning("⚠️ Oy vermek için giriş yapmalısınız!");
            return;
        }

        const series = db.getSeries(seriesId);
        const character = series.characters?.find(c => c.id === characterId);
        if (!character) return;

        if (!character.votes) character.votes = 0;
        character.votes++;

        db.updateSeries(seriesId, { characters: series.characters });
        Toast.success("✅ Oy verildi!");
        Gamification.addXP(3, "Karakter Oylaması");
    }
};

// --- BLOG SYSTEM ---
// Only define if not already defined by blog-system.js
if (!window.BlogSystem) {
    window.BlogSystem = {
        posts: [],

        init() {
            console.log('📝 Blog System initialized');
            this.loadPosts();
        },


        canCreatePost() {
            if (!State.currentUser) return false;

            // Check if user has Blogger badge, role, or is Admin
            const badges = State.currentUser.badges || [];
            const role = State.currentUser.role;
            return role === 'admin' || role === 'blogger' || badges.includes('Blogger') || badges.includes('Yönetici') || badges.includes('Admin');
        },

        createPost(title, content, category, coverImage = null, tags = []) {
            if (!State.currentUser) {
                Toast.warning("⚠️ Blog yazmak için giriş yapmalısınız!");
                return;
            }

            if (!this.canCreatePost()) {
                Toast.error("❌ Blog yazabilmek için 'Blogger' rozetine sahip olmalısınız! Admin panelinden rozet talep edebilirsiniz.");
                return;
            }

            const post = {
                id: 'post-' + Date.now(),
                authorId: State.currentUser.id,
                authorName: State.currentUser.username,
                title: title,
                content: content,
                category: category, // 'news', 'review', 'theory', 'analysis'
                coverImage: coverImage, // New
                tags: tags,           // New
                likes: 0,
                comments: [],
                createdAt: Date.now()
            };

            this.posts.unshift(post);
            localStorage.setItem('blog_posts', JSON.stringify(this.posts));

            // Also try to save to DB if available
            if (typeof db !== 'undefined' && db.saveBlog) {
                db.saveBlog(post);
            }

            Toast.success("✅ Blog yazısı yayınlandı!");
            Gamification.addXP(50, "Blog Yazısı");
        },

        loadPosts() {
            const saved = localStorage.getItem('blog_posts');
            if (saved) {
                this.posts = JSON.parse(saved);
            }
        },

        render(category = 'all') {
            const filtered = category === 'all' ? this.posts : this.posts.filter(p => p.category === category);

            if (filtered.length === 0) {
                return '<p style="color: var(--text-secondary);">Henüz blog yazısı yok.</p>';
            }

            return filtered.map(post => `
            <div class="blog-post">
                <h3>${post.title}</h3>
                <div class="blog-meta">
                    <span>👤 ${post.authorName}</span>
                    <span>📅 ${new Date(post.createdAt).toLocaleDateString('tr-TR')}</span>
                    <span>❤️ ${post.likes}</span>
                </div>
                <p>${post.content.substring(0, 200)}...</p>
                <button class="btn btn-outline btn-sm" onclick="BlogSystem.viewPost('${post.id}')">
                    Devamını Oku
                </button>
            </div>
        `).join('');
        },

        viewPost(postId) {
            const post = this.posts.find(p => p.id === postId);
            if (!post) return;

            // Create modal for full post
            const modal = document.createElement('div');
            modal.className = 'modal';
            modal.style.display = 'flex';
            modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>${post.title}</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div style="padding: 20px;">
                    <div class="blog-meta" style="margin-bottom: 20px;">
                        <span>👤 ${post.authorName}</span>
                        <span>📅 ${new Date(post.createdAt).toLocaleDateString('tr-TR')}</span>
                        <span>❤️ ${post.likes}</span>
                    </div>
                    </div>
                </div>
            </div>
        `;
            document.body.appendChild(modal);
        }
    };
} // End of if (!window.BlogSystem)

// Initialize (only if BlogSystem was defined here)
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (window.BlogSystem && window.BlogSystem.loadPosts) {
            BlogSystem.loadPosts();
        }
        ExpandedAchievements.checkAllAchievements();
    }, 1500);
});

// Expose modules globally
window.Analytics = Analytics;
window.AIRecommendations = AIRecommendations;
window.AdvancedVideoControls = AdvancedVideoControls;
window.ExpandedAchievements = ExpandedAchievements;
window.RewardStore = RewardStore;
window.CharacterFeatures = CharacterFeatures;

console.log('✅ Premium Features Loaded: Analytics, AI, Video, Achievements, Rewards!');
