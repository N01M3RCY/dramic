/**
 * DramicBox Premium Hero Slider - High-End Cinematic Version
 */
const HeroSlider = {
    currentSlide: 0,
    interval: null,
    slides: [],

    init() {
        console.log('🎬 Hero Slider Premium Initialized');
        const user = State.currentUser;
        const isLoggedIn = user && user.role !== 'guest';
        const isVipUser = isLoggedIn && (user.role === 'admin' || user.role === 'moderator' || user.role === 'vip' || (user.vipUntil && new Date(user.vipUntil) > new Date()));

        let sourceData = [];
        if (State.data.heroSlides && State.data.heroSlides.length > 0) {
            // Validate that hero slides actually exist in series
            sourceData = State.data.heroSlides.filter(hs => State.data.series.some(s => s.id === hs.id));
        }
        
        if (sourceData.length === 0) {
            sourceData = State.data.series || [];
        }
        
        // Hero slider: gizli içerikleri çıkar, hero işaretli olanları önceliklendir, VIP filtresi uygula
        const visible = sourceData.filter(s => !s.isHidden);
        const heroMarked = visible.filter(s => s.isHeroSlider);
        const pool = heroMarked.length > 0 ? heroMarked : visible;
        this.slides = pool
            .filter(s => isVipUser || (!s.isVip && !s.isPremium))
            .sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
            .slice(0, 5);

        if (this.slides.length === 0 && sourceData.length > 0) this.slides = sourceData.slice(0, 5);

        this.render();
        this.startAutoPlay();
    },

    render() {
        const container = document.getElementById('home-hero');
        if (!container) return;

        if (this.slides.length === 0) {
            container.innerHTML = `<div style="height:300px; display:flex; align-items:center; justify-content:center; background:#07070a; border-radius:24px; color:#444;">No Content Available</div>`;
            return;
        }

        container.innerHTML = `
            <div class="hs-slider">
                ${this.slides.map((slide, i) => `
                    <div class="hs-slide ${i === 0 ? 'active' : ''}" data-index="${i}">
                        <div class="hs-bg" style="background-image: url('${slide.backdrop || slide.poster}')"></div>
                        <div class="hs-gradient-left"></div>
                        <div class="hs-gradient-bottom"></div>
                        
                        <div class="hs-content">
                            <div class="hs-info">
                                <div class="hs-badges">
                                    <span class="hs-badge">${slide.type || 'DIZI'}</span>
                                    ${slide.isVip ? '<span class="hs-badge" style="background:rgba(245,158,11,0.2); border-color:#f59e0b; color:#f59e0b;">VIP</span>' : ''}
                                </div>
                                <h1 class="hs-title">${slide.title}</h1>
                                <div class="hs-meta">
                                    <span>${slide.year || '2024'}</span>
                                    <span><i class="fa-solid fa-star"></i> ${slide.rating || '8.5'}</span>
                                    <span>${Array.isArray(slide.genres) ? slide.genres.slice(0, 2).join(' / ') : 'Dostluk'}</span>
                                </div>
                                <p class="hs-desc">${slide.description || slide.synopsis || 'Bu yapım hakkında henüz bir açıklama eklenmedi.'}</p>
                                <div class="hs-actions">
                                    <a href="#" onclick="App.router('player', '${slide.id}', 0); return false;" class="hs-btn-primary">
                                        <i class="fa-solid fa-play"></i> Hemen İzle
                                    </a>
                                    <a href="#" onclick="App.router('detail', '${slide.id}'); return false;" class="hs-btn-ghost">
                                        <i class="fa-solid fa-circle-info"></i> Detaylar
                                    </a>
                                </div>
                            </div>
                            
                            <div class="hs-poster-wrap hide-mobile">
                                <img src="${slide.poster}" class="hs-poster" alt="${slide.title}">
                            </div>
                        </div>
                    </div>
                `).join('')}
                
                <button class="hs-arrow hs-arrow-left" onclick="HeroSlider.prev()"><i class="fa-solid fa-chevron-left"></i></button>
                <button class="hs-arrow hs-arrow-right" onclick="HeroSlider.next()"><i class="fa-solid fa-chevron-right"></i></button>
                
                <div class="hs-dots">
                    ${this.slides.map((_, i) => `<button class="hs-dot ${i === 0 ? 'active' : ''}" onclick="HeroSlider.goToSlide(${i})"></button>`).join('')}
                </div>
            </div>
        `;

        // Inject Styles
        if (!document.getElementById('hs-premium-css')) {
            const s = document.createElement('style');
            s.id = 'hs-premium-css';
            s.textContent = this.getStyles();
            document.head.appendChild(s);
        }
    },

    goToSlide(index) {
        this.currentSlide = index;
        const slides = document.querySelectorAll('.hs-slide');
        const dots = document.querySelectorAll('.hs-dot');
        slides.forEach((s, i) => s.classList.toggle('active', i === index));
        dots.forEach((d, i) => d.classList.toggle('active', i === index));
        this.resetAutoPlay();
    },

    next() { this.goToSlide((this.currentSlide + 1) % this.slides.length); },
    prev() { this.goToSlide((this.currentSlide - 1 + this.slides.length) % this.slides.length); },
    startAutoPlay() { this.interval = setInterval(() => this.next(), 8000); },
    resetAutoPlay() { clearInterval(this.interval); this.startAutoPlay(); },

    getStyles() {
        return `
            .hs-slider { position: relative; width: 100%; height: 550px; background: #07070a; overflow: hidden; border-radius: 24px; margin-top: 20px; box-shadow: 0 40px 100px -20px rgba(0,0,0,0.8); border: 1px solid rgba(255,255,255,0.05); }
            .hs-slide { position: absolute; inset: 0; opacity: 0; transition: opacity 1.2s cubic-bezier(0.4, 0, 0.2, 1); display: flex; align-items: center; pointer-events: none; }
            .hs-slide.active { opacity: 1; pointer-events: all; }
            .hs-bg { position: absolute; inset: 0; background-size: cover; background-position: center 20%; z-index: 0; filter: brightness(0.6); }
            .hs-gradient-left { position: absolute; inset: 0; background: linear-gradient(to right, #07070a 10%, rgba(7,7,10,0.8) 30%, transparent 70%); z-index: 1; }
            .hs-gradient-bottom { position: absolute; bottom: 0; left: 0; width: 100%; height: 50%; background: linear-gradient(to top, #07070a 0%, transparent 100%); z-index: 1; }
            .hs-content { position: relative; z-index: 5; display: flex; align-items: center; padding: 0 80px; width: 100%; height: 100%; gap: 50px; }
            .hs-info { flex: 1; display: flex; flex-direction: column; gap: 20px; max-width: 650px; }
            .hs-badges { display: flex; gap: 10px; }
            .hs-badge { background: rgba(124, 58, 237, 0.2); border: 1px solid rgba(124, 58, 237, 0.4); color: #fff; padding: 5px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; backdrop-filter: blur(5px); }
            .hs-title { font-family: 'Outfit', sans-serif; font-size: 4rem; font-weight: 900; color: #fff; line-height: 1.1; letter-spacing: -2px; }
            .hs-meta { display: flex; gap: 20px; color: rgba(255,255,255,0.7); font-weight: 700; font-size: 0.95rem; align-items: center; }
            .hs-meta i { color: #facc15; }
            .hs-desc { font-size: 1.1rem; color: rgba(255,255,255,0.6); line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
            .hs-actions { display: flex; gap: 15px; margin-top: 10px; }
            .hs-btn-primary { background: var(--premium-violet); color: #fff; padding: 14px 35px; border-radius: 50px; text-decoration: none; font-weight: 800; display: flex; align-items: center; gap: 10px; transition: 0.4s; box-shadow: 0 10px 20px var(--premium-violet-glow); }
            .hs-btn-primary:hover { transform: translateY(-5px); filter: brightness(1.1); box-shadow: 0 15px 30px var(--premium-violet-glow); }
            .hs-btn-ghost { background: rgba(255,255,255,0.1); color: #fff; padding: 14px 35px; border-radius: 50px; text-decoration: none; font-weight: 700; display: flex; align-items: center; gap: 10px; backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); transition: 0.3s; }
            .hs-btn-ghost:hover { background: rgba(255,255,255,0.2); transform: translateY(-3px); }
            .hs-poster-wrap { width: 280px; height: 400px; flex-shrink: 0; perspective: 1000px; }
            .hs-poster { width: 100%; height: 100%; border-radius: 20px; object-fit: cover; box-shadow: 0 30px 60px rgba(0,0,0,0.8); border: 1px solid rgba(255,255,255,0.1); transform: rotateY(-15deg); transition: 0.6s; }
            .hs-poster-wrap:hover .hs-poster { transform: rotateY(0deg) scale(1.05); }
            .hs-arrow { position: absolute; top: 50%; transform: translateY(-50%); width: 50px; height: 50px; border-radius: 50%; background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.1); color: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: 0.3s; backdrop-filter: blur(10px); z-index: 10; opacity: 0; }
            .hs-slider:hover .hs-arrow { opacity: 1; }
            .hs-arrow:hover { background: var(--premium-violet); box-shadow: 0 0 20px var(--premium-violet-glow); }
            .hs-arrow-left { left: 30px; } .hs-arrow-right { right: 30px; }
            .hs-dots { position: absolute; bottom: 30px; left: 80px; display: flex; gap: 10px; z-index: 10; }
            .hs-dot { width: 40px; height: 4px; background: rgba(255,255,255,0.2); border: none; cursor: pointer; border-radius: 2px; transition: 0.3s; }
            .hs-dot.active { background: #fff; width: 60px; box-shadow: 0 0 10px rgba(255,255,255,0.5); }
            @media (max-width: 1024px) { .hs-poster-wrap { display: none; } .hs-content { padding: 0 40px; } .hs-title { font-size: 3rem; } }
            @media (max-width: 768px) { .hs-slider { height: 400px; border-radius: 0; margin-top: 0; } .hs-content { padding: 0 20px; text-align: center; } .hs-info { align-items: center; } .hs-title { font-size: 2.2rem; } .hs-arrow { display: none; } .hs-dots { left: 50%; transform: translateX(-50%); } }
        `;
    }
};

window.HeroSlider = HeroSlider;
