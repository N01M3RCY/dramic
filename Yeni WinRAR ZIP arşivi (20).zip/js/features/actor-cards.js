/**
 * Actor Cards - Collection & Award System
 */
const ActorCards = {
    init() {
        console.log('🎭 Actor Cards System Initialized');
        this.initializeUserData();
    },

    initializeUserData() {
        if (!State.currentUser) return;
        if (!State.currentUser.actorCards) State.currentUser.actorCards = [];
        if (!State.currentUser.finishedSeries) State.currentUser.finishedSeries = [];
    },

    /**
     * Called whenever an episode is marked as watched.
     */
    checkSeriesCompletion(seriesId) {
        if (!State.currentUser) return;
        this.initializeUserData();

        const series = db.getSeries(seriesId);
        if (!series || !series.episodes) return;

        // Check if already marked as finished
        if (State.currentUser.finishedSeries.includes(seriesId)) return;

        const watchedList = State.currentUser.watchedEpisodes?.[seriesId] || [];
        const totalEpisodes = series.episodes.length;

        // Determine completion (allow for small margin if needed, but here we require 100%)
        if (watchedList.length >= totalEpisodes && totalEpisodes > 0) {
            console.log(`✅ Series Finished: ${series.title}`);
            State.currentUser.finishedSeries.push(seriesId);

            // Save current status
            db.updateUser(State.currentUser.id, { finishedSeries: State.currentUser.finishedSeries });
            sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));

            // Trigger Actor Award Check
            this.checkActorAward(series);
        }
    },

    /**
     * Check if finishing this series completes an actor's filmography.
     */
    checkActorAward(series) {
        if (!series.characters) return;

        series.characters.forEach(char => {
            const actorName = char.actor || char.name;
            if (!actorName) return;

            // Check if already has this actor's card
            if (State.currentUser.actorCards.some(card => card.actorName === actorName)) return;

            // Find all series featuring this actor
            const allSeriesWithActor = State.data.series.filter(s =>
                s.characters && s.characters.some(c => (c.actor || c.name) === actorName)
            );

            // Check if user has finished all these series
            const finishedAll = allSeriesWithActor.every(s =>
                State.currentUser.finishedSeries.includes(s.id)
            );

            if (finishedAll && allSeriesWithActor.length > 0) {
                this.awardCard(actorName, char.image || 'assets/logo.png');
            }
        });
    },

    awardCard(actorName, actorImage) {
        const newCard = {
            id: 'card-' + Date.now(),
            actorName: actorName,
            image: actorImage,
            awardedAt: Date.now(),
            rarity: 'Rare' // Default for now
        };

        State.currentUser.actorCards.push(newCard);

        // Save
        db.updateUser(State.currentUser.id, { actorCards: State.currentUser.actorCards });
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));

        // UI Feedback
        this.showAwardModal(newCard);

        if (window.Toast) {
            Toast.success(`Tebrikler! ${actorName} koleksiyon kartını kazandınız!`);
        }
    },

    showAwardModal(card) {
        const modal = document.createElement('div');
        modal.className = 'modal actor-card-award-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content card-award-content" style="background: linear-gradient(135deg, #1a1a2e, #16213e); border: 2px solid #ffd700; max-width: 400px; text-align: center; overflow: hidden; animation: cardAwardPop 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);">
                <div class="card-glow-effect"></div>
                <div style="padding: 40px 20px;">
                    <h2 style="color: #ffd700; margin-bottom: 5px; text-transform: uppercase; letter-spacing: 2px;">YENİ KART!</h2>
                    <p style="color: #a0a0ff; font-size: 0.9rem; margin-bottom: 25px;">Koleksiyonun Gelişiyor</p>
                    
                    <div class="rare-actor-card" style="position: relative; width: 220px; height: 320px; margin: 0 auto; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.5); border: 4px solid #ffd700; background: #000;">
                        <img src="${card.image}" style="width: 100%; height: 100%; object-fit: cover; filter: contrast(1.1) brightness(1.1);">
                        <div style="position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(transparent, rgba(0,0,0,0.9)); padding: 20px 10px; text-align: center;">
                            <div style="color: #ffd700; font-weight: 800; font-size: 1.2rem; text-shadow: 0 2px 4px rgba(0,0,0,0.8);">${card.actorName}</div>
                            <div style="color: #fff; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 1px; margin-top: 5px; opacity: 0.8;">${card.rarity} Koleksiyonu</div>
                        </div>
                        <div class="card-shimmer"></div>
                    </div>

                    <button class="btn btn-primary" onclick="this.closest('.modal').remove()" style="margin-top: 30px; background: #ffd700; color: #000; font-weight: bold; width: 100%; border: none;">Koleksiyona Ekle</button>
                </div>
            </div>
            <style>
                @keyframes cardAwardPop {
                    from { transform: scale(0.5); opacity: 0; }
                    to { transform: scale(1); opacity: 1; }
                }
                .card-award-content {
                    position: relative;
                }
                .card-glow-effect {
                    position: absolute;
                    top: -50%;
                    left: -50%;
                    width: 200%;
                    height: 200%;
                    background: radial-gradient(circle, rgba(255,215,0,0.1) 0%, transparent 70%);
                    animation: glowRotate 10s linear infinite;
                    pointer-events: none;
                }
                @keyframes glowRotate {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
                .card-shimmer {
                    position: absolute;
                    top: 0;
                    left: -150%;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
                    transform: skewX(-20deg);
                    animation: shimmer 3s infinite;
                }
                @keyframes shimmer {
                    0% { left: -150%; }
                    100% { left: 150%; }
                }
            </style>
        `;
        document.body.appendChild(modal);
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => ActorCards.init(), 3000);
});
