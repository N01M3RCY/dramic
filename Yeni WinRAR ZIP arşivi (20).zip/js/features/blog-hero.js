/**
 * BlogHero - Hero Slider and Blog Page Management
 */
window.BlogHero = {
    currentSliderType: 'new',
    currentCategory: 'all',
    sliderIndex: 0,
    sliderInterval: null,

    init() {
        console.log('📰 BlogHero initialized');
        this.renderSlider();
        this.renderPosts();
    },

    switchSlider(type, btn) {
        this.currentSliderType = type;

        // Update button styles
        document.querySelectorAll('.blog-tab-btn').forEach(b => {
            if (b === btn) {
                b.style.background = 'linear-gradient(135deg, #7c3aed, #6d28d9)';
                b.style.border = 'none';
                b.style.color = 'white';
                b.classList.add('active');
            } else {
                b.style.background = 'rgba(255,255,255,0.1)';
                b.style.border = '1px solid rgba(255,255,255,0.2)';
                b.style.color = '#888';
                b.classList.remove('active');
            }
        });

        this.renderSlider();
    },

    renderSlider() {
        const container = document.getElementById('blog-hero-slider');
        if (!container) return;

        const posts = this.getFilteredPosts();

        // Sort based on type
        let sortedPosts = [...posts];
        if (this.currentSliderType === 'new') {
            sortedPosts.sort((a, b) => new Date(b.createdAt || b.date) - new Date(a.createdAt || a.date));
        } else {
            sortedPosts.sort((a, b) => (b.views || 0) - (a.views || 0));
        }

        const heroItems = sortedPosts.slice(0, 5);

        if (heroItems.length === 0) {
            container.innerHTML = `
                <div style="padding: 80px; text-align: center; color: #666;">
                    <i class="fa-solid fa-newspaper" style="font-size: 3rem; opacity: 0.3; margin-bottom: 20px;"></i>
                    <p>Henüz yazı bulunmuyor.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div class="hero-slider-track" style="display: flex; transition: transform 0.5s ease; height: 100%;">
                ${heroItems.map((post, i) => `
                    <div class="hero-slide" style="min-width: 100%; position: relative; cursor: pointer; height: 100%;" onclick="window.location.href='#/blog/${post.id}'; window.location.reload();">
                        <div style="position: relative; height: 100%; overflow: hidden;">
                            <img src="${post.image || post.coverImage || 'img/blog-placeholder.jpg'}" 
                                 style="width: 100%; height: 100%; object-fit: cover; filter: brightness(0.7);"
                                 onerror="this.src='img/no-poster.jpg'">
                            <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(5,5,5,1) 0%, rgba(5,5,5,0.6) 40%, transparent 100%);"></div>
                            <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 40px; display: flex; flex-direction: column; justify-content: flex-end; height: 100%;">
                                <div style="display: flex; gap: 12px; margin-bottom: 16px; flex-wrap: wrap;">
                                    <span style="background: var(--blog-accent); color: white; padding: 6px 16px; border-radius: 30px; font-size: 0.8rem; font-weight: 700; text-transform: uppercase;">
                                        ${this.getCategoryName(post.category)}
                                    </span>
                                    <span style="background: rgba(255,255,255,0.1); backdrop-filter: blur(5px); color: white; padding: 6px 16px; border-radius: 30px; font-size: 0.8rem; display: flex; align-items: center; gap: 5px;">
                                        <i class="fa-solid fa-eye"></i> ${post.views || 0}
                                    </span>
                                </div>
                                <h2 style="font-size: 2.2rem; font-weight: 800; margin: 0 0 15px; line-height: 1.2; color: #fff; text-shadow: 0 2px 10px rgba(0,0,0,0.5);">${post.title}</h2>
                                <p style="color: rgba(255,255,255,0.8); font-size: 1.05rem; margin: 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.6; max-width: 800px; text-shadow: 0 1px 5px rgba(0,0,0,0.5);">
                                    ${post.excerpt || (post.content ? post.content.substring(0, 150) + '...' : '')}
                                </p>
                                <div style="display: flex; align-items: center; gap: 20px; margin-top: 25px;">
                                    <div style="display: flex; align-items: center; gap: 12px;">
                                        <img src="${post.authorAvatar || 'assets/logo.png'}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 2px solid var(--blog-glass-border);">
                                        <span style="font-size: 0.95rem; color: #fff; font-weight: 600;">${post.author || 'Anonim'}</span>
                                    </div>
                                    <span style="font-size: 0.9rem; color: rgba(255,255,255,0.6); display: flex; align-items: center; gap: 6px;">
                                        <i class="fa-regular fa-calendar"></i> ${this.formatDate(post.date || post.createdAt)}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <!-- Slider Navigation -->
            ${heroItems.length > 1 ? `
                <button onclick="BlogHero.prevSlide()" class="hero-slide-nav prev">
                    <i class="fa-solid fa-chevron-left"></i>
                </button>
                <button onclick="BlogHero.nextSlide()" class="hero-slide-nav next">
                    <i class="fa-solid fa-chevron-right"></i>
                </button>
                <div style="position: absolute; bottom: 30px; right: 40px; display: flex; gap: 10px; z-index: 10;">
                    ${heroItems.map((_, i) => `
                        <button onclick="BlogHero.goToSlide(${i})" 
                                style="width: ${i === 0 ? '30px' : '12px'}; height: 12px; border-radius: 6px; background: ${i === 0 ? 'var(--blog-accent)' : 'rgba(255,255,255,0.4)'}; border: none; cursor: pointer; transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);"
                                class="slider-dot" data-index="${i}">
                        </button>
                    `).join('')}
                </div>
            ` : ''}
        `;

        this.sliderIndex = 0;
        this.startAutoSlide();
    },

    startAutoSlide() {
        if (this.sliderInterval) clearInterval(this.sliderInterval);
        this.sliderInterval = setInterval(() => this.nextSlide(), 6000);
    },

    nextSlide() {
        const track = document.querySelector('.hero-slider-track');
        const dots = document.querySelectorAll('.slider-dot');
        if (!track || dots.length === 0) return;

        this.sliderIndex = (this.sliderIndex + 1) % dots.length;
        this.updateSlider();
    },

    prevSlide() {
        const dots = document.querySelectorAll('.slider-dot');
        if (dots.length === 0) return;

        this.sliderIndex = (this.sliderIndex - 1 + dots.length) % dots.length;
        this.updateSlider();
    },

    goToSlide(index) {
        this.sliderIndex = index;
        this.updateSlider();
    },

    updateSlider() {
        const track = document.querySelector('.hero-slider-track');
        const dots = document.querySelectorAll('.slider-dot');
        if (!track) return;

        track.style.transform = `translateX(-${this.sliderIndex * 100}%)`;

        dots.forEach((dot, i) => {
            dot.style.width = i === this.sliderIndex ? '30px' : '12px';
            dot.style.background = i === this.sliderIndex ? 'var(--blog-accent)' : 'rgba(255,255,255,0.4)';
        });
    },

    filterPosts(category, btn) {
        this.currentCategory = category;

        // Update filter buttons
        document.querySelectorAll('.filter-chip').forEach(b => {
            b.classList.remove('active');
        });
        if (btn) btn.classList.add('active');

        this.renderPosts();
    },

    renderPosts() {
        const container = document.getElementById('blog-posts-grid');
        if (!container) return;

        let posts = this.getFilteredPosts();

        // Filter by category
        if (this.currentCategory !== 'all') {
            posts = posts.filter(p => p.category === this.currentCategory);
        }

        // Filter by Search Query (Phase 5)
        if (window.BlogSystem && BlogSystem.searchQuery) {
            const query = BlogSystem.searchQuery;
            posts = posts.filter(p => 
                (p.title && p.title.toLowerCase().includes(query)) || 
                (p.content && p.content.toLowerCase().includes(query)) ||
                (p.excerpt && p.excerpt.toLowerCase().includes(query))
            );
        }

        // Sort by date (newest first by default)
        posts.sort((a, b) => new Date(b.createdAt || b.date) - new Date(a.createdAt || a.date));

        if (posts.length === 0) {
            container.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 60px; color: #666;">
                    <i class="fa-solid fa-file-lines" style="font-size: 3rem; opacity: 0.3; margin-bottom: 15px;"></i>
                    <p>Bu kategoride yazı bulunmuyor.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = posts.map(post => `
            <article class="blog-card-cinema" onclick="window.location.href='#/blog/${post.id}'; window.location.reload();">
                <div class="card-img-box">
                    <img src="${post.image || post.coverImage || 'img/blog-placeholder.jpg'}" 
                         onerror="this.src='img/no-poster.jpg'">
                    <div class="card-overlay"></div>
                    <div class="category-tag">${this.getCategoryName(post.category)}</div>
                </div>
                <div class="card-details">
                    <h3 class="card-title">${post.title}</h3>
                    <p class="card-excerpt">${post.excerpt || (post.content ? post.content.substring(0, 100) + '...' : '')}</p>
                    
                    <div class="card-author-info">
                        <div class="author-box">
                            <img src="${post.authorAvatar || 'assets/logo.png'}" alt="${post.author}" class="author-avatar">
                            <span class="author-name">${post.author || 'Anonim'}</span>
                        </div>
                        <div style="display: flex; gap: 10px; font-size: 0.75rem; color: var(--blog-text-muted);">
                            <span><i class="fa-solid fa-eye"></i> ${post.views || 0}</span>
                            <span><i class="fa-solid fa-heart"></i> ${post.likes || 0}</span>
                        </div>
                    </div>
                </div>
            </article>
        `).join('');

    },

    getFilteredPosts() {
        const posts = (State.data && State.data.blogPosts) ? State.data.blogPosts : [];
        // Only show published posts
        return posts.filter(p => p.approvalStatus === 'published' || !p.approvalStatus);
    },

    getCategoryName(key) {
        const cats = {
            'news': 'Haber',
            'review': 'İnceleme',
            'theory': 'Teori',
            'guide': 'Rehber',
            'general': 'Genel',
            'analysis': 'Analiz'
        };
        return cats[key] || key || 'Genel';
    },

    formatDate(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        return d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short', year: 'numeric' });
    }
};

