/**
 * Achievements System
 * 100+ achievements with real tracking and progress
 */
const Achievements = {
    // All achievements definition
    definitions: [
        // === WATCHING ACHIEVEMENTS ===
        { id: 'first_watch', name: 'İlk Adım', desc: 'İlk dizini izle', icon: 'fa-play', category: 'watching', xp: 10, condition: (u) => (u.watchHistory?.length || 0) >= 1 },
        { id: 'watch_5', name: 'Meraklı', desc: '5 dizi izle', icon: 'fa-eye', category: 'watching', xp: 25, condition: (u) => (u.watchHistory?.length || 0) >= 5 },
        { id: 'watch_10', name: 'Düzenli İzleyici', desc: '10 dizi izle', icon: 'fa-tv', category: 'watching', xp: 50, condition: (u) => (u.watchHistory?.length || 0) >= 10 },
        { id: 'watch_25', name: 'Dizi Sever', desc: '25 dizi izle', icon: 'fa-heart', category: 'watching', xp: 100, condition: (u) => (u.watchHistory?.length || 0) >= 25 },
        { id: 'watch_50', name: 'Maratoncu', desc: '50 dizi izle', icon: 'fa-fire', category: 'watching', xp: 200, condition: (u) => (u.watchHistory?.length || 0) >= 50 },
        { id: 'watch_100', name: 'Efsane', desc: '100 dizi izle', icon: 'fa-crown', category: 'watching', xp: 500, condition: (u) => (u.watchHistory?.length || 0) >= 100 },
        { id: 'watch_250', name: 'Dizi Ustası', desc: '250 dizi izle', icon: 'fa-gem', category: 'watching', xp: 1000, condition: (u) => (u.watchHistory?.length || 0) >= 250 },

        // Episode milestones
        { id: 'ep_10', name: '10 Bölüm', desc: '10 bölüm izle', icon: 'fa-film', category: 'watching', xp: 15, condition: (u) => (u.totalEpisodes || 0) >= 10 },
        { id: 'ep_50', name: '50 Bölüm', desc: '50 bölüm izle', icon: 'fa-clapperboard', category: 'watching', xp: 50, condition: (u) => (u.totalEpisodes || 0) >= 50 },
        { id: 'ep_100', name: '100 Bölüm Kulübü', desc: '100 bölüm izle', icon: 'fa-ticket', category: 'watching', xp: 100, condition: (u) => (u.totalEpisodes || 0) >= 100 },
        { id: 'ep_500', name: 'Binge Master', desc: '500 bölüm izle', icon: 'fa-star', category: 'watching', xp: 300, condition: (u) => (u.totalEpisodes || 0) >= 500 },
        { id: 'ep_1000', name: 'Dizi Tanrısı', desc: '1000 bölüm izle', icon: 'fa-trophy', category: 'watching', xp: 750, condition: (u) => (u.totalEpisodes || 0) >= 1000 },

        // Watch hours
        { id: 'hours_10', name: 'İlk 10 Saat', desc: '10 saat izle', icon: 'fa-clock', category: 'watching', xp: 30, condition: (u) => (u.totalWatchMinutes || 0) >= 600 },
        { id: 'hours_50', name: 'Zamansız', desc: '50 saat izle', icon: 'fa-hourglass-half', category: 'watching', xp: 100, condition: (u) => (u.totalWatchMinutes || 0) >= 3000 },
        { id: 'hours_100', name: 'Yüzyılın İzleyicisi', desc: '100 saat izle', icon: 'fa-hourglass', category: 'watching', xp: 250, condition: (u) => (u.totalWatchMinutes || 0) >= 6000 },
        { id: 'hours_500', name: 'Zaman Yolcusu', desc: '500 saat izle', icon: 'fa-infinity', category: 'watching', xp: 1000, condition: (u) => (u.totalWatchMinutes || 0) >= 30000 },

        // === SOCIAL ACHIEVEMENTS ===
        { id: 'first_friend', name: 'İlk Arkadaş', desc: 'İlk arkadaşını ekle', icon: 'fa-user-plus', category: 'social', xp: 15, condition: (u) => (u.friends?.length || 0) >= 1 },
        { id: 'friends_5', name: 'Sosyal', desc: '5 arkadaş edin', icon: 'fa-users', category: 'social', xp: 30, condition: (u) => (u.friends?.length || 0) >= 5 },
        { id: 'friends_10', name: 'Popüler', desc: '10 arkadaş edin', icon: 'fa-user-group', category: 'social', xp: 75, condition: (u) => (u.friends?.length || 0) >= 10 },
        { id: 'friends_25', name: 'Sosyal Kelebek', desc: '25 arkadaş edin', icon: 'fa-heart', category: 'social', xp: 150, condition: (u) => (u.friends?.length || 0) >= 25 },
        { id: 'friends_50', name: 'Influencer', desc: '50 arkadaş edin', icon: 'fa-star', category: 'social', xp: 300, condition: (u) => (u.friends?.length || 0) >= 50 },
        { id: 'friends_100', name: 'Fenomen', desc: '100 arkadaş edin', icon: 'fa-crown', category: 'social', xp: 500, condition: (u) => (u.friends?.length || 0) >= 100 },

        // Followers
        { id: 'followers_10', name: '10 Takipçi', desc: '10 takipçi kazan', icon: 'fa-bell', category: 'social', xp: 50, condition: (u) => (u.followers?.length || 0) >= 10 },
        { id: 'followers_50', name: 'Yükselen Yıldız', desc: '50 takipçi kazan', icon: 'fa-rocket', category: 'social', xp: 150, condition: (u) => (u.followers?.length || 0) >= 50 },
        { id: 'followers_100', name: 'Mikro İnfluencer', desc: '100 takipçi kazan', icon: 'fa-circle-check', category: 'social', xp: 300, condition: (u) => (u.followers?.length || 0) >= 100 },
        { id: 'followers_500', name: 'İnfluencer', desc: '500 takipçi kazan', icon: 'fa-certificate', category: 'social', xp: 750, condition: (u) => (u.followers?.length || 0) >= 500 },
        { id: 'followers_1000', name: 'Ünlü', desc: '1000 takipçi kazan', icon: 'fa-gem', category: 'social', xp: 1500, condition: (u) => (u.followers?.length || 0) >= 1000 },

        // === COMMENT ACHIEVEMENTS ===
        { id: 'first_comment', name: 'İlk Söz', desc: 'İlk yorumunu yap', icon: 'fa-comment', category: 'comments', xp: 10, condition: (u) => (u.totalComments || 0) >= 1 },
        { id: 'comments_10', name: 'Konuşkan', desc: '10 yorum yap', icon: 'fa-comments', category: 'comments', xp: 25, condition: (u) => (u.totalComments || 0) >= 10 },
        { id: 'comments_50', name: 'Yorumcu', desc: '50 yorum yap', icon: 'fa-message', category: 'comments', xp: 75, condition: (u) => (u.totalComments || 0) >= 50 },
        { id: 'comments_100', name: 'Eleştirmen', desc: '100 yorum yap', icon: 'fa-star', category: 'comments', xp: 150, condition: (u) => (u.totalComments || 0) >= 100 },
        { id: 'comments_500', name: 'Dizi Filozofu', desc: '500 yorum yap', icon: 'fa-graduation-cap', category: 'comments', xp: 500, condition: (u) => (u.totalComments || 0) >= 500 },

        // Likes received
        { id: 'likes_10', name: 'Beğenilen', desc: '10 beğeni al', icon: 'fa-thumbs-up', category: 'comments', xp: 20, condition: (u) => (u.totalLikesReceived || 0) >= 10 },
        { id: 'likes_50', name: 'Sevilen', desc: '50 beğeni al', icon: 'fa-heart', category: 'comments', xp: 75, condition: (u) => (u.totalLikesReceived || 0) >= 50 },
        { id: 'likes_100', name: 'Popüler Yorumcu', desc: '100 beğeni al', icon: 'fa-fire', category: 'comments', xp: 150, condition: (u) => (u.totalLikesReceived || 0) >= 100 },
        { id: 'likes_500', name: 'Beğeni Kralı', desc: '500 beğeni al', icon: 'fa-crown', category: 'comments', xp: 400, condition: (u) => (u.totalLikesReceived || 0) >= 500 },

        // === LIST ACHIEVEMENTS ===
        { id: 'first_list', name: 'Koleksiyoncu', desc: 'İlk listeyi oluştur', icon: 'fa-list', category: 'lists', xp: 15, condition: (u) => (u.playlists?.length || 0) >= 1 },
        { id: 'lists_5', name: 'Düzenleyici', desc: '5 liste oluştur', icon: 'fa-folder', category: 'lists', xp: 40, condition: (u) => (u.playlists?.length || 0) >= 5 },
        { id: 'lists_10', name: 'Arşivci', desc: '10 liste oluştur', icon: 'fa-boxes-stacked', category: 'lists', xp: 100, condition: (u) => (u.playlists?.length || 0) >= 10 },

        // Watchlist
        { id: 'watchlist_10', name: 'Planlı', desc: 'İzleneceklere 10 dizi ekle', icon: 'fa-bookmark', category: 'lists', xp: 20, condition: (u) => (u.watchlist?.length || 0) >= 10 },
        { id: 'watchlist_50', name: 'Liste Ustası', desc: 'İzleneceklere 50 dizi ekle', icon: 'fa-bookmarks', category: 'lists', xp: 75, condition: (u) => (u.watchlist?.length || 0) >= 50 },
        { id: 'watchlist_100', name: 'Koleksiyoner', desc: 'İzleneceklere 100 dizi ekle', icon: 'fa-layer-group', category: 'lists', xp: 150, condition: (u) => (u.watchlist?.length || 0) >= 100 },

        // === RATING ACHIEVEMENTS ===
        { id: 'first_rating', name: 'İlk Puan', desc: 'İlk puanlamayı yap', icon: 'fa-star-half-stroke', category: 'ratings', xp: 10, condition: (u) => (u.totalRatings || 0) >= 1 },
        { id: 'ratings_10', name: 'Değerlendirici', desc: '10 dizi puanla', icon: 'fa-star', category: 'ratings', xp: 30, condition: (u) => (u.totalRatings || 0) >= 10 },
        { id: 'ratings_50', name: 'Kritik', desc: '50 dizi puanla', icon: 'fa-ranking-star', category: 'ratings', xp: 100, condition: (u) => (u.totalRatings || 0) >= 50 },
        { id: 'ratings_100', name: 'Profesyonel Jüri', desc: '100 dizi puanla', icon: 'fa-award', category: 'ratings', xp: 200, condition: (u) => (u.totalRatings || 0) >= 100 },

        // === GENRE ACHIEVEMENTS ===
        { id: 'romance_lover', name: 'Romantik Ruh', desc: '10 romantik dizi izle', icon: 'fa-heart', category: 'genres', xp: 50, condition: (u) => this.countGenreWatched(u, 'Romance') >= 10 },
        { id: 'action_fan', name: 'Aksiyon Fanı', desc: '10 aksiyon dizi izle', icon: 'fa-burst', category: 'genres', xp: 50, condition: (u) => this.countGenreWatched(u, 'Action') >= 10 },
        { id: 'thriller_addict', name: 'Gerilim Bağımlısı', desc: '10 gerilim dizi izle', icon: 'fa-skull', category: 'genres', xp: 50, condition: (u) => this.countGenreWatched(u, 'Thriller') >= 10 },
        { id: 'comedy_king', name: 'Komedi Kralı', desc: '10 komedi izle', icon: 'fa-face-laugh', category: 'genres', xp: 50, condition: (u) => this.countGenreWatched(u, 'Comedy') >= 10 },
        { id: 'drama_queen', name: 'Drama Kraliçesi', desc: '10 drama izle', icon: 'fa-masks-theater', category: 'genres', xp: 50, condition: (u) => this.countGenreWatched(u, 'Drama') >= 10 },
        { id: 'fantasy_dreamer', name: 'Fantezi Hayalperest', desc: '10 fantezi izle', icon: 'fa-wand-magic-sparkles', category: 'genres', xp: 50, condition: (u) => this.countGenreWatched(u, 'Fantasy') >= 10 },
        { id: 'horror_brave', name: 'Cesur Kalp', desc: '10 korku izle', icon: 'fa-ghost', category: 'genres', xp: 50, condition: (u) => this.countGenreWatched(u, 'Horror') >= 10 },
        { id: 'mystery_detective', name: 'Dedektif', desc: '10 gizem dizi izle', icon: 'fa-magnifying-glass', category: 'genres', xp: 50, condition: (u) => this.countGenreWatched(u, 'Mystery') >= 10 },

        // === COUNTRY ACHIEVEMENTS ===
        { id: 'korea_fan', name: 'Kore Hayranı', desc: '20 Kore dizisi izle', icon: 'fa-flag', category: 'countries', xp: 75, condition: (u) => this.countCountryWatched(u, 'Kore') >= 20 },
        { id: 'china_fan', name: 'Çin Meraklısı', desc: '20 Çin dizisi izle', icon: 'fa-flag', category: 'countries', xp: 75, condition: (u) => this.countCountryWatched(u, 'Çin') >= 20 },
        { id: 'japan_fan', name: 'Japonya Aşığı', desc: '20 Japon dizisi izle', icon: 'fa-flag', category: 'countries', xp: 75, condition: (u) => this.countCountryWatched(u, 'Japonya') >= 20 },
        { id: 'thai_fan', name: 'Tayland Sevdalısı', desc: '10 Tayland dizisi izle', icon: 'fa-flag', category: 'countries', xp: 75, condition: (u) => this.countCountryWatched(u, 'Tayland') >= 10 },
        { id: 'global_watcher', name: 'Küresel İzleyici', desc: '5 farklı ülkeden dizi izle', icon: 'fa-globe', category: 'countries', xp: 100, condition: (u) => this.countUniqueCountries(u) >= 5 },
        { id: 'world_citizen', name: 'Dünya Vatandaşı', desc: '10 farklı ülkeden dizi izle', icon: 'fa-earth-americas', category: 'countries', xp: 250, condition: (u) => this.countUniqueCountries(u) >= 10 },

        // === TIME ACHIEVEMENTS ===
        { id: 'night_owl', name: 'Gece Kuşu', desc: 'Gece 2-5 arası izle', icon: 'fa-moon', category: 'time', xp: 30, condition: (u) => u.nightWatches >= 5 },
        { id: 'early_bird', name: 'Erken Kuş', desc: 'Sabah 5-7 arası izle', icon: 'fa-sun', category: 'time', xp: 30, condition: (u) => u.morningWatches >= 5 },
        { id: 'weekend_warrior', name: 'Hafta Sonu Savaşçısı', desc: 'Hafta sonu 10 bölüm izle', icon: 'fa-calendar-week', category: 'time', xp: 50, condition: (u) => u.weekendEpisodes >= 10 },
        { id: 'binge_day', name: 'Maraton Günü', desc: 'Bir günde 10 bölüm izle', icon: 'fa-stopwatch', category: 'time', xp: 75, condition: (u) => u.maxDailyEpisodes >= 10 },
        { id: 'streak_7', name: '7 Gün Seri', desc: '7 gün üst üste izle', icon: 'fa-fire-flame-curved', category: 'time', xp: 100, condition: (u) => u.longestStreak >= 7 },
        { id: 'streak_30', name: '30 Gün Seri', desc: '30 gün üst üste izle', icon: 'fa-fire', category: 'time', xp: 300, condition: (u) => u.longestStreak >= 30 },
        { id: 'streak_100', name: '100 Gün Efsane', desc: '100 gün üst üste izle', icon: 'fa-trophy', category: 'time', xp: 1000, condition: (u) => u.longestStreak >= 100 },

        // === SPECIAL ACHIEVEMENTS ===
        { id: 'vip_member', name: 'VIP Üye', desc: 'VIP üyelik satın al', icon: 'fa-gem', category: 'special', xp: 100, condition: (u) => u.isVip || u.vipExpiry },
        { id: 'beta_tester', name: 'Beta Tester', desc: 'Beta test programına katıl', icon: 'fa-flask', category: 'special', xp: 200, condition: (u) => u.badges?.includes('beta') },
        { id: 'founder', name: 'Kurucu Üye', desc: 'İlk 100 üyeden biri ol', icon: 'fa-medal', category: 'special', xp: 500, condition: (u) => u.badges?.includes('founder') },
        { id: 'contributor', name: 'Katkıda Bulunan', desc: 'Site geliştirmeye yardım et', icon: 'fa-code', category: 'special', xp: 300, condition: (u) => u.badges?.includes('contributor') },
        { id: 'translator', name: 'Çevirmen', desc: 'Çevirmen olarak katkıda bulun', icon: 'fa-language', category: 'special', xp: 250, condition: (u) => u.role === 'translator' },
        { id: 'moderator', name: 'Moderatör', desc: 'Moderatör ol', icon: 'fa-shield', category: 'special', xp: 300, condition: (u) => u.role === 'moderator' || u.role === 'admin' },
        { id: 'admin', name: 'Yönetici', desc: 'Yönetici ol', icon: 'fa-crown', category: 'special', xp: 500, condition: (u) => u.role === 'admin' },

        // === ACCOUNT ACHIEVEMENTS ===
        { id: 'profile_complete', name: 'Tamamlanmış Profil', desc: 'Profil bilgilerini doldur', icon: 'fa-user-check', category: 'account', xp: 20, condition: (u) => u.avatar && u.bio && u.location },
        { id: 'avatar_set', name: 'Yeni Yüz', desc: 'Avatar ayarla', icon: 'fa-image-portrait', category: 'account', xp: 10, condition: (u) => u.avatar && !u.avatar.includes('default') },
        { id: 'member_1month', name: '1 Aylık Üye', desc: '1 aydır üye ol', icon: 'fa-calendar', category: 'account', xp: 30, condition: (u) => this.memberDays(u) >= 30 },
        { id: 'member_6months', name: '6 Aylık Veteran', desc: '6 aydır üye ol', icon: 'fa-calendar-days', category: 'account', xp: 100, condition: (u) => this.memberDays(u) >= 180 },
        { id: 'member_1year', name: '1 Yıllık Efsane', desc: '1 yıldır üye ol', icon: 'fa-cake-candles', category: 'account', xp: 300, condition: (u) => this.memberDays(u) >= 365 },
        { id: 'member_2years', name: '2 Yıllık Antik', desc: '2 yıldır üye ol', icon: 'fa-hourglass', category: 'account', xp: 500, condition: (u) => this.memberDays(u) >= 730 },

        // === LEVEL ACHIEVEMENTS ===
        { id: 'level_5', name: 'Seviye 5', desc: 'Seviye 5\'e ulaş', icon: 'fa-5', category: 'levels', xp: 0, condition: (u) => this.calculateLevel(u) >= 5 },
        { id: 'level_10', name: 'Seviye 10', desc: 'Seviye 10\'a ulaş', icon: 'fa-1', category: 'levels', xp: 0, condition: (u) => this.calculateLevel(u) >= 10 },
        { id: 'level_25', name: 'Seviye 25', desc: 'Seviye 25\'e ulaş', icon: 'fa-2', category: 'levels', xp: 0, condition: (u) => this.calculateLevel(u) >= 25 },
        { id: 'level_50', name: 'Seviye 50', desc: 'Seviye 50\'ye ulaş', icon: 'fa-5', category: 'levels', xp: 0, condition: (u) => this.calculateLevel(u) >= 50 },
        { id: 'level_100', name: 'Maksimum Seviye', desc: 'Seviye 100\'e ulaş', icon: 'fa-infinity', category: 'levels', xp: 0, condition: (u) => this.calculateLevel(u) >= 100 },

        // === WEBTOON ACHIEVEMENTS ===
        { id: 'first_webtoon', name: 'İlk Webtoon', desc: 'İlk webtoon\'u oku', icon: 'fa-book-open', category: 'webtoons', xp: 15, condition: (u) => (u.webtoonsRead || 0) >= 1 },
        { id: 'webtoon_10', name: 'Webtoon Okuru', desc: '10 webtoon oku', icon: 'fa-book', category: 'webtoons', xp: 50, condition: (u) => (u.webtoonsRead || 0) >= 10 },
        { id: 'webtoon_50', name: 'Webtoon Master', desc: '50 webtoon oku', icon: 'fa-books', category: 'webtoons', xp: 150, condition: (u) => (u.webtoonsRead || 0) >= 50 },
        { id: 'loyal_fan', name: 'Sadık Hayran', desc: 'Bir diziyi 3 kez izle', icon: 'fa-heart', category: 'watching', xp: 150, condition: (u) => (u.watchHistory?.some(wh => wh.repeats >= 2)) },
        { id: 'series_wolf', name: 'Dizi Kurdu', desc: '50 farklı dizi izle', icon: 'fa-eye', category: 'watching', xp: 500, condition: (u) => (u.watchHistory?.length || 0) >= 50 },
        { id: 'marathoner', name: 'Maratoncu', desc: 'Bir günde 15 bölüm izle', icon: 'fa-bolt', category: 'time', xp: 300, condition: (u) => (u.maxDailyEpisodes || 0) >= 15 }
    ],

    // Helper functions
    countGenreWatched(user, genre) {
        if (!user.watchHistory || !State.data?.series) return 0;
        return user.watchHistory.filter(wh => {
            const series = State.data.series.find(s => s.id === wh.seriesId);
            if (!series) return false;
            const genres = Array.isArray(series.genres) ? series.genres :
                Array.isArray(series.genre) ? series.genre :
                    typeof series.genre === 'string' ? series.genre.split(',') : [];
            return genres.some(g => g.toLowerCase().includes(genre.toLowerCase()));
        }).length;
    },

    countCountryWatched(user, country) {
        if (!user.watchHistory || !State.data?.series) return 0;
        return user.watchHistory.filter(wh => {
            const series = State.data.series.find(s => s.id === wh.seriesId);
            return series && series.country === country;
        }).length;
    },

    countUniqueCountries(user) {
        if (!user.watchHistory || !State.data?.series) return 0;
        const countries = new Set();
        user.watchHistory.forEach(wh => {
            const series = State.data.series.find(s => s.id === wh.seriesId);
            if (series && series.country) countries.add(series.country);
        });
        return countries.size;
    },

    memberDays(user) {
        if (!user.createdAt) return 0;
        const created = new Date(user.createdAt);
        const now = new Date();
        return Math.floor((now - created) / (1000 * 60 * 60 * 24));
    },

    // Calculate XP and Level
    calculateTotalXP(user) {
        let xp = user.baseXP || 0;
        this.definitions.forEach(ach => {
            try {
                if (ach.condition(user)) {
                    xp += ach.xp;
                }
            } catch (e) { }
        });
        return xp;
    },

    calculateLevel(user) {
        // Use central Gamification logic if available
        if (typeof Gamification !== 'undefined' && Gamification.getLevel) {
            return Gamification.getLevel(user.stats?.xp || 0);
        }

        const xp = this.calculateTotalXP(user);
        // Level formula: each level requires more XP
        // Level 1 = 0, Level 2 = 100, Level 3 = 250, etc.
        let level = 1;
        let requiredXP = 0;
        while (xp >= requiredXP) {
            level++;
            requiredXP += level * 50;
        }
        return level - 1;
    },

    getXPForNextLevel(user) {
        const currentLevel = this.calculateLevel(user);
        let requiredXP = 0;
        for (let i = 1; i <= currentLevel + 1; i++) {
            requiredXP += i * 50;
        }
        return requiredXP;
    },

    // Get earned achievements
    getEarnedAchievements(user) {
        return this.definitions.filter(ach => {
            try {
                return ach.condition(user);
            } catch (e) {
                return false;
            }
        });
    },

    // Get unearned achievements  
    getUnearnedAchievements(user) {
        return this.definitions.filter(ach => {
            try {
                return !ach.condition(user);
            } catch (e) {
                return true;
            }
        });
    },

    // Get category info
    categories: {
        watching: { name: 'İzleme', icon: 'fa-tv', color: '#8b5cf6' },
        social: { name: 'Sosyal', icon: 'fa-users', color: '#ec4899' },
        comments: { name: 'Yorumlar', icon: 'fa-comments', color: '#14b8a6' },
        lists: { name: 'Listeler', icon: 'fa-list', color: '#f59e0b' },
        ratings: { name: 'Puanlamalar', icon: 'fa-star', color: '#eab308' },
        genres: { name: 'Türler', icon: 'fa-masks-theater', color: '#ef4444' },
        countries: { name: 'Ülkeler', icon: 'fa-globe', color: '#3b82f6' },
        time: { name: 'Zaman', icon: 'fa-clock', color: '#6366f1' },
        special: { name: 'Özel', icon: 'fa-gem', color: '#a855f7' },
        account: { name: 'Hesap', icon: 'fa-user', color: '#22c55e' },
        levels: { name: 'Seviyeler', icon: 'fa-arrow-up', color: '#06b6d4' },
        webtoons: { name: 'Webtoons', icon: 'fa-book', color: '#84cc16' }
    },

    // Render achievement badge
    renderBadge(achievement, earned = true) {
        const cat = this.categories[achievement.category] || { color: '#64748b' };
        const opacity = earned ? 1 : 0.3;
        return `
            <div class="achievement-badge ${earned ? 'earned' : 'locked'}" 
                 style="opacity: ${opacity}; background: linear-gradient(135deg, ${cat.color}22, ${cat.color}11); border: 1px solid ${cat.color}44; border-radius: 16px; padding: 16px; text-align: center; transition: all 0.3s;"
                 title="${achievement.desc}${earned ? '' : ' (Kilitli)'}">
                <div style="width: 50px; height: 50px; margin: 0 auto 10px; background: ${earned ? cat.color : '#333'}; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fa-solid ${achievement.icon}" style="font-size: 1.4rem; color: ${earned ? '#fff' : '#666'};"></i>
                </div>
                <div style="font-weight: 700; font-size: 0.85rem; color: ${earned ? '#fff' : '#666'}; margin-bottom: 4px;">${achievement.name}</div>
                <div style="font-size: 0.7rem; color: ${earned ? '#94a3b8' : '#444'};">${achievement.xp} XP</div>
                ${!earned ? '<i class="fa-solid fa-lock" style="position: absolute; top: 8px; right: 8px; color: #444; font-size: 0.7rem;"></i>' : ''}
            </div>
        `;
    },

    // Render achievements modal  
    showAllAchievements(userId) {
        const user = State.data.users.find(u => u.id === userId) || State.currentUser;
        if (!user) return;

        const earned = this.getEarnedAchievements(user);
        const unearned = this.getUnearnedAchievements(user);
        const totalXP = this.calculateTotalXP(user);
        const level = this.calculateLevel(user);
        const nextLevelXP = this.getXPForNextLevel(user);
        const progress = Math.min(100, (totalXP / nextLevelXP) * 100);

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = 'achievements-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 900px; max-height: 85vh; overflow-y: auto; background: #0f0f14;">
                <div class="modal-header" style="background: linear-gradient(135deg, #8b5cf6, #ec4899); padding: 30px; border-radius: 20px 20px 0 0;">
                    <div>
                        <h2 style="margin: 0; font-size: 1.8rem;"><i class="fa-solid fa-trophy"></i> Başarımlar</h2>
                        <p style="margin: 10px 0 0; opacity: 0.9;">${earned.length} / ${this.definitions.length} başarım kazanıldı</p>
                    </div>
                    <button class="modal-close" onclick="this.closest('.modal').remove()" style="background: rgba(255,255,255,0.2);">×</button>
                </div>
                
                <div style="padding: 25px;">
                    <!-- Level Progress -->
                    <div style="background: rgba(255,255,255,0.03); border-radius: 20px; padding: 25px; margin-bottom: 30px; border: 1px solid rgba(255,255,255,0.05);">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #8b5cf6, #ec4899); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: 900;">${level}</div>
                                <div>
                                    <div style="font-size: 1.2rem; font-weight: 800;">Seviye ${level}</div>
                                    <div style="color: #64748b; font-size: 0.9rem;">${totalXP} / ${nextLevelXP} XP</div>
                                </div>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-size: 2rem; font-weight: 900; background: linear-gradient(90deg, #8b5cf6, #ec4899); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">${totalXP}</div>
                                <div style="color: #64748b; font-size: 0.8rem;">Toplam XP</div>
                            </div>
                        </div>
                        <div style="background: rgba(255,255,255,0.1); height: 12px; border-radius: 10px; overflow: hidden;">
                            <div style="background: linear-gradient(90deg, #8b5cf6, #ec4899); height: 100%; width: ${progress}%; transition: width 0.5s;"></div>
                        </div>
                    </div>
                    
                    <!-- Category Tabs -->
                    <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 25px;">
                        <button class="ach-cat-btn active" data-cat="all" onclick="Achievements.filterCategory('all')" style="padding: 10px 20px; border-radius: 30px; border: 1px solid #333; background: #8b5cf6; color: white; font-weight: 600; cursor: pointer;">Tümü</button>
                        ${Object.entries(this.categories).map(([key, cat]) => `
                            <button class="ach-cat-btn" data-cat="${key}" onclick="Achievements.filterCategory('${key}')" style="padding: 10px 20px; border-radius: 30px; border: 1px solid #333; background: transparent; color: #94a3b8; font-weight: 600; cursor: pointer;">
                                <i class="fa-solid ${cat.icon}"></i> ${cat.name}
                            </button>
                        `).join('')}
                    </div>
                    
                    <!-- Achievements Grid -->
                    <div id="achievements-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 15px;">
                        ${earned.map(a => this.renderBadge(a, true)).join('')}
                        ${unearned.map(a => this.renderBadge(a, false)).join('')}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    filterCategory(category) {
        // Update button states
        document.querySelectorAll('.ach-cat-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.cat === category);
            btn.style.background = btn.dataset.cat === category ? '#8b5cf6' : 'transparent';
            btn.style.color = btn.dataset.cat === category ? 'white' : '#94a3b8';
        });

        // Filter badges
        const badges = document.querySelectorAll('.achievement-badge');
        badges.forEach(badge => {
            const achName = badge.querySelector('div[style*="font-weight: 700"]')?.textContent;
            const ach = this.definitions.find(a => a.name === achName);
            if (category === 'all' || (ach && ach.category === category)) {
                badge.style.display = 'block';
            } else {
                badge.style.display = 'none';
            }
        });
    },

    // Check and award new achievements (call this after user actions)
    async checkAndAward(user) {
        if (!user) user = State.currentUser;
        if (!user) return;

        const newlyEarned = [];
        const prevEarned = user.earnedAchievements || [];

        this.definitions.forEach(ach => {
            try {
                if (ach.condition(user) && !prevEarned.includes(ach.id)) {
                    newlyEarned.push(ach);
                }
            } catch (e) { }
        });

        if (newlyEarned.length > 0) {
            // Update user
            user.earnedAchievements = [...prevEarned, ...newlyEarned.map(a => a.id)];

            // Show notifications
            newlyEarned.forEach(ach => {
                Toast.success(`🏆 Yeni başarım: ${ach.name}!`);
            });

            // Save
            await db.save();
        }

        return newlyEarned;
    }
};

window.Achievements = Achievements;
console.log('🏆 Achievements System Loaded - ' + Achievements.definitions.length + ' achievements defined');
