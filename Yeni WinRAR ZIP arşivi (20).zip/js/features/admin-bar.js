/**
 * DRAMICBOX - ADMİN QUICK ACCESS TOOLBAR
 * Provides quick actions for administrators from the frontend.
 */
const AdminBar = {
    init() {
        // Admin bar disabled — admin functionality only available in admin panel
        console.log('🛡️ Admin Bar Disabled (only in admin panel)');
        return;
    },

    injectStyles() {
        if (document.getElementById('admin-bar-style')) return;
        const link = document.createElement('link');
        link.id = 'admin-bar-style';
        link.rel = 'stylesheet';
        link.href = 'css/admin/admin-bar.css';
        document.head.appendChild(link);
    },

    render() {
        if (document.getElementById('admin-quick-bar')) return;

        const bar = document.createElement('div');
        bar.id = 'admin-quick-bar';
        bar.className = 'admin-toolbar';
        bar.innerHTML = `
            <div class="at-toggle" onclick="AdminBar.toggleBar()" title="Paneli Gizle/Göster">
                <i class="fa-solid fa-chevron-down" id="at-toggle-icon"></i>
            </div>
            <div class="at-left">
                <div class="at-brand">
                    <i class="fa-solid fa-shield-halved"></i>
                    <span>ADMİN PANEL</span>
                </div>
                <div class="at-stats">
                    <div class="at-stat-item" id="at-pending-reports">
                        <i class="fa-solid fa-flag"></i> Raporlar: <b>0</b>
                    </div>
                    <div class="at-stat-item" id="at-pending-tickets">
                        <i class="fa-solid fa-headset"></i> Destek: <b>0</b>
                    </div>
                </div>
            </div>
            <div class="at-actions">
                <a href="#/studio-panel-secure-access" class="at-btn">
                    <i class="fa-solid fa-gauge"></i> <span>Dashboard</span>
                </a>
                <button onclick="AdminBar.quickAddSeries()" class="at-btn">
                    <i class="fa-solid fa-plus"></i> <span>Dizi Ekle</span>
                </button>
                <button onclick="AdminBar.toggleMaintenance()" class="at-btn" id="at-mt-toggle">
                    <i class="fa-solid fa-wrench"></i> <span>Bakım Modu</span>
                </button>
                <button onclick="AdminBar.broadcastNotification()" class="at-btn">
                    <i class="fa-solid fa-bullhorn"></i> <span>Duyuru</span>
                </button>
                <a href="#/admin" class="at-btn primary">
                    <i class="fa-solid fa-user-gear"></i> <span>Admin Girişi</span>
                </a>
            </div>
        `;
        document.body.appendChild(bar);
        this.updateMaintenanceUI();
    },

    startStatusPolling() {
        this.updateStats();
        setInterval(() => this.updateStats(), 30000); // Every 30s
    },

    updateStats() {
        if (!State.data) return;

        const reports = (State.data.reports || []).filter(r => r.status === 'pending').length;
        const tickets = (State.data.tickets || []).filter(t => t.status === 'open' || t.status === 'pending').length;

        const reportEl = document.getElementById('at-pending-reports');
        const ticketEl = document.getElementById('at-pending-tickets');

        if (reportEl) {
            reportEl.querySelector('b').textContent = reports;
            reportEl.classList.toggle('alert', reports > 0);
        }
        if (ticketEl) {
            ticketEl.querySelector('b').textContent = tickets;
            ticketEl.classList.toggle('alert', tickets > 0);
        }
    },

    quickAddSeries() {
        // Redirect to studio with tab or open mini modal?
        // Let's redirect to specific studio route if available
        window.location.hash = '#/studio-panel-secure-access?tab=content&action=add';
        Toast.info('Dizi ekleme paneli açılıyor...');
    },

    toggleMaintenance() {
        const isMaintenance = State.data.settings?.maintenanceMode || false;
        const newState = !isMaintenance;

        if (confirm(`Bakım modunu ${newState ? 'AÇMAK' : 'KAPATMAK'} istediğinize emin misiniz?`)) {
            if (!State.data.settings) State.data.settings = {};
            State.data.settings.maintenanceMode = newState;

            if (window.db && db.updateSettings) {
                db.updateSettings({ maintenanceMode: newState });
                Toast.success(`Bakım modu ${newState ? 'aktif edildi' : 'devre dışı bırakıldı'}.`);
                this.updateMaintenanceUI();
            }
        }
    },

    updateMaintenanceUI() {
        const btn = document.getElementById('at-mt-toggle');
        if (!btn) return;

        const isMaintenance = State.data.settings?.maintenanceMode || false;
        if (isMaintenance) {
            btn.style.background = '#ef4444';
            btn.style.borderColor = '#ef4444';
            btn.querySelector('span').textContent = 'Bakım: AKTİF';
        } else {
            btn.style.background = '';
            btn.style.borderColor = '';
            btn.querySelector('span').textContent = 'Bakım Modu';
        }
    },

    broadcastNotification() {
        const title = prompt("Duyuru Başlığı:");
        if (!title) return;
        const msg = prompt("Duyuru Mesajı:");
        if (!msg) return;
        const link = prompt("Opsiyonel Link (Boş bırakabilirsiniz):", "");

        if (confirm("Bu duyuruyu TÜM kullanıcılara göndermek istediğinize emin misiniz?")) {
            fetch('api/Router.php?action=notif-create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId: 'all',
                    type: 'system',
                    title: title,
                    message: msg,
                    link: link
                })
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        Toast.success('Duyuru başarıyla yayınlandı! 📢');
                    } else {
                        Toast.error('Hata: ' + (data.message || 'Bilinmeyen hata'));
                    }
                })
                .catch(err => {
                    console.error(err);
                    Toast.error('Sunucu bağlantı hatası.');
                });
        }
    },

    toggleBar() {
        const bar = document.getElementById('admin-quick-bar');
        const icon = document.getElementById('at-toggle-icon');
        if (!bar) return;

        bar.classList.toggle('collapsed');

        if (bar.classList.contains('collapsed')) {
            icon.classList.remove('fa-chevron-down');
            icon.classList.add('fa-chevron-up');
            document.body.classList.remove('admin-mode');
        } else {
            icon.classList.remove('fa-chevron-up');
            icon.classList.add('fa-chevron-down');
            document.body.classList.add('admin-mode');
        }
    }
};

// Initialize after app load
document.addEventListener('AppReady', () => AdminBar.init());
// Also fallback if event missed
setTimeout(() => AdminBar.init(), 3000);

window.AdminBar = AdminBar;
