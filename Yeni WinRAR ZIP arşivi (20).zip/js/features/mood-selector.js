// ============================================
// MOOD SELECTOR
// Suggest content based on user mood
// ============================================

const MoodSelector = {
    moods: [
        { id: 'sad', emoji: '😢', label: 'Hüzünlü', genres: ['Dram', 'Melodram', 'Trajedi'] },
        { id: 'happy', emoji: '😄', label: 'Neşeli', genres: ['Komedi', 'Romantik Komedi', 'Gençlik'] },
        { id: 'excited', emoji: '🤩', label: 'Heyecanlı', genres: ['Aksiyon', 'Macera', 'Fantastik'] },
        { id: 'tense', emoji: '😨', label: 'Gergin', genres: ['Gerilim', 'Korku', 'Gizem'] },
        { id: 'romantic', emoji: '😍', label: 'Romantik', genres: ['Romantik', 'Romantik Komedi'] },
        { id: 'chill', emoji: '☕', label: 'Sakin', genres: ['Slice of Life', 'Dram', 'Belgesel'] },
        { id: 'curious', emoji: '🤔', label: 'Meraklı', genres: ['Gizem', 'Suç', 'Dedektif'] },
    ],

    init() {
        console.log('🎭 Mood Selector Initialized');
        this.renderSelector();
    },

    renderSelector() {
        const container = document.getElementById('mood-selector-container');
        if (!container) return;

        container.innerHTML = `
            <div class="container section">
                <div class="section-header">
                    <h2>Bugün Hangi Moddasın?</h2>
                    <p style="color: var(--text-secondary);">Ruh haline uygun içerikleri senin için seçelim.</p>
                </div>
                <div class="mood-container">
                    ${this.moods.map(m => `
                        <div class="mood-btn" onclick="MoodSelector.selectMood('${m.id}')">
                            <div class="mood-emoji">${m.emoji}</div>
                            <div class="mood-label">${m.label}</div>
                        </div>
                    `).join('')}
                </div>
                <div id="mood-results" class="media-grid" style="margin-top: 30px; display: none;"></div>
            </div>
        `;
    },

    selectMood(moodId) {
        // UI Update
        document.querySelectorAll('.mood-btn').forEach(b => b.classList.remove('active'));
        event.currentTarget.classList.add('active');

        const mood = this.moods.find(m => m.id === moodId);
        if (!mood) return;

        // Filter Logic
        const allSeries = State.data.series || [];
        const filtered = allSeries.filter(s => {
            if (!s.genres) return false;
            // Check if any of series genres match mood genres
            return s.genres.some(g => mood.genres.includes(g));
        });

        // Sort Randomly for variety
        const randomized = filtered.sort(() => 0.5 - Math.random()).slice(0, 10);

        this.renderResults(randomized, mood);
    },

    renderResults(seriesList, mood) {
        const grid = document.getElementById('mood-results');
        grid.style.display = 'grid';

        if (seriesList.length === 0) {
            grid.innerHTML = `<p style="grid-column: 1/-1; text-align: center; color: #888;">"${mood.label}" moduna uygun içerik bulamadık. 😔</p>`;
            return;
        }

        grid.innerHTML = seriesList.map(item => App.renderCard(item)).join('');

        // Scroll to results
        grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
};

window.MoodSelector = MoodSelector;
