// Enhanced Comment System with Spoiler Protection
const EnhancedComments = {
    init() {
        console.log('💬 Enhanced Comment System initialized');
    },

    // Get up to 3 featured badges for display (selected by user or auto-picked)
    getFeaturedBadgesHTML(user) {
        if (!user) return '';

        const allBadges = user.badges || [];
        // Use user's selected displayBadges, or pick first 3
        let displayBadges = user.displayBadges || [];

        if (displayBadges.length === 0 && allBadges.length > 0) {
            // Auto-pick first 3, prioritizing VIP and admin badges
            const priorityOrder = ['VIP+', 'VIP', 'Admin', 'Yönetici', 'Moderatör', 'Çevirmen', '👑'];
            displayBadges = [...allBadges]
                .sort((a, b) => {
                    const aIdx = priorityOrder.indexOf(a);
                    const bIdx = priorityOrder.indexOf(b);
                    if (aIdx === -1 && bIdx === -1) return 0;
                    if (aIdx === -1) return 1;
                    if (bIdx === -1) return -1;
                    return aIdx - bIdx;
                })
                .slice(0, 3);
        } else {
            displayBadges = displayBadges.slice(0, 3);
        }

        return displayBadges.map(b => this.getBadgeHTML(b)).filter(Boolean).join('');
    },

    getBadgeHTML(badge) {
        const badgeMap = {
            'VIP': '<span class="modern-badge" title="VIP Üye" style="background: rgba(255, 215, 0, 0.1); border-color: rgba(255, 215, 0, 0.3); color: #ffd700;"><i class="fa-solid fa-crown"></i> VIP</span>',
            'VIP+': '<span class="modern-badge" title="VIP+ Üye" style="background: linear-gradient(135deg, #ffd700, #f59e0b); color: #000; font-weight: 800; border: none;"><i class="fa-solid fa-crown"></i> VIP+</span>',
            '👑': '<span class="modern-badge" title="VIP" style="padding: 4px 8px;">👑</span>',
            'Çevirmen': '<span class="modern-badge" title="Çevirmen" style="background: rgba(16, 185, 129, 0.1); border-color: rgba(16, 185, 129, 0.3); color: #10b981;"><i class="fa-solid fa-language"></i> Çevirmen</span>',
            'Admin': '<span class="modern-badge" title="Yönetici" style="background: rgba(239, 68, 68, 0.1); border-color: rgba(239, 68, 68, 0.3); color: #ef4444;"><i class="fa-solid fa-shield-halved"></i> Yönetici</span>',
            'Yönetici': '<span class="modern-badge" title="Yönetici" style="background: rgba(239, 68, 68, 0.1); border-color: rgba(239, 68, 68, 0.3); color: #ef4444;"><i class="fa-solid fa-shield-halved"></i> Yönetici</span>',
            'Moderatör': '<span class="modern-badge" title="Moderatör" style="background: rgba(139, 92, 246, 0.1); border-color: rgba(139, 92, 246, 0.3); color: #8b5cf6;"><i class="fa-solid fa-gavel"></i> Mod</span>',
            'Blogger': '<span class="modern-badge" title="Blogger" style="background: rgba(236, 72, 153, 0.1); border-color: rgba(236, 72, 153, 0.3); color: #ec4899;"><i class="fa-solid fa-pen-nib"></i> Blog</span>',
            'Onaylı': '<span class="modern-badge" title="Onaylı" style="background: rgba(59, 130, 246, 0.1); border-color: rgba(59, 130, 246, 0.3); color: #3b82f6;"><i class="fa-solid fa-circle-check"></i> Onaylı</span>',
            '💎': '<span class="modern-badge" title="Destekçi" style="padding: 4px 8px;">💎</span>',
            '🐲': '<span class="modern-badge" title="Efsane" style="padding: 4px 8px;">🐲</span>',
            '🐦': '<span class="modern-badge" title="Erken Kuş" style="padding: 4px 8px;">🐦</span>',
            '📺': '<span class="modern-badge" title="Maratoncu" style="padding: 4px 8px;">📺</span>',
            '🦋': '<span class="modern-badge" title="Sosyal Kelebek" style="padding: 4px 8px;">🦋</span>',
            '⭐': '<span class="modern-badge" title="Eleştirmen" style="padding: 4px 8px;">⭐</span>',
            '🏆': '<span class="modern-badge" title="OG Üye" style="padding: 4px 8px;">🏆</span>'
        };
        return badgeMap[badge] || (badge.length <= 2 ? `<span style="font-size:0.9em; margin-left:2px;">${badge}</span>` : '');
    },

    showCommentsSection(seriesId, episodeNumber = null) {
        const series = State.data.series.find(s => s.id === seriesId);
        if (!series) return;

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 900px; max-height: 90vh; overflow-y: auto;">
                <div class="modal-header">
                    <h2>💬 Yorumlar - ${series.title}</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body" id="modal-comments-container">
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        this.renderInline('modal-comments-container', seriesId, episodeNumber);
    },

    renderInline(containerId, seriesId, episodeNumber = null) {
        const container = document.getElementById(containerId);
        if (!container) return;

        let isSeries = true;
        let contentObj = null;

        if (seriesId.startsWith('actor_')) {
            isSeries = false;
        } else if (seriesId.startsWith('blog-')) {
            isSeries = false;
            contentObj = State.data.blogPosts.find(p => p.id === seriesId);
        } else {
            contentObj = State.data.series.find(s => s.id === seriesId);
            if (!contentObj) isSeries = false;
        }

        if (isSeries && !contentObj) return;

        container.innerHTML = `
            <!-- Episode Filter -->
            ${isSeries && contentObj ? (episodeNumber ? `
                <div style="background: var(--bg-secondary); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <strong>Bölüm ${episodeNumber}</strong> yorumları gösteriliyor
                    <button class="btn btn-outline btn-sm" onclick="EnhancedComments.renderInline('${containerId}', '${seriesId}', null)" style="margin-left: 10px;">
                        Tüm Yorumlar
                    </button>
                </div>
            ` : `
                <div class="form-group">
                    <label>Bölüm Filtrele</label>
                    <select id="episode-filter-${containerId}" class="form-select" onchange="EnhancedComments.renderInline('${containerId}', '${seriesId}', this.value || null)">
                        <option value="">Tüm Bölümler</option>
                        ${(contentObj.episodes || []).map(ep => `
                            <option value="${ep.number}">Bölüm ${ep.number}</option>
                        `).join('')}
                    </select>
                </div>
            `) : ''}

            <!-- Add Comment -->
            ${State.currentUser && State.currentUser.role !== 'guest' ? `
                <div class="add-comment-section" style="background: var(--bg-secondary); padding: 20px; border-radius: 12px; margin-bottom: 20px; position: relative;">
                    <h4>Yorum Ekle</h4>
                    <textarea id="comment-text-${containerId}" class="form-input" rows="4" placeholder="Yorumunuzu yazın..."></textarea>
                    
                    <!-- Emoji Picker Container -->
                    <div id="emoji-picker-${containerId}" style="display: none; position: absolute; bottom: 70px; left: 130px; background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 10px; z-index: 100; box-shadow: 0 4px 6px rgba(0,0,0,0.3); width: 250px;">
                        <div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 5px;">
                            ${this.getCommonEmojis().map(e => `<button onclick="EnhancedComments.insertAtCursor('${e}', 'comment-text-${containerId}')" style="font-size: 1.2rem; background: none; border: none; cursor: pointer; padding: 4px; border-radius: 4px; transition: background 0.1s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='transparent'">${e}</button>`).join('')}
                        </div>
                    </div>

                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 10px;">
                        <div style="display: flex; gap: 10px;">
                            <button class="btn btn-sm btn-secondary" onclick="document.getElementById('emoji-picker-${containerId}').style.display = document.getElementById('emoji-picker-${containerId}').style.display === 'none' ? 'block' : 'none'">
                                😀 Emoji
                            </button>
                            <label class="checkbox-label" style="display: flex; align-items: center; gap: 5px; cursor: pointer;">
                                <input type="checkbox" id="spoiler-check-${containerId}"> Spoiler içerir
                            </label>
                        </div>
                        <button class="btn btn-primary" onclick="EnhancedComments.postComment('${seriesId}', '${containerId}', '${episodeNumber || ''}')">
                            <i class="fa-solid fa-paper-plane"></i> Gönder
                        </button>
                    </div>
                </div>
            ` : `
                <div class="alert alert-info" style="margin-bottom: 20px;">
                    Yorum yapmak için <a href="javascript:void(0)" onclick="if(window.Auth) Auth.openLoginModal()" style="color: var(--accent-color); font-weight: bold;">giriş yapmalısınız</a>.
                </div>
            `}

            <!-- Comments List -->
            <div id="comments-list-${containerId}" class="comments-list">
                ${this.renderComments(seriesId, episodeNumber)}
            </div>
        `;

        // Attach autocomplete to comment textareas
        setTimeout(() => {
            const textarea = document.getElementById(`comment-text-${containerId}`);
            if (textarea && window.SocialFeed && SocialFeed.attachAutocomplete) {
                SocialFeed.attachAutocomplete(textarea);
            }
        }, 100);
    },


    getCommonEmojis() {
        return ['😂', '😭', '🥺', '😍', '🥰', '🤯', '😱', '😡', '🤢', '🤮', '🤧', '😷', '🥴', '🥳', '😎', '🤓', '🧐', '🤡', '👻', '💀', '👽', '👾', '🤖', '💩', '👍', '👎', '👊', '🤜', '🤛', '👏', '🙌', '👐', '🤲', '🤝', '🙏', '🔥', '✨', '🌟', '💫', '💥', '💢', '💦', '💧', '💤', '👋', '🤚', '🖐️', '✋'];
    },

    insertAtCursor(text, inputId = 'comment-text') {
        const textarea = document.getElementById(inputId);
        if (textarea) {
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const val = textarea.value;
            textarea.value = val.substring(0, start) + text + val.substring(end);
            textarea.selectionStart = textarea.selectionEnd = start + text.length;
            textarea.focus();
        }
    },

    insertTag(open, close, inputId = 'comment-text') {
        const textarea = document.getElementById(inputId);
        if (textarea) {
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const val = textarea.value;
            const selected = val.substring(start, end);
            const replacement = open + (selected || 'Metin') + close;
            textarea.value = val.substring(0, start) + replacement + val.substring(end);
            textarea.selectionStart = start + open.length;
            textarea.selectionEnd = start + open.length + (selected || 'Metin').length;
            textarea.focus();
        }
    },

    renderComments(seriesId, episodeNumber = null) {
        let contentObj = State.data.series.find(s => s.id === seriesId);
        if (!contentObj) {
            contentObj = State.data.blogPosts.find(p => p.id === seriesId);
        }
        
        // Merge comments from series object and global episodeComments for maximum visibility
        let allComments = (contentObj && contentObj.comments) ? [...contentObj.comments] : [];
        
        // Pull from legacy/global container if exists
        const legacyKey = episodeNumber ? `${seriesId}_ep${episodeNumber}` : null;
        if (State.data.episodeComments) {
            if (legacyKey && State.data.episodeComments[legacyKey]) {
                allComments = [...allComments, ...State.data.episodeComments[legacyKey]];
            } else if (!episodeNumber) {
                // If checking all comments for a series, collect all episode-specific ones too
                Object.keys(State.data.episodeComments).forEach(key => {
                    if (key.startsWith(seriesId + '_ep')) {
                        allComments = [...allComments, ...State.data.episodeComments[key]];
                    }
                });
            }
        }

        if (allComments.length === 0) {
            return '<p style="text-align: center; color: var(--text-secondary); padding: 40px;">Henüz yorum yok. İlk yorumu siz yapın!</p>';
        }

        // Deduplicate by ID
        const uniqueComments = Array.from(new Map(allComments.map(c => [c.id, c])).values());

        let filteredComments = uniqueComments;
        if (episodeNumber) {
            filteredComments = uniqueComments.filter(c => c.episode === parseInt(episodeNumber));
        }

        // Sort by votes (best first) or date
        filteredComments.sort((a, b) => (b.upvotes || 0) - (a.upvotes || 0) || (b.createdAt - a.createdAt));

        return filteredComments.map(comment => this.renderComment(comment, seriesId)).join('');
    },

    parseText(text) {
        if (!text) return '';
        
        // Escape HTML
        let clean = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

        // Parse hashtags (including Turkish characters)
        clean = clean.replace(/#([a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+)/g, '<span class="hashtag" onclick="SocialFeed.filterByTag(\'#$1\')" style="color: #a78bfa; font-weight: 600; cursor: pointer;">#$1</span>');

        // Parse mentions (including Turkish characters)
        clean = clean.replace(/@([a-zA-Z0-9ğüşıöçĞÜŞİÖÇ_]+)/g, '<span class="mention" onclick="App.navigate(\'social/profile/@$1\')" style="color: #3b82f6; font-weight: 600; cursor: pointer;">@$1</span>');

        // Parse [spoiler]...[/spoiler]
        clean = clean.replace(/\[spoiler\](.*?)\[\/spoiler\]/gis, '<span class="inline-spoiler" onclick="this.classList.toggle(\'revealed\')">$1</span>');

        // URL to links
        clean = clean.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" style="color:var(--accent-color); text-decoration:underline;">$1</a>');

        // New lines
        clean = clean.replace(/\n/g, '<br>');

        return clean;
    },

    renderComment(comment, seriesId, depth = 0) {
        const user = State.data.users.find(u => u.id === comment.userId);
        const upvotes = comment.upvotes || 0;
        const downvotes = comment.downvotes || 0;
        const score = upvotes - downvotes;
        const hasVoted = comment.voters?.includes(State.currentUser?.id);

        const marginLeft = Math.min(depth * 30, 120); // Cap indentation

        // Admin check
        const currentUser = State.currentUser;
        const isAdmin = currentUser && (currentUser.role === 'admin' || currentUser.badges?.includes('Yönetici') || currentUser.badges?.includes('Admin'));

        // Parse content
        const renderedText = this.parseText(comment.text);

        return `
            <div class="comment-item" style="background: var(--bg-secondary); padding: 15px; border-radius: 8px; margin-bottom: 15px; margin-left: ${marginLeft}px; border-left: ${depth > 0 ? '2px solid rgba(255,255,255,0.1)' : 'none'};">
                <style>
                    .inline-spoiler { background: #333; color: #333; border-radius: 4px; cursor: pointer; padding: 0 4px; user-select: none; transition: all 0.2s; }
                    .inline-spoiler:hover { background: #444; }
                    .inline-spoiler.revealed { background: rgba(255,255,0,0.1); color: inherit; user-select: text; border: 1px solid rgba(255,255,0,0.2); }
                </style>
                <div style="display: flex; gap: 15px;">
                    <div class="user-avatar-wrapper" style="width: 42px; height: 42px; display: flex; align-items:center; justify-content:center; cursor: pointer;" onclick="App.navigate('social/profile/@${user?.username}')">
                        ${window.UIExtensions ? UIExtensions.getAvatarHTML(user, 40) : `<img src="${user?.avatar || 'assets/logo.png'}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">`}
                    </div>
                    <div style="flex: 1;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <div>
                                <div onclick="App.navigate('social/profile/@${user?.username}')" style="cursor: pointer; display: inline-block;">
                                    ${window.UIExtensions ? UIExtensions.getNameHTML(user) : `<strong>${user?.username || 'Anonim'}</strong>`}
                                </div>
                                <span class="user-badges" style="display: inline-flex; gap: 5px; margin-left: 8px; vertical-align: middle;">
                                    ${this.getFeaturedBadgesHTML(user)}
                                </span>
                                ${comment.episode ? `<span style="color: var(--text-secondary); font-size: 0.85rem; margin-left: 10px;">Bölüm ${comment.episode}</span>` : ''}
                            </div>
                            <span style="color: var(--text-secondary); font-size: 0.85rem;">
                                ${new Date(comment.createdAt).toLocaleDateString('tr-TR')}
                            </span>
                        </div>

                        ${comment.spoiler ? `
                            <div>
                                <span class="spoiler-warning-text" style="color: #ef4444; font-size: 0.9rem; font-weight: bold; display: flex; align-items: center; gap: 5px; margin-bottom: 5px;">
                                    <i class="fa-solid fa-triangle-exclamation"></i> Spoiler Uyarısı
                                </span>
                                <div class="spoiler-content" onclick="this.classList.toggle('spoiler-revealed')" title="Görmek için tıklayın" style="filter: blur(8px); cursor: pointer; user-select: none; transition: filter 0.3s;">
                                    <p>${renderedText}</p>
                                </div>
                                <style>.spoiler-content.spoiler-revealed { filter: blur(0); user-select: text; }</style>
                            </div>
                        ` : `
                            <p style="white-space: pre-wrap; margin: 0; line-height: 1.5; color: #e2e8f0;">${renderedText}</p>
                        `}

                        <div style="display: flex; gap: 15px; margin-top: 10px; align-items: center;">
                            <div style="display: flex; gap: 5px; align-items: center;">
                                <button class="btn btn-sm btn-outline" onclick="EnhancedComments.voteComment('${seriesId}', '${comment.id}', 'up')" ${hasVoted ? 'disabled' : ''}>
                                    <i class="fa-solid fa-arrow-up"></i>
                                </button>
                                <span style="font-weight: 600; color: ${score > 0 ? '#10b981' : score < 0 ? '#ef4444' : 'var(--text-secondary)'};">
                                    ${score}
                                </span>
                                <button class="btn btn-sm btn-outline" onclick="EnhancedComments.voteComment('${seriesId}', '${comment.id}', 'down')" ${hasVoted ? 'disabled' : ''}>
                                    <i class="fa-solid fa-arrow-down"></i>
                                </button>
                            </div>
                            <button class="btn btn-sm btn-outline" onclick="EnhancedComments.replyToComment('${seriesId}', '${comment.id}')">
                                <i class="fa-solid fa-reply"></i> Yanıtla
                            </button>
                            
                            <!-- Delete and Report Buttons -->
                            <div style="margin-left: auto; display: flex; gap: 10px;">
                                ${isAdmin ? `
                                <button class="btn btn-sm btn-outline" onclick="EnhancedComments.deleteComment('${seriesId}', '${comment.id}')" style="color: #ef4444; border-color: rgba(239, 68, 68, 0.3);">
                                    <i class="fa-solid fa-trash"></i> Sil
                                </button>
                                ` : ''}
                                <button class="btn btn-sm btn-outline" onclick="EnhancedComments.reportComment('${comment.id}')" style="color: #f59e0b; border-color: rgba(245, 158, 11, 0.3);">
                                    <i class="fa-solid fa-flag"></i> Bildir
                                </button>
                            </div>
                        </div>

                        <!-- Reply Form Container -->
                        <div id="reply-form-${comment.id}" style="display: none; margin-top: 10px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 8px;">
                            <textarea id="reply-text-${comment.id}" class="form-input" rows="2" placeholder="Yanıtınızı yazın..." style="width: 100%; margin-bottom: 5px;"></textarea>
                            <div style="display: flex; justify-content: flex-end; gap: 5px;">
                                <button class="btn btn-sm btn-outline" onclick="document.getElementById('reply-form-${comment.id}').style.display = 'none'">İptal</button>
                                <button class="btn btn-sm btn-primary" onclick="EnhancedComments.submitReply('${seriesId}', '${comment.id}')">Yanıtla</button>
                            </div>
                        </div>

                        <!-- Replies -->
                        ${comment.replies && comment.replies.length > 0 ? `
                            <div style="margin-top: 15px;">
                                ${comment.replies.map(reply => this.renderComment(reply, seriesId, depth + 1)).join('')}
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    },

    deleteComment(seriesId, commentId) {
        if (!confirm('Bu yorumu silmek istediğinizden emin misiniz?')) return;
        const series = State.data.series.find(s => s.id === seriesId);
        if (series && series.comments) {
            series.comments = series.comments.filter(c => c.id !== commentId);
            db.save();
            Toast.success('Yorum silindi.');
            // Refresh comments
            this.showCommentsSection(seriesId); // For modal
            this.displayComments(series, 'docked-comments-list'); // For docked view
            this.displayComments(series, 'detail-comments-container'); // For detail view
        }
    },

    reportComment(commentId) {
        if (!State.currentUser) {
            Toast.error('Bildirmek için giriş yapmalısınız.');
            return;
        }

        this.showReportModal(commentId);
    },

    showReportModal(commentId) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 450px;">
                <div class="modal-header">
                    <h2>🚩 Yorum Bildir</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <p style="margin-bottom: 15px; color: var(--text-secondary);">Bu yorumu bildirme nedeninizi seçin:</p>
                    
                    <div class="form-group">
                        <select id="comment-report-reason" class="form-select">
                            <option value="spam">Spam / Reklam</option>
                            <option value="spoiler">İşaretlenmemiş Spoiler</option>
                            <option value="harassment">Hakaret / Taciz</option>
                            <option value="inappropriate">Uygunsuz İçerik</option>
                            <option value="other">Diğer</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <textarea id="comment-report-desc" class="form-input" rows="3" placeholder="Ek açıklama (isteğe bağlı)..."></textarea>
                    </div>

                    <button class="btn btn-primary" style="width: 100%;" onclick="EnhancedComments.submitReport('${commentId}')">
                        Bildirimi Gönder
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    submitReport(commentId) {
        const reason = document.getElementById('comment-report-reason').value;
        const description = document.getElementById('comment-report-desc').value.trim();

        if (window.AdminSupport) {
            AdminSupport.createSystemTicket({
                category: 'moderation',
                subject: `🚩 Yorum Bildirimi: ${reason}`,
                description: `**Neden:** ${reason}\n**Açıklama:** ${description || 'Belirtilmedi'}\n**Yorum ID:** ${commentId}`,
                priority: 'normal',
                metadata: {
                    reportType: 'comment',
                    commentId: commentId,
                    reason: reason,
                    reporterId: State.currentUser.id
                }
            });
            Toast.success('Bildiriminiz alındı. Teşekkürler.');
            document.querySelector('.modal').remove();
        } else {
            Toast.error('Sistem hatası: Destek modülü yüklenemedi.');
        }
    },

    async addComment(seriesId, episodeNumber) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Yorum yapmak için giriş yapmalısınız!');
            return;
        }

        const text = document.getElementById(`comment-text-${seriesId}`).value.trim();
        if (!text) {
            Toast.warning('Lütfen bir yorum yazın!');
            return;
        }

        const spoiler = document.getElementById(`spoiler-check-${seriesId}`)?.checked || false;

        const series = State.data.series.find(s => s.id === seriesId);
        if (series && !series.comments) series.comments = [];

        // Try to sync to cloud FIRST
        const res = await db.syncAction('comment-submit', { 
            seriesId: seriesId, 
            text: text, 
            episodeIndex: episodeNumber || 0,
            spoiler: spoiler 
        });

        if (res && res.success === false) {
            Toast.error(res.message || 'Yorum gönderilemedi. Kurallara aykırı kelime kullanımı tespit edildi.');
            return;
        }

        const finalComment = (res && res.comment) ? res.comment : {
            id: 'comment-' + Date.now(),
            userId: State.currentUser.id,
            text,
            spoiler,
            episode: episodeNumber ? parseInt(episodeNumber) : null,
            upvotes: 0,
            downvotes: 0,
            voters: [],
            replies: [],
            createdAt: Date.now()
        };

        if (series) {
            series.comments.push(finalComment);
        } else {
            // Might be blog or actor, ignore local push since it will be synced
        }

        if (typeof DailyQuests !== 'undefined') DailyQuests.updateProgress('comment_5');
        Toast.success('Yorum eklendi!');
        this.showCommentsSection(seriesId, episodeNumber);
    },

    voteComment(seriesId, commentId, type) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Oy vermek için giriş yapmalısınız!');
            return;
        }

        const series = State.data.series.find(s => s.id === seriesId);
        const comment = series.comments.find(c => c.id === commentId);

        if (comment.voters.includes(State.currentUser.id)) {
            Toast.warning('Bu yoruma zaten oy verdiniz!');
            return;
        }

        if (type === 'up') {
            comment.upvotes = (comment.upvotes || 0) + 1;
        } else {
            comment.downvotes = (comment.downvotes || 0) + 1;
        }

        comment.voters.push(State.currentUser.id);
        db.save();

        Toast.success('Oyunuz kaydedildi!');
        this.showCommentsSection(seriesId);
    },

    replyToComment(seriesId, commentId) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Yanıtlamak için giriş yapmalısınız!');
            return;
        }

        const formDiv = document.getElementById(`reply-form-${commentId}`);
        if (formDiv) {
            // Toggle form visibility
            formDiv.style.display = formDiv.style.display === 'none' ? 'block' : 'none';
            if (formDiv.style.display === 'block') {
                document.getElementById(`reply-text-${commentId}`).focus();
            }
        }
    },

    submitReply(seriesId, parentCommentId) {
        const text = document.getElementById(`reply-text-${parentCommentId}`).value.trim();
        if (!text) return;

        const series = State.data.series.find(s => s.id === seriesId);

        // Recursive helper to find parent comment
        const findComment = (comments) => {
            for (let c of comments) {
                if (c.id === parentCommentId) return c;
                if (c.replies) {
                    const found = findComment(c.replies);
                    if (found) return found;
                }
            }
            return null;
        };

        const parentComment = findComment(series.comments);
        if (parentComment) {
            if (!parentComment.replies) parentComment.replies = [];

            parentComment.replies.push({
                id: 'reply-' + Date.now(),
                userId: State.currentUser.id,
                text: text,
                spoiler: false,
                upvotes: 0,
                downvotes: 0,
                voters: [],
                replies: [],
                createdAt: Date.now()
            });

            // Sync to cloud
            db.syncAction('comment-submit', { 
                seriesId: seriesId, 
                text: text, 
                parentId: parentCommentId 
            });
            if (typeof DailyQuests !== 'undefined') DailyQuests.updateProgress('comment_5');

            // XP Reward
            if (window.Gamification) {
                Gamification.addXP(3, 'Cevap Gönderildi');
            }

            Toast.success('Yanıt gönderildi!');

            // Refresh logic - try simple re-render
            this.showCommentsSection(seriesId); // Refresh modal if open
            this.displayComments(series, 'docked-comments-list'); // Refresh dock
            this.displayComments(series, 'detail-comments-container'); // Refresh details
        }
    },

    insertEmoji() {
        const emojis = ['😊', '😂', '❤️', '👍', '🔥', '😍', '🎉', '👏', '😢', '😮'];
        const emoji = emojis[Math.floor(Math.random() * emojis.length)];
        const textarea = document.getElementById('comment-text');
        textarea.value += emoji;
    },

    insertGIF() {
        Toast.info('GIF ekleme özelliği yakında eklenecek! (Tenor API)');
    },
    displayComments(series, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const rulesHtml = `
        <div class="comments-rules" style="background: rgba(255, 165, 0, 0.1); border-left: 4px solid orange; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
            <h4 style="color: orange; margin-top:0; margin-bottom: 10px;">⚠️ Yorum Kuralları</h4>
            <ul style="font-size: 0.9rem; color: var(--text-secondary); margin: 0; padding-left: 20px;">
                <li>Saygılı olun ve hakaret içeren dil kullanmayın.</li>
                <li>Spoiler içeren yorumları mutlaka "Spoiler" olarak işaretleyin.</li>
                <li>Spam veya reklam içerikli yorumlar silinecektir.</li>
            </ul>
        </div>`;

        let formHtml = '';
        if (State.currentUser && State.currentUser.role !== 'guest') {
            formHtml = `
            <div class="add-comment-section" style="background: var(--bg-secondary); padding: 20px; border-radius: 12px; margin-bottom: 20px; position:relative;">
                <h4>Yorum Ekle</h4>
                <textarea id="docked-comment-text" class="form-input" rows="3" placeholder="Yorumunuzu yazın..."></textarea>
                <div style="display: flex; gap: 10px; margin-top: 10px; align-items: center;">
                    <label><input type="checkbox" id="docked-comment-spoiler"> Spoiler içeriyor</label>
                    <button class="btn btn-primary" onclick="EnhancedComments.addDockedComment('${series.id}')" style="margin-left: auto;">Gönder</button>
                </div>
            </div>`;
        } else {
            formHtml = `<div style="text-align:center; padding: 20px; background: var(--bg-secondary); border-radius: 8px;">Yorum yapmak için giriş yapmalısınız.</div>`;
        }

        container.innerHTML = rulesHtml + formHtml + `<div id="docked-comments-list">${this.renderComments(series.id)}</div>`;

        // Attach autocomplete to docked comment textarea
        setTimeout(() => {
            const textarea = document.getElementById('docked-comment-text');
            if (textarea && window.SocialFeed && SocialFeed.attachAutocomplete) {
                SocialFeed.attachAutocomplete(textarea);
            }
        }, 100);
    },

    async addDockedComment(seriesId) {
        if (!State.currentUser || State.currentUser.role === 'guest') return;
        const text = document.getElementById('docked-comment-text').value.trim();
        const spoiler = document.getElementById('docked-comment-spoiler').checked;

        if (!text) { Toast.warning('Yorum yazın!'); return; }

        const series = State.data.series.find(s => s.id === seriesId);
        if (!series.comments) series.comments = [];

        // Try to sync to cloud FIRST
        const res = await db.syncAction('comment-submit', { 
            seriesId: seriesId, 
            text: text, 
            spoiler: spoiler 
        });

        if (res && res.success === false) {
            Toast.error(res.message || 'Yorum gönderilemedi. Kurallara aykırı kelime kullanımı tespit edildi.');
            return;
        }

        const finalComment = (res && res.comment) ? res.comment : {
            id: 'cmt-' + Date.now(),
            userId: State.currentUser.id,
            text, spoiler, upvotes: 0, downvotes: 0, voters: [], replies: [], createdAt: Date.now()
        };

        series.comments.push(finalComment);
        db.save();

        if (typeof DailyQuests !== 'undefined') DailyQuests.updateProgress('comment_5');

        // XP Reward
        if (window.Gamification) {
            Gamification.addXP(5, 'Yorum Gönderildi');
            Gamification.checkDailyCommentBonus();
        }

        Toast.success('Yorum gönderildi!');
        document.getElementById('docked-comments-list').innerHTML = this.renderComments(seriesId);
        document.getElementById('docked-comment-text').value = '';
    },

    // New optimized postComment for inline updates without modal/refresh
    async postComment(seriesId, containerId, episodeNumber) {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Yorum yapmak için giriş yapmalısınız!');
            return;
        }

        const inputId = `comment-text-${containerId}`;
        const input = document.getElementById(inputId);
        const text = input ? input.value.trim() : '';

        if (!text) {
            Toast.warning('Lütfen bir yorum yazın!');
            return;
        }

        const spoilerCheck = document.getElementById(`spoiler-check-${containerId}`);
        const spoiler = spoilerCheck ? spoilerCheck.checked : false;

        let contentObj = State.data.series.find(s => s.id === seriesId);
        if (!contentObj) {
            contentObj = State.data.blogPosts.find(p => p.id === seriesId);
        }
        
        if (!contentObj) return;
        if (!contentObj.comments) contentObj.comments = [];

        // Sync to cloud FIRST
        const res = await db.syncAction('comment-submit', { 
            seriesId: seriesId, 
            text: text, 
            episodeIndex: episodeNumber || 0,
            spoiler: spoiler 
        });

        if (res && res.success === false) {
            Toast.error(res.message || 'Yorum gönderilemedi. Kurallara aykırı kelime kullanımı tespit edildi.');
            return;
        }

        const finalComment = (res && res.comment) ? res.comment : {
            id: 'comment-' + Date.now(),
            userId: State.currentUser.id,
            text,
            spoiler,
            episode: episodeNumber ? parseInt(episodeNumber) : null,
            upvotes: 0,
            downvotes: 0,
            voters: [],
            replies: [],
            createdAt: Date.now()
        };

        contentObj.comments.push(finalComment);

        db.save();

        if (typeof DailyQuests !== 'undefined') DailyQuests.updateProgress('comment_5');

        // XP Reward
        if (window.Gamification) {
            Gamification.addXP(5, 'Yorum Paylaşıldı');
            Gamification.checkDailyCommentBonus();
        }

        Toast.success('Yorum paylaşıldı!');

        // Clear input
        if (input) input.value = '';
        if (spoilerCheck) spoilerCheck.checked = false;

        // Update UI immediately
        const listContainer = document.getElementById(`comments-list-${containerId}`);
        if (listContainer) {
            listContainer.innerHTML = this.renderComments(seriesId, episodeNumber);
        }
    }
};

console.log('✅ Enhanced Comment System Module Loaded!');
window.EnhancedComments = EnhancedComments;
window.Comments = EnhancedComments;
