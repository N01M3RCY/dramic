const AutoEpisodeScheduler = {
    init() {
        // Only run for admins or moderators
        const user = State.currentUser;
        if (!user || (user.role !== 'admin' && user.role !== 'moderator')) {
            return;
        }

        console.log('🤖 Auto Episode Scheduler: Checking for new episodes...');
        this.checkAndAddEpisodes();

        // Sync calendar entries from active series broadcast days
        this.syncCalendarFromSeries();
    },

    async checkAndAddEpisodes() {
        if (!State.data || !State.data.series) return;

        const seriesList = State.data.series;
        const today = new Date();
        const todayDayIndex = today.getDay(); // 0 = Sunday, 1 = Monday...
        const daysMap = {
            'Pazar': 0, 'Pazartesi': 1, 'Salı': 2, 'Çarşamba': 3,
            'Perşembe': 4, 'Cuma': 5, 'Cumartesi': 6
        };

        let updatesMade = false;
        let addedSeriesNames = [];

        seriesList.forEach(series => {
            // 1. Check Status
            if (series.status !== 'Devam Ediyor') return;

            // 2. Check Broadcast Days
            if (!series.broadcastDays || series.broadcastDays.length === 0) return;

            // Check if today is a broadcast day
            const isBroadcastDay = series.broadcastDays.some(dayName => daysMap[dayName] === todayDayIndex);
            if (!isBroadcastDay) return;

            // 3. Get Episodes List
            let episodes = series.episodes || [];
            if (series.seasons && series.seasons.length > 0) {
                // If seasons exist, usually we add to the last season
                // For simplicity, let's assume flat episodes or handle first season
                // If complex season structure, we might skip or append to last season
                const lastSeason = series.seasons[series.seasons.length - 1];
                if (lastSeason && lastSeason.episodes) {
                    episodes = lastSeason.episodes;
                }
            }

            // 4. Check Last Episode Date to avoid duplicates
            // We want to add MAX one episode per day
            if (episodes.length > 0) {
                const lastEp = episodes[episodes.length - 1];
                const lastDate = new Date(lastEp.date || 0); // content saved date

                // Check if last episode was added TODAY
                if (this.isSameDay(today, lastDate)) {
                    // Already added today
                    return;
                }
            }

            // 5. Add New Episode
            const nextEpNumber = episodes.length + 1;

            // Create new episode object
            const newEpisode = {
                id: 'ep-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
                number: nextEpNumber,
                title: `${nextEpNumber}. Bölüm`,
                progress: 0, // 0% translation
                sources: [], // Empty sources
                date: new Date().toISOString()
            };

            // Push to array
            episodes.push(newEpisode);

            // Update Series "Last Updated"
            series.lastUpdated = Date.now();

            updatesMade = true;
            addedSeriesNames.push(series.title);
            console.log(`🤖 Auto-Added Episode ${nextEpNumber} to ${series.title}`);

            // 6. Sync calendar entry for today's broadcast day
            this.ensureCalendarEntry(series, nextEpNumber);
        });

        if (updatesMade) {
            try {
                // Determine save method
                if (typeof db !== 'undefined' && db.save) {
                    await db.save();
                    const msg = `Otomatik: ${addedSeriesNames.length} diziye yeni bölüm eklendi. (${addedSeriesNames.slice(0, 2).join(', ')}...)`;
                    if (window.Toast) Toast.info(msg);
                    console.log('🤖 Data saved successfully.');
                } else {
                    console.warn('🤖 db.save not found, cannot persist auto-episodes.');
                }
            } catch (err) {
                console.error('🤖 Failed to save auto-episodes:', err);
            }
        } else {
            console.log('🤖 No new episodes to add today.');
        }
    },

    /**
     * After adding an episode, ensure a calendar entry exists for
     * the series + today's broadcast day combination.
     */
    ensureCalendarEntry(series, episodeNumber) {
        if (!State.data.calendar) State.data.calendar = [];

        const daysMap = {
            'Pazar': 0, 'Pazartesi': 1, 'Salı': 2, 'Çarşamba': 3,
            'Perşembe': 4, 'Cuma': 5, 'Cumartesi': 6
        };
        const reverseDaysMap = {};
        for (const [name, idx] of Object.entries(daysMap)) {
            reverseDaysMap[idx] = name;
        }

        const todayDayIndex = new Date().getDay();
        const todayDayName = reverseDaysMap[todayDayIndex];

        if (!todayDayName) return;

        // Check if a calendar entry already exists for this series + day
        const existing = State.data.calendar.find(
            c => c.seriesId === series.id && c.day === todayDayName
        );

        if (existing) {
            // Update the episode number on the existing entry
            existing.episodeNumber = episodeNumber;
            console.log(`📅 Calendar updated for ${series.title} on ${todayDayName} → Ep ${episodeNumber}`);
        } else {
            // Create new calendar entry
            State.data.calendar.push({
                id: 'cal-' + Date.now(),
                seriesId: series.id,
                day: todayDayName,
                time: series.broadcastTime || '20:00',
                episodeNumber: episodeNumber
            });
            console.log(`📅 Calendar entry created for ${series.title} on ${todayDayName}`);
        }
    },

    /**
     * Syncs State.data.calendar from all active series broadcastDays.
     * - Ensures every active series with broadcastDays has calendar entries
     * - Removes stale entries for series that are no longer active
     */
    syncCalendarFromSeries() {
        if (!State.data || !State.data.series) return;
        if (!State.data.calendar) State.data.calendar = [];

        const seriesList = State.data.series;
        let changed = false;

        // 1. Build a set of active series IDs (status === 'Devam Ediyor' with broadcastDays)
        const activeSeriesMap = new Map();
        seriesList.forEach(series => {
            if (series.status === 'Devam Ediyor' && series.broadcastDays && series.broadcastDays.length > 0) {
                activeSeriesMap.set(series.id, series);
            }
        });

        // 2. Add missing calendar entries for active series
        activeSeriesMap.forEach((series, seriesId) => {
            series.broadcastDays.forEach(dayName => {
                const exists = State.data.calendar.some(
                    c => c.seriesId === seriesId && c.day === dayName
                );

                if (!exists) {
                    State.data.calendar.push({
                        id: 'cal-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
                        seriesId: seriesId,
                        day: dayName,
                        time: series.broadcastTime || '20:00',
                        episodeNumber: null
                    });
                    changed = true;
                    console.log(`📅 Sync: Added calendar entry for "${series.title}" on ${dayName}`);
                }
            });
        });

        // 3. Remove calendar entries for series that are no longer active
        const before = State.data.calendar.length;
        State.data.calendar = State.data.calendar.filter(entry => {
            // Keep if the series is still active and the day is still in broadcastDays
            const series = activeSeriesMap.get(entry.seriesId);
            if (!series) {
                console.log(`📅 Sync: Removed stale calendar entry for seriesId "${entry.seriesId}" (no longer active)`);
                return false;
            }
            if (!series.broadcastDays.includes(entry.day)) {
                console.log(`📅 Sync: Removed calendar entry for "${series.title}" on ${entry.day} (day removed from broadcast)`);
                return false;
            }
            return true;
        });
        if (State.data.calendar.length !== before) changed = true;

        // 4. Persist if changes were made
        if (changed) {
            console.log('📅 Calendar sync complete — saving changes.');
            if (typeof db !== 'undefined' && db.save) {
                db.save();
            }
        } else {
            console.log('📅 Calendar already in sync.');
        }
    },

    /**
     * Removes all calendar entries for a given series.
     * Useful when a series is deleted or manually deactivated.
     */
    removeSeriesFromCalendar(seriesId) {
        if (!State.data || !State.data.calendar) return;

        const before = State.data.calendar.length;
        State.data.calendar = State.data.calendar.filter(entry => entry.seriesId !== seriesId);
        const removed = before - State.data.calendar.length;

        if (removed > 0) {
            console.log(`📅 Removed ${removed} calendar entry/entries for series "${seriesId}".`);
            if (typeof db !== 'undefined' && db.save) {
                db.save();
            }
            if (window.Toast) Toast.info(`Takvimden ${removed} giriş kaldırıldı.`);
        }
    },

    isSameDay(d1, d2) {
        return d1.getFullYear() === d2.getFullYear() &&
            d1.getMonth() === d2.getMonth() &&
            d1.getDate() === d2.getDate();
    }
};

// Expose
window.AutoEpisodeScheduler = AutoEpisodeScheduler;
