// ============================================
// BLOG MANAGEMENT & DETAILED STATISTICS
// ============================================

const BlogManagement = {
    categories: ['Haberler', 'İncelemeler', 'Teoriler', 'Analizler', 'Röportajlar', 'Listeler'],

    // Show blogger's own blog management
    showMyBlogs() {
        if (!State.currentUser) {
            Toast.warning("Giriş yapmalısınız!");
            return;
        }

        const canBlog = State.currentUser.badges?.includes('Blogger') ||
            State.currentUser.badges?.includes('Yönetici');

        if (!canBlog) {
            Toast.error("Blog yazmak için 'Blogger' rozetine sahip olmalısınız!");
            return;
        }

        const myPosts = BlogSystem.posts.filter(p => p.authorId === State.currentUser.id);

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 900px;">
                <div class="modal-header">
                    <h2>Bloglarım</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div style="padding: 25px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
                        <h3>Toplam ${myPosts.length} blog yazınız var</h3>
                        <button class="btn btn-primary" onclick="ViewManager.showView('blog'); BlogEditor.showEditor(); this.closest('.modal').remove();">
                            <i class="fa-solid fa-plus"></i> Yeni Blog Yaz
                        </button>
                    </div>

                    <div class="my-blogs-list">
                        ${myPosts.length === 0 ? '<p style="color: var(--text-secondary); text-align: center; padding: 40px;">Henüz blog yazınız yok.</p>' :
                myPosts.map(post => `
                                <div class="my-blog-item">
                                    <div class="my-blog-info">
                                        ${post.coverImage ? `<img src="${post.coverImage}" class="my-blog-thumb">` : ''}
                                        <div>
                                            <h4>${post.title}</h4>
                                            <div class="my-blog-meta">
                                                <span><i class="fa-solid fa-heart"></i> ${post.likes || 0}</span>
                                                <span><i class="fa-solid fa-comment"></i> ${post.comments?.length || 0}</span>
                                                <span><i class="fa-solid fa-calendar"></i> ${new Date(post.createdAt).toLocaleDateString('tr-TR')}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="my-blog-actions">
                                        <button class="btn btn-sm btn-outline" onclick="BlogManagement.editBlog('${post.id}')">
                                            <i class="fa-solid fa-edit"></i> Düzenle
                                        </button>
                                        <button class="btn btn-sm btn-outline" onclick="BlogManagement.deleteBlog('${post.id}')">
                                            <i class="fa-solid fa-trash"></i> Sil
                                        </button>
                                    </div>
                                </div>
                            `).join('')
            }
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    editBlog(postId) {
        Toast.info("Blog düzenleme özelliği yakında eklenecek!");
    },

    deleteBlog(postId) {
        if (!confirm('Bu blog yazısını silmek istediğinizden emin misiniz?')) return;

        const index = BlogSystem.posts.findIndex(p => p.id === postId);
        if (index > -1) {
            BlogSystem.posts.splice(index, 1);
            localStorage.setItem('blog_posts', JSON.stringify(BlogSystem.posts));
            Toast.success("Blog yazısı silindi!");
            this.showMyBlogs();
        }
    }
};

// DETAILED STATISTICS
const DetailedStatistics = {
    generateDetailedStats() {
        if (!State.currentUser) return null;

        const history = State.currentUser.watchHistory || [];
        const watchTime = WatchTimeTracker.getTotalWatchTime();

        // Genre breakdown
        const genreStats = {};
        history.forEach(h => {
            const series = db.getSeries(h.seriesId);
            if (series && series.genre) {
                if (!genreStats[series.genre]) {
                    genreStats[series.genre] = { count: 0, minutes: 0 };
                }
                genreStats[series.genre].count++;
                genreStats[series.genre].minutes += h.duration || 0;
            }
        });

        // Watching patterns
        const hourStats = {};
        history.forEach(h => {
            const hour = new Date(h.watchedAt).getHours();
            hourStats[hour] = (hourStats[hour] || 0) + 1;
        });

        const mostActiveHour = Object.keys(hourStats).reduce((a, b) =>
            hourStats[a] > hourStats[b] ? a : b, null
        );

        // Day of week stats
        const dayStats = {};
        const dayNames = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
        history.forEach(h => {
            const day = new Date(h.watchedAt).getDay();
            dayStats[day] = (dayStats[day] || 0) + 1;
        });

        const mostActiveDay = Object.keys(dayStats).reduce((a, b) =>
            dayStats[a] > dayStats[b] ? a : b, null
        );

        // Completion rate
        const watchlist = State.currentUser.watchlist || [];
        const completedSeries = watchlist.filter(sid => {
            const series = db.getSeries(sid);
            if (!series || !series.episodes) return false;

            const watchedEpisodes = history.filter(h => h.seriesId === sid).length;
            return watchedEpisodes >= series.episodes.length;
        });

        const completionRate = watchlist.length > 0
            ? Math.round((completedSeries.length / watchlist.length) * 100)
            : 0;

        // Average watch time per day
        const firstWatch = history.length > 0 ? Math.min(...history.map(h => h.watchedAt)) : Date.now();
        const daysSinceFirst = Math.max(1, Math.floor((Date.now() - firstWatch) / (1000 * 60 * 60 * 24)));
        const avgMinutesPerDay = Math.round(watchTime.minutes / daysSinceFirst);

        return {
            totalWatchTime: watchTime,
            episodesWatched: history.length,
            genreStats: genreStats,
            mostActiveHour: mostActiveHour ? `${mostActiveHour}:00` : 'Bilinmiyor',
            mostActiveDay: mostActiveDay ? dayNames[mostActiveDay] : 'Bilinmiyor',
            completionRate: completionRate,
            avgWatchTimePerDay: WatchTimeTracker.formatWatchTime(avgMinutesPerDay),
            seriesInWatchlist: watchlist.length,
            completedSeries: completedSeries.length
        };
    },

    showDetailedStats() {
        const stats = this.generateDetailedStats();
        if (!stats) {
            Toast.warning("İstatistik oluşturulamadı!");
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 1000px;">
                <div class="modal-header">
                    <h2>📊 Detaylı İstatistikler</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div style="padding: 30px;">
                    <!-- Main Stats -->
                    <div class="stats-grid-modern">
                        <div class="stat-card-modern">
                            <div class="stat-icon-modern" style="background: linear-gradient(135deg, #7c3aed, #a78bfa);">
                                <i class="fa-solid fa-clock"></i>
                            </div>
                            <div class="stat-details">
                                <div class="stat-value-modern">${stats.totalWatchTime.formatted}</div>
                                <div class="stat-label-modern">Toplam İzleme Süresi</div>
                            </div>
                        </div>

                        <div class="stat-card-modern">
                            <div class="stat-icon-modern" style="background: linear-gradient(135deg, #10b981, #34d399);">
                                <i class="fa-solid fa-play-circle"></i>
                            </div>
                            <div class="stat-details">
                                <div class="stat-value-modern">${stats.episodesWatched}</div>
                                <div class="stat-label-modern">İzlenen Bölüm</div>
                            </div>
                        </div>

                        <div class="stat-card-modern">
                            <div class="stat-icon-modern" style="background: linear-gradient(135deg, #f59e0b, #fbbf24);">
                                <i class="fa-solid fa-percentage"></i>
                            </div>
                            <div class="stat-details">
                                <div class="stat-value-modern">%${stats.completionRate}</div>
                                <div class="stat-label-modern">Tamamlama Oranı</div>
                            </div>
                        </div>

                        <div class="stat-card-modern">
                            <div class="stat-icon-modern" style="background: linear-gradient(135deg, #ef4444, #f87171);">
                                <i class="fa-solid fa-chart-line"></i>
                            </div>
                            <div class="stat-details">
                                <div class="stat-value-modern">${stats.avgWatchTimePerDay}</div>
                                <div class="stat-label-modern">Günlük Ortalama</div>
                            </div>
                        </div>
                    </div>

                    <!-- Genre Breakdown -->
                    <div class="stats-section">
                        <h3>Tür Dağılımı</h3>
                        <div class="genre-stats-list">
                            ${Object.entries(stats.genreStats).map(([genre, data]) => `
                                <div class="genre-stat-item">
                                    <div class="genre-stat-name">${genre}</div>
                                    <div class="genre-stat-bar">
                                        <div class="genre-stat-fill" style="width: ${(data.count / stats.episodesWatched) * 100}%"></div>
                                    </div>
                                    <div class="genre-stat-value">${data.count} bölüm (${WatchTimeTracker.formatWatchTime(data.minutes)})</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>

                    <!-- Watching Patterns -->
                    <div class="stats-section">
                        <h3>İzleme Alışkanlıkları</h3>
                        <div class="pattern-stats">
                            <div class="pattern-stat">
                                <i class="fa-solid fa-clock"></i>
                                <div>
                                    <strong>En Aktif Saat</strong>
                                    <p>${stats.mostActiveHour}</p>
                                </div>
                            </div>
                            <div class="pattern-stat">
                                <i class="fa-solid fa-calendar"></i>
                                <div>
                                    <strong>En Aktif Gün</strong>
                                    <p>${stats.mostActiveDay}</p>
                                </div>
                            </div>
                            <div class="pattern-stat">
                                <i class="fa-solid fa-list"></i>
                                <div>
                                    <strong>Listemde</strong>
                                    <p>${stats.seriesInWatchlist} dizi</p>
                                </div>
                            </div>
                            <div class="pattern-stat">
                                <i class="fa-solid fa-check-circle"></i>
                                <div>
                                    <strong>Tamamlanan</strong>
                                    <p>${stats.completedSeries} dizi</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }
};

console.log('✅ Blog Management & Detailed Statistics Loaded!');
