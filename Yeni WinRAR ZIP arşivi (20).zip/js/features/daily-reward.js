const DailyReward = {
    prizes: [
        { id: 1, text: '50 Coin', type: 'coin', amount: 50, chance: 30, color: '#a855f7' },
        { id: 2, text: '100 Coin', type: 'coin', amount: 100, chance: 20, color: '#3b82f6' },
        { id: 3, text: '50 XP', type: 'xp', amount: 50, chance: 25, color: '#22c55e' },
        { id: 4, text: '250 Coin', type: 'coin', amount: 250, chance: 10, color: '#eab308' },
        { id: 5, text: '500 XP', type: 'xp', amount: 500, chance: 5, color: '#f97316' },
        { id: 6, text: 'JACKPOT', type: 'coin', amount: 1000, chance: 1, color: '#ef4444' },
        { id: 7, text: 'Pas', type: 'none', amount: 0, chance: 9, color: '#64748b' },
    ],

    init() {
        console.log('🎡 Daily Reward initialized');
    },

    canSpin() {
        if (!State.currentUser) return false;
        const lastSpin = parseInt(localStorage.getItem(`last_spin_${State.currentUser.id}`) || '0');
        const now = Date.now();
        // 2 hours in ms
        return (now - lastSpin) > (2 * 60 * 60 * 1000);
    },

    getRemainingTime() {
        if (!State.currentUser) return '';
        const lastSpin = parseInt(localStorage.getItem(`last_spin_${State.currentUser.id}`) || '0');
        const now = Date.now();
        const diff = (2 * 60 * 60 * 1000) - (now - lastSpin);

        if (diff <= 0) return 'DÖNDÜR!';

        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        return `${hours}s ${minutes}dk`;
    },

    show() {
        console.log('🎡 Daily login rewards are disabled per user request. Use the 12-Hour Chest system on your profile instead.');
    },

    claimSilent() {
        // Deactivated per user request.
        return;
    },

    claimPrize(prize) {
        // Deactivated.
        return;
    }
};

window.DailyReward = DailyReward;

