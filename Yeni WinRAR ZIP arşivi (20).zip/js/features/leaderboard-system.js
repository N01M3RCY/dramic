/**
 * DRAMICBOX - LEADERBOARD SYSTEM
 * Handles global rankings for users based on XP, Coins, and Activity.
 */

const LeaderboardSystem = {
    init() {
        console.log('🏆 Leaderboard System Loaded');
        this.injectStyles();
    },

    injectStyles() {
        if (document.getElementById('lb-styles')) return;
        const style = document.createElement('style');
        style.id = 'lb-styles';
        style.textContent = `
            .leaderboard-modal .modal-content {
                background: #0f172a !important;
                border: 1px solid rgba(139, 92, 246, 0.3);
                box-shadow: 0 0 50px rgba(139, 92, 246, 0.2);
                border-radius: 24px;
                max-width: 800px !important;
                overflow: hidden;
            }
            .lb-tab {
                background: rgba(255,255,255,0.03);
                border: 1px solid rgba(255,255,255,0.06);
                color: #94a3b8;
                padding: 10px 25px;
                border-radius: 12px;
                font-weight: 700;
                cursor: pointer;
                transition: all 0.3s;
            }
            .lb-tab.active {
                background: #8b5cf6;
                color: white;
                box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
            }
            .lb-podium {
                display: flex;
                align-items: flex-end;
                justify-content: center;
                gap: 20px;
                padding: 40px 0;
            }
            .podium-item {
                display: flex;
                flex-direction: column;
                align-items: center;
                transition: all 0.3s;
                width: 140px;
            }
            .podium-avatar {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                object-fit: cover;
                border: 3px solid #fff;
            }
            .rank-1 .podium-avatar { width: 110px; height: 110px; border-color: #ffd700; box-shadow: 0 0 20px rgba(255, 215, 0, 0.3); }
            .rank-2 .podium-avatar { width: 90px; height: 90px; border-color: #c0c0c0; }
            .rank-3 .podium-avatar { width: 85px; height: 85px; border-color: #cd7f32; }
            
            .lb-row {
                display: flex;
                align-items: center;
                padding: 15px 20px;
                background: rgba(255,255,255,0.02);
                border-radius: 16px;
                margin-bottom: 10px;
                border: 1px solid rgba(255,255,255,0.05);
                transition: all 0.2s;
            }
            .lb-row:hover {
                background: rgba(255,255,255,0.04);
                transform: translateX(5px);
            }
            .lb-rank { font-size: 1.2rem; font-weight: 900; margin-right: 20px; width: 40px; }
            .lb-user { flex: 1; display: flex; align-items: center; gap: 15px; }
            .lb-value { font-weight: 800; color: #a78bfa; font-size: 1.1rem; }
        `;
        document.head.appendChild(style);
    },

    open() {
        const modal = document.createElement('div');
        modal.className = 'modal leaderboard-modal';
        modal.id = 'leaderboard-modal';
        modal.style.display = 'flex';

        modal.innerHTML = `
            <div class="modal-content leaderboard-container">
                <div class="leaderboard-header" style="background: linear-gradient(135deg, #1e293b, #0f172a); padding: 40px; position: relative;">
                    <div class="leaderboard-title" style="font-size: 2.2rem; font-weight: 900; text-align: center; color: #fff;">
                        <i class="fa-solid fa-trophy" style="color:#ffd700"></i> LİDERLİK TABLOSU
                    </div>
                    <button class="modal-close" onclick="LeaderboardSystem.close()" style="position:absolute; top:30px; right:30px;">×</button>
                </div>
                
                <div class="leaderboard-tabs" style="display: flex; justify-content: center; gap: 10px; padding: 20px; background: rgba(0,0,0,0.2);">
                    <button class="lb-tab active" data-tab="xp" onclick="LeaderboardSystem.switchTab('xp')">Seviye</button>
                    <button class="lb-tab" data-tab="coins" onclick="LeaderboardSystem.switchTab('coins')">Coin</button>
                    <button class="lb-tab" data-tab="active" onclick="LeaderboardSystem.switchTab('active')">Aktivite</button>
                </div>
                
                <div class="leaderboard-body" style="padding: 30px; max-height: 60vh; overflow-y: auto;">
                    <div class="lb-podium" id="lb-podium">
                        <!-- Top 3 -->
                    </div>
                    <div class="lb-list" id="lb-list">
                        <!-- List -->
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        this.render('xp');
    },


    close() {
        const modal = document.getElementById('leaderboard-modal');
        if (modal) modal.remove();
    },

    switchTab(tab) {
        document.querySelectorAll('.lb-tab').forEach(t => t.classList.remove('active'));
        document.querySelector(`.lb-tab[data-tab="${tab}"]`).classList.add('active');
        this.render(tab);
    },

    render(criteria) {
        const podium = document.getElementById('lb-podium');
        const list = document.getElementById('lb-list');
        if (!podium || !list) return;

        // Get and sort users
        let users = [...(State.data.users || [])];

        if (criteria === 'xp') {
            users.sort((a, b) => (b.stats?.xp || 0) - (a.stats?.xp || 0));
        } else if (criteria === 'coins') {
            users.sort((a, b) => (b.stats?.coins || 0) - (a.stats?.coins || 0));
        } else if (criteria === 'active') {
            users.sort((a, b) => (b.watchHistory?.length || 0) - (a.watchHistory?.length || 0));
        }

        const top3 = users.slice(0, 3);
        const others = users.slice(3, 10);

        // Render Podium
        podium.innerHTML = this.renderPodium(top3, criteria);

        // Render List
        list.innerHTML = others.map((u, i) => this.renderListRow(u, i + 4, criteria)).join('');
    },

    renderPodium(topUsers, criteria) {
        // Rearrange for visual hierarchy: 2, 1, 3
        const order = [1, 0, 2];
        const podiumItems = order.map(idx => {
            const user = topUsers[idx];
            if (!user) return '<div class="podium-empty" style="flex:1;"></div>';

            const rank = idx + 1;
            const val = this.getVal(user, criteria);
            const activeFrame = user.activeFrame ? ShopSystem.items.frames.find(f => f.id === user.activeFrame)?.class : '';
            const activeGlow = user.activeGlow ? ShopSystem.items.glows.find(g => g.id === user.activeGlow)?.class : '';
            
            const medalColor = rank === 1 ? '#ffd700' : rank === 2 ? '#c0c0c0' : '#cd7f32';
            const scale = rank === 1 ? '1.2' : rank === 2 ? '1.1' : '1';

            return `
                <div class="podium-item rank-${rank}" style="transform: scale(${scale});">
                    <div class="podium-avatar-container" style="position: relative;">
                        <div class="podium-rank-badge" style="background: ${medalColor}; border: 2px solid #0f0f13; box-shadow: 0 4px 10px rgba(0,0,0,0.3);">${rank}</div>
                        <div class="user-avatar-wrapper ${activeFrame}" style="padding: ${activeFrame ? '5px' : '2px'}; border-radius: 50%; background: ${rank === 1 ? 'rgba(255,215,0,0.1)' : 'transparent'};">
                            <img src="${user.avatar || 'assets/logo.png'}" class="podium-avatar" style="border: 3px solid ${rank === 1 ? '#ffd700' : 'rgba(255,255,255,0.1)'};">
                        </div>
                        ${rank === 1 ? '<i class="fa-solid fa-crown" style="position: absolute; top: -15px; left: 50%; transform: translateX(-50%) rotate(-15deg); color: #ffd700; font-size: 1.2rem; filter: drop-shadow(0 0 5px rgba(255,215,0,0.5));"></i>' : ''}
                    </div>
                    <div class="podium-name ${activeGlow}" style="margin-top: 12px; font-weight: 800; font-size: ${rank === 1 ? '1rem' : '0.9rem'};">${user.username}</div>
                    <div class="podium-value" style="color: ${medalColor}; font-weight: 700;">${val}</div>
                </div>
            `;
        });

        return podiumItems.join('');
    },

    renderListRow(user, rank, criteria) {
        const val = this.getVal(user, criteria);
        const activeFrame = user.activeFrame ? ShopSystem.items.frames.find(f => f.id === user.activeFrame)?.class : '';
        const activeGlow = user.activeGlow ? ShopSystem.items.glows.find(g => g.id === user.activeGlow)?.class : '';
        
        // Dynamic color for top 10
        const rankColor = rank <= 5 ? '#a78bfa' : '#64748b';
        const isSelf = user.id === State.currentUser?.id;

        return `
            <div class="lb-row" style="${isSelf ? 'background: rgba(124, 58, 237, 0.1); border-left: 3px solid #7c3aed;' : ''}">
                <div class="lb-rank" style="color: ${rankColor}; font-weight: 800;">#${rank}</div>
                <div class="lb-user">
                    <div class="user-avatar-wrapper ${activeFrame}" style="width: 40px; height: 40px; padding: ${activeFrame ? '2px' : '0'}; border-radius: 50%; position: relative;">
                        <img src="${user.avatar || 'assets/logo.png'}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover; border: 2px solid rgba(255,255,255,0.05);">
                        ${user.isPremium ? '<div style="position:absolute; bottom:-2px; right:-2px; background:#f59e0b; width:14px; height:14px; border-radius:50%; display:flex; items-center; justify-center; border:2px solid #0f0f13;"><i class="fa-solid fa-crown" style="font-size:7px; color:#fff;"></i></div>' : ''}
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 2px;">
                        <span class="lb-username ${activeGlow}" style="font-weight: 700; color: ${isSelf ? '#fff' : '#e2e8f0'};">${user.username}</span>
                        <div style="display: flex; gap: 4px; flex-wrap: wrap;">
                            ${(user.badges || []).slice(0, 3).map(b => `<span style="font-size: 9px; padding: 1px 6px; border-radius: 4px; background: rgba(167, 139, 250, 0.1); color: #a78bfa; font-weight: 600;">${b}</span>`).join('')}
                        </div>
                    </div>
                </div>
                <div class="lb-value" style="font-weight: 700; color: #fff;">${val}</div>
            </div>
        `;
    },

    getVal(user, criteria) {
        if (criteria === 'xp') return `Seviye ${Gamification.getLevel(user.stats?.xp || 0)}`;
        if (criteria === 'coins') return `<i class="fa-solid fa-coins" style="color:#ffd700"></i> ${user.stats?.coins || 0}`;
        if (criteria === 'active') return `<i class="fa-solid fa-eye"></i> ${user.watchHistory?.length || 0} İzleme`;
        return '';
    }
};

window.LeaderboardSystem = LeaderboardSystem;
