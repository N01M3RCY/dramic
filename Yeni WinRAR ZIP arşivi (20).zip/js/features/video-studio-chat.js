const VideoStudioChat = {
    isOpen: false,
    pollInterval: null,
    messages: [],
    context: {},

    init(context) {
        this.context = context;
        this.render();
        this.startPolling();
        console.log('💬 VideoStudioChat initialized');
    },

    toggle() {
        this.isOpen = !this.isOpen;
        const panel = document.getElementById('vs-chat-panel');
        if (panel) {
            panel.style.display = this.isOpen ? 'flex' : 'none';
            if (this.isOpen) {
                this.scrollToBottom();
                const badge = document.getElementById('vs-chat-badge');
                if (badge) badge.style.display = 'none'; // Clear notification
            }
        }
    },

    render() {
        // Find a place to inject. Ideally right side or floating.
        // We'll inject into the main studio container
        const root = document.querySelector('.video-studio-page');
        if (!root) return;

        const container = document.createElement('div');
        container.id = 'vs-chat-panel';
        container.style.cssText = 'position: absolute; top: 60px; right: 20px; width: 320px; height: 500px; background: #16191f; border: 1px solid #1e293b; border-radius: 12px; display: none; flex-direction: column; z-index: 1000; box-shadow: 0 10px 25px rgba(0,0,0,0.5);';

        container.innerHTML = `
            <div style="padding: 12px 16px; border-bottom: 1px solid #1e293b; display: flex; justify-content: space-between; align-items: center; background: #0f1115; border-radius: 12px 12px 0 0;">
                <div style="font-weight: 700; color: #e2e8f0; font-size: 14px;">
                    <i class="fa-solid fa-comments" style="color: #8b5cf6; margin-right: 8px;"></i> Ekip Sohbeti
                </div>
                <button onclick="VideoStudioChat.toggle()" style="background: none; border: none; color: #64748b; cursor: pointer;">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            
            <div id="vs-chat-messages" style="flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 12px;">
                <!-- Messages go here -->
                <div style="text-align: center; color: #475569; font-size: 12px; margin-top: 20px;">Sohbet yükleniyor...</div>
            </div>

            <div style="padding: 12px; border-top: 1px solid #1e293b; background: #0f1115; border-radius: 0 0 12px 12px;">
                <form onsubmit="VideoStudioChat.sendMessage(event)" style="display: flex; gap: 8px;">
                    <input type="text" id="vs-chat-input" placeholder="Mesaj yaz..." style="flex: 1; background: #1e293b; border: 1px solid #334155; border-radius: 6px; padding: 8px; color: white; font-size: 13px; outline: none;">
                    <button type="submit" style="width: 36px; height: 36px; background: #8b5cf6; border: none; border-radius: 6px; color: white; cursor: pointer; display: flex; align-items: center; justify-content: center;">
                        <i class="fa-solid fa-paper-plane" style="font-size: 12px;"></i>
                    </button>
                </form>
            </div>
        `;

        root.appendChild(container);

        // Add Toggle Button to Header if not exists
        const headerRight = document.querySelector('header > div:last-child'); // The button group
        if (headerRight) {
            const btn = document.createElement('button');
            btn.onclick = () => this.toggle();
            btn.style.cssText = 'width: 36px; height: 36px; border-radius: 6px; background: transparent; border: 1px solid #334155; color: #e2e8f0; cursor: pointer; display: flex; align-items: center; justify-content: center; position: relative; margin-right: 8px;';
            btn.innerHTML = `
                <i class="fa-regular fa-comment-dots"></i>
                <div id="vs-chat-badge" style="position: absolute; top: -4px; right: -4px; width: 8px; height: 8px; background: #ef4444; border-radius: 50%; display: none;"></div>
            `;
            headerRight.insertBefore(btn, headerRight.firstChild);
        }
    },

    startPolling() {
        this.fetchMessages();
        this.pollInterval = setInterval(() => this.fetchMessages(), 3000);
    },

    stopPolling() {
        if (this.pollInterval) clearInterval(this.pollInterval);
    },

    async fetchMessages() {
        try {
            const res = await fetch(`api/db.php?action=studio-chat-get&seriesId=${this.context.seriesId}&episodeNumber=${this.context.episodeNumber}`);
            const data = await res.json();

            if (data.success) {
                const prevLength = this.messages.length;
                this.messages = data.messages || [];

                if (this.messages.length > prevLength) {
                    this.renderMessages();
                    if (!this.isOpen && prevLength > 0) {
                        const badge = document.getElementById('vs-chat-badge');
                        if (badge) badge.style.display = 'block';
                    } else {
                        this.scrollToBottom();
                    }
                }
            }
        } catch (e) {
            console.error('Chat poll error:', e);
        }
    },

    sendMessage(e) {
        e.preventDefault();
        const input = document.getElementById('vs-chat-input');
        const text = input.value.trim();
        if (!text) return;

        input.value = '';

        fetch('api/db.php?action=studio-chat-send', {
            method: 'POST',
            body: JSON.stringify({
                seriesId: this.context.seriesId,
                episodeNumber: this.context.episodeNumber,
                message: text,
                user: State.currentUser || { username: 'Guest' }
            })
        }).then(() => this.fetchMessages());
    },

    renderMessages() {
        const list = document.getElementById('vs-chat-messages');
        if (!list) return;

        if (this.messages.length === 0) {
            list.innerHTML = '<div style="text-align: center; color: #475569; font-size: 12px; margin-top: 20px;">Henüz mesaj yok.</div>';
            return;
        }

        const currentUsername = State.currentUser?.username || 'Guest';

        list.innerHTML = this.messages.map(msg => {
            const isMe = msg.user.username === currentUsername;
            return `
                <div style="display: flex; flex-direction: column; align-items: ${isMe ? 'flex-end' : 'flex-start'};">
                    <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 2px;">
                        <span style="font-size: 10px; color: #64748b; font-weight: 700;">${msg.user.username}</span>
                        <span style="font-size: 9px; color: #475569;">${this.formatTime(msg.timestamp)}</span>
                    </div>
                    <div style="background: ${isMe ? '#8b5cf6' : '#1e293b'}; color: ${isMe ? 'white' : '#cbd5e1'}; padding: 8px 12px; border-radius: ${isMe ? '12px 12px 0 12px' : '12px 12px 12px 0'}; font-size: 13px; max-width: 85%; word-wrap: break-word; box-shadow: 0 1px 2px rgba(0,0,0,0.2);">
                        ${msg.message}
                    </div>
                </div>
            `;
        }).join('');
    },

    scrollToBottom() {
        const list = document.getElementById('vs-chat-messages');
        if (list) list.scrollTop = list.scrollHeight;
    },

    formatTime(timestamp) {
        const date = new Date(timestamp * 1000); // PHP sends seconds
        return date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    }
};
