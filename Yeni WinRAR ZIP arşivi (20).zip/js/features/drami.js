/**
 * Drami AI Assistant - Core Logic
 */
const Drami = {
    isOpen: false,
    messages: [],
    humanMode: false,
    activeTicketId: null,
    context: {
        series: null,
        episode: null
    },

    setContext(series, episode) {
        this.context.series = series;
        this.context.episode = episode;
        console.log('🤖 Drami Context Set:', series?.title, episode ? `Ep ${episode}` : '');
    },

    init() {
        console.log('🤖 Drami AI Assistant Initializing...');
        this.loadState();
        this.renderElements();
        this.attachListeners();

        // Initial bot greeting if no messages
        if (this.messages.length === 0) {
            setTimeout(() => {
                this.addMessage("Merhaba! Ben Drami. Sana bugün nasıl yardımcı olabilirim? 👋", 'bot');
            }, 4000);
        }

        // Check for active ticket status
        this.checkTicketStatus();

        // New episode notifications for followed series
        setTimeout(() => this.checkNewEpisodes(), 5000);

        // Analyze watchlist for resume suggestions
        setTimeout(() => this.analyzeWatchlist(), 8000);
    },

    checkNewEpisodes() {
        if (!State.currentUser || !State.currentUser.following || !State.data.series) return;

        const following = State.currentUser.following;
        const notifiedData = JSON.parse(localStorage.getItem('drami_notified_episodes') || '{}');
        let newUpdates = [];

        following.forEach(seriesId => {
            const series = State.data.series.find(s => s.id == seriesId);
            if (!series) return;

            const currentEpCount = series.episodes ? series.episodes.length :
                (series.seasons ? series.seasons.reduce((acc, s) => acc + (s.episodes ? s.episodes.length : 0), 0) : 0);

            const lastCount = notifiedData[seriesId] || 0;

            if (currentEpCount > lastCount && lastCount !== 0) {
                newUpdates.push({
                    title: series.title,
                    id: seriesId,
                    newCount: currentEpCount - lastCount
                });
            }

            // Update last known count
            notifiedData[seriesId] = currentEpCount;
        });

        localStorage.setItem('drami_notified_episodes', JSON.stringify(notifiedData));

        if (newUpdates.length > 0) {
            const updatesHtml = newUpdates.map(u =>
                `<div style="margin-bottom: 5px;">• <b>${u.title}</b> dizisine ${u.newCount} yeni bölüm eklendi!</div>`
            ).join('');

            this.addMessage(`Takip ettiğin dizilerde heyecan verici gelişmeler var! 🎬 <br><br> ${updatesHtml} <br> Hemen izlemek ister misin?`, 'bot', true);
        }
    },

    learnFromInput(text) {
        if (!State.currentUser) return;

        // Simple learning: Extract genres user mentions or shows interest in
        const genres = ['aksiyon', 'romantik', 'komedi', 'drama', 'korku', 'fantastik', 'bilim kurgu', 'tarihi', 'gerilim'];
        let matchedGenres = genres.filter(g => text.includes(g));

        if (matchedGenres.length > 0) {
            if (!State.currentUser.metadata) State.currentUser.metadata = {};
            if (!State.currentUser.metadata.drami_interests) State.currentUser.metadata.drami_interests = [];

            matchedGenres.forEach(g => {
                if (!State.currentUser.metadata.drami_interests.includes(g)) {
                    State.currentUser.metadata.drami_interests.push(g);
                }
            });

            // Save state (persists interest)
            if (window.db && db.save) db.save();
            console.log('🤖 Drami learned interests:', matchedGenres);
            this.updateRecommendations();
        }

        // --- NEW: Secret Discovery Hinting ---
        if (text.includes('sır') || text.includes('gizli') || text.includes('easter egg') || text.includes('ödül')) {
            this.checkForSecrets();
        }
    },

    checkForSecrets() {
        const findersCount = State.data.easterEgg?.finders?.length || 0;
        const max = State.data.easterEgg?.max || 3;
        
        if (findersCount < max) {
            this.addMessage(`Bir kuş bana Dramicbox'ta hala keşfedilmemiş sırlar olduğunu söyledi... 🤫 Üstelik bulursan 5.000 Coin senin olabilir! Belki de logonun etrafında bir şeyler gizlidir?`, 'bot');
        } else {
            this.addMessage(`Sırlar çoktan keşfedilmiş ama Hall of Fame'deki efsanelere bakarak yeni gizemler peşinde koşabilirsin! 🏆`, 'bot');
        }
    },

    updateRecommendations() {
        if (!State.data.series) return;
        
        const history = State.currentUser?.watchHistory || [];
        const likedGenres = new Set();
        const likedTags = new Set();
        
        // Analyze history
        history.forEach(h => {
            const s = State.data.series.find(x => x.id === h.seriesId);
            if (s) {
                (s.genres || []).forEach(g => likedGenres.add(g));
                (s.hashtags || []).forEach(t => likedTags.add(t));
            }
        });

        // Score all series
        const scored = State.data.series.map(s => {
            let score = 0;
            (s.genres || []).forEach(g => { if (likedGenres.has(g)) score += 5; });
            (s.hashtags || []).forEach(t => { if (likedTags.has(t)) score += 3; });
            return { series: s, score };
        })
        .filter(x => x.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 3);

        this.recommendations = scored.map(x => x.series);
    },

    analyzeWatchlist() {
        if (!State.currentUser || !State.data.series) return;

        // Find series with some progress but not finished
        // Using State.currentUser.watchHistory for recent activity
        const history = State.currentUser.watchHistory || [];
        if (history.length === 0) return;

        const recent = history[0];
        const series = State.data.series.find(s => s.id == recent.seriesId);

        if (series) {
            // Random chance to suggest (don't be annoying every time)
            if (Math.random() > 0.7) {
                this.addMessage(`En son <b>${series.title}</b> izliyordun. Devam etmek için harika bir zaman olabilir! 🍿`, 'bot', true);
            }
        }
    },

    loadState() {
        const saved = localStorage.getItem('drami_state');
        if (saved) {
            try {
                const state = JSON.parse(saved);
                this.messages = state.messages || [];

                // --- 24h Clean Up ---
                const oneDay = 24 * 60 * 60 * 1000;
                const now = Date.now();
                const initialCount = this.messages.length;
                this.messages = this.messages.filter(m => m.timestamp && (now - m.timestamp < oneDay));
                if (this.messages.length < initialCount) {
                    this.saveState(); // Update storage after cleanup
                }
                // --------------------

                this.isOpen = state.isOpen || false;
                this.humanMode = state.humanMode || false;
                this.activeTicketId = state.activeTicketId || null;
            } catch (e) { console.error('Drami state load error', e); }
        }
    },

    saveState() {
        const state = {
            messages: this.messages,
            isOpen: this.isOpen,
            humanMode: this.humanMode,
            activeTicketId: this.activeTicketId
        };
        localStorage.setItem('drami_state', JSON.stringify(state));
    },

    renderElements() {
        // Remove existing if any
        const oldBubble = document.getElementById('drami-trigger');
        const oldChat = document.getElementById('drami-chat');
        if (oldBubble) oldBubble.remove();
        if (oldChat) oldChat.remove();

        // Check if Drami is hidden (user toggle)
        if (localStorage.getItem('drami_hidden') === 'true') {
            console.log('🤖 Drami is hidden by user.');
            return;
        }

        const user = State.currentUser;
        if (!user || user.role === 'guest') return; // Must be logged in

        // Determine Avatar based on gender
        const gender = user.gender;
        const avatarUrl = gender === 'kiz' ? 'assets/mascot/drami-girl.png' : 'assets/mascot/drami-boy.png';


        // 1. Bubble
        const bubble = document.createElement('div');
        bubble.className = 'drami-bubble';
        bubble.id = 'drami-trigger';
        bubble.innerHTML = `
            <img src="${avatarUrl}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
            <div class="drami-ping"></div>
        `;
        // Contextual Quick Questions Chips
        if (this.context.series) {
            const chip = document.createElement('div');
            chip.className = 'drami-chip';
            chip.style.cssText = 'background: rgba(139, 92, 246, 0.1); border: 1px solid rgba(139, 92, 246, 0.3); padding: 5px 10px; border-radius: 12px; font-size: 0.75rem; color: #a78bfa; margin-bottom: 10px; display: inline-block; cursor: pointer; transform: translateY(-5px); animation: fadeInDown 0.5s ease;';
            chip.innerHTML = `<i class="fa-solid fa-circle-question"></i> ${this.context.series.title} Hakkında`;
            chip.onclick = (e) => {
                e.stopPropagation();
                this.toggleChat(); // Use toggleChat, it will open if closed
                this.sendMessage(`Bana "${this.context.series.title}" hakkında bilgi ver.`);
            };
            bubble.prepend(chip); // Use 'bubble' instead of 'dramiBubble'
        }

        document.body.appendChild(bubble); // Use 'bubble' instead of 'dramiBubble'

        // 2. Chat Container
        const container = document.createElement('div');
        container.className = `drami-container ${this.isOpen ? 'active' : ''}`;
        container.id = 'drami-chat';
        container.innerHTML = `
            <div class="drami-header">
                <div class="drami-avatar">
                    <img src="${avatarUrl}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
                </div>
                <div class="drami-header-info">
                    <h3>Drami</h3>
                    <p>${this.humanMode ? 'Canlı Destek' : 'Yapay Zeka Asistanın (Beta)'}</p>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button class="drami-minimize" title="Kapat"><i class="fa-solid fa-minus"></i></button>
                    <button class="drami-close-permanent" title="Drami'yi Devre Dışı Bırak"><i class="fa-solid fa-xmark"></i></button>
                </div>
            </div>
            
            <div class="drami-messages" id="drami-msgr">
                <!-- Messages filled by loadState -->
            </div>

            <div class="drami-actions">
                ${!this.humanMode ? `
                    <div class="drami-chip" onclick="Drami.handleAction('recommend')">✨ Öneri Yap</div>
                    <div class="drami-chip" onclick="Drami.handleAction('report')">⚠️ Hata Bildir</div>
                    <div class="drami-chip" onclick="Drami.handleAction('connect_admin')">💬 Destek Ekibi</div>
                ` : `
                    <div class="drami-chip active" style="background:var(--success-color); color:white;">🎧 Canlı Mod Aktif</div>
                `}
            </div>

            <div class="drami-input-area">
                <label for="drami-file-upload" class="drami-upload-btn" id="drami-upload-trigger" title="Görsel Gönder" style="display: none;">
                    <i class="fa-solid fa-paperclip"></i>
                </label>
                <input type="file" id="drami-file-upload" accept="image/png, image/jpeg" style="display: none;">
                <input type="text" class="drami-input" placeholder="Drami'ye bir şeyler sor..." id="drami-input-field">
                <button class="drami-send" id="drami-send-btn"><i class="fa-solid fa-paper-plane"></i></button>
            </div>

        `;
        document.body.appendChild(container);

        // Render existing messages
        this.messages.forEach(m => this.renderMessage(m.text, m.type, m.isHtml, false));
    },

    attachListeners() {
        const trigger = document.getElementById('drami-trigger');
        const chat = document.getElementById('drami-chat');
        if (!chat) return;

        const minimize = chat.querySelector('.drami-minimize');
        const permanentClose = chat.querySelector('.drami-close-permanent');
        const input = document.getElementById('drami-input-field');
        const send = document.getElementById('drami-send-btn');

        if (trigger) trigger.addEventListener('click', () => this.toggleChat());
        if (minimize) minimize.addEventListener('click', () => this.toggleChat());

        if (permanentClose) {
            permanentClose.addEventListener('click', () => {
                if (confirm('Drami asistanı kapatmak istiyor musunuz? İstediğiniz zaman kullanıcı menüsünden tekrar açabilirsiniz.')) {
                    this.hidePermanently();
                }
            });
        }

        if (send) send.addEventListener('click', () => this.sendMessage());

        // File Upload Listener
        const fileInput = document.getElementById('drami-file-upload');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => this.handleFileUpload(e));
        }

        if (input) {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.sendMessage();
            });
        }
    },

    toggleChat() {
        this.isOpen = !this.isOpen;
        const chat = document.getElementById('drami-chat');
        if (this.isOpen) {
            chat.classList.add('active');
            document.getElementById('drami-input-field').focus();
        } else {
            chat.classList.remove('active');
        }
        this.saveState();
    },

    hidePermanently() {
        localStorage.setItem('drami_hidden', 'true');
        const bubble = document.getElementById('drami-trigger');
        const chat = document.getElementById('drami-chat');
        if (bubble) bubble.remove();
        if (chat) chat.remove();
        this.isOpen = false;
        this.saveState();
        Toast.info('Drami gizlendi. Profil menüsünden tekrar açabilirsiniz.');
    },

    showPermanently() {
        localStorage.removeItem('drami_hidden');
        this.init();
        this.toggleChat();
    },

    sendMessage() {
        const input = document.getElementById('drami-input-field');
        const text = input.value.trim();
        if (!text) return;

        // Auto-Moderation Check
        const bannedWords = State.data.settings?.bannedWords || [];
        const foundBanned = bannedWords.some(word => text.toLowerCase().includes(word.toLowerCase()));

        if (foundBanned) {
            this.addMessage("Üzgünüm, mesajınız topluluk kurallarımızı ihlal eden kelimeler içerdiği için gönderilemedi. 🚫", 'bot');
            input.value = '';
            if (window.db && db.logActivity) {
                db.logActivity(`Drami Engelleme: ${State.currentUser?.username || 'Misafir'} yasaklı kelime kullandı.`, '🤖');
            }
            return;
        }

        this.addMessage(text, 'user');
        input.value = '';

        // Learn from input
        this.learnFromInput(text.toLowerCase());

        if (this.humanMode) {
            this.sendToAdmin(text);
        } else {
            // Bot thinking process with typing indicator
            this.showTypingIndicator();
            setTimeout(() => {
                this.removeTypingIndicator();
                this.processMessage(text.toLowerCase());
            }, 1000 + Math.random() * 1000); // Varied thinking time
        }

        // Log to Admin Logs
        if (window.db && db.logActivity) {
            db.logActivity(`Drami Mesaj: ${text.substring(0, 50)}${text.length > 50 ? '...' : ''}`, '🤖');
        }
    },

    addMessage(text, type, isHtml = false) {
        this.messages.push({ text, type, isHtml, timestamp: Date.now() });
        this.renderMessage(text, type, isHtml);
        this.saveState();
    },

    renderMessage(text, type, isHtml = false, scroll = true) {
        const container = document.getElementById('drami-msgr');
        if (!container) return;

        const msg = document.createElement('div');
        msg.className = `drami-msg ${type}`;

        if (isHtml) {
            msg.innerHTML = text;
        } else {
            msg.textContent = text;
        }

        container.appendChild(msg);
        if (scroll) container.scrollTop = container.scrollHeight;
    },

    showTypingIndicator() {
        const container = document.getElementById('drami-msgr');
        if (!container) return;

        const typing = document.createElement('div');
        typing.className = 'drami-msg bot drami-typing';
        typing.id = 'drami-typing-indicator';
        typing.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        container.appendChild(typing);
        container.scrollTop = container.scrollHeight;
    },

    removeTypingIndicator() {
        const indicator = document.getElementById('drami-typing-indicator');
        if (indicator) indicator.remove();
    },

    async processMessage(text) {
        // 1. Check if AI is globally enabled
        if (State.data.settings && State.data.settings.aiEnabled === false) {
            this.addMessage("Üzgünüm, şu anda bakım modundayım veya yöneticilerim beni geçici olarak dinlendirmeye aldı. 😴 Daha sonra tekrar konuşalım!", 'bot');
            return;
        }

        const lowerText = text.toLowerCase();

        // --- EMOTION & MOOD RECOGNITION ---
        const emotions = {
            sad: ['üzgünüm', 'mutsuzum', 'ağlamak istiyorum', 'moralim bozuk', 'canım sıkkın', 'modum düşük'],
            bored: ['sıkıldım', 'yapacak bir şey yok', 'vakit geçsin', 'boşluktayım'],
            tense: ['gerginim', 'korkuyorum', 'stresliyim', 'daraldım'],
            happy: ['mutluyum', 'harika', 'süper', 'keyfim yerinde', 'bomba gibiyim'],
            romantic: ['aşık oldum', 'romantizm', 'aşk', 'duygusal']
        };

        // Check for moods
        if (emotions.sad.some(e => lowerText.includes(e))) {
            this.addMessage("Üzgün olmana çok üzüldüm... 😔 Ama merak etme, seni biraz neşelendirecek harika içerikler biliyorum! Komedi veya sıcak bir romantik komediye ne dersin?", 'bot');
            setTimeout(() => this.suggestByMood('sad'), 1000);
            return;
        }

        if (emotions.bored.some(e => lowerText.includes(e))) {
            this.addMessage("Sıkılmak mı? DramicBox'ta buna yer yok! 😉 Adrenalini yükseltecek aksiyon dolu bir maceraya hazır mısın?", 'bot');
            setTimeout(() => this.suggestByMood('bored'), 1000);
            return;
        }

        if (emotions.tense.some(e => lowerText.includes(e))) {
            this.addMessage("Gergin hissediyorsan seni biraz rahatlatacak, 'kafa dağıtmalık' sakin dizilerim var. Veya bu gerilimi güvenli bir korku filmiyle atabilirsin? Ben sana şimdilik sakinleşmen için bir liste yapayım. ☕", 'bot');
            setTimeout(() => this.suggestByMood('tense'), 1000);
            return;
        }

        if (emotions.happy.some(e => lowerText.includes(e))) {
            this.addMessage("Harika! 🎉 Enerjin çok güzel. Bu modunu koruyacak, keyifli ve eğlenceli dizilere göz atalım mı?", 'bot');
            setTimeout(() => this.suggestByMood('happy'), 1000);
            return;
        }

        if (emotions.romantic.some(e => lowerText.includes(e))) {
            this.addMessage("Ooo, havada aşk kokusu var! ❤️ Kalbini pır pır ettirecek en iyi romantik serileri senin için seçtim.", 'bot');
            setTimeout(() => this.suggestByMood('romantic'), 1000);
            return;
        }


        // --- CONVERSATION LOGIC ---
        // Greetings
        if (/^(merhaba|selam|slm|hi|hello)$/.test(lowerText) || lowerText.includes('selamün aleyküm')) {
            this.addMessage("Selamlar! 👋 DramicBox dünyasına hoş geldin. Bugün modun nasıl? Sana özel bir öneri yapmamı ister misin?", 'bot');
            return;
        }

        if (/^(naber|ne haber|nasıl gidiyor|nasilsin|nasılsın)$/.test(lowerText)) {
            const replies = [
                "Ben bir yapay zeka olduğum için hep harikayım! 🤖 Sen nasılsın?",
                "Kodlarım tıkırında çalışıyor, teşekkürler! 😄 Bugün senin için ne yapabilirim?",
                "Süperim! Veri tabanımda gezinip duruyorum. Sen nasılsın, keyifler yerinde mi?"
            ];
            this.addMessage(replies[Math.floor(Math.random() * replies.length)], 'bot');
            return;
        }

        if (/^(iyiyim|iyi|süper|fena değil)$/.test(lowerText)) {
            this.addMessage("Bunu duyduğuma sevindim! 😊 Keyifli vakit geçirmek için bir şeyler izlemeye ne dersin?", 'bot');
            return;
        }

        if (/^(kötüyüm|kötü|idare eder)$/.test(lowerText)) {
            this.addMessage("Hadi ya... 😕 Bazen güzel bir dizi her şeyi unutturabilir. Moduna uygun bir şeyler önermemi ister misin? (Örn: 'Mutsuz' veya 'Sıkıldım' yazabilirsin)", 'bot');
            return;
        }

        if (lowerText.includes('günaydın')) {
            this.addMessage("Günaydın! ☀️ Güne başlamak için kısa, çerezlik bir webtoon okumaya ne dersin?", 'bot');
            return;
        }
        if (lowerText.includes('iyi geceler')) {
            this.addMessage("İyi geceler! 🌙 Uyumadan önce sakin bir şeyler izlemek istersen ben buradayım.", 'bot');
            return;
        }


        // --- STANDARD COMMANDS ---
        if (text.includes('öneri') || text.includes('ne izlesem') || text.includes('tavsiye')) {
            const interests = State.currentUser?.metadata?.drami_interests || [];
            if (interests.length > 0) {
                this.addMessage(`Baktım da genelde <b>${interests.join(', ')}</b> tarzı içeriklerle ilgileniyorsun. Senin için özel birkaç öneri hazırladım:`, 'bot', true);
            } else {
                this.addMessage("Senin için harika birkaç önerim var:", 'bot');
            }
            this.renderRecommendations(); // Default generic
        } else if (text.includes('hata') || text.includes('bozuk') || text.includes('çalışmıyor')) {
            this.handleAction('report');
        } else if (text.includes('yardım') || text.includes('nedir')) {
            this.handleAction('help');
        } else if (text.includes('teşekkür') || text.includes('sağol')) {
            this.addMessage("Rica ederim! Her zaman buradayım. ❤️", 'bot');
        } else if (text.includes('destek') || text.includes('admin') || text.includes('canlı')) {
            this.handleAction('connect_admin');
        } else {
            // 3. LLM Fallback (Smart Mode)
            this.askLLM(text);
        }
    },

    suggestByMood(moodType) {
        if (!State.data || !State.data.series) return;

        // 1. Define Mood -> Genre Mapping
        const moodMap = {
            'sad': ['Komedi', 'Romantik Komedi', 'Gençlik', 'Fantastik'], // Cheer up
            'bored': ['Aksiyon', 'Macera', 'Bilim Kurgu', 'Korku', 'Gerilim'], // Excitement
            'tense': ['Slice of Life', 'Dram', 'Belgesel', 'Romantik'], // Relax
            'happy': ['Komedi', 'Romantik Komedi', 'Müzikal', 'Gençlik'], // Sustain
            'romantic': ['Romantik', 'Romantik Komedi', 'Dram'] // Match
        };

        const targetGenres = moodMap[moodType] || [];

        // 2. Filter Series
        let candidates = State.data.series.filter(s => {
            const sGenres = Array.isArray(s.genres) ? s.genres : (s.genre || '').split(',');
            // Check intersection logic
            return sGenres.some(g => targetGenres.some(tg => g.trim().includes(tg)));
        });

        // If not enough candidates, try generic fallback
        if (candidates.length < 3) {
            candidates = State.data.series; // Fallback to all (better than nothing)
        }

        // 3. Randomize & Slice
        const suggestions = candidates.sort(() => 0.5 - Math.random()).slice(0, 5);

        // 4. Render Horizontal List
        const html = `
            <div class="drami-horizontal-list" style="display: flex; gap: 10px; overflow-x: auto; padding-bottom: 5px;">
                ${suggestions.map(s => `
                    <div style="min-width: 120px; max-width: 120px; background: rgba(255,255,255,0.05); border-radius: 8px; padding: 5px; cursor: pointer;" 
                         onclick="App.visitPage('#/detail/${s.id}')">
                        <img src="${s.coverImage || s.poster || 'assets/logo.png'}" 
                             style="width: 100%; aspect-ratio: 2/3; object-fit: cover; border-radius: 6px; margin-bottom: 5px;">
                        <div style="font-size: 0.75rem; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${s.title}</div>
                        <div style="font-size: 0.65rem; color: #aaa;">⭐ ${(s.rating || 'N/A')}</div>
                    </div>
                `).join('')}
            </div>
            <div style="font-size: 0.7rem; color: #888; margin-top: 5px; text-align: right;">Kaydırarak incele 👉</div>
        `;

        this.addMessage(html, 'bot', true);
    },

    async askLLM(prompt) {
        // Show a typing indicator to indicate thinking
        this.addMessage("Düşünüyorum... 🤔", 'bot');
        const containers = document.querySelectorAll('.drami-msg.bot');
        const lastBotMsg = containers[containers.length - 1];

        const requestBody = { prompt: prompt };

        // Context Injection
        if (this.context.series) {
            requestBody.context = {
                seriesId: this.context.series.id,
                title: this.context.series.title,
                episode: this.context.episode,
                genres: this.context.series.genres || []
            };
        }

        try {
            const response = await fetch('api/drami-ai.php?action=ask', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody)
            });
            const res = await response.json();

            if (res.success) {
                if (lastBotMsg) lastBotMsg.textContent = res.response;
            } else {
                if (lastBotMsg) lastBotMsg.textContent = "Bunu tam anlayamadım, ama sana öneri yapmamı ister misin?";
            }
        } catch (e) {
            console.error('Drami AI Error:', e);
            if (lastBotMsg) lastBotMsg.textContent = "Biraz kafam karıştı ama buradayım! Başka bir şey sormak ister misin?";
        }
    },

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        const validTypes = ['image/png', 'image/jpeg', 'image/jpg'];
        if (!validTypes.includes(file.type)) {
            Toast.error('Sadece PNG ve JPEG dosyaları gönderebilirsiniz.');
            return;
        }

        if (file.size > 2 * 1024 * 1024) { // 2MB limit
            Toast.error('Dosya boyutu çok büyük (Max: 2MB).');
            return;
        }

        // Simulate Upload
        const reader = new FileReader();
        reader.onload = (e) => {
            const dataUrl = e.target.result;
            // Add user message with image
            this.addMessage(`<div style="display:flex; flex-direction:column; gap:5px;"><img src="${dataUrl}" style="max-width:150px; border-radius:8px;"><span>Dosya gönderildi.</span></div>`, 'user', true);

            // If in human mode, it should be sent to admin ticket (simulated)
            if (this.humanMode) {
                this.sendToAdmin('[Görsel Eklenmiştir]', dataUrl);
                setTimeout(() => this.addMessage("Görseli ekibe ilettim. 📁", 'bot'), 1000);
            } else {
                setTimeout(() => this.addMessage("Bu görseli henüz analiz edemiyorum ama güzel görünüyor! 🖼️", 'bot'), 1000);
            }
        };
        reader.readAsDataURL(file);

        // Reset input
        event.target.value = '';
    },

    handleAction(action) {
        if (action === 'recommend') {
            this.addMessage("Senin için harika birkaç önerim var:", 'bot');
            this.renderRecommendations();
        } else if (action === 'report') {
            const context = State.currentSeries ? `(${State.currentSeries.title})` : '';
            this.addMessage(`Bir sorun mu var? Merak etme, teknik ekibi hemen bilgilendirebilirim. Lütfen sorunu kısaca anlatır mısın? ${context}`, 'bot');
        } else if (action === 'help') {
            this.addMessage("Sana şu konularda yardımcı olabilirim:\n- 🎯 Dizi ve Webtoon önerileri\n- 🐞 Hata bildirme\n- 💎 Premium üyelik hakkında bilgi\n- 🎭 Koleksiyon kartları\n- 🎧 Canlı Destek ekibine bağlanma", 'bot');
        } else if (action === 'connect_admin') {
            this.connectToAdmin();
        }
    },

    async connectToAdmin() {
        if (this.humanMode) return;

        this.addMessage("Seni bir ekip arkadaşımıza bağlıyorum. Lütfen bekler misin? 🎧", 'bot');

        const ticketData = {
            category: 'chat_request',
            subject: 'Drami Canlı Destek Talebi',
            description: 'Kullanıcı Drami üzerinden canlı destek talep etti.',
            priority: 'high',
            metadata: { source: 'drami_ai' }
        };

        if (!State.data.tickets) State.data.tickets = [];
        
        const ticketId = 'ticket-' + Date.now();
        const newTicket = { 
            ...ticketData, 
            id: ticketId,
            userId: State.currentUser.id,
            username: State.currentUser.username,
            status: 'açık',
            createdAt: new Date().toISOString(),
            conversations: []
        };

        // PUSH and SAVE
        State.data.tickets.push(newTicket);
        if (window.db && db.save) db.save();

        this.activeTicketId = ticketId;
        this.humanMode = true;
        this.saveState();

        setTimeout(() => {
            this.addMessage("Talebin başarıyla oluşturuldu! ✅ Bir yönetici en kısa sürede dönüş yapacak.", 'bot');
            this.renderElements(); // Refresh UI for chips
        }, 1500);

    },

    sendToAdmin(text, imageUrl = null) {
        if (this.activeTicketId) {
            const tickets = State.data.tickets || [];
            const ticket = tickets.find(t => t.id === this.activeTicketId);
            if (ticket) {
                if (!ticket.conversations) ticket.conversations = [];
                ticket.conversations.push({
                    role: 'user',
                    senderName: State.currentUser.username,
                    text: text + (imageUrl ? ` <br><img src="${imageUrl}" style="max-width:200px; border-radius:8px; margin-top:5px;">` : ''),
                    at: new Date().toISOString()
                });
                db.save();
            }
        }
    },

    checkTicketStatus() {
        if (!this.activeTicketId) return;

        if (this.failsafeInterval) clearInterval(this.failsafeInterval);
        
        this.failsafeInterval = setInterval(async () => {
            if (!this.activeTicketId) return;
            
            try {
                const ticket = State.data.tickets?.find(t => t.id === this.activeTicketId);
                if (ticket) {
                    // Check for new messages from staff
                    const lastMsg = ticket.conversations && ticket.conversations.length > 0 ? ticket.conversations[ticket.conversations.length - 1] : null;
                    
                    // If last message is from staff and NOT in our local messages, add it
                    if (lastMsg && lastMsg.role === 'staff') {
                        const alreadyShown = this.messages.some(m => m.text === lastMsg.text);
                        if (!alreadyShown) {
                            this.addMessage(`<b>${lastMsg.senderName}:</b> ${lastMsg.text}`, 'bot', true);
                            
                            // Trigger notification if panel is closed
                            if (!this.isOpen && typeof NotificationSystem !== 'undefined') {
                                NotificationSystem.addLocalNotification({
                                    title: 'Destek Yanıtı',
                                    message: `${lastMsg.senderName} talebinize yanıt verdi.`,
                                    type: 'support',
                                    link: '#/social' // Or wherever the chat is
                                });
                            }
                        }
                    }

                    // Check for Screenshot Permission
                    const uploadBtn = document.getElementById('drami-upload-trigger');
                    if (uploadBtn) {
                        uploadBtn.style.display = ticket.canUploadImage ? 'flex' : 'none';
                    }

                    if (ticket.status === 'kapalı') {
                        this.addMessage("Bu görüşme destek ekibi tarafından sonlandırıldı. Başka bir konuda yardımcı olmamı ister misin?", 'bot');
                        this.humanMode = false;
                        this.activeTicketId = null;
                        this.saveState();
                        this.renderElements();
                    }
                }
            } catch (e) { console.warn('Ticket status check failed', e); }
        }, 5000); // Check every 5s for better responsiveness
    },

    renderRecommendations() {
        if (!State.data || !State.data.series) return;

        const interests = State.currentUser?.metadata?.drami_interests || [];
        let candidates = [...State.data.series];

        if (interests.length > 0) {
            // Filter by interests if any match
            const matching = candidates.filter(s => {
                const sGenres = (s.genres || s.genre || '').toString().toLowerCase();
                return interests.some(i => sGenres.includes(i));
            });
            if (matching.length > 0) candidates = matching;
        }

        const randoms = candidates.sort(() => 0.5 - Math.random()).slice(0, 3);

        const html = randoms.map(s => `
            <div class="drami-suggestion-card" onclick="App.router('detail', '${s.id}'); Drami.toggleChat();">
                <img src="${s.coverImage || s.poster || 'assets/logo.png'}">
                <div class="drami-suggestion-info">
                    <div class="drami-suggestion-title">${s.title}</div>
                    <div class="drami-suggestion-meta">${s.year || ''} • ${s.type === 'drama' ? 'Dizi' : 'Webtoon'}</div>
                </div>
            </div>
        `).join('');

        this.addMessage(html, 'bot', true);
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => Drami.init(), 2000);
});

window.Drami = Drami;
