// Custom List System
const ListSystem = {
    init() {
        console.log('📋 List System Initialized');
    },

    // Updated Create List with Modal
    createList() {
        if (!State.currentUser) {
            Toast.warning("Liste oluşturmak için giriş yapmalısınız!");
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.zIndex = '10001';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 400px;">
                <div class="modal-header">
                    <h2>📝 Yeni Liste Oluştur</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <form onsubmit="ListSystem.handleCreateListSubmit(event)">
                        <div class="form-group">
                            <label>Liste Adı</label>
                            <input type="text" name="listName" class="form-input" placeholder="Örn: Favorilerim" required autoFocus>
                        </div>
                        <div class="form-group">
                            <label>Açıklama (İsteğe bağlı)</label>
                            <textarea name="listDesc" class="form-input" rows="3" placeholder="Bu liste ne hakkında?"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Oluştur</button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        // Focus input
        setTimeout(() => {
            const input = modal.querySelector('input[name="listName"]');
            if (input) input.focus();
        }, 100);
    },

    handleCreateListSubmit(event) {
        event.preventDefault();
        const form = event.target;
        const name = form.listName.value;
        const desc = form.listDesc.value;

        if (!name) return;

        const newList = {
            id: 'list-' + Date.now(),
            userId: State.currentUser.id,
            username: State.currentUser.username,
            name: name,
            description: desc || '',
            items: [],
            createdAt: Date.now(),
            likes: []
        };

        if (!State.data.customLists) State.data.customLists = [];
        State.data.customLists.push(newList);

        // Save
        if (window.db && window.db.save) window.db.save();

        Toast.success("✅ Liste oluşturuldu!");

        // Close modal
        form.closest('.modal').remove();

        // Refresh view if open lists modal
        this.showMyLists();
    },

    addSeriesToList(listId, seriesId) {
        const list = State.data.customLists.find(l => l.id === listId);
        if (!list) return;

        if (list.items.includes(seriesId)) {
            Toast.warning("Bu dizi zaten listede var.");
            return;
        }

        list.items.push(seriesId);
        if (window.db && window.db.save) window.db.save();

        Toast.success("Dizi listeye eklendi!");
    },

    removeSeriesFromList(listId, seriesId) {
        const list = State.data.customLists.find(l => l.id === listId);
        if (!list) return;

        list.items = list.items.filter(id => id !== seriesId);
        if (window.db && window.db.save) window.db.save();

        Toast.info("Dizi listeden çıkarıldı.");
        this.viewList(listId); // Refresh
    },

    deleteList(listId) {
        if (!confirm("Bu listeyi silmek istediğinize emin misiniz?")) return;

        State.data.customLists = State.data.customLists.filter(l => l.id !== listId);
        if (window.db && window.db.save) window.db.save();

        Toast.info("Liste silindi.");
        this.showMyLists();
    },

    // UI: Show User's Lists
    showMyLists() {
        if (!State.currentUser) return;

        const myLists = (State.data.customLists || []).filter(l => l.userId === State.currentUser.id);

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2>📋 Listelerim</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <button class="btn btn-primary" onclick="ListSystem.createList()" style="width:100%; margin-bottom:20px;">
                        <i class="fa-solid fa-plus"></i> Yeni Liste Oluştur
                    </button>

                    <div class="list-container" style="display:flex; flex-direction:column; gap:10px;">
                        ${myLists.length > 0 ? myLists.map(list => `
                            <div style="background:var(--bg-secondary); padding:15px; border-radius:8px; display:flex; justify-content:space-between; align-items:center;">
                                <div onclick="ListSystem.viewList('${list.id}')" style="cursor:pointer; flex:1;">
                                    <h4 style="margin:0;">${list.name}</h4>
                                    <small style="color:var(--text-secondary);">${list.items.length} içerik</small>
                                </div>
                                <button class="btn btn-sm btn-danger" onclick="ListSystem.deleteList('${list.id}')"><i class="fa-solid fa-trash"></i></button>
                            </div>
                        `).join('') : '<p style="text-align:center; color:var(--text-secondary);">Listeniz yok.</p>'}
                    </div>
                </div>
            </div>
        `;

        // Remove existing if any
        const existing = document.querySelector('.modal');
        if (existing) existing.remove();

        document.body.appendChild(modal);
    },

    // UI: View Single List
    viewList(listId) {
        const list = (State.data.customLists || []).find(l => l.id === listId);
        if (!list) return;

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 700px; max-height:80vh; overflow-y:auto;">
                <div class="modal-header">
                    <h2>${list.name}</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <p>${list.description}</p>
                    <hr style="border-color:var(--border-color); margin:15px 0;">
                    
                    <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap:15px;">
                        ${list.items.map(sid => {
            const series = db.getSeries(sid);
            if (!series) return '';
            return `
                                <div style="position:relative;">
                                    <img src="${series.poster}" style="width:100%; border-radius:8px; aspect-ratio: 2/3; object-fit:cover;">
                                    <div style="font-size:0.8rem; margin-top:5px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${series.title}</div>
                                    ${list.userId === State.currentUser?.id ? `
                                        <button onclick="ListSystem.removeSeriesFromList('${listId}', '${sid}')" 
                                            style="position:absolute; top:5px; right:5px; background:rgba(0,0,0,0.7); border:none; color:white; border-radius:50%; width:24px; height:24px; cursor:pointer;">
                                            ×
                                        </button>
                                    ` : ''}
                                </div>
                            `;
        }).join('')}
                    </div>
                </div>
            </div>
        `;

        const existing = document.querySelector('.modal');
        if (existing) existing.remove();

        document.body.appendChild(modal);
    },

    // UI: Add Series Picker Modal
    openAddToListModal(seriesId) {
        if (!State.currentUser) {
            Toast.warning("Giriş yapmalısınız!");
            return;
        }

        const myLists = (State.data.customLists || []).filter(l => l.userId === State.currentUser.id);

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 400px;">
                <div class="modal-header">
                    <h2>Listeye Ekle</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <button class="btn btn-outline" style="width:100%; margin-bottom:15px;" onclick="ListSystem.createList()">
                        <i class="fa-solid fa-plus"></i> Yeni Liste Oluştur
                    </button>

                    <div style="display:flex; flex-direction:column; gap:10px; max-height:300px; overflow-y:auto;">
                        ${myLists.map(list => {
            const hasSeries = list.items.includes(seriesId);
            return `
                                <button class="btn ${hasSeries ? 'btn-success' : 'btn-secondary'}" 
                                    style="width:100%; text-align:left; justify-content:space-between; display:flex;"
                                    onclick="${hasSeries ? '' : `ListSystem.addSeriesToList('${list.id}', '${seriesId}'); this.closest('.modal').remove();`}"
                                    ${hasSeries ? 'disabled' : ''}>
                                    <span>${list.name}</span>
                                    ${hasSeries ? '<i class="fa-solid fa-check"></i>' : '<i class="fa-solid fa-plus"></i>'}
                                </button>
                            `;
        }).join('')}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }
};

window.ListSystem = ListSystem;
