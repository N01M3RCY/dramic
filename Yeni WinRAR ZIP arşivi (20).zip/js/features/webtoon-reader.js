// ============================================
// WEBTOON READER ENGINE
// Handles vertical scrolling and chapter navigation
// ============================================

if (typeof WebtoonReader === 'undefined') {
    window.WebtoonReader = {
        currentSeriesId: null,
        currentChapterIdx: -1,
        isZenMode: false,
        isAutoScrolling: false,
        scrollSpeed: 2, // Default pixels per tick
        scrollInterval: null,

        init() {
            // Event listeners for keys
            document.addEventListener('keydown', (e) => {
                if (document.getElementById('webtoon-reader-view')?.style.display === 'block') {
                    if (e.key === 'ArrowLeft') this.prevChapter();
                    if (e.key === 'ArrowRight') this.nextChapter();
                }
            });

            // Hide/Show controls on scroll interact
            let lastScrollY = window.scrollY;
            window.addEventListener('scroll', () => {
                if (document.getElementById('webtoon-reader-view')?.style.display !== 'block') return;

                // Stop auto-scroll if manual scroll detected (and not currently auto-scrolling)
                // We check if the difference is significant to avoid jitter
                if (this.isAutoScrolling) {
                    // Logic to detect manual interruption could be complex with delta check
                    // For now, let's just allow auto-scroll to continue unless they use mousewheel/touch
                }

                const controls = document.querySelector('.reader-controls');
                if (!controls) return;

                if (window.scrollY > lastScrollY && window.scrollY > 100) {
                    // Scrolling down
                    if (!this.isZenMode) controls.classList.add('hidden');
                } else {
                    // Scrolling up
                    controls.classList.remove('hidden');
                }
                lastScrollY = window.scrollY;
            });

            // Manual interruption check
            window.addEventListener('wheel', () => {
                if (this.isAutoScrolling) this.toggleAutoScroll(false);
            }, { passive: true });

            window.addEventListener('touchstart', () => {
                if (this.isAutoScrolling) this.toggleAutoScroll(false);
            }, { passive: true });
        },

        openReader(seriesId, chapterNum) {
            // Switch view manually
            document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');

            // Ensure reader container exists
            let readerView = document.getElementById('webtoon-reader-view');
            if (!readerView) {
                readerView = document.createElement('div');
                readerView.id = 'webtoon-reader-view';
                readerView.className = 'view-section';
                document.getElementById('main-app').appendChild(readerView);
            }

            readerView.style.display = 'block';
            window.scrollTo(0, 0);

            this.currentSeriesId = seriesId;
            this.loadChapter(chapterNum);
        },

        loadChapter(chapterNum) {
            const series = db.getSeries(this.currentSeriesId);
            if (!series) {
                Toast.error('Seri bulunamadı!');
                App.router('home');
                return;
            }

            // Support both 'episodes' (Series) and 'chapters' (Webtoon)
            const contentList = series.chapters || series.episodes || [];

            // Find chapter by number
            const index = contentList.findIndex(ep => ep.number == chapterNum);

            if (index === -1) {
                Toast.error('Bölüm bulunamadı!');
                return;
            }

            this.currentChapterIdx = index;
            const chapter = contentList[index];

            const readerView = document.getElementById('webtoon-reader-view');

            const pages = chapter.pages || [];

            const hasPrev = index > 0; // Index 0 is usually Chapter 1
            const hasNext = index < contentList.length - 1;

            // For simple prev/next based on Array Index (safer than number math if gaps exist)
            const prevEp = hasPrev ? contentList[index - 1] : null;
            const nextEp = hasNext ? contentList[index + 1] : null;

            readerView.innerHTML = `
                <div class="reader-container">
                    <div class="reader-pages" id="reader-pages-container">
                        ${pages.length > 0 ?
                    pages.map(url => `<img src="${url}" class="reader-page" loading="lazy" alt="">`).join('') :
                    `<div style="padding: 100px; text-align: center; color: #666;">
                                <i class="fa-regular fa-image" style="font-size: 3rem; margin-bottom: 20px;"></i>
                                <p>Bu bölümde henüz sayfa yok.</p>
                            </div>`
                }
                    </div>
                </div>

                <style>
                    .reader-container {
                        max-width: 800px;
                        margin: 0 auto;
                        background: #000;
                        min-height: 100vh;
                        line-height: 0;
                        font-size: 0;
                    }
                    .reader-pages {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        gap: 0;
                        margin: 0;
                        padding: 0;
                    }
                    .reader-page {
                        display: block;
                        width: 100%;
                        height: auto;
                        margin: 0;
                        padding: 0;
                        border: none;
                        outline: none;
                        image-rendering: auto;
                        -webkit-user-select: none;
                        user-select: none;
                    }
                    .reader-controls {
                        position: fixed;
                        bottom: 0;
                        left: 0;
                        right: 0;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        gap: 12px;
                        padding: 12px 20px;
                        background: rgba(15, 23, 42, 0.95);
                        backdrop-filter: blur(12px);
                        border-top: 1px solid rgba(139, 92, 246, 0.2);
                        z-index: 100;
                        transition: transform 0.3s;
                    }
                    .reader-controls.hidden {
                        transform: translateY(100%);
                    }
                    .reader-btn {
                        background: rgba(255,255,255,0.08);
                        border: 1px solid rgba(255,255,255,0.1);
                        color: #e2e8f0;
                        width: 40px;
                        height: 40px;
                        border-radius: 10px;
                        cursor: pointer;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        transition: all 0.2s;
                    }
                    .reader-btn:hover:not(:disabled) {
                        background: rgba(139, 92, 246, 0.3);
                    }
                    .reader-btn:disabled {
                        opacity: 0.3;
                        cursor: not-allowed;
                    }
                    .reader-btn.active {
                        background: #8b5cf6;
                        border-color: #8b5cf6;
                    }
                    .reader-title {
                        text-align: center;
                        color: #e2e8f0;
                        font-weight: 600;
                        font-size: 0.9rem;
                        line-height: 1.4;
                    }
                    .reader-auto-scroll {
                        display: flex;
                        align-items: center;
                        gap: 8px;
                    }
                    .speed-slider {
                        width: 60px;
                        accent-color: #8b5cf6;
                    }
                    body.zen-active {
                        background: #000 !important;
                    }
                    body.zen-active .reader-controls {
                        opacity: 0.3;
                    }
                    body.zen-active .reader-controls:hover {
                        opacity: 1;
                    }
                    @media (max-width: 768px) {
                        .reader-container {
                            max-width: 100%;
                        }
                    }
                </style>

                <div class="reader-controls">
                    <button class="reader-btn" onclick="WebtoonReader.prevChapter()" ${prevEp ? '' : 'disabled'} title="Önceki Bölüm">
                        <i class="fa-solid fa-chevron-left"></i>
                    </button>
                    
                    <div class="reader-title">
                        <div style="display:flex; align-items:center; gap:8px;">
                            ${series.title}
                            ${!navigator.onLine ? '<span style="font-size:0.6rem; background:#10b981; color:white; padding:2px 6px; border-radius:4px; text-transform:uppercase;">Çevrimdışı</span>' : ''}
                        </div>
                        <div style="font-size: 0.8em; color: var(--accent-color);">Bölüm ${chapter.number}</div>
                    </div>

                    <button class="reader-btn" onclick="WebtoonReader.nextChapter()" ${nextEp ? '' : 'disabled'} title="Sonraki Bölüm">
                        <i class="fa-solid fa-chevron-right"></i>
                    </button>
                    
                    <div style="width: 1px; height: 20px; background: rgba(255,255,255,0.1); margin: 0 10px;"></div>
                    
                    <button class="reader-btn" id="zen-mode-toggle" onclick="WebtoonReader.toggleZenMode()" title="Zen Modu (Odağı Artır)">
                        <i class="fa-solid fa-moon"></i>
                    </button>

                    <div class="reader-auto-scroll">
                        <button class="reader-btn" id="auto-scroll-toggle" onclick="WebtoonReader.toggleAutoScroll()" title="Otomatik Kaydır">
                            <i class="fa-solid fa-play"></i>
                        </button>
                        <div class="speed-slider-container">
                             <input type="range" min="1" max="10" value="${this.scrollSpeed}" 
                                    oninput="WebtoonReader.updateSpeed(this.value)" 
                                    class="speed-slider" title="Kaydırma Hızı">
                        </div>
                    </div>

                    <button class="reader-btn" onclick="App.router('detail', '${series.id}')" title="Seriye Dön">
                        <i class="fa-solid fa-list"></i>
                    </button>
                </div>
            `;

            // Reset Zen mode UI state
            if (this.isZenMode) {
                document.body.classList.add('zen-active');
                const zenBtn = document.getElementById('zen-mode-toggle');
                if (zenBtn) {
                    zenBtn.classList.add('active');
                    zenBtn.innerHTML = '<i class="fa-solid fa-sun"></i>';
                }
            }

            // Mark as watched/read history
            db.addToHistory(series.id, index);
            Gamification.addXP(10, "Webtoon Okuma");

            // --- NEW: Preload Next Chapter for Offline ---
            if (hasNext) {
                this.preloadNextChapter(contentList[index + 1]);
            }
        },

        preloadNextChapter(nextChapter) {
            if (!nextChapter || !nextChapter.pages) return;
            console.log(`🚀 Preloading Chapter ${nextChapter.number} for offline...`);
            nextChapter.pages.forEach(url => {
                const img = new Image();
                img.src = url;
            });
        },

        prevChapter() {
            const series = db.getSeries(this.currentSeriesId);
            const contentList = series.chapters || series.episodes || [];
            if (this.currentChapterIdx > 0) {
                const targetEp = contentList[this.currentChapterIdx - 1]; // Previous in array
                // Or verify logic: if sorted ASC, index-1 is previous. 
                // But if sorted DESC (Newest first), index+1 is previous.
                // DramicBox standard seems to be sorted ASC (Chapter 1 at 0).
                if (targetEp) {
                    WebtoonReader.openReader(this.currentSeriesId, targetEp.number);
                }
            }
        },

        nextChapter() {
            const series = db.getSeries(this.currentSeriesId);
            const contentList = series.chapters || series.episodes || [];
            if (this.currentChapterIdx < contentList.length - 1) {
                const targetEp = contentList[this.currentChapterIdx + 1];
                if (targetEp) {
                    WebtoonReader.openReader(this.currentSeriesId, targetEp.number);
                }
            }
        },

        toggleZenMode() {
            this.isZenMode = !this.isZenMode;
            const btn = document.getElementById('zen-mode-toggle');

            if (this.isZenMode) {
                document.body.classList.add('zen-active');
                if (btn) {
                    btn.classList.add('active');
                    btn.innerHTML = '<i class="fa-solid fa-sun"></i>';
                }
                Toast.info('Zen Modu: Aktif. Huzurlu okumalar... ✨');
            } else {
                document.body.classList.remove('zen-active');
                if (btn) {
                    btn.classList.remove('active');
                    btn.innerHTML = '<i class="fa-solid fa-moon"></i>';
                }
            }
        },

        toggleAutoScroll(forceState) {
            this.isAutoScrolling = forceState !== undefined ? forceState : !this.isAutoScrolling;
            const btn = document.getElementById('auto-scroll-toggle');

            if (this.isAutoScrolling) {
                if (btn) {
                    btn.classList.add('active');
                    btn.innerHTML = '<i class="fa-solid fa-pause"></i>';
                }
                this.scrollInterval = setInterval(() => {
                    window.scrollBy(0, this.scrollSpeed);

                    // Check if reach bottom
                    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 50) {
                        this.toggleAutoScroll(false);
                        Toast.success('Bölüm sonuna ulaşıldı.');
                    }
                }, 30);
            } else {
                if (btn) {
                    btn.classList.remove('active');
                    btn.innerHTML = '<i class="fa-solid fa-play"></i>';
                }
                if (this.scrollInterval) {
                    clearInterval(this.scrollInterval);
                    this.scrollInterval = null;
                }
            }
        },

        updateSpeed(val) {
            this.scrollSpeed = parseInt(val);
            // Optionally show visual feedback
        }
    };
    console.log('📖 Webtoon Reader Loaded');
}
