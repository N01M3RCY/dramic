/**
 * DRAMICBOX - ADVANCED GAMIFICATION SYSTEM (V2)
 * Handles XP, Levels, Achievements, 12-Hour Cooldown Chests, Collectible Cards, and Dramic Pass Tiers.
 */

const Gamification = {
    config: null,
    currentTab: 'chests',
    cooldownInterval: null,

    async init() {
        console.log('🏆 Gamification System V2 initialized');
        await this.loadConfig();
        this.initUserGamification();
        this.checkAchievements();
        this.injectStyles();
        
        // Start cooldown ticker if the panel is open
        this.startCooldownTicker();
    },

    // Achievement Definitions
    achievements: [
        { id: 'first_login', title: 'Hoşgeldin!', desc: 'DramicBox dünyasına ilk adım.', icon: '👋', xp: 100 },
        { id: 'watch_1', title: 'İlk İzleyiş', desc: 'İlk dizini izlemeye başladın.', icon: '📺', xp: 50 },
        { id: 'comment_5', title: 'Eleştirmen', desc: '5 farklı yapıma yorum yaptın.', icon: '✍️', xp: 250 },
        { id: 'streak_3', title: 'Dramic Streak', desc: '3 gün üst üste giriş yaptın.', icon: '🔥', xp: 300 },
        { id: 'finish_series', title: 'Seri Ustası', desc: 'Bir seriyi tamamen bitirdin.', icon: '🏆', xp: 1000 },
        { id: 'social_star', title: 'Sosyal Yıldız', desc: 'Bir gönderin 10 beğeni aldı.', icon: '⭐', xp: 500 },
        { id: 'market_buyer', title: 'Koleksiyoncu', desc: 'Marketten ilk ürününü aldın.', icon: '🛍️', xp: 200 }
    ],

    ranks: [
        { level: 1, name: 'Acemi İzleyici', color: '#94a3b8' },
        { level: 5, name: 'Dramic Fan', color: '#8b5cf6' },
        { level: 10, name: 'Elite Watcher', color: '#ec4899' },
        { level: 20, name: 'Dramic Master', color: '#f59e0b' },
        { level: 50, name: 'Legendary Fan', color: '#ef4444' }
    ],

    async loadConfig() {
        try {
            const res = await fetch('Database/gamification_config.json');
            if (res.ok) {
                this.config = await res.json();
                console.log('🎮 Gamification Config loaded from file.');
            }
        } catch (e) {
            console.error('Failed to load gamification config, using static defaults:', e);
        }

        if (!this.config) {
            // Robust static fallback
            this.config = {
                cards: [
                    { id: "card_song_kang", name: "Song Kang", rarity: "common", kdrama: "Sweet Home", baseValue: 50, avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80" },
                    { id: "card_han_so_hee", name: "Han So-hee", rarity: "common", kdrama: "Nevertheless", baseValue: 50, avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80" },
                    { id: "card_park_seo_jun", name: "Park Seo-jun", rarity: "rare", kdrama: "Itaewon Class", baseValue: 150, avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80" },
                    { id: "card_son_ye_jin", name: "Son Ye-jin", rarity: "rare", kdrama: "Crash Landing on You", baseValue: 150, avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=150&q=80" },
                    { id: "card_lee_min_ho", name: "Lee Min-ho", rarity: "epic", kdrama: "Boys Over Flowers", baseValue: 500, avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80" },
                    { id: "card_iu", name: "IU (Lee Ji-eun)", rarity: "legendary", kdrama: "Hotel Del Luna", baseValue: 2000, avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80" }
                ],
                chests: {
                    bronz: { name: "Bronz Sandık", price: 100, xpMin: 10, xpMax: 30, coinsMin: 20, coinsMax: 50, cardDropChance: 0.20, rarityWeight: { common: 1.0, rare: 0.0, epic: 0.0, legendary: 0.0 } },
                    gumus: { name: "Gümüş Sandık", price: 250, xpMin: 30, xpMax: 80, coinsMin: 50, coinsMax: 150, cardDropChance: 0.50, rarityWeight: { common: 0.8, rare: 0.2, epic: 0.0, legendary: 0.0 } },
                    altin: { name: "Altın Sandık", price: 600, xpMin: 80, xpMax: 200, coinsMin: 150, coinsMax: 400, cardDropChance: 0.80, rarityWeight: { common: 0.4, rare: 0.4, epic: 0.18, legendary: 0.02 } },
                    efsanevi: { name: "Efsanevi Sandık", price: 1500, xpMin: 200, xpMax: 500, coinsMin: 400, coinsMax: 1000, cardDropChance: 1.00, rarityWeight: { common: 0.0, rare: 0.5, epic: 0.35, legendary: 0.15 } }
                },
                passTiers: {
                    "2": { free: { type: "coins", value: 50, label: "50 Coin" }, vip: { type: "coins", value: 150, label: "150 Coin" } },
                    "3": { free: { type: "chest", value: "bronz", label: "Bronz Sandık" }, vip: { type: "frame", value: "frame_neon_purple", "label": "Neon Mor Çerçeve" } },
                    "4": { free: { type: "coins", value: 100, "label": "100 Coin" }, vip: { type: "chest", value: "altin", "label": "Altın Sandık" } },
                    "5": { free: { type: "vip_days", value: 1, "label": "1 Günlük VIP" }, vip: { type: "coins", value: 400, "label": "400 Coin" } }
                }
            };
        }
    },

    initUserGamification() {
        if (!State.currentUser || State.currentUser.role === 'guest') return;

        if (!State.currentUser.stats) {
            State.currentUser.stats = { xp: 0, level: 1, coins: 150 };
        }

        if (!State.currentUser.gamification) {
            State.currentUser.gamification = {
                cards: [],
                chests: {
                    bronz: 1,
                    gumus: 0,
                    altin: 0,
                    efsanevi: 0
                },
                lastFreeChestTime: 0,
                claimedTiers: {
                    free: [],
                    vip: []
                }
            };
        }

        // Fill keys if missing
        if (!State.currentUser.gamification.cards) State.currentUser.gamification.cards = [];
        if (!State.currentUser.gamification.chests) {
            State.currentUser.gamification.chests = { bronz: 1, gumus: 0, altin: 0, efsanevi: 0 };
        }
        if (!State.currentUser.gamification.claimedTiers) {
            State.currentUser.gamification.claimedTiers = { free: [], vip: [] };
        }
    },

    // --- LEVEL ENGINE ---
    getLevel(xp) {
        return Math.floor(Math.sqrt(xp / 100)) + 1;
    },

    getNextLevelXP(level) {
        return Math.pow(level, 2) * 100;
    },

    getXpToNextLevel(xp) {
        const currentLevel = this.getLevel(xp);
        const nextLevelXP = this.getNextLevelXP(currentLevel);
        return Math.max(0, nextLevelXP - xp);
    },

    getLevelProgress(xp) {
        const currentLevel = this.getLevel(xp);
        const nextLevelXP = this.getNextLevelXP(currentLevel);
        const prevLevelXP = currentLevel > 1 ? this.getNextLevelXP(currentLevel - 1) : 0;

        const range = nextLevelXP - prevLevelXP;
        if (range <= 0) return 0;

        const progress = ((xp - prevLevelXP) / range) * 100;
        return Math.min(Math.max(progress, 0), 100);
    },

    async addXP(amount, reason = 'Aktivite') {
        if (!State.currentUser || State.currentUser.role === 'guest') return;

        this.initUserGamification();
        const oldXP = State.currentUser.stats.xp || 0;
        const newXP = oldXP + amount;
        State.currentUser.stats.xp = newXP;

        const oldLevel = this.getLevel(oldXP);
        const newLevel = this.getLevel(newXP);
        State.currentUser.stats.level = newLevel;

        if (newLevel > oldLevel) {
            this.handleLevelUp(newLevel);
        }

        this.saveUser();

        // Update UI Live
        if (window.Auth && Auth.updateAuthUI) {
            Auth.updateAuthUI();
        }
    },

    handleLevelUp(newLevel) {
        const coinReward = 100 + (newLevel * 20);
        State.currentUser.stats.coins = (State.currentUser.stats.coins || 0) + coinReward;

        Toast.success(`🎉 TEBRİKLER! Seviye ${newLevel} oldunuz!`);
        Toast.info(`💰 ${coinReward} Coin kazanıldı! Dramic Pass ödüllerinizi kontrol edin.`);

        if (window.confetti) confetti();
    },

    // --- CHEST & LOOT ROLLING ---
    async openChest(chestType, isFree = false) {
        if (!State.currentUser || State.currentUser.role === 'guest') return;
        this.initUserGamification();

        const gamif = State.currentUser.gamification;

        // Normalize chest key
        const trKey = { bronze: 'bronz', silver: 'gumus', gold: 'altin', legendary: 'efsanevi' }[chestType] || chestType;
        const enKey = { bronz: 'bronze', gumus: 'silver', altin: 'gold', efsanevi: 'legendary' }[chestType] || chestType;
        const targetType = this.config.chests[trKey] ? trKey : (this.config.chests[enKey] ? enKey : chestType);

        if (isFree) {
            const cooldown = 12 * 60 * 60 * 1000;
            const diff = Date.now() - (gamif.lastFreeChestTime || 0);
            if (diff < cooldown) {
                const remaining = cooldown - diff;
                Toast.warning(`Sandık bekleme süresinde! Lütfen bekleyin: ${this.formatRemainingTime(remaining)}`);
                return;
            }
            gamif.lastFreeChestTime = Date.now();
        } else {
            if (gamif.chests[trKey] && gamif.chests[trKey] > 0) {
                gamif.chests[trKey]--;
            } else if (gamif.chests[enKey] && gamif.chests[enKey] > 0) {
                gamif.chests[enKey]--;
            } else if (gamif.chests[chestType] && gamif.chests[chestType] > 0) {
                gamif.chests[chestType]--;
            } else {
                Toast.error('Sahip olduğunuz bu sandıktan kalmadı!');
                return;
            }
        }

        const chestDef = this.config.chests[targetType] || this.config.chests[trKey] || this.config.chests[enKey];
        if (!chestDef) return;

        // Roll Loot
        const xpLoot = Math.floor(Math.random() * (chestDef.xpMax - chestDef.xpMin + 1)) + chestDef.xpMin;
        const coinLoot = Math.floor(Math.random() * (chestDef.coinsMax - chestDef.coinsMin + 1)) + chestDef.coinsMin;

        // Roll Cheer Points drop (10-250 depending on rarity)
        let cheerMin = 10;
        let cheerMax = 30;
        if (targetType === 'gumus' || targetType === 'silver') {
            cheerMin = 30;
            cheerMax = 80;
        } else if (targetType === 'altin' || targetType === 'gold') {
            cheerMin = 80;
            cheerMax = 150;
        } else if (targetType === 'efsanevi' || targetType === 'legendary') {
            cheerMin = 150;
            cheerMax = 250;
        }
        const cheerLoot = Math.floor(Math.random() * (cheerMax - cheerMin + 1)) + cheerMin;

        if (!State.currentUser.stats) State.currentUser.stats = {};
        State.currentUser.stats.cheerPoints = (State.currentUser.stats.cheerPoints || 0) + cheerLoot;

        const cardsPerOpen = chestDef.cardsPerOpen || { bronz: 1, gumus: 3, altin: 5, efsanevi: 5 }[targetType] || 1;
        const droppedCards = [];
        for (let i = 0; i < cardsPerOpen; i++) {
            if (Math.random() <= chestDef.cardDropChance) {
                const card = this.rollCardDrop(chestDef.rarityWeight);
                if (card) droppedCards.push(card);
            }
        }

        State.currentUser.stats.coins = (State.currentUser.stats.coins || 0) + coinLoot;
        
        if (!gamif.cards) gamif.cards = [];
        droppedCards.forEach(c => gamif.cards.push(c.id));

        this.saveUser();
        this.addXP(xpLoot, `${chestDef.name} Açılışı`);

        this.triggerChestOpenAnimation(chestDef.name, xpLoot, coinLoot, droppedCards, cheerLoot);
        
        // Refresh Hub UI if open
        const modal = document.querySelector('.gamification-modal');
        if (modal) {
            this.renderHubContent();
        }
        if (window.UserProfile && UserProfile.activeTab === 'gamification') {
            const container = document.getElementById('profile-tab-content');
            if (container) UserProfile.renderGamificationTab(container);
        }
        if (window.AdvancedProfile && document.getElementById('tab-content-inventory') && document.getElementById('tab-content-inventory').style.display !== 'none') {
            AdvancedProfile.renderInventoryTab(State.currentUser.id);
        }
    },

    rollCardDrop(weights) {
        const r = Math.random();
        let raritySelected = 'common';

        if (r < weights.legendary) {
            raritySelected = 'legendary';
        } else if (r < weights.legendary + weights.epic) {
            raritySelected = 'epic';
        } else if (r < weights.legendary + weights.epic + weights.rare) {
            raritySelected = 'rare';
        } else {
            raritySelected = 'common';
        }

        const availableCards = this.config.cards.filter(c => c.rarity === raritySelected);
        if (availableCards.length === 0) {
            // Fallback to any card
            return this.config.cards[Math.floor(Math.random() * this.config.cards.length)];
        }
        return availableCards[Math.floor(Math.random() * availableCards.length)];
    },

    triggerChestOpenAnimation(chestName, xp, coins, cards, cheer = 0) {
        const cardList = Array.isArray(cards) ? cards : (cards ? [cards] : []);
        const cardsHtml = cardList.length
            ? `<div style="display:flex; flex-wrap:wrap; gap:12px; justify-content:center; margin-top:12px;">
                ${cardList.map(card => `
                    <div class="reward-card-wrap rarity-${card.rarity}" style="flex:0 0 auto;">
                        <div class="card-glow"></div>
                        <img src="${card.avatar}" class="card-img" alt="${card.name}">
                        <div class="card-name">${card.name}</div>
                        <div class="card-meta">${card.kdrama}</div>
                        <span class="card-badge">${card.rarity.toUpperCase()}</span>
                    </div>
                `).join('')}
               </div>
               <p style="color:#a78bfa; font-size:0.9rem; margin-top:10px; font-weight:700;">${cardList.length} oyuncu kartı envanterine eklendi!</p>`
            : '<p style="color:#94a3b8; font-size:0.85rem; margin-top:8px;">Bu açılımda kart çıkmadı, bir sonrakinde şansını dene!</p>';

        const overlay = document.createElement('div');
        overlay.className = 'chest-open-animation-overlay';
        overlay.innerHTML = `
            <div class="animation-container">
                <div class="chest-box-shaker animate-shake">
                    <div class="chest-glow-light"></div>
                    <i class="fa-solid fa-box-open chest-large-icon"></i>
                </div>
                <h2 class="opening-title">${chestName} açılıyor...</h2>
                <div class="rewards-display" style="display: none; flex-direction:column; align-items:center;">
                    <div style="display:flex; gap:10px; flex-wrap:wrap; justify-content:center; margin-bottom:15px;">
                        <div class="reward-pill xp-pill">+${xp} XP</div>
                        <div class="reward-pill coin-pill">+${coins} DramiCoin</div>
                        ${cheer > 0 ? `<div class="reward-pill cheer-pill" style="background: linear-gradient(135deg, #ec4899, #f43f5e); color: white;"><i class="fa-solid fa-heart animate-pulse"></i> +${cheer} Cheer</div>` : ''}
                    </div>
                    ${cardsHtml}
                </div>
                <button class="btn btn-primary close-anim-btn" style="display: none;" onclick="this.closest('.chest-open-animation-overlay').remove()">Harika! 🎉</button>
            </div>
        `;
        document.body.appendChild(overlay);

        // Sound / Confetti
        if (window.confetti) confetti({ particleCount: 50, spread: 60 });

        // Trigger reveal
        setTimeout(() => {
            const shaker = overlay.querySelector('.chest-box-shaker');
            const title = overlay.querySelector('.opening-title');
            const rewards = overlay.querySelector('.rewards-display');
            const closeBtn = overlay.querySelector('.close-anim-btn');

            if (shaker) {
                shaker.classList.remove('animate-shake');
                shaker.classList.add('animate-burst');
            }

            setTimeout(() => {
                if (shaker) shaker.style.display = 'none';
                if (title) title.innerHTML = 'Kutudan Çıkan Ödüller!';
                if (rewards) {
                    rewards.style.display = 'flex';
                    rewards.classList.add('animate-fade-in');
                }
                if (closeBtn) closeBtn.style.display = 'inline-block';
                if (window.confetti) confetti({ particleCount: 80, spread: 80 });
            }, 800);
        }, 1200);
    },

    // --- COOLDOWN WORKOUT ---
    startCooldownTicker() {
        if (this.cooldownInterval) clearInterval(this.cooldownInterval);
        this.cooldownInterval = setInterval(() => {
            const timer = document.getElementById('free-chest-countdown-timer');
            if (timer) {
                const gamif = State.currentUser?.gamification;
                if (!gamif) return;
                const cooldown = 12 * 60 * 60 * 1000;
                const diff = Date.now() - (gamif.lastFreeChestTime || 0);

                if (diff < cooldown) {
                    const remaining = cooldown - diff;
                    timer.textContent = this.formatRemainingTime(remaining);
                } else {
                    if (window.UserProfile && UserProfile.activeTab === 'gamification') {
                        const container = document.getElementById('profile-tab-content');
                        if (container) UserProfile.renderGamificationTab(container);
                    }
                    this.renderHubContent(); // Rerender to show the unlock button!
                }
            }
        }, 1000);
    },

    formatRemainingTime(ms) {
        const seconds = Math.floor((ms / 1000) % 60);
        const minutes = Math.floor((ms / (1000 * 60)) % 60);
        const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);

        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    },

    // --- SHOP ACTIONS ---
    async buyChestFromShop(chestKey) {
        if (!State.currentUser || State.currentUser.role === 'guest') return;
        this.initUserGamification();

        const chestDef = this.config.chests[chestKey];
        if (!chestDef) return;

        const currentCoins = State.currentUser.stats.coins || 0;
        if (currentCoins < chestDef.price) {
            Toast.error('Yetersiz bakiye! Coin kazanmak için diziler izleyin ve yorum yapın.');
            return;
        }

        State.currentUser.stats.coins -= chestDef.price;
        State.currentUser.gamification.chests[chestKey] = (State.currentUser.gamification.chests[chestKey] || 0) + 1;

        this.saveUser();
        Toast.success(`${chestDef.name} başarıyla satın alındı! Envanterinizden açabilirsiniz.`);
        this.renderHubContent();
        if (window.UserProfile && UserProfile.activeTab === 'gamification') {
            const container = document.getElementById('profile-tab-content');
            if (container) UserProfile.renderGamificationTab(container);
        }
    },

    async sellItemBack(type, itemId) {
        if (!State.currentUser || State.currentUser.role === 'guest') return;
        this.initUserGamification();

        const gamif = State.currentUser.gamification;

        if (type === 'chest') {
            if (!gamif.chests[itemId] || gamif.chests[itemId] <= 0) return;
            const chestDef = this.config.chests[itemId];
            if (!chestDef) return;

            const value = Math.round(chestDef.price * 0.5);
            gamif.chests[itemId]--;
            State.currentUser.stats.coins = (State.currentUser.stats.coins || 0) + value;

            this.saveUser();
            Toast.success(`${chestDef.name} ${value} Coin karşılığında satıldı!`);
        } else if (type === 'card') {
            const index = gamif.cards.indexOf(itemId);
            if (index === -1) return;

            const cardDef = this.config.cards.find(c => c.id === itemId);
            if (!cardDef) return;

            gamif.cards.splice(index, 1);
            State.currentUser.stats.coins = (State.currentUser.stats.coins || 0) + cardDef.baseValue;

            this.saveUser();
            Toast.success(`${cardDef.name} oyuncu kartı ${cardDef.baseValue} Coin karşılığında sisteme satıldı!`);
        }

        this.renderHubContent();
        if (window.UserProfile && UserProfile.activeTab === 'gamification') {
            const container = document.getElementById('profile-tab-content');
            if (container) UserProfile.renderGamificationTab(container);
        }
    },

    // --- CLAIMING PASS REWARDS ---
    async claimPassTier(level, track) {
        if (!State.currentUser || State.currentUser.role === 'guest') return;
        this.initUserGamification();

        const gamif = State.currentUser.gamification;
        const currentLevel = State.currentUser.stats.level || 1;

        if (currentLevel < level) {
            Toast.error('Bu seviye henüz kilitli!');
            return;
        }

        const tierDef = this.config.passTiers[level.toString()];
        if (!tierDef) return;

        const reward = track === 'free' ? tierDef.free : tierDef.vip;
        if (!reward) return;

        if (track === 'vip') {
            // Check if user has VIP status
            const hasVip = State.currentUser.badges?.includes('VIP') || State.currentUser.role === 'admin' || State.currentUser.isVip;
            if (!hasVip) {
                Toast.error('VIP ödüllerini almak için VIP üye olmalısınız!');
                return;
            }
        }

        if (!gamif.claimedTiers[track]) gamif.claimedTiers[track] = [];
        if (gamif.claimedTiers[track].includes(level)) {
            Toast.info('Bu ödülü zaten aldınız!');
            return;
        }

        // Apply Reward
        if (reward.type === 'coins') {
            State.currentUser.stats.coins = (State.currentUser.stats.coins || 0) + reward.value;
        } else if (reward.type === 'chest') {
            gamif.chests[reward.value] = (gamif.chests[reward.value] || 0) + 1;
        } else if (reward.type === 'frame') {
            if (!State.currentUser.inventory) State.currentUser.inventory = [];
            State.currentUser.inventory.push(reward.value);
        } else if (reward.type === 'cheer_points' || reward.type === 'cheer') {
            if (!State.currentUser.stats) State.currentUser.stats = {};
            State.currentUser.stats.cheerPoints = (State.currentUser.stats.cheerPoints || 0) + reward.value;
        } else if (reward.type === 'vip_days') {
            // Give VIP badge or simulate VIP days
            if (!State.currentUser.badges) State.currentUser.badges = [];
            if (!State.currentUser.badges.includes('VIP')) State.currentUser.badges.push('VIP');
            State.currentUser.isVip = true;
        }

        gamif.claimedTiers[track].push(level);
        this.saveUser();
        Toast.success(`🎉 ${reward.label} ödülü başarıyla envanterinize eklendi!`);

        this.renderHubContent();
    },

    // --- FRONTEND UI RENDERING ---
    openGamificationHub() {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            Toast.warning('Oyunlaştırma merkezine erişmek için oturum açmalısınız!');
            if (window.Auth && Auth.showLogin) Auth.showLogin();
            return;
        }
        this.initUserGamification();

        // Remove old hub
        const oldHub = document.getElementById('gamification-hub-modal');
        if (oldHub) oldHub.remove();

        const modal = document.createElement('div');
        modal.className = 'modal gamification-modal';
        modal.id = 'gamification-hub-modal';
        modal.onclick = (e) => { if (e.target === modal) modal.remove(); };

        modal.innerHTML = `
            <div class="modal-content gamif-modal-content">
                <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                <div class="gamif-modal-header">
                    <h2>🎮 Dramic Hub: Seviye, Sandık & Kartlar</h2>
                    <p>Diziler izleyerek, yorumlar yaparak kartları toplayın, takas edin ve ödüller kazanın!</p>
                </div>
                
                <div class="gamif-tabs">
                    <button class="gamif-tab-btn active" id="gt-btn-chests" onclick="Gamification.switchTab('chests')">🎁 Sandık Portalı</button>
                    <button class="gamif-tab-btn" id="gt-btn-pass" onclick="Gamification.switchTab('pass')">🎫 Dramic Pass</button>
                    <button class="gamif-tab-btn" id="gt-btn-cards" onclick="Gamification.switchTab('cards')">🎴 Kart Envanteri</button>
                    <button class="gamif-tab-btn" id="gt-btn-shop" onclick="Gamification.switchTab('shop')">🛍️ Hub Dükkanı</button>
                </div>

                <div class="gamif-scroll-body custom-scrollbar" id="gamif-hub-body">
                    <!-- Dynamic rendering goes here -->
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        this.renderHubContent();
    },

    switchTab(tab) {
        this.currentTab = tab;
        document.querySelectorAll('.gamif-tab-btn').forEach(btn => btn.classList.remove('active'));
        const activeBtn = document.getElementById(`gt-btn-${tab}`);
        if (activeBtn) activeBtn.classList.add('active');

        this.renderHubContent();
    },

    renderHubContent() {
        const body = document.getElementById('gamif-hub-body');
        if (!body) return;

        const gamif = State.currentUser.gamification;
        const stats = State.currentUser.stats;
        const hasVip = State.currentUser.badges?.includes('VIP') || State.currentUser.role === 'admin' || State.currentUser.isVip;

        if (this.currentTab === 'chests') {
            // Sandık Portalı
            const cooldown = 12 * 60 * 60 * 1000;
            const diff = Date.now() - (gamif.lastFreeChestTime || 0);
            const isChestUnlocked = diff >= cooldown;

            body.innerHTML = `
                <div class="gamif-hub-section-inner">
                    <!-- Balance -->
                    <div class="g-balance-card">
                        <div class="b-details">
                            <span class="lbl">Hub Bakiyeniz</span>
                            <span class="val"><i class="fa-solid fa-coins"></i> ${stats.coins || 0} Coin</span>
                        </div>
                        <div class="b-details align-right">
                            <span class="lbl">Profil Seviyeniz</span>
                            <span class="val" style="color:var(--premium-violet);"><i class="fa-solid fa-star"></i> Lvl ${stats.level}</span>
                        </div>
                    </div>

                    <!-- Free Chest Card -->
                    <div class="g-portal-card free-chest-portal rarity-${hasVip ? 'rare' : 'common'}">
                        <div class="portal-light"></div>
                        <div style="font-size: 3.5rem; margin-bottom:12px;">🎁</div>
                        <h3>12 Saatlik Ücretsiz Sandık</h3>
                        <p class="desc">${hasVip ? '👑 VIP Özel: <strong>Gümüş Sandık</strong> açılacak!' : 'Standart Üye: <strong>Bronz Sandık</strong> açılacak! (VIP ile Gümüş açabilirsiniz)'}</p>
                        
                        <div class="action-wrap" style="margin-top:20px;">
                            ${isChestUnlocked ? `
                                <button class="btn btn-primary pulse-btn" onclick="Gamification.openChest('${hasVip ? 'gumus' : 'bronz'}', true)">
                                    <i class="fa-solid fa-gift"></i> Ücretsiz Sandığı Aç!
                                </button>
                            ` : `
                                <div class="timer-badge">
                                    <i class="fa-solid fa-clock-rotate-left"></i> Sonraki Açım: <span id="free-chest-countdown-timer">00:00:00</span>
                                </div>
                            `}
                        </div>
                    </div>

                    <!-- Owned Chests Grid -->
                    <h3 style="color:#fff; margin:30px 0 15px; font-weight:800; font-size:1.1rem;"><i class="fa-solid fa-box"></i> Envanterdeki Sandıklarım</h3>
                    <div class="chests-owned-grid">
                        ${Object.keys(this.config.chests).map(key => {
                            const count = gamif.chests[key] || 0;
                            const def = this.config.chests[key];
                            return `
                                <div class="owned-chest-item rarity-${key === 'bronz' ? 'common' : key === 'gumus' ? 'rare' : key === 'altin' ? 'epic' : 'legendary'}">
                                    <span class="count">x${count}</span>
                                    <div style="font-size:2rem; margin-bottom:5px;">📦</div>
                                    <div class="name">${def.name}</div>
                                    <button class="btn btn-sm btn-outline" ${count <= 0 ? 'disabled' : ''} onclick="Gamification.openChest('${key}', false)" style="margin-top:10px; width:100%;">
                                        Aç
                                    </button>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
            this.startCooldownTicker();

        } else if (this.currentTab === 'pass') {
            // Dramic Pass Tiers
            const progress = this.getLevelProgress(stats.xp);
            const nextXp = this.getXpToNextLevel(stats.xp);

            body.innerHTML = `
                <div class="gamif-hub-section-inner">
                    <!-- Progress bar -->
                    <div class="pass-progress-card">
                        <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-weight:800; font-size:0.9rem;">
                            <span>Lvl ${stats.level}</span>
                            <span style="color:#a78bfa;">Sonraki Seviyeye ${nextXp} XP kaldı</span>
                            <span>Lvl ${stats.level + 1}</span>
                        </div>
                        <div class="progress-bar-wrap">
                            <div class="fill" style="width:${progress}%"></div>
                        </div>
                    </div>

                    <!-- Pass Tiers List -->
                    <h3 style="color:#fff; margin:30px 0 15px; font-weight:800; font-size:1.1rem;"><i class="fa-solid fa-award"></i> Dramic Seviye Ödülleri</h3>
                    <div class="pass-tiers-wrapper">
                        ${Object.keys(this.config.passTiers).map(lvlStr => {
                            const lvl = parseInt(lvlStr);
                            const def = this.config.passTiers[lvlStr];
                            const isLvlReached = stats.level >= lvl;
                            
                            const freeClaimed = gamif.claimedTiers.free?.includes(lvl);
                            const vipClaimed = gamif.claimedTiers.vip?.includes(lvl);

                            return `
                                <div class="pass-tier-row ${isLvlReached ? 'reached' : 'locked'}">
                                    <div class="tier-badge">Lvl ${lvl}</div>
                                    
                                    <!-- Free Track Card -->
                                    <div class="track-reward-card free-track ${freeClaimed ? 'claimed' : ''}">
                                        <div class="meta">Ücretsiz Yol</div>
                                        <div class="reward-title">${def.free.label}</div>
                                        ${freeClaimed ? '<div class="claimed-txt">Alındı ✓</div>' : 
                                          isLvlReached ? `<button class="btn btn-sm btn-primary" onclick="Gamification.claimPassTier(${lvl}, 'free')">Al</button>` : 
                                          '<div class="lock"><i class="fa-solid fa-lock"></i> Kilitli</div>'}
                                    </div>

                                    <!-- VIP Track Card -->
                                    <div class="track-reward-card vip-track ${vipClaimed ? 'claimed' : ''} ${hasVip ? 'vip-active' : ''}">
                                        <div class="meta" style="color:#fbbf24;"><i class="fa-solid fa-crown"></i> VIP Yol</div>
                                        <div class="reward-title">${def.vip.label}</div>
                                        ${vipClaimed ? '<div class="claimed-txt" style="color:#fbbf24;">Alındı ✓</div>' : 
                                          isLvlReached ? (hasVip ? `<button class="btn btn-sm btn-primary" style="background:#fbbf24; color:#000;" onclick="Gamification.claimPassTier(${lvl}, 'vip')">Al</button>` : '<div class="lock" style="color:#fbbf24;"><i class="fa-solid fa-crown"></i> VIP Kilidi</div>') : 
                                          '<div class="lock"><i class="fa-solid fa-lock"></i> Kilitli</div>'}
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;

        } else if (this.currentTab === 'cards') {
            // Kart Envanteri
            const ownedCounts = {};
            gamif.cards.forEach(cid => { ownedCounts[cid] = (ownedCounts[cid] || 0) + 1; });

            body.innerHTML = `
                <div class="gamif-hub-section-inner">
                    <p style="color:#94a3b8; font-size:0.85rem; margin-bottom:20px; line-height:1.5;">Kutulardan çıkan K-Drama oyuncu kartları burada birikir. Tekrarlanan kartlarınızı dükkana geri satabilir veya Sohbet kutusundan arkadaşlarınızla takas edebilirsiniz!</p>
                    
                    <div class="cards-gallery-grid">
                        ${this.config.cards.map(c => {
                            const count = ownedCounts[c.id] || 0;
                            const isOwned = count > 0;
                            return `
                                <div class="gallery-card rarity-${c.rarity} ${isOwned ? '' : 'locked'}">
                                    <div class="card-light"></div>
                                    <img src="${c.avatar}" class="card-avatar" alt="${c.name}">
                                    <div class="card-name">${c.name}</div>
                                    <div class="card-drama">${c.kdrama}</div>
                                    <div class="card-badge">${c.rarity.toUpperCase()}</div>
                                    <div class="card-count">${isOwned ? `Adet: ${count}` : '🔒 KİLİTLİ'}</div>
                                    ${isOwned ? `
                                        <button class="btn btn-sm btn-outline sell-card-btn" onclick="Gamification.sellItemBack('card', '${c.id}')" style="margin-top:10px; width:100%; border-color:rgba(251,191,36,0.3); color:#fbbf24;">
                                            Dükkana Sat (+${c.baseValue} Coin)
                                        </button>
                                    ` : ''}
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;

        } else if (this.currentTab === 'shop') {
            // Hub Dükkanı
            body.innerHTML = `
                <div class="gamif-hub-section-inner">
                    <div class="g-balance-card" style="margin-bottom:25px;">
                        <div class="b-details">
                            <span class="lbl">Hub Bakiyeniz</span>
                            <span class="val"><i class="fa-solid fa-coins"></i> ${stats.coins || 0} Coin</span>
                        </div>
                    </div>

                    <h3 style="color:#fff; margin:0 0 15px; font-weight:800; font-size:1.1rem;"><i class="fa-solid fa-cart-shopping"></i> Sandık Satın Al</h3>
                    <div class="shop-chests-grid">
                        ${Object.keys(this.config.chests).map(key => {
                            const def = this.config.chests[key];
                            const cardChanceText = `${Math.round(def.cardDropChance * 100)}% Kart Şansı`;
                            return `
                                <div class="shop-chest-card rarity-${key === 'bronz' ? 'common' : key === 'gumus' ? 'rare' : key === 'altin' ? 'epic' : 'legendary'}">
                                    <div style="font-size:3rem; margin-bottom:10px;">📦</div>
                                    <div class="title">${def.name}</div>
                                    <div class="drop-desc">🪙 +${def.coinsMin}-${def.coinsMax} Coin | 🌟 +${def.xpMin}-${def.xpMax} XP</div>
                                    <div class="card-chance">${cardChanceText}</div>
                                    <div class="price">${def.price} Coin</div>
                                    <button class="btn btn-sm btn-primary" ${stats.coins < def.price ? 'disabled' : ''} onclick="Gamification.buyChestFromShop('${key}')" style="margin-top:12px; width:100%;">
                                        Satın Al
                                    </button>
                                </div>
                            `;
                        }).join('')}
                    </div>

                    <h3 style="color:#fff; margin:40px 0 15px; font-weight:800; font-size:1.1rem;"><i class="fa-solid fa-sack-dollar"></i> Sandık Geri Satışı</h3>
                    <p style="color:#94a3b8; font-size:0.85rem; margin-bottom:15px;">Dramic Pass'ten kazandığınız sandıklarınızı sistem dükkanına %50 değerine anında satabilirsiniz.</p>
                    <div class="sell-chests-list">
                        ${Object.keys(this.config.chests).map(key => {
                            const count = gamif.chests[key] || 0;
                            const def = this.config.chests[key];
                            const sellValue = Math.round(def.price * 0.5);
                            return `
                                <div style="display:flex; justify-content:space-between; align-items:center; padding:12px 18px; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.05); border-radius:14px; margin-bottom:10px;">
                                    <div style="font-weight:700; color:#fff;">${def.name} <span style="color:#a78bfa; font-size:0.8rem; font-weight:600; margin-left:10px;">(Adet: ${count})</span></div>
                                    <button class="btn btn-sm btn-outline" ${count <= 0 ? 'disabled' : ''} onclick="Gamification.sellItemBack('chest', '${key}')" style="border-color:rgba(239,68,68,0.3); color:#ef4444;">
                                        Geri Sat (+${sellValue} Coin)
                                    </button>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
        }
    },

    checkDailyLogin() {
        // TURNED OFF per user request to replace with the 12-hour Chest portal!
        console.log('Daily reward modal is deactivated. Use the Chest system instead.');
    },

    // --- LEGACY PORT FOR COMPATIBILITY ---
    checkDailyCommentBonus() {
        if (!State.currentUser) return;
        const lastCommentDate = State.currentUser.stats?.lastCommentDate || '';
        const today = new Date().toISOString().split('T')[0];

        if (lastCommentDate !== today) {
            this.addXP(15, 'Günün İlk Yorumu Bonusu');
            if (!State.currentUser.stats) State.currentUser.stats = {};
            State.currentUser.stats.lastCommentDate = today;
            this.saveUser();
            Toast.success('🎉 Günün ilk yorumu! +15 XP kazandın.');
        }
    },

    checkAchievements() {
        if (!State.currentUser) return;
        const user = State.currentUser;
        if (!user.achievements) user.achievements = [];

        const ownedIds = user.achievements.map(a => a.id);
        const newAchievements = [];

        if (!ownedIds.includes('first_login')) newAchievements.push('first_login');

        if (user.watchHistory) {
            const uniqueSeries = new Set(user.watchHistory.map(h => h.seriesId)).size;
            if (uniqueSeries >= 1 && !ownedIds.includes('watch_1')) newAchievements.push('watch_1');
        }

        newAchievements.forEach(id => {
            const ach = this.achievements.find(a => a.id === id);
            if (ach) {
                user.achievements.push({ id: id, date: Date.now() });
                this.addXP(ach.xp, `Başarım: ${ach.title}`);
                Toast.success(`🏆 Başarım: ${ach.title}`);
            }
        });

        if (newAchievements.length > 0) this.saveUser();
    },

    renderAchievements(containerId, userId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        let user = (State.currentUser && State.currentUser.id === userId) ? State.currentUser : State.data.users.find(u => u.id === userId);
        if (!user) { container.innerHTML = '<p class="text-muted">Kullanıcı bulunamadı.</p>'; return; }

        const userAchievements = user.achievements || [];
        if (userAchievements.length === 0) {
            container.innerHTML = `<div class="empty-state" style="text-align:center; padding:20px; opacity:0.6;"><i class="fa-solid fa-trophy"></i><p>Henüz başarım yok.</p></div>`;
            return;
        }

        container.innerHTML = `
            <div class="achievements-grid" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap:10px;">
                ${userAchievements.map(ua => {
            const ach = this.achievements.find(a => a.id === ua.id);
            if (!ach) return '';
            return `
                    <div style="background:rgba(255,255,255,0.05); padding:15px; border-radius:10px; text-align:center; border:1px solid rgba(255,255,255,0.1);">
                        <div style="font-size:2rem; margin-bottom:5px;">${ach.icon}</div>
                        <div style="font-weight:bold; font-size:0.85rem;">${ach.title}</div>
                    </div>`;
        }).join('')}
            </div>
        `;
    },

    saveUser() {
        if (window.db && window.db.updateUser) {
            db.updateUser(State.currentUser.id, {
                stats: State.currentUser.stats,
                gamification: State.currentUser.gamification,
                achievements: State.currentUser.achievements
            });
        }
        if (State.currentUser) {
            localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
        }
    },

    // --- STYLES SYSTEM ---
    injectStyles() {
        if (document.getElementById('gamif-v2-styles')) return;
        const styles = document.createElement('style');
        styles.id = 'gamif-v2-styles';
        styles.textContent = `
            .gamif-modal-content {
                max-width: 900px !important; width: 95%; height: 85vh;
                background: rgba(10, 10, 15, 0.95) !important;
                backdrop-filter: blur(40px); border: 1px solid rgba(255,255,255,0.08) !important;
                border-radius: 28px !important; display: flex; flex-direction: column; overflow: hidden;
            }
            .gamif-modal-header { padding: 24px 30px; border-bottom: 1px solid rgba(255,255,255,0.05); }
            .gamif-modal-header h2 { font-size: 1.4rem; color: #fff; font-weight: 800; margin: 0 0 6px; }
            .gamif-modal-header p { color: #94a3b8; font-size: 0.9rem; margin: 0; }
            
            .gamif-tabs { display: flex; gap: 8px; padding: 12px 30px; border-bottom: 1px solid rgba(255,255,255,0.04); background: rgba(0,0,0,0.1); }
            .gamif-tab-btn { padding: 10px 20px; font-weight: 700; font-size: 0.88rem; color: #64748b; border: none; background: transparent; cursor: pointer; border-radius: 12px; transition: 0.3s; }
            .gamif-tab-btn:hover { color: #fff; background: rgba(255,255,255,0.03); }
            .gamif-tab-btn.active { color: #a78bfa; background: rgba(139,92,246,0.1); }

            .gamif-scroll-body { flex: 1; overflow-y: auto; padding: 30px; }
            .gamif-hub-section-inner { display: flex; flex-direction: column; gap: 20px; }

            /* Balance Card */
            .g-balance-card {
                display: flex; justify-content: space-between; align-items: center;
                background: linear-gradient(135deg, rgba(139,92,246,0.08), rgba(251,191,36,0.05));
                border: 1px solid rgba(139,92,246,0.15); padding: 18px 24px; border-radius: 20px;
            }
            .g-balance-card .b-details { display: flex; flex-direction: column; gap: 4px; }
            .g-balance-card .b-details .lbl { font-size: 0.72rem; color: #94a3b8; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
            .g-balance-card .b-details .val { font-size: 1.4rem; color: #fbbf24; font-weight: 900; }
            .g-balance-card .b-details.align-right { text-align: right; }

            /* Free Chest Portal */
            .g-portal-card {
                background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05);
                border-radius: 24px; padding: 30px; text-align: center; position: relative; overflow: hidden;
            }
            .g-portal-card.rarity-rare { border-color: rgba(139,92,246,0.25); background: linear-gradient(180deg, rgba(139,92,246,0.03) 0%, rgba(0,0,0,0) 100%); }
            .portal-light { position: absolute; top: -50%; left:-50%; width:200%; height:200%; background: radial-gradient(circle, rgba(124,58,237,0.08) 0%, transparent 70%); pointer-events:none; }
            .g-portal-card h3 { font-size: 1.3rem; font-weight: 800; color: #fff; margin: 0 0 8px; }
            .g-portal-card .desc { font-size: 0.88rem; color: #94a3b8; margin: 0; }
            
            .timer-badge {
                display: inline-flex; align-items: center; gap: 8px;
                background: rgba(0,0,0,0.4); border: 1px solid rgba(255,255,255,0.08);
                padding: 10px 24px; border-radius: 20px; font-weight: 800; color: #fff; font-size: 1rem;
            }

            /* Owned Chests Grid */
            .chests-owned-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }
            .owned-chest-item {
                background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05);
                border-radius: 20px; padding: 20px 15px; text-align: center; position: relative;
            }
            .owned-chest-item .count { position: absolute; top: 12px; right: 14px; background: rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.1); padding: 2px 8px; border-radius: 10px; font-size: 0.72rem; font-weight: 800; color: #a78bfa; }
            .owned-chest-item .name { font-weight: 700; color: #fff; font-size: 0.85rem; }

            /* Rarity Styles */
            .rarity-common { border-color: rgba(255,255,255,0.06); }
            .rarity-rare { border-color: rgba(59,130,246,0.3); }
            .rarity-epic { border-color: rgba(139,92,246,0.3); }
            .rarity-legendary { border-color: rgba(251,191,36,0.3); }

            /* Pass Progress Card */
            .pass-progress-card { background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius: 20px; padding: 20px; }
            .progress-bar-wrap { width: 100%; height: 8px; background: rgba(255,255,255,0.06); border-radius: 4px; overflow: hidden; }
            .progress-bar-wrap .fill { height: 100%; background: linear-gradient(90deg, #7c3aed, #ec4899); border-radius: 4px; box-shadow: 0 0 12px rgba(124,58,237,0.5); }

            /* Pass Tiers */
            .pass-tiers-wrapper { display: flex; flex-direction: column; gap: 15px; }
            .pass-tier-row {
                display: flex; gap: 15px; align-items: center;
                background: rgba(255,255,255,0.015); border: 1px solid rgba(255,255,255,0.04);
                padding: 15px; border-radius: 20px; transition: 0.3s;
            }
            .pass-tier-row.reached { background: rgba(124,58,237,0.02); border-color: rgba(124,58,237,0.1); }
            .pass-tier-row.locked { opacity: 0.5; }
            .pass-tier-row .tier-badge {
                width: 60px; height: 60px; background: rgba(255,255,255,0.04);
                border-radius: 14px; display: flex; align-items: center; justify-content: center;
                font-weight: 900; color: #fff; font-size: 0.95rem; border: 1px solid rgba(255,255,255,0.08);
            }
            .pass-tier-row.reached .tier-badge { background: rgba(124,58,237,0.15); border-color: #7c3aed; color: #a78bfa; box-shadow:0 0 10px rgba(124,58,237,0.1); }
            
            .track-reward-card {
                flex: 1; background: rgba(255,255,255,0.025); border: 1px solid rgba(255,255,255,0.05);
                padding: 12px 18px; border-radius: 14px; display: flex; justify-content: space-between; align-items: center;
            }
            .track-reward-card .meta { font-size: 0.7rem; font-weight: 700; color: #64748b; text-transform: uppercase; }
            .track-reward-card .reward-title { font-weight: 800; color: #fff; font-size: 0.9rem; }
            .track-reward-card .claimed-txt { font-size: 0.8rem; font-weight: 800; color: #10b981; }
            .track-reward-card .lock { font-size: 0.8rem; font-weight: 700; color: #475569; display: flex; align-items: center; gap: 5px; }

            .track-reward-card.vip-track.vip-active { border-color: rgba(251,191,36,0.15); background: linear-gradient(135deg, rgba(251,191,36,0.02), rgba(0,0,0,0)); }

            /* Cards Gallery */
            .cards-gallery-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
            .gallery-card {
                background: rgba(255,255,255,0.02); border: 2px solid rgba(255,255,255,0.05);
                border-radius: 24px; padding: 25px 20px; text-align: center; position: relative;
                transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1); overflow: hidden;
            }
            .gallery-card:hover:not(.locked) {
                transform: translateY(-8px) scale(1.02);
                background: rgba(255,255,255,0.04);
                box-shadow: 0 15px 30px rgba(0,0,0,0.5);
            }
            .gallery-card.locked { opacity: 0.3; filter: grayscale(1); }
            .card-light { position: absolute; inset:0; background: radial-gradient(circle at 50% 30%, rgba(255,255,255,0.05) 0%, transparent 60%); pointer-events:none; }
            .gallery-card.rarity-rare:hover { border-color: rgba(59,130,246,0.5); box-shadow: 0 0 25px rgba(59,130,246,0.15); }
            .gallery-card.rarity-epic:hover { border-color: rgba(139,92,246,0.5); box-shadow: 0 0 25px rgba(139,92,246,0.15); }
            .gallery-card.rarity-legendary:hover { border-color: rgba(251,191,36,0.5); box-shadow: 0 0 25px rgba(251,191,36,0.15); }

            .card-avatar { width: 90px; height: 90px; border-radius: 50%; object-fit: cover; border: 3px solid rgba(255,255,255,0.08); margin-bottom: 12px; }
            .gallery-card.rarity-rare .card-avatar { border-color: #3b82f6; }
            .gallery-card.rarity-epic .card-avatar { border-color: #8b5cf6; }
            .gallery-card.rarity-legendary .card-avatar { border-color: #fbbf24; }
            
            .card-name { font-weight: 900; color: #fff; font-size: 1.1rem; }
            .card-drama { font-size: 0.75rem; color: #64748b; font-weight: 600; margin-top: 4px; }
            .card-badge { display: inline-block; font-size: 0.6rem; font-weight: 900; padding: 2px 8px; border-radius: 5px; text-transform: uppercase; margin-top: 10px; background: rgba(255,255,255,0.08); color: #fff; }
            .gallery-card.rarity-rare .card-badge { background: rgba(59,130,246,0.15); color: #3b82f6; }
            .gallery-card.rarity-epic .card-badge { background: rgba(139,92,246,0.15); color: #a78bfa; }
            .gallery-card.rarity-legendary .card-badge { background: rgba(251,191,36,0.15); color: #fbbf24; }
            
            .card-count { font-size: 0.72rem; color: #94a3b8; font-weight: 700; margin-top: 12px; text-transform: uppercase; letter-spacing: 0.5px; }

            /* Shop Chest Grid */
            .shop-chests-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }
            .shop-chest-card {
                background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05);
                border-radius: 20px; padding: 25px 15px; text-align: center; transition: 0.3s;
            }
            .shop-chest-card:hover { transform: translateY(-5px); background: rgba(255,255,255,0.04); }
            .shop-chest-card .title { font-weight: 800; color: #fff; font-size: 0.95rem; margin-bottom: 5px; }
            .shop-chest-card .drop-desc { font-size: 0.72rem; color: #64748b; font-weight: 600; }
            .shop-chest-card .card-chance { font-size: 0.72rem; color: #a78bfa; font-weight: 800; margin-top: 5px; }
            .shop-chest-card .price { font-size: 1.1rem; color: #fbbf24; font-weight: 900; margin-top: 15px; }

            /* CHEST OPENING STYLES */
            .chest-open-animation-overlay {
                position: fixed; inset: 0; background: rgba(5,5,10,0.95); z-index: 100000;
                display: flex; align-items: center; justify-content: center;
                animation: fadeIn 0.4s ease;
            }
            .animation-container { text-align: center; display: flex; flex-direction: column; align-items: center; gap: 20px; }
            .chest-large-icon { font-size: 6rem; color: #fbbf24; filter: drop-shadow(0 0 30px rgba(251,191,36,0.3)); }
            .opening-title { color: #fff; font-weight: 900; font-size: 2rem; }
            .rewards-display { display: flex; align-items: center; justify-content: center; gap: 20px; margin-top: 30px; }
            .reward-pill { padding: 15px 30px; border-radius: 16px; font-size: 1.2rem; font-weight: 900; color: #fff; }
            .reward-pill.xp-pill { background: rgba(139,92,246,0.2); border: 2px solid #8b5cf6; box-shadow: 0 0 20px rgba(139,92,246,0.3); }
            .reward-pill.coin-pill { background: rgba(251,191,36,0.2); border: 2px solid #fbbf24; box-shadow: 0 0 20px rgba(251,191,36,0.3); }
            
            .reward-card-wrap {
                width: 140px; background: rgba(255,255,255,0.03); border: 2px solid rgba(255,255,255,0.1);
                border-radius: 20px; padding: 18px 12px; text-align: center; position: relative; overflow: hidden;
            }
            .reward-card-wrap .card-glow { position: absolute; inset:0; background:radial-gradient(circle at 50% 20%, rgba(255,255,255,0.1) 0%, transparent 60%); }
            .reward-card-wrap.rarity-rare { border-color:#3b82f6; box-shadow: 0 0 20px rgba(59,130,246,0.2); }
            .reward-card-wrap.rarity-epic { border-color:#8b5cf6; box-shadow: 0 0 20px rgba(139,92,246,0.2); }
            .reward-card-wrap.rarity-legendary { border-color:#fbbf24; box-shadow: 0 0 30px rgba(251,191,36,0.3); }
            .reward-card-wrap .card-img { width: 65px; height: 65px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(255,255,255,0.1); margin-bottom: 8px; }
            .reward-card-wrap.rarity-rare .card-img { border-color:#3b82f6; }
            .reward-card-wrap.rarity-epic .card-img { border-color:#8b5cf6; }
            .reward-card-wrap.rarity-legendary .card-img { border-color:#fbbf24; }
            .reward-card-wrap .card-name { font-weight: 800; font-size: 0.9rem; color: #fff; }
            .reward-card-wrap .card-meta { font-size: 0.65rem; color: #64748b; margin-top: 2px; }
            .reward-card-wrap .card-badge { display: inline-block; font-size: 0.5rem; font-weight: 900; padding: 1px 6px; border-radius: 4px; text-transform: uppercase; margin-top: 6px; }

            /* Animations */
            @keyframes pulse-btn {
                0%, 100% { transform: scale(1); box-shadow: 0 5px 15px rgba(124,58,237,0.4); }
                50% { transform: scale(1.03); box-shadow: 0 8px 25px rgba(124,58,237,0.6); }
            }
            .pulse-btn { animation: pulse-btn 2s infinite; }
            
            .animate-shake {
                animation: shake 0.6s cubic-bezier(.36,.07,.19,.97) infinite;
            }
            @keyframes shake {
                10%, 90% { transform: translate3d(-2px, 0, 0) rotate(-2deg); }
                20%, 80% { transform: translate3d(3px, 0, 0) rotate(2deg); }
                30%, 50%, 70% { transform: translate3d(-5px, 0, 0) rotate(-4deg); }
                40%, 60% { transform: translate3d(5px, 0, 0) rotate(4deg); }
            }
            .animate-burst {
                animation: burst 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
            }
            @keyframes burst {
                0% { transform: scale(1); opacity: 1; }
                50% { transform: scale(1.3); opacity: 0.8; filter: brightness(2); }
                100% { transform: scale(0.3); opacity: 0; }
            }
            .animate-fade-in { animation: fadeIn 0.5s ease forwards; }

            @media (max-width: 768px) {
                .chests-owned-grid, .shop-chests-grid { grid-template-columns: repeat(2, 1fr); }
                .cards-gallery-grid { grid-template-columns: repeat(2, 1fr); }
                .pass-tier-row { flex-direction: column; align-items: stretch; }
                .pass-tier-row .tier-badge { align-self: center; }
                .rewards-display { flex-direction: column; }
            }
            @media (max-width: 480px) {
                .chests-owned-grid, .shop-chests-grid { grid-template-columns: 1fr; }
                .cards-gallery-grid { grid-template-columns: 1fr; }
            }
        `;
        document.head.appendChild(styles);
    }
};

// Global Exposure
window.Gamification = Gamification;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        Gamification.init();
    }, 1600);
});
