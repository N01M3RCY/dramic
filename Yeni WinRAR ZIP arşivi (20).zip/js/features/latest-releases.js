// ============================================
// LATEST RELEASES SYSTEM
// Shows latest 100 episodes with filters
// ============================================

const LatestReleases = {
    currentFilter: 'all',

    init(filterType) {
        if (filterType && filterType !== 'all') {
            this.currentFilter = filterType;
        } else if (filterType === 'all') {
            this.currentFilter = 'all';
        }
        this.renderCarousel();
    },

    filterType(type) {
        this.currentFilter = type;
        this.renderCarousel();
    },

    toggleFilters() {
        const tabs = document.getElementById('latest-filter-tabs');
        if (!tabs) return;
        const isHidden = tabs.style.display === 'none';
        tabs.style.display = isHidden ? 'block' : 'none';
        
        if (isHidden) {
            tabs.style.opacity = '0';
            tabs.style.transform = 'translateY(-10px)';
            setTimeout(() => {
                tabs.style.transition = 'all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)';
                tabs.style.opacity = '1';
                tabs.style.transform = 'translateY(0)';
            }, 10);
        }
    },

    filter(type, btn) {
        document.querySelectorAll('.latest-filter-btn').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
        this.filterType(type);
    },

    getLatestEpisodes(limit = 10) {
        if (!State.data || !State.data.series) {
            console.warn('LatestReleases: State.data.series is missing');
            return [];
        }

        // --- VIP CHECK ---
        const user = State.currentUser;
        const isLoggedIn = user && user.role && user.role !== 'guest';
        const isVipUser = isLoggedIn && (
            user.role === 'admin' ||
            user.role === 'moderator' ||
            user.role === 'vip' ||
            (user.vipUntil && new Date(user.vipUntil) > new Date())
        );

        const allEpisodes = [];

        // Get all series
        State.data.series.forEach(series => {
            // Filter by type
            if (this.currentFilter !== 'all' && series.type !== this.currentFilter) {
                return;
            }

            // Skip disabled systems
            const sysMap = { 'drama': 'drama', 'anime': 'anime', 'webtoon': 'webtoon', 'short': 'shorts' };
            const sysKey = sysMap[series.type] || series.type;
            if (window.App && !App.isSystemEnabled(sysKey)) {
                return;
            }

            // VIP FILTER: Exclude VIP content if user is not VIP
            if (!isVipUser && (series.isVip || series.isPremium)) {
                return;
            }

            // Get episodes from seasons or direct episodes
            if (Array.isArray(series.seasons)) {
                let absoluteIndex = 0;
                series.seasons.forEach(season => {
                    if (Array.isArray(season.episodes)) {
                        season.episodes.forEach(episode => {
                            if (episode.isPublished) {
                                allEpisodes.push({
                                    series: series,
                                    episode: episode,
                                    seasonNumber: season.number,
                                    index: absoluteIndex,
                                    addedAt: episode.addedAt ? new Date(episode.addedAt).getTime() : (series.lastUpdated || Date.now())
                                });
                            }
                            absoluteIndex++;
                        });
                    }
                });
            } else if (Array.isArray(series.episodes)) {
                series.episodes.forEach((episode, idx) => {
                    if (episode.isPublished) {
                        allEpisodes.push({
                            series: series,
                            episode: episode,
                            seasonNumber: null,
                            index: idx,
                            addedAt: episode.addedAt ? new Date(episode.addedAt).getTime() : (series.lastUpdated || Date.now())
                        });
                    }
                });
            } else if (series.chapters) {
                // Webtoon chapters
                for (let i = 1; i <= series.chapters; i++) {
                    allEpisodes.push({
                        series: series,
                        episode: { number: i, title: `${i}. Bölüm` },
                        seasonNumber: null,
                        index: i - 1,
                        addedAt: series.lastUpdated || Date.now()
                    });
                }
            }
        });

        // Sort by added date (newest first)
        allEpisodes.sort((a, b) => b.addedAt - a.addedAt);

        console.log(`LatestReleases: Found ${allEpisodes.length} total episodes.`);
        return allEpisodes.slice(0, limit);
    },

    renderCarousel() {
        const container = document.getElementById('latest-releases-carousel');
        if (!container) return;

        // Mobile Optimization: Show button instead of carousel
        if (window.innerWidth <= 768) {
            // Adjust parent padding for mobile
            if (container.parentElement) {
                container.parentElement.style.padding = '0 20px';
            }

            container.style.display = 'block'; // Disable flex for this view
            container.innerHTML = `
                <div style="text-align: center; padding: 10px 0;">
                    <button class="btn btn-primary" onclick="LatestReleases.showAllModal()" style="width: 100%; padding: 15px; font-size: 1.1rem; border-radius: 12px; background: var(--accent-gradient); border: none; box-shadow: 0 4px 15px rgba(94, 114, 228, 0.4); display: flex; align-items: center; justify-content: center; gap: 10px;">
                        <i class="fa-solid fa-layer-group"></i> 
                        <span>Son Eklenenleri Gör</span>
                    </button>
                    <p style="margin-top: 10px; font-size: 0.85rem; color: var(--text-secondary);">En yeni 100 bölümü listelemek için tıklayın</p>
                </div>
            `;
            return;
        }

        // Desktop View: Reset styles if returning from mobile resize
        if (container.parentElement) {
            container.parentElement.style.padding = '';
        }
        container.style.display = 'flex';
        container.style.flexWrap = 'nowrap';
        container.style.overflowX = 'auto';
        container.style.gap = '20px';
        container.style.paddingBottom = '15px';
        container.style.overflowX = 'auto'; // Ensure usage of scroll
        container.style.paddingBottom = '20px'; // Space for shadow/transform

        const latest = this.getLatestEpisodes(10);

        if (latest.length === 0) {
            container.innerHTML = '<p style="color: var(--text-secondary); padding: 40px; text-align: center;">Henüz bölüm eklenmedi.</p>';
            return;
        }

        container.innerHTML = latest.map(item => {
            if (window.StandardCard) {
                return `
                    <div style="flex: 0 0 220px;">
                        ${StandardCard.render(item.series, { episode: item.episode.number })}
                    </div>
                `;
            }

            const poster = item.series.poster || item.series.coverImage || 'assets/poster-placeholder.jpg';
            const title = item.series.title;
            const episodeNum = item.episode.number;
            const typeLabel = item.series.type === 'webtoon' ? 'Webtoon' : (item.series.type === 'anime' ? 'Anime' : 'Dizi');
            const timeAgo = this.timeAgo(item.addedAt);
            const clickAction = `LatestReleases.openContent('${item.series.id}', ${item.series.type === 'webtoon' ? item.episode.number : (item.index || 0)}, '${item.series.type}')`;

            return `
            <div onclick="${clickAction}" class="carousel-item-link" style="flex: 0 0 220px; text-decoration:none; color:inherit; cursor:pointer;">
                <div class="standard-media-card">
                    <img src="${poster}" alt="${title}" class="std-card-poster" loading="lazy">
                    <div class="std-card-badges">
                        <span class="std-badge episode">Bölüm ${episodeNum}</span>
                        <span class="std-badge type">${typeLabel}</span>
                    </div>
                    <div class="std-card-overlay">
                        <div class="std-card-meta">
                            <span>${timeAgo}</span>
                        </div>
                        <h3 class="std-card-title">${title}</h3>
                    </div>
                    <div class="std-card-action"><i class="fa-solid fa-play"></i></div>
                </div>
            </div>
        `;
        }).join('');
    },

    openContent(seriesId, refIndex, type) {
        if (!seriesId) {
            Toast.error('İçerik ID bulunamadı!');
            return;
        }

        if (type === 'webtoon') {
            // Check if WebtoonReader exists
            if (window.WebtoonReader) {
                WebtoonReader.openReader(seriesId, refIndex); // refIndex is episode number here
            } else {
                Toast.error('Webtoon okuyucu yüklenemedi.');
            }
        } else {
            // Standard Player
            App.router('player', seriesId, refIndex); // refIndex is array index
        }
    },

    renderEpisodeBadges(item) {
        // ... kept as helper if needed, but unused in standard card currently ...
        return '';
    },

    showAllModal() {
        const latest = this.getLatestEpisodes(100);

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 1200px; max-height: 90vh;">
                <div class="modal-header">
                    <h2>Son Eklenen 100 Bölüm</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div style="padding: 25px; overflow-y: auto; max-height: calc(90vh - 100px);">
                    <div class="latest-filter-btns" style="margin-bottom: 20px;">
                        <button class="filter-btn ${this.currentFilter === 'all' ? 'active' : ''}" onclick="LatestReleases.filterTypeInModal('all', event)">Tümü</button>
                        <button class="filter-btn ${this.currentFilter === 'drama' ? 'active' : ''}" onclick="LatestReleases.filterTypeInModal('drama', event)">Diziler</button>
                        <button class="filter-btn ${this.currentFilter === 'anime' ? 'active' : ''}" onclick="LatestReleases.filterTypeInModal('anime', event)">Animeler</button>
                        <button class="filter-btn ${this.currentFilter === 'webtoon' ? 'active' : ''}" onclick="LatestReleases.filterTypeInModal('webtoon', event)">Webtoonlar</button>
                    </div>
                    <div class="latest-episodes-grid standard-grid" id="latest-episodes-grid">
                        ${this.renderLatestGrid(latest)}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    filterTypeInModal(type, event) {
        this.currentFilter = type;
        const latest = this.getLatestEpisodes(100);
        document.getElementById('latest-episodes-grid').innerHTML = this.renderLatestGrid(latest);

        // Update buttons
        if (event && event.target) {
            document.querySelectorAll('.latest-filter-btns .filter-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
        }
    },

    renderLatestGrid(episodes) {
        if (episodes.length === 0) {
            return '<p style="text-align: center; color: var(--text-secondary); padding: 40px; grid-column: 1/-1;">Bölüm bulunamadı.</p>';
        }

        return episodes.map(item => {
            if (window.StandardCard) {
                return `<div>${StandardCard.render(item.series, { episode: item.episode.number })}</div>`;
            }
            
            const clickAction = `LatestReleases.openContent('${item.series.id}', ${item.series.type === 'webtoon' ? item.episode.number : (item.index || 0)}, '${item.series.type}'); document.querySelector('.modal').remove();`;
            const poster = item.series.poster || item.series.coverImage || 'assets/poster-placeholder.jpg';
            const title = item.series.title;
            const episodeNum = item.episode.number;
            const typeLabel = item.series.type === 'webtoon' ? 'Webtoon' : (item.series.type === 'anime' ? 'Anime' : 'Dizi');
            const timeAgo = this.timeAgo(item.addedAt);

            return `
            <div onclick="${clickAction}" style="cursor:pointer;">
                <div class="standard-media-card">
                    <img src="${poster}" alt="${title}" class="std-card-poster" loading="lazy">
                    <div class="std-card-badges">
                        <span class="std-badge episode">Bölüm ${episodeNum}</span>
                        <span class="std-badge type">${typeLabel}</span>
                    </div>
                    <div class="std-card-overlay">
                        <div class="std-card-meta">
                            <span>${timeAgo}</span>
                        </div>
                        <h3 class="std-card-title">${title}</h3>
                    </div>
                    <div class="std-card-action"><i class="fa-solid fa-play"></i></div>
                </div>
            </div>
        `}).join('');
    },

    timeAgo(timestamp) {
        const seconds = Math.floor((Date.now() - timestamp) / 1000);

        if (seconds < 60) return 'Az önce';
        if (seconds < 3600) return Math.floor(seconds / 60) + ' dakika önce';
        if (seconds < 86400) return Math.floor(seconds / 3600) + ' saat önce';
        if (seconds < 604800) return Math.floor(seconds / 86400) + ' gün önce';

        return new Date(timestamp).toLocaleDateString('tr-TR');
    }
};

// Initialize
// Initialize is handled by App.js after data load
// document.addEventListener('DOMContentLoaded', () => {
//     setTimeout(() => {
//         LatestReleases.init();
//     }, 2000);
// });

console.log('✅ Latest Releases System Loaded!');
window.LatestReleases = LatestReleases;
