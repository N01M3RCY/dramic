/**
 * Dramicbox Friend Center System
 * Handles followers, following, and friend relationships with a premium UI.
 */
const FriendCenter = {
    currentFilter: 'friends', // 'friends', 'followers', 'following', 'requests'

    render() {
        if (!State.currentUser || State.currentUser.role === 'guest') {
            return `<div class="social-empty-state">
                <i class="fa-solid fa-user-lock"></i>
                <h3>Giriş Yapmalısın</h3>
                <p>Arkadaş merkezini görmek için lütfen giriş yapın.</p>
                <button class="btn btn-primary" onclick="Auth.showLogin()">Giriş Yap</button>
            </div>`;
        }

        const user = State.currentUser;
        const friendsCount = (user.friends || []).length;
        const followersCount = (user.followers || []).length;
        const followingCount = (user.following || []).length;
        const requestsCount = (user.friendRequests || []).length + (user.followRequests || []).length;

        return `
            <div class="friend-center-container">
                <!-- Header Stats -->
                <div class="friend-stats-grid" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 25px;">
                    ${this.renderStatCard('Arkadaşlar', friendsCount, 'fa-user-group', 'friends')}
                    ${this.renderStatCard('Takipçiler', followersCount, 'fa-users', 'followers')}
                    ${this.renderStatCard('Takip Edilenler', followingCount, 'fa-user-plus', 'following')}
                    ${this.renderStatCard('İstekler', requestsCount, 'fa-clock', 'requests', requestsCount > 0)}
                </div>

                <!-- Main Content Area -->
                <div class="glass-card" style="padding: 0; overflow: hidden; border-radius: 24px; border: 1px solid var(--border-premium);">
                    <div style="padding: 20px 25px; border-bottom: 1px solid var(--border-premium); display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.02);">
                        <h3 id="friend-center-title" style="margin: 0; font-size: 1.1rem; color: #fff;">${this.getFilterTitle()}</h3>
                        <div class="friend-search-box" style="position: relative;">
                            <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #64748b; font-size: 0.8rem;"></i>
                            <input type="text" placeholder="Listede ara..." oninput="FriendCenter.filterList(this.value)" 
                                style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 8px 12px 8px 35px; color: #fff; font-size: 0.85rem; width: 200px; outline: none; transition: all 0.3s;">
                        </div>
                    </div>
                    
                    <div id="friend-center-list" style="min-height: 400px; padding: 15px;">
                        ${this.renderActiveList()}
                    </div>
                </div>

                <!-- Suggestions Section -->
                <div style="margin-top: 30px;">
                    <h3 style="color: #fff; font-size: 1.2rem; font-weight: 800; margin-bottom: 15px; display: flex; align-items: center; gap: 10px;">
                        <i class="fa-solid fa-wand-magic-sparkles" style="color: #a78bfa;"></i> Tanıyor Olabilirsin
                    </h3>
                    <div id="friend-suggestions-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;">
                        ${this.renderSuggestions()}
                    </div>
                </div>
            </div>
        `;
    },

    renderStatCard(label, count, icon, filter, hasAlert = false) {
        const isActive = this.currentFilter === filter;
        return `
            <div class="friend-stat-card ${isActive ? 'active' : ''}" onclick="FriendCenter.switchFilter('${filter}')" 
                style="background: ${isActive ? 'linear-gradient(135deg, rgba(124,58,237,0.15), rgba(236,72,153,0.15))' : 'rgba(255,255,255,0.02)'}; 
                       border: 1px solid ${isActive ? 'var(--premium-violet)' : 'var(--border-premium)'}; 
                       padding: 20px; border-radius: 20px; cursor: pointer; text-align: center; transition: all 0.3s; position: relative;">
                ${hasAlert ? `<span style="position: absolute; top: 10px; right: 10px; width: 10px; height: 10px; background: #ef4444; border-radius: 50%; box-shadow: 0 0 10px #ef4444;"></span>` : ''}
                <div style="font-size: 1.5rem; margin-bottom: 8px; color: ${isActive ? 'var(--premium-violet)' : '#64748b'};">
                    <i class="fa-solid ${icon}"></i>
                </div>
                <div style="font-size: 1.5rem; font-weight: 900; color: #fff;">${count}</div>
                <div style="font-size: 0.75rem; color: #94a3b8; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">${label}</div>
            </div>
        `;
    },

    getFilterTitle() {
        switch(this.currentFilter) {
            case 'friends': return 'Arkadaşlarım';
            case 'followers': return 'Takipçilerim';
            case 'following': return 'Takip Ettiklerim';
            case 'requests': return 'Bekleyen İstekler';
            default: return 'Kullanıcılar';
        }
    },

    switchFilter(filter) {
        this.currentFilter = filter;
        const container = document.getElementById('social-tab-content');
        if (container) {
            container.innerHTML = this.render();
        }
    },

    renderActiveList(query = '') {
        const user = State.currentUser;
        let list = [];
        
        switch(this.currentFilter) {
            case 'friends':
                list = (user.friends || []).map(id => State.data.users.find(u => u.id === id)).filter(u => u);
                break;
            case 'followers':
                list = (user.followers || []).map(id => State.data.users.find(u => u.id === id)).filter(u => u);
                break;
            case 'following':
                list = (user.following || []).map(id => State.data.users.find(u => u.id === id)).filter(u => u);
                break;
            case 'requests':
                return this.renderRequestsList();
        }

        if (query) {
            list = list.filter(u => u.username.toLowerCase().includes(query.toLowerCase()));
        }

        if (list.length === 0) {
            return `<div style="text-align: center; padding: 50px; color: #64748b;">
                <i class="fa-solid fa-user-slash" style="font-size: 3rem; opacity: 0.2; margin-bottom: 15px;"></i>
                <p>Burada henüz kimse yok.</p>
            </div>`;
        }

        return `
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 15px;">
                ${list.map(u => this.renderUserCard(u)).join('')}
            </div>
        `;
    },

    renderUserCard(u) {
        const presence = (window.SocialFeed && window.SocialFeed.getUserPresence) ? window.SocialFeed.getUserPresence(u) : { status: 'offline', label: 'Çevrimdışı' };
        const isFriend = (State.currentUser.friends || []).includes(u.id);
        const isFollowing = (State.currentUser.following || []).includes(u.id);

        return `
            <div class="friend-card-premium" style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 18px; padding: 15px; display: flex; align-items: center; gap: 15px; transition: all 0.3s;" onmouseenter="this.style.background='rgba(255,255,255,0.05)'; this.style.borderColor='rgba(124,58,237,0.2)'" onmouseleave="this.style.background='rgba(255,255,255,0.03)'; this.style.borderColor='rgba(255,255,255,0.06)'">
                <div style="position: relative; width: 60px; height: 60px; flex-shrink: 0;">
                    <img src="${u.avatar || 'assets/logo.png'}" style="width: 100%; height: 100%; border-radius: 16px; object-fit: cover; border: 2px solid rgba(255,255,255,0.05);">
                    <span style="position: absolute; bottom: -2px; right: -2px; width: 14px; height: 14px; border-radius: 50%; background: ${presence.status === 'online' ? '#10b981' : '#64748b'}; border: 3px solid #0f0f13;"></span>
                </div>
                <div style="flex: 1; min-width: 0;">
                    <div style="font-weight: 700; color: #fff; font-size: 1rem; cursor: pointer;" onclick="SocialFeed.goToProfile('${u.username}')">${u.username}</div>
                    <div style="font-size: 0.75rem; color: #64748b;">${presence.label}</div>
                    <div style="display: flex; gap: 5px; margin-top: 8px;">
                        <button onclick="SocialFeed.startChat('${u.id}')" style="background: rgba(124,58,237,0.1); border: none; color: #a78bfa; padding: 5px 10px; border-radius: 8px; font-size: 0.75rem; cursor: pointer; font-weight: 600;"><i class="fa-solid fa-message"></i></button>
                        <button onclick="SocialFeed.toggleFollow('${u.id}')" style="background: rgba(255,255,255,0.05); border: none; color: #fff; padding: 5px 10px; border-radius: 8px; font-size: 0.75rem; cursor: pointer; font-weight: 600;"><i class="fa-solid ${isFollowing ? 'fa-user-check' : 'fa-user-plus'}"></i></button>
                    </div>
                </div>
                <div style="cursor: pointer; color: #475569;" onclick="FriendCenter.showQuickMenu('${u.id}')">
                    <i class="fa-solid fa-ellipsis-vertical"></i>
                </div>
            </div>
        `;
    },

    renderRequestsList() {
        const user = State.currentUser;
        const fReqs = user.friendRequests || [];
        const followReqs = user.followRequests || [];

        if (fReqs.length === 0 && followReqs.length === 0) {
            return `<div style="text-align: center; padding: 50px; color: #64748b;">
                <i class="fa-solid fa-bell-slash" style="font-size: 3rem; opacity: 0.2; margin-bottom: 15px;"></i>
                <p>Bekleyen bir isteğiniz yok.</p>
            </div>`;
        }

        let html = '';
        if (fReqs.length > 0) {
            html += `<h4 style="color: #a78bfa; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; margin: 10px 0 15px;">Arkadaşlık İstekleri</h4>
            <div style="display: grid; gap: 10px; margin-bottom: 30px;">
                ${fReqs.map((r, i) => {
                    const sender = State.data.users.find(u => u.id === r.fromId);
                    if (!sender) return '';
                    return this.renderRequestCard(sender, i, 'friend');
                }).join('')}
            </div>`;
        }

        if (followReqs.length > 0) {
            html += `<h4 style="color: #3b82f6; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; margin: 10px 0 15px;">Takip İstekleri</h4>
            <div style="display: grid; gap: 10px;">
                ${followReqs.map((r, i) => {
                    const fromId = typeof r === 'object' ? r.fromId : r;
                    const sender = State.data.users.find(u => u.id === fromId);
                    if (!sender) return '';
                    return this.renderRequestCard(sender, i, 'follow');
                }).join('')}
            </div>`;
        }

        return html;
    },

    renderRequestCard(u, index, type) {
        return `
            <div class="request-card-premium" style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 18px; padding: 15px; display: flex; align-items: center; gap: 15px;">
                <img src="${u.avatar || 'assets/logo.png'}" style="width: 50px; height: 50px; border-radius: 14px; object-fit: cover;">
                <div style="flex: 1;">
                    <div style="font-weight: 700; color: #fff; font-size: 0.95rem;">${u.username}</div>
                    <div style="font-size: 0.75rem; color: #64748b;">${type === 'friend' ? 'Sizinle arkadaş olmak istiyor' : 'Sizi takip etmek istiyor'}</div>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button onclick="${type === 'friend' ? 'SocialFeed.acceptFriendRequest' : 'SocialFeed.acceptFollowRequest'}(${index})" 
                        style="background: #10b981; border: none; color: #fff; padding: 8px 15px; border-radius: 10px; font-size: 0.8rem; cursor: pointer; font-weight: 700;">Kabul Et</button>
                    <button onclick="${type === 'friend' ? 'SocialFeed.rejectFriendRequest' : 'SocialFeed.rejectFollowRequest'}(${index})" 
                        style="background: rgba(239, 68, 68, 0.1); border: none; color: #ef4444; padding: 8px 15px; border-radius: 10px; font-size: 0.8rem; cursor: pointer; font-weight: 700;">Reddet</button>
                </div>
            </div>
        `;
    },

    renderSuggestions() {
        // Simple algorithm: Users you are not following, not friends with, excluding yourself
        const user = State.currentUser;
        const following = user.following || [];
        const friends = user.friends || [];
        
        const suggestions = (State.data.users || [])
            .filter(u => u.id !== user.id && !following.includes(u.id) && !friends.includes(u.id))
            .sort((a, b) => (b.socialKarma || 0) - (a.socialKarma || 0))
            .slice(0, 5);

        if (suggestions.length === 0) return '<p style="color: #475569;">Öneri bulunamadı.</p>';

        return suggestions.map(u => `
            <div class="suggestion-card-premium" style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius: 20px; padding: 20px; text-align: center; transition: all 0.3s;" onmouseenter="this.style.background='rgba(255,255,255,0.04)'; this.style.transform='translateY(-5px)'" onmouseleave="this.style.background='rgba(255,255,255,0.02)'; this.style.transform=''">
                <img src="${u.avatar || 'assets/logo.png'}" style="width: 70px; height: 70px; border-radius: 50%; object-fit: cover; margin-bottom: 12px; border: 3px solid rgba(124,58,237,0.2);">
                <div style="font-weight: 800; color: #fff; font-size: 0.9rem; margin-bottom: 4px;">${u.username}</div>
                <div style="font-size: 0.7rem; color: #64748b; margin-bottom: 15px;">${u.socialKarma || 0} Karma</div>
                <button onclick="SocialFeed.toggleFollow('${u.id}')" style="width: 100%; padding: 8px; background: linear-gradient(135deg, #7c3aed, #6d28d9); border: none; color: #fff; border-radius: 10px; font-weight: 700; cursor: pointer; font-size: 0.8rem; transition: 0.2s;">
                    <i class="fa-solid fa-user-plus"></i> Takip Et
                </button>
            </div>
        `).join('');
    },

    filterList(query) {
        const listContainer = document.getElementById('friend-center-list');
        if (listContainer) {
            listContainer.innerHTML = this.renderActiveList(query);
        }
    },

    showQuickMenu(userId) {
        // Could show options to unfriend, block, or view full profile
        Toast.info("Hızlı menü yakında eklenecek.");
    }
};

window.FriendCenter = FriendCenter;
console.log('👥 Friend Center System Loaded!');
