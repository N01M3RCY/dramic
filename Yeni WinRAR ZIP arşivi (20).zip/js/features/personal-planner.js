/**
 * DRAMICBOX - PERSONAL PLANNER
 * User personal calendar, plans and reminders
 */

const PersonalPlanner = {
    init() {
        console.log('📅 Personal Planner Loaded');
        // Check reminders on load
        this.checkReminders();
        // Check reminders every 5 min
        setInterval(() => this.checkReminders(), 5 * 60 * 1000);
    },

    getPlans() {
        if (!State.currentUser) return [];
        return State.currentUser.plans || [];
    },

    async addPlan(data) {
        if (!State.currentUser) {
            Toast.warning('Giriş yapmalısınız!');
            return;
        }

        if (!State.currentUser.plans) State.currentUser.plans = [];

        const plan = {
            id: 'plan-' + Date.now(),
            title: data.title,
            date: data.date,
            time: data.time || null,
            type: data.type || 'custom', // custom, series, watch
            seriesId: data.seriesId || null,
            reminder: data.reminder ?? true,
            reminderMinutes: data.reminderMinutes || 15,
            createdAt: Date.now(),
            completed: false
        };

        State.currentUser.plans.push(plan);
        await this.save();
        Toast.success('Plan eklendi! 📅');
        return plan;
    },

    async deletePlan(planId) {
        if (!State.currentUser) return;
        State.currentUser.plans = (State.currentUser.plans || []).filter(p => p.id !== planId);
        await this.save();
        Toast.success('Plan silindi!');
    },

    async toggleComplete(planId) {
        if (!State.currentUser) return;
        const plan = (State.currentUser.plans || []).find(p => p.id === planId);
        if (plan) {
            plan.completed = !plan.completed;
            await this.save();
        }
    },

    checkReminders() {
        if (!State.currentUser || !State.currentUser.plans) return;

        const now = new Date();
        const plans = State.currentUser.plans.filter(p => !p.completed && p.reminder);

        plans.forEach(plan => {
            if (!plan.date) return;

            const planDate = new Date(plan.date + (plan.time ? 'T' + plan.time : 'T00:00'));
            const reminderTime = new Date(planDate.getTime() - (plan.reminderMinutes || 15) * 60 * 1000);

            // Check if reminder should trigger (within 1 minute window)
            if (now >= reminderTime && now <= planDate && !plan._reminded) {
                this.showReminder(plan);
                plan._reminded = true;
            }
        });
    },

    showReminder(plan) {
        // Browser notification if permitted
        if (Notification.permission === 'granted') {
            new Notification('📅 Hatırlatma: ' + plan.title, {
                body: plan.time ? `Saat ${plan.time}` : 'Bugün',
                icon: '/assets/logo.png'
            });
        }

        // Also show in-app toast
        Toast.info(`📅 Hatırlatma: ${plan.title}`);
    },

    requestNotificationPermission() {
        if ('Notification' in window && Notification.permission !== 'granted') {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    Toast.success('Bildirimler aktif!');
                }
            });
        }
    },

    // Sync with user's watchlist
    syncFromWatchlist() {
        if (!State.currentUser || !State.currentUser.watchlist) return [];

        const calendar = State.data.calendar || [];
        const suggestions = [];

        State.currentUser.watchlist.forEach(wl => {
            const calEntry = calendar.find(c => c.seriesId === wl.seriesId);
            if (calEntry) {
                suggestions.push({
                    seriesId: calEntry.seriesId,
                    day: calEntry.day,
                    time: calEntry.time,
                    seriesTitle: db.getSeries(calEntry.seriesId)?.title || 'Dizi'
                });
            }
        });

        return suggestions;
    },

    async save() {
        if (window.db && db.updateUser) {
            await db.updateUser(State.currentUser.id, { plans: State.currentUser.plans });
        }
        sessionStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
    },

    // --- UI Methods ---

    show() {
        if (!State.currentUser) {
            Toast.warning('Giriş yapmalısınız!');
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal planner-modal';
        modal.id = 'planner-modal';
        modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 700px; max-height: 90vh; overflow-y: auto;">
                <div class="modal-header">
                    <h2 style="display: flex; align-items: center; gap: 10px;">
                        <i class="fa-solid fa-calendar-check" style="color: #8b5cf6;"></i>
                        Kişisel Planlayıcı
                    </h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div style="display: flex; gap: 15px; margin-bottom: 20px;">
                        <button class="btn btn-primary" onclick="PersonalPlanner.showAddPlan()">
                            <i class="fa-solid fa-plus"></i> Yeni Plan
                        </button>
                        <button class="btn btn-outline" onclick="PersonalPlanner.requestNotificationPermission()">
                            <i class="fa-solid fa-bell"></i> Bildirimleri Aç
                        </button>
                    </div>

                    <div id="planner-plans-list">
                        ${this.renderPlansList()}
                    </div>

                    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                        <h4 style="color: #fff; margin-bottom: 15px;">
                            <i class="fa-solid fa-lightbulb" style="color: #fbbf24;"></i> İzleme Önerileri
                        </h4>
                        ${this.renderWatchlistSuggestions()}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    renderPlansList() {
        const plans = this.getPlans();

        if (plans.length === 0) {
            return `<div style="text-align: center; padding: 40px; color: #64748b;">
                <i class="fa-solid fa-calendar-xmark" style="font-size: 3rem; opacity: 0.3; margin-bottom: 15px;"></i>
                <p>Henüz plan eklenmemiş.</p>
            </div>`;
        }

        // Sort by date
        const sortedPlans = [...plans].sort((a, b) => new Date(a.date) - new Date(b.date));

        return `<div style="display: flex; flex-direction: column; gap: 10px;">
            ${sortedPlans.map(plan => {
            const dateObj = new Date(plan.date);
            const isToday = dateObj.toDateString() === new Date().toDateString();
            const isPast = dateObj < new Date();

            return `
                <div style="background: ${plan.completed ? 'rgba(16, 185, 129, 0.1)' : 'rgba(255,255,255,0.03)'}; border: 1px solid ${plan.completed ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255,255,255,0.05)'}; border-radius: 12px; padding: 15px; display: flex; align-items: center; gap: 15px;">
                    <button onclick="PersonalPlanner.toggleComplete('${plan.id}'); PersonalPlanner.refreshList();" style="width: 24px; height: 24px; border-radius: 50%; border: 2px solid ${plan.completed ? '#10b981' : '#64748b'}; background: ${plan.completed ? '#10b981' : 'transparent'}; cursor: pointer; display: flex; align-items: center; justify-content: center;">
                        ${plan.completed ? '<i class="fa-solid fa-check" style="color: white; font-size: 12px;"></i>' : ''}
                    </button>
                    <div style="flex: 1;">
                        <div style="font-weight: 600; color: ${plan.completed ? '#64748b' : '#fff'}; text-decoration: ${plan.completed ? 'line-through' : 'none'};">${plan.title}</div>
                        <div style="font-size: 0.85rem; color: #64748b; margin-top: 3px;">
                            <i class="fa-solid fa-calendar"></i> ${dateObj.toLocaleDateString('tr-TR')}
                            ${plan.time ? ` <i class="fa-solid fa-clock" style="margin-left: 10px;"></i> ${plan.time}` : ''}
                            ${isToday && !plan.completed ? ' <span style="color: #fbbf24; margin-left: 10px;">Bugün!</span>' : ''}
                        </div>
                    </div>
                    <button onclick="PersonalPlanner.deletePlan('${plan.id}'); PersonalPlanner.refreshList();" style="background: none; border: none; color: #ef4444; cursor: pointer; padding: 5px;">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>`;
        }).join('')}
        </div>`;
    },

    renderWatchlistSuggestions() {
        const suggestions = this.syncFromWatchlist();

        if (suggestions.length === 0) {
            return '<p style="color: #64748b; font-size: 0.9rem;">İzleme listenize dizi ekleyerek yayın hatırlatmaları alabilirsiniz.</p>';
        }

        return `<div style="display: flex; flex-wrap: wrap; gap: 10px;">
            ${suggestions.map(s => `
                <div style="background: rgba(139, 92, 246, 0.1); border: 1px solid rgba(139, 92, 246, 0.2); border-radius: 10px; padding: 10px 15px;">
                    <div style="font-weight: 600; color: #a78bfa;">${s.seriesTitle}</div>
                    <div style="font-size: 0.8rem; color: #94a3b8;">${s.day} - ${s.time}</div>
                    <button onclick="PersonalPlanner.addFromSuggestion('${s.seriesId}', '${s.day}', '${s.time}')" style="margin-top: 8px; background: #8b5cf6; border: none; color: white; padding: 5px 10px; border-radius: 6px; cursor: pointer; font-size: 0.75rem;">
                        <i class="fa-solid fa-plus"></i> Ekle
                    </button>
                </div>
            `).join('')}
        </div>`;
    },

    showAddPlan() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'flex';
        modal.style.zIndex = '10000';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 450px;">
                <div class="modal-header">
                    <h2>Yeni Plan Ekle</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Başlık</label>
                        <input type="text" id="plan-title" class="form-input" placeholder="Örn: Dizi izle" required>
                    </div>
                    <div class="form-group">
                        <label>Tarih</label>
                        <input type="date" id="plan-date" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label>Saat (Opsiyonel)</label>
                        <input type="time" id="plan-time" class="form-input">
                    </div>
                    <div class="form-group">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" id="plan-reminder" checked>
                            Hatırlatıcı (15 dk önce)
                        </label>
                    </div>
                    <button onclick="PersonalPlanner.submitNewPlan(); this.closest('.modal').remove();" class="btn btn-primary" style="width: 100%;">
                        <i class="fa-solid fa-plus"></i> Ekle
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async submitNewPlan() {
        const title = document.getElementById('plan-title').value;
        const date = document.getElementById('plan-date').value;
        const time = document.getElementById('plan-time').value;
        const reminder = document.getElementById('plan-reminder').checked;

        if (!title || !date) {
            Toast.error('Başlık ve tarih gerekli!');
            return;
        }

        await this.addPlan({ title, date, time, reminder });
        this.refreshList();
    },

    async addFromSuggestion(seriesId, day, time) {
        const series = db.getSeries(seriesId);
        const nextDate = this.getNextDayDate(day);

        await this.addPlan({
            title: `${series?.title || 'Dizi'} izle`,
            date: nextDate,
            time: time,
            type: 'series',
            seriesId: seriesId,
            reminder: true
        });

        this.refreshList();
    },

    getNextDayDate(dayName) {
        const days = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
        const today = new Date();
        const todayDay = today.getDay();
        const targetDay = days.indexOf(dayName);

        let diff = targetDay - todayDay;
        if (diff <= 0) diff += 7;

        const nextDate = new Date(today);
        nextDate.setDate(today.getDate() + diff);
        return nextDate.toISOString().split('T')[0];
    },

    refreshList() {
        const container = document.getElementById('planner-plans-list');
        if (container) {
            container.innerHTML = this.renderPlansList();
        }
    }
};

window.PersonalPlanner = PersonalPlanner;
