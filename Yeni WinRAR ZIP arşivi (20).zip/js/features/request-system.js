/**
 * DRAMICBOX - REQUEST & REPORT SYSTEM
 * Handles user content requests and bug reports.
 */

const RequestSystem = {
    // Mock Data
    requests: [
        { id: 'req1', userId: 'u1', type: 'request', subject: 'Moving on', desc: 'Dizi eklensin lütfen', status: 'pending', timestamp: Date.now() - 86400000 },
        { id: 'req2', userId: 'u2', type: 'report', subject: 'Video açılmıyor', desc: 'The Impossible Heir 3. bölüm açılmıyor.', status: 'resolved', timestamp: Date.now() - 43200000 }
    ],

    init() {
        console.log('🎫 Request System Loaded');
        if (!State.data.requests) {
            State.data.requests = [];
            // Optional: Save immediately if critical, but lazy init fine
        }
    },

    openModal() {
        if (!State.currentUser) {
            Toast.warning('İstek göndermek için giriş yapmalısınız.');
            return;
        }

        const modal = document.createElement('div');
        modal.className = 'modal request-modal';
        modal.id = 'request-modal';
        modal.style.display = 'flex';

        modal.innerHTML = `
            <div class="modal-content" style="max-width: 500px;">
                <div class="modal-header">
                    <h2>🎫 İstek / Rapor Merkezi</h2>
                    <button class="modal-close" onclick="document.getElementById('request-modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <form onsubmit="event.preventDefault(); RequestSystem.submitForm()">
                        <div class="form-group">
                            <label>Kategori</label>
                            <select id="req-type" class="form-input">
                                <option value="request">Dizi/Webtoon İsteği</option>
                                <option value="report">Hata Bildirimi</option>
                                <option value="other">Diğer</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Konu</label>
                            <input type="text" id="req-subject" class="form-input" placeholder="Kısaca konu nedir?" required>
                        </div>
                        <div class="form-group">
                            <label>Açıklama</label>
                            <textarea id="req-desc" class="form-input" rows="4" placeholder="Detayları buraya yazın..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 15px;">Gönder</button>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async submitForm() {
        const type = document.getElementById('req-type').value;
        const subject = document.getElementById('req-subject').value;
        const desc = document.getElementById('req-desc').value;

        const newReq = {
            id: 'req_' + Date.now(),
            userId: State.currentUser.id,
            username: State.currentUser.username,
            type,
            subject,
            desc,
            status: 'pending',
            timestamp: Date.now()
        };

        if (!State.data.requests) State.data.requests = [];
        State.data.requests.unshift(newReq);

        try {
            await db.save();
            Toast.success('Talebiniz başarıyla iletildi. Admin ekibi ilgilenecektir.');
            document.getElementById('request-modal').remove();
        } catch (e) {
            console.error('Failed to save request:', e);
            Toast.error('Bir hata oluştu, lütfen tekrar deneyin.');
        }
    },

    renderAdminList() {
        const requests = State.data.requests || [];

        if (requests.length === 0) {
            return '<div class="admin-requests-panel"><p style="text-align: center; color: #94a3b8;">Henüz talep bulunmuyor.</p></div>';
        }

        return `
            <div class="admin-requests-panel">
                <h2 style="margin-bottom: 20px;">🎫 İstek ve Raporlar</h2>
                <div class="requests-list" style="display: flex; flex-direction: column; gap: 15px;">
                    ${requests.map(req => `
                        <div class="request-item" style="background: rgba(30, 41, 59, 0.4); padding: 15px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                                <span class="badge" style="background: ${req.type === 'report' ? '#ef4444' : '#10b981'}">${req.type.toUpperCase()}</span>
                                <span style="font-size: 0.8rem; color: #64748b;">${new Date(req.timestamp).toLocaleString()}</span>
                            </div>
                            <div style="font-weight: 700; font-size: 1.1rem; color: #fff;">${req.subject}</div>
                            <div style="color: #94a3b8; font-size: 0.9rem; margin: 10px 0;">${req.desc}</div>
                            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(255,255,255,0.05); pt: 10px; margin-top: 10px;">
                                <span style="color: var(--accent-color);">Gonderen: ${req.username || 'Kullanıcı'}</span>
                                <div style="display: flex; gap: 8px;">
                                    ${req.status === 'pending' ? `
                                        <button class="btn btn-sm btn-success" onclick="RequestSystem.updateStatus('${req.id}', 'resolved')">Çözüldü Olarak İşaretle</button>
                                        <button class="btn btn-sm btn-danger" onclick="RequestSystem.updateStatus('${req.id}', 'rejected')">Reddet</button>
                                    ` : `<span style="font-weight: bold; color: #64748b;">DURUM: ${req.status.toUpperCase()}</span>`}
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    },

    async updateStatus(id, newStatus) {
        const requests = State.data.requests || [];
        const req = requests.find(r => r.id === id);
        if (req) {
            req.status = newStatus;
            try {
                await db.save();
                Toast.info(`Talep durumu "${newStatus}" olarak güncellendi.`);
                if (window.AdminPanelHub && AdminPanelHub.activeTab === 'requests') {
                    AdminPanelHub.switchTab('requests'); // Refresh
                }
            } catch (e) {
                console.error('Update status failed:', e);
                Toast.error('Güncelleme başarısız.');
            }
        }
    },

    getAdminPanelHTML() {
        return this.renderAdminList();
    }
};

window.RequestSystem = RequestSystem;
