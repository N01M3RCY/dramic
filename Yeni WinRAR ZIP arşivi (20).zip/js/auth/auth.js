window.Auth = {
        tempUserData: null,
    _loginSubmitting: false,
    _loginDebounceUntil: 0,

    showLoginError(message) {
        const el = document.getElementById('login-error-msg');
        if (el) {
            el.textContent = message;
            el.classList.add('visible');
        }
        Toast.show(message, 'error');
    },

    clearLoginError() {
        const el = document.getElementById('login-error-msg');
        if (el) {
            el.textContent = '';
            el.classList.remove('visible');
        }
    },

    // ==================== LOGIN ====================
    async login(event) {
        if (event) event.preventDefault();
        
        const identifier = document.getElementById('login-username')?.value.trim();
        const password = document.getElementById('login-password')?.value;

        if (!identifier || !password) {
            Toast.show('Lütfen tüm alanları doldurun.', 'error');
            return;
        }

        try {
            const response = await fetch('api/db.php?action=login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ username: identifier, password: password })
            });
            const data = await response.json();

            if (data.success) {
                this.setCurrentUser(data.user);
                this.closeAuthModal();
                Toast.show(`Hoş geldiniz, ${data.user.username}! 🎉`);
                App.navigate('home');
            } else {
                const msg = data.message || data.error || 'Giriş başarısız!';
                document.getElementById('login-password') && (document.getElementById('login-password').value = '');
                this.showLoginError(msg);
            }
        } catch (e) {
            console.error('Login error:', e);
            Toast.error('Sunucu ile bağlantı kurulamadı.');
        }
    },

    // ==================== REGISTER ====================
    async register(event) {
        if (event) event.preventDefault();

        const email = document.getElementById('register-email')?.value.trim();
        const username = document.getElementById('register-username')?.value.trim();
        const password = document.getElementById('register-password')?.value;
        const passwordConfirm = document.getElementById('register-password-confirm')?.value;

        if (!email || !username || !password) {
            Toast.warning('Tüm alanlar gereklidir!');
            return;
        }

        if (password !== passwordConfirm) {
            Toast.warning('Şifreler uyuşmuyor!');
            return;
        }

        try {
            const response = await fetch('api/db.php?action=register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ email, username, password })
            });
            const data = await response.json();

            if (data.success) {
                this.setCurrentUser(data.user);
                this.closeAuthModal();
                Toast.show(`Kayıt başarılı! Hoş geldiniz, ${username}! 🎉`);
                App.navigate('home');
            } else {
                Toast.show(data.message || 'Kayıt başarısız!', 'error');
            }
        } catch (e) {
            console.error('Register error:', e);
            Toast.error('Sunucu hatası oluştu.');
        }
    },

    // ==================== LOGOUT ====================
    async logout() {
        try {
            await fetch('api/db.php?action=logout', { credentials: 'include' });
            State.currentUser = { role: 'guest' };
            localStorage.removeItem('dramicbox_user');
            this.updateAuthUI();
            App.navigate('home');
            Toast.show('Çıkış yapıldı. Güle güle! 👋');
        } catch (e) {
            console.error('Logout error:', e);
        }
    },

    // ==================== MODAL NAVIGATION ====================
    loginState: 'initial',
    tempEmail: '',
    tempUsername: '',

    togglePasswordlessMode(isPasswordless) {
        const pwdGroup = document.getElementById('login-password-group');
        const identLabel = document.getElementById('login-identifier-label');
        const forgotGroup = document.getElementById('forgot-password-link-group');
        const submitBtn = document.getElementById('login-submit-btn');

        if (isPasswordless) {
            if (pwdGroup) pwdGroup.style.display = 'none';
            if (identLabel) identLabel.textContent = 'E-posta Adresi';
            if (forgotGroup) forgotGroup.style.display = 'none';
            if (submitBtn) submitBtn.textContent = 'Giriş Kodu Gönder';
            document.getElementById('login-password')?.removeAttribute('required');
        } else {
            if (pwdGroup) pwdGroup.style.display = 'block';
            if (identLabel) identLabel.textContent = 'Kullanıcı Adı';
            if (forgotGroup) forgotGroup.style.display = 'block';
            if (submitBtn) submitBtn.textContent = 'Giriş Yap';
            document.getElementById('login-password')?.setAttribute('required', '');
        }
        
        document.getElementById('login-otp-group').style.display = 'none';
        this.loginState = 'initial';
    },

    async handleLoginSubmit(event) {
        if (event) event.preventDefault();

        const now = Date.now();
        if (this._loginSubmitting || now < this._loginDebounceUntil) return;
        this._loginSubmitting = true;
        this._loginDebounceUntil = now + 1200;
        this.clearLoginError();

        const isPasswordless = document.getElementById('login-passwordless-checkbox')?.checked || false;
        const identifier = document.getElementById('login-username')?.value.trim();
        const password = document.getElementById('login-password')?.value;
        const otpCode = document.getElementById('login-otp-code')?.value.trim();

        if (!this.loginState) this.loginState = 'initial';

        try {
        if (isPasswordless) {
            if (this.loginState === 'initial') {
                if (!identifier) {
                    Toast.warning('Lütfen e-posta adresinizi girin.');
                    return;
                }
                Toast.info('Giriş kodu gönderiliyor...');
                try {
                    const response = await fetch('api/db.php?action=send-login-otp', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'include',
                        body: JSON.stringify({ email: identifier })
                    });
                    const data = await response.json();
                    if (data.success) {
                        Toast.success('Doğrulama kodu e-postanıza gönderildi!');
                        document.getElementById('login-otp-group').style.display = 'block';
                        document.getElementById('login-identifier-group').style.display = 'none';
                        document.getElementById('passwordless-toggle-group').style.display = 'none';
                        document.getElementById('login-submit-btn').textContent = 'Kodu Doğrula & Giriş Yap';
                        this.loginState = 'otp_sent';
                        this.tempEmail = identifier;
                    } else {
                        Toast.error(data.message || 'Kod gönderilemedi.');
                    }
                } catch (e) {
                    Toast.error('Bağlantı hatası.');
                }
            } else if (this.loginState === 'otp_sent') {
                if (!otpCode || otpCode.length < 6) {
                    Toast.warning('Lütfen 6 haneli doğrulama kodunu girin.');
                    return;
                }
                try {
                    const response = await fetch('api/db.php?action=verify-login-otp', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'include',
                        body: JSON.stringify({ email: this.tempEmail, code: otpCode })
                    });
                    const data = await response.json();
                    if (data.success) {
                        this.setCurrentUser(data.user);
                        this.closeAuthModal();
                        Toast.show(`Hoş geldiniz, ${data.user.username}! 🎉`);
                        this.resetLoginModalState();
                        App.navigate('home');
                        if (window.DailyReward && DailyReward.claimSilent) {
                            DailyReward.claimSilent();
                        }
                    } else {
                        Toast.error(data.message || 'Hatalı veya süresi dolmuş kod.');
                    }
                } catch (e) {
                    Toast.error('Doğrulama hatası.');
                }
            }
        } else {
            if (this.loginState === 'initial') {
                if (!identifier || !password) {
                    Toast.warning('Lütfen tüm alanları doldurun.');
                    return;
                }
                try {
                    const response = await fetch('api/db.php?action=login', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'include',
                        body: JSON.stringify({ username: identifier, password: password })
                    });
                    const data = await response.json();
                    if (data.success) {
                        if (data.twoFactorRequired) {
                            Toast.info('İki aşamalı doğrulama gerekli. E-postanıza gönderilen kodu girin.');
                            document.getElementById('login-otp-group').style.display = 'block';
                            document.getElementById('login-identifier-group').style.display = 'none';
                            document.getElementById('login-password-group').style.display = 'none';
                            document.getElementById('passwordless-toggle-group').style.display = 'none';
                            document.getElementById('forgot-password-link-group').style.display = 'none';
                            document.getElementById('login-submit-btn').textContent = 'Kodu Doğrula & Giriş Yap';
                            this.loginState = '2fa_required';
                            this.tempUsername = identifier;
                        } else {
                            this.setCurrentUser(data.user);
                            this.closeAuthModal();
                            Toast.show(`Hoş geldiniz, ${data.user.username}! 🎉`);
                            App.navigate('home');
                            if (window.DailyReward && DailyReward.claimSilent) {
                                DailyReward.claimSilent();
                            }
                        }
                    } else {
                        const msg = data.message || data.error || 'Giriş başarısız!';
                        const pwd = document.getElementById('login-password');
                        if (pwd) pwd.value = '';
                        this.showLoginError(msg);
                    }
                } catch (e) {
                    Toast.error('Giriş yapılamadı.');
                }
            } else if (this.loginState === '2fa_required') {
                if (!otpCode || otpCode.length < 6) {
                    Toast.warning('Lütfen 6 haneli doğrulama kodunu girin.');
                    return;
                }
                try {
                    const response = await fetch('api/db.php?action=verify-2fa', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        credentials: 'include',
                        body: JSON.stringify({ username: this.tempUsername, code: otpCode })
                    });
                    const data = await response.json();
                    if (data.success) {
                        this.setCurrentUser(data.user);
                        this.closeAuthModal();
                        Toast.show(`Hoş geldiniz, ${data.user.username}! 🎉`);
                        this.resetLoginModalState();
                        App.navigate('home');
                        if (window.DailyReward && DailyReward.claimSilent) {
                            DailyReward.claimSilent();
                        }
                    } else {
                        Toast.error(data.message || 'Hatalı doğrulama kodu.');
                    }
                } catch (e) {
                    Toast.error('Doğrulama hatası.');
                }
            }
        }
        } finally {
            this._loginSubmitting = false;
        }
    },

    resetLoginModalState() {
        this.loginState = 'initial';
        this.tempEmail = '';
        this.tempUsername = '';
        const identGroup = document.getElementById('login-identifier-group');
        const pwdGroup = document.getElementById('login-password-group');
        const toggleGroup = document.getElementById('passwordless-toggle-group');
        const forgotGroup = document.getElementById('forgot-password-link-group');
        const otpGroup = document.getElementById('login-otp-group');
        const submitBtn = document.getElementById('login-submit-btn');
        const pwdCheckbox = document.getElementById('login-passwordless-checkbox');

        if (identGroup) identGroup.style.display = 'block';
        if (pwdGroup) pwdGroup.style.display = 'block';
        if (toggleGroup) toggleGroup.style.display = 'flex';
        if (forgotGroup) forgotGroup.style.display = 'block';
        if (otpGroup) otpGroup.style.display = 'none';
        if (pwdCheckbox) pwdCheckbox.checked = false;
        
        const usernameInput = document.getElementById('login-username');
        const passwordInput = document.getElementById('login-password');
        const otpCodeInput = document.getElementById('login-otp-code');

        if (usernameInput) usernameInput.value = '';
        if (passwordInput) {
            passwordInput.value = '';
            passwordInput.setAttribute('required', '');
        }
        if (otpCodeInput) otpCodeInput.value = '';
        if (submitBtn) submitBtn.textContent = 'Giriş Yap';
        
        const identLabel = document.getElementById('login-identifier-label');
        if (identLabel) identLabel.textContent = 'Kullanıcı Adı veya E-posta';
    },

    showLogin() {
        this.closeAuthModal();
        this.clearLoginError();
        const loginModal = document.getElementById('login-modal');
        if (loginModal) {
            loginModal.classList.add('show');
            loginModal.style.display = 'flex';
        }
    },

    openLoginModal() {
        this.showLogin();
    },

    showLoginModal() {
        this.showLogin();
    },

    showRegister() {
        this.closeAuthModal();
        const registerModal = document.getElementById('register-modal');
        if (registerModal) {
            registerModal.classList.add('show');
            registerModal.style.display = 'flex';
        }
    },

    openRegisterModal() {
        this.showRegister();
    },

    showRegisterModal() {
        this.showRegister();
    },

    closeAuthModal() {
        this.resetLoginModalState();
        ['login-modal', 'register-modal', 'verify-modal', 'forgot-password-modal', 'reset-password-modal'].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.style.display = 'none';
                el.classList.remove('show');
            }
        });
    },

    showForgotPassword() {
        this.closeAuthModal();
        const forgotModal = document.getElementById('forgot-password-modal');
        if (forgotModal) {
            forgotModal.classList.add('show');
            forgotModal.style.display = 'flex';
        }
    },

    async submitForgotPassword(event) {
        if (event) event.preventDefault();
        const email = document.getElementById('forgot-email')?.value.trim();
        if (!email) {
            Toast.warning('Lütfen e-posta adresinizi girin.');
            return;
        }
        Toast.info('Doğrulama kodu gönderiliyor...');
        try {
            const response = await fetch('api/db.php?action=auth-forgot', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ email: email })
            });
            const data = await response.json();
            if (data.success) {
                Toast.success('Şifre sıfırlama kodu e-postanıza gönderildi!');
                this.closeAuthModal();
                const resetModal = document.getElementById('reset-password-modal');
                if (resetModal) {
                    resetModal.classList.add('show');
                    resetModal.style.display = 'flex';
                }
                this.tempEmail = email;
            } else {
                Toast.error(data.message || 'Kod gönderilemedi.');
            }
        } catch (e) {
            Toast.error('Bağlantı hatası.');
        }
    },

    async submitResetPassword(event) {
        if (event) event.preventDefault();
        const code = document.getElementById('reset-code')?.value.trim();
        const newPassword = document.getElementById('reset-new-password')?.value;
        const email = this.tempEmail;

        if (!email) {
            Toast.error('E-posta adresi bulunamadı. Lütfen sıfırlama işlemini baştan başlatın.');
            return;
        }
        if (!code || !newPassword) {
            Toast.warning('Lütfen tüm alanları doldurun.');
            return;
        }

        Toast.info('Şifreniz güncelleniyor...');
        try {
            const response = await fetch('api/db.php?action=auth-reset', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ email: email, code: code, newPassword: newPassword })
            });
            const data = await response.json();
            if (data.success) {
                Toast.success('Şifreniz başarıyla güncellendi! Giriş yapabilirsiniz.');
                this.showLogin();
            } else {
                Toast.error(data.message || 'Şifre sıfırlama başarısız.');
            }
        } catch (e) {
            Toast.error('Bağlantı hatası.');
        }
    },

    // ==================== SESSION ====================
    setCurrentUser(user) {
        State.currentUser = user;
        localStorage.setItem('dramicbox_user', JSON.stringify(user));
        this.updateAuthUI();
        this.applyNavbarPosition(user?.navbarPosition || 'top');
        
        if (window.AdminChat && window.AdminChat.checkAccess) AdminChat.checkAccess();
        if (window.UserCustomization && window.UserCustomization.init) UserCustomization.init();
    },

    applyNavbarPosition(position) {
        document.body.classList.remove('navbar-top', 'navbar-left', 'navbar-right', 'sidebar-compact');
        if (position && position !== 'top') {
            document.body.classList.add('navbar-' + position);
        }
    },

    setNavbarPosition(position) {
        this.applyNavbarPosition(position);
        // Save to user profile
        if (State.currentUser && State.currentUser.role !== 'guest') {
            State.currentUser.navbarPosition = position;
            localStorage.setItem('dramicbox_user', JSON.stringify(State.currentUser));
            if (window.db) db.save();
        }
        // Save to localStorage for guests
        localStorage.setItem('dramicbox_navbar_pos', position);
        Toast.success(`Menü konumu: ${position === 'top' ? 'Üst' : position === 'left' ? 'Sol' : 'Sağ'}`);
        // Update selector UI
        document.querySelectorAll('.navbar-pos-option').forEach(opt => {
            opt.classList.toggle('selected', opt.dataset.position === position);
        });
    },

    toggleSidebarCompact() {
        document.body.classList.toggle('sidebar-compact');
        const isCompact = document.body.classList.contains('sidebar-compact');
        if (State.currentUser) {
            State.currentUser.sidebarCompact = isCompact;
            if (window.db) db.save();
        }
    },

    async checkPersistentSession() {
        try {
            const response = await fetch('api/db.php?action=check-session', { credentials: 'include' });
            const data = await response.json();
            if (data.success && data.valid) {
                this.setCurrentUser(data.user);
                return data.user;
            } else {
                // If PHP session is invalid/expired but localStorage has user, synchronize it
                const storedUser = localStorage.getItem('dramicbox_user');
                if (storedUser) {
                    try {
                        const user = JSON.parse(storedUser);
                        if (user && user.role !== 'guest' && user.id) {
                            console.log('🔄 Server session expired. Synchronizing session for user:', user.username);
                            const syncRes = await fetch('api/db.php?action=sync-session', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                credentials: 'include',
                                body: JSON.stringify(user)
                            });
                            const syncData = await syncRes.json();
                            if (syncData.success) {
                                this.setCurrentUser(user);
                                return user;
                            }
                        }
                    } catch (err) {
                        console.warn('Failed parsing local user for sync:', err);
                    }
                }
            }
        } catch (e) {
            console.warn('Session check failed', e);
        }
        return null;
    },

    // ==================== UI UPDATE ====================
    updateAuthUI() {
        if (!window.State) return;
        const authContainer = document.getElementById('nav-auth-container');
        const mobileAuthContainer = document.getElementById('mobile-auth-section');
        const currentUser = State.currentUser;
        const isLoggedIn = currentUser && currentUser.role !== 'guest';

        if (!isLoggedIn) {
            if (authContainer) {
                authContainer.innerHTML = `
                    <div style="display:flex; align-items:center; gap:20px;">
                        <a href="#" onclick="Auth.showLogin(); return false;" class="premium-nav-link">Giriş Yap</a>
                        <a href="#" onclick="Auth.showRegister(); return false;" class="premium-nav-link" style="color:var(--ultra-accent);">Üye Ol</a>
                    </div>
                `;
            }
            if (mobileAuthContainer) {
                mobileAuthContainer.innerHTML = `
                    <a href="#" onclick="Auth.showLogin(); return false;" class="mobile-auth-btn mobile-auth-btn-primary">Giriş Yap</a>
                    <a href="#" onclick="Auth.showRegister(); return false;" class="mobile-auth-btn mobile-auth-btn-outline">Üye Ol</a>
                `;
            }
        } else {
            const avatar = currentUser.avatar || 'assets/logo.png';
            const username = currentUser.username || 'Kullanıcı';
            
            if (authContainer) {
                authContainer.innerHTML = `
                    <div class="nav-user-pill" onclick="Auth.toggleDropdown(event)">
                        <img src="${avatar}" class="user-avatar-small" onerror="this.src='assets/logo.png'">
                        <div class="user-info-pill">
                            <span class="user-name-pill">${username}</span>
                            <span class="user-id-pill">#${currentUser.id || '0'} • ${(currentUser.role || 'user').toUpperCase()}</span>
                        </div>
                        <i class="fa-solid fa-chevron-down" style="font-size:0.7rem; color:var(--text-secondary); margin-left:5px;"></i>
                    </div>
                    <div id="user-dropdown" class="glass-card" style="position:absolute; top:calc(100% + 15px); right:0; min-width:280px; padding:20px; display:none; z-index:1000; border-radius:24px; box-shadow:0 20px 50px rgba(0,0,0,0.5); border:1px solid var(--border-premium);">
                        <div class="dropdown-links" style="display:grid; gap:8px;">
                            <a href="#" onclick="App.router('profile', '${currentUser.id}'); Auth.closeDropdown(); return false;" class="premium-nav-link">Profilim</a>
                            ${['admin', 'moderator', 'editor', 'translation_leader', 'editor_leader'].includes(currentUser.role || 'user') ? `<a href="admin.html" class="premium-nav-link" style="color:var(--premium-violet);">Yönetim Paneli</a>` : ''}
                            <div style="border-top:1px solid rgba(255,255,255,0.05); padding-top:10px; margin-top:5px;">
                                <div style="font-size:0.7rem; color:#64748b; text-transform:uppercase; font-weight:700; letter-spacing:1px; margin-bottom:8px;">Menü Konumu</div>
                                <div class="navbar-position-selector" style="padding:8px; gap:6px;">
                                    <div class="navbar-pos-option ${(currentUser.navbarPosition || 'top') === 'top' ? 'selected' : ''}" data-position="top" onclick="Auth.setNavbarPosition('top')" style="padding:8px 6px; font-size:0.7rem;">
                                        <i class="fa-solid fa-arrow-up"></i> Üst
                                    </div>
                                    <div class="navbar-pos-option ${currentUser.navbarPosition === 'left' ? 'selected' : ''}" data-position="left" onclick="Auth.setNavbarPosition('left')" style="padding:8px 6px; font-size:0.7rem;">
                                        <i class="fa-solid fa-arrow-left"></i> Sol
                                    </div>
                                    <div class="navbar-pos-option ${currentUser.navbarPosition === 'right' ? 'selected' : ''}" data-position="right" onclick="Auth.setNavbarPosition('right')" style="padding:8px 6px; font-size:0.7rem;">
                                        <i class="fa-solid fa-arrow-right"></i> Sağ
                                    </div>
                                </div>
                            </div>
                            <a href="#" onclick="Auth.logout(); return false;" class="premium-nav-link" style="color:#ef4444; margin-top:5px;">Çıkış Yap</a>
                        </div>
                    </div>
                `;
            }
            if (mobileAuthContainer) {
                mobileAuthContainer.innerHTML = `
                    <div class="mobile-user-card" onclick="App.router('profile', '${currentUser.id}'); App.toggleMobileMenu();">
                        <img src="${avatar}" class="mobile-user-avatar" onerror="this.src='assets/logo.png'">
                        <div style="display:flex; flex-direction:column; flex:1;">
                            <span style="font-weight:800; color:#fff; font-size:1rem;">${username}</span>
                            <span style="font-size:0.75rem; color:var(--text-muted);">#${currentUser.id || '0'} • ${(currentUser.role || 'user').toUpperCase()}</span>
                        </div>
                        <i class="fa-solid fa-chevron-right" style="color:var(--text-muted); font-size:0.9rem;"></i>
                    </div>
                    <button onclick="Auth.logout(); App.toggleMobileMenu();" class="mobile-auth-btn mobile-auth-btn-outline" style="margin-top: 10px; color: #ef4444; border-color: rgba(239, 68, 68, 0.3); background: rgba(239, 68, 68, 0.05); display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; height: 42px; border-radius: 12px; font-weight: bold; cursor: pointer; border: 1px solid rgba(239, 68, 68, 0.3);">
                        <i class="fa-solid fa-right-from-bracket"></i> Çıkış Yap
                    </button>
                `;
            }
        }
    },

    toggleDropdown(event) {
        if (event) event.stopPropagation();
        const dropdown = document.getElementById('user-dropdown');
        if (dropdown) dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    },

    closeDropdown() {
        const dropdown = document.getElementById('user-dropdown');
        if (dropdown) dropdown.style.display = 'none';
    }
};
document.addEventListener('click', () => window.Auth.closeDropdown());

// Auto-apply saved navbar position on page load
document.addEventListener('DOMContentLoaded', () => {
    const savedPos = localStorage.getItem('dramicbox_navbar_pos');
    if (savedPos && savedPos !== 'top') {
        Auth.applyNavbarPosition(savedPos);
    }
});
