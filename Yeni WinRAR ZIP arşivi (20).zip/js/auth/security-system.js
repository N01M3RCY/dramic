// Security & Protection System
const SecuritySystem = {
    init() {
        console.log('🔒 Security System initialized');
        this.enableRightClickProtection();
        this.enableDevToolsProtection();
        this.enableCopyProtection();
        this.enableScreenshotProtection();
        this.setupBlackoutScreen();
    },

    // Siyah ekran elementini oluştur
    setupBlackoutScreen() {
        if (!document.getElementById('security-blackout')) {
            const blackout = document.createElement('div');
            blackout.id = 'security-blackout';
            blackout.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                background: #000;
                z-index: 2147483647;
                display: none;
                align-items: center;
                justify-content: center;
                color: #ff3333;
                font-family: system-ui, -apple-system, sans-serif;
                flex-direction: column;
                text-align: center;
            `;
            blackout.innerHTML = `
                <div style="font-size: 5rem; margin-bottom: 20px;"><i class="fa-solid fa-shield-halved"></i></div>
                <h1 style="font-size: 2rem; margin: 0;">GÜVENLİK UYARISI</h1>
                <p style="font-size: 1.2rem; margin-top: 10px; color: #fff;">Ekran görüntüsü almak veya geliştirici araçlarını kullanmak yasaktır.</p>
            `;
            document.body.appendChild(blackout);
        }
    },

    // Ekranı karart
    triggerBlackout(duration = 2000) {
        const blackout = document.getElementById('security-blackout');
        if (blackout) {
            blackout.style.display = 'flex';

            // Clipboard'u temizle (Sadece odaklanmışsa çalışır, hatayı yoksay)
            try {
                navigator.clipboard.writeText(' ').catch(() => { });
            } catch (e) { /* ignore */ }

            if (duration > 0) {
                setTimeout(() => {
                    blackout.style.display = 'none';
                }, duration);
            }
        }
    },

    // Sağ tık engelleme
    enableRightClickProtection() {
        document.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showProtectionMessage('Sağ tık devre dışı bırakıldı!');
            return false;
        });
        console.log('✅ Right-click protection enabled');
    },

    // F12 ve DevTools engelleme
    enableDevToolsProtection() {
        // Tuş kombinasyonları
        document.addEventListener('keydown', (e) => {
            // F12
            if (e.key === 'F12' || e.keyCode === 123) {
                e.preventDefault();
                this.triggerBlackout(3000);
                this.showProtectionMessage('Geliştirici araçları devre dışı!');
                return false;
            }

            // Ctrl+Shift+I, J, C (DevTools)
            if (e.ctrlKey && e.shiftKey && (['I', 'J', 'C'].includes(e.key.toUpperCase()))) {
                e.preventDefault();
                this.triggerBlackout(3000);
                this.showProtectionMessage('Geliştirici araçları devre dışı!');
                return false;
            }

            // Ctrl+U (View Source)
            if (e.ctrlKey && (e.key === 'u' || e.key === 'U')) {
                e.preventDefault();
                this.triggerBlackout(3000);
                this.showProtectionMessage('Kaynak kodu görüntüleme devre dışı!');
                return false;
            }
        });

        // Debugger Trap - Gelişmiş Tespit
        // Bu yöntem, devtools açıkken debugger'ın duraklamasından kaynaklanan zaman farkını ölçer
        /* 
           NOT: Bu yöntem çok agresiftir ve bazen normal kullanımı etkileyebilir. 
           Şimdilik daha hafif bir versiyon kullanıyoruz. 
        */
        const devtoolsTrap = () => {
            // Mobile devices often have variable innerHeight/outerHeight due to browser chrome (address bar)
            // This causes false positives. We disable this check for mobile devices.
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth < 1000) {
                return;
            }

            const widthThreshold = window.outerWidth - window.innerWidth > 160;
            const heightThreshold = window.outerHeight - window.innerHeight > 160;

            if (widthThreshold || heightThreshold) {
                this.triggerBlackout(0); // Süresiz karartma, araçlar kapanana kadar
            } else {
                const blackout = document.getElementById('security-blackout');
                if (blackout && blackout.style.display === 'flex' && !this.isScreenshotActive) {
                    blackout.style.display = 'none';
                }
            }
        };

        setInterval(devtoolsTrap, 1000);
        console.log('✅ DevTools protection enabled');
    },

    // Kopyalama engelleme
    enableCopyProtection() {
        const preventAction = (e) => {
            if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
                e.preventDefault();
                return false;
            }
        };

        document.addEventListener('selectstart', preventAction);
        document.addEventListener('copy', (e) => {
            if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
                e.preventDefault();
                this.showProtectionMessage('Kopyalama devre dışı!');
                return false;
            }
        });
        document.addEventListener('cut', preventAction);
        document.addEventListener('dragstart', (e) => e.preventDefault());

        console.log('✅ Copy protection enabled');
    },

    isScreenshotActive: false,

    // Gelişmiş Ekran Görüntüsü Engelleme
    enableScreenshotProtection() {
        // Tuş Dinleyicisi
        document.addEventListener('keydown', (e) => {
            // Windows Tuşu (MetaKey) - ANINDA KARARTMA
            if (e.metaKey || e.key === 'Meta' || e.key === 'OS') {
                this.isScreenshotActive = true;
                // Kullanıcı Windows tuşuna bastığı an ekranı karartıyoruz
                // Bu, Snipping Tool açılmadan önce görüntüyü gizler
                this.triggerBlackout(0); // Süresiz aç, keyup veya blur ile yönetilecek
            }

            // Windows + Shift + S (Snipping Tool) - Ekstra Güvenlik
            if ((e.metaKey || e.key === 'Meta') && e.shiftKey && (e.key === 's' || e.key === 'S')) {
                this.isScreenshotActive = true;
                this.triggerBlackout(7000);
                this.showProtectionMessage('Ekran alıntısı aracı tespit edildi!');
                navigator.clipboard.writeText(' ');
                e.preventDefault();
            }

            // Print Screen - ANINDA KARARTMA
            if (e.key === 'PrintScreen' || e.keyCode === 44) {
                this.isScreenshotActive = true;
                this.triggerBlackout(3000); // 3 saniye yeterli
                this.showProtectionMessage('Ekran görüntüsü alınamaz!');
                navigator.clipboard.writeText(' ');
                e.preventDefault();
            }

            // Alt + PrintScreen
            if (e.altKey && (e.key === 'PrintScreen' || e.keyCode === 44)) {
                this.triggerBlackout(3000);
                navigator.clipboard.writeText(' ');
                e.preventDefault();
            }
        });

        document.addEventListener('keyup', (e) => {
            if (e.key === 'Meta' || e.key === 'OS') {
                // Windows tuşu bırakıldığında
                // Eğer hemen arkasından Shift+S gelmediyse (blur olmadıysa) karartmayı kaldır
                // Ancak Snipping Tool açıldıysa 'blur' event'i devreye girmiştir bile.

                setTimeout(() => {
                    // Eğer pencere hala odaktaysa (yani snipping tool arayüzü açılmadıysa)
                    if (document.hasFocus()) {
                        this.isScreenshotActive = false;
                        const blackout = document.getElementById('security-blackout');
                        // Devtools açık değilse kapat
                        const widthThreshold = window.outerWidth - window.innerWidth > 160;
                        const heightThreshold = window.outerHeight - window.innerHeight > 160;

                        if (blackout && !widthThreshold && !heightThreshold) {
                            blackout.style.display = 'none';
                        }
                    }
                }, 500); // Yarım saniye bekle (yanlışlıkla basmalara karşı tolerans)
            }
        });

        // Window Blur Detection (Pencere odağını kaybettiğinde)
        // Snipping tool açıldığında pencere odağını kaybeder.
        window.addEventListener('blur', () => {
            // Windows tuşuna basılmışsa ve odak kayboluyorsa kesin screenshot girişimidir
            if (this.isScreenshotActive) {
                this.triggerBlackout(0); // Odaklanana kadar karart
            }
        });

        window.addEventListener('focus', () => {
            // Pencere tekrar odaklandığında
            // Eğer screenshot modundaysak bir süre daha bekleyip açalım
            if (this.isScreenshotActive) {
                setTimeout(() => {
                    this.isScreenshotActive = false;
                    // Kapatma kontrolü (DevTools vs.)
                    const blackout = document.getElementById('security-blackout');
                    const widthThreshold = window.outerWidth - window.innerWidth > 160;
                    const heightThreshold = window.outerHeight - window.innerHeight > 160;
                    if (blackout && !widthThreshold && !heightThreshold) {
                        blackout.style.display = 'none';
                    }
                }, 1000);
            }
        });

        console.log('✅ Advanced Screenshot protection enabled');
    },

    // Koruma mesajı göster
    showProtectionMessage(message) {
        if (typeof Toast !== 'undefined') {
            Toast.warning(message);
        } else {
            console.log('Security Warning:', message);
        }
    },

    // Korumayı devre dışı bırak (Admin rozeti için)
    disableProtection() {
        const hasAdminBadge = State.currentUser?.badges?.includes('Admin');

        if (hasAdminBadge) {
            console.log('⚠️ Protection disabled for Admin badge holder');
            // Elementi kaldır
            const blackout = document.getElementById('security-blackout');
            if (blackout) blackout.remove();

            // Event listener'ları kaldırmak zor olduğu için (named function kullanmadık),
            // sadece reload öneriyoruz veya flag kullanıyoruz.
            // Basitçe init metodunu by-pass etmek daha kolay.
            Toast.info('Koruma Admin için pasif (Sayfa yenilendiğinde aktif olabilir)');
        }
    }
};

// Auto-initialize
window.addEventListener('load', () => {
    setTimeout(() => {
        const hasAdminBadge = State.currentUser?.badges?.includes('Admin');
        if (!hasAdminBadge) {
            SecuritySystem.init();
        } else {
            console.log('ℹ️ Admin - Security Disabled');
        }
    }, 1000);
});

// CSS animasyonu
if (!document.getElementById('security-system-styles')) {
    const securityStyle = document.createElement('style');
    securityStyle.id = 'security-system-styles';
    securityStyle.textContent = `
        @keyframes slideIn { from { transform: translateX(400px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    `;
    document.head.appendChild(securityStyle);
}

console.log('✅ Security System Module Loaded!');
