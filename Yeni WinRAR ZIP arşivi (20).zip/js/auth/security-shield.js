/**
 * DramiBox Security Shield
 * Client-side DDoS mitigation and bot detection
 */
const SecurityShield = {
    config: {
        maxRequestsPerMinute: 60,
        requestWindowMs: 60000,
        botDetection: true,
        throttleDelay: 200 // ms
    },

    state: {
        requestLog: [],
        isThrottled: false,
        isBotSuspect: false,
        mouseMoveCount: 0,
        hasInteracted: false
    },

    init() {
        // SecurityShield disabled — no longer hooking fetch or doing bot detection
        console.log('🛡️ Security Shield Disabled');
    },

    setupInteractions() {
        // Detect real human interaction
        const onInteract = () => {
            this.state.hasInteracted = true;
            window.removeEventListener('mousemove', onInteract);
            window.removeEventListener('keydown', onInteract);
            window.removeEventListener('scroll', onInteract);
        };

        window.addEventListener('mousemove', onInteract);
        window.addEventListener('keydown', onInteract);
        window.addEventListener('scroll', onInteract);

        // Simple bot detection: check for rapid mouse movements or lack of typical human patterns
        window.addEventListener('mousemove', (e) => {
            if (this.state.mouseMoveCount < 100) {
                this.state.mouseMoveCount++;
            }
        });
    },

    /**
     * Intercept all fetch requests to enforce client-side throttling
     */
    hookFetch() {
        const originalFetch = window.fetch;
        const self = this;

        window.fetch = async function (...args) {
            const url = args[0];

            // Only protect our API calls
            if (typeof url === 'string' && (url.includes('/api/') || url.includes('api.php'))) {

                // 1. Check Rate Limit
                if (self.isOverLimit()) {
                    console.warn('⚠️ Client-side rate limit exceeded. Request delayed.');
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }

                // 2. Bot Check (if no interaction yet and making API calls)
                if (!self.state.hasInteracted && self.state.requestLog.length > 5) {
                    self.state.isBotSuspect = true;
                    // Inject a fake delay or challenge if suspect
                }

                // 3. Global Throttle
                if (self.state.isThrottled) {
                    await new Promise(resolve => setTimeout(resolve, self.config.throttleDelay));
                }

                self.recordRequest();

                const response = await originalFetch(...args);

                // Handle server-side rate limit response
                if (response.status === 429) {
                    const data = await response.clone().json();
                    self.handleRateLimitError(data);
                }

                return response;
            }

            return originalFetch(...args);
        };
    },

    isOverLimit() {
        const now = Date.now();
        const windowStart = now - this.config.requestWindowMs;

        // Remove old entries
        this.state.requestLog = this.state.requestLog.filter(ts => ts > windowStart);

        return this.state.requestLog.length >= this.config.maxRequestsPerMinute;
    },

    recordRequest() {
        this.state.requestLog.push(Date.now());
    },

    handleRateLimitError(data) {
        if (typeof Toast !== 'undefined') {
            Toast.error(`🛡️ Güvenlik Sistemi: Çok fazla istek! Lütfen ${data.retryAfter || 5} saniye bekleyin.`, 5000);
        } else {
            alert(`Çok fazla istek yaptınız. Lütfen ${data.retryAfter || 5} saniye bekleyin.`);
        }

        // Add a local block
        this.state.isThrottled = true;
        setTimeout(() => {
            this.state.isThrottled = false;
        }, (data.retryAfter || 5) * 1000);
    }
};

// Start protection
SecurityShield.init();
