// DramicBox Service Worker - PWA & Offline Support
const CACHE_NAME = 'dramicbox-v3';
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/assets/logo.png',
    '/assets/manifest.json'
];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => cache.addAll(STATIC_ASSETS))
    );
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then(keys => Promise.all(
            keys.map(key => {
                if (key !== CACHE_NAME) return caches.delete(key);
            })
        ))
    );
    self.clients.claim(); // Take control of clients immediately
});

self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    // 1. Bypass Service Worker for uploads and API POST requests
    if (
        event.request.method === 'POST' ||
        url.pathname.includes('upload-video') ||
        url.pathname.includes('upload-subtitle') ||
        url.pathname.includes('api/db.php') ||
        url.searchParams.has('action')
    ) {
        return;
    }

    // 2. Webtoon Image Caching (Cache-First)
    if (url.pathname.includes('/uploads/webtoon/') || url.pathname.endsWith('.jpg') || url.pathname.endsWith('.png') || url.pathname.endsWith('.webp')) {
        event.respondWith(
            caches.match(event.request).then(cached => {
                return cached || fetch(event.request).then(response => {
                    const copy = response.clone();
                    caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
                    return response;
                });
            })
        );
        return;
    }

    // 3. App Shell, JS & CSS - Network-First (always get fresh code)
    if (STATIC_ASSETS.includes(url.pathname) || url.pathname.startsWith('/css/') || url.pathname.startsWith('/js/')) {
        event.respondWith(
            fetch(event.request).then(response => {
                const copy = response.clone();
                caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
                return response;
            }).catch(() => caches.match(event.request))
        );
        return;
    }

    // 4. Everything else (Network-First)
    event.respondWith(
        fetch(event.request).catch(() => caches.match(event.request))
    );
});

// --- WEB PUSH NOTIFICATIONS ---
self.addEventListener('push', (event) => {
    let data = { title: 'DramicBox', body: 'Yeni bir bildiriminiz var!', icon: '/assets/logo.png' };
    
    if (event.data) {
        try {
            data = event.data.json();
        } catch (e) {
            data.body = event.data.text();
        }
    }

    const options = {
        body: data.body,
        icon: data.icon || '/assets/logo.png',
        badge: '/assets/logo.png',
        data: {
            url: data.url || '/'
        },
        vibrate: [100, 50, 100],
        actions: [
            { action: 'open', title: 'Görüntüle' }
        ]
    };

    event.waitUntil(
        self.registration.showNotification(data.title, options)
    );
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    const urlToOpen = event.notification.data.url;

    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
            for (let i = 0; i < windowClients.length; i++) {
                const client = windowClients[i];
                if (client.url === urlToOpen && 'focus' in client) {
                    return client.focus();
                }
            }
            if (clients.openWindow) {
                return clients.openWindow(urlToOpen);
            }
        })
    );
});
