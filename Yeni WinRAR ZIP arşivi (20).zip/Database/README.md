# Database Klasör Yapısı

Bu klasör, DramicBox uygulamasının tüm veritabanı dosyalarını organize bir şekilde tutar.

## Yapı:

```
/Database/
├── kullanicilar/           # Kullanıcı verileri
│   └── user-{id}.json      # Her kullanıcı için ayrı dosya
├── diziler/                # Dizi ve webtoon verileri
│   └── {series-slug}.json  # Her dizi için ayrı dosya
├── party-rooms/            # Watch Party odaları
│   └── room-{id}.json      # Her oda için ayrı dosya
├── blog/                   # Blog yazıları
│   └── {post-id}.json      # Her yazı için ayrı dosya
├── tickets/                # Destek talepleri
│   └── {ticket-id}.json    # Her talep için ayrı dosya
└── actors/                 # Oyuncu bilgileri
    └── {actor-slug}.json   # Her oyuncu için ayrı dosya
```

## Nasıl Çalışır:

1. **Veri Okuma**: `Database.php` tüm klasörlerdeki JSON dosyalarını okuyarak birleştiriri
2. **Veri Yazma**: Yeni veri eklendiğinde ilgili klasöre JSON dosyası oluşturulur
3. **Güncelleme**: Mevcut veri güncellendiğinde ilgili dosya güncellenir
4. **Silme**: Veri silindiğinde ilgili dosya silinir

## Avantajları:

- Her veri türü için ayrı klasör
- Daha kolay yedekleme ve geri yükleme
- Git ile versiyon kontrolü daha kolay
- Büyük JSON dosyalarından kaçınma
